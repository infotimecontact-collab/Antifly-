import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { db } from './server/db';
import {
  queryWiseAIShopping,
  parseVoiceIntent,
  matchProductFromImage,
  askPdpAssistant,
  queryAdminAnalytics,
} from './server/gemini';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON payload parsers with high limit for image uploads
  app.use(express.json({ limit: '15mb' }));
  app.use(express.urlencoded({ extended: true, limit: '15mb' }));

  // --- API ROUTE HANDLERS ---

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', store: 'WiseIndia Omnichannel E-Commerce', timestamp: new Date().toISOString() });
  });

  // 1. Products API
  app.get('/api/products', (req, res) => {
    const { category, search, minPrice, maxPrice, sort, featured, tag } = req.query;
    let list = [...db.products];

    if (category && category !== 'all') {
      list = list.filter(
        (p) =>
          p.category.toLowerCase() === String(category).toLowerCase() ||
          p.subcategory.toLowerCase() === String(category).toLowerCase()
      );
    }
    if (tag) {
      list = list.filter((p) => p.tags.includes(String(tag)));
    }
    if (featured === 'true') {
      list = list.filter((p) => p.isFeatured);
    }
    if (search) {
      const q = String(search).toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q)) ||
          p.searchKeywords.some((k) => k.toLowerCase().includes(q))
      );
    }
    if (minPrice) {
      list = list.filter((p) => p.price >= Number(minPrice));
    }
    if (maxPrice) {
      list = list.filter((p) => p.price <= Number(maxPrice));
    }

    if (sort === 'price-low') {
      list.sort((a, b) => a.price - b.price);
    } else if (sort === 'price-high') {
      list.sort((a, b) => b.price - a.price);
    } else if (sort === 'rating') {
      list.sort((a, b) => b.rating - a.rating);
    } else if (sort === 'discount') {
      list.sort((a, b) => b.discountPercentage - a.discountPercentage);
    }

    res.json({ success: true, count: list.length, products: list });
  });

  app.get('/api/products/:id', (req, res) => {
    const product = db.products.find((p) => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }
    res.json({ success: true, product });
  });

  app.post('/api/products', (req, res) => {
    const newProduct = db.addProduct(req.body);
    res.status(201).json({ success: true, product: newProduct });
  });

  app.put('/api/products/:id', (req, res) => {
    const updated = db.updateProduct(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }
    res.json({ success: true, product: updated });
  });

  app.delete('/api/products/:id', (req, res) => {
    const success = db.deleteProduct(req.params.id);
    res.json({ success });
  });

  // 2. Categories API
  app.get('/api/categories', (req, res) => {
    res.json({ success: true, categories: db.categories });
  });

  app.post('/api/categories', (req, res) => {
    const newCat = { ...req.body, id: `cat-${Date.now()}` };
    db.categories.push(newCat);
    db.logAudit('Category Created', 'Products', `Created category: ${newCat.name}`);
    res.json({ success: true, category: newCat });
  });

  // 3. Banners API
  app.get('/api/banners', (req, res) => {
    res.json({ success: true, banners: db.banners });
  });

  app.post('/api/banners', (req, res) => {
    const newBanner = { ...req.body, id: `ban-${Date.now()}` };
    db.banners.push(newBanner);
    db.logAudit('Banner Created', 'Banners', `Created banner: ${newBanner.title}`);
    res.json({ success: true, banner: newBanner });
  });

  app.put('/api/banners/:id', (req, res) => {
    const idx = db.banners.findIndex((b) => b.id === req.params.id);
    if (idx !== -1) {
      db.banners[idx] = { ...db.banners[idx], ...req.body };
      db.logAudit('Banner Updated', 'Banners', `Updated banner: ${db.banners[idx].title}`);
      return res.json({ success: true, banner: db.banners[idx] });
    }
    res.status(404).json({ success: false });
  });

  app.delete('/api/banners/:id', (req, res) => {
    db.banners = db.banners.filter((b) => b.id !== req.params.id);
    db.logAudit('Banner Deleted', 'Banners', `Removed banner ID: ${req.params.id}`);
    res.json({ success: true });
  });

  // 4. Homepage Sections CMS
  app.get('/api/homepage-sections', (req, res) => {
    res.json({ success: true, sections: db.homepageSections });
  });

  app.put('/api/homepage-sections', (req, res) => {
    if (Array.isArray(req.body.sections)) {
      db.homepageSections = req.body.sections;
      db.logAudit('Homepage Layout Updated', 'CMS', 'Reordered/updated homepage modular blocks');
      return res.json({ success: true, sections: db.homepageSections });
    }
    res.status(400).json({ success: false, message: 'Invalid sections array' });
  });

  // 5. Cart API (Omnichannel Synchronized)
  app.get('/api/cart', (req, res) => {
    res.json({ success: true, cart: db.cart });
  });

  app.post('/api/cart/add', (req, res) => {
    const item = db.addToCart(req.body);
    res.json({ success: true, cart: db.cart, item });
  });

  app.put('/api/cart/update', (req, res) => {
    const { id, quantity } = req.body;
    db.updateCartQuantity(id, quantity);
    res.json({ success: true, cart: db.cart });
  });

  app.delete('/api/cart/:id', (req, res) => {
    db.removeFromCart(req.params.id);
    res.json({ success: true, cart: db.cart });
  });

  app.post('/api/cart/clear', (req, res) => {
    db.clearCart();
    res.json({ success: true, cart: [] });
  });

  // 6. Wishlist API
  app.get('/api/wishlist', (req, res) => {
    res.json({ success: true, wishlist: db.wishlist });
  });

  app.post('/api/wishlist/toggle', (req, res) => {
    const result = db.toggleWishlist(req.body.productId);
    res.json({ success: true, ...result });
  });

  // 7. Orders API
  app.get('/api/orders', (req, res) => {
    const { source, status } = req.query;
    let list = [...db.orders];
    if (source && source !== 'All') {
      list = list.filter((o) => o.source.toLowerCase() === String(source).toLowerCase());
    }
    if (status && status !== 'All') {
      list = list.filter((o) => o.status.toLowerCase() === String(status).toLowerCase());
    }
    res.json({ success: true, count: list.length, orders: list });
  });

  app.get('/api/orders/:id', (req, res) => {
    const order = db.orders.find((o) => o.id === req.params.id || o.orderNumber === req.params.id);
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });
    res.json({ success: true, order });
  });

  app.post('/api/orders', (req, res) => {
    const newOrder = db.createOrder(req.body);
    res.status(201).json({ success: true, order: newOrder });
  });

  app.patch('/api/orders/:id/status', (req, res) => {
    const { status, courierName, trackingNumber } = req.body;
    const updated = db.updateOrderStatus(req.params.id, status, courierName, trackingNumber);
    if (!updated) return res.status(404).json({ success: false, message: 'Order not found' });
    res.json({ success: true, order: updated });
  });

  // 8. Coupons API
  app.get('/api/coupons', (req, res) => {
    res.json({ success: true, coupons: db.coupons });
  });

  app.post('/api/coupons/apply', (req, res) => {
    const { code, cartTotal, source } = req.body;
    const coupon = db.coupons.find(
      (c) => c.code.toUpperCase() === String(code).trim().toUpperCase() && c.isActive
    );

    if (!coupon) {
      return res.status(400).json({ success: false, message: 'Invalid or expired coupon code.' });
    }

    if (coupon.minCartValue && cartTotal < coupon.minCartValue) {
      return res.status(400).json({
        success: false,
        message: `Minimum cart value of ₹${coupon.minCartValue} required for ${coupon.code}.`,
      });
    }

    if (coupon.appOnly && source === 'Website') {
      return res.status(400).json({
        success: false,
        message: `Coupon ${coupon.code} is exclusively available on WiseIndia Android & iOS apps!`,
      });
    }

    let discountAmount = 0;
    if (coupon.discountType === 'percentage') {
      discountAmount = Math.round((cartTotal * coupon.discountValue) / 100);
      if (coupon.maxDiscount && discountAmount > coupon.maxDiscount) {
        discountAmount = coupon.maxDiscount;
      }
    } else {
      discountAmount = coupon.discountValue;
    }

    res.json({
      success: true,
      coupon,
      discountAmount,
      message: `Coupon ${coupon.code} applied! Saved ₹${discountAmount}.`,
    });
  });

  app.post('/api/coupons', (req, res) => {
    const newCoupon = { ...req.body, id: `c-${Date.now()}`, usedCount: 0 };
    db.coupons.push(newCoupon);
    db.logAudit('Coupon Created', 'Coupons', `Created promo code: ${newCoupon.code}`);
    res.json({ success: true, coupon: newCoupon });
  });

  // 9. Returns & Exchanges API
  app.get('/api/returns', (req, res) => {
    res.json({ success: true, returns: db.returns });
  });

  app.post('/api/returns', (req, res) => {
    const newReturn: any = {
      ...req.body,
      id: `ret-${Date.now()}`,
      status: 'Pending',
      createdAt: new Date().toISOString(),
    };
    db.returns.unshift(newReturn);

    // Update order return status
    const order = db.orders.find((o) => o.id === req.body.orderId || o.orderNumber === req.body.orderNumber);
    if (order) {
      order.returnStatus = 'Requested';
      order.returnReason = req.body.reason;
    }

    db.logAudit('Return Requested', 'Returns', `Return requested for Order #${req.body.orderNumber}`);
    res.json({ success: true, returnRequest: newReturn });
  });

  app.patch('/api/returns/:id/status', (req, res) => {
    const { status } = req.body;
    const item = db.returns.find((r) => r.id === req.params.id);
    if (!item) return res.status(404).json({ success: false });
    item.status = status;

    const order = db.orders.find((o) => o.orderNumber === item.orderNumber);
    if (order) {
      if (status === 'Approved') order.returnStatus = 'Approved';
      if (status === 'Rejected') order.returnStatus = 'Rejected';
      if (status === 'Completed') {
        order.returnStatus = item.type === 'Refund' ? 'Refunded' : 'Exchanged';
        order.status = item.type === 'Refund' ? 'Refunded' : 'Returned';
      }
    }

    db.logAudit('Return Processed', 'Returns', `Return request for Order #${item.orderNumber} set to ${status}`);
    res.json({ success: true, returnRequest: item });
  });

  // 10. Customers & Abandoned Carts API
  app.get('/api/customers', (req, res) => {
    res.json({ success: true, customers: db.customers });
  });

  app.get('/api/abandoned-carts', (req, res) => {
    res.json({ success: true, abandonedCarts: db.abandonedCarts });
  });

  app.post('/api/abandoned-carts/:id/remind', (req, res) => {
    const item = db.abandonedCarts.find((a) => a.id === req.params.id);
    if (item) {
      item.reminderSent = true;
      item.reminderCount += 1;
      db.notifications.unshift({
        id: `notif-${Date.now()}`,
        title: 'Abandoned Cart Reminder Sent',
        message: `Recovery reminder dispatched to ${item.customerName} (${item.customerEmail}) with special 5% nudge coupon.`,
        type: 'promo',
        timestamp: 'Just now',
        isRead: false,
      });
      return res.json({ success: true, abandonedCart: item });
    }
    res.status(404).json({ success: false });
  });

  // 11. Audit Logs & Notifications & CMS & Settings API
  app.get('/api/audit-logs', (req, res) => {
    res.json({ success: true, logs: db.auditLogs });
  });

  app.get('/api/notifications', (req, res) => {
    res.json({ success: true, notifications: db.notifications });
  });

  app.patch('/api/notifications/mark-read', (req, res) => {
    db.notifications.forEach((n) => (n.isRead = true));
    res.json({ success: true });
  });

  app.get('/api/cms-pages', (req, res) => {
    res.json({ success: true, pages: db.cmsPages });
  });

  app.put('/api/cms-pages/:slug', (req, res) => {
    const page = db.cmsPages.find((p) => p.slug === req.params.slug);
    if (page) {
      page.content = req.body.content || page.content;
      page.title = req.body.title || page.title;
      page.lastUpdated = new Date().toISOString().split('T')[0];
      db.logAudit('CMS Page Edited', 'CMS', `Updated content for ${page.title}`);
      return res.json({ success: true, page });
    }
    res.status(404).json({ success: false });
  });

  app.get('/api/settings', (req, res) => {
    res.json({ success: true, settings: db.settings });
  });

  app.put('/api/settings', (req, res) => {
    db.settings = { ...db.settings, ...req.body };
    db.logAudit('Settings Updated', 'Settings', 'Updated global store configuration');
    res.json({ success: true, settings: db.settings });
  });

  // 12. WiseAI Intelligence Endpoints

  // WiseAI Shopping Assistant
  app.post('/api/wiseai/chat', async (req, res) => {
    try {
      const { message, history } = req.body;
      const result = await queryWiseAIShopping(message, db.products, history || []);
      res.json({ success: true, ...result });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Multilingual Voice Search Parser (English, Hindi, Hinglish)
  app.post('/api/wiseai/voice', async (req, res) => {
    try {
      const { transcript } = req.body;
      const result = await parseVoiceIntent(transcript, db.products);
      res.json({ success: true, ...result });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Visual Image Search
  app.post('/api/wiseai/image-search', async (req, res) => {
    try {
      const { imageBase64, mimeType } = req.body;
      const result = await matchProductFromImage(imageBase64, mimeType || 'image/jpeg', db.products);
      res.json({ success: true, ...result });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Product Detail Page "Ask WiseAI" Assistant
  app.post('/api/wiseai/pdp-assistant', async (req, res) => {
    try {
      const { productId, question } = req.body;
      const product = db.products.find((p) => p.id === productId);
      if (!product) return res.status(404).json({ success: false, message: 'Product not found' });
      const result = await askPdpAssistant(product, question);
      res.json({ success: true, ...result });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Admin WiseAI Analytics Assistant
  app.post('/api/wiseai/admin-analytics', async (req, res) => {
    try {
      const { query } = req.body;
      const totalRevenue = db.orders.reduce((sum, o) => sum + o.totalAmount, 0);
      const totalOrders = db.orders.length;
      const webOrders = db.orders.filter((o) => o.source === 'Website').length;
      const androidOrders = db.orders.filter((o) => o.source === 'Android App').length;
      const iosOrders = db.orders.filter((o) => o.source === 'iOS App').length;
      const lowStockCount = db.products.filter((p) => p.totalStock < 40).length;

      const summary = {
        totalRevenue,
        totalOrders,
        ordersBySource: {
          Website: webOrders,
          Android: androidOrders,
          iOS: iosOrders,
        },
        customersCount: db.customers.length,
        totalProducts: db.products.length,
        lowStockCount,
      };

      const result = await queryAdminAnalytics(query, summary);
      res.json({ success: true, ...result });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Vite middleware for development & production static fallback
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`WiseIndia Omnichannel Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
