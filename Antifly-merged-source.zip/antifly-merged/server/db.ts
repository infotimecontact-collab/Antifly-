import {
  Product,
  Category,
  Banner,
  HomepageSection,
  Coupon,
  Order,
  Customer,
  ReturnRequest,
  AbandonedCart,
  AuditLog,
  NotificationItem,
  CMSPage,
  StoreSettings,
  CartItem,
  OrderSource,
} from '../src/types';
import {
  INITIAL_PRODUCTS,
  INITIAL_CATEGORIES,
  INITIAL_BANNERS,
  INITIAL_HOMEPAGE_SECTIONS,
  INITIAL_COUPONS,
  INITIAL_ORDERS,
  INITIAL_CUSTOMERS,
  INITIAL_RETURNS,
  INITIAL_ABANDONED_CARTS,
  INITIAL_AUDIT_LOGS,
  INITIAL_CMS_PAGES,
  INITIAL_SETTINGS,
} from '../src/data/mockData';

// Centralized in-memory store representing the unified database
class CentralDatabase {
  products: Product[] = [...INITIAL_PRODUCTS];
  categories: Category[] = [...INITIAL_CATEGORIES];
  banners: Banner[] = [...INITIAL_BANNERS];
  homepageSections: HomepageSection[] = [...INITIAL_HOMEPAGE_SECTIONS];
  coupons: Coupon[] = [...INITIAL_COUPONS];
  orders: Order[] = [...INITIAL_ORDERS];
  customers: Customer[] = [...INITIAL_CUSTOMERS];
  returns: ReturnRequest[] = [...INITIAL_RETURNS];
  abandonedCarts: AbandonedCart[] = [...INITIAL_ABANDONED_CARTS];
  auditLogs: AuditLog[] = [...INITIAL_AUDIT_LOGS];
  cmsPages: CMSPage[] = [...INITIAL_CMS_PAGES];
  settings: StoreSettings = { ...INITIAL_SETTINGS };
  cart: CartItem[] = [];
  wishlist: string[] = ['wi-prod-001', 'wi-prod-005'];
  notifications: NotificationItem[] = [
    {
      id: 'notif-1',
      title: 'Order Dispatched #WI-2026-8891',
      message: 'Your Artisan Linen Cuban Collar Shirt is out for delivery in Mumbai!',
      type: 'order',
      timestamp: 'Today, 07:15 AM',
      isRead: false,
      link: '/account/orders',
    },
    {
      id: 'notif-2',
      title: 'Welcome to WiseIndia!',
      message: 'Enjoy ₹200 off your first purchase with code WELCOME200 at checkout.',
      type: 'promo',
      timestamp: 'Yesterday',
      isRead: true,
    },
  ];

  logAudit(action: string, module: AuditLog['module'], details: string, userName = 'Admin') {
    const newLog: AuditLog = {
      id: `log-${Date.now()}`,
      userId: 'admin-current',
      userName,
      userRole: 'Admin',
      action,
      module,
      details,
      timestamp: new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) + ' IST',
    };
    this.auditLogs.unshift(newLog);
    if (this.auditLogs.length > 100) this.auditLogs.pop();
    return newLog;
  }

  // Cart operations
  addToCart(item: Omit<CartItem, 'id'>) {
    const existingIndex = this.cart.findIndex(
      (c) => c.productId === item.productId && c.variantId === item.variantId
    );
    if (existingIndex > -1) {
      this.cart[existingIndex].quantity += item.quantity;
      return this.cart[existingIndex];
    } else {
      const newItem: CartItem = { ...item, id: `cart-${Date.now()}` };
      this.cart.push(newItem);
      return newItem;
    }
  }

  updateCartQuantity(id: string, quantity: number) {
    if (quantity <= 0) {
      this.cart = this.cart.filter((c) => c.id !== id);
      return null;
    }
    const item = this.cart.find((c) => c.id === id);
    if (item) {
      item.quantity = quantity;
    }
    return item;
  }

  removeFromCart(id: string) {
    this.cart = this.cart.filter((c) => c.id !== id);
  }

  clearCart() {
    this.cart = [];
  }

  // Wishlist operations
  toggleWishlist(productId: string) {
    if (this.wishlist.includes(productId)) {
      this.wishlist = this.wishlist.filter((id) => id !== productId);
      return { isInWishlist: false, wishlist: this.wishlist };
    } else {
      this.wishlist.push(productId);
      return { isInWishlist: true, wishlist: this.wishlist };
    }
  }

  // Product operations
  addProduct(productData: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>) {
    const newProduct: Product = {
      ...productData,
      id: `wi-prod-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.products.unshift(newProduct);
    this.logAudit('Product Created', 'Products', `Added new product: ${newProduct.name} (${newProduct.sku})`);
    return newProduct;
  }

  updateProduct(id: string, updates: Partial<Product>) {
    const index = this.products.findIndex((p) => p.id === id);
    if (index === -1) return null;
    this.products[index] = {
      ...this.products[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.logAudit('Product Updated', 'Products', `Updated product: ${this.products[index].name}`);
    return this.products[index];
  }

  deleteProduct(id: string) {
    const p = this.products.find((prod) => prod.id === id);
    if (p) {
      this.products = this.products.filter((prod) => prod.id !== id);
      this.logAudit('Product Deleted', 'Products', `Deleted product: ${p.name}`);
      return true;
    }
    return false;
  }

  // Order operations
  createOrder(orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'updatedAt' | 'timeline'>) {
    const orderNumber = `WI-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const deliveryOtp = (orderData as any).deliveryOtp || Math.floor(1000 + Math.random() * 9000).toString();
    const newOrder: Order = {
      ...orderData,
      deliveryOtp,
      id: `ord-${Date.now()}`,
      orderNumber,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      timeline: [
        {
          status: 'Confirmed',
          timestamp: 'Just now',
          location: 'WiseIndia Processing Gateway',
          description: `Order booked via ${orderData.source}. Payment status: ${orderData.paymentStatus}`,
          isCompleted: true,
        },
        {
          status: 'Packed',
          timestamp: 'Expected within 12 hours',
          location: 'WiseIndia Central Fulfillment Center',
          description: 'Quality checks & barcoding',
          isCompleted: false,
        },
        {
          status: 'Shipped',
          timestamp: 'Expected tomorrow',
          location: 'WiseExpress Logistics Hub',
          description: 'Handover to priority courier',
          isCompleted: false,
        },
        {
          status: 'Out for delivery',
          timestamp: 'Expected in 2 days',
          location: `${orderData.shippingAddress.city} Delivery Hub`,
          description: 'Local courier dispatch',
          isCompleted: false,
        },
        {
          status: 'Delivered',
          timestamp: orderData.estimatedDelivery || 'In 2-3 Days',
          location: `${orderData.shippingAddress.pincode}, ${orderData.shippingAddress.city}`,
          description: 'Doorstep handoff',
          isCompleted: false,
        },
      ],
    };

    // Deduct stock
    orderData.items.forEach((item) => {
      const prod = this.products.find((p) => p.id === item.productId);
      if (prod) {
        prod.totalStock = Math.max(0, prod.totalStock - item.quantity);
        const variant = prod.variants.find((v) => v.id === item.variantId);
        if (variant) {
          variant.stock = Math.max(0, variant.stock - item.quantity);
        }
      }
    });

    this.orders.unshift(newOrder);
    this.cart = []; // Clear cart on order

    // Add push & transactional email simulation
    const emailNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: `Order Confirmed: ${newOrder.orderNumber}`,
      message: `Thank you for ordering with WiseIndia! Total ₹${newOrder.totalAmount.toLocaleString('en-IN')}. Tracking ID: ${newOrder.orderNumber}`,
      type: 'order',
      timestamp: 'Just now',
      isRead: false,
      link: '/account/orders',
      emailHtml: `
        <div style="font-family: sans-serif; padding: 20px; color: #1e293b; max-width: 600px; margin: auto; border: 1px solid #e2e8f0; border-radius: 12px;">
          <h2 style="color: #d9531e; margin-bottom: 4px;">WiseIndia Order Confirmation</h2>
          <p style="color: #64748b; font-size: 14px;">Order #${newOrder.orderNumber} &bull; Origin: ${newOrder.source}</p>
          <div style="background: #f8fafc; padding: 14px; border-radius: 8px; margin: 16px 0;">
            <p style="margin: 0; font-weight: 600;">Delivery Address:</p>
            <p style="margin: 4px 0 0; color: #475569;">${newOrder.shippingAddress.fullName}, ${newOrder.shippingAddress.street}, ${newOrder.shippingAddress.city}, ${newOrder.shippingAddress.state} - ${newOrder.shippingAddress.pincode}</p>
          </div>
          <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
            ${newOrder.items
              .map(
                (i) => `
              <tr style="border-bottom: 1px solid #f1f5f9;">
                <td style="padding: 10px 0;"><img src="${i.image}" width="50" style="border-radius: 6px; vertical-align: middle; margin-right: 10px;"/> <strong>${i.productName}</strong> (${i.color}, ${i.size})</td>
                <td style="text-align: right; padding: 10px 0;">₹${i.price} &times; ${i.quantity}</td>
              </tr>
            `
              )
              .join('')}
          </table>
          <div style="margin-top: 16px; border-top: 2px solid #e2e8f0; padding-top: 12px; font-size: 15px;">
            <p style="display: flex; justify-content: space-between; margin: 4px 0;"><span>Subtotal:</span> <span>₹${newOrder.subtotal}</span></p>
            ${newOrder.discount > 0 ? `<p style="display: flex; justify-content: space-between; margin: 4px 0; color: #16a34a;"><span>Discount:</span> <span>-₹${newOrder.discount}</span></p>` : ''}
            <p style="display: flex; justify-content: space-between; margin: 4px 0; font-weight: bold; font-size: 17px; color: #0f172a;"><span>Grand Total:</span> <span>₹${newOrder.totalAmount}</span></p>
          </div>
          <p style="font-size: 12px; color: #94a3b8; margin-top: 24px; text-align: center;">WiseIndia &bull; Helpline: 9000099551 &bull; wiseindia@gmail.com</p>
        </div>
      `,
    };
    this.notifications.unshift(emailNotif);

    this.logAudit(
      'Order Created',
      'Orders',
      `New Order #${newOrder.orderNumber} placed via ${newOrder.source} for ₹${newOrder.totalAmount}`
    );

    return newOrder;
  }

  updateOrderStatus(orderId: string, status: Order['status'], courierName?: string, trackingNumber?: string) {
    const order = this.orders.find((o) => o.id === orderId);
    if (!order) return null;
    order.status = status;
    order.updatedAt = new Date().toISOString();
    if (courierName) order.courierName = courierName;
    if (trackingNumber) order.trackingNumber = trackingNumber;

    // Update timeline step
    const step = order.timeline.find((t) => t.status === status);
    if (step) {
      step.isCompleted = true;
      step.timestamp = 'Updated ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    this.logAudit('Order Status Updated', 'Orders', `Order #${order.orderNumber} updated to ${status}`);
    return order;
  }
}

export const db = new CentralDatabase();
