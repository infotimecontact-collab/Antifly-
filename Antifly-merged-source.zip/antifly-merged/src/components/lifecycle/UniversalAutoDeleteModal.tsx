import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Clock,
  Trash2,
  Calendar,
  Shield,
  Eye,
  Lock,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  X,
  Layers,
  Search,
  Filter,
  Flame,
  FileText,
  MessageSquare,
  Video,
  Image as ImageIcon,
  ShoppingBag,
  Share2,
  HardDrive,
  Users,
  UserCheck,
  Globe,
  Settings2,
  RefreshCw,
  Info,
  Archive,
  ChevronRight,
  Database,
  Sliders,
  History,
  Timer,
} from 'lucide-react';
import {
  ContentLifecycleItem,
  ContentLifecycleType,
  ExpirationPreset,
  ContentAudience,
  ScheduledDeletionJob,
} from '../../types';

export const UniversalAutoDeleteModal: React.FC = () => {
  const {
    isContentLifecycleModalOpen,
    setIsContentLifecycleModalOpen,
    activeLifecycleTab,
    setActiveLifecycleTab,
    contentLifecycleItems,
    scheduledDeletionJobs,
    lifecycleStats,
    deleteContentNow,
    scheduleContentDeletion,
    updateContentExpirationTimer,
    keepContentPermanently,
    cancelScheduledDeletion,
    bulkDeleteContent,
    showToast,
  } = useApp();

  const [selectedContentType, setSelectedContentType] = useState<string>('all');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>([]);
  const [bulkExpirationPreset, setBulkExpirationPreset] = useState<ExpirationPreset>('30d');
  const [customDaysInput, setCustomDaysInput] = useState<number>(30);

  // New item scheduling modal state
  const [activeItemForTimer, setActiveItemForTimer] = useState<ContentLifecycleItem | null>(null);
  const [tempTimerPreset, setTempTimerPreset] = useState<ExpirationPreset>('24h');
  const [tempScheduleDate, setTempScheduleDate] = useState<string>('');

  if (!isContentLifecycleModalOpen) return null;

  // Filter items
  const filteredItems = contentLifecycleItems.filter((item) => {
    if (selectedContentType !== 'all' && item.contentType !== selectedContentType) return false;
    if (selectedStatusFilter !== 'all') {
      if (selectedStatusFilter === 'expiring' && item.status !== 'expiring_today' && item.status !== 'expiring_soon') return false;
      if (selectedStatusFilter === 'scheduled' && !item.isScheduledDelete) return false;
      if (selectedStatusFilter === 'permanent' && item.expiresAt !== null) return false;
      if (selectedStatusFilter === 'expired' && item.status !== 'expired') return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        item.title.toLowerCase().includes(q) ||
        item.previewText?.toLowerCase().includes(q) ||
        item.ownerName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const expiringSoonItems = contentLifecycleItems.filter(
    (item) => item.status === 'expiring_today' || item.status === 'expiring_soon' || item.isScheduledDelete
  );

  const handleSelectAll = () => {
    if (selectedItemIds.length === filteredItems.length) {
      setSelectedItemIds([]);
    } else {
      setSelectedItemIds(filteredItems.map((i) => i.id));
    }
  };

  const toggleSelectItem = (id: string) => {
    setSelectedItemIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const handleApplyBulkDelete = () => {
    if (selectedItemIds.length === 0) {
      showToast('Select at least one item first');
      return;
    }
    bulkDeleteContent(selectedItemIds);
    setSelectedItemIds([]);
  };

  const handleApplyTimerToItem = () => {
    if (!activeItemForTimer) return;
    if (tempTimerPreset === 'permanent') {
      keepContentPermanently(activeItemForTimer.id);
    } else if (tempTimerPreset === 'custom' && tempScheduleDate) {
      scheduleContentDeletion(activeItemForTimer.id, tempScheduleDate);
    } else {
      updateContentExpirationTimer(activeItemForTimer.id, tempTimerPreset);
    }
    setActiveItemForTimer(null);
  };

  const getContentTypeIcon = (type: ContentLifecycleType) => {
    switch (type) {
      case 'message':
        return <MessageSquare className="w-4 h-4 text-indigo-600" />;
      case 'media':
        return <ImageIcon className="w-4 h-4 text-emerald-600" />;
      case 'reel':
        return <Video className="w-4 h-4 text-rose-600" />;
      case 'story':
        return <Flame className="w-4 h-4 text-amber-600" />;
      case 'post':
        return <FileText className="w-4 h-4 text-blue-600" />;
      case 'product_share':
        return <ShoppingBag className="w-4 h-4 text-purple-600" />;
      case 'collection_share':
        return <Layers className="w-4 h-4 text-teal-600" />;
      default:
        return <Share2 className="w-4 h-4 text-slate-600" />;
    }
  };

  return (
    <div
      id="universal-auto-delete-modal"
      className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 lg:p-6 animate-fade-in"
    >
      <div className="bg-white dark:bg-slate-900 w-full max-w-5xl rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col my-auto max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-5 sm:p-6 relative overflow-hidden flex-shrink-0">
          <div className="flex items-start justify-between relative z-10">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center shadow-inner">
                <Timer className="w-6 h-6 text-indigo-400 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase tracking-widest bg-indigo-500/30 text-indigo-300 border border-indigo-400/30 px-2 py-0.5 rounded-full">
                    Universal Expiration & Auto-Delete
                  </span>
                  <span className="text-[10px] font-bold text-slate-400">
                    Engine v4.2 • You Control Your Data
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight mt-0.5">
                  Content Lifecycle & Disappearing Hub
                </h2>
                <p className="text-xs text-slate-300">
                  Granular control over how long your messages, media, reels, stories, and shared products live.
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsContentLifecycleModalOpen(false)}
              className="p-2 text-slate-400 hover:text-white rounded-full hover:bg-white/10 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Metrics Ribbon */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4 pt-3 border-t border-white/10 text-xs">
            <div className="bg-white/5 rounded-xl p-2 border border-white/5">
              <span className="text-[10px] text-slate-400 block">Expiring Today</span>
              <span className="font-extrabold text-amber-400 text-sm">
                {lifecycleStats.expiringTodayCount} Items
              </span>
            </div>
            <div className="bg-white/5 rounded-xl p-2 border border-white/5">
              <span className="text-[10px] text-slate-400 block">Scheduled Purges</span>
              <span className="font-extrabold text-indigo-400 text-sm">
                {lifecycleStats.scheduledDeletionsCount} Jobs
              </span>
            </div>
            <div className="bg-white/5 rounded-xl p-2 border border-white/5">
              <span className="text-[10px] text-slate-400 block">Storage Reclaimed</span>
              <span className="font-extrabold text-emerald-400 text-sm">
                {lifecycleStats.storageReclaimedGB} GB
              </span>
            </div>
            <div className="bg-white/5 rounded-xl p-2 border border-white/5">
              <span className="text-[10px] text-slate-400 block">Active Lifecycle Items</span>
              <span className="font-extrabold text-white text-sm">
                {lifecycleStats.totalActiveItems}
              </span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 px-4 flex gap-1 overflow-x-auto scrollbar-none flex-shrink-0">
          {[
            { id: 'expiring', label: 'Expiring Soon', icon: Flame, badge: lifecycleStats.expiringTodayCount },
            { id: 'manage', label: 'Content Manager', icon: Layers },
            { id: 'scheduled', label: 'Scheduled Queue', icon: Calendar, badge: scheduledDeletionJobs.length },
            { id: 'rules', label: 'Universal Presets', icon: Sliders },
            { id: 'privacy', label: 'Privacy & Visibility', icon: Lock },
            { id: 'compliance', label: 'Compliance & Safety', icon: Shield },
            { id: 'admin', label: 'Admin Telemetry', icon: HardDrive },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeLifecycleTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveLifecycleTab(tab.id as any)}
                className={`py-3 px-3.5 text-xs font-bold whitespace-nowrap flex items-center gap-2 border-b-2 transition ${
                  isActive
                    ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 bg-white dark:bg-slate-900 rounded-t-xl shadow-xs'
                    : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="bg-amber-500 text-slate-800 font-black text-[10px] px-1.5 py-0.2 rounded-full">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Tab Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* TAB 1: EXPIRING SOON DASHBOARD */}
          {activeLifecycleTab === 'expiring' && (
            <div className="space-y-6 animate-fade-in">
              <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 rounded-2xl p-4 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <Flame className="w-8 h-8 text-amber-600 flex-shrink-0 animate-bounce" />
                  <div>
                    <h3 className="font-extrabold text-amber-950 dark:text-amber-200 text-sm">
                      Expiring Soon & Active Countdowns
                    </h3>
                    <p className="text-xs text-amber-800 dark:text-amber-300">
                      These items have active timers and will automatically disappear from feed, chat, and profile views when their timer runs out.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setActiveLifecycleTab('rules')}
                  className="px-3 py-1.5 bg-amber-600 text-white rounded-xl text-xs font-bold hover:bg-amber-700 transition whitespace-nowrap shadow-xs"
                >
                  Adjust Default Timers
                </button>
              </div>

              {expiringSoonItems.length === 0 ? (
                <div className="text-center py-12 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700">
                  <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-2" />
                  <h4 className="font-bold text-slate-800 dark:text-white text-sm">No Content Expiring Imminently</h4>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                    All your current posts, stories, and chats have stable or extended retention periods.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {expiringSoonItems.map((item) => (
                    <div
                      key={item.id}
                      className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/80 shadow-xs hover:border-indigo-300 dark:hover:border-indigo-500/50 transition flex flex-col justify-between gap-3"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="p-2 bg-slate-100 dark:bg-slate-700 rounded-xl flex-shrink-0">
                            {getContentTypeIcon(item.contentType)}
                          </div>
                          <div className="min-w-0">
                            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                              {item.contentType.replace('_', ' ')}
                            </span>
                            <h4 className="font-bold text-sm text-slate-900 dark:text-white truncate">
                              {item.title}
                            </h4>
                            {item.previewText && (
                              <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
                                {item.previewText}
                              </p>
                            )}
                          </div>
                        </div>

                        <span
                          className={`text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 shrink-0 ${
                            item.status === 'expiring_today'
                              ? 'bg-rose-100 text-rose-700 border border-rose-200 animate-pulse'
                              : 'bg-amber-100 text-amber-800 border border-amber-200'
                          }`}
                        >
                          <Clock className="w-3 h-3" />
                          {item.expiresAt ? `Expires: ${new Date(item.expiresAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}` : 'Scheduled'}
                        </span>
                      </div>

                      {/* Expiration warning banner for product share */}
                      {item.isMarketplaceListingPreserved && (
                        <div className="text-[10px] text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950/30 px-2.5 py-1 rounded-lg border border-purple-200 dark:border-purple-900/40 flex items-center gap-1.5">
                          <Info className="w-3 h-3 flex-shrink-0" />
                          <span>Chat share expires, but marketplace product remains active.</span>
                        </div>
                      )}

                      {/* Action buttons */}
                      <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-700/60 text-xs">
                        <div className="flex items-center gap-1 text-[11px] text-slate-500">
                          <Eye className="w-3.5 h-3.5" />
                          <span>{item.viewCount} views</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => {
                              setActiveItemForTimer(item);
                              setTempTimerPreset(item.expirationPreset);
                            }}
                            className="px-2.5 py-1 bg-slate-100 dark:bg-slate-700 hover:bg-indigo-50 hover:text-indigo-600 text-slate-700 dark:text-slate-200 rounded-lg font-semibold transition"
                          >
                            Edit Timer
                          </button>
                          <button
                            onClick={() => keepContentPermanently(item.id)}
                            className="px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 rounded-lg font-semibold transition"
                          >
                            Keep Permanent
                          </button>
                          <button
                            onClick={() => deleteContentNow(item.id)}
                            className="p-1 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/30 transition"
                            title="Delete Now"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: CONTENT MANAGEMENT CENTER */}
          {activeLifecycleTab === 'manage' && (
            <div className="space-y-4 animate-fade-in">
              {/* Filter and Search Bar */}
              <div className="flex flex-col sm:flex-row gap-2.5 items-stretch sm:items-center justify-between">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search posts, reels, stories, messages, shared items..."
                    className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
                  <select
                    value={selectedContentType}
                    onChange={(e) => setSelectedContentType(e.target.value)}
                    className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 focus:outline-none"
                  >
                    <option value="all">All Types</option>
                    <option value="message">Messages</option>
                    <option value="post">Posts</option>
                    <option value="reel">Reels & Videos</option>
                    <option value="story">Stories</option>
                    <option value="product_share">Product Shares</option>
                    <option value="media">Photos & Snaps</option>
                    <option value="comment">Comments</option>
                  </select>

                  <select
                    value={selectedStatusFilter}
                    onChange={(e) => setSelectedStatusFilter(e.target.value)}
                    className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 focus:outline-none"
                  >
                    <option value="all">All Statuses</option>
                    <option value="expiring">Expiring Soon</option>
                    <option value="scheduled">Scheduled Delete</option>
                    <option value="permanent">Permanent Only</option>
                    <option value="expired">Expired / Inactive</option>
                  </select>
                </div>
              </div>

              {/* Bulk Actions Ribbon */}
              <div className="p-3 bg-slate-100 dark:bg-slate-800/60 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={selectedItemIds.length > 0 && selectedItemIds.length === filteredItems.length}
                    onChange={handleSelectAll}
                    className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                  />
                  <span className="font-bold text-slate-700 dark:text-slate-300">
                    {selectedItemIds.length} of {filteredItems.length} selected
                  </span>
                </div>

                {selectedItemIds.length > 0 && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleApplyBulkDelete}
                      className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold flex items-center gap-1.5 transition shadow-xs"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete Selected</span>
                    </button>
                    <button
                      onClick={() => {
                        selectedItemIds.forEach((id) => keepContentPermanently(id));
                        setSelectedItemIds([]);
                      }}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold flex items-center gap-1.5 transition shadow-xs"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Keep All Permanent</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Items Table / Grid */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden bg-white dark:bg-slate-800/40">
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredItems.map((item) => {
                    const isSelected = selectedItemIds.includes(item.id);
                    return (
                      <div
                        key={item.id}
                        className={`p-3.5 flex items-center justify-between gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/80 transition ${
                          isSelected ? 'bg-indigo-50/60 dark:bg-indigo-950/30' : ''
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => toggleSelectItem(item.id)}
                            className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                          />
                          <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-700 flex-shrink-0">
                            {getContentTypeIcon(item.contentType)}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white truncate">
                                {item.title}
                              </h4>
                              {item.isViewOnce && (
                                <span className="bg-amber-100 text-amber-800 text-[10px] font-extrabold px-1.5 py-0.2 rounded-full">
                                  View Once
                                </span>
                              )}
                              {item.expiresAt === null && (
                                <span className="bg-slate-100 text-slate-600 text-[10px] font-bold px-1.5 py-0.2 rounded-full">
                                  Permanent
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                              <span>Created {item.publishedAt}</span>
                              <span>&bull;</span>
                              <span className="capitalize">{item.privacy.audience.replace('_', ' ')}</span>
                              <span>&bull;</span>
                              <span>{item.viewCount} views</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <span className="text-[11px] font-mono font-bold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-700 px-2.5 py-1 rounded-lg">
                            {item.expiresAt
                              ? `⏱ ${new Date(item.expiresAt).toLocaleDateString()} ${new Date(item.expiresAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
                              : '♾️ No Expiry'}
                          </span>

                          <button
                            onClick={() => {
                              setActiveItemForTimer(item);
                              setTempTimerPreset(item.expirationPreset);
                            }}
                            className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition"
                            title="Edit Lifetime Timer"
                          >
                            <Clock className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => deleteContentNow(item.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                            title="Delete Now"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: SCHEDULED QUEUE */}
          {activeLifecycleTab === 'scheduled' && (
            <div className="space-y-4 animate-fade-in">
              <div className="bg-indigo-50 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-900/40 rounded-2xl p-4">
                <h3 className="font-extrabold text-indigo-950 dark:text-indigo-200 text-sm">
                  Scheduled Future Deletion Queue
                </h3>
                <p className="text-xs text-indigo-800 dark:text-indigo-300">
                  Targeted automated destruction jobs scheduled for specific future dates. You can cancel any job before its deadline.
                </p>
              </div>

              <div className="space-y-2.5">
                {scheduledDeletionJobs.map((job) => (
                  <div
                    key={job.id}
                    className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center text-indigo-600 dark:text-indigo-400 font-black">
                        {job.countdownDays}d
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                          {job.title}
                        </h4>
                        <p className="text-xs text-slate-500">
                          Deletes automatically on <span className="font-bold text-slate-800 dark:text-slate-200">{job.scheduledFor}</span> ({job.countdownDays} days remaining)
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => cancelScheduledDeletion(job.id)}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-white rounded-xl text-xs font-bold transition"
                      >
                        Cancel Deletion
                      </button>
                      <button
                        onClick={() => deleteContentNow(job.itemId)}
                        className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition shadow-xs"
                      >
                        Delete Immediately
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: UNIVERSAL PRESETS & AUTO-DELETE RULES */}
          {activeLifecycleTab === 'rules' && (
            <div className="space-y-6 animate-fade-in">
              <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-2xl border border-slate-200 dark:border-slate-700">
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white mb-1">
                  Default Platform Auto-Expiration Rules
                </h3>
                <p className="text-xs text-slate-500">
                  Configure default lifetimes applied whenever you create stories, posts, send snaps, or share products.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  {
                    title: '1-to-1 & Group Chats',
                    desc: 'Default disappearing timer for direct user and store messages',
                    defaultVal: '30 Days',
                    options: ['Off', 'After Viewing', '10 Minutes', '1 Hour', '24 Hours', '7 Days', '30 Days'],
                    icon: MessageSquare,
                  },
                  {
                    title: 'Stories & Status Updates',
                    desc: 'Standard duration for 24h photo & video updates',
                    defaultVal: '24 Hours',
                    options: ['View Once', '6 Hours', '12 Hours', '24 Hours', '3 Days', 'Custom'],
                    icon: Flame,
                  },
                  {
                    title: 'Seller & Community Posts',
                    desc: 'Feed post lifetime before automatic removal',
                    defaultVal: 'Permanent',
                    options: ['24 Hours', '3 Days', '7 Days', '30 Days', 'Permanent', 'Custom Date'],
                    icon: FileText,
                  },
                  {
                    title: 'Shared Product Links in Chat',
                    desc: 'Removes the chat message bubble while keeping marketplace item safe',
                    defaultVal: '7 Days',
                    options: ['24 Hours', '3 Days', '7 Days', '30 Days', 'Custom'],
                    icon: ShoppingBag,
                  },
                  {
                    title: 'Private Media & Snaps',
                    desc: 'Photos & short videos sent in direct messages',
                    defaultVal: 'View Once',
                    options: ['View Once', '10 Seconds', '1 Hour', '24 Hours', 'Keep in Chat'],
                    icon: ImageIcon,
                  },
                  {
                    title: 'Creator Short Video Reels',
                    desc: 'Creator promotional reels and showcase videos',
                    defaultVal: 'Permanent',
                    options: ['24 Hours', '7 Days', '30 Days', 'Permanent'],
                    icon: Video,
                  },
                ].map((rule, idx) => {
                  const Icon = rule.icon;
                  return (
                    <div
                      key={idx}
                      className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/80 space-y-3"
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-indigo-50 dark:bg-indigo-950/50 rounded-xl text-indigo-600 dark:text-indigo-400">
                          <Icon className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                            {rule.title}
                          </h4>
                          <p className="text-xs text-slate-500">{rule.desc}</p>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {rule.options.map((opt) => (
                          <button
                            key={opt}
                            onClick={() => showToast(`Set ${rule.title} default to ${opt}`)}
                            className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition ${
                              opt === rule.defaultVal
                                ? 'bg-indigo-600 text-white font-bold'
                                : 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                            }`}
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 5: PRIVACY & VISIBILITY CONTROLS */}
          {activeLifecycleTab === 'privacy' && (
            <div className="space-y-4 animate-fade-in">
              <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-2xl border border-slate-200 dark:border-slate-700">
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white mb-1">
                  Default Content Privacy Presets
                </h3>
                <p className="text-xs text-slate-500">
                  Choose who can view, reply, download, and share your published content across the ecosystem.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { label: 'Everyone', desc: 'Public on feed, discovery, and search', icon: Globe },
                  { label: 'Followers Only', desc: 'Visible only to verified followers', icon: Users },
                  { label: 'Close Friends', desc: 'Restricted to your custom VIP inner circle', icon: UserCheck },
                ].map((aud, i) => {
                  const Icon = aud.icon;
                  return (
                    <button
                      key={i}
                      onClick={() => showToast(`Updated default audience to ${aud.label}`)}
                      className="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-indigo-400 text-left transition flex flex-col justify-between gap-3 group"
                    >
                      <div className="p-2.5 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 rounded-xl w-fit group-hover:scale-110 transition">
                        <Icon className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white">{aud.label}</h4>
                        <p className="text-xs text-slate-500 mt-0.5">{aud.desc}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 6: SAFETY, COMPLIANCE & LEGAL DATA RETENTION */}
          {activeLifecycleTab === 'compliance' && (
            <div className="space-y-4 animate-fade-in">
              <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/40 rounded-2xl p-5 space-y-3">
                <div className="flex items-center gap-3">
                  <Shield className="w-8 h-8 text-blue-600 flex-shrink-0" />
                  <div>
                    <h3 className="font-black text-blue-950 dark:text-blue-200 text-sm">
                      Transparent Data Retention & Safety Architecture
                    </h3>
                    <p className="text-xs text-blue-800 dark:text-blue-300">
                      How deletion works behind the scenes to protect your privacy while complying with consumer regulations.
                    </p>
                  </div>
                </div>

                <div className="space-y-2 text-xs text-slate-700 dark:text-slate-300 pt-2 border-t border-blue-200 dark:border-blue-900/40">
                  <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-blue-100 dark:border-blue-900/20 flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold block text-slate-900 dark:text-white">User App Removal</span>
                      When an item expires or is deleted, it is instantly removed from feeds, search index, discovery recommendations, receiver chats, and media galleries.
                    </div>
                  </div>

                  <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-blue-100 dark:border-blue-900/20 flex items-start gap-2.5">
                    <Lock className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold block text-slate-900 dark:text-white">Statutory & Tax Compliance</span>
                      GST tax invoices, financial UPI transaction records, and legally mandated order audit trails remain safely encrypted in compliance vaults for 7 years as required by Indian e-commerce law.
                    </div>
                  </div>

                  <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-blue-100 dark:border-blue-900/20 flex items-start gap-2.5">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold block text-slate-900 dark:text-white">Fraud Prevention & Security Locks</span>
                      Content flagged in active safety investigations or fraud audits is retained in secure quarantine to protect victims and facilitate law enforcement inquiries.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: ADMIN LIFECYCLE TELEMETRY */}
          {activeLifecycleTab === 'admin' && (
            <div className="space-y-4 animate-fade-in">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
                  <span className="text-[10px] font-bold text-slate-500 block uppercase">Messages Purged Today</span>
                  <span className="text-xl font-black text-indigo-600 dark:text-indigo-400">
                    {lifecycleStats.messagesExpiredToday.toLocaleString()}
                  </span>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
                  <span className="text-[10px] font-bold text-slate-500 block uppercase">Posts Expired Today</span>
                  <span className="text-xl font-black text-blue-600 dark:text-blue-400">
                    {lifecycleStats.postsExpiredToday}
                  </span>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
                  <span className="text-[10px] font-bold text-slate-500 block uppercase">Stories Purged (24h)</span>
                  <span className="text-xl font-black text-amber-600 dark:text-amber-400">
                    {lifecycleStats.storiesExpiredToday}
                  </span>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
                  <span className="text-[10px] font-bold text-slate-500 block uppercase">Legal Preservation Locks</span>
                  <span className="text-xl font-black text-rose-600">
                    {lifecycleStats.legalPreservationLocksCount}
                  </span>
                </div>
              </div>

              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <HardDrive className="w-6 h-6 text-emerald-600" />
                  <div>
                    <h4 className="font-bold text-sm text-emerald-950 dark:text-emerald-200">
                      Automated Garbage Collector Status: Healthy
                    </h4>
                    <p className="text-xs text-emerald-800 dark:text-emerald-300">
                      Cron job running every 60s &bull; {lifecycleStats.failedDeletionJobs} failed jobs in queue
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => showToast('🚀 Garbage Collector triggered. Purged 14 expired cache objects.')}
                  className="px-3 py-1.5 bg-emerald-600 text-white font-bold text-xs rounded-xl hover:bg-emerald-700 transition"
                >
                  Run GC Now
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-100 dark:bg-slate-800/80 p-4 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between flex-shrink-0 text-xs">
          <span className="text-slate-500 flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-emerald-600" />
            <span>End-to-End Expiration Engine Active</span>
          </span>
          <button
            onClick={() => setIsContentLifecycleModalOpen(false)}
            className="px-5 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold rounded-xl hover:bg-slate-800 transition"
          >
            Done
          </button>
        </div>
      </div>

      {/* Item Timer Adjustment Sub-Modal */}
      {activeItemForTimer && (
        <div className="fixed inset-0 z-60 bg-white/70 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-sm text-slate-900 dark:text-white">
                Set Lifetime: {activeItemForTimer.title}
              </h3>
              <button
                onClick={() => setActiveItemForTimer(null)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-500">
              Choose how long this item remains visible before automatically deleting from the application.
            </p>

            <div className="grid grid-cols-2 gap-2">
              {[
                { label: 'View Once', preset: 'view_once' },
                { label: '10 Minutes', preset: '10m' },
                { label: '1 Hour', preset: '1h' },
                { label: '24 Hours', preset: '24h' },
                { label: '3 Days', preset: '3d' },
                { label: '7 Days', preset: '7d' },
                { label: '30 Days', preset: '30d' },
                { label: 'Permanent', preset: 'permanent' },
              ].map((p) => (
                <button
                  key={p.preset}
                  onClick={() => setTempTimerPreset(p.preset as ExpirationPreset)}
                  className={`p-2.5 rounded-xl text-xs font-bold text-left transition ${
                    tempTimerPreset === p.preset
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                onClick={() => setActiveItemForTimer(null)}
                className="px-3.5 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleApplyTimerToItem}
                className="px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl hover:bg-indigo-700 transition"
              >
                Apply Lifetime
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
