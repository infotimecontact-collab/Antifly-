import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { RealisticDynamicClock } from '../common/RealisticDynamicClock';
import {
  Search,
  Mic,
  Camera,
  ShoppingBag,
  Heart,
  User,
  Sparkles,
  ChevronDown,
  Menu,
  X,
  Bell,
  Scale,
  Truck,
  ShieldCheck,
  Smartphone,
  Layers,
  ArrowRight,
  Coins,
  Store,
  Users,
  UtensilsCrossed,
  Crown,
  CreditCard,
  Tv,
  MessageSquare,
  Tag,
  Bookmark,
  FolderHeart,
  ArrowRightLeft,
  CheckCircle2,
  Bot,
  Headphones,
  Phone,
  RotateCcw,
  Star,
  Globe,
  Timer,
  Gem,
  Radio,
  Glasses,
  AudioLines,
  Flame,
  Compass,
  Rocket,
  Zap,
} from 'lucide-react';

interface WebsiteHeaderProps {
  currentView: 'home' | 'catalog' | 'account';
  setCurrentView: (view: 'home' | 'catalog' | 'account') => void;
}

export const WebsiteHeader: React.FC<WebsiteHeaderProps> = ({ currentView, setCurrentView }) => {
  const {
    categories,
    cart,
    wishlist,
    comparisonList,
    setIsCartOpen,
    setIsWiseAIOpen,
    setIsVoiceSearchOpen,
    setIsImageSearchOpen,
    setIsNotificationDrawerOpen,
    setIsComparisonOpen,
    searchQuery,
    setSearchQuery,
    selectedCategorySlug,
    setSelectedCategorySlug,
    notifications,
    setDeviceMode,
    superCoinsBalance,
    setIsSuperCoinsModalOpen,
    setIsResellerModalOpen,
    setIsStyleCastModalOpen,
    setIsGroupBuyModalOpen,
    resellerConfig,
    setIsFoodDeliveryModalOpen,
    setIsWiseOneModalOpen,
    setIsBankOffersModalOpen,
    setIsOTTModalOpen,
    wiseOneSubscription,
    openStoreCommunity,
    storeChatSessions,
    setIsStoreChatOpen,
    setIsRoleSwitcherOpen,
    setIsConnectMembershipModalOpen,
    setIsVerifiedBadgeModalOpen,
    setIsSupportChatbotOpen,
    userPersonaProfile,
    customerConnectState,
    websiteMainTab,
    setWebsiteMainTab,
    settings,
    selectedLanguage,
    setSelectedLanguage,
    setIsFavoritesHubOpen,
    savedItems,
    setIsContentLifecycleModalOpen,
    setIsRewardsEconomyModalOpen,
    superCoinWallet,
    diamondWallet,
    setIsLiveShoppingOpen,
    setIsMultilingualStudioOpen,
    openVirtualTryOn,
    openNavaSocialHub,
    setIsAutonomousZeroAdminOpen,
    setIsJustAwayHubOpen,
    awayModeActive,
  } = useApp();

  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);

  const unreadCount = notifications.filter((n) => !n.isRead).length;
  const totalChatUnread = storeChatSessions.reduce((acc, s) => acc + (s.unreadCount || 0), 0);
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const indianLanguages = [
    { code: 'hi', label: 'हिंदी (Hindi)' },
    { code: 'en', label: 'English' },
    { code: 'bn', label: 'বাংলা (Bengali)' },
    { code: 'te', label: 'తెలుగు (Telugu)' },
    { code: 'mr', label: 'मराठी (Marathi)' },
    { code: 'ta', label: 'தமிழ் (Tamil)' },
    { code: 'ur', label: 'اردو (Urdu)' },
    { code: 'gu', label: 'ગુજરાતી (Gujarati)' },
    { code: 'kn', label: 'ಕನ್ನಡ (Kannada)' },
    { code: 'ml', label: 'മലയാളം (Malayalam)' },
    { code: 'pa', label: 'ਪੰਜਾਬੀ (Punjabi)' },
    { code: 'or', label: 'ଓଡ଼ିଆ (Odia)' },
  ];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setWebsiteMainTab('search');
      setCurrentView('home');
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 transition-colors shadow-2xs">
      {/* Top Value Proposition Strip: 24/7 Dynamic Helpline & Policies */}
      <div className="bg-slate-50 text-slate-800 text-[11px] py-1.5 px-4 hidden sm:block border-b border-slate-200 font-medium">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* 24/7 Support Helpline Display */}
            <div className="flex items-center gap-1.5 text-slate-800">
              <Headphones className="w-3.5 h-3.5 text-red-600" />
              <span>24/7 Customer Helpline:</span>
              <strong className="text-red-700">{settings.contactPhone || '+91 98765 43210'}</strong>
            </div>

            <span className="text-slate-300">|</span>

            {/* 7-Day Exchange Guarantee */}
            <div className="flex items-center gap-1 text-emerald-800 font-bold">
              <RotateCcw className="w-3 h-3 text-emerald-600" />
              <span>Mandatory 7-Day Return / Exchange Guarantee</span>
            </div>

            <span className="text-slate-300">|</span>

            {/* OTT Platform Button */}
            <button
              onClick={() => setIsOTTModalOpen(true)}
              className="flex items-center gap-1 text-indigo-700 hover:text-indigo-900 font-bold cursor-pointer"
            >
              <Tv className="w-3 h-3" />
              <span>WiseStream OTT</span>
            </button>
          </div>

          <div className="flex items-center gap-3">
            {/* Language Selector Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
                className="flex items-center gap-1 text-slate-700 hover:text-red-600 font-bold cursor-pointer"
              >
                <Globe className="w-3.5 h-3.5 text-red-600" />
                <span>Language</span>
                <ChevronDown className="w-3 h-3" />
              </button>

              {isLangDropdownOpen && (
                <div className="absolute right-0 mt-1 w-44 bg-white border border-slate-200 rounded-2xl shadow-lg p-2 z-50 max-h-60 overflow-y-auto">
                  {indianLanguages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setSelectedLanguage(lang.code as any);
                        setIsLangDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-1.5 text-xs font-semibold hover:bg-red-50 hover:text-red-600 rounded-xl transition"
                    >
                      {lang.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <span className="text-slate-300">|</span>

            {/* 24/7 Live Chat Support Button */}
            <button
              onClick={() => setIsSupportChatbotOpen(true)}
              className="flex items-center gap-1 bg-red-600 hover:bg-red-700 text-white px-2.5 py-0.5 rounded-full font-bold shadow-2xs transition cursor-pointer"
            >
              <MessageSquare className="w-3 h-3" />
              <span>24/7 Live Chat</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Header Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3">
        <div className="flex items-center justify-between gap-4">
          {/* Attractive Antifly Brand Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMobileNavOpen(!isMobileNavOpen)}
              className="p-1.5 text-slate-700 lg:hidden rounded-xl hover:bg-slate-100 transition cursor-pointer"
            >
              {isMobileNavOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <div
              onClick={() => {
                setWebsiteMainTab('nearby');
                setCurrentView('home');
                setSelectedCategorySlug('all');
                setSearchQuery('');
              }}
              className="cursor-pointer flex items-center gap-2 group select-none"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-600 flex items-center justify-center text-white font-black text-lg shadow-md shadow-orange-500/20 group-hover:scale-105 transition-transform">
                W
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-1.5">
                  <span className="text-base sm:text-lg font-black tracking-tight bg-gradient-to-r from-stone-900 via-stone-800 to-orange-950 bg-clip-text text-transparent">
                    Antifly
                  </span>
                  <span className="text-[9px] font-black px-1.5 py-0.2 rounded-md bg-rose-100 text-rose-700 uppercase tracking-wide">
                    DIRECT
                  </span>
                </div>
                <span className="text-[10px] font-bold text-stone-500 tracking-tight -mt-0.5">
                  Zero Commission • Hyperlocal
                </span>
              </div>
            </div>
          </div>

          {/* Large Universal Vice-Versa Search Bar */}
          <div className="flex-1 max-w-xl hidden md:block">
            <form onSubmit={handleSearchSubmit} className="relative flex items-center">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products, stores, Hotstar OTT, food, sarees..."
                className="w-full pl-10 pr-20 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition-all shadow-inner"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5" />

              <div className="absolute right-1.5 flex items-center gap-1">
                <button
                  type="button"
                  title="Voice Search"
                  onClick={() => setIsVoiceSearchOpen(true)}
                  className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition cursor-pointer"
                >
                  <Mic className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  title="Visual Photo Search"
                  onClick={() => setIsImageSearchOpen(true)}
                  className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition cursor-pointer"
                >
                  <Camera className="w-4 h-4" />
                </button>
              </div>
            </form>
          </div>

          {/* Right Action Icons */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Real-time Dynamic Clock */}
            <div className="hidden md:block">
              <RealisticDynamicClock
                size="sm"
                variant="luxury"
                showDigitalTime={true}
                showSeconds={true}
              />
            </div>

            {/* JustAway — "Just go. Just away." Spontaneous Travel & Nomad Engine */}
            <button
              type="button"
              id="btn-header-justaway-travel"
              onClick={() => setIsJustAwayHubOpen(true)}
              title="JustAway: 'Just go. Just away.' — Spontaneous 1-Tap Escapes & Try-Before-You-Fly WanderKits"
              className="relative p-2 rounded-xl text-slate-700 hover:text-amber-600 hover:bg-amber-50 transition cursor-pointer"
            >
              <Compass className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 bg-gradient-to-r from-amber-400 to-orange-500 text-slate-800 text-[8px] font-black px-1 py-0.2 rounded-full">
                {awayModeActive ? 'AWAY' : 'GO'}
              </span>
            </button>

            {/* NAVA Next-Gen Social Network Trigger */}
            <button
              type="button"
              id="btn-header-nava-social"
              onClick={() => openNavaSocialHub()}
              title="NAVA Next-Gen Social Network (17 Features: Missions, Circles, Help Exchange)"
              className="relative p-2 rounded-xl text-slate-700 hover:text-indigo-600 hover:bg-indigo-50 transition cursor-pointer"
            >
              <Rocket className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 bg-amber-400 text-slate-800 text-[8px] font-black px-1.5 py-0.2 rounded-full">
                17
              </span>
            </button>

            {/* Ask WiseAI Trigger */}
            <button
              type="button"
              onClick={() => setIsWiseAIOpen(true)}
              title="Ask WiseAI Copilot"
              className="relative p-2 rounded-xl text-slate-700 hover:text-fuchsia-600 hover:bg-fuchsia-50 transition cursor-pointer"
            >
              <Sparkles className="w-5 h-5 text-fuchsia-600" />
              <span className="absolute -top-1 -right-1 bg-fuchsia-500 text-white text-[8px] font-black px-1 py-0.2 rounded-full">
                AI
              </span>
            </button>

            {/* Zero-Admin Autonomous Hub Trigger */}
            <button
              type="button"
              id="btn-header-zero-admin-hub"
              onClick={() => setIsAutonomousZeroAdminOpen(true)}
              title="Zero-Admin Autonomous Operations & AI Arbitrator"
              className="relative p-2 rounded-xl text-slate-700 hover:text-emerald-600 hover:bg-emerald-50 transition cursor-pointer"
            >
              <Zap className="w-5 h-5 text-emerald-600" />
              <span className="absolute -top-1 -right-1 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-800 text-[7px] font-black px-1 py-0.2 rounded-full">
                0-ADMIN
              </span>
            </button>

            {/* Free Trial & Virtual Try-On Trigger */}
            <button
              type="button"
              id="btn-header-free-trial-tryon"
              onClick={() => openVirtualTryOn()}
              title="Free Product Trial & AI Fitting Room"
              className="relative p-2 rounded-xl text-slate-700 hover:text-teal-600 hover:bg-teal-50 transition cursor-pointer"
            >
              <Glasses className="w-5 h-5 text-teal-600" />
              <span className="absolute -top-1 -right-1 bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-800 text-[8px] font-black px-1 py-0.2 rounded-full">
                FREE
              </span>
            </button>

            {/* Direct 1-to-1 Messages Trigger */}
            <button
              type="button"
              id="btn-header-direct-messages"
              onClick={() => setIsStoreChatOpen(true)}
              title="1-to-1 Messages & Live Bargaining"
              className="relative p-2 rounded-xl text-slate-700 hover:text-indigo-600 hover:bg-indigo-50 transition cursor-pointer"
            >
              <MessageSquare className="w-5 h-5" />
              {totalChatUnread > 0 && (
                <span className="absolute -top-1 -right-1 bg-indigo-600 text-white text-[8px] font-black px-1.5 py-0.2 rounded-full">
                  {totalChatUnread}
                </span>
              )}
            </button>

            {/* Super Coins & Diamond Rewards Pill */}
            <button
              type="button"
              id="btn-header-supercoins-rewards"
              onClick={() => setIsRewardsEconomyModalOpen(true)}
              title="Super Coins & Diamond Rewards Economy"
              className="flex items-center gap-1.5 bg-amber-50 hover:bg-amber-100/80 text-amber-900 border border-amber-300/60 px-2.5 py-1.5 rounded-xl text-xs font-black transition cursor-pointer shadow-xs"
            >
              <Coins className="w-3.5 h-3.5 text-amber-600" />
              <span className="text-xs font-black">{superCoinWallet.availableBalance.toLocaleString()}</span>
              <span className="text-amber-400">|</span>
              <Gem className="w-3.5 h-3.5 text-cyan-600" />
              <span className="text-xs font-black">{diamondWallet.availableDiamonds}</span>
            </button>

            {/* Universal Auto-Delete & Expiration Lifecycle Engine */}
            <button
              type="button"
              id="btn-header-auto-delete-lifecycle"
              onClick={() => setIsContentLifecycleModalOpen(true)}
              title="Universal Content Lifecycle & Auto-Delete Hub"
              className="relative p-2 rounded-xl text-slate-700 hover:text-emerald-600 hover:bg-emerald-50 transition cursor-pointer"
            >
              <Timer className="w-5 h-5 text-emerald-600" />
              <span className="absolute -top-1 -right-1 bg-emerald-600 text-white text-[8px] font-black px-1 py-0.2 rounded-full">
                24h
              </span>
            </button>

            {/* Notifications Bell */}
            <button
              type="button"
              onClick={() => setIsNotificationDrawerOpen(true)}
              title="Notifications"
              className="relative p-2 rounded-xl text-slate-700 hover:text-red-600 hover:bg-red-50 transition cursor-pointer"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[8px] font-black min-w-[15px] h-[15px] flex items-center justify-center rounded-full px-0.5">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Universal Saved Vault & Collections */}
            <button
              type="button"
              id="btn-header-saved-vault"
              onClick={() => setIsFavoritesHubOpen(true)}
              title="Saved Vault & Collections"
              className="relative p-2 rounded-xl text-slate-700 hover:text-amber-600 hover:bg-amber-50 transition cursor-pointer"
            >
              <Bookmark className="w-5 h-5" />
              {savedItems.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-amber-400 text-slate-800 text-[8px] font-black min-w-[15px] h-[15px] flex items-center justify-center rounded-full px-0.5">
                  {savedItems.length}
                </span>
              )}
            </button>

            {/* Wishlist */}
            <button
              type="button"
              onClick={() => {
                setWebsiteMainTab('profile');
                setCurrentView('home');
              }}
              title="Saved Wishlist"
              className="relative p-2 rounded-xl text-slate-700 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer hidden sm:block"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[8px] font-black min-w-[15px] h-[15px] flex items-center justify-center rounded-full px-0.5">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Account Profile */}
            <button
              type="button"
              onClick={() => {
                setWebsiteMainTab('profile');
                setCurrentView('home');
              }}
              title="My Profile & Settings"
              className={`p-2 rounded-xl transition cursor-pointer ${
                websiteMainTab === 'profile'
                  ? 'bg-red-50 text-red-600'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <User className="w-5 h-5" />
            </button>

            {/* Shopping Bag trigger */}
            <button
              type="button"
              id="header-cart-button"
              onClick={() => setIsCartOpen(true)}
              title="View Shopping Bag"
              className="relative p-2 rounded-xl bg-red-50 text-red-600 hover:bg-red-100 transition cursor-pointer"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-600 text-white text-[9px] font-black min-w-[16px] h-[16px] flex items-center justify-center rounded-full px-1">
                  {cartItemCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Mobile Search Bar */}
        <div className="mt-2.5 md:hidden">
          <form onSubmit={handleSearchSubmit} className="relative flex items-center">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products, stores, OTT..."
              className="w-full pl-9 pr-16 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-medium"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3" />
            <div className="absolute right-1.5 flex items-center gap-1">
              <button
                type="button"
                onClick={() => setIsVoiceSearchOpen(true)}
                className="p-1 text-slate-400 hover:text-red-600"
              >
                <Mic className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setIsImageSearchOpen(true)}
                className="p-1 text-slate-400 hover:text-red-600"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* 5-Tab Navigation Bar */}
      <nav className="border-t border-slate-100 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between text-xs font-bold overflow-x-auto scrollbar-none">
          <div className="flex items-center gap-1.5 sm:gap-2 py-1.5">
            {/* Tab 1: Nearby Ventures (Home Page) */}
            <button
              onClick={() => {
                setWebsiteMainTab('nearby');
                setCurrentView('home');
              }}
              className={`py-2 px-3.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                websiteMainTab === 'nearby' && currentView === 'home'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-700 hover:bg-slate-100'
              }`}
            >
              <span>📍 Nearby Ventures</span>
            </button>

            {/* Tab 2: Venture Profiles (30 Profiles / Page) */}
            <button
              onClick={() => {
                setWebsiteMainTab('sellers');
                setCurrentView('home');
              }}
              className={`py-2 px-3.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                websiteMainTab === 'sellers' && currentView === 'home'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-700 hover:bg-slate-100'
              }`}
            >
              <span>🏪 Venture Profiles (30/Pg)</span>
            </button>

            {/* Tab 3: Dedicated Search Tab */}
            <button
              onClick={() => {
                setWebsiteMainTab('search');
                setCurrentView('home');
              }}
              className={`py-2 px-3.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                websiteMainTab === 'search' && currentView === 'home'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-700 hover:bg-slate-100'
              }`}
            >
              <Search className="w-3.5 h-3.5" />
              <span>Search</span>
            </button>

            {/* Tab 4: 24h Status & Stories (WhatsApp Sync) */}
            <button
              onClick={() => {
                setWebsiteMainTab('status');
                setCurrentView('home');
              }}
              className={`py-2 px-3.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                websiteMainTab === 'status' && currentView === 'home'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-700 hover:bg-slate-100'
              }`}
            >
              <Camera className="w-3.5 h-3.5" />
              <span>📱 24h Status & Stories</span>
            </button>

            {/* Tab 5: Social Community & Follow Requests */}
            <button
              onClick={() => {
                setWebsiteMainTab('social');
                setCurrentView('home');
              }}
              className={`py-2 px-3.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                websiteMainTab === 'social' && currentView === 'home'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-700 hover:bg-slate-100'
              }`}
            >
              <span>💬 Community & Follow</span>
            </button>

            {/* Tab 6: Profile, 2-Tab Wishlist & 24/7 Support */}
            <button
              onClick={() => {
                setWebsiteMainTab('profile');
                setCurrentView('home');
              }}
              className={`py-2 px-3.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                websiteMainTab === 'profile' && currentView === 'home'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-700 hover:bg-slate-100'
              }`}
            >
              <span>👤 Profile & Wishlist</span>
            </button>
          </div>

          <div className="hidden lg:flex items-center gap-2 text-slate-500 text-[11px] pl-4">
            {/* Live Shopping Studio Launch */}
            <button
              onClick={() => setIsLiveShoppingOpen(true)}
              className="bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-extrabold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5 shadow-xs transition hover:scale-105 cursor-pointer animate-pulse"
              title="Interactive Live Stream Shopping Shows"
            >
              <Radio className="w-3.5 h-3.5" />
              <span>LIVE Shows</span>
              <span className="w-2 h-2 rounded-full bg-white animate-ping" />
            </button>

            {/* 12-Language Vernacular Voice Studio */}
            <button
              onClick={() => setIsMultilingualStudioOpen(true)}
              className="bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white font-extrabold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5 shadow-xs transition hover:scale-105 cursor-pointer"
              title="Vernacular Voice Assistant (12 Indian Languages)"
            >
              <AudioLines className="w-3.5 h-3.5" />
              <span>Voice Studio</span>
            </button>

            {/* 3D AR Studio */}
            <button
              onClick={() => openVirtualTryOn()}
              className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5 shadow-xs transition hover:scale-105 cursor-pointer"
              title="3D Virtual & Augmented Reality Try-On Studio"
            >
              <Glasses className="w-3.5 h-3.5" />
              <span>3D Try-On</span>
            </button>

            <button
              onClick={() => {
                setSelectedCategorySlug('all');
                setCurrentView('catalog');
              }}
              className="text-red-600 hover:text-red-700 font-extrabold flex items-center gap-1 cursor-pointer whitespace-nowrap pl-2 border-l border-slate-200"
            >
              <span>Catalog</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Responsive Mobile Drawer Menu */}
        {isMobileNavOpen && (
          <div className="lg:hidden border-t border-slate-200 bg-white/95 backdrop-blur-md px-4 py-3 space-y-3 animate-in slide-in-from-top-2 duration-200 shadow-xl max-h-[80vh] overflow-y-auto">
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  setWebsiteMainTab('nearby');
                  setCurrentView('home');
                  setIsMobileNavOpen(false);
                }}
                className={`p-2.5 rounded-xl text-left text-xs font-bold flex items-center gap-2 border transition ${
                  websiteMainTab === 'nearby' && currentView === 'home'
                    ? 'bg-red-50 border-red-300 text-red-700'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <span>📍 Nearby Stores</span>
              </button>
              <button
                onClick={() => {
                  setWebsiteMainTab('sellers');
                  setCurrentView('home');
                  setIsMobileNavOpen(false);
                }}
                className={`p-2.5 rounded-xl text-left text-xs font-bold flex items-center gap-2 border transition ${
                  websiteMainTab === 'sellers' && currentView === 'home'
                    ? 'bg-red-50 border-red-300 text-red-700'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <span>🏪 Sellers (30/Pg)</span>
              </button>
              <button
                onClick={() => {
                  setWebsiteMainTab('status');
                  setCurrentView('home');
                  setIsMobileNavOpen(false);
                }}
                className={`p-2.5 rounded-xl text-left text-xs font-bold flex items-center gap-2 border transition ${
                  websiteMainTab === 'status' && currentView === 'home'
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-700'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <Camera className="w-3.5 h-3.5 text-emerald-600" />
                <span>24h Stories</span>
              </button>
              <button
                onClick={() => {
                  setWebsiteMainTab('social');
                  setCurrentView('home');
                  setIsMobileNavOpen(false);
                }}
                className={`p-2.5 rounded-xl text-left text-xs font-bold flex items-center gap-2 border transition ${
                  websiteMainTab === 'social' && currentView === 'home'
                    ? 'bg-red-50 border-red-300 text-red-700'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <span>💬 Community</span>
              </button>
              <button
                onClick={() => {
                  setWebsiteMainTab('profile');
                  setCurrentView('home');
                  setIsMobileNavOpen(false);
                }}
                className={`p-2.5 rounded-xl text-left text-xs font-bold flex items-center gap-2 border transition ${
                  websiteMainTab === 'profile' && currentView === 'home'
                    ? 'bg-red-50 border-red-300 text-red-700'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <span>👤 My Profile</span>
              </button>
              <button
                onClick={() => {
                  setSelectedCategorySlug('all');
                  setCurrentView('catalog');
                  setIsMobileNavOpen(false);
                }}
                className="p-2.5 rounded-xl text-left text-xs font-bold flex items-center gap-2 border bg-amber-50 border-amber-300 text-amber-900"
              >
                <span>📦 Full Catalog</span>
              </button>
            </div>

            {/* Quick Feature Launchers */}
            <div className="pt-2 border-t border-slate-100 space-y-1.5">
              <div className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 px-1">
                Ecosystem Services & Rewards
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  onClick={() => {
                    setIsRewardsEconomyModalOpen(true);
                    setIsMobileNavOpen(false);
                  }}
                  className="p-2 bg-amber-500/10 hover:bg-amber-500/20 text-amber-950 text-[11px] font-bold rounded-xl border border-amber-300/60 flex items-center gap-1.5"
                >
                  <Coins className="w-3.5 h-3.5 text-amber-600" />
                  <span>Coins & Diamonds</span>
                </button>
                <button
                  onClick={() => {
                    setIsContentLifecycleModalOpen(true);
                    setIsMobileNavOpen(false);
                  }}
                  className="p-2 bg-emerald-50 text-emerald-900 text-[11px] font-bold rounded-xl border border-emerald-200 flex items-center gap-1.5"
                >
                  <Timer className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Auto-Delete Hub</span>
                </button>
                <button
                  onClick={() => {
                    setIsFavoritesHubOpen(true);
                    setIsMobileNavOpen(false);
                  }}
                  className="p-2 bg-purple-50 text-purple-900 text-[11px] font-bold rounded-xl border border-purple-200 flex items-center gap-1.5"
                >
                  <Bookmark className="w-3.5 h-3.5 text-purple-600" />
                  <span>Saved Vault</span>
                </button>
                <button
                  onClick={() => {
                    setIsWiseAIOpen(true);
                    setIsMobileNavOpen(false);
                  }}
                  className="p-2 bg-red-50 text-red-900 text-[11px] font-bold rounded-xl border border-red-200 flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-red-600" />
                  <span>Ask WiseAI</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};
