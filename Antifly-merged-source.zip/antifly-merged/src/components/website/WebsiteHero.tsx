import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ChevronLeft,
  ChevronRight,
  Sparkles,
  ArrowRight,
  Tag,
  Clock,
  Flame,
  Pause,
  Play,
  Globe,
  CheckCircle2,
} from 'lucide-react';

interface WebsiteHeroProps {
  onExploreCategory: (slug: string) => void;
}

const SLIDE_DURATION_MS = 6000;

export const WebsiteHero: React.FC<WebsiteHeroProps> = ({ onExploreCategory }) => {
  const {
    banners,
    setIsWiseAIOpen,
    currentRegion,
    setIsCommunityNetworkOpen,
    setIsDestinationDetourOpen,
    setIsTimeToEarnOpen,
    setIsProductExchangeOpen,
    setIsJustAwayHubOpen,
    awayModeActive,
  } = useApp();
  const heroBanners = banners.filter((b) => (b.type === 'Hero' || b.type === 'Offer') && b.isActive);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [progress, setProgress] = useState(0);
  
  // Real-time ticking countdown per banner
  const [countdownSeconds, setCountdownSeconds] = useState<Record<string, number>>({});

  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize countdowns
  useEffect(() => {
    const initialCounts: Record<string, number> = {};
    heroBanners.forEach((b) => {
      initialCounts[b.id] = b.timingSeconds || 14400;
    });
    setCountdownSeconds(initialCounts);

    // Live 1-second interval ticker for countdowns
    const ticker = setInterval(() => {
      setCountdownSeconds((prev) => {
        const next = { ...prev };
        Object.keys(next).forEach((k) => {
          if (next[k] > 0) next[k] -= 1;
        });
        return next;
      });
    }, 1000);

    return () => clearInterval(ticker);
  }, [heroBanners.length]);

  // Real-time slide transition progress animation
  useEffect(() => {
    if (heroBanners.length <= 1) return;
    if (isPaused) {
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
      return;
    }

    const stepMs = 50;
    const increment = (stepMs / SLIDE_DURATION_MS) * 100;

    progressIntervalRef.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          setCurrentIndex((curr) => (curr + 1) % heroBanners.length);
          return 0;
        }
        return prev + increment;
      });
    }, stepMs);

    return () => {
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
    };
  }, [currentIndex, isPaused, heroBanners.length]);

  // Reset progress when index changes manually
  const handleSelectIndex = (idx: number) => {
    setCurrentIndex(idx);
    setProgress(0);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % heroBanners.length);
    setProgress(0);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + heroBanners.length) % heroBanners.length);
    setProgress(0);
  };

  if (!heroBanners || heroBanners.length === 0) return null;

  const currentBanner = heroBanners?.[currentIndex] || heroBanners?.[0] || null;
  if (!currentBanner) return null;
  const activeRemainingSec = countdownSeconds[currentBanner.id] ?? (currentBanner.timingSeconds || 14400);

  const hours = Math.floor(activeRemainingSec / 3600);
  const minutes = Math.floor((activeRemainingSec % 3600) / 60);
  const seconds = activeRemainingSec % 60;

  return (
    <section
      id="hero-banner-carousel"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      className="relative overflow-hidden bg-white text-white rounded-3xl max-w-7xl mx-auto my-3 sm:my-5 shadow-2xl border border-slate-800 transition-all group"
    >
      {/* Real-time Top Progress Bar Indicator */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-slate-800 z-30 overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-amber-400 via-orange-400 to-amber-300 transition-all duration-75 ease-linear"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Main Banner Canvas */}
      <div className="relative min-h-[420px] sm:min-h-[490px] flex items-center">
        {/* Real-time Background Image with Cinematic Zoom */}
        <img
          key={currentBanner.id}
          src={currentBanner.desktopImage}
          alt={currentBanner.title}
          className="absolute inset-0 w-full h-full object-cover object-center opacity-45 filter brightness-95 transition-all duration-1000 ease-out scale-105 group-hover:scale-100"
          loading="eager"
        />

        {/* Multi-layered Vignette Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/85 to-transparent z-[1]" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-950/40 z-[1]" />

        {/* Content Box */}
        <div className="relative z-10 max-w-2xl p-6 sm:p-12 space-y-4 sm:space-y-6">
          {/* Top Badges: Discount & Real-time Live Ticker */}
          <div className="flex flex-wrap items-center gap-2.5">
            {currentBanner.liveTag && (
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-black tracking-wider uppercase animate-pulse">
                <Flame className="w-3.5 h-3.5 text-rose-400" />
                <span>{currentBanner.liveTag}</span>
              </div>
            )}

            {currentBanner.discountBadge && (
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-extrabold tracking-wide">
                <Tag className="w-3.5 h-3.5 text-amber-400" />
                <span>{currentBanner.discountBadge}</span>
              </div>
            )}

            {/* Real-Time Countdown Badge */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900/80 border border-slate-700 text-slate-300 text-xs font-mono font-bold backdrop-blur-md">
              <Clock className="w-3.5 h-3.5 text-amber-400 animate-spin" />
              <span>Ends in:</span>
              <span className="text-amber-400">
                {String(hours).padStart(2, '0')}:{String(minutes).padStart(2, '0')}:
                {String(seconds).padStart(2, '0')}
              </span>
            </div>
          </div>

          {/* Heading and Description */}
          <div className="space-y-2.5">
            <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight text-white drop-shadow-lg">
              {currentBanner.title}
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-normal max-w-xl drop-shadow">
              {currentBanner.subtitle}
            </p>
          </div>

          {/* Call to Actions */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              id="btn-hero-primary-cta"
              onClick={() => onExploreCategory(currentBanner.categorySlug || 'all')}
              className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-800 font-black px-6 py-3.5 rounded-2xl text-xs sm:text-sm flex items-center gap-2 shadow-xl shadow-amber-500/25 hover:scale-105 active:scale-95 transition-all"
            >
              <span>{currentBanner.ctaText || 'Shop Collection'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {/* JustAway Spontaneous Escapes & WanderKits */}
            <button
              id="btn-hero-justaway-travel"
              onClick={() => setIsJustAwayHubOpen(true)}
              className="bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-slate-800 font-black px-5 py-3.5 rounded-2xl text-xs sm:text-sm flex items-center gap-2 shadow-xl shadow-orange-500/30 hover:scale-105 active:scale-95 transition-all ring-2 ring-amber-300/60"
            >
              <Sparkles className="w-4 h-4 text-slate-800 animate-pulse" />
              <span>🧭 JustAway: "Just go. Just away." {awayModeActive ? '(Away ON)' : ''}</span>
            </button>

            {/* Community Network Hub Trigger */}
            <button
              onClick={() => setIsCommunityNetworkOpen(true)}
              className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black px-5 py-3.5 rounded-2xl text-xs sm:text-sm flex items-center gap-2 shadow-xl shadow-emerald-600/30 hover:scale-105 active:scale-95 transition-all ring-2 ring-emerald-400/40"
            >
              <Sparkles className="w-4 h-4 text-emerald-200 animate-pulse" />
              <span>⚡ Community Network (Earn & Connect)</span>
            </button>

            <button
              id="btn-hero-ai-stylist"
              onClick={() => setIsWiseAIOpen(true)}
              className="bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 text-white font-bold px-5 py-3.5 rounded-2xl text-xs sm:text-sm flex items-center gap-2 transition-all hover:scale-105 active:scale-95"
            >
              <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
              <span>WiseAI Stylist</span>
            </button>
          </div>

          {/* Quick Micro-Earning & Detour Badges */}
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <button
              onClick={() => setIsDestinationDetourOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-emerald-300 text-xs font-bold border border-emerald-500/30 flex items-center gap-1.5 transition cursor-pointer backdrop-blur-sm"
            >
              <span>🚗 Indore-Khandwa Detour Delivery</span>
              <span className="text-[10px] bg-emerald-950 text-emerald-400 px-1.5 rounded-full border border-emerald-600/50">Earn ₹180-450</span>
            </button>

            <button
              onClick={() => setIsTimeToEarnOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-blue-300 text-xs font-bold border border-blue-500/30 flex items-center gap-1.5 transition cursor-pointer backdrop-blur-sm"
            >
              <span>⏱️ Time-To-Earn (15m-120m)</span>
              <span className="text-[10px] bg-blue-950 text-blue-400 px-1.5 rounded-full border border-blue-600/50">Instant Payout</span>
            </button>

            <button
              onClick={() => setIsProductExchangeOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-cyan-300 text-xs font-bold border border-cyan-500/30 flex items-center gap-1.5 transition cursor-pointer backdrop-blur-sm"
            >
              <span>🔄 Barter & Swap</span>
            </button>
          </div>

          {/* Regional Delivery Guarantee & Genuine Tag */}
          <div className="flex flex-wrap items-center gap-4 sm:gap-6 pt-4 text-xs text-slate-400 border-t border-slate-800/80">
            <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
              <CheckCircle2 className="w-4 h-4" />
              <span>100% Authentic Handcrafted</span>
            </div>
            <div className="flex items-center gap-1.5 text-amber-300 font-medium">
              <Globe className="w-4 h-4 text-amber-400" />
              <span>
                {currentRegion.flag} {currentRegion.name}: Fast Express Dispatch ({currentRegion.estimatedDeliveryDays})
              </span>
            </div>
          </div>
        </div>

        {/* Carousel Navigation Arrows */}
        {heroBanners.length > 1 && (
          <>
            <button
              id="btn-hero-prev"
              onClick={handlePrev}
              aria-label="Previous Slide"
              className="absolute left-3 sm:left-5 top-1/2 -translate-y-1/2 w-11 h-11 rounded-2xl bg-slate-900/70 hover:bg-slate-900/95 text-white border border-slate-700/80 flex items-center justify-center backdrop-blur-md transition-all shadow-xl z-20 hover:scale-110 active:scale-95"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              id="btn-hero-next"
              onClick={handleNext}
              aria-label="Next Slide"
              className="absolute right-3 sm:right-5 top-1/2 -translate-y-1/2 w-11 h-11 rounded-2xl bg-slate-900/70 hover:bg-slate-900/95 text-white border border-slate-700/80 flex items-center justify-center backdrop-blur-md transition-all shadow-xl z-20 hover:scale-110 active:scale-95"
            >
              <ChevronRight className="w-5 h-5" />
            </button>

            {/* Bottom Real-time Slide Thumbnails & Pause/Play Control */}
            <div className="absolute bottom-4 right-4 sm:right-8 flex items-center gap-2 z-20 bg-white/70 backdrop-blur-md p-1.5 rounded-2xl border border-slate-800">
              <button
                onClick={() => setIsPaused((p) => !p)}
                className="w-7 h-7 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center text-xs transition"
                title={isPaused ? 'Resume auto-slider' : 'Pause auto-slider'}
              >
                {isPaused ? <Play className="w-3 h-3 text-amber-400" /> : <Pause className="w-3 h-3 text-slate-300" />}
              </button>

              <div className="flex items-center gap-1.5">
                {heroBanners.map((banner, idx) => (
                  <button
                    key={banner.id}
                    onClick={() => handleSelectIndex(idx)}
                    className={`relative overflow-hidden rounded-xl transition-all duration-300 ${
                      currentIndex === idx
                        ? 'w-12 sm:w-16 h-8 sm:h-9 border-2 border-amber-400 shadow-md ring-2 ring-amber-400/30'
                        : 'w-7 sm:w-8 h-8 sm:h-9 opacity-50 hover:opacity-90 border border-slate-700'
                    }`}
                  >
                    <img
                      src={banner.mobileImage || banner.desktopImage}
                      alt={banner.title}
                      className="w-full h-full object-cover"
                    />
                    {currentIndex === idx && (
                      <div className="absolute inset-0 bg-amber-400/10 flex items-center justify-center">
                        <span className="text-[9px] font-black text-white bg-white/80 px-1 rounded">
                          0{idx + 1}
                        </span>
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </section>
  );
};

