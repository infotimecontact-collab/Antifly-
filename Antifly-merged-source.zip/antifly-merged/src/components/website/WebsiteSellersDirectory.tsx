import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Store,
  Star,
  Users,
  MessageSquare,
  Share2,
  CheckCircle2,
  Gem,
  Search,
  SlidersHorizontal,
  ExternalLink,
  Phone,
  Mail,
  MapPin,
  TrendingUp,
  Award,
  Sparkles,
  ShieldCheck,
  Video,
  QrCode,
  Heart,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
} from 'lucide-react';
import { DirectSellerPaymentModal } from '../common/DirectSellerPaymentModal';
import { SellerProfile } from '../../types';

export const WebsiteSellersDirectory: React.FC = () => {
  const {
    sellers,
    openStoreChat,
    openStoreCommunity,
    toggleFollowSeller,
    openRatingModalForSeller,
    shareStoreToEarnPoints,
    sellerRatings,
    shortVideoReels,
    openReelPlayer,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'diamond' | 'grocery' | 'sweets' | 'handloom' | 'services'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'followers' | 'rating' | 'orders'>('followers');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const itemsPerPage = 30;

  // Direct QR Modal
  const [selectedSellerForQR, setSelectedSellerForQR] = useState<SellerProfile | null>(null);
  const [isQRModalOpen, setIsQRModalOpen] = useState(false);

  // Generate a rich set of 30+ seller profiles if needed
  const extendedSellers: SellerProfile[] = React.useMemo(() => {
    if (sellers.length >= 30) return sellers;
    // Generate simulated nearby verified merchant profiles to reach 30+ compact profiles
    const extraCategories = ['general', 'fashion', 'electronics', 'services', 'food', 'sweets'];
    const extraCities = ['Indore', 'Bhopal', 'Ujjain', 'Dewas', 'Pithampur'];
    const extraAreas = ['Vijaynagar', 'Rajwada', 'Palasia', 'Chappan Dukan', 'Bhawarkua', 'Annapurna'];
    const generated: SellerProfile[] = [...sellers];

    const storeNames = [
      'Shree Balaji Kirana & Dry Fruits',
      'Mahalaxmi Sweets & Namkeen',
      'Indore Silk Heritage & Saree',
      'Sharma Electricals & Tech',
      'Kailash Dairy & Fresh Paneer',
      'Apna Bazaar Hyperlocal Mart',
      'Malwa Handloom Emporium',
      'Chappan Chaat & Fast Foods',
      'Gurukrupa Organic Groceries',
      'Royal Rajasthani Poshak',
      'City Hardware & Sanitary',
      'New Bharat Watch & Mobile Care',
      'Vrindavan Pure Milk Depot',
      'Siddhi Vinayak Gold & Silver',
      'Navrang Fashion Hub',
      'Rajwada Namkeen & Farsan House',
      'Mahaveer Stationary & Xerox',
      'Pooja Sarees & Lehengas',
      'Kisan Seva Kendra Agro',
      'Anand Sweets & Desi Ghee',
      'Super Fast Mobile Repair Hub',
      'Jain Namkeen Bhandar',
      'Radha Krishna Handlooms',
      'Gokul Milk & Bakery',
      'Metro Electronic Superstore',
    ];

    storeNames.forEach((name, i) => {
      if (generated.length < 32) {
        generated.push({
          id: `ext-seller-${i + 1}`,
          storeName: name,
          name: `${name?.split(' ')?.[0] || name || 'Store'} Merchant`,
          email: `store${i + 1}@antifly.com`,
          phone: `+91 98${Math.floor(10000000 + Math.random() * 90000000)}`,
          status: 'Active',
          tier: i % 3 === 0 ? 'Diamond Vendor' : 'Verified Merchant',
          category: extraCategories[i % extraCategories.length] as any,
          city: extraCities[i % extraCities.length],
          locality: extraAreas[i % extraAreas.length],
          rating: Number((4.5 + (i % 5) * 0.1).toFixed(1)),
          totalOrders: 120 + i * 35,
          followersCount: 350 + i * 90,
          isServiceProvider: name.includes('Repair') || name.includes('Tech'),
          storeUpiId: `${name.toLowerCase().replace(/[^a-z0-9]/g, '')}@okaxis`,
          guaranteed7DayExchange: true,
          badge: i % 3 === 0 ? '💎 Diamond' : '⭐ Verified Local',
          description: `Trusted local store in ${extraAreas[i % extraAreas.length]}, ${extraCities[i % extraCities.length]}. Direct delivery & 7-day exchange.`,
        });
      }
    });

    return generated;
  }, [sellers]);

  const filteredSellers = extendedSellers
    .filter((seller) => {
      const isDiamond = (seller.followersCount || 0) >= 1000 || seller.tier === 'Diamond Vendor';
      if (activeTab === 'diamond' && !isDiamond) return false;
      if (activeTab === 'grocery' && seller.category !== 'general' && !seller.storeName.toLowerCase().includes('kirana') && !seller.storeName.toLowerCase().includes('mart')) return false;
      if (activeTab === 'sweets' && !seller.storeName.toLowerCase().includes('sweet') && !seller.storeName.toLowerCase().includes('namkeen')) return false;
      if (activeTab === 'handloom' && !seller.storeName.toLowerCase().includes('silk') && !seller.storeName.toLowerCase().includes('handloom') && !seller.storeName.toLowerCase().includes('saree')) return false;
      if (activeTab === 'services' && !seller.isServiceProvider && seller.category !== 'services') return false;

      const matchesSearch =
        seller.storeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        seller.city?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        seller.locality?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        seller.description?.toLowerCase().includes(searchQuery.toLowerCase());

      return matchesSearch;
    })
    .sort((a, b) => {
      if (sortBy === 'followers') return (b.followersCount || 0) - (a.followersCount || 0);
      if (sortBy === 'rating') return (b.rating || 0) - (a.rating || 0);
      if (sortBy === 'orders') return (b.totalOrders || 0) - (a.totalOrders || 0);
      return 0;
    });

  // Pagination (30 profiles per page)
  const totalPages = Math.ceil(filteredSellers.length / itemsPerPage) || 1;
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedSellers = filteredSellers.slice(startIndex, startIndex + itemsPerPage);

  const diamondVendorsCount = extendedSellers.filter((s) => (s.followersCount || 0) >= 1000 || s.tier === 'Diamond Vendor').length;

  return (
    <div id="website-sellers-directory-page" className="w-full bg-white text-slate-900 min-h-[85vh]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-5">
        
        {/* Header with Search & Live Count */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-xs space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-xl bg-red-100 text-red-600 font-bold">
                  <Store className="w-5 h-5" />
                </span>
                <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900">
                  Venture Profiles Directory
                </h1>
                <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs font-black border border-slate-200">
                  30 Profiles / Page
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">
                Browse compact venture profiles, search by venture name or category, scan direct payment QR codes, and chat instantly.
              </p>
            </div>

            {/* Quick Stats Pill */}
            <div className="flex items-center gap-2 self-start md:self-auto">
              <span className="px-3 py-1.5 rounded-2xl bg-blue-50 text-blue-700 border border-blue-200 text-xs font-black flex items-center gap-1.5">
                <Gem className="w-3.5 h-3.5 text-blue-600" />
                <span>{diamondVendorsCount} Diamond Ventures</span>
              </span>
              <span className="px-3 py-1.5 rounded-2xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-black flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>7-Day Exchange</span>
              </span>
            </div>
          </div>

          {/* Search Box & Sort Row */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
            <div className="relative w-full sm:max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="Search venture name, city, namkeen, silk sarees, grocer..."
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
              />
            </div>

            {/* Category Tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 scrollbar-none">
              <button
                onClick={() => {
                  setActiveTab('all');
                  setCurrentPage(1);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap ${
                  activeTab === 'all'
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                All ({filteredSellers.length})
              </button>
              <button
                onClick={() => {
                  setActiveTab('diamond');
                  setCurrentPage(1);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                  activeTab === 'diamond'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <Gem className="w-3 h-3" />
                <span>Diamond</span>
              </button>
              <button
                onClick={() => {
                  setActiveTab('grocery');
                  setCurrentPage(1);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap ${
                  activeTab === 'grocery'
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                🌾 Kirana
              </button>
              <button
                onClick={() => {
                  setActiveTab('sweets');
                  setCurrentPage(1);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap ${
                  activeTab === 'sweets'
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                🥨 Namkeen
              </button>
              <button
                onClick={() => {
                  setActiveTab('handloom');
                  setCurrentPage(1);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap ${
                  activeTab === 'handloom'
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                🥻 Handlooms
              </button>
            </div>
          </div>
        </div>

        {/* Small Format Compact Grid (30 Profiles per page) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3.5">
          {paginatedSellers.map((seller) => {
            const isDiamond = (seller.followersCount || 0) >= 1000 || seller.tier === 'Diamond Vendor';
            return (
              <div
                key={seller.id}
                className="p-3.5 bg-white border border-slate-200 rounded-2xl flex flex-col justify-between space-y-2.5 shadow-2xs hover:shadow-md transition-all hover:border-slate-300 group"
              >
                {/* Store Header */}
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-8 h-8 rounded-xl bg-red-100 text-red-600 flex items-center justify-center font-black text-xs border border-red-200 flex-shrink-0">
                        {seller.storeName.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <h4 className="font-extrabold text-xs text-slate-900 truncate leading-tight">
                          {seller.storeName}
                        </h4>
                        <p className="text-[10px] text-slate-500 font-semibold truncate">
                          📍 {seller.locality || seller.city || 'Indore'}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => toggleFollowSeller(seller.id)}
                      className={`p-1 rounded-lg text-[10px] font-black transition cursor-pointer ${
                        seller.isFollowed
                          ? 'bg-red-50 text-red-600'
                          : 'bg-slate-100 text-slate-600 hover:bg-red-50 hover:text-red-600'
                      }`}
                      title={seller.isFollowed ? 'Unfollow' : 'Follow'}
                    >
                      {seller.isFollowed ? '✓' : '+'}
                    </button>
                  </div>

                  {/* Badges & Rating */}
                  <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                    <span className="text-[10px] font-black px-1.5 py-0.2 rounded bg-amber-50 text-amber-800 border border-amber-200 flex items-center gap-0.5">
                      <Star className="w-2.5 h-2.5 fill-amber-400 text-amber-500" />
                      <span>{seller.rating || 4.8}</span>
                    </span>

                    {isDiamond ? (
                      <span className="text-[9px] font-black px-1.5 py-0.2 rounded-full bg-blue-50 text-blue-700 border border-blue-200 flex items-center gap-0.5">
                        <Gem className="w-2.5 h-2.5 text-blue-600" />
                        <span>Diamond</span>
                      </span>
                    ) : (
                      <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-600">
                        ⭐ Local
                      </span>
                    )}

                    <span className="text-[9px] font-medium text-slate-500">
                      {seller.followersCount || 250} followers
                    </span>
                  </div>
                </div>

                {/* 7-Day Exchange Micro Tag */}
                <div className="text-[9px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-100 flex items-center gap-1">
                  <RotateCcw className="w-2.5 h-2.5" />
                  <span>7-Day Exchange Guaranteed</span>
                </div>

                {/* Direct Actions: QR Pay & Chat */}
                <div className="grid grid-cols-2 gap-1.5 pt-1.5 border-t border-slate-100">
                  <button
                    onClick={() => {
                      setSelectedSellerForQR(seller);
                      setIsQRModalOpen(true);
                    }}
                    className="py-1 px-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-800 rounded-xl text-[10px] font-black flex items-center justify-center gap-1 transition cursor-pointer"
                  >
                    <QrCode className="w-3 h-3 text-red-600" />
                    <span>Pay QR</span>
                  </button>

                  <button
                    onClick={() => openStoreChat(seller.id)}
                    className="py-1 px-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-[10px] font-black flex items-center justify-center gap-1 transition cursor-pointer shadow-2xs"
                  >
                    <MessageSquare className="w-3 h-3" />
                    <span>Chat</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Pagination Bar */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between bg-white border border-slate-200 rounded-2xl p-4 shadow-xs text-xs font-bold">
            <span className="text-slate-600">
              Showing {startIndex + 1}–{Math.min(startIndex + itemsPerPage, filteredSellers.length)} of {filteredSellers.length} Venture Profiles
            </span>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 disabled:opacity-40 transition cursor-pointer flex items-center gap-1"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Prev</span>
              </button>

              <span className="px-3 py-1.5 bg-red-600 text-white rounded-xl font-black">
                Page {currentPage} of {totalPages}
              </span>

              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 disabled:opacity-40 transition cursor-pointer flex items-center gap-1"
              >
                <span>Next</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Direct Seller Payment QR Modal */}
      <DirectSellerPaymentModal
        seller={selectedSellerForQR}
        isOpen={isQRModalOpen}
        onClose={() => setIsQRModalOpen(false)}
      />
    </div>
  );
};
