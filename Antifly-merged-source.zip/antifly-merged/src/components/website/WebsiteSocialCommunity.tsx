import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Heart,
  MessageCircle,
  Repeat2,
  Send,
  Share2,
  Image as ImageIcon,
  Sparkles,
  CheckCircle2,
  Gem,
  Store,
  MapPin,
  Plus,
  UserPlus,
  UserCheck,
  TrendingUp,
  User,
  Users,
  Search,
  RotateCcw,
} from 'lucide-react';
import { CommunityMember, SellerProfile } from '../../types';

export const WebsiteSocialCommunity: React.FC = () => {
  const {
    communityMembers,
    toggleFollowCommunityMember,
    createCommunityFeedPost,
    shareStoreToEarnPoints,
    openStoreChat,
    sellers,
    toggleFollowSeller,
    showToast,
  } = useApp();

  const [newPostText, setNewPostText] = useState<string>('');
  const [selectedStoreTag, setSelectedStoreTag] = useState<string>('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'sellers' | 'customers' | 'followed'>('all');
  const [searchMemberQuery, setSearchMemberQuery] = useState<string>('');

  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostText.trim()) return;

    createCommunityFeedPost(newPostText, undefined, selectedStoreTag || undefined);
    setNewPostText('');
    setSelectedStoreTag('');
    showToast('🎉 Posted to Antifly Community! +2 Reward Points earned');
  };

  const filteredMembers = communityMembers.filter((m) =>
    m.name.toLowerCase().includes(searchMemberQuery.toLowerCase()) ||
    m.handle.toLowerCase().includes(searchMemberQuery.toLowerCase()) ||
    m.bio?.toLowerCase().includes(searchMemberQuery.toLowerCase())
  );

  const filteredSellers = sellers.filter((s) =>
    s.storeName.toLowerCase().includes(searchMemberQuery.toLowerCase()) ||
    s.city?.toLowerCase().includes(searchMemberQuery.toLowerCase())
  );

  return (
    <div id="website-social-community-page" className="w-full bg-white text-slate-900 min-h-[85vh]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
        {/* Header */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-red-100 text-red-600 font-bold">
                <Users className="w-5 h-5" />
              </span>
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900">
                Community & Follow Requests
              </h1>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">
              Follow both local store merchants and nearby customers. Stay updated with hyperlocal deals, bargain feeds, and honest reviews.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-3 py-1.5 rounded-2xl bg-red-50 text-red-700 border border-red-200 text-xs font-black">
              +2 Pts / Store Share
            </span>
          </div>
        </div>

        {/* Filter Tabs & Search Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-50 border border-slate-200 rounded-2xl p-2">
          <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap ${
                activeFilter === 'all'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Feeds
            </button>
            <button
              onClick={() => setActiveFilter('sellers')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                activeFilter === 'sellers'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Store className="w-3 h-3" />
              <span>Sellers to Follow</span>
            </button>
            <button
              onClick={() => setActiveFilter('customers')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                activeFilter === 'customers'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <User className="w-3 h-3" />
              <span>Customers / Friends</span>
            </button>
            <button
              onClick={() => setActiveFilter('followed')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                activeFilter === 'followed'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <UserCheck className="w-3 h-3" />
              <span>My Followed List</span>
            </button>
          </div>

          <div className="relative w-full sm:w-56">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchMemberQuery}
              onChange={(e) => setSearchMemberQuery(e.target.value)}
              placeholder="Search people or stores..."
              className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-red-500 font-medium"
            />
          </div>
        </div>

        {/* Create Post Card */}
        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs">
          <form onSubmit={handlePostSubmit} className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-red-600 to-rose-600 flex items-center justify-center text-white font-black text-sm flex-shrink-0 shadow-xs">
                W
              </div>
              <textarea
                value={newPostText}
                onChange={(e) => setNewPostText(e.target.value)}
                placeholder="Share a deal, recommend a nearby shop, or ask for local reviews in Indore..."
                rows={3}
                className="flex-1 bg-slate-50 border border-slate-200 rounded-2xl p-3 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 resize-none font-medium"
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
              <div className="flex items-center gap-2">
                <select
                  value={selectedStoreTag}
                  onChange={(e) => setSelectedStoreTag(e.target.value)}
                  aria-label="Tag a Store in your post"
                  className="bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-700 focus:outline-none cursor-pointer"
                >
                  <option value="">🏷️ Tag a Store (+2 Points)</option>
                  {sellers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.storeName}
                    </option>
                  ))}
                </select>
              </div>

              <button
                type="submit"
                disabled={!newPostText.trim()}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white text-xs font-black shadow-xs transition cursor-pointer flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Post Update</span>
              </button>
            </div>
          </form>
        </div>

        {/* SECTION 1: NEARBY SELLERS (Follow / Unfollow) */}
        {(activeFilter === 'all' || activeFilter === 'sellers' || activeFilter === 'followed') && (
          <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Store className="w-4 h-4 text-red-600" />
                <h2 className="text-xs font-black uppercase tracking-wider text-slate-900">
                  Nearby Sellers & Merchants to Follow
                </h2>
              </div>
              <span className="text-[11px] font-bold text-slate-400">Direct Merchant Network</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {filteredSellers
                .filter((s) => activeFilter !== 'followed' || s.isFollowed)
                .slice(0, 6)
                .map((seller) => (
                  <div
                    key={seller.id}
                    className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-xl bg-red-100 text-red-600 flex items-center justify-center font-black text-sm border border-red-200 flex-shrink-0">
                        {seller.storeName.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1">
                          <h4 className="font-black text-xs text-slate-900 truncate">
                            {seller.storeName}
                          </h4>
                          <CheckCircle2 className="w-3 h-3 text-blue-600 fill-blue-50 flex-shrink-0" />
                        </div>
                        <p className="text-[10px] text-slate-500 font-semibold truncate">
                          📍 {seller.city || 'Indore'} &bull; {seller.followersCount || 100} followers
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      <button
                        onClick={() => openStoreChat(seller.id)}
                        className="p-1.5 bg-white border border-slate-200 text-slate-700 hover:text-red-600 rounded-xl text-xs font-bold transition cursor-pointer"
                        title="Chat"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => toggleFollowSeller(seller.id)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-1 ${
                          seller.isFollowed
                            ? 'bg-slate-200 text-slate-800 hover:bg-red-50 hover:text-red-600'
                            : 'bg-red-600 text-white hover:bg-red-700 shadow-2xs'
                        }`}
                      >
                        {seller.isFollowed ? (
                          <>
                            <UserCheck className="w-3 h-3" />
                            <span>Following</span>
                          </>
                        ) : (
                          <>
                            <UserPlus className="w-3 h-3" />
                            <span>Follow</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* SECTION 2: NEARBY CUSTOMERS & FRIENDS (Follow / Unfollow) */}
        {(activeFilter === 'all' || activeFilter === 'customers' || activeFilter === 'followed') && (
          <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-blue-600" />
                <h2 className="text-xs font-black uppercase tracking-wider text-slate-900">
                  Nearby Customers & Voice Shoppers to Follow
                </h2>
              </div>
              <span className="text-[11px] font-bold text-slate-400">Community Circle</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {filteredMembers
                .filter((m) => activeFilter !== 'followed' || m.isFollowed)
                .map((member) => (
                  <div
                    key={member.id}
                    className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-full overflow-hidden border border-slate-200 flex-shrink-0">
                        <img
                          src={member.avatar}
                          alt={member.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1">
                          <h4 className="font-black text-xs text-slate-900 truncate">
                            {member.name}
                          </h4>
                          {member.isVerified && (
                            <CheckCircle2 className="w-3 h-3 text-blue-600 fill-blue-50 flex-shrink-0" />
                          )}
                        </div>
                        <p className="text-[10px] text-slate-500 font-semibold truncate">
                          @{member.handle} &bull; {member.followersCount || 45} followers
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => toggleFollowCommunityMember(member.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-1 flex-shrink-0 ${
                        member.isFollowed
                          ? 'bg-slate-200 text-slate-800 hover:bg-red-50 hover:text-red-600'
                          : 'bg-blue-600 text-white hover:bg-blue-700 shadow-2xs'
                      }`}
                    >
                      {member.isFollowed ? (
                        <>
                          <UserCheck className="w-3 h-3" />
                          <span>Following</span>
                        </>
                      ) : (
                        <>
                          <UserPlus className="w-3 h-3" />
                          <span>Follow</span>
                        </>
                      )}
                    </button>
                  </div>
                ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
