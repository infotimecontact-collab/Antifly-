import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  MapPin,
  Search,
  Store,
  Star,
  Users,
  MessageSquare,
  Share2,
  Navigation,
  Sparkles,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldCheck,
  Percent,
  TrendingUp,
  Tag,
  Gem,
  QrCode,
  RotateCcw,
  Heart,
  Calendar,
} from 'lucide-react';
import { DirectSellerPaymentModal } from '../common/DirectSellerPaymentModal';
import { SellerProfile } from '../../types';

interface WebsiteNearbyStoresProps {
  onSelectStoreProducts?: (sellerId: string) => void;
}

export const WebsiteNearbyStores: React.FC<WebsiteNearbyStoresProps> = ({ onSelectStoreProducts }) => {
  const {
    sellers,
    openStoreChat,
    openStoreCommunity,
    toggleFollowSeller,
    openRatingModalForSeller,
    shareStoreToEarnPoints,
    customerConnectState,
    setIsConnectMembershipModalOpen,
    isOneYearFreePromoActive,
    userLocation,
    setUserLocation,
    openReelPlayer,
    shortVideoReels,
    showToast,
  } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [maxDistanceKm, setMaxDistanceKm] = useState<number>(50);
  const [selectedArea, setSelectedArea] = useState<string>('Vijaynagar');

  // Direct QR Modal
  const [selectedSellerForQR, setSelectedSellerForQR] = useState<SellerProfile | null>(null);
  const [isQRModalOpen, setIsQRModalOpen] = useState(false);

  const indoreAreas = [
    { name: 'Vijaynagar', lat: 22.7533, lng: 75.8937 },
    { name: 'Rajwada Market', lat: 22.7196, lng: 75.8577 },
    { name: 'Palasia', lat: 22.7244, lng: 75.8839 },
    { name: 'Chappan Dukan', lat: 22.7230, lng: 75.8790 },
    { name: 'Bhawarkua', lat: 22.6920, lng: 75.8670 },
    { name: 'Annapurna Road', lat: 22.7050, lng: 75.8450 },
  ];

  const categories = [
    { id: 'all', label: 'All Nearby Stores', icon: '🏪' },
    { id: 'grocery', label: 'Groceries & Kirana', icon: '🌾' },
    { id: 'sweets', label: 'Sweets & Namkeen', icon: '🥨' },
    { id: 'dairy', label: 'Fresh Milk & Dairy', icon: '🥛' },
    { id: 'handloom', label: 'Silk & Handlooms', icon: '🥻' },
    { id: 'electronics', label: 'Electronics & Gadgets', icon: '⚡' },
    { id: 'services', label: 'Electrician & Repairs', icon: '🔧' },
  ];

  const filteredSellers = sellers.filter((seller) => {
    const matchesCategory =
      selectedCategory === 'all' ||
      (selectedCategory === 'grocery' && (seller.category === 'general' || seller.storeName.toLowerCase().includes('general') || seller.storeName.toLowerCase().includes('store') || seller.storeName.toLowerCase().includes('kirana'))) ||
      (selectedCategory === 'sweets' && (seller.storeName.toLowerCase().includes('sweet') || seller.storeName.toLowerCase().includes('namkeen'))) ||
      (selectedCategory === 'dairy' && (seller.storeName.toLowerCase().includes('dairy') || seller.storeName.toLowerCase().includes('milk'))) ||
      (selectedCategory === 'handloom' && (seller.storeName.toLowerCase().includes('silk') || seller.storeName.toLowerCase().includes('handloom') || seller.category === 'fashion')) ||
      (selectedCategory === 'electronics' && (seller.storeName.toLowerCase().includes('electronics') || seller.storeName.toLowerCase().includes('tech') || seller.category === 'electronics')) ||
      (selectedCategory === 'services' && (seller.isServiceProvider || seller.category === 'services'));

    const matchesSearch =
      seller.storeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      seller.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      seller.city?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      seller.locality?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      seller.badge?.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesSearch;
  });

  return (
    <div id="website-nearby-stores-page" className="w-full bg-white text-slate-900 min-h-[85vh]">
      {/* 1-Year Free & 3-Month Free Promo Strip */}
      <div className="bg-red-50 border-b border-red-100 py-2 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2 text-xs font-semibold text-red-900">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-full bg-red-600 text-white font-black text-[10px] uppercase tracking-wider">
              {isOneYearFreePromoActive ? '1-Year Free Promo' : '3-Month Free Trial'}
            </span>
            <span>
              Talk to <strong>Any Nearby Store</strong> for free! Zero platform contact fees currently active.
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-[11px] text-red-700 hidden sm:inline">
              🛡️ <strong>7-Day Mandatory Exchange</strong>: Sellers cannot deny returns or exchanges!
            </span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Top Header Card */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-xs">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="p-1.5 rounded-xl bg-red-100 text-red-600 font-bold">
                  <Store className="w-5 h-5" />
                </span>
                <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900">
                  Nearby Stores & Merchants
                </h1>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-xs font-black">
                  Within {maxDistanceKm} KM
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">
                Discover verified shops in your neighborhood. Scan store QR to pay directly, chat 1-on-1, or book home delivery.
              </p>
            </div>

            {/* Geolocation Area Selector */}
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-2xl px-3 py-1.5">
                <MapPin className="w-4 h-4 text-red-600 flex-shrink-0" />
                <span className="text-xs font-bold text-slate-700">Area:</span>
                <select
                  value={selectedArea}
                  onChange={(e) => {
                    const area = indoreAreas.find((a) => a.name === e.target.value);
                    if (area) {
                      setSelectedArea(area.name);
                      setUserLocation({ lat: area.lat, lng: area.lng, city: 'Indore', address: `${area.name}, Indore` });
                      showToast(`📍 Switched location to ${area.name}`);
                    }
                  }}
                  className="bg-transparent text-xs font-extrabold text-slate-900 focus:outline-none cursor-pointer"
                >
                  {indoreAreas.map((a) => (
                    <option key={a.name} value={a.name}>
                      {a.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Radius Filter */}
              <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-2xl px-3 py-1.5">
                <Navigation className="w-4 h-4 text-red-600 flex-shrink-0" />
                <span className="text-xs font-bold text-slate-700">Radius:</span>
                <select
                  value={maxDistanceKm}
                  onChange={(e) => setMaxDistanceKm(Number(e.target.value))}
                  className="bg-transparent text-xs font-extrabold text-slate-900 focus:outline-none cursor-pointer"
                >
                  <option value={5}>5 KM</option>
                  <option value={10}>10 KM</option>
                  <option value={25}>25 KM</option>
                  <option value={50}>50 KM (Default)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Search Box */}
          <div className="mt-4 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search store name, item, locality (e.g. Balaji Kirana, Silk Sarees, Palasia)..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
            />
          </div>

          {/* Category Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pt-3 pb-1 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-black whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                  selectedCategory === cat.id
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Sellers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredSellers.map((seller, idx) => {
            const distance = (0.4 + (idx % 6) * 0.8).toFixed(1);
            const isDiamond = (seller.followersCount || 0) >= 1000 || seller.tier === 'Diamond Vendor';

            return (
              <div
                key={seller.id}
                className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs hover:shadow-md hover:border-slate-300 transition-all flex flex-col justify-between group"
              >
                <div>
                  {/* Top Store Banner / Image */}
                  <div className="relative h-36 w-full rounded-2xl overflow-hidden mb-3.5 bg-slate-100">
                    <img
                      src={seller.bannerImage || 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=800&auto=format&fit=crop&q=80'}
                      alt={seller.storeName}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent" />

                    {/* Distance Badge */}
                    <span className="absolute top-2.5 left-2.5 px-2.5 py-1 rounded-full bg-white/95 backdrop-blur-md text-slate-900 text-[11px] font-black shadow-xs flex items-center gap-1 border border-slate-200/80">
                      <MapPin className="w-3 h-3 text-red-600" />
                      {distance} km away
                    </span>

                    {/* Diamond Vendor Badge */}
                    {isDiamond && (
                      <span className="absolute top-2.5 right-2.5 px-2.5 py-0.5 rounded-full bg-blue-600 text-white text-[10px] font-black shadow-xs flex items-center gap-1">
                        <Gem className="w-3 h-3" />
                        Diamond Vendor
                      </span>
                    )}

                    {/* Store Logo */}
                    <div className="absolute -bottom-2 left-3 w-12 h-12 rounded-xl border-2 border-white bg-white overflow-hidden shadow-md">
                      <img
                        src={seller.logoImage || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=150&auto=format&fit=crop&q=80'}
                        alt={seller.storeName}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>

                    <div className="absolute bottom-1.5 right-3 text-white text-[11px] font-bold flex items-center gap-1">
                      <Clock className="w-3 h-3 text-emerald-400" />
                      <span>Open Now</span>
                    </div>
                  </div>

                  {/* Store Title & Description */}
                  <div className="mt-4">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <h3 className="font-extrabold text-base text-slate-900 group-hover:text-red-600 transition-colors">
                        {seller.storeName}
                      </h3>
                      {seller.isActive && (
                        <CheckCircle2 className="w-4 h-4 text-blue-600 fill-blue-50" />
                      )}
                    </div>

                    <p className="text-xs text-slate-500 font-medium line-clamp-2 mt-1">
                      {seller.description}
                    </p>

                    {/* Address & 7-Day Exchange Tag */}
                    <div className="flex items-center justify-between text-xs text-slate-600 mt-2.5">
                      <div className="flex items-center gap-1 truncate">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                        <span className="truncate">{seller.locality || seller.warehouseAddress?.street || 'Indore'}</span>
                      </div>

                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1 flex-shrink-0">
                        <RotateCcw className="w-2.5 h-2.5" />
                        <span>7-Day Exchange</span>
                      </span>
                    </div>

                    {/* Metrics Row: Rating, Followers & Orders */}
                    <div className="flex items-center gap-3 mt-3 pt-3 border-t border-slate-100 text-xs">
                      <button
                        onClick={() => openRatingModalForSeller(seller)}
                        className="flex items-center gap-1 font-extrabold text-slate-900 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200/80 hover:bg-amber-100 transition cursor-pointer"
                        title="Click to Rate Store (1-10 Scale)"
                      >
                        <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
                        <span>{seller.rating || 4.9} / 5</span>
                        <span className="text-[10px] text-amber-800 font-medium">({((seller.rating || 4.9) * 2).toFixed(1)}/10)</span>
                      </button>

                      <div className="flex items-center gap-1 text-slate-600 font-semibold">
                        <Users className="w-3.5 h-3.5 text-slate-400" />
                        <span>{seller.followersCount || 120} followers</span>
                      </div>

                      <div className="text-slate-500 text-[11px]">
                        {seller.totalOrders || 500}+ orders
                      </div>
                    </div>
                  </div>
                </div>

                {/* Interactive Action Buttons */}
                <div className="mt-4 pt-3 border-t border-slate-100 space-y-2">
                  <div className="grid grid-cols-3 gap-2">
                    {/* Direct QR Pay */}
                    <button
                      onClick={() => {
                        setSelectedSellerForQR(seller);
                        setIsQRModalOpen(true);
                      }}
                      className="flex items-center justify-center gap-1 py-2 px-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-800 text-xs font-black transition cursor-pointer"
                      title="Direct Scan & Pay to Store UPI"
                    >
                      <QrCode className="w-3.5 h-3.5 text-red-600" />
                      <span>Pay QR</span>
                    </button>

                    {/* Direct 1-on-1 Store Chat */}
                    <button
                      onClick={() => openStoreChat(seller.id)}
                      className="flex items-center justify-center gap-1 py-2 px-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-xs transition cursor-pointer"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Chat</span>
                    </button>

                    {/* Join Community Feed */}
                    <button
                      onClick={() => openStoreCommunity(seller.id)}
                      className="flex items-center justify-center gap-1 py-2 px-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition cursor-pointer"
                    >
                      <Users className="w-3.5 h-3.5 text-red-600" />
                      <span>Feed</span>
                    </button>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-1 text-xs">
                    {/* Follow / Unfollow */}
                    <button
                      onClick={() => toggleFollowSeller(seller.id)}
                      className="flex items-center gap-1 font-bold text-slate-700 hover:text-red-600 cursor-pointer"
                    >
                      <span>{seller.isFollowed ? '✓ Following' : '+ Follow Store'}</span>
                    </button>

                    {/* Share Store to Earn +2 Points */}
                    <button
                      onClick={() => shareStoreToEarnPoints(seller.id, seller.storeName)}
                      className="flex items-center gap-1 text-red-600 hover:text-red-700 font-extrabold cursor-pointer bg-red-50 hover:bg-red-100 px-2 py-0.5 rounded-md transition"
                      title="Share link with friends to earn +2 Reward Points"
                    >
                      <Share2 className="w-3 h-3" />
                      <span>Share (+2 Pts)</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Direct Seller Payment QR Modal */}
      <DirectSellerPaymentModal
        seller={selectedSellerForQR}
        isOpen={isQRModalOpen}
        onClose={() => setIsQRModalOpen(false)}
      />
    </div>
  );
};
