import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../common/ProductCard';
import {
  Sparkles,
  Zap,
  TrendingUp,
  Award,
  Clock,
  ArrowRight,
  ShieldCheck,
  Truck,
  RotateCcw,
  Headphones,
  Smartphone,
  Star,
  Tag,
  CheckCircle,
  Coins,
  Store,
  Users,
  Heart,
  Eye,
  Gift,
  ShoppingBag,
  Flame,
  UtensilsCrossed,
  Crown,
  CreditCard,
  Tv,
  Film,
  Percent,
  MapPin,
  BadgeCheck,
  Navigation,
  Compass,
  Palmtree,
  Luggage,
  Mountain,
  Wind,
} from 'lucide-react';
import { JUSTAWAY_ESCAPES, JUSTAWAY_GEAR_KITS } from '../../data/justAwayData';

interface WebsiteModularHomepageProps {
  onSelectCategory: (slug: string) => void;
  onViewCatalog: () => void;
}

export const WebsiteModularHomepage: React.FC<WebsiteModularHomepageProps> = ({
  onSelectCategory,
  onViewCatalog,
}) => {
  const {
    homepageSections,
    products,
    categories,
    banners,
    setIsWiseAIOpen,
    setDeviceMode,
    superCoinsBalance,
    setIsSuperCoinsModalOpen,
    setIsResellerModalOpen,
    setIsStyleCastModalOpen,
    setActiveStyleLook,
    styleCastLooks,
    groupBuyDeals,
    setIsGroupBuyModalOpen,
    joinGroupBuy,
    formatPrice,
    setIsFoodDeliveryModalOpen,
    setIsWiseOneModalOpen,
    setIsBankOffersModalOpen,
    setIsOTTModalOpen,
    wiseOneSubscription,
    sellers,
    userLocation,
    calculateDistanceKm,
    setSelectedCategorySlug,
    setIsJustAwayHubOpen,
    awayModeActive,
    setAwayModeActive,
    driftMilesBalance,
  } = useApp();

  // Flash Sale Countdown Timer
  const [timeLeft, setTimeLeft] = useState({ hours: 7, minutes: 42, seconds: 19 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return { hours: 12, minutes: 0, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const visibleSections = [...homepageSections]
    .filter((s) => s.isVisible)
    .sort((a, b) => a.order - b.order);

  const trendingProducts = products.filter((p) => p.isTrending || p.isFeatured).slice(0, 4);
  const flashSaleProducts = products.filter((p) => p.discountPercentage >= 30).slice(0, 4);
  const newArrivals = products.filter((p) => p.isNewArrival || p.isBestSeller).slice(0, 4);

  return (
    <div className="space-y-12 sm:space-y-16 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* 1. Value Proposition Features Bar */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-4 p-5 sm:p-6 bg-slate-50 dark:bg-slate-800/60 rounded-3xl border border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-600 flex items-center justify-center flex-shrink-0">
            <Truck className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">Free Express Delivery</h4>
            <p className="text-[11px] text-slate-500">On all prepaid orders over ₹999</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center flex-shrink-0">
            <RotateCcw className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">7-Day Free Returns</h4>
            <p className="text-[11px] text-slate-500">Instant UPI & Bank refunds</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-blue-500/10 text-blue-600 flex items-center justify-center flex-shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">100% Authentic Quality</h4>
            <p className="text-[11px] text-slate-500">Handcrafted artisan standards</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-purple-500/10 text-purple-600 flex items-center justify-center flex-shrink-0">
            <Headphones className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">24/7 WiseAI Concierge</h4>
            <p className="text-[11px] text-slate-500">Styling & size recommendations</p>
          </div>
        </div>
      </section>

      {/* 2. WiseCoins Loyalty & Rewards Zone Bar */}
      <section className="p-5 sm:p-6 bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-500 rounded-3xl text-slate-800 shadow-lg border border-amber-300 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center border border-slate-200/10 shadow-inner flex-shrink-0">
            <Coins className="w-8 h-8 text-slate-800 fill-amber-300 animate-bounce" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-wider bg-white text-amber-300 px-2 py-0.5 rounded-full">
                ⚡ WiseCoins Loyalty Hub
              </span>
              <span className="text-xs font-black text-slate-900">Your Balance: {superCoinsBalance} Coins (₹{superCoinsBalance})</span>
            </div>
            <h3 className="text-lg font-black text-slate-800 mt-0.5">
              Claim Premium Subscriptions, Travel Perks & Direct Checkout Savings
            </h3>
          </div>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <button
            onClick={() => setIsSuperCoinsModalOpen(true)}
            className="flex-1 sm:flex-initial px-4 py-2.5 bg-white hover:bg-slate-900 text-amber-300 font-black text-xs rounded-2xl shadow-md transition flex items-center justify-center gap-1.5 whitespace-nowrap"
          >
            <Gift className="w-4 h-4" />
            Explore Coin Rewards
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </section>

      {/* 3. WiseStyle Creator Lookbook */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-pink-500 to-rose-500 text-white flex items-center justify-center shadow-md">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-pink-100 dark:bg-pink-950 text-pink-700 dark:text-pink-300 px-2 py-0.5 rounded-md">
                  WiseStyle Runway & Lookbook
                </span>
                <span className="text-xs text-stone-500 font-semibold">Influencer Outfit Styling</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-stone-900 dark:text-white">
                Shop Trending Looks & Outfits
              </h2>
            </div>
          </div>

          <button
            onClick={() => setIsStyleCastModalOpen(true)}
            className="text-xs font-bold text-pink-600 dark:text-pink-400 hover:underline flex items-center gap-1"
          >
            <span>Open WiseStyle</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {styleCastLooks.map((look) => (
            <div
              key={look.id}
              onClick={() => {
                setActiveStyleLook(look);
                setIsStyleCastModalOpen(true);
              }}
              className="group cursor-pointer rounded-3xl overflow-hidden border border-stone-200 dark:border-slate-800 bg-stone-950 relative shadow-md hover:shadow-xl transition-all flex flex-col justify-between h-[360px]"
            >
              <img
                src={look.coverImage}
                alt={look.title}
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-85"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent" />

              {/* Top pill */}
              <div className="relative z-10 p-3 flex justify-between items-center">
                <span className="px-2.5 py-1 rounded-full bg-slate-100/60 backdrop-blur-md text-[10px] font-extrabold text-pink-300 border border-pink-500/30">
                  ✨ {look.occasion}
                </span>
                <span className="px-2 py-1 rounded-full bg-rose-600/90 text-white text-[10px] font-black shadow-sm">
                  {look.bundleDiscountPercentage}% Bundle OFF
                </span>
              </div>

              {/* Bottom Creator Info */}
              <div className="relative z-10 p-4 space-y-2 text-white">
                <div className="flex items-center gap-2">
                  <img
                    src={look.influencerAvatar}
                    alt={look.influencerName}
                    className="w-7 h-7 rounded-full border border-pink-400 object-cover"
                  />
                  <div>
                    <p className="text-xs font-bold text-white">{look.influencerName}</p>
                    <p className="text-[10px] text-pink-300">{look.influencerHandle}</p>
                  </div>
                </div>

                <h4 className="font-extrabold text-xs text-white line-clamp-2 leading-snug">
                  {look.title}
                </h4>

                <div className="pt-2 border-t border-white/20 flex items-center justify-between">
                  <span className="text-[11px] text-stone-300 font-semibold flex items-center gap-1">
                    <ShoppingBag className="w-3.5 h-3.5 text-pink-400" />
                    {look?.taggedProductIds?.length || 0} Items Tagged
                  </span>
                  <span className="text-xs font-extrabold text-pink-400 group-hover:translate-x-1 transition-transform flex items-center gap-0.5">
                    Shop Look <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3.4. Hyperlocal Verified Stores & Wholesalers Discovery (Within 50 KM) */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-wider bg-emerald-600 text-white px-2.5 py-0.5 rounded-full flex items-center gap-1 shadow-xs">
                <Navigation className="w-3 h-3" />
                Hyperlocal Geolocation Discovery
              </span>
              <span className="text-xs text-slate-500 font-semibold hidden sm:inline">
                Delivering to: <strong className="text-slate-800 dark:text-slate-200">{userLocation.city}</strong> (Within 50 KM Radius)
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1 flex items-center gap-2">
              <Store className="w-6 h-6 text-emerald-500" />
              Stores & Authorized Wholesalers Near You
            </h2>
          </div>
          <button
            onClick={onViewCatalog}
            className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
          >
            <span>View All Stores</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {sellers.slice(0, 4).map((seller) => {
            const distance = calculateDistanceKm(
              userLocation.lat,
              userLocation.lng,
              seller.lat,
              seller.lng
            );
            const isWholesale = seller.isWholesaler;
            const isDealership = seller.isDealershipVendor;

            return (
              <div
                key={seller.id}
                onClick={onViewCatalog}
                className="group relative bg-white dark:bg-slate-900 rounded-3xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl hover:border-emerald-500/50 transition-all duration-300 cursor-pointer flex flex-col justify-between"
              >
                <div>
                  {/* Store Banner */}
                  <div className="relative h-28 rounded-2xl overflow-hidden mb-3 bg-slate-800">
                    <img
                      src={seller.bannerImage || 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=500&auto=format&fit=crop&q=60'}
                      alt={seller.storeName}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                    
                    {/* Distance Badge */}
                    <div className="absolute top-2.5 right-2.5 bg-white/90 backdrop-blur-md text-emerald-400 border border-emerald-500/30 text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm">
                      <MapPin className="w-3 h-3" />
                      {distance.toFixed(1)} KM
                    </div>

                    {/* Badge */}
                    <div className="absolute bottom-2 left-2.5">
                      <span className="text-[10px] font-bold bg-amber-500 text-slate-800 px-2 py-0.5 rounded-lg shadow-sm">
                        {seller.badge}
                      </span>
                    </div>
                  </div>

                  {/* Store Info */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <h3 className="font-extrabold text-sm text-slate-900 dark:text-white line-clamp-1 group-hover:text-emerald-500 transition-colors">
                        {seller.storeName}
                      </h3>
                      <div className="flex items-center gap-1 text-[11px] font-bold text-amber-500 bg-amber-500/10 px-1.5 py-0.5 rounded-md">
                        <Star className="w-3 h-3 fill-amber-400" />
                        {seller.rating.toFixed(1)}
                      </div>
                    </div>

                    <p className="text-[11px] text-slate-500 line-clamp-1">
                      {seller.category} • {seller.city}
                    </p>

                    {/* Role & MOQ Chips */}
                    <div className="flex flex-wrap gap-1 pt-1.5">
                      {isWholesale && (
                        <span className="text-[9px] font-bold bg-purple-500/10 text-purple-600 dark:text-purple-300 border border-purple-500/20 px-2 py-0.5 rounded-md">
                          Wholesale Lot Pricing
                        </span>
                      )}
                      {isDealership && (
                        <span className="text-[9px] font-bold bg-blue-500/10 text-blue-600 dark:text-blue-300 border border-blue-500/20 px-2 py-0.5 rounded-md">
                          Dealership Direct
                        </span>
                      )}
                      <span className="text-[9px] font-medium text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md">
                        Max {seller.deliveryRadiusKm} KM Service
                      </span>
                    </div>
                  </div>
                </div>

                {/* Footer ETA */}
                <div className="pt-3 mt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs">
                  <span className="text-[11px] font-semibold text-slate-500 flex items-center gap-1">
                    <Truck className="w-3.5 h-3.5 text-emerald-500" />
                    ~30-45 min delivery
                  </span>
                  <span className="text-xs font-black text-emerald-600 dark:text-emerald-400 group-hover:translate-x-1 transition-transform flex items-center gap-0.5">
                    Visit Store <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3.5. Wise Super-App 4-in-1 Lifestyle Services Ecosystem */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-orange-500 to-indigo-600 text-white px-2.5 py-0.5 rounded-full shadow-xs">
                Wise Super-App Ecosystem
              </span>
              <span className="text-xs text-slate-500 font-semibold hidden sm:inline">
                Food • Entertainment • VIP Pass • Card Rewards
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
              One App for Everything You Need
            </h2>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: WiseBites Food Delivery */}
          <div
            onClick={() => setIsFoodDeliveryModalOpen(true)}
            className="group relative overflow-hidden rounded-3xl p-5 bg-gradient-to-br from-orange-500 to-amber-600 text-white shadow-lg cursor-pointer hover:shadow-orange-500/30 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between h-56"
          >
            <div className="space-y-1.5 z-10">
              <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center">
                <UtensilsCrossed className="w-5 h-5 text-white" />
              </div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-full inline-block">
                ⚡ 25 Min Delivery
              </span>
              <h3 className="text-lg font-black leading-tight">
                WiseBites Food Delivery
              </h3>
              <p className="text-xs text-orange-100 line-clamp-2">
                Order hot biryani, burgers, pizzas & North Indian feasts from top cloud kitchens.
              </p>
            </div>
            <div className="flex items-center justify-between z-10 pt-2 border-t border-white/20">
              <span className="text-xs font-bold text-amber-200">50% Off First 3 Orders</span>
              <span className="text-xs font-black bg-white text-orange-600 px-2.5 py-1 rounded-xl group-hover:scale-105 transition-transform flex items-center gap-1">
                Order Now <ArrowRight className="w-3 h-3" />
              </span>
            </div>
            <div className="absolute -right-6 -bottom-6 w-28 h-28 bg-white/10 rounded-full blur-xl pointer-events-none" />
          </div>

          {/* Card 2: WiseOne VIP All-in-One Subscription */}
          <div
            onClick={() => setIsWiseOneModalOpen(true)}
            className="group relative overflow-hidden rounded-3xl p-5 bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950 text-white border border-amber-500/30 shadow-lg cursor-pointer hover:shadow-amber-500/20 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between h-56"
          >
            <div className="space-y-1.5 z-10">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center">
                <Crown className="w-5 h-5 fill-amber-400" />
              </div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded-full inline-block">
                👑 All-in-One VIP Pass
              </span>
              <h3 className="text-lg font-black leading-tight text-amber-300">
                WiseOne Membership
              </h3>
              <p className="text-xs text-slate-300 line-clamp-2">
                Free Express Delivery, unlimited OTT stream, 0₹ food delivery fee & 2X coins.
              </p>
            </div>
            <div className="flex items-center justify-between z-10 pt-2 border-t border-slate-800">
              <span className="text-xs font-bold text-amber-400">Plans from ₹149/mo</span>
              <span className="text-xs font-black bg-gradient-to-r from-amber-400 to-amber-500 text-slate-800 px-2.5 py-1 rounded-xl group-hover:scale-105 transition-transform flex items-center gap-1">
                {wiseOneSubscription.isActive ? 'Active VIP' : 'Join VIP'} <ArrowRight className="w-3 h-3" />
              </span>
            </div>
            <div className="absolute -right-6 -bottom-6 w-28 h-28 bg-amber-500/10 rounded-full blur-xl pointer-events-none" />
          </div>

          {/* Card 3: All Bank Credit Cards & EMI Hub */}
          <div
            onClick={() => setIsBankOffersModalOpen(true)}
            className="group relative overflow-hidden rounded-3xl p-5 bg-gradient-to-br from-sky-600 via-blue-700 to-indigo-800 text-white shadow-lg cursor-pointer hover:shadow-sky-500/30 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between h-56"
          >
            <div className="space-y-1.5 z-10">
              <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-white" />
              </div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-full inline-block">
                💳 All Indian Banks
              </span>
              <h3 className="text-lg font-black leading-tight">
                Bank Offers & 0% EMI
              </h3>
              <p className="text-xs text-sky-100 line-clamp-2">
                Instant 10% Off with HDFC, ICICI, SBI, Axis, Kotak, BOB, & Federal bank cards.
              </p>
            </div>
            <div className="flex items-center justify-between z-10 pt-2 border-t border-white/20">
              <span className="text-xs font-bold text-sky-200">No-Cost EMI up to 12m</span>
              <span className="text-xs font-black bg-white text-sky-700 px-2.5 py-1 rounded-xl group-hover:scale-105 transition-transform flex items-center gap-1">
                View Cards <ArrowRight className="w-3 h-3" />
              </span>
            </div>
            <div className="absolute -right-6 -bottom-6 w-28 h-28 bg-sky-400/20 rounded-full blur-xl pointer-events-none" />
          </div>

          {/* Card 4: WiseStream OTT Platform */}
          <div
            onClick={() => setIsOTTModalOpen(true)}
            className="group relative overflow-hidden rounded-3xl p-5 bg-gradient-to-br from-purple-700 via-pink-600 to-rose-700 text-white shadow-lg cursor-pointer hover:shadow-pink-500/30 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between h-56"
          >
            <div className="space-y-1.5 z-10">
              <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center">
                <Tv className="w-5 h-5 text-white" />
              </div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-full inline-block">
                🎬 WiseStream OTT Hub
              </span>
              <h3 className="text-lg font-black leading-tight">
                Movies, Shows & Live Sports
              </h3>
              <p className="text-xs text-pink-100 line-clamp-2">
                Watch 4K blockbusters, web originals, live cricket T20 streaming & anime series.
              </p>
            </div>
            <div className="flex items-center justify-between z-10 pt-2 border-t border-white/20">
              <span className="text-xs font-bold text-pink-200">Free with WiseOne</span>
              <span className="text-xs font-black bg-white text-pink-700 px-2.5 py-1 rounded-xl group-hover:scale-105 transition-transform flex items-center gap-1">
                Watch Now <ArrowRight className="w-3 h-3" />
              </span>
            </div>
            <div className="absolute -right-6 -bottom-6 w-28 h-28 bg-pink-400/20 rounded-full blur-xl pointer-events-none" />
          </div>
        </div>
      </section>

      {/* 4. JustAway Spontaneous Escapes & WanderKits Showcase */}
      <section className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-amber-950 via-slate-950 to-orange-950 text-white border border-amber-500/40 shadow-2xl relative overflow-hidden space-y-6">
        {/* Background Ambient Glow */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-amber-500/20 via-orange-500/15 to-transparent rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-400 to-orange-500 text-slate-800 text-[10px] font-black tracking-wider uppercase shadow-xs">
                🧭 JUSTAWAY TRAVEL & NOMAD ENGINE
              </span>
              <span className="text-xs text-amber-300 font-bold flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                {driftMilesBalance.toLocaleString()} DriftMiles™ Available
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2">
              Just<span className="text-amber-400">Away</span>
              <span className="text-base sm:text-xl font-medium text-slate-300 italic font-serif">
                — "Just go. Just away."
              </span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl font-medium">
              Escape the ordinary. 1-Tap spontaneous weekend getaways & ₹0 3-day doorstep try-before-you-fly WanderKits.
            </p>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            <button
              onClick={() => setAwayModeActive(!awayModeActive)}
              className={`px-4 py-2.5 rounded-2xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer ${
                awayModeActive
                  ? 'bg-amber-400 text-slate-800 shadow-lg shadow-amber-400/30'
                  : 'bg-white/10 text-white hover:bg-white/20 border border-white/20'
              }`}
            >
              <Compass className={`w-4 h-4 ${awayModeActive ? 'animate-spin' : ''}`} />
              <span>{awayModeActive ? 'Away Mode: ACTIVE' : 'Turn On Away Mode'}</span>
            </button>

            <button
              onClick={() => setIsJustAwayHubOpen(true)}
              className="px-5 py-2.5 rounded-2xl text-xs font-black bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-slate-800 shadow-xl shadow-orange-500/25 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <span>Explore JustAway Hub</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 1-Tap Spontaneous Escapes Grid */}
        <div className="relative z-10 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <Mountain className="w-4 h-4" />
              <span>⚡ 1-Tap Spontaneous Escapes (1h–6h Drive)</span>
            </h3>
            <span className="text-[11px] text-slate-400 font-semibold">100% Free Cancellation • No Hidden Fees</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {JUSTAWAY_ESCAPES.slice(0, 4).map((escape) => (
              <div
                key={escape.id}
                onClick={() => setIsJustAwayHubOpen(true)}
                className="group cursor-pointer rounded-2xl overflow-hidden bg-slate-900/90 border border-slate-800 hover:border-amber-500/60 shadow-lg hover:shadow-2xl hover:-translate-y-1 transition-all flex flex-col justify-between"
              >
                <div className="relative h-44 overflow-hidden">
                  <img
                    src={escape.imageUrl}
                    alt={escape.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />
                  <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded-full bg-white/80 backdrop-blur-md text-[10px] font-black text-amber-300 border border-amber-500/40">
                      {escape.driveTimeHours}
                    </span>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500 text-slate-800 text-[10px] font-black">
                      +{escape.driftMilesEarn} DriftMiles
                    </span>
                  </div>
                  <div className="absolute bottom-2.5 left-2.5 right-2.5">
                    <p className="text-[10px] font-bold text-amber-300 flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {escape.destination}
                    </p>
                  </div>
                </div>

                <div className="p-3.5 space-y-2 flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="font-bold text-xs text-white group-hover:text-amber-400 transition-colors line-clamp-1">
                      {escape.title}
                    </h4>
                    <p className="text-[11px] text-slate-400 line-clamp-2 mt-0.5 leading-relaxed font-normal">
                      {escape.tagline}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Nightly Stay</span>
                      <span className="font-black text-xs text-amber-400">₹{escape.pricePerNightINR.toLocaleString()}</span>
                    </div>
                    <span className="px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 group-hover:bg-amber-400 group-hover:text-slate-800 text-[10px] font-black transition-colors flex items-center gap-1">
                      Instant Book <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* WanderKits Try-Before-You-Fly Locker Row */}
        <div className="relative z-10 space-y-3 pt-2 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <Luggage className="w-4 h-4" />
              <span>🎒 WanderKits™ — 3-Day ₹0 Doorstep Trial</span>
            </h3>
            <span className="text-[11px] text-emerald-400 font-bold">Try for 3 days before any trip</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {JUSTAWAY_GEAR_KITS.slice(0, 3).map((kit) => (
              <div
                key={kit.id}
                onClick={() => setIsJustAwayHubOpen(true)}
                className="group cursor-pointer p-3 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-amber-500/50 transition-all flex items-center gap-3"
              >
                <img
                  src={kit.imageUrl}
                  alt={kit.name}
                  className="w-16 h-16 rounded-xl object-cover flex-shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <span className="text-[9px] font-black text-amber-400 uppercase tracking-wider">{kit.badge}</span>
                  <h5 className="text-xs font-bold text-white truncate group-hover:text-amber-300 transition-colors">
                    {kit.name}
                  </h5>
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-[10px] text-slate-400">Rent ₹{kit.rentalDailyINR}/day</span>
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded-md border border-emerald-700/50">
                      ₹0 Trial
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. WiseSquad Community Group Buy Deals */}
      <section className="p-6 sm:p-8 bg-gradient-to-br from-rose-50 via-pink-50 to-amber-50 dark:from-rose-950/30 dark:to-slate-900 rounded-3xl border border-rose-200 dark:border-rose-900/40 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-rose-600 text-white flex items-center justify-center shadow-lg">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-rose-600 text-white px-2 py-0.5 rounded-full">
                  WiseSquad Group Buy
                </span>
                <span className="text-xs text-rose-700 dark:text-rose-300 font-bold">2-Person Buying Teams</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-stone-900 dark:text-white">
                Team Up with Shoppers & Unlock Wholesale Discounts
              </h3>
            </div>
          </div>

          <button
            onClick={() => setIsGroupBuyModalOpen(true)}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition self-start sm:self-auto"
          >
            View All Open Teams
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {groupBuyDeals.map((deal) => (
            <div
              key={deal.id}
              className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-rose-200 dark:border-slate-700 shadow-sm flex flex-col justify-between space-y-3"
            >
              <div className="flex gap-3">
                <img
                  src={deal.productImage}
                  alt={deal.productName}
                  className="w-16 h-16 rounded-xl object-cover flex-shrink-0"
                />
                <div className="min-w-0">
                  <span className="text-[10px] font-extrabold text-rose-600 uppercase">{deal.groupCode}</span>
                  <h4 className="font-bold text-xs text-stone-900 dark:text-white truncate mt-0.5">
                    {deal.productName}
                  </h4>
                  <div className="flex items-baseline gap-1.5 mt-1">
                    <span className="font-black text-sm text-rose-600">{formatPrice(deal.groupPrice)}</span>
                    <span className="text-xs text-stone-400 line-through">{formatPrice(deal.originalPrice)}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-stone-100 dark:border-slate-700 text-xs">
                <span className="font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded">
                  Save {formatPrice(deal.savings)}
                </span>
                <button
                  onClick={() => joinGroupBuy(deal.id)}
                  className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs shadow-sm transition"
                >
                  Join Team
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 2. Categories Circular Visual Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white">
              Shop by Department
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">Explore our artisan curated categories</p>
          </div>
          <button
            onClick={onViewCatalog}
            className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 sm:gap-4">
          {categories.map((cat) => (
            <div
              key={cat.id}
              onClick={() => onSelectCategory(cat.slug)}
              className="group cursor-pointer p-3 sm:p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 hover:border-amber-500 hover:shadow-xl transition-all flex flex-col items-center text-center"
            >
              <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden mb-3 group-hover:scale-105 transition-transform">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white group-hover:text-amber-600 transition-colors">
                {cat.name}
              </h3>
              <p className="text-[10px] text-slate-500 mt-0.5">{cat.itemCount}+ Products</p>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Flash Sale / Deals of the Day with Live Countdown */}
      <section className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-amber-500/10 via-orange-500/5 to-rose-500/10 border border-amber-500/30 space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 text-slate-800 flex items-center justify-center font-black">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
                  Limited Flash Deals
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-rose-600 text-white font-black text-[10px] uppercase animate-pulse">
                  Up to 45% Off
                </span>
              </div>
              <p className="text-xs text-slate-500">Handcrafted pieces at unbeatable festival prices</p>
            </div>
          </div>

          {/* Countdown Clock */}
          <div className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-2xl font-mono text-xs shadow-md">
            <Clock className="w-4 h-4 text-amber-400 animate-spin" />
            <span className="font-semibold text-slate-300">Ends in:</span>
            <span className="bg-slate-800 px-2 py-1 rounded font-bold text-amber-400">
              {String(timeLeft.hours).padStart(2, '0')}h
            </span>
            <span>:</span>
            <span className="bg-slate-800 px-2 py-1 rounded font-bold text-amber-400">
              {String(timeLeft.minutes).padStart(2, '0')}m
            </span>
            <span>:</span>
            <span className="bg-slate-800 px-2 py-1 rounded font-bold text-amber-400">
              {String(timeLeft.seconds).padStart(2, '0')}s
            </span>
          </div>
        </div>

        {/* Product Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {flashSaleProducts.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* 4. Trending & Best-Selling Spotlight */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-amber-500" />
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Trending Modern Indian Wear
            </h2>
          </div>
          <button
            onClick={onViewCatalog}
            className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1"
          >
            <span>Explore All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {trendingProducts.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* 5. WiseAI Stylist Interactive Banner */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950 text-white p-6 sm:p-10 border border-slate-800 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-3 max-w-xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold border border-amber-500/30">
            <Sparkles className="w-3.5 h-3.5 animate-spin" />
            <span>Powered by Gemini 3.7 Flash</span>
          </div>
          <h3 className="text-2xl sm:text-3xl font-extrabold">
            Can't decide what to wear for Diwali, Weddings or Work?
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Chat with <strong>WiseAI Stylist</strong>. Ask in English, Hindi, or Hinglish ("Kurta for sangeet under 2500"), and get tailored product pairings instantly.
          </p>
          <div className="pt-2">
            <button
              onClick={() => setIsWiseAIOpen(true)}
              className="bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold px-6 py-3 rounded-xl text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-amber-500/20"
            >
              <Sparkles className="w-4 h-4" />
              <span>Launch WiseAI Assistant</span>
            </button>
          </div>
        </div>

        <div className="w-full md:w-72 bg-slate-800/80 backdrop-blur-md rounded-2xl p-4 border border-slate-700 space-y-2 text-xs">
          <div className="flex items-center gap-2 text-amber-400 font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Sample Prompts</span>
          </div>
          <div
            onClick={() => setIsWiseAIOpen(true)}
            className="p-2.5 bg-slate-900/80 rounded-xl cursor-pointer hover:bg-slate-900 text-slate-300 border border-slate-700"
          >
            💬 "Show me beige linen shirts for summer under ₹2,000"
          </div>
          <div
            onClick={() => setIsWiseAIOpen(true)}
            className="p-2.5 bg-slate-900/80 rounded-xl cursor-pointer hover:bg-slate-900 text-slate-300 border border-slate-700"
          >
            💬 "Wedding footwear that matches my silk Nehru jacket"
          </div>
        </div>
      </section>

      {/* 6. New Arrivals Collection */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-500" />
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Fresh New Arrivals
            </h2>
          </div>
          <button
            onClick={onViewCatalog}
            className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {newArrivals.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* 7. Customer Reviews & Community Trust */}
      <section className="p-6 sm:p-8 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-6">
        <div className="text-center max-w-xl mx-auto space-y-1">
          <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
            Loved by 45,000+ Patrons Across India
          </h3>
          <p className="text-xs text-slate-500">
            Real verified reviews from Mumbai, Delhi, Bengaluru, Pune, and Jaipur.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
            <div className="flex items-center gap-1 text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400" />
              ))}
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 italic">
              "The linen quality is unmatched at this price point. Breathable, perfectly stitched, and got delivered to Bangalore within 48 hours."
            </p>
            <div className="pt-2 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-900 dark:text-white">Rohan Deshmukh</span>
              <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1">
                <CheckCircle className="w-3 h-3" /> Verified Buyer
              </span>
            </div>
          </div>

          <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
            <div className="flex items-center gap-1 text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400" />
              ))}
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 italic">
              "WiseAI helped me choose the exact matching mojari footwear for my sangeet kurta. Super accurate sizing chart too!"
            </p>
            <div className="pt-2 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-900 dark:text-white">Pooja Singhania</span>
              <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1">
                <CheckCircle className="w-3 h-3" /> Verified Buyer
              </span>
            </div>
          </div>

          <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
            <div className="flex items-center gap-1 text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400" />
              ))}
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 italic">
              "Seamless exchange when I needed one size larger. Courier picked it up right from my doorstep in Gurgaon without questions."
            </p>
            <div className="pt-2 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-900 dark:text-white">Vikramaditya S.</span>
              <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1">
                <CheckCircle className="w-3 h-3" /> Verified Buyer
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* 8. App Download Banner Simulation */}
      <section className="p-6 sm:p-8 rounded-3xl bg-slate-900 text-white flex flex-col sm:flex-row items-center justify-between gap-6 border border-slate-800 shadow-xl">
        <div className="space-y-2 max-w-md">
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
            <Smartphone className="w-4 h-4" />
            <span>Omnichannel Mobile Experience</span>
          </div>
          <h3 className="text-2xl font-extrabold">Shop Smarter with Antifly App</h3>
          <p className="text-xs text-slate-300">
            Get exclusive app-only coupons (e.g. <strong>APPEXCLUSIVE15</strong>), real-time push notifications, and visual camera search on Android & iOS.
          </p>
        </div>

        <div className="flex flex-wrap gap-3">
          <button
            onClick={() => setDeviceMode('mobile-android')}
            className="bg-white/10 hover:bg-white/20 border border-white/20 px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all"
          >
            <span>📱 Preview Android App</span>
          </button>
          <button
            onClick={() => setDeviceMode('mobile-ios')}
            className="bg-amber-500 hover:bg-amber-400 text-slate-800 px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all"
          >
            <span>🍏 Preview iOS App</span>
          </button>
        </div>
      </section>
    </div>
  );
};
