import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Search,
  Mic,
  Camera,
  Heart,
  MessageCircle,
  Share2,
  Sparkles,
  ShoppingBag,
  Tag,
  Star,
  Flame,
  TrendingUp,
  SlidersHorizontal,
  Play,
  Store,
  Tv,
  UtensilsCrossed,
  CheckCircle2,
  Gem,
  QrCode,
  RotateCcw,
  Film,
  Layers,
} from 'lucide-react';
import { DirectSellerPaymentModal } from '../common/DirectSellerPaymentModal';
import { Product, SellerProfile } from '../../types';

export const WebsiteInstagramSearch: React.FC = () => {
  const {
    products,
    categories,
    sellers,
    restaurants,
    addToCart,
    toggleWishlist,
    wishlist,
    setActivePdpId,
    setIsVoiceSearchOpen,
    setIsImageSearchOpen,
    shortVideoReels,
    openReelPlayer,
    openStoreChat,
    setIsOTTModalOpen,
    setIsFoodDeliveryModalOpen,
    showToast,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'all' | 'products' | 'stores' | 'ott' | 'food' | 'reels'>('all');
  const [selectedTag, setSelectedTag] = useState<string>('all');

  // Direct QR Modal
  const [selectedSellerForQR, setSelectedSellerForQR] = useState<SellerProfile | null>(null);
  const [isQRModalOpen, setIsQRModalOpen] = useState(false);

  const hashtags = [
    { tag: 'all', label: '✨ All Explore' },
    { tag: '#TrendingIndore', label: '🔥 #TrendingIndore' },
    { tag: '#NamkeenAndSweets', label: '🥨 #Namkeen' },
    { tag: '#SilkSarees', label: '🥻 #SilkSarees' },
    { tag: '#LiveCricketOTT', label: '🏏 #OTTStreaming' },
    { tag: '#ChappanFood', label: '🍲 #FoodDelivery' },
    { tag: '#KiranaStores', label: '🌾 #Kirana' },
  ];

  // OTT Data for Search
  const ottList = [
    { id: 'ott-1', name: 'Disney+ Hotstar VIP', genre: 'Live IPL & World Cup Cricket, Marvel, Bollywood', icon: '🎬', category: 'OTT Streaming' },
    { id: 'ott-2', name: 'SonyLIV Premium', genre: 'Sony Live Sports, MasterChef, Hindi Originals', icon: '📺', category: 'OTT Streaming' },
    { id: 'ott-3', name: 'Zee5 All-Access Pass', genre: 'Regional Blockbusters, Hindi TV Shows', icon: '🍿', category: 'OTT Streaming' },
    { id: 'ott-4', name: 'Amazon Prime Video Hub', genre: 'Global Movies, 1-Day Express Delivery Free', icon: '📦', category: 'OTT Streaming' },
    { id: 'ott-5', name: 'Netflix Mobile Hub Pass', genre: 'Global Series, Documentaries & 4K HDR', icon: '🎥', category: 'OTT Streaming' },
  ];

  // Search Match Filtering across all entities
  const q = searchQuery.toLowerCase().trim();

  const matchedProducts = products.filter((p) =>
    !q ||
    p.name.toLowerCase().includes(q) ||
    p.description?.toLowerCase().includes(q) ||
    p.tags?.some((t) => t.toLowerCase().includes(q)) ||
    p.brand?.toLowerCase().includes(q)
  );

  const matchedSellers = sellers.filter((s) =>
    !q ||
    s.storeName.toLowerCase().includes(q) ||
    s.city?.toLowerCase().includes(q) ||
    s.locality?.toLowerCase().includes(q) ||
    s.description?.toLowerCase().includes(q) ||
    s.category?.toLowerCase().includes(q)
  );

  const matchedOTT = ottList.filter((o) =>
    !q ||
    o.name.toLowerCase().includes(q) ||
    o.genre.toLowerCase().includes(q)
  );

  const matchedRestaurants = restaurants.filter((r) =>
    !q ||
    r.name.toLowerCase().includes(q) ||
    r.cuisine?.some((c) => c.toLowerCase().includes(q)) ||
    r.address?.toLowerCase().includes(q)
  );

  const matchedReels = shortVideoReels.filter((r) =>
    !q ||
    r.title.toLowerCase().includes(q) ||
    r.storeName.toLowerCase().includes(q)
  );

  return (
    <div id="website-instagram-search-page" className="w-full bg-white text-slate-900 min-h-[85vh]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
        
        {/* Universal Search Header */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs max-w-3xl mx-auto space-y-4 text-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-50 text-red-700 text-xs font-black border border-red-200">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Universal Vice-Versa Search & Reels</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900">
            Search Products, Businesses, OTT & Food
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 font-medium max-w-xl mx-auto">
            Search anything vice-versa — from local sarees & electronics to business store profiles, OTT streaming, cloud kitchen food, and 5-sec product reels.
          </p>

          {/* Large Search Input */}
          <div className="relative flex items-center shadow-xs text-left">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products, stores, Hotstar OTT, food, sarees, reels..."
              className="w-full pl-11 pr-24 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition-all"
            />
            <Search className="w-5 h-5 text-slate-400 absolute left-3.5" />

            <div className="absolute right-2.5 flex items-center gap-1.5">
              <button
                onClick={() => setIsVoiceSearchOpen(true)}
                className="p-2 rounded-xl bg-slate-200 hover:bg-red-100 hover:text-red-600 text-slate-700 transition cursor-pointer"
                title="Voice Search"
              >
                <Mic className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsImageSearchOpen(true)}
                className="p-2 rounded-xl bg-slate-200 hover:bg-red-100 hover:text-red-600 text-slate-700 transition cursor-pointer"
                title="Visual Search by Camera"
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Trending Hashtags */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none justify-start sm:justify-center">
            {hashtags.map((h) => (
              <button
                key={h.tag}
                onClick={() => {
                  setSelectedTag(h.tag);
                  if (h.tag !== 'all') {
                    setSearchQuery(h.tag.replace('#', ''));
                  } else {
                    setSearchQuery('');
                  }
                }}
                className={`px-3 py-1 rounded-xl text-xs font-black whitespace-nowrap transition cursor-pointer ${
                  selectedTag === h.tag
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {h.label}
              </button>
            ))}
          </div>
        </div>

        {/* Universal Search Results Navigation Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 border-b border-slate-200 scrollbar-none">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-4 py-2 rounded-2xl text-xs font-black transition cursor-pointer whitespace-nowrap ${
              activeTab === 'all'
                ? 'bg-red-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            All Results
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`px-4 py-2 rounded-2xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'products'
                ? 'bg-red-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Products ({matchedProducts.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('stores')}
            className={`px-4 py-2 rounded-2xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'stores'
                ? 'bg-red-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Store className="w-3.5 h-3.5" />
            <span>Ventures & Businesses ({matchedSellers.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('ott')}
            className={`px-4 py-2 rounded-2xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'ott'
                ? 'bg-red-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Tv className="w-3.5 h-3.5" />
            <span>OTT Entertainment ({matchedOTT.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('food')}
            className={`px-4 py-2 rounded-2xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'food'
                ? 'bg-red-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <UtensilsCrossed className="w-3.5 h-3.5" />
            <span>Food Deliveries ({matchedRestaurants.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('reels')}
            className={`px-4 py-2 rounded-2xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'reels'
                ? 'bg-red-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            <span>5-Sec Reels ({matchedReels.length})</span>
          </button>
        </div>

        {/* 5-SECOND SHORT REELS SECTION */}
        {(activeTab === 'all' || activeTab === 'reels') && matchedReels.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-red-600" />
                <span>Trending Store Product Reels (5s Video)</span>
              </h2>
              <span className="text-xs font-bold text-red-600">Tap to watch with sound</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
              {matchedReels.map((reel) => (
                <div
                  key={reel.id}
                  onClick={() => openReelPlayer(reel)}
                  className="relative aspect-[9/16] rounded-2xl overflow-hidden bg-slate-900 group cursor-pointer shadow-xs hover:shadow-md transition-transform hover:scale-[1.02]"
                >
                  <img
                    src={reel.thumbnailUrl}
                    alt={reel.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-100/80 via-transparent to-transparent flex flex-col justify-end p-3 text-white">
                    <div className="flex items-center gap-1 text-[10px] font-bold text-amber-300">
                      <Play className="w-3 h-3 fill-amber-300" />
                      <span>{reel.viewsCount}</span>
                    </div>
                    <p className="font-extrabold text-xs line-clamp-1 text-white">{reel.title}</p>
                    <p className="text-[10px] text-slate-300 font-semibold">{reel.storeName}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SECTION 1: MATCHED BUSINESSES & STORE PROFILES */}
        {(activeTab === 'all' || activeTab === 'stores') && matchedSellers.length > 0 && (
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Store className="w-4 h-4 text-red-600" />
                <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider">
                  Venture Profiles & Business Information
                </h2>
              </div>
              <span className="text-xs font-bold text-slate-500">
                {matchedSellers.length} Ventures Found
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
              {matchedSellers.map((seller) => (
                <div
                  key={seller.id}
                  className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex flex-col justify-between space-y-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-xl bg-red-100 text-red-600 flex items-center justify-center font-black text-sm border border-red-200 flex-shrink-0">
                        {seller.storeName.charAt(0)}
                      </div>
                      <div>
                        <div className="flex items-center gap-1">
                          <h4 className="font-black text-xs text-slate-900">{seller.storeName}</h4>
                          <CheckCircle2 className="w-3 h-3 text-blue-600 fill-blue-50" />
                        </div>
                        <p className="text-[10px] text-slate-500 font-semibold">
                          📍 {seller.locality || seller.city || 'Indore'} &bull; ⭐ {seller.rating || 4.8}
                        </p>
                      </div>
                    </div>

                    <span className="text-[10px] font-black px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                      7-Day Exchange
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-200/80">
                    <button
                      onClick={() => {
                        setSelectedSellerForQR(seller);
                        setIsQRModalOpen(true);
                      }}
                      className="py-1.5 px-2 bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 rounded-xl text-xs font-black flex items-center justify-center gap-1 transition cursor-pointer"
                    >
                      <QrCode className="w-3.5 h-3.5 text-red-600" />
                      <span>Direct Pay QR</span>
                    </button>

                    <button
                      onClick={() => openStoreChat(seller.id)}
                      className="py-1.5 px-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1 transition cursor-pointer shadow-xs"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>Direct Chat</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SECTION 2: MATCHED PRODUCTS */}
        {(activeTab === 'all' || activeTab === 'products') && matchedProducts.length > 0 && (
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-red-600" />
                <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider">
                  Product Catalog Results
                </h2>
              </div>
              <span className="text-xs font-bold text-slate-500">
                {matchedProducts.length} Items Found
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {matchedProducts.map((product) => (
                <div
                  key={product.id}
                  className="p-3 bg-slate-50 border border-slate-200 rounded-2xl flex flex-col justify-between space-y-2 group hover:border-slate-300 transition-all"
                >
                  <div
                    onClick={() => setActivePdpId(product.id)}
                    className="relative aspect-square rounded-xl overflow-hidden bg-white border border-slate-200 cursor-pointer"
                  >
                    <img
                      src={product.images?.[0] || 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=300'}
                      alt={product.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleWishlist(product.id);
                      }}
                      className="absolute top-2 right-2 p-1.5 rounded-full bg-white/90 shadow-sm text-slate-600 hover:text-rose-500 cursor-pointer"
                    >
                      <Heart className={`w-3.5 h-3.5 ${wishlist.includes(product.id) ? 'fill-rose-500 text-rose-500' : ''}`} />
                    </button>
                  </div>

                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900 line-clamp-1">{product.name}</h4>
                    <p className="text-[10px] text-slate-500 font-semibold">{product.brand}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs font-black text-slate-900">₹{product.price}</span>
                      {product.mrp && <span className="text-[10px] text-slate-400 line-through">₹{product.mrp}</span>}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      addToCart(product, product.variants?.[0]?.id || 'v-1');
                      showToast(`Added ${product.name} to Cart`);
                    }}
                    className="w-full py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black shadow-xs transition cursor-pointer"
                  >
                    Add to Cart
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SECTION 3: MATCHED OTT ENTERTAINMENT */}
        {(activeTab === 'all' || activeTab === 'ott') && matchedOTT.length > 0 && (
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Tv className="w-4 h-4 text-indigo-600" />
                <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider">
                  OTT Entertainment & Live Cricket
                </h2>
              </div>
              <button
                onClick={() => setIsOTTModalOpen(true)}
                className="text-xs text-indigo-600 hover:text-indigo-800 font-bold cursor-pointer"
              >
                Open OTT Theater →
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {matchedOTT.map((ott) => (
                <div
                  key={ott.id}
                  className="p-4 bg-indigo-50/50 border border-indigo-200 rounded-2xl flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{ott.icon}</span>
                    <div>
                      <h4 className="font-black text-xs text-indigo-950">{ott.name}</h4>
                      <p className="text-[10px] text-indigo-800/80 font-medium">{ott.genre}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => setIsOTTModalOpen(true)}
                    className="px-3 py-1.5 bg-indigo-600 text-white text-xs font-black rounded-xl hover:bg-indigo-700 transition cursor-pointer"
                  >
                    Watch
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SECTION 4: MATCHED FOOD DELIVERIES */}
        {(activeTab === 'all' || activeTab === 'food') && matchedRestaurants.length > 0 && (
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <UtensilsCrossed className="w-4 h-4 text-orange-600" />
                <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider">
                  Food Deliveries & Cloud Kitchens
                </h2>
              </div>
              <button
                onClick={() => setIsFoodDeliveryModalOpen(true)}
                className="text-xs text-orange-600 hover:text-orange-800 font-bold cursor-pointer"
              >
                Open Food Delivery Hub →
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {matchedRestaurants.map((res) => (
                <div
                  key={res.id}
                  className="p-4 bg-orange-50/50 border border-orange-200 rounded-2xl flex items-center justify-between gap-3"
                >
                  <div>
                    <h4 className="font-black text-xs text-orange-950">{res.name}</h4>
                    <p className="text-[10px] text-orange-800/80 font-medium">
                      {res.cuisine?.join(', ')} &bull; ⏱️ 20–30 mins
                    </p>
                  </div>

                  <button
                    onClick={() => setIsFoodDeliveryModalOpen(true)}
                    className="px-3 py-1.5 bg-orange-600 text-white text-xs font-black rounded-xl hover:bg-orange-700 transition cursor-pointer"
                  >
                    Order Food
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Direct Seller Payment QR Modal */}
      <DirectSellerPaymentModal
        seller={selectedSellerForQR}
        isOpen={isQRModalOpen}
        onClose={() => setIsQRModalOpen(false)}
      />
    </div>
  );
};
