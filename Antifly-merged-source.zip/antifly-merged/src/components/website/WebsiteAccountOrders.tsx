import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../common/ProductCard';
import {
  User,
  Package,
  Heart,
  MapPin,
  Clock,
  Truck,
  RotateCcw,
  FileText,
  CheckCircle,
  AlertCircle,
  ArrowRight,
  ShieldCheck,
  ShoppingBag,
  Coins,
  Gift,
  Power,
  Trash2,
  Phone,
  Navigation,
  KeyRound,
  Edit2,
  Sparkles,
} from 'lucide-react';
import { Order } from '../../types';

export const WebsiteAccountOrders: React.FC = () => {
  const {
    currentCustomer,
    orders,
    products,
    wishlist,
    setActiveTrackingOrder,
    addToCart,
    showToast,
    settings,
    drivers,
    userProfile,
    updateUserProfile,
    toggleUserStatus,
    deleteUserAccount,
    deleteCustomerAccountPermanently,
    openAuthModalFor,
    superCoinsBalance,
    claimUserWelcomeBonus,
    userLocation,
    setUserLocation,
    openLiveMapForOrder,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'orders' | 'wishlist' | 'addresses' | 'account-settings'>('orders');
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [profileName, setProfileName] = useState(userProfile.name || currentCustomer.name);
  const [profilePhone, setProfilePhone] = useState(userProfile.phone || currentCustomer.phone);
  const [selectedCity, setSelectedCity] = useState(userLocation.city || 'Indore');

  // Customer's orders
  const customerOrders = orders.filter(
    (o) => o.customerId === currentCustomer.id || o.customerEmail === currentCustomer.email
  );

  // Customer's wishlist products
  const wishlistProducts = products.filter((p) => wishlist.includes(p.id));

  const handleSaveProfile = () => {
    updateUserProfile({
      name: profileName,
      phone: profilePhone,
      city: selectedCity,
    });
    setUserLocation({
      ...userLocation,
      city: selectedCity,
    });
    setIsEditingProfile(false);
    showToast('Profile & City updated successfully!');
  };

  const handlePrintInvoice = (order: Order) => {
    showToast(`Generating GST Tax Invoice for Order #${order.orderNumber}...`);
    const invoiceWindow = window.open('', '_blank');
    if (invoiceWindow) {
      invoiceWindow.document.write(`
        <html>
          <head>
            <title>Tax Invoice - ${order.orderNumber}</title>
            <style>
              body { font-family: sans-serif; padding: 24px; color: #1e293b; }
              .header { display: flex; justify-content: space-between; border-bottom: 2px solid #e2e8f0; padding-bottom: 16px; margin-bottom: 20px; }
              .table { width: 100%; border-collapse: collapse; margin-top: 20px; }
              .table th, .table td { border: 1px solid #cbd5e1; padding: 8px 12px; text-align: left; font-size: 12px; }
              .table th { background: #f8fafc; }
              .totals { margin-top: 20px; text-align: right; font-size: 13px; }
            </style>
          </head>
          <body>
            <div class="header">
              <div>
                <h2>Antifly Retail Pvt Ltd</h2>
                <p>GSTIN: 27AABCT3421K1ZZ<br/>${order.shippingAddress.city}, India</p>
              </div>
              <div>
                <h3>TAX INVOICE</h3>
                <p><strong>Invoice No:</strong> INV-${order.orderNumber}<br/><strong>Date:</strong> ${new Date(order.createdAt).toLocaleDateString('en-IN')}<br/><strong>Order Source:</strong> ${order.source}</p>
              </div>
            </div>
            <div>
              <strong>Billed To:</strong><br/>
              ${order.shippingAddress.fullName}<br/>
              ${order.shippingAddress.street}, ${order.shippingAddress.city}, ${order.shippingAddress.state} - ${order.shippingAddress.pincode}<br/>
              Phone: ${order.shippingAddress.phone}
            </div>
            <table class="table">
              <thead>
                <tr>
                  <th>Item</th>
                  <th>Size/Color</th>
                  <th>Qty</th>
                  <th>Price</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>
                ${order.items
                  .map(
                    (it) => `
                  <tr>
                    <td>${it.productName}</td>
                    <td>${it.size} / ${it.color}</td>
                    <td>${it.quantity}</td>
                    <td>₹${it.price.toLocaleString('en-IN')}</td>
                    <td>₹${(it.price * it.quantity).toLocaleString('en-IN')}</td>
                  </tr>
                `
                  )
                  .join('')}
              </tbody>
            </table>
            <div class="totals">
              <p>Subtotal: ₹${order.subtotal.toLocaleString('en-IN')}</p>
              ${order.discount ? `<p>Discount: -₹${order.discount.toLocaleString('en-IN')}</p>` : ''}
              <p>Shipping: ₹${order.shippingFee.toLocaleString('en-IN')}</p>
              <p><strong>Grand Total: ₹${order.totalAmount.toLocaleString('en-IN')}</strong></p>
              <p>Payment: ${order.paymentMethod} (${order.paymentStatus})</p>
            </div>
          </body>
        </html>
      `);
      invoiceWindow.document.close();
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Profile Overview Card */}
      <div className="p-6 rounded-3xl bg-slate-900 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border border-slate-800 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-slate-800 font-black text-2xl shadow-lg">
            {userProfile.name ? userProfile.name.charAt(0) : currentCustomer.name.charAt(0)}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-extrabold text-white">
                {userProfile.name || currentCustomer.name}
              </h2>
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                Gold Patron
              </span>
              <span
                className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                  userProfile.isActive
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                }`}
              >
                {userProfile.isActive ? '🟢 Active Customer' : '⏸️ Deactivated'}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {currentCustomer.email} &bull; {userProfile.phone || currentCustomer.phone} &bull; 📍{' '}
              <strong className="text-amber-300">{userLocation.city || 'Indore'}</strong>
            </p>
          </div>
        </div>

        {/* Quick Stats & SuperCoins */}
        <div className="flex flex-wrap items-center gap-6 text-xs border-t md:border-t-0 md:border-l border-slate-800 pt-4 md:pt-0 md:pl-6">
          <div>
            <span className="text-slate-400 block">SuperCoins / Bonus</span>
            <div className="flex items-center gap-1 mt-0.5">
              <Coins className="w-4 h-4 text-amber-400" />
              <span className="text-lg font-extrabold text-amber-400 font-mono">
                ₹{superCoinsBalance}
              </span>
            </div>
          </div>
          <div>
            <span className="text-slate-400 block">Total Orders</span>
            <span className="text-lg font-extrabold text-white font-mono mt-0.5 block">
              {customerOrders.length}
            </span>
          </div>
          <div>
            <span className="text-slate-400 block">Saved Wishlist</span>
            <span className="text-lg font-extrabold text-rose-400 font-mono mt-0.5 block">
              {wishlist.length} Items
            </span>
          </div>
        </div>
      </div>

      {/* Bonus Reward Claim Bar */}
      {!userProfile.hasClaimedBonus && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-amber-500/10 border border-amber-500/40 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-800 flex items-center justify-center font-black">
              <Gift className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-amber-300">
                Claim ₹500 Customer Welcome Bonus Reward
              </h4>
              <p className="text-xs text-amber-200/80">
                Instant SuperCoins credit for booking T-shirts, dresses, and cloths in {userLocation.city || 'Indore'}.
              </p>
            </div>
          </div>
          <button
            onClick={claimUserWelcomeBonus}
            className="px-4 py-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-800 font-bold rounded-xl text-xs transition-all shadow-md"
          >
            Claim ₹500 Now 🎁
          </button>
        </div>
      )}

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('orders')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all whitespace-nowrap ${
            activeTab === 'orders'
              ? 'bg-amber-500 text-slate-800 shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>My Orders & Live Drivers ({customerOrders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('wishlist')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all whitespace-nowrap ${
            activeTab === 'wishlist'
              ? 'bg-amber-500 text-slate-800 shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>Wishlist ({wishlistProducts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('addresses')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all whitespace-nowrap ${
            activeTab === 'addresses'
              ? 'bg-amber-500 text-slate-800 shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <MapPin className="w-4 h-4" />
          <span>Saved Addresses ({currentCustomer?.addresses?.length || 0})</span>
        </button>

        <button
          onClick={() => setActiveTab('account-settings')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all whitespace-nowrap ${
            activeTab === 'account-settings'
              ? 'bg-amber-500 text-slate-800 shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Account Settings & Deactivation</span>
        </button>
      </div>

      {/* Tab Contents */}
      {/* TAB 1: ORDERS & DRIVERS */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          {customerOrders.length === 0 ? (
            <div className="p-12 text-center bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
              <Package className="w-12 h-12 text-slate-400 mx-auto" />
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                No orders placed yet
              </h3>
              <p className="text-xs text-slate-500">
                Explore our catalog to book a T-shirt, dress, or cloth from a nearby Indore or pan-India vendor shop.
              </p>
            </div>
          ) : (
            customerOrders.map((order) => {
              const isDelivered = order.status === 'Delivered';
              const isPending = order.status === 'Pending' || order.status === 'Confirmed';
              const isShipped = order.status === 'Shipped' || order.status === 'Out for delivery';
              const assignedDriver = drivers.find((d) => d.id === order.assignedDriverId);

              return (
                <div
                  key={order.id}
                  className="p-5 sm:p-6 bg-white dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700/80 shadow-sm space-y-4"
                >
                  {/* Order Top Banner */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-700/80 text-xs">
                    <div className="flex items-center gap-3">
                      <span className="font-mono font-bold text-sm text-slate-900 dark:text-white">
                        #{order.orderNumber}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                        {order.source}
                      </span>
                      <span className="text-slate-500">
                        Placed on{' '}
                        {new Date(order.createdAt).toLocaleDateString('en-IN', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </span>
                    </div>

                    {/* Status Badge */}
                    <div className="flex items-center gap-2">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-extrabold ${
                          isDelivered
                            ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/30'
                            : isShipped
                            ? 'bg-blue-500/10 text-blue-600 border border-blue-500/30'
                            : order.status === 'Cancelled'
                            ? 'bg-rose-500/10 text-rose-600 border border-rose-500/30'
                            : 'bg-amber-500/10 text-amber-600 border border-amber-500/30'
                        }`}
                      >
                        ● {order.status}
                      </span>

                      {order.deliveryOtp && !isDelivered && (
                        <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-amber-500 text-slate-800 shadow-sm">
                          Delivery OTP: {order.deliveryOtp}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Assigned Driver Card */}
                  {assignedDriver && (
                    <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 flex flex-wrap items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-3">
                        <img
                          src={assignedDriver.avatar}
                          alt={assignedDriver.name}
                          className="w-10 h-10 rounded-full object-cover border-2 border-emerald-500"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900 dark:text-white text-sm">
                              {assignedDriver.name}
                            </span>
                            <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-600 dark:text-emerald-300">
                              Assigned Delivery Partner
                            </span>
                          </div>
                          <p className="text-slate-600 dark:text-slate-400 text-xs">
                            {assignedDriver.vehicleType} ({assignedDriver.vehicleNumber}) &bull; ⭐ {assignedDriver.rating}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <a
                          href={`tel:${assignedDriver.phone}`}
                          className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg transition-all"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          <span>Call Rider</span>
                        </a>

                        <button
                          onClick={() => openLiveMapForOrder(order)}
                          className="flex items-center gap-1 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg transition-all"
                        >
                          <Navigation className="w-3.5 h-3.5" />
                          <span>Live GPS Track</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Items list */}
                  <div className="space-y-3">
                    {order.items.map((item, i) => (
                      <div key={i} className="flex items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={item.image}
                            alt={item.productName}
                            className="w-14 h-16 object-cover rounded-xl border border-slate-200 dark:border-slate-700 flex-shrink-0"
                          />
                          <div>
                            <span className="text-[10px] uppercase font-bold text-slate-500">
                              {item.brand}
                            </span>
                            <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                              {item.productName}
                            </h4>
                            <p className="text-xs text-slate-500">
                              Size: <strong>{item.size}</strong> &bull; Color: <strong>{item.color}</strong> &bull; Qty:{' '}
                              <strong>{item.quantity}</strong>
                            </p>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="font-bold text-sm text-slate-900 dark:text-white">
                            ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Bottom details & Actions */}
                  <div className="pt-3 border-t border-slate-100 dark:border-slate-700/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs">
                    <div className="text-slate-600 dark:text-slate-400">
                      <span>
                        Delivery to: <strong>{order.shippingAddress.city}, {order.shippingAddress.pincode}</strong>
                      </span>{' '}
                      &bull;{' '}
                      <span>
                        Total Paid: <strong className="text-slate-900 dark:text-white">₹{order.totalAmount.toLocaleString('en-IN')}</strong>
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        onClick={() => handlePrintInvoice(order)}
                        className="bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-800 dark:text-slate-200 font-semibold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Tax Invoice</span>
                      </button>

                      <button
                        onClick={() => setActiveTrackingOrder(order)}
                        className="bg-slate-900 dark:bg-amber-500 hover:bg-slate-800 text-white dark:text-slate-800 font-bold px-3.5 py-1.5 rounded-xl text-xs flex items-center gap-1.5 shadow-sm"
                      >
                        <Truck className="w-3.5 h-3.5" />
                        <span>Track Live Package</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* TAB 2: WISHLIST */}
      {activeTab === 'wishlist' && (
        <div>
          {wishlistProducts.length === 0 ? (
            <div className="p-12 text-center bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
              <Heart className="w-12 h-12 text-slate-400 mx-auto" />
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Your wishlist is empty
              </h3>
              <p className="text-xs text-slate-500">Tap the heart icon on any product to save items.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              {wishlistProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: ADDRESSES */}
      {activeTab === 'addresses' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {currentCustomer.addresses.map((addr) => (
            <div
              key={addr.id}
              className="p-5 bg-white dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700/80 space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                    {addr.fullName}
                  </h4>
                  <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-[10px] font-bold uppercase">
                    {addr.type}
                  </span>
                </div>
                {addr.isDefault && (
                  <span className="text-[10px] font-bold text-amber-600 bg-amber-500/10 px-2 py-0.5 rounded">
                    Default Address
                  </span>
                )}
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                {addr.street}
                {addr.apartment && <>, {addr.apartment}</>}
                <br />
                {addr.city}, {addr.state} - {addr.pincode}
                <br />
                Phone: {addr.phone}
              </p>
            </div>
          ))}
        </div>
      )}

      {/* TAB 4: ACCOUNT SETTINGS, DEACTIVATION & DELETION */}
      {activeTab === 'account-settings' && (
        <div className="max-w-3xl mx-auto bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-4">
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-amber-500" />
                Customer Account Profile & Lifecycle
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Manage your user details, delivery city location, account activation, and deletion.
              </p>
            </div>
            {!isEditingProfile ? (
              <button
                onClick={() => setIsEditingProfile(true)}
                className="flex items-center gap-1 px-3 py-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-xs font-bold rounded-lg text-slate-800 dark:text-slate-200"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Edit Profile</span>
              </button>
            ) : (
              <button
                onClick={handleSaveProfile}
                className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-800 text-xs font-bold rounded-lg shadow-sm"
              >
                Save Changes
              </button>
            )}
          </div>

          {/* Edit / View Profile Form */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="text-slate-500 dark:text-slate-400 block mb-1 font-semibold">
                Customer Name
              </label>
              <input
                type="text"
                disabled={!isEditingProfile}
                value={profileName}
                onChange={(e) => setProfileName(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white disabled:opacity-75"
              />
            </div>

            <div>
              <label className="text-slate-500 dark:text-slate-400 block mb-1 font-semibold">
                Phone Number
              </label>
              <input
                type="text"
                disabled={!isEditingProfile}
                value={profilePhone}
                onChange={(e) => setProfilePhone(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white disabled:opacity-75"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="text-slate-500 dark:text-slate-400 block mb-1 font-semibold">
                Current Hyperlocal City Location (for near-shop delivery & 10–20km matching)
              </label>
              <select
                disabled={!isEditingProfile}
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white disabled:opacity-75 font-semibold text-amber-600 dark:text-amber-400"
              >
                <option value="Indore">Indore (Madhya Pradesh) - Hyperlocal Hub</option>
                <option value="Bhopal">Bhopal (Madhya Pradesh)</option>
                <option value="Mumbai">Mumbai (Maharashtra)</option>
                <option value="Delhi">Delhi NCR</option>
                <option value="Bengaluru">Bengaluru (Karnataka)</option>
                <option value="Jaipur">Jaipur (Rajasthan)</option>
              </select>
            </div>
          </div>

          {/* Account Lifecycle & Security */}
          <div className="space-y-4 divide-y divide-slate-100 dark:divide-slate-700/80 pt-4 text-xs">
            <div className="pt-3 flex items-center justify-between">
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white">Customer Account Status</h4>
                <p className="text-slate-500 dark:text-slate-400">
                  Toggle whether this account is active or temporarily deactivated.
                </p>
              </div>
              <button
                onClick={toggleUserStatus}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl font-bold transition-all ${
                  userProfile.isActive
                    ? 'bg-rose-500/10 text-rose-600 border border-rose-500/30 hover:bg-rose-500/20'
                    : 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/30 hover:bg-emerald-500/20'
                }`}
              >
                <Power className="w-4 h-4" />
                <span>{userProfile.isActive ? 'Deactivate Account' : 'Activate Account'}</span>
              </button>
            </div>

            <div className="pt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-rose-500/20">
              <div>
                <h4 className="font-bold text-rose-600">Permanently Delete Customer Account</h4>
                <p className="text-slate-500 dark:text-slate-400">
                  Permanently deletes your customer account and frees mobile number <strong className="text-slate-900 dark:text-white">{profilePhone || currentCustomer.phone}</strong> so it can be registered or used for Driver Partner or Seller Store login.
                </p>
              </div>
              <button
                id="btn-delete-customer-account"
                onClick={async () => {
                  if (
                    window.confirm(
                      `Are you sure you want to permanently delete your customer account? This will free your mobile number (${profilePhone || currentCustomer.phone}) to be used for Driver or Seller registration.`
                    )
                  ) {
                    await deleteCustomerAccountPermanently(profilePhone || currentCustomer.phone);
                  }
                }}
                className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold transition-all shadow-md shrink-0"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete Customer Account & Free Number</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
