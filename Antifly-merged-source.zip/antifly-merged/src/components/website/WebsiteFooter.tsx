import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Mail,
  Phone,
  MapPin,
  ShieldCheck,
  Truck,
  RotateCcw,
  Sparkles,
  ArrowRight,
  Heart,
  Smartphone,
  ExternalLink,
  Headphones,
  CreditCard,
  Store,
  CheckCircle2,
} from 'lucide-react';

interface WebsiteFooterProps {
  onNavigate?: (view: 'home' | 'catalog' | 'account') => void;
}

export const WebsiteFooter: React.FC<WebsiteFooterProps> = ({ onNavigate }) => {
  const {
    cmsPages,
    setActiveCMSPage,
    setDeviceMode,
    settings,
    categories,
    setSelectedCategorySlug,
    showToast,
    setIsSupportChatbotOpen,
  } = useApp();

  const [newsletterEmail, setNewsletterEmail] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail.trim()) {
      showToast(`🎉 Subscribed ${newsletterEmail}! ₹200 voucher code sent.`);
      setNewsletterEmail('');
    }
  };

  const handleOpenPage = (slug: string) => {
    const page = cmsPages.find((p) => p.slug === slug);
    if (page) {
      setActiveCMSPage(page);
    }
  };

  return (
    <footer className="bg-white text-slate-700 border-t border-slate-200 transition-colors pb-24">
      {/* 4 Feature Value Props */}
      <div className="border-b border-slate-100 bg-slate-50/70 py-6 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs font-semibold">
          <div className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-2xl shadow-2xs">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center flex-shrink-0">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-extrabold text-slate-900">7-Day Exchange Policy</h4>
              <p className="text-[11px] text-slate-500">Ventures cannot deny exchanges</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-2xl shadow-2xs">
            <div className="w-10 h-10 rounded-xl bg-red-50 text-red-600 flex items-center justify-center flex-shrink-0">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-extrabold text-slate-900">24/7 Dedicated Support</h4>
              <p className="text-[11px] text-slate-500">Direct phone, email & live chat</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-2xl shadow-2xs">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center flex-shrink-0">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-extrabold text-slate-900">Direct Venture UPI QR</h4>
              <p className="text-[11px] text-slate-500">Scan & pay venture directly</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-2xl shadow-2xs">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center flex-shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-extrabold text-slate-900">100% Verified Local Ventures</h4>
              <p className="text-[11px] text-slate-500">Zero fake venture guarantee</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main 4-Column Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-600 flex items-center justify-center text-white font-black text-lg shadow-sm">
                J
              </div>
              <div>
                <span className="font-black text-lg text-slate-900 tracking-tight">
                  Just<span className="text-amber-500">Away</span>
                </span>
                <p className="text-[9px] uppercase tracking-wider text-slate-500 font-bold">
                  Just go. Just away.
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed max-w-sm font-medium">
              The spontaneous travel, 1-tap escapes & nomad gear trial ecosystem. Escape the ordinary, try premium adventure kits at ₹0 doorstep trials, and earn DriftMiles anytime, anywhere.
            </p>

            <div className="space-y-2 text-xs">
              <div className="flex items-center gap-2 text-slate-700 font-medium">
                <Phone className="w-4 h-4 text-amber-600 flex-shrink-0" />
                <span>
                  24/7 Helpline: <strong className="text-slate-900">{settings.contactPhone || '+91 98765 43210'}</strong>
                </span>
              </div>

              <div className="flex items-center gap-2 text-slate-700 font-medium">
                <Mail className="w-4 h-4 text-amber-600 flex-shrink-0" />
                <span>
                  Support Email: <strong className="text-slate-900">{settings.contactEmail || 'concierge@justaway.travel'}</strong>
                </span>
              </div>

              <div className="flex items-center gap-2 text-slate-700 font-medium">
                <MapPin className="w-4 h-4 text-amber-600 flex-shrink-0" />
                <span>{settings.businessAddress || 'Palasia Square, A.B. Road, Indore, MP 452001'}</span>
              </div>
            </div>
          </div>

          {/* Quick Categories */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">
              Explore Ventures
            </h4>
            <ul className="space-y-2 text-xs font-semibold text-slate-600">
              <li>
                <button
                  onClick={() => {
                    setSelectedCategorySlug('all');
                    onNavigate?.('catalog');
                  }}
                  className="hover:text-red-600 transition cursor-pointer"
                >
                  🌾 Kirana & Groceries
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setSelectedCategorySlug('all');
                    onNavigate?.('catalog');
                  }}
                  className="hover:text-red-600 transition cursor-pointer"
                >
                  🥨 Sweets & Namkeen
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setSelectedCategorySlug('all');
                    onNavigate?.('catalog');
                  }}
                  className="hover:text-red-600 transition cursor-pointer"
                >
                  🥻 Silk & Handloom Sarees
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setSelectedCategorySlug('all');
                    onNavigate?.('catalog');
                  }}
                  className="hover:text-red-600 transition cursor-pointer"
                >
                  ⚡ Electronics & Tech Care
                </button>
              </li>
            </ul>
          </div>

          {/* Customer Policies & Help */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">
              Customer Assurance
            </h4>
            <ul className="space-y-2 text-xs font-semibold text-slate-600">
              <li>
                <button
                  onClick={() => setIsSupportChatbotOpen(true)}
                  className="hover:text-red-600 transition cursor-pointer flex items-center gap-1 text-red-600 font-bold"
                >
                  <span>24/7 Live Support Chat</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleOpenPage('return-policy')}
                  className="hover:text-red-600 transition cursor-pointer"
                >
                  7-Day Return & Exchange Rules
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleOpenPage('terms-and-conditions')}
                  className="hover:text-red-600 transition cursor-pointer"
                >
                  Buyer Protection Terms
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleOpenPage('shipping-policy')}
                  className="hover:text-red-600 transition cursor-pointer"
                >
                  50 KM Hyperlocal Delivery
                </button>
              </li>
            </ul>
          </div>

          {/* Newsletter Subscribe */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">
              Stay Connected
            </h4>
            <p className="text-xs text-slate-500 font-medium">
              Get ₹200 voucher code on your first store order.
            </p>
            <form onSubmit={handleSubscribe} className="space-y-2">
              <input
                type="email"
                required
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                placeholder="Enter email address..."
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-red-500 font-medium"
              />
              <button
                type="submit"
                className="w-full py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black transition cursor-pointer shadow-xs"
              >
                Claim ₹200 Off
              </button>
            </form>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-slate-100 mt-8 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 font-medium">
          <p>© {new Date().getFullYear()} Antifly Hyperlocal Marketplace. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 text-slate-700">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              100% Encrypted Direct UPI Payments
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
