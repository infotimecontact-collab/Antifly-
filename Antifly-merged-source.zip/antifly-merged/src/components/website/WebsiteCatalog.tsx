import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../common/ProductCard';
import {
  Filter,
  SlidersHorizontal,
  X,
  Search,
  Check,
  ChevronDown,
  Sparkles,
  Layers,
  ArrowUpDown,
  MapPin,
  Store,
  Navigation,
  Clock,
  Zap,
  ShieldCheck,
  Building2,
  Sparkle,
} from 'lucide-react';

interface WebsiteCatalogProps {
  onBackToHome: () => void;
}

const INDORE_LOCATION_PRESETS = [
  { name: 'Rajwada Central (Maharani Road)', lat: 22.7196, lng: 75.8577, address: 'Rajwada Chowk, Indore' },
  { name: 'Palasia Square / AB Road', lat: 22.7244, lng: 75.8839, address: 'Greater Kailash Road, Old Palasia, Indore' },
  { name: 'Vijay Nagar & Scheme 54', lat: 22.7533, lng: 75.8937, address: 'Mangal City / Orbit Mall, Vijay Nagar, Indore' },
  { name: 'Bhawarkua & Silicon City', lat: 22.6896, lng: 75.8647, address: 'Bhawarkua Main Road, Indore' },
  { name: 'Chappan Dukan & New Palasia', lat: 22.7218, lng: 75.8785, address: '56 Dukan Street, New Palasia, Indore' },
];

export const WebsiteCatalog: React.FC<WebsiteCatalogProps> = ({ onBackToHome }) => {
  const {
    products,
    categories,
    selectedCategorySlug,
    setSelectedCategorySlug,
    searchQuery,
    setSearchQuery,
    appliedFilters,
    setAppliedFilters,
    setIsWiseAIOpen,
    sellers,
    userLocation,
    setUserLocation,
    calculateDistanceKm,
  } = useApp();

  const [isFilterDrawerOpen, setIsFilterDrawerOpen] = useState(false);
  const [priceRange, setPriceRange] = useState<number>(appliedFilters.maxPrice || 25000);
  const [selectedRating, setSelectedRating] = useState<number>(0);
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [selectedTag, setSelectedTag] = useState<string>('');
  const [selectedSellerStoreId, setSelectedSellerStoreId] = useState<string>('all');
  const [maxDistanceRadiusKm, setMaxDistanceRadiusKm] = useState<number>(25);
  const [isNearbyOnly, setIsNearbyOnly] = useState<boolean>(false);
  const [isLocationModalOpen, setIsLocationModalOpen] = useState<boolean>(false);

  // Available unique colors & tags from products
  const allColors = Array.from(
    new Set(products.flatMap((p) => p.colors.map((c) => c.name)))
  );
  const allTags = Array.from(new Set(products.flatMap((p) => p.tags)));

  // Calculate distances for all sellers relative to customer's location
  const sellersWithDistance = sellers.map((seller) => {
    const distanceKm = calculateDistanceKm(
      userLocation.lat,
      userLocation.lng,
      seller.lat,
      seller.lng
    );
    const etaMins = Math.max(15, Math.round(distanceKm * 3.5 + 10));
    return {
      ...seller,
      distanceKm,
      etaMins,
      isDeliverable: distanceKm <= (seller.deliveryRadiusKm || 20),
    };
  }).sort((a, b) => a.distanceKm - b.distanceKm);

  // Filter products based on all conditions including location & selected seller store
  const filteredProducts = products.filter((product) => {
    // Selected Specific Seller Store filter
    if (selectedSellerStoreId !== 'all') {
      const matchSeller =
        product.sellerId === selectedSellerStoreId ||
        product.brand.toLowerCase().includes(
          (sellers.find((s) => s.id === selectedSellerStoreId)?.storeName || '').toLowerCase()
        ) ||
        product.storeName?.toLowerCase() ===
          (sellers.find((s) => s.id === selectedSellerStoreId)?.storeName || '').toLowerCase() ||
        product.tags.includes(
          sellers.find((s) => s.id === selectedSellerStoreId)?.storeName || ''
        );
      if (!matchSeller) return false;
    }

    // Nearby Location & Radius constraint
    if (isNearbyOnly && product.storeLat && product.storeLng) {
      const dist = calculateDistanceKm(
        userLocation.lat,
        userLocation.lng,
        product.storeLat,
        product.storeLng
      );
      if (dist > maxDistanceRadiusKm) return false;
    }

    // Category match
    if (selectedCategorySlug && selectedCategorySlug !== 'all') {
      const matchCat =
        product.category.toLowerCase() === selectedCategorySlug.toLowerCase() ||
        product.subcategory.toLowerCase() === selectedCategorySlug.toLowerCase() ||
        (selectedCategorySlug === 'electrical' && (product.category === 'electrical' || product.category === 'commercial-hardware')) ||
        (selectedCategorySlug === 'cosmetics' && product.category === 'cosmetics') ||
        (selectedCategorySlug === 'furniture' && product.category === 'furniture') ||
        (selectedCategorySlug === 'fashion' && (product.category === 'ethnic-wear' || product.category === 'men' || product.category === 'women'));
      if (!matchCat) return false;
    }

    // Search query match
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = product.name.toLowerCase().includes(q);
      const matchBrand = product.brand.toLowerCase().includes(q);
      const matchDesc = product.description.toLowerCase().includes(q);
      const matchTag = product.tags.some((t) => t.toLowerCase().includes(q));
      const matchCategory = product.category.toLowerCase().includes(q);
      const matchKeyword = product.searchKeywords.some((k) => k.toLowerCase().includes(q));
      if (!matchName && !matchBrand && !matchDesc && !matchTag && !matchKeyword && !matchCategory) return false;
    }

    // Price range match
    if (product.price > priceRange) return false;

    // Rating match
    if (selectedRating > 0 && product.rating < selectedRating) return false;

    // Color match
    if (selectedColor && !product.colors.some((c) => c.name === selectedColor)) return false;

    // Tag match
    if (selectedTag && !product.tags.includes(selectedTag)) return false;

    return true;
  });

  // Sort filtered list
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (appliedFilters.sortBy) {
      case 'nearby': {
        const distA = a.storeLat && a.storeLng ? calculateDistanceKm(userLocation.lat, userLocation.lng, a.storeLat, a.storeLng) : 999;
        const distB = b.storeLat && b.storeLng ? calculateDistanceKm(userLocation.lat, userLocation.lng, b.storeLat, b.storeLng) : 999;
        return distA - distB;
      }
      case 'price-low':
        return a.price - b.price;
      case 'price-high':
        return b.price - a.price;
      case 'rating':
        return b.rating - a.rating;
      case 'discount':
        return b.discountPercentage - a.discountPercentage;
      case 'newest':
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      default:
        return 0;
    }
  });

  const clearAllFilters = () => {
    setSelectedCategorySlug('all');
    setSearchQuery('');
    setPriceRange(25000);
    setSelectedRating(0);
    setSelectedColor('');
    setSelectedTag('');
    setSelectedSellerStoreId('all');
    setIsNearbyOnly(false);
    setAppliedFilters({ sortBy: 'featured' });
  };

  const selectedSeller = sellers.find((s) => s.id === selectedSellerStoreId);

  const activeFiltersCount =
    (selectedCategorySlug !== 'all' ? 1 : 0) +
    (searchQuery ? 1 : 0) +
    (selectedSellerStoreId !== 'all' ? 1 : 0) +
    (isNearbyOnly ? 1 : 0) +
    (priceRange < 25000 ? 1 : 0) +
    (selectedRating > 0 ? 1 : 0) +
    (selectedColor ? 1 : 0) +
    (selectedTag ? 1 : 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Hyperlocal Customer Location Bar */}
      <div className="bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-emerald-500/10 border border-amber-500/30 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-800 flex items-center justify-center font-bold shrink-0 shadow-md">
            <MapPin className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                Delivering To Your Live Location
              </span>
              <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded text-[10px] font-bold">
                Hyperlocal Active ⚡
              </span>
            </div>
            <p className="text-sm font-bold text-slate-900 dark:text-white">
              {userLocation.address || `${userLocation.city}, Madhya Pradesh`}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            id="change-location-btn"
            onClick={() => setIsLocationModalOpen(true)}
            className="px-3.5 py-1.5 bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-sm border border-slate-700"
          >
            <Navigation className="w-3.5 h-3.5 text-amber-400" />
            <span>Change Location</span>
          </button>

          <button
            onClick={() => setIsNearbyOnly(!isNearbyOnly)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 border ${
              isNearbyOnly
                ? 'bg-emerald-500 text-slate-800 border-emerald-400 font-bold shadow-md'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>{isNearbyOnly ? 'Nearby Stores (<20km) Active' : 'Filter by Nearby Stores'}</span>
          </button>
        </div>
      </div>

      {/* NEARBY VERIFIED STORES CAROUSEL / SELECTOR */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Store className="w-5 h-5 text-amber-500" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Nearby Stores in Indore & Around You
            </h2>
            <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded text-xs font-semibold">
              {sellersWithDistance.length} Merchant Stores
            </span>
          </div>

          {selectedSellerStoreId !== 'all' && (
            <button
              onClick={() => setSelectedSellerStoreId('all')}
              className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1"
            >
              <X className="w-3.5 h-3.5" />
              <span>Show All Stores</span>
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Option for All Stores */}
          <div
            onClick={() => setSelectedSellerStoreId('all')}
            className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between gap-2 ${
              selectedSellerStoreId === 'all'
                ? 'bg-amber-500/10 border-amber-500 shadow-md ring-2 ring-amber-500/30'
                : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700/80 hover:border-amber-400'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-500 flex items-center justify-center font-bold">
                🏪
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                All Marketplace
              </span>
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">All Nearby & Pan-India Stores</h4>
              <p className="text-[11px] text-slate-500 mt-0.5">Explore electricals, cosmetics, furniture, cloths, & commercial</p>
            </div>
            <div className="text-[10px] font-semibold text-amber-600 dark:text-amber-400">
              {products.length} Products Live
            </div>
          </div>

          {/* Individual Nearby Stores */}
          {sellersWithDistance.slice(0, 7).map((seller) => {
            const isSelected = selectedSellerStoreId === seller.id;
            return (
              <div
                key={seller.id}
                onClick={() => setSelectedSellerStoreId(seller.id)}
                className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between gap-2.5 ${
                  isSelected
                    ? 'bg-amber-500/10 border-amber-500 shadow-md ring-2 ring-amber-500/30'
                    : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700/80 hover:border-amber-400'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1">
                      {seller.storeName}
                    </h4>
                    <p className="text-[10px] text-slate-500 line-clamp-1">{seller.warehouseAddress?.street || seller.city}</p>
                  </div>
                  <span className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-500 text-[9px] font-bold rounded shrink-0">
                    ⭐ {seller.rating}
                  </span>
                </div>

                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    {seller.distanceKm.toFixed(1)} km
                  </span>
                  <span className="text-slate-500 flex items-center gap-1 text-[10px]">
                    <Clock className="w-3 h-3 text-amber-500" />
                    {seller.etaMins} mins
                  </span>
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-[10px]">
                  <span className="capitalize font-semibold text-slate-600 dark:text-slate-300">
                    {seller.category === 'electrical' && '⚡ Electrical Mart'}
                    {seller.category === 'cosmetics' && '💄 Cosmetics & Beauty'}
                    {seller.category === 'furniture' && '🪑 Furniture & Wood'}
                    {seller.category === 'ethnic-wear' && '👕 Handloom & Cloths'}
                    {seller.category === 'commercial-hardware' && '🛠️ Contractor Supplies'}
                    {!['electrical', 'cosmetics', 'furniture', 'ethnic-wear', 'commercial-hardware'].includes(seller.category) && seller.category}
                  </span>
                  <span className="text-amber-500 font-bold">
                    {isSelected ? '✓ Selected' : 'View Store →'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Store Banner */}
      {selectedSeller && (
        <div className="p-4 bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-teal-500/20 border-2 border-amber-500/50 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-slate-800 flex items-center justify-center font-black text-xl shadow-lg">
              🏪
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {selectedSeller.storeName}
                </h3>
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-600 dark:text-emerald-300 text-[10px] font-bold rounded-lg border border-emerald-500/30">
                  {selectedSeller.badge || 'Verified Merchant ⭐'}
                </span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                📍 {selectedSeller.warehouseAddress?.street}, {selectedSeller.city} &bull;{' '}
                <span className="font-bold text-emerald-500">
                  {calculateDistanceKm(userLocation.lat, userLocation.lng, selectedSeller.lat, selectedSeller.lng).toFixed(1)} km away
                </span>{' '}
                &bull; ⏱️ Same-day {Math.max(15, Math.round(calculateDistanceKm(userLocation.lat, userLocation.lng, selectedSeller.lat, selectedSeller.lng) * 3.5 + 10))} min Hyperlocal Delivery
              </p>
            </div>
          </div>

          <button
            onClick={() => setSelectedSellerStoreId('all')}
            className="px-4 py-2 bg-slate-900 dark:bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl shadow border border-slate-700 whitespace-nowrap"
          >
            Show Products from All Stores
          </button>
        </div>
      )}

      {/* Header breadcrumb & info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <button onClick={onBackToHome} className="hover:text-amber-600">
              Home
            </button>
            <span>/</span>
            <span className="font-semibold text-slate-900 dark:text-white capitalize">
              {selectedCategorySlug === 'all' ? 'All Marketplace Products' : selectedCategorySlug}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            {selectedCategorySlug === 'all'
              ? searchQuery
                ? `Search Results for "${searchQuery}"`
                : selectedSeller
                ? `${selectedSeller.storeName} Catalog`
                : 'Explore All Flipkart-Style Categories'
              : categories.find((c) => c.slug === selectedCategorySlug)?.name || selectedCategorySlug}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Showing {sortedProducts.length} items available for immediate order & rider dispatch
          </p>
        </div>

        {/* Sort & Mobile Filter Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsFilterDrawerOpen(!isFilterDrawerOpen)}
            className="md:hidden flex items-center gap-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-800 dark:text-white"
          >
            <Filter className="w-4 h-4" />
            <span>Filters</span>
            {activeFiltersCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-amber-500 text-slate-800 font-bold text-[10px] flex items-center justify-center">
                {activeFiltersCount}
              </span>
            )}
          </button>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 px-3 py-1.5 rounded-xl text-xs">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-slate-500 font-medium">Sort:</span>
            <select
              value={appliedFilters.sortBy || 'featured'}
              onChange={(e) =>
                setAppliedFilters((prev) => ({ ...prev, sortBy: e.target.value }))
              }
              className="bg-transparent font-bold text-slate-900 dark:text-white focus:outline-none cursor-pointer"
            >
              <option value="featured">Featured & Trending</option>
              <option value="nearby">📍 Closest to My Location</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="rating">Customer Rating</option>
              <option value="discount">Biggest Discount</option>
              <option value="newest">Newest First</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Grid: Sidebar Filters + Products List */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Sidebar Filters (Desktop) */}
        <aside
          className={`space-y-6 md:block ${
            isFilterDrawerOpen ? 'block' : 'hidden'
          } p-4 sm:p-5 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-800 h-fit`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold text-sm text-slate-900 dark:text-white">
              <SlidersHorizontal className="w-4 h-4 text-amber-500" />
              <span>Filter Catalog</span>
            </div>
            {activeFiltersCount > 0 && (
              <button
                onClick={clearAllFilters}
                className="text-[11px] font-bold text-rose-600 dark:text-rose-400 hover:underline"
              >
                Reset All
              </button>
            )}
          </div>

          {/* Department / Category Filter */}
          <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-700">
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-500">
              Categories & Departments
            </h4>
            <div className="space-y-1 text-xs">
              <button
                onClick={() => setSelectedCategorySlug('all')}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg font-medium transition-all ${
                  selectedCategorySlug === 'all'
                    ? 'bg-amber-500 text-slate-800 font-bold'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                All Departments ({products.length})
              </button>

              <button
                onClick={() => setSelectedCategorySlug('electrical')}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg font-medium flex items-center justify-between transition-all ${
                  selectedCategorySlug === 'electrical'
                    ? 'bg-amber-500 text-slate-800 font-bold'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <span>⚡ Electricals & MCB Tools</span>
                <span className="text-[10px] opacity-70">
                  ({products.filter((p) => p.category === 'electrical' || p.category === 'commercial-hardware').length})
                </span>
              </button>

              <button
                onClick={() => setSelectedCategorySlug('cosmetics')}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg font-medium flex items-center justify-between transition-all ${
                  selectedCategorySlug === 'cosmetics'
                    ? 'bg-amber-500 text-slate-800 font-bold'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <span>💄 Cosmetics & Beauty</span>
                <span className="text-[10px] opacity-70">
                  ({products.filter((p) => p.category === 'cosmetics').length})
                </span>
              </button>

              <button
                onClick={() => setSelectedCategorySlug('furniture')}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg font-medium flex items-center justify-between transition-all ${
                  selectedCategorySlug === 'furniture'
                    ? 'bg-amber-500 text-slate-800 font-bold'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <span>🪑 Furniture & Woodcraft</span>
                <span className="text-[10px] opacity-70">
                  ({products.filter((p) => p.category === 'furniture').length})
                </span>
              </button>

              <button
                onClick={() => setSelectedCategorySlug('ethnic-wear')}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg font-medium flex items-center justify-between transition-all ${
                  selectedCategorySlug === 'ethnic-wear'
                    ? 'bg-amber-500 text-slate-800 font-bold'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <span>👕 Cloths & Ethnic Sarees</span>
                <span className="text-[10px] opacity-70">
                  ({products.filter((p) => p.category === 'ethnic-wear').length})
                </span>
              </button>

              <button
                onClick={() => setSelectedCategorySlug('commercial-hardware')}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg font-medium flex items-center justify-between transition-all ${
                  selectedCategorySlug === 'commercial-hardware'
                    ? 'bg-amber-500 text-slate-800 font-bold'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <span>🛠️ Commercial & Hardware</span>
                <span className="text-[10px] opacity-70">
                  ({products.filter((p) => p.category === 'commercial-hardware').length})
                </span>
              </button>

              <button
                onClick={() => setSelectedCategorySlug('gadgets')}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg font-medium flex items-center justify-between transition-all ${
                  selectedCategorySlug === 'gadgets'
                    ? 'bg-amber-500 text-slate-800 font-bold'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <span>📱 Electronics & Gadgets</span>
                <span className="text-[10px] opacity-70">
                  ({products.filter((p) => p.category === 'gadgets').length})
                </span>
              </button>
            </div>
          </div>

          {/* Hyperlocal Distance Radius Filter */}
          <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-700">
            <div className="flex justify-between items-center text-xs">
              <h4 className="font-bold uppercase tracking-wider text-slate-500">Max Delivery Distance</h4>
              <span className="font-bold font-mono text-emerald-600 dark:text-emerald-400">
                {maxDistanceRadiusKm} km
              </span>
            </div>
            <input
              type="range"
              min={3}
              max={30}
              step={1}
              value={maxDistanceRadiusKm}
              onChange={(e) => {
                setMaxDistanceRadiusKm(Number(e.target.value));
                setIsNearbyOnly(true);
              }}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-mono">
              <span>3 km (Instant)</span>
              <span>15 km</span>
              <span>30 km (Metro)</span>
            </div>
          </div>

          {/* Price Range Slider */}
          <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-700">
            <div className="flex justify-between items-center text-xs">
              <h4 className="font-bold uppercase tracking-wider text-slate-500">Max Price</h4>
              <span className="font-bold font-mono text-slate-900 dark:text-white">
                ₹{priceRange.toLocaleString('en-IN')}
              </span>
            </div>
            <input
              type="range"
              min={300}
              max={25000}
              step={500}
              value={priceRange}
              onChange={(e) => setPriceRange(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-mono">
              <span>₹300</span>
              <span>₹12,000</span>
              <span>₹25,000</span>
            </div>
          </div>

          {/* Color Filter */}
          <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-700">
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-500">Color</h4>
            <div className="flex flex-wrap gap-1.5">
              {allColors.slice(0, 8).map((color) => (
                <button
                  key={color}
                  onClick={() => setSelectedColor(selectedColor === color ? '' : color)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
                    selectedColor === color
                      ? 'bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-800 border-transparent'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700 hover:border-slate-400'
                  }`}
                >
                  {color}
                </button>
              ))}
            </div>
          </div>

          {/* Tag Filter */}
          <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-700">
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-500">
              Occasion & Style
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {allTags.slice(0, 8).map((tag) => (
                <button
                  key={tag}
                  onClick={() => setSelectedTag(selectedTag === tag ? '' : tag)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
                    selectedTag === tag
                      ? 'bg-amber-500 text-slate-800 border-amber-500 font-bold'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
                  }`}
                >
                  #{tag}
                </button>
              ))}
            </div>
          </div>

          {/* WiseAI Shopping CTA */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-700">
            <div className="p-3 bg-gradient-to-br from-amber-500/10 to-orange-500/10 rounded-xl border border-amber-500/30 text-xs space-y-2">
              <div className="flex items-center gap-1.5 text-amber-700 dark:text-amber-300 font-bold">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>Need Personalized Advice?</span>
              </div>
              <p className="text-[11px] text-slate-600 dark:text-slate-400">
                WiseAI recommends tailored sizing, fabric pairings, and festive looks.
              </p>
              <button
                onClick={() => setIsWiseAIOpen(true)}
                className="w-full bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-800 font-bold py-2 rounded-lg text-xs"
              >
                Chat with WiseAI
              </button>
            </div>
          </div>
        </aside>

        {/* Product Cards Grid */}
        <main className="md:col-span-3 space-y-6">
          {/* Active Filter Chips */}
          {activeFiltersCount > 0 && (
            <div className="flex flex-wrap items-center gap-2 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl text-xs">
              <span className="font-bold text-slate-500">Active Filters:</span>
              {selectedSellerStoreId !== 'all' && (
                <span className="px-2.5 py-1 bg-amber-500 text-slate-800 rounded-lg flex items-center gap-1 font-bold">
                  Store: {selectedSeller?.storeName}
                  <button onClick={() => setSelectedSellerStoreId('all')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {isNearbyOnly && (
                <span className="px-2.5 py-1 bg-emerald-500 text-slate-800 rounded-lg flex items-center gap-1 font-bold">
                  Distance: &lt; {maxDistanceRadiusKm} km
                  <button onClick={() => setIsNearbyOnly(false)}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {selectedCategorySlug !== 'all' && (
                <span className="px-2.5 py-1 bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-200 rounded-lg flex items-center gap-1 font-semibold">
                  Category: {selectedCategorySlug}
                  <button onClick={() => setSelectedCategorySlug('all')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {searchQuery && (
                <span className="px-2.5 py-1 bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-200 rounded-lg flex items-center gap-1 font-semibold">
                  Search: "{searchQuery}"
                  <button onClick={() => setSearchQuery('')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {selectedColor && (
                <span className="px-2.5 py-1 bg-slate-200 dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg flex items-center gap-1 font-semibold">
                  Color: {selectedColor}
                  <button onClick={() => setSelectedColor('')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {selectedTag && (
                <span className="px-2.5 py-1 bg-slate-200 dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg flex items-center gap-1 font-semibold">
                  Tag: #{selectedTag}
                  <button onClick={() => setSelectedTag('')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              <button
                onClick={clearAllFilters}
                className="text-rose-600 dark:text-rose-400 font-bold ml-auto hover:underline"
              >
                Clear All
              </button>
            </div>
          )}

          {/* Grid or Empty state */}
          {sortedProducts.length === 0 ? (
            <div className="py-16 text-center space-y-4 bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-slate-200 dark:border-slate-800 p-8">
              <div className="w-16 h-16 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center mx-auto text-slate-500">
                <Search className="w-8 h-8" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-slate-900 dark:text-white">
                  No products matched your criteria
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Try clearing some filters, expanding your delivery distance radius, or searching for terms like "switch", "lipstick", "drill", "desk", or "kurta".
                </p>
              </div>
              <button
                onClick={clearAllFilters}
                className="bg-amber-500 text-slate-800 font-bold px-6 py-2.5 rounded-xl text-xs shadow-md"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {sortedProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </main>
      </div>

      {/* LOCATION SELECTION MODAL */}
      {isLocationModalOpen && (
        <div className="fixed inset-0 z-50 bg-white/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-white text-base">Select Your Delivery Location</h3>
              </div>
              <button onClick={() => setIsLocationModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-400">
              Nearby stores and delivery ETAs will automatically recalculate in real-time based on your selected address.
            </p>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-300 block">Indore Hyperlocal Hubs & Markets:</label>
              {INDORE_LOCATION_PRESETS.map((loc, idx) => {
                const isCurrent = userLocation?.address?.includes(loc.name?.split(' ')?.[0] || loc.name);
                return (
                  <button
                    key={idx}
                    onClick={() => {
                      setUserLocation({
                        city: 'Indore',
                        lat: loc.lat,
                        lng: loc.lng,
                        address: loc.address,
                      });
                      setIsLocationModalOpen(false);
                    }}
                    className={`w-full text-left p-3 rounded-xl border text-xs flex items-center justify-between transition-all ${
                      isCurrent
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold'
                        : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                    }`}
                  >
                    <div>
                      <div className="font-bold text-white">{loc.name}</div>
                      <div className="text-[11px] text-slate-400">{loc.address}</div>
                    </div>
                    {isCurrent && <span className="text-amber-400 font-bold">✓ Active</span>}
                  </button>
                );
              })}
            </div>

            <div className="pt-2 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setIsLocationModalOpen(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
