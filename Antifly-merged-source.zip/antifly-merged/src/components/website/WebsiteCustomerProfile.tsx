import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  User,
  ShieldCheck,
  CheckCircle2,
  Gem,
  Award,
  CreditCard,
  Sparkles,
  Share2,
  LifeBuoy,
  RefreshCw,
  Clock,
  ShoppingBag,
  Heart,
  ChevronRight,
  Gift,
  Tv,
  Crown,
  Camera,
  Plus,
  Star,
  Mic,
  Phone,
  Store,
  Check,
  Flame,
  Coins,
  QrCode,
  MessageSquare,
  Building2,
  Trash2,
  Headphones,
  RotateCcw,
  AlertCircle,
  IndianRupee,
  ExternalLink,
  Mail,
} from 'lucide-react';
import { DirectSellerPaymentModal } from '../common/DirectSellerPaymentModal';
import { SellerProfile } from '../../types';

export const WebsiteCustomerProfile: React.FC = () => {
  const {
    userPersonaProfile,
    updatePersonaProfile,
    customerConnectState,
    setIsConnectMembershipModalOpen,
    setIsVerifiedBadgeModalOpen,
    setIsRoleSwitcherOpen,
    setIsSupportChatbotOpen,
    isOneYearFreePromoActive,
    orders,
    wishlist,
    products,
    toggleWishlist,
    addToCart,
    wiseOneSubscription,
    setIsWiseOneModalOpen,
    setIsOTTModalOpen,
    superCoinsBalance,
    setIsSuperCoinsModalOpen,
    showToast,
    sellers,
    openStoreChat,
    openStoreCommunity,
    toggleFollowSeller,
    settings,
    setActivePdpId,
  } = useApp();

  const [activePhotoTab, setActivePhotoTab] = useState<'profile' | 'business'>('profile');
  const [newPhotoUrl, setNewPhotoUrl] = useState<string>('');
  const [isAddingPhoto, setIsAddingPhoto] = useState<boolean>(false);

  // Wishlist 2-Tab State
  const [wishlistTab, setWishlistTab] = useState<'products' | 'sellers'>('products');

  // Favorite sellers state (stored locally or synced)
  const [favoriteSellerIds, setFavoriteSellerIds] = useState<string[]>([
    'seller-1',
    'seller-2',
    'seller-3',
  ]);

  // Saved Bank & Card Details
  const [savedCards, setSavedCards] = useState([
    {
      id: 'card-1',
      bank: 'HDFC Bank Millennia',
      cardNumber: '•••• •••• •••• 4829',
      cardType: 'Visa Platinum',
      expiry: '08/29',
      isDefault: true,
    },
    {
      id: 'card-2',
      bank: 'ICICI Bank Coral',
      cardNumber: '•••• •••• •••• 9102',
      cardType: 'Mastercard',
      expiry: '11/28',
      isDefault: false,
    },
  ]);

  const [savedBankAccounts, setSavedBankAccounts] = useState([
    {
      id: 'bank-1',
      accountHolder: 'Rahul Sharma',
      bankName: 'State Bank of India',
      accountNumber: '••••••••8819',
      ifsc: 'SBIN0001234',
      upiId: 'rahul.sharma@oksbi',
    },
  ]);

  const [isAddingCard, setIsAddingCard] = useState(false);
  const [newCardBank, setNewCardBank] = useState('');
  const [newCardNumber, setNewCardNumber] = useState('');
  const [newCardExpiry, setNewCardExpiry] = useState('');

  // QR Modal
  const [selectedSellerForQR, setSelectedSellerForQR] = useState<SellerProfile | null>(null);
  const [isQRModalOpen, setIsQRModalOpen] = useState(false);

  const toggleFavoriteSeller = (sellerId: string) => {
    if (favoriteSellerIds.includes(sellerId)) {
      setFavoriteSellerIds((prev) => prev.filter((id) => id !== sellerId));
      showToast('Removed store from favorite sellers');
    } else {
      setFavoriteSellerIds((prev) => [...prev, sellerId]);
      showToast('Added store to favorite sellers ⭐');
    }
  };

  const handleAddCard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCardNumber.trim() || !newCardBank.trim()) return;
    const newCard = {
      id: `card-${Date.now()}`,
      bank: newCardBank,
      cardNumber: `•••• •••• •••• ${newCardNumber.slice(-4) || '1234'}`,
      cardType: 'RuPay / Visa',
      expiry: newCardExpiry || '12/30',
      isDefault: false,
    };
    setSavedCards((prev) => [...prev, newCard]);
    setNewCardBank('');
    setNewCardNumber('');
    setNewCardExpiry('');
    setIsAddingCard(false);
    showToast('✅ Payment card added securely!');
  };

  const handleDeleteCard = (cardId: string) => {
    setSavedCards((prev) => prev.filter((c) => c.id !== cardId));
    showToast('Card removed from saved payment methods');
  };

  const handleAddPhoto = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPhotoUrl.trim()) return;

    if (activePhotoTab === 'profile') {
      const currentList = userPersonaProfile.profilePictures || [userPersonaProfile.avatar];
      updatePersonaProfile({ profilePictures: [...currentList, newPhotoUrl] });
      showToast('✅ Profile photo added successfully!');
    } else {
      const currentBiz = userPersonaProfile.businessPhotos || [];
      updatePersonaProfile({ businessPhotos: [...currentBiz, newPhotoUrl] });
      showToast('✅ Storefront business photo added!');
    }

    setNewPhotoUrl('');
    setIsAddingPhoto(false);
  };

  const handleRedeemPointsForQuota = () => {
    if ((userPersonaProfile.rewardPoints || 0) < 10) {
      showToast('⚠️ You need at least 10 Reward Points to redeem for 5 extra seller contacts.');
      return;
    }
    updatePersonaProfile({
      rewardPoints: Math.max(0, (userPersonaProfile.rewardPoints || 0) - 10),
    });
    showToast('🎉 10 Points redeemed! +5 Seller quota added to your account.');
  };

  const ottPlatforms = [
    { name: 'Disney+ Hotstar VIP', icon: '🎬', active: wiseOneSubscription.isActive },
    { name: 'SonyLIV Premium', icon: '📺', active: wiseOneSubscription.isActive },
    { name: 'Zee5 All-Access', icon: '🍿', active: wiseOneSubscription.isActive },
    { name: 'Amazon Prime Video', icon: '📦', active: wiseOneSubscription.isActive },
    { name: 'Netflix Mobile Hub', icon: '🎥', active: wiseOneSubscription.isActive },
  ];

  const wishlistProducts = products.filter((p) => wishlist.includes(p.id));
  const wishlistSellerProfiles = sellers.filter((s) => favoriteSellerIds.includes(s.id));

  return (
    <div id="website-customer-profile-page" className="w-full bg-white text-slate-900 min-h-[85vh]">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        
        {/* Profile Card Header */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-6 shadow-xs">
          <div className="flex items-center gap-4">
            <div className="relative w-20 h-20 rounded-2xl overflow-hidden border-2 border-slate-100 shadow-md bg-red-600 flex items-center justify-center text-white text-2xl font-black flex-shrink-0">
              <img
                src={userPersonaProfile.avatar}
                alt={userPersonaProfile.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              {userPersonaProfile.isVerifiedCustomer && (
                <div className="absolute bottom-1 right-1 p-0.5 rounded-full bg-blue-600 text-white">
                  <CheckCircle2 className="w-4 h-4 fill-blue-500 text-white" />
                </div>
              )}
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl sm:text-2xl font-black text-slate-900">
                  {userPersonaProfile.name}
                </h1>

                {/* Voice Customer Star Identifier */}
                <span className="px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 text-xs font-black border border-amber-200 flex items-center gap-1">
                  <Star className="w-3 h-3 text-amber-500 fill-amber-400" />
                  <span>Voice Star {userPersonaProfile?.name?.split(' ')?.[0] || 'Member'}</span>
                </span>

                {userPersonaProfile.isVerifiedCustomer ? (
                  <span className="px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 text-xs font-black border border-blue-200 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-blue-600 fill-blue-50" />
                    Verified Blue Tick
                  </span>
                ) : (
                  <button
                    onClick={() => setIsVerifiedBadgeModalOpen(true)}
                    className="px-2.5 py-0.5 rounded-full bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-700 text-xs font-bold transition cursor-pointer"
                  >
                    + Get Verified ($2/yr)
                  </button>
                )}
              </div>

              {/* Mandatory & Unique Mobile Number Display */}
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 flex-wrap">
                <span className="flex items-center gap-1 text-slate-800 bg-slate-50 px-2 py-0.5 rounded-lg border border-slate-200">
                  <Phone className="w-3 h-3 text-emerald-600" />
                  <strong>{userPersonaProfile.phone}</strong> (Verified Phone)
                </span>
                <span>• {userPersonaProfile.email}</span>
              </div>

              <p className="text-xs text-slate-500 font-medium">
                📍 {userPersonaProfile.locality || 'Indore, MP'} • Customer Voice Mode Active
              </p>
            </div>
          </div>

          {/* Switch Persona Role Button */}
          <div className="flex flex-col gap-2">
            <button
              onClick={() => setIsRoleSwitcherOpen(true)}
              className="px-5 py-2.5 rounded-2xl bg-red-600 hover:bg-red-700 text-white text-xs font-black shadow-sm transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Switch to Seller / Driver</span>
            </button>
            <span className="text-[10px] text-center text-slate-400 font-medium">
              1-Click dynamic role transition
            </span>
          </div>
        </div>

        {/* 24/7 CUSTOMER SUPPORT SECTION (Dynamic Admin Email & Phone) */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-red-50 text-red-600 flex items-center justify-center">
                <Headphones className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-black text-slate-900 flex items-center gap-2">
                  <span>24/7 Dedicated Customer Support</span>
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-black rounded-full uppercase">
                    Live
                  </span>
                </h2>
                <p className="text-xs text-slate-500 font-medium">
                  Reach our dedicated helpdesk anytime via 24/7 helpline, email, or direct live chat
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsSupportChatbotOpen(true)}
              className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black transition cursor-pointer flex items-center gap-1.5 shadow-sm"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Start 24/7 Live Chat</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Dynamic Support Email */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-1">
              <div className="flex items-center gap-2 text-slate-500 text-xs font-bold">
                <Mail className="w-3.5 h-3.5 text-red-600" />
                <span>24/7 Support Email:</span>
              </div>
              <p className="text-sm font-black text-slate-900 break-all">
                {settings.contactEmail || 'support@antifly.com'}
              </p>
              <p className="text-[10px] text-slate-400 font-medium">
                Admin managed &bull; Average response &lt; 5 mins
              </p>
            </div>

            {/* Dynamic Helpline Phone */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-1">
              <div className="flex items-center gap-2 text-slate-500 text-xs font-bold">
                <Phone className="w-3.5 h-3.5 text-emerald-600" />
                <span>24/7 Helpline Phone:</span>
              </div>
              <p className="text-sm font-black text-slate-900">
                {settings.contactPhone || '+91 98765 43210'}
              </p>
              <p className="text-[10px] text-slate-400 font-medium">
                Toll-free voice call & WhatsApp support
              </p>
            </div>

            {/* 7-Day Exchange Guarantee */}
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-1">
              <div className="flex items-center gap-2 text-emerald-900 text-xs font-bold">
                <RotateCcw className="w-3.5 h-3.5 text-emerald-600" />
                <span>Guaranteed 7-Day Return / Exchange</span>
              </div>
              <p className="text-xs font-bold text-emerald-950">
                Sellers cannot deny exchanges
              </p>
              <p className="text-[10px] text-emerald-800 font-medium">
                100% cancellation right anytime + penalty refund if denied
              </p>
            </div>
          </div>
        </div>

        {/* 2-TAB WISHLIST (Tab 1: Product Wishlist, Tab 2: Seller Wishlist) */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-rose-500 fill-rose-500" />
              <div>
                <h2 className="text-base font-black text-slate-900">
                  My Wishlist & Favorite Stores
                </h2>
                <p className="text-xs text-slate-500 font-medium">
                  Two tabs: Browse saved products or your favorite local merchant shops
                </p>
              </div>
            </div>

            {/* 2 Tabs Toggle */}
            <div className="flex items-center p-1 bg-slate-100 rounded-2xl border border-slate-200 self-start sm:self-auto">
              <button
                onClick={() => setWishlistTab('products')}
                className={`px-4 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${
                  wishlistTab === 'products'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Saved Products ({wishlistProducts.length})</span>
              </button>

              <button
                onClick={() => setWishlistTab('sellers')}
                className={`px-4 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${
                  wishlistTab === 'sellers'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Store className="w-3.5 h-3.5" />
                <span>Favorite Sellers ({wishlistSellerProfiles.length})</span>
              </button>
            </div>
          </div>

          {/* TAB 1: PRODUCT WISHLIST */}
          {wishlistTab === 'products' && (
            <div>
              {wishlistProducts.length === 0 ? (
                <div className="text-center py-8 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                  <ShoppingBag className="w-8 h-8 text-slate-300 mx-auto" />
                  <p className="text-xs font-bold text-slate-600">Your product wishlist is empty</p>
                  <p className="text-[11px] text-slate-400">Save items while browsing to see them here.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {wishlistProducts.map((p) => (
                    <div
                      key={p.id}
                      className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex flex-col justify-between space-y-3 group"
                    >
                      <div className="flex gap-3">
                        <div
                          onClick={() => setActivePdpId(p.id)}
                          className="w-16 h-16 rounded-xl overflow-hidden bg-white border border-slate-200 flex-shrink-0 cursor-pointer"
                        >
                          <img
                            src={p.images?.[0] || 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=300'}
                            alt={p.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-black text-slate-900 truncate">{p.name}</p>
                          <p className="text-[10px] text-slate-500 font-semibold">{p.brand}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-xs font-black text-slate-900">₹{p.price}</span>
                            {p.mrp && <span className="text-[10px] text-slate-400 line-through">₹{p.mrp}</span>}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 pt-2 border-t border-slate-200/80">
                        <button
                          onClick={() => {
                            addToCart(p, p.variants?.[0]?.id || 'v-1');
                            showToast(`Added ${p.name} to Cart`);
                          }}
                          className="flex-1 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black shadow-xs transition cursor-pointer"
                        >
                          Add to Cart
                        </button>
                        <button
                          onClick={() => toggleWishlist(p.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-slate-200/70 rounded-xl transition cursor-pointer"
                          title="Remove"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: SELLER WISHLIST */}
          {wishlistTab === 'sellers' && (
            <div>
              {wishlistSellerProfiles.length === 0 ? (
                <div className="text-center py-8 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                  <Store className="w-8 h-8 text-slate-300 mx-auto" />
                  <p className="text-xs font-bold text-slate-600">No favorite sellers saved yet</p>
                  <p className="text-[11px] text-slate-400">Click the heart on any store card to bookmark your favorite merchants.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {wishlistSellerProfiles.map((s) => (
                    <div
                      key={s.id}
                      className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex flex-col justify-between space-y-3"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <div className="w-10 h-10 rounded-xl bg-red-100 text-red-600 flex items-center justify-center font-black text-sm border border-red-200 flex-shrink-0">
                            {s.storeName.charAt(0)}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-1">
                              <h4 className="font-black text-xs text-slate-900 truncate">{s.storeName}</h4>
                              <CheckCircle2 className="w-3 h-3 text-blue-600 fill-blue-50 flex-shrink-0" />
                            </div>
                            <p className="text-[10px] text-slate-500 font-semibold truncate">
                              📍 {s.city || 'Indore'} &bull; ⭐ {s.rating || 4.8}
                            </p>
                          </div>
                        </div>

                        <button
                          onClick={() => toggleFavoriteSeller(s.id)}
                          className="text-rose-500 hover:text-rose-700 cursor-pointer"
                          title="Remove from favorites"
                        >
                          <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
                        </button>
                      </div>

                      {/* Direct Action Buttons */}
                      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-200/80">
                        <button
                          onClick={() => {
                            setSelectedSellerForQR(s);
                            setIsQRModalOpen(true);
                          }}
                          className="py-1.5 px-2 bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 rounded-xl text-[11px] font-black flex items-center justify-center gap-1 shadow-xs transition cursor-pointer"
                        >
                          <QrCode className="w-3 h-3 text-red-600" />
                          <span>Direct QR Pay</span>
                        </button>

                        <button
                          onClick={() => openStoreChat(s.id)}
                          className="py-1.5 px-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-[11px] font-black flex items-center justify-center gap-1 shadow-xs transition cursor-pointer"
                        >
                          <MessageSquare className="w-3 h-3" />
                          <span>Chat & Book</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* SAVED BANK ACCOUNTS & PAYMENT CARDS */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-red-600" />
              <div>
                <h2 className="text-base font-black text-slate-900">
                  Saved Cards & Bank Accounts
                </h2>
                <p className="text-xs text-slate-500 font-medium">
                  Manage your UPI IDs, debit/credit cards, and bank details for 1-click checkout
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsAddingCard(!isAddingCard)}
              className="px-3.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition cursor-pointer flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New Card</span>
            </button>
          </div>

          {/* Add Card Form */}
          {isAddingCard && (
            <form onSubmit={handleAddCard} className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3 animate-in fade-in">
              <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">
                Add New Debit / Credit Card
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  placeholder="Bank Name (e.g. Axis Bank)"
                  value={newCardBank}
                  onChange={(e) => setNewCardBank(e.target.value)}
                  required
                  className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 font-medium focus:outline-none focus:border-red-500"
                />
                <input
                  type="text"
                  placeholder="Card Number (16 digits)"
                  value={newCardNumber}
                  onChange={(e) => setNewCardNumber(e.target.value)}
                  maxLength={19}
                  required
                  className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 font-medium focus:outline-none focus:border-red-500"
                />
                <input
                  type="text"
                  placeholder="Expiry (MM/YY)"
                  value={newCardExpiry}
                  onChange={(e) => setNewCardExpiry(e.target.value)}
                  maxLength={5}
                  required
                  className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 font-medium focus:outline-none focus:border-red-500"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddingCard(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 font-bold hover:bg-slate-200 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-xl shadow-xs cursor-pointer"
                >
                  Save Card
                </button>
              </div>
            </form>
          )}

          {/* Cards & Bank List */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {savedCards.map((card) => (
              <div
                key={card.id}
                className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between gap-3 shadow-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-700">
                    <CreditCard className="w-5 h-5 text-red-600" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <p className="text-xs font-black text-slate-900">{card.bank}</p>
                      {card.isDefault && (
                        <span className="text-[9px] font-black px-1.5 py-0.2 bg-emerald-100 text-emerald-800 rounded">
                          Default
                        </span>
                      )}
                    </div>
                    <p className="text-xs font-mono font-bold text-slate-600">{card.cardNumber}</p>
                    <p className="text-[10px] text-slate-400">Expires: {card.expiry} &bull; {card.cardType}</p>
                  </div>
                </div>

                <button
                  onClick={() => handleDeleteCard(card.id)}
                  className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition cursor-pointer"
                  title="Delete Card"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}

            {savedBankAccounts.map((bank) => (
              <div
                key={bank.id}
                className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between gap-3 shadow-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-700">
                    <Building2 className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-xs font-black text-slate-900">{bank.bankName}</p>
                    <p className="text-xs font-mono font-bold text-slate-600">{bank.accountNumber}</p>
                    <p className="text-[10px] text-slate-400">UPI: <span className="font-bold text-slate-700">{bank.upiId}</span></p>
                  </div>
                </div>

                <span className="text-[10px] font-black px-2 py-0.5 bg-blue-100 text-blue-800 rounded-full">
                  Verified
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Centralized Subscriptions Hub (OTT & WiseOne VIP) */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Crown className="w-5 h-5 text-amber-500" />
              <div>
                <h2 className="text-base font-black text-slate-900">
                  Subscriptions & OTT Hub
                </h2>
                <p className="text-xs text-slate-500 font-medium">
                  Manage WiseOne VIP, 1-Year Free Hyperlocal Connect, and OTT streaming passes
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsWiseOneModalOpen(true)}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-800 font-black text-xs transition cursor-pointer"
            >
              {wiseOneSubscription.isActive ? 'WiseOne Active' : 'Upgrade to WiseOne'}
            </button>
          </div>

          {/* OTT Subscriptions Grid */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                <Tv className="w-3.5 h-3.5 text-indigo-600" />
                <span>WiseStream OTT Entertainment Passes</span>
              </h3>

              <button
                onClick={() => setIsOTTModalOpen(true)}
                className="text-xs text-indigo-600 hover:text-indigo-800 font-bold cursor-pointer"
              >
                Open OTT Theater →
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {ottPlatforms.map((ott) => (
                <div
                  key={ott.name}
                  className={`p-3 rounded-2xl border text-center space-y-1 ${
                    ott.active
                      ? 'bg-indigo-50/60 border-indigo-200 text-indigo-950'
                      : 'bg-slate-50 border-slate-200 text-slate-700'
                  }`}
                >
                  <span className="text-xl">{ott.icon}</span>
                  <p className="text-[11px] font-bold truncate">{ott.name}</p>
                  <span
                    className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded-full inline-block ${
                      ott.active ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {ott.active ? 'Unlocked' : 'Free Preview'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Multi-Photo Gallery (Profile & Business Storefront Photos) */}
        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Camera className="w-4 h-4 text-red-600" />
              <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider">
                Photo Gallery (Multiple Profile & Business Pictures)
              </h2>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setActivePhotoTab('profile')}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition cursor-pointer ${
                  activePhotoTab === 'profile'
                    ? 'bg-red-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Personal Photos
              </button>
              <button
                onClick={() => setActivePhotoTab('business')}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition cursor-pointer ${
                  activePhotoTab === 'business'
                    ? 'bg-red-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Business Photos
              </button>
            </div>
          </div>

          {/* Photos Grid */}
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">
            {(activePhotoTab === 'profile'
              ? userPersonaProfile.profilePictures || [userPersonaProfile.avatar]
              : userPersonaProfile.businessPhotos || [
                  'https://images.unsplash.com/photo-1542838132-92c53300491e?w=300&auto=format&fit=crop&q=80',
                  'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=300&auto=format&fit=crop&q=80',
                ]
            ).map((imgUrl, idx) => (
              <div
                key={idx}
                className="relative aspect-square rounded-2xl overflow-hidden border border-slate-200 group shadow-xs"
              >
                <img
                  src={imgUrl}
                  alt={`Photo ${idx + 1}`}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <span className="absolute bottom-1 left-1 bg-slate-100/60 text-white text-[9px] font-bold px-1.5 py-0.5 rounded">
                  #{idx + 1}
                </span>
              </div>
            ))}

            {/* Add Photo Button */}
            <button
              onClick={() => setIsAddingPhoto(!isAddingPhoto)}
              className="aspect-square rounded-2xl border-2 border-dashed border-slate-200 hover:border-red-500 hover:bg-red-50/40 text-slate-400 hover:text-red-600 flex flex-col items-center justify-center gap-1 text-xs font-bold transition cursor-pointer"
            >
              <Plus className="w-5 h-5" />
              <span>Add Photo</span>
            </button>
          </div>

          {isAddingPhoto && (
            <form onSubmit={handleAddPhoto} className="flex items-center gap-2 pt-2 animate-in fade-in">
              <input
                type="url"
                value={newPhotoUrl}
                onChange={(e) => setNewPhotoUrl(e.target.value)}
                placeholder="Paste Image URL (https://...)"
                className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-red-500"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-red-600 text-white text-xs font-bold rounded-xl cursor-pointer hover:bg-red-700"
              >
                Upload
              </button>
            </form>
          )}
        </div>

        {/* Reward Points & Coins Banner */}
        <div className="bg-slate-50 border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gift className="w-5 h-5 text-red-600" />
              <div>
                <h2 className="text-base font-black text-slate-900">
                  SuperCoins & Reward Points
                </h2>
                <p className="text-xs text-slate-500 font-medium">
                  Earn +2 points for every store recommendation you share with friends
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-2xl font-black text-amber-600 flex items-center gap-1">
                  <Coins className="w-5 h-5 fill-amber-400 text-amber-500" />
                  {superCoinsBalance}
                </span>
                <span className="text-[10px] font-bold text-slate-500">SuperCoins</span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-200">
            <p className="text-xs text-slate-600 font-medium">
              🎁 10 Points = 5 Extra Free Seller Contacts (Save $1)
            </p>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsSuperCoinsModalOpen(true)}
                className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-800 font-black text-xs transition cursor-pointer"
              >
                SuperCoins Zone
              </button>
              <button
                onClick={handleRedeemPointsForQuota}
                className="px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs transition cursor-pointer shadow-xs"
              >
                Redeem 10 Points
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Direct Seller Payment QR Modal */}
      <DirectSellerPaymentModal
        seller={selectedSellerForQR}
        isOpen={isQRModalOpen}
        onClose={() => setIsQRModalOpen(false)}
      />
    </div>
  );
};
