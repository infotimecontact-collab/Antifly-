import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Plus,
  FolderHeart,
  Check,
  Lock,
  Globe,
  Users,
  Bell,
  TrendingDown,
  PackageCheck,
  Sparkles,
  Search,
  Tag,
  FileText,
  ThumbsUp,
  ThumbsDown,
} from 'lucide-react';
import { SaveCollection } from '../../types';

export const SaveToCollectionModal: React.FC = () => {
  const {
    isSaveToCollectionModalOpen,
    setIsSaveToCollectionModalOpen,
    pendingSaveItem,
    saveCollections,
    createSaveCollection,
    addItemToCollection,
    removeItemFromCollection,
    updateSavedItem,
    recordInterestFeedback,
    showToast,
  } = useApp();

  const [isCreatingCollection, setIsCreatingCollection] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newIsPrivate, setNewIsPrivate] = useState(true);
  const [newColorTheme, setNewColorTheme] = useState('from-amber-500 to-rose-600');
  const [searchQuery, setSearchQuery] = useState('');
  const [notes, setNotes] = useState(pendingSaveItem?.notes || '');
  const [notifyPriceDrop, setNotifyPriceDrop] = useState(pendingSaveItem?.notifyPriceDrop ?? true);
  const [notifyRestock, setNotifyRestock] = useState(pendingSaveItem?.notifyRestock ?? true);
  const [notifyNewPosts, setNotifyNewPosts] = useState(pendingSaveItem?.notifyNewPosts ?? true);

  // Sync notes & notification state when pending item changes
  React.useEffect(() => {
    if (pendingSaveItem) {
      setNotes(pendingSaveItem.notes || '');
      setNotifyPriceDrop(pendingSaveItem.notifyPriceDrop ?? true);
      setNotifyRestock(pendingSaveItem.notifyRestock ?? true);
      setNotifyNewPosts(pendingSaveItem.notifyNewPosts ?? true);
    }
  }, [pendingSaveItem]);

  if (!isSaveToCollectionModalOpen || !pendingSaveItem) {
    return null;
  }

  const handleToggleCollection = (colId: string) => {
    const isMember = pendingSaveItem.collectionIds.includes(colId);
    if (isMember) {
      removeItemFromCollection(pendingSaveItem.id, colId);
    } else {
      addItemToCollection(pendingSaveItem.id, colId);
    }
  };

  const handleCreateCollection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const newCol = createSaveCollection({
      title: newTitle.trim(),
      description: newDesc.trim(),
      isPrivate: newIsPrivate,
      isShared: !newIsPrivate,
      colorTheme: newColorTheme,
      coverImage: pendingSaveItem.imageUrl || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&auto=format&fit=crop&q=80',
    });

    // Auto-add current item to new collection
    addItemToCollection(pendingSaveItem.id, newCol.id);

    setNewTitle('');
    setNewDesc('');
    setIsCreatingCollection(false);
  };

  const handleSavePreferences = () => {
    updateSavedItem(pendingSaveItem.id, {
      notes,
      notifyPriceDrop,
      notifyRestock,
      notifyNewPosts,
    });
    setIsSaveToCollectionModalOpen(false);
  };

  const filteredCollections = saveCollections.filter((c) =>
    c.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const themeOptions = [
    { label: 'Amber Rose', value: 'from-amber-500 to-rose-600', preview: 'bg-gradient-to-r from-amber-500 to-rose-600' },
    { label: 'Emerald Teal', value: 'from-emerald-500 to-teal-700', preview: 'bg-gradient-to-r from-emerald-500 to-teal-700' },
    { label: 'Royal Indigo', value: 'from-blue-600 to-indigo-800', preview: 'bg-gradient-to-r from-blue-600 to-indigo-800' },
    { label: 'Purple Pink', value: 'from-purple-500 to-pink-600', preview: 'bg-gradient-to-r from-purple-500 to-pink-600' },
    { label: 'Slate Luxury', value: 'from-slate-700 to-slate-950', preview: 'bg-gradient-to-r from-slate-700 to-slate-950' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-white/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
      <div
        className="bg-white dark:bg-slate-900 w-full sm:max-w-lg rounded-t-[32px] sm:rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 max-h-[92vh] flex flex-col overflow-hidden animate-in slide-in-from-bottom-6 duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 dark:bg-amber-950/40 text-amber-600 flex items-center justify-center font-bold">
              <FolderHeart className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-slate-900 dark:text-white">Save to Collection</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">Organize your saved vault & preferences</p>
            </div>
          </div>

          <button
            onClick={() => setIsSaveToCollectionModalOpen(false)}
            className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-5 flex-1">
          {/* Target Item Preview Card */}
          <div className="flex items-center gap-3.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
            {pendingSaveItem.imageUrl ? (
              <img
                src={pendingSaveItem.imageUrl}
                alt={pendingSaveItem.title}
                className="w-14 h-14 rounded-xl object-cover shadow-xs border border-slate-200 dark:border-slate-700"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-14 h-14 rounded-xl bg-amber-100 text-amber-700 font-bold flex items-center justify-center text-xs">
                {pendingSaveItem.itemType.toUpperCase()}
              </div>
            )}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-md bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-300 text-[10px] font-black uppercase tracking-wider">
                  {pendingSaveItem.itemType}
                </span>
                {pendingSaveItem.badge && (
                  <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400">
                    {pendingSaveItem.badge}
                  </span>
                )}
              </div>
              <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white truncate mt-0.5">
                {pendingSaveItem.title}
              </h3>
              {pendingSaveItem.subtitle && (
                <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                  {pendingSaveItem.subtitle}
                </p>
              )}
              {pendingSaveItem.price !== undefined && (
                <div className="flex items-center gap-2 mt-1">
                  <span className="font-black text-xs text-slate-900 dark:text-white">
                    ₹{pendingSaveItem.price.toLocaleString('en-IN')}
                  </span>
                  {pendingSaveItem.originalPrice && (
                    <span className="text-[11px] text-slate-400 line-through">
                      ₹{pendingSaveItem.originalPrice.toLocaleString('en-IN')}
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Search or Create Collection Bar */}
          {!isCreatingCollection && (
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Filter collections..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500/30"
                />
              </div>
              <button
                type="button"
                onClick={() => setIsCreatingCollection(true)}
                className="flex items-center gap-1.5 px-3 py-2 bg-amber-500 hover:bg-amber-600 text-slate-800 font-black text-xs rounded-xl shadow-xs transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>New</span>
              </button>
            </div>
          )}

          {/* New Collection Form */}
          {isCreatingCollection && (
            <form
              onSubmit={handleCreateCollection}
              className="p-4 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/50 space-y-3 animate-in fade-in duration-150"
            >
              <div className="flex items-center justify-between">
                <h4 className="font-black text-xs text-amber-900 dark:text-amber-300 uppercase tracking-wider">
                  Create New Collection
                </h4>
                <button
                  type="button"
                  onClick={() => setIsCreatingCollection(false)}
                  className="text-xs text-slate-500 hover:text-slate-800 font-bold"
                >
                  Cancel
                </button>
              </div>

              <div>
                <input
                  type="text"
                  required
                  placeholder="Collection Name (e.g., Diwali Shopping, Wedding Outfits)..."
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500/30"
                />
              </div>

              <div>
                <input
                  type="text"
                  placeholder="Optional description / theme notes..."
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none"
                />
              </div>

              {/* Color Theme Selector */}
              <div>
                <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1 block">
                  Moodboard Gradient
                </label>
                <div className="flex items-center gap-2">
                  {themeOptions.map((opt) => (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setNewColorTheme(opt.value)}
                      className={`w-6 h-6 rounded-full ${opt.preview} transition-transform cursor-pointer ${
                        newColorTheme === opt.value ? 'ring-2 ring-slate-900 dark:ring-white scale-110 shadow-sm' : 'opacity-70 hover:opacity-100'
                      }`}
                      title={opt.label}
                    />
                  ))}
                </div>
              </div>

              {/* Privacy Toggle */}
              <div className="flex items-center gap-4 pt-1 text-xs">
                <label className="flex items-center gap-1.5 font-bold text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="radio"
                    name="privacy"
                    checked={newIsPrivate}
                    onChange={() => setNewIsPrivate(true)}
                    className="text-amber-600"
                  />
                  <Lock className="w-3 h-3 text-slate-500" />
                  <span>Private</span>
                </label>
                <label className="flex items-center gap-1.5 font-bold text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="radio"
                    name="privacy"
                    checked={!newIsPrivate}
                    onChange={() => setNewIsPrivate(false)}
                    className="text-amber-600"
                  />
                  <Users className="w-3 h-3 text-slate-500" />
                  <span>Shared with Friends</span>
                </label>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-slate-800 font-black text-xs rounded-xl shadow-xs transition cursor-pointer"
              >
                Create & Add Item
              </button>
            </form>
          )}

          {/* Collections List */}
          <div>
            <label className="text-xs font-black text-slate-700 dark:text-slate-300 mb-2 block uppercase tracking-wider">
              Select Collections ({saveCollections.length})
            </label>

            <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
              {filteredCollections.map((col) => {
                const isSelected = pendingSaveItem.collectionIds.includes(col.id);

                return (
                  <div
                    key={col.id}
                    onClick={() => handleToggleCollection(col.id)}
                    className={`flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer select-none ${
                      isSelected
                        ? 'bg-amber-50/80 dark:bg-amber-950/40 border-amber-400 dark:border-amber-700 text-amber-950 dark:text-amber-100 shadow-xs'
                        : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700/80 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className={`w-9 h-9 rounded-xl bg-gradient-to-tr ${col.colorTheme || 'from-amber-500 to-rose-600'} text-white flex items-center justify-center font-bold text-xs shadow-xs`}
                      >
                        <FolderHeart className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <p className="font-bold text-xs truncate">{col.title}</p>
                          {col.isPrivate ? (
                            <Lock className="w-2.5 h-2.5 text-slate-400" />
                          ) : (
                            <Users className="w-2.5 h-2.5 text-indigo-400" />
                          )}
                        </div>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400">
                          {col.itemCount} items saved
                        </p>
                      </div>
                    </div>

                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                        isSelected
                          ? 'bg-amber-500 text-slate-800 shadow-xs scale-105'
                          : 'border-2 border-slate-300 dark:border-slate-600'
                      }`}
                    >
                      {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </div>
                  </div>
                );
              })}

              {filteredCollections.length === 0 && (
                <div className="text-center py-6 text-xs text-slate-500">
                  No collections match "{searchQuery}". Create one above!
                </div>
              )}
            </div>
          </div>

          {/* Personal Note */}
          <div>
            <label className="flex items-center gap-1 text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              <FileText className="w-3.5 h-3.5 text-amber-600" />
              <span>Personal Private Notes</span>
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Size M fits well, check for weekend flash sale, bargaining note..."
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500/30"
            />
          </div>

          {/* Smart Alerts & Notification Controls */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2.5">
            <h4 className="text-[11px] font-black text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Bell className="w-3.5 h-3.5 text-red-500" />
              <span>Smart Notification Alerts</span>
            </h4>

            {pendingSaveItem.itemType === 'product' && (
              <>
                <label className="flex items-center justify-between text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                  <div className="flex items-center gap-2">
                    <TrendingDown className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Price Drop Alerts</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={notifyPriceDrop}
                    onChange={(e) => setNotifyPriceDrop(e.target.checked)}
                    className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
                  />
                </label>

                <label className="flex items-center justify-between text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                  <div className="flex items-center gap-2">
                    <PackageCheck className="w-3.5 h-3.5 text-blue-600" />
                    <span>Back in Stock Alerts</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={notifyRestock}
                    onChange={(e) => setNotifyRestock(e.target.checked)}
                    className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
                  />
                </label>
              </>
            )}

            {(pendingSaveItem.itemType === 'seller' || pendingSaveItem.itemType === 'user') && (
              <label className="flex items-center justify-between text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                  <span>New Posts, Stories & Deals Alert</span>
                </div>
                <input
                  type="checkbox"
                  checked={notifyNewPosts}
                  onChange={(e) => setNotifyNewPosts(e.target.checked)}
                  className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
                />
              </label>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 sm:p-5 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between gap-3">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => {
                recordInterestFeedback(pendingSaveItem.targetId, pendingSaveItem.itemType, pendingSaveItem.title, 'interested');
                showToast(`⭐ Tuned feed: Interested in ${pendingSaveItem.title}`);
              }}
              title="Interested - Boost similar recommendations"
              className="p-2 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-xl transition flex items-center gap-1 text-xs font-bold cursor-pointer"
            >
              <ThumbsUp className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Boost</span>
            </button>
            <button
              type="button"
              onClick={() => {
                recordInterestFeedback(pendingSaveItem.targetId, pendingSaveItem.itemType, pendingSaveItem.title, 'not_interested', 'not_relevant');
                showToast(`👍 Tuned feed: Showing less like ${pendingSaveItem.title}`);
              }}
              title="Not Interested - Reduce similar recommendations"
              className="p-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition flex items-center gap-1 text-xs font-bold cursor-pointer"
            >
              <ThumbsDown className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Reduce</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsSaveToCollectionModalOpen(false)}
              className="px-4 py-2.5 text-xs font-bold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition cursor-pointer"
            >
              Close
            </button>
            <button
              type="button"
              onClick={handleSavePreferences}
              className="px-5 py-2.5 bg-slate-900 dark:bg-amber-500 hover:bg-slate-800 dark:hover:bg-amber-600 text-white dark:text-slate-800 font-black text-xs rounded-2xl shadow-md transition cursor-pointer"
            >
              Done & Save
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
