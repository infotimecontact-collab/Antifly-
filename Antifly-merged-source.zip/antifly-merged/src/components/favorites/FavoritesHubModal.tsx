import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Bookmark,
  Heart,
  FolderHeart,
  Search,
  SlidersHorizontal,
  Grid,
  List,
  Sparkles,
  ShoppingBag,
  Store,
  User,
  Film,
  MessageSquare,
  FileText,
  Bell,
  Trash2,
  Share2,
  ExternalLink,
  Plus,
  Lock,
  Users,
  CheckCircle2,
  TrendingDown,
  PackageCheck,
  TrendingUp,
  X,
  MoreVertical,
  ThumbsUp,
  ThumbsDown,
  ArrowRight,
  Filter,
  CheckSquare,
  Square,
  Download,
  AlertCircle,
  Tag,
  Zap,
} from 'lucide-react';
import { SaveItemType, UniversalSaveItem, SaveCollection } from '../../types';
import { UniversalSaveButton } from './UniversalSaveButton';

export const FavoritesHubModal: React.FC = () => {
  const {
    isFavoritesHubOpen,
    setIsFavoritesHubOpen,
    savedItems,
    saveCollections,
    interestFeedbacks,
    savedSearches,
    activeFavoritesTab,
    setActiveFavoritesTab,
    removeSavedItem,
    openSaveToCollectionModal,
    createSaveCollection,
    deleteSaveCollection,
    recordInterestFeedback,
    removeSavedSearch,
    addToCart,
    openStoreCommunity,
    openStoreChat,
    openReelPlayer,
    shortVideoReels,
    setSelectedCategorySlug,
    setSearchQuery: setGlobalSearchQuery,
    setWebsiteMainTab,
    showToast,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCollectionId, setSelectedCollectionId] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'recent' | 'price-low' | 'price-high' | 'type'>('recent');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>([]);
  const [isBatchMode, setIsBatchMode] = useState(false);
  const [activeCollectionDetail, setActiveCollectionDetail] = useState<SaveCollection | null>(null);
  const [isCreatingCollection, setIsCreatingCollection] = useState(false);
  const [newColTitle, setNewColTitle] = useState('');
  const [newColDesc, setNewColDesc] = useState('');
  const [newColPrivacy, setNewColPrivacy] = useState(true);
  const [newColGradient, setNewColGradient] = useState('from-amber-500 to-rose-600');

  // Navigation tab definitions
  const tabs: { id: string; label: string; icon: React.ReactNode; count: number }[] = [
    { id: 'all', label: 'All Saved', icon: <Bookmark className="w-4 h-4" />, count: savedItems.length },
    {
      id: 'products',
      label: 'Products & Deals',
      icon: <ShoppingBag className="w-4 h-4" />,
      count: savedItems.filter((i) => i.itemType === 'product' || i.itemType === 'deal').length,
    },
    {
      id: 'sellers',
      label: 'Stores & Sellers',
      icon: <Store className="w-4 h-4" />,
      count: savedItems.filter((i) => i.itemType === 'seller').length,
    },
    {
      id: 'creators',
      label: 'People & Creators',
      icon: <User className="w-4 h-4" />,
      count: savedItems.filter((i) => i.itemType === 'user').length,
    },
    {
      id: 'reels',
      label: 'Reels & Videos',
      icon: <Film className="w-4 h-4" />,
      count: savedItems.filter((i) => i.itemType === 'reel').length,
    },
    {
      id: 'posts',
      label: 'Posts & Stories',
      icon: <FileText className="w-4 h-4" />,
      count: savedItems.filter((i) => i.itemType === 'post' || i.itemType === 'story').length,
    },
    {
      id: 'chats',
      label: 'Chats & Bargains',
      icon: <MessageSquare className="w-4 h-4" />,
      count: savedItems.filter((i) => i.itemType === 'chat').length,
    },
    {
      id: 'collections',
      label: 'Collections',
      icon: <FolderHeart className="w-4 h-4" />,
      count: saveCollections.length,
    },
    {
      id: 'searches',
      label: 'Saved Searches',
      icon: <Search className="w-4 h-4" />,
      count: savedSearches.length,
    },
    {
      id: 'ai-tuning',
      label: 'AI Personalization',
      icon: <Sparkles className="w-4 h-4 text-purple-500" />,
      count: interestFeedbacks.length,
    },
  ];

  // Filtering & sorting logic
  const filteredItems = useMemo(() => {
    return savedItems
      .filter((item) => {
        // Tab filter
        if (activeFavoritesTab === 'products') {
          if (item.itemType !== 'product' && item.itemType !== 'deal') return false;
        } else if (activeFavoritesTab === 'sellers') {
          if (item.itemType !== 'seller') return false;
        } else if (activeFavoritesTab === 'creators') {
          if (item.itemType !== 'user') return false;
        } else if (activeFavoritesTab === 'reels') {
          if (item.itemType !== 'reel') return false;
        } else if (activeFavoritesTab === 'posts') {
          if (item.itemType !== 'post' && item.itemType !== 'story') return false;
        } else if (activeFavoritesTab === 'chats') {
          if (item.itemType !== 'chat') return false;
        }

        // Collection filter
        if (selectedCollectionId !== 'all') {
          if (!item.collectionIds.includes(selectedCollectionId)) return false;
        }

        // Search filter
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = item.title.toLowerCase().includes(q);
          const matchSub = item.subtitle?.toLowerCase().includes(q);
          const matchNotes = item.notes?.toLowerCase().includes(q);
          const matchTags = item.tags?.some((t) => t.toLowerCase().includes(q));
          if (!matchTitle && !matchSub && !matchNotes && !matchTags) return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price-low') {
          return (a.price || 0) - (b.price || 0);
        }
        if (sortBy === 'price-high') {
          return (b.price || 0) - (a.price || 0);
        }
        if (sortBy === 'type') {
          return a.itemType.localeCompare(b.itemType);
        }
        // default recent
        return new Date(b.savedAt).getTime() - new Date(a.savedAt).getTime();
      });
  }, [savedItems, activeFavoritesTab, selectedCollectionId, searchQuery, sortBy]);

  if (!isFavoritesHubOpen) return null;

  const handleCreateCollectionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newColTitle.trim()) return;

    createSaveCollection({
      title: newColTitle.trim(),
      description: newColDesc.trim(),
      isPrivate: newColPrivacy,
      isShared: !newColPrivacy,
      colorTheme: newColGradient,
    });

    setNewColTitle('');
    setNewColDesc('');
    setIsCreatingCollection(false);
  };

  const handleBatchDelete = () => {
    selectedItemIds.forEach((id) => removeSavedItem(id));
    setSelectedItemIds([]);
    setIsBatchMode(false);
    showToast(`Deleted ${selectedItemIds.length} items from vault`);
  };

  const handleSelectAll = () => {
    if (selectedItemIds.length === filteredItems.length) {
      setSelectedItemIds([]);
    } else {
      setSelectedItemIds(filteredItems.map((i) => i.id));
    }
  };

  const handleReplaySearch = (search: any) => {
    setIsFavoritesHubOpen(false);
    setGlobalSearchQuery(search.query);
    if (search.categorySlug) {
      setSelectedCategorySlug(search.categorySlug);
    }
    setWebsiteMainTab('search');
  };

  const handleActionClick = (item: UniversalSaveItem) => {
    if (item.itemType === 'product') {
      addToCart({
        productId: item.targetId,
        quantity: 1,
        title: item.title,
        price: item.price || 999,
        image: item.imageUrl || '',
        category: 'Fashion',
      });
      showToast(`🛒 Added "${item.title}" to Shopping Bag`);
    } else if (item.itemType === 'seller') {
      setIsFavoritesHubOpen(false);
      openStoreCommunity(item.targetId);
    } else if (item.itemType === 'chat') {
      setIsFavoritesHubOpen(false);
      openStoreChat();
    } else if (item.itemType === 'reel') {
      const reel = shortVideoReels?.find((r) => r.id === item.targetId) || shortVideoReels?.[0];
      if (reel) openReelPlayer(reel);
    } else if (item.itemType === 'category') {
      setIsFavoritesHubOpen(false);
      if (item.metadata?.categorySlug) {
        setSelectedCategorySlug(item.metadata.categorySlug);
      }
      setWebsiteMainTab('search');
    }
  };

  return (
    <div
      id="universal-saved-vault-modal"
      className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 md:p-6 animate-in fade-in duration-200 select-none"
    >
      <div className="bg-white dark:bg-slate-900 w-full max-w-6xl h-[94vh] rounded-[32px] shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Top Header Bar */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-white dark:bg-slate-900 z-10">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500 to-rose-500 text-slate-800 font-black flex items-center justify-center shadow-lg shadow-amber-500/20">
              <Bookmark className="w-6 h-6 fill-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white tracking-tight">
                  Saved Vault & Collections
                </h1>
                <span className="px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900/60 text-amber-900 dark:text-amber-200 text-xs font-black">
                  {savedItems.length} Saved
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Your universal bookmarking, custom moodboards, and AI personalization hub
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Batch Selection Mode Toggle */}
            <button
              onClick={() => {
                setIsBatchMode(!isBatchMode);
                setSelectedItemIds([]);
              }}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                isBatchMode
                  ? 'bg-red-50 text-red-600 border border-red-200'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
              }`}
            >
              <CheckSquare className="w-4 h-4" />
              <span className="hidden sm:inline">{isBatchMode ? 'Cancel Selection' : 'Select'}</span>
            </button>

            {/* Close Button */}
            <button
              onClick={() => setIsFavoritesHubOpen(false)}
              className="p-2.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Segmented Horizontal Navigation Strip */}
        <div className="px-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-white/40 overflow-x-auto scrollbar-none flex items-center gap-1.5 py-2">
          {tabs.map((tab) => {
            const isActive = activeFavoritesTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveFavoritesTab(tab.id);
                  setActiveCollectionDetail(null);
                }}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs font-black transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-800 shadow-md scale-[1.02]'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200/60 dark:hover:bg-slate-800'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
                <span
                  className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                    isActive
                      ? 'bg-white/20 dark:bg-slate-900/20 text-white dark:text-slate-800'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Filter, Collection Selector & Search Bar */}
        {activeFavoritesTab !== 'ai-tuning' && activeFavoritesTab !== 'searches' && (
          <div className="p-3 sm:px-5 sm:py-3 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2.5 bg-white dark:bg-slate-900 text-xs">
            <div className="flex items-center gap-2 flex-1 min-w-[240px]">
              {/* Internal Search */}
              <div className="relative flex-1 max-w-sm">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search saved items, tags, notes..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                />
              </div>

              {/* Filter by Collection Dropdown */}
              {activeFavoritesTab !== 'collections' && (
                <div className="relative">
                  <select
                    value={selectedCollectionId}
                    onChange={(e) => setSelectedCollectionId(e.target.value)}
                    className="pl-3 pr-8 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-700 dark:text-slate-300 focus:outline-none cursor-pointer appearance-none"
                  >
                    <option value="all">All Collections ({saveCollections.length})</option>
                    {saveCollections.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.title} ({c.itemCount})
                      </option>
                    ))}
                  </select>
                  <Filter className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              {/* Sort By Dropdown */}
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-700 dark:text-slate-300 focus:outline-none cursor-pointer text-xs"
              >
                <option value="recent">Recently Saved</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="type">Item Category</option>
              </select>

              {/* View Toggle */}
              <div className="flex items-center border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden bg-slate-50 dark:bg-slate-800">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 transition cursor-pointer ${
                    viewMode === 'grid'
                      ? 'bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-800 font-bold'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                  title="Grid View"
                >
                  <Grid className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 transition cursor-pointer ${
                    viewMode === 'list'
                      ? 'bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-800 font-bold'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                  title="List View"
                >
                  <List className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Batch Operations Bar (if active) */}
        {isBatchMode && (
          <div className="p-3 px-5 bg-amber-50 dark:bg-amber-950/40 border-b border-amber-200 dark:border-amber-900/40 flex items-center justify-between text-xs animate-in fade-in">
            <div className="flex items-center gap-3">
              <button
                onClick={handleSelectAll}
                className="flex items-center gap-1.5 font-bold text-amber-900 dark:text-amber-200 hover:underline cursor-pointer"
              >
                {selectedItemIds.length === filteredItems.length ? (
                  <CheckSquare className="w-4 h-4 text-amber-600" />
                ) : (
                  <Square className="w-4 h-4 text-slate-400" />
                )}
                <span>Select All ({filteredItems.length})</span>
              </button>
              <span className="text-amber-800 dark:text-amber-300 font-semibold">
                {selectedItemIds.length} items selected
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                disabled={selectedItemIds.length === 0}
                onClick={handleBatchDelete}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 disabled:opacity-40 text-white font-black rounded-xl transition flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Selected</span>
              </button>
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-50/50 dark:bg-white/20">
          {/* VIEW 1: COLLECTIONS TAB */}
          {activeFavoritesTab === 'collections' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-black text-sm sm:text-base text-slate-900 dark:text-white">
                    Custom Collections & Moodboards
                  </h3>
                  <p className="text-xs text-slate-500">
                    Group mixed items (products, sellers, reels, chats) into themed boards
                  </p>
                </div>
                <button
                  onClick={() => setIsCreatingCollection(true)}
                  className="px-4 py-2 bg-gradient-to-r from-amber-500 to-rose-600 hover:brightness-110 text-slate-800 font-black text-xs rounded-2xl shadow-md flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Create Collection</span>
                </button>
              </div>

              {/* Create Collection Modal / Inline Card */}
              {isCreatingCollection && (
                <form
                  onSubmit={handleCreateCollectionSubmit}
                  className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-700 shadow-xl space-y-4 max-w-xl animate-in zoom-in-95"
                >
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                    <h4 className="font-black text-sm text-slate-900 dark:text-white flex items-center gap-2">
                      <FolderHeart className="w-4 h-4 text-amber-600" />
                      <span>New Themed Collection</span>
                    </h4>
                    <button
                      type="button"
                      onClick={() => setIsCreatingCollection(false)}
                      className="text-xs font-bold text-slate-400 hover:text-slate-700"
                    >
                      Cancel
                    </button>
                  </div>

                  <input
                    type="text"
                    required
                    placeholder="Collection Name (e.g., Festive Wardrobe, Grocery Essentials)..."
                    value={newColTitle}
                    onChange={(e) => setNewColTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white focus:outline-none"
                  />

                  <textarea
                    rows={2}
                    placeholder="Description / notes for collaborators..."
                    value={newColDesc}
                    onChange={(e) => setNewColDesc(e.target.value)}
                    className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none"
                  />

                  <div className="flex items-center justify-between pt-2">
                    <div className="flex items-center gap-3 text-xs">
                      <label className="flex items-center gap-1.5 font-bold cursor-pointer text-slate-700 dark:text-slate-300">
                        <input
                          type="radio"
                          name="coll-priv"
                          checked={newColPrivacy}
                          onChange={() => setNewColPrivacy(true)}
                        />
                        <Lock className="w-3.5 h-3.5 text-slate-400" />
                        <span>Private</span>
                      </label>
                      <label className="flex items-center gap-1.5 font-bold cursor-pointer text-slate-700 dark:text-slate-300">
                        <input
                          type="radio"
                          name="coll-priv"
                          checked={!newColPrivacy}
                          onChange={() => setNewColPrivacy(false)}
                        />
                        <Users className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Shared with Friends</span>
                      </label>
                    </div>

                    <button
                      type="submit"
                      className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-800 font-black text-xs rounded-xl shadow-xs transition cursor-pointer"
                    >
                      Save Collection
                    </button>
                  </div>
                </form>
              )}

              {/* Collections Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {saveCollections.map((col) => {
                  const collectionItems = savedItems.filter((i) => i.collectionIds.includes(col.id));

                  return (
                    <div
                      key={col.id}
                      onClick={() => {
                        setSelectedCollectionId(col.id);
                        setActiveFavoritesTab('all');
                      }}
                      className="group bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden cursor-pointer flex flex-col"
                    >
                      {/* Gradient Header / Cover Collage */}
                      <div className={`h-36 bg-gradient-to-tr ${col.colorTheme || 'from-amber-500 to-rose-600'} p-4 flex flex-col justify-between relative overflow-hidden text-white`}>
                        <div className="flex items-center justify-between z-10">
                          <div className="w-8 h-8 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center font-black">
                            <FolderHeart className="w-4 h-4" />
                          </div>
                          <div className="flex items-center gap-1.5">
                            {col.isPrivate ? (
                              <span className="px-2 py-0.5 rounded-md bg-slate-100/30 backdrop-blur-md text-[10px] font-black flex items-center gap-1">
                                <Lock className="w-2.5 h-2.5" /> Private
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-md bg-white/30 backdrop-blur-md text-[10px] font-black flex items-center gap-1">
                                <Users className="w-2.5 h-2.5" /> Shared
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="z-10">
                          <h4 className="font-black text-base drop-shadow-xs line-clamp-1">{col.title}</h4>
                          <p className="text-[11px] text-white/80 font-medium">
                            {col.itemCount} items saved • Click to explore
                          </p>
                        </div>

                        {/* Background Thumbnail Preview Collages */}
                        {col.previewImages && col.previewImages.length > 0 && (
                          <div className="absolute right-2 -bottom-4 flex gap-1 opacity-40 group-hover:opacity-70 group-hover:scale-105 transition-all">
                            {col.previewImages.slice(0, 3).map((img, i) => (
                              <img
                                key={i}
                                src={img}
                                alt="preview"
                                className="w-14 h-20 rounded-xl object-cover shadow-lg border border-white/20"
                                referrerPolicy="no-referrer"
                              />
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Collection Details */}
                      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                        <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                          {col.description || 'Custom collection of handpicked items.'}
                        </p>

                        {/* Tags */}
                        {col.tags && col.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {col.tags.map((tag) => (
                              <span
                                key={tag}
                                className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] font-bold text-slate-600 dark:text-slate-400"
                              >
                                #{tag}
                              </span>
                            ))}
                          </div>
                        )}

                        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                          <span className="font-bold text-amber-600 flex items-center gap-1">
                            <span>Open Board</span>
                            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                          </span>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteSaveCollection(col.id);
                            }}
                            title="Delete Collection"
                            className="p-1 text-slate-400 hover:text-rose-600 transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* VIEW 2: SAVED SEARCHES TAB */}
          {activeFavoritesTab === 'searches' && (
            <div className="space-y-4 max-w-3xl mx-auto">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-black text-base text-slate-900 dark:text-white">
                    Saved Search Queries & Instant Alerts
                  </h3>
                  <p className="text-xs text-slate-500">
                    Get alerted when new products, stores or services match your searches
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {savedSearches.map((search) => (
                  <div
                    key={search.id}
                    className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-600 flex items-center justify-center font-bold">
                        <Search className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white truncate">
                          "{search.query}"
                        </h4>
                        <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-500">
                          {search.categorySlug && (
                            <span className="capitalize text-amber-600 font-bold">
                              Category: {search.categorySlug}
                            </span>
                          )}
                          <span>• {search.lastResultsCount || 12} items matched</span>
                          <span>• Saved {new Date(search.savedAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleReplaySearch(search)}
                        className="px-3.5 py-2 bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-800 font-black text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Search Now</span>
                      </button>
                      <button
                        onClick={() => removeSavedSearch(search.id)}
                        className="p-2 text-slate-400 hover:text-rose-600 transition rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        title="Remove saved search"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}

                {savedSearches.length === 0 && (
                  <div className="text-center py-12 text-slate-500">
                    <Search className="w-10 h-10 mx-auto mb-2 text-slate-300" />
                    <p className="text-sm font-bold">No saved search alerts yet</p>
                    <p className="text-xs">Search anything in the main bar and tap "Save Search" to get auto-alerts.</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* VIEW 3: AI PERSONALIZATION & RECOMMENDATION TUNER TAB */}
          {activeFavoritesTab === 'ai-tuning' && (
            <div className="space-y-5 max-w-3xl mx-auto">
              <div className="p-5 rounded-3xl bg-gradient-to-r from-purple-900 to-indigo-950 text-white shadow-xl space-y-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-amber-400" />
                  <h3 className="font-black text-base">Algorithmic Preference Tuning</h3>
                </div>
                <p className="text-xs text-purple-200">
                  Every time you tap <strong>"Interested"</strong> or <strong>"Not Interested"</strong> on a product, seller, story, or video, our discovery engine dynamically tunes your feed weights. You have full transparency and control over your recommendation parameters below.
                </p>
              </div>

              <div className="space-y-3">
                <h4 className="font-black text-xs text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  Recent Personalization Adjustments ({interestFeedbacks.length})
                </h4>

                {interestFeedbacks.map((fb) => (
                  <div
                    key={fb.id}
                    className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-start justify-between gap-4"
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs ${
                          fb.feedback === 'interested'
                            ? 'bg-emerald-100 text-emerald-700'
                            : 'bg-rose-100 text-rose-700'
                        }`}
                      >
                        {fb.feedback === 'interested' ? (
                          <ThumbsUp className="w-4 h-4" />
                        ) : (
                          <ThumbsDown className="w-4 h-4" />
                        )}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                              fb.feedback === 'interested'
                                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                : 'bg-rose-50 text-rose-800 border border-rose-200'
                            }`}
                          >
                            {fb.feedback === 'interested' ? 'Interested (Boosted)' : 'Not Interested'}
                          </span>
                          <span className="text-xs font-bold text-slate-900 dark:text-white">
                            {fb.targetTitle}
                          </span>
                        </div>

                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 font-medium">
                          ⚡ {fb.appliedPersonalizationEffect}
                        </p>

                        {fb.reason && (
                          <p className="text-[11px] text-slate-400 mt-0.5">
                            Reason: {fb.reason.replace(/_/g, ' ')}
                          </p>
                        )}
                      </div>
                    </div>

                    <span className="text-[10px] text-slate-400 whitespace-nowrap">
                      {new Date(fb.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* VIEW 4: DEFAULT ITEMS GRID / LIST (ALL, PRODUCTS, SELLERS, REELS, CHATS, POSTS) */}
          {activeFavoritesTab !== 'collections' &&
            activeFavoritesTab !== 'searches' &&
            activeFavoritesTab !== 'ai-tuning' && (
              <div>
                {/* Active Collection Filter Pill */}
                {selectedCollectionId !== 'all' && (
                  <div className="mb-4 flex items-center gap-2">
                    <span className="text-xs text-slate-500 font-medium">Filtered by Collection:</span>
                    <span className="px-3 py-1 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-200 text-xs font-black flex items-center gap-1.5">
                      <FolderHeart className="w-3.5 h-3.5 text-amber-600" />
                      <span>{saveCollections.find((c) => c.id === selectedCollectionId)?.title}</span>
                      <button
                        onClick={() => setSelectedCollectionId('all')}
                        className="hover:text-rose-600 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </span>
                  </div>
                )}

                {/* Items Container */}
                {viewMode === 'grid' ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {filteredItems.map((item) => {
                      const isSelected = selectedItemIds.includes(item.id);

                      return (
                        <div
                          key={item.id}
                          onClick={() => {
                            if (isBatchMode) {
                              if (isSelected) {
                                setSelectedItemIds(selectedItemIds.filter((id) => id !== item.id));
                              } else {
                                setSelectedItemIds([...selectedItemIds, item.id]);
                              }
                            }
                          }}
                          className={`group bg-white dark:bg-slate-900 rounded-3xl border transition-all duration-300 overflow-hidden flex flex-col justify-between shadow-xs hover:shadow-xl relative ${
                            isSelected
                              ? 'border-amber-500 ring-2 ring-amber-400'
                              : 'border-slate-200/80 dark:border-slate-800 hover:border-amber-300'
                          }`}
                        >
                          {/* Top Image & Micro-Badges */}
                          <div className="relative aspect-4/3 overflow-hidden bg-slate-100 dark:bg-slate-800">
                            {item.imageUrl ? (
                              <img
                                src={item.imageUrl}
                                alt={item.title}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center font-black text-slate-400 text-sm">
                                {item.itemType.toUpperCase()}
                              </div>
                            )}

                            {/* Item Type Badge */}
                            <div className="absolute top-3 left-3 flex items-center gap-1.5 z-10">
                              <span className="px-2.5 py-1 rounded-xl bg-white/80 backdrop-blur-md text-white text-[10px] font-black uppercase tracking-wider shadow-sm">
                                {item.itemType}
                              </span>
                              {item.badge && (
                                <span className="px-2.5 py-1 rounded-xl bg-amber-500 text-slate-800 text-[10px] font-black shadow-sm">
                                  {item.badge}
                                </span>
                              )}
                            </div>

                            {/* Save Button */}
                            <div className="absolute top-3 right-3 z-10">
                              <UniversalSaveButton
                                targetId={item.targetId}
                                itemType={item.itemType}
                                title={item.title}
                                subtitle={item.subtitle}
                                imageUrl={item.imageUrl}
                                price={item.price}
                                originalPrice={item.originalPrice}
                                size="sm"
                              />
                            </div>

                            {/* Batch Select Checkbox */}
                            {isBatchMode && (
                              <div className="absolute inset-0 bg-slate-100/40 flex items-center justify-center z-20">
                                <div
                                  className={`w-7 h-7 rounded-xl flex items-center justify-center transition-all ${
                                    isSelected
                                      ? 'bg-amber-500 text-slate-800 scale-110 shadow-lg'
                                      : 'border-2 border-white bg-slate-100/50 text-white'
                                  }`}
                                >
                                  {isSelected && <CheckCircle2 className="w-5 h-5" />}
                                </div>
                              </div>
                            )}
                          </div>

                          {/* Details Body */}
                          <div className="p-4 flex-1 flex flex-col justify-between space-y-2.5">
                            <div>
                              <h4 className="font-black text-xs sm:text-sm text-slate-900 dark:text-white line-clamp-1">
                                {item.title}
                              </h4>
                              {item.subtitle && (
                                <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                                  {item.subtitle}
                                </p>
                              )}

                              {/* Price Tag if applicable */}
                              {item.price !== undefined && (
                                <div className="flex items-center gap-2 mt-1.5">
                                  <span className="font-black text-sm text-slate-900 dark:text-white">
                                    ₹{item.price.toLocaleString('en-IN')}
                                  </span>
                                  {item.originalPrice && (
                                    <span className="text-xs text-slate-400 line-through">
                                      ₹{item.originalPrice.toLocaleString('en-IN')}
                                    </span>
                                  )}
                                </div>
                              )}

                              {/* Personal Private Note */}
                              {item.notes && (
                                <div className="mt-2 p-2 rounded-xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 text-[11px] text-amber-950 dark:text-amber-200 line-clamp-2">
                                  📝 {item.notes}
                                </div>
                              )}

                              {/* Social Signal */}
                              {item.socialSignals?.savedByFriendsCount && (
                                <div className="mt-2 flex items-center gap-1 text-[10px] font-bold text-slate-500 dark:text-slate-400">
                                  <Users className="w-3 h-3 text-indigo-500" />
                                  <span>
                                    Saved by {item.socialSignals.savedByFriendsCount} others in your network
                                  </span>
                                </div>
                              )}
                            </div>

                            {/* Action Buttons */}
                            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                              <button
                                onClick={() =>
                                  openSaveToCollectionModal({
                                    targetId: item.targetId,
                                    itemType: item.itemType,
                                    title: item.title,
                                    subtitle: item.subtitle,
                                    imageUrl: item.imageUrl,
                                    price: item.price,
                                    originalPrice: item.originalPrice,
                                    badge: item.badge,
                                    tags: item.tags,
                                  })
                                }
                                className="p-2 text-slate-500 hover:text-amber-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition cursor-pointer"
                                title="Assign to Collections / Add Notes"
                              >
                                <FolderHeart className="w-4 h-4" />
                              </button>

                              <button
                                onClick={() => handleActionClick(item)}
                                className="flex-1 py-2 bg-slate-900 dark:bg-amber-500 hover:bg-slate-800 dark:hover:bg-amber-600 text-white dark:text-slate-800 font-black text-xs rounded-xl shadow-xs transition text-center cursor-pointer"
                              >
                                {item.itemType === 'product'
                                  ? 'Add to Bag'
                                  : item.itemType === 'seller'
                                  ? 'Visit Store'
                                  : item.itemType === 'chat'
                                  ? 'Open Chat'
                                  : item.itemType === 'reel'
                                  ? 'Play Reel'
                                  : 'View Item'}
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  /* List View */
                  <div className="space-y-2.5">
                    {filteredItems.map((item) => (
                      <div
                        key={item.id}
                        className="p-3 sm:p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between gap-4"
                      >
                        <div className="flex items-center gap-3.5 min-w-0">
                          {item.imageUrl ? (
                            <img
                              src={item.imageUrl}
                              alt={item.title}
                              className="w-14 h-14 rounded-xl object-cover border border-slate-200 dark:border-slate-700"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-14 h-14 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-400">
                              {item.itemType.toUpperCase()}
                            </div>
                          )}

                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-black uppercase text-slate-700 dark:text-slate-300">
                                {item.itemType}
                              </span>
                              {item.badge && (
                                <span className="text-[10px] font-bold text-amber-600">
                                  {item.badge}
                                </span>
                              )}
                            </div>
                            <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white truncate mt-0.5">
                              {item.title}
                            </h4>
                            {item.subtitle && (
                              <p className="text-xs text-slate-500 truncate">{item.subtitle}</p>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          {item.price !== undefined && (
                            <div className="text-right hidden sm:block">
                              <span className="font-black text-sm text-slate-900 dark:text-white">
                                ₹{item.price.toLocaleString('en-IN')}
                              </span>
                              {item.originalPrice && (
                                <span className="text-xs text-slate-400 line-through block">
                                  ₹{item.originalPrice.toLocaleString('en-IN')}
                                </span>
                              )}
                            </div>
                          )}

                          <button
                            onClick={() => handleActionClick(item)}
                            className="px-4 py-2 bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-800 font-black text-xs rounded-xl shadow-xs transition cursor-pointer"
                          >
                            {item.itemType === 'product' ? 'Add to Bag' : 'Open'}
                          </button>

                          <UniversalSaveButton
                            targetId={item.targetId}
                            itemType={item.itemType}
                            title={item.title}
                            size="sm"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Empty State */}
                {filteredItems.length === 0 && (
                  <div className="text-center py-16 px-4 max-w-md mx-auto">
                    <div className="w-16 h-16 rounded-3xl bg-amber-50 dark:bg-amber-950/40 text-amber-600 flex items-center justify-center mx-auto mb-4 shadow-inner">
                      <Bookmark className="w-8 h-8" />
                    </div>
                    <h3 className="font-black text-base text-slate-900 dark:text-white">
                      No saved items found
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">
                      {searchQuery
                        ? `No items in your vault match "${searchQuery}". Try a different keyword.`
                        : 'You haven’t saved any items to this category yet. Tap the bookmark icon on any product, store, post or reel to save it!'}
                    </p>
                  </div>
                )}
              </div>
            )}
        </div>

        {/* Footer Summary Strip */}
        <div className="p-3.5 sm:px-6 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Vault Synced Live across Customer, Venture & Buddy Profiles</span>
          </div>

          <div className="flex items-center gap-4">
            <span>
              <strong>{savedItems.length}</strong> Saved Items
            </span>
            <span>
              <strong>{saveCollections.length}</strong> Moodboards
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
