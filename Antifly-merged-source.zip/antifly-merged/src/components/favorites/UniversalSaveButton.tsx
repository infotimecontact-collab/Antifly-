import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Bookmark,
  Heart,
  FolderPlus,
  ThumbsUp,
  ThumbsDown,
  MoreHorizontal,
  Check,
  Sparkles,
  Share2,
} from 'lucide-react';
import { SaveItemType, UniversalSaveItem, NotInterestedReason } from '../../types';

interface UniversalSaveButtonProps {
  targetId: string;
  itemType: SaveItemType;
  title: string;
  subtitle?: string;
  imageUrl?: string;
  price?: number;
  originalPrice?: number;
  badge?: string;
  tags?: string[];
  metadata?: Record<string, any>;
  variant?: 'icon-only' | 'compact' | 'chip' | 'text-with-icon' | 'floating';
  iconType?: 'bookmark' | 'heart';
  size?: 'xs' | 'sm' | 'md' | 'lg';
  className?: string;
  showFeedbackOption?: boolean;
}

export const UniversalSaveButton: React.FC<UniversalSaveButtonProps> = ({
  targetId,
  itemType,
  title,
  subtitle,
  imageUrl,
  price,
  originalPrice,
  badge,
  tags,
  metadata,
  variant = 'icon-only',
  iconType = 'bookmark',
  size = 'md',
  className = '',
  showFeedbackOption = true,
}) => {
  const {
    isSaved,
    toggleSaveItem,
    openSaveToCollectionModal,
    recordInterestFeedback,
    showToast,
  } = useApp();

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);

  const saved = isSaved(targetId, itemType);

  const handleToggleSave = async (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setIsAnimating(true);
    setTimeout(() => setIsAnimating(false), 600);

    await toggleSaveItem({
      targetId,
      itemType,
      title,
      subtitle,
      imageUrl,
      price,
      originalPrice,
      badge,
      tags,
      metadata,
    });
  };

  const handleOpenCollections = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setIsMenuOpen(false);
    openSaveToCollectionModal({
      targetId,
      itemType,
      title,
      subtitle,
      imageUrl,
      price,
      originalPrice,
      badge,
      tags,
      metadata,
    });
  };

  const handleQuickFeedback = (
    e: React.MouseEvent,
    type: 'interested' | 'not_interested',
    reason?: NotInterestedReason
  ) => {
    e.stopPropagation();
    e.preventDefault();
    setIsMenuOpen(false);
    setShowFeedbackModal(false);
    recordInterestFeedback(targetId, itemType, title, type, reason);
  };

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setIsMenuOpen(false);
    if (navigator.clipboard) {
      navigator.clipboard.writeText(`${window.location.origin}/item/${targetId}`);
      showToast(`🔗 Copied link for "${title}" to clipboard!`);
    } else {
      showToast(`Shared "${title}"`);
    }
  };

  // Size mapping
  const sizeClasses = {
    xs: 'w-6 h-6 p-1 text-xs',
    sm: 'w-8 h-8 p-1.5 text-xs',
    md: 'w-9 h-9 p-2 text-sm',
    lg: 'w-11 h-11 p-2.5 text-base',
  };

  const iconSizes = {
    xs: 'w-3.5 h-3.5',
    sm: 'w-4 h-4',
    md: 'w-4.5 h-4.5',
    lg: 'w-5 h-5',
  };

  return (
    <div className="relative inline-flex items-center">
      {/* 1. Icon Only Variant */}
      {variant === 'icon-only' && (
        <button
          type="button"
          onClick={handleToggleSave}
          onContextMenu={(e) => {
            e.preventDefault();
            setIsMenuOpen(!isMenuOpen);
          }}
          title={
            saved
              ? iconType === 'heart'
                ? 'Favorited (Click to remove, right-click for options)'
                : 'Saved in Vault (Click to remove, right-click for options)'
              : iconType === 'heart'
              ? 'Save to Favorites'
              : 'Save to Vault'
          }
          className={`relative rounded-full transition-all flex items-center justify-center cursor-pointer select-none active:scale-75 ${
            sizeClasses[size]
          } ${
            iconType === 'heart'
              ? saved
                ? 'bg-rose-50 dark:bg-rose-950/80 text-rose-500 shadow-md shadow-rose-500/25 ring-2 ring-rose-300 dark:ring-rose-700'
                : 'bg-white/90 dark:bg-slate-900/90 hover:bg-white dark:hover:bg-slate-900 text-slate-600 dark:text-slate-300 hover:text-rose-500 shadow-sm border border-slate-200/80 dark:border-slate-700/80 backdrop-blur-xs hover:scale-110'
              : saved
              ? 'bg-amber-500 text-slate-800 shadow-md shadow-amber-500/30 ring-2 ring-amber-400'
              : 'bg-white/90 hover:bg-white text-slate-700 hover:text-amber-600 shadow-sm border border-slate-200/80 backdrop-blur-xs'
          } ${isAnimating ? 'scale-125 duration-300' : 'duration-150'} ${className}`}
        >
          {isAnimating && (
            <span
              className={`absolute inset-0 rounded-full animate-ping pointer-events-none ${
                iconType === 'heart' ? 'bg-rose-400/40' : 'bg-amber-400/40'
              }`}
            />
          )}
          {iconType === 'heart' ? (
            <Heart
              className={`${iconSizes[size]} transition-transform ${
                saved ? 'fill-rose-500 text-rose-500 scale-110' : 'stroke-[2.2]'
              } ${isAnimating ? 'scale-125' : ''}`}
            />
          ) : (
            <Bookmark
              className={`${iconSizes[size]} transition-transform ${
                saved ? 'fill-current stroke-current scale-110' : 'stroke-[2.2]'
              }`}
            />
          )}
        </button>
      )}

      {/* 2. Chip / Pill Variant */}
      {variant === 'chip' && (
        <button
          type="button"
          onClick={handleToggleSave}
          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer select-none active:scale-95 ${
            saved
              ? 'bg-amber-500 text-slate-800 shadow-sm'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
          } ${className}`}
        >
          <Bookmark className={`w-3.5 h-3.5 ${saved ? 'fill-current' : ''}`} />
          <span>{saved ? 'Saved' : 'Save'}</span>
        </button>
      )}

      {/* 3. Compact with Menu button */}
      {variant === 'compact' && (
        <div className="inline-flex items-center bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          <button
            type="button"
            onClick={handleToggleSave}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-bold transition-colors cursor-pointer ${
              saved ? 'bg-amber-500 text-slate-800' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Bookmark className={`w-3.5 h-3.5 ${saved ? 'fill-current' : ''}`} />
            <span>{saved ? 'Saved' : 'Save'}</span>
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsMenuOpen(!isMenuOpen);
            }}
            className="px-1.5 py-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 border-l border-slate-200 transition cursor-pointer"
            title="More Save Options"
          >
            <MoreHorizontal className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* 4. Text With Icon Variant */}
      {variant === 'text-with-icon' && (
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={handleToggleSave}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer shadow-sm active:scale-95 ${
              saved
                ? 'bg-amber-500 text-slate-800 shadow-amber-500/20'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200'
            } ${className}`}
          >
            <Bookmark className={`w-4 h-4 ${saved ? 'fill-current' : ''}`} />
            <span>{saved ? 'Saved in Vault' : 'Save to Vault'}</span>
          </button>
          {saved && (
            <button
              type="button"
              onClick={handleOpenCollections}
              title="Add to Custom Collection"
              className="p-2.5 bg-slate-100 hover:bg-amber-50 text-slate-600 hover:text-amber-700 rounded-2xl border border-slate-200 transition cursor-pointer"
            >
              <FolderPlus className="w-4 h-4" />
            </button>
          )}
        </div>
      )}

      {/* Dropdown Options Menu */}
      {isMenuOpen && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={(e) => {
              e.stopPropagation();
              setIsMenuOpen(false);
            }}
          />
          <div className="absolute right-0 top-full mt-1.5 z-50 w-56 bg-white rounded-2xl shadow-xl border border-slate-200 py-1.5 text-xs text-slate-800 animate-in fade-in zoom-in-95 duration-150 select-none">
            <div className="px-3 py-1.5 border-b border-slate-100">
              <p className="font-bold text-[11px] text-slate-900 truncate">{title}</p>
              <p className="text-[10px] text-slate-500 capitalize">{itemType}</p>
            </div>

            <button
              type="button"
              onClick={handleToggleSave}
              className="w-full px-3 py-2 text-left flex items-center gap-2 hover:bg-slate-50 transition cursor-pointer font-semibold"
            >
              <Bookmark className={`w-3.5 h-3.5 ${saved ? 'text-amber-600 fill-amber-500' : 'text-slate-500'}`} />
              <span>{saved ? 'Remove from Saved' : 'Save to Vault'}</span>
            </button>

            <button
              type="button"
              onClick={handleOpenCollections}
              className="w-full px-3 py-2 text-left flex items-center gap-2 hover:bg-slate-50 transition cursor-pointer font-semibold text-slate-700"
            >
              <FolderPlus className="w-3.5 h-3.5 text-amber-600" />
              <span>Add to Collection...</span>
            </button>

            {showFeedbackOption && (
              <>
                <div className="my-1 border-t border-slate-100" />
                <button
                  type="button"
                  onClick={(e) => handleQuickFeedback(e, 'interested')}
                  className="w-full px-3 py-2 text-left flex items-center gap-2 hover:bg-emerald-50 text-emerald-700 transition cursor-pointer font-semibold"
                >
                  <ThumbsUp className="w-3.5 h-3.5" />
                  <span>Interested (See more)</span>
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowFeedbackModal(true);
                    setIsMenuOpen(false);
                  }}
                  className="w-full px-3 py-2 text-left flex items-center gap-2 hover:bg-rose-50 text-rose-700 transition cursor-pointer font-semibold"
                >
                  <ThumbsDown className="w-3.5 h-3.5" />
                  <span>Not Interested (See less)</span>
                </button>
              </>
            )}

            <div className="my-1 border-t border-slate-100" />
            <button
              type="button"
              onClick={handleShare}
              className="w-full px-3 py-2 text-left flex items-center gap-2 hover:bg-slate-50 text-slate-600 transition cursor-pointer font-semibold"
            >
              <Share2 className="w-3.5 h-3.5 text-slate-400" />
              <span>Share Item Link</span>
            </button>
          </div>
        </>
      )}

      {/* Not Interested Reason Sheet */}
      {showFeedbackModal && (
        <div
          className="fixed inset-0 z-50 bg-white/60 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={(e) => {
            e.stopPropagation();
            setShowFeedbackModal(false);
          }}
        >
          <div
            className="bg-white rounded-3xl p-5 max-w-sm w-full shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 text-slate-900 mb-2">
              <ThumbsDown className="w-4 h-4 text-rose-600" />
              <h3 className="font-black text-sm">Help tune your recommendations</h3>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Why aren't you interested in <strong>{title}</strong>?
            </p>

            <div className="space-y-2">
              {[
                { reason: 'not_relevant' as const, label: 'Not relevant to my current interests' },
                { reason: 'already_bought' as const, label: 'I already bought this / have this' },
                { reason: 'seen_too_much' as const, label: 'I see too much of this content' },
                { reason: 'dislike_brand_or_seller' as const, label: 'Not interested in this seller/brand' },
                { reason: 'other' as const, label: 'Other / Just don’t like it' },
              ].map((item) => (
                <button
                  key={item.reason}
                  type="button"
                  onClick={(e) => handleQuickFeedback(e, 'not_interested', item.reason)}
                  className="w-full text-left px-3.5 py-2.5 rounded-xl border border-slate-200 hover:border-rose-400 hover:bg-rose-50 text-xs font-semibold text-slate-700 hover:text-rose-900 transition flex items-center justify-between cursor-pointer"
                >
                  <span>{item.label}</span>
                  <Check className="w-3 h-3 opacity-0 group-hover:opacity-100" />
                </button>
              ))}
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex justify-end">
              <button
                type="button"
                onClick={() => setShowFeedbackModal(false)}
                className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
