import React, { useEffect, useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Phone,
  PhoneCall,
  PhoneOff,
  MapPin,
  Package,
  Navigation,
  CheckCircle,
  X,
  Volume2,
  VolumeX,
  Sparkles,
  Bike,
} from 'lucide-react';

export const IncomingBuddyCallModal: React.FC = () => {
  const {
    activeVentureBookingCall,
    currentDriver,
    acceptVentureBuddyCall,
    declineVentureBuddyCall,
    calculateDistanceKm,
    formatPrice,
    setDeviceMode,
    showToast,
  } = useApp();

  const [ringTimer, setRingTimer] = useState<number>(30);
  const [isAccepting, setIsAccepting] = useState<boolean>(false);

  const call = activeVentureBookingCall;
  const isRinging = call && call.status === 'RINGING';

  // Count down ring timer
  useEffect(() => {
    if (!isRinging) {
      setRingTimer(30);
      return;
    }
    const interval = setInterval(() => {
      setRingTimer((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isRinging]);

  if (!isRinging || !call) return null;

  // Calculate distance from current driver to venture store
  const distanceToStore = calculateDistanceKm(
    currentDriver?.currentLat || 22.7196,
    currentDriver?.currentLng || 75.8577,
    call.ventureLat,
    call.ventureLng
  );

  const handleAccept = async () => {
    setIsAccepting(true);
    try {
      const res = await acceptVentureBuddyCall(call.id, currentDriver?.id || 'driver-indore-01');
      if (res.success) {
        setDeviceMode('driver');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsAccepting(false);
    }
  };

  const handleDecline = () => {
    declineVentureBuddyCall(call.id, currentDriver?.id || 'driver-indore-01');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/85 backdrop-blur-md animate-in fade-in zoom-in-95 duration-200">
      {/* PHONE CALLER INTERFACE */}
      <div className="bg-slate-900 border-2 border-amber-500 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden text-white flex flex-col items-center p-6 text-center relative font-sans">
        
        {/* TOP CALLING STATUS & TIMER */}
        <div className="w-full flex items-center justify-between text-xs text-amber-300 font-bold mb-4">
          <span className="flex items-center gap-1.5 px-2.5 py-1 bg-amber-500/20 rounded-full border border-amber-500/30 animate-pulse">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            INCOMING VENTURE CALL (5km RADAR)
          </span>
          <span className="font-mono text-slate-400">⏱️ {ringTimer}s</span>
        </div>

        {/* PULSING CALLER AVATAR AURA */}
        <div className="relative my-2">
          <div className="absolute inset-0 rounded-full bg-emerald-500/30 animate-ping" />
          <div className="absolute -inset-3 rounded-full bg-amber-500/20 animate-pulse" />
          <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center text-slate-800 font-black text-3xl shadow-xl relative z-10 border-4 border-slate-900">
            <PhoneCall className="w-12 h-12 text-slate-800 animate-bounce" />
          </div>
        </div>

        {/* CALLER INFORMATION */}
        <div className="mt-3 space-y-1">
          <h2 className="text-xl font-black text-white tracking-tight">
            {call.ventureName}
          </h2>
          <p className="text-sm font-mono font-bold text-amber-400">
            Caller ID: +91 {call.venturePhone}
          </p>
          <div className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30 mt-1">
            <Navigation className="w-3.5 h-3.5" />
            <span>Store is {distanceToStore} km away (~{Math.round(distanceToStore * 2.5 + 2)} mins)</span>
          </div>
        </div>

        {/* TRIP & PARCEL DETAILS CARD */}
        <div className="w-full bg-slate-800/80 border border-slate-700/80 rounded-2xl p-4 my-5 text-left space-y-3 text-xs">
          <div className="flex items-start gap-2.5">
            <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
              <MapPin className="w-3.5 h-3.5" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Pickup From Venture:</span>
              <span className="font-semibold text-white">{call.ventureStoreAddress}</span>
            </div>
          </div>

          <div className="flex items-start gap-2.5 pt-2 border-t border-slate-700/60">
            <div className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0 mt-0.5">
              <Navigation className="w-3.5 h-3.5" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Deliver To Customer:</span>
              <span className="font-semibold text-white">{call.customerAddress} ({call.customerName})</span>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-700/60 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">
                Delivery Trip ({call.deliveryDistanceKm || 3} km @ ₹{call.ratePerKm || 15}/km):
              </span>
              <span className="text-sm text-emerald-400 font-black font-mono">
                {formatPrice(call.totalAmount || call.estimatedFare)}
              </span>
            </div>

            {(call.seasonalSurgeBonus || 0) > 0 && (
              <div className="flex items-center justify-between text-[11px] px-2.5 py-1.5 bg-amber-500/20 rounded-xl border border-amber-500/30 text-amber-300 font-bold">
                <span>
                  {call.seasonApplied === 'RAINY' ? '🌧️ Monsoon Hazard Surge' : '☀️ Summer Heat Allowance'}
                </span>
                <span>+₹{call.seasonalSurgeBonus} Bonus</span>
              </div>
            )}

            <div className="flex items-center justify-between text-[11px] p-2 bg-slate-900/90 rounded-xl border border-slate-700">
              <span className="text-slate-400 font-medium">Payment Settlement:</span>
              <span className="font-bold text-amber-400">
                {call.paymentMethod === 'VENTURE_WALLET'
                  ? '💳 Venture Store Direct Credit'
                  : call.paymentMethod === 'CASH_ON_PICKUP'
                  ? '💵 Cash on Pickup at Store'
                  : '📱 Direct UPI / Bank Transfer'}
              </span>
            </div>
          </div>
        </div>

        {/* CALL ACTION BUTTONS */}
        <div className="w-full grid grid-cols-2 gap-4">
          <button
            onClick={handleDecline}
            className="w-full py-3.5 bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white font-bold rounded-2xl text-sm transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer"
          >
            <PhoneOff className="w-4 h-4" />
            <span>Decline</span>
          </button>

          <button
            onClick={handleAccept}
            disabled={isAccepting}
            className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-800 font-black rounded-2xl text-sm transition-all shadow-xl flex items-center justify-center gap-2 animate-bounce disabled:opacity-50 cursor-pointer"
          >
            <Phone className="w-4 h-4" />
            <span>{isAccepting ? 'Accepting...' : `Accept & Earn ${formatPrice(call.totalAmount || call.estimatedFare)}`}</span>
          </button>
        </div>

        <p className="text-[10px] text-slate-400 mt-4">
          First nearby buddy within 5km to answer receives the dispatch assignment
        </p>
      </div>
    </div>
  );
};
