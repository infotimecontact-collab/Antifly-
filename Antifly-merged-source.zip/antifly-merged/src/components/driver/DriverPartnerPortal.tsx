import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Navigation,
  MapPin,
  Phone,
  CheckCircle2,
  AlertCircle,
  Shield,
  Clock,
  Compass,
  IndianRupee,
  Wallet,
  Camera,
  Edit3,
  Power,
  RotateCw,
  Truck,
  Package,
  Layers,
  ChevronRight,
  ExternalLink,
  LifeBuoy,
  BadgeAlert,
  KeyRound,
  Gift,
  Trash2,
  Plus,
  X,
  UserCheck,
  Bike,
  Coins,
  TrendingUp,
  Sparkles,
  Award,
  ArrowRight,
  Car,
  FileText,
  CreditCard,
  ShieldCheck,
  AlertTriangle,
  UploadCloud,
  CheckCircle,
  Zap,
  Search,
  ArrowUpDown,
  Banknote,
  Flame,
  SlidersHorizontal,
  Activity,
  Radio,
  Eye,
  EyeOff,
  Crosshair,
  Info,
} from 'lucide-react';
import { DriverDeliveryTask, DriverProfile, DriverKycDocuments } from '../../types';
import { WhatsAppStatusHub } from '../social/WhatsAppStatusHub';

export interface HighDemandPickupZone {
  id: string;
  name: string;
  subArea: string;
  category: string;
  cx: number;
  cy: number;
  radius: number;
  ordersPerHour: number;
  surgeMultiplier: string;
  surgeBonus: number;
  activeCouriers: number;
  intensityColor: string;
  densityLevel: 'Ultra High' | 'High Surge' | 'Moderate';
  activeMerchants: number;
  highlightText: string;
  avgPickupWaitMins: number;
}

export const HIGH_DEMAND_PICKUP_ZONES: HighDemandPickupZone[] = [
  {
    id: 'zone-rajwada',
    name: 'Rajwada Cloth Market & Handlooms',
    subArea: 'Central MG Road & Sarafa Bazaar',
    category: 'Handlooms & Fashion',
    cx: 140,
    cy: 175,
    radius: 56,
    ordersPerHour: 48,
    surgeMultiplier: '1.6x',
    surgeBonus: 35,
    activeCouriers: 7,
    intensityColor: '#ef4444',
    densityLevel: 'Ultra High',
    activeMerchants: 28,
    highlightText: '🔥 48 Pickups/hr • +₹35 Surge Bonus',
    avgPickupWaitMins: 3,
  },
  {
    id: 'zone-vijay-nagar',
    name: 'Vijay Nagar Food & IT Tech Hub',
    subArea: 'AB Road & Scheme 54',
    category: 'Gourmet & Tech Hub',
    cx: 345,
    cy: 80,
    radius: 64,
    ordersPerHour: 62,
    surgeMultiplier: '1.8x',
    surgeBonus: 45,
    activeCouriers: 12,
    intensityColor: '#dc2626',
    densityLevel: 'Ultra High',
    activeMerchants: 42,
    highlightText: '🔥 62 Pickups/hr • +₹45 Peak Surge',
    avgPickupWaitMins: 4,
  },
  {
    id: 'zone-chappan',
    name: 'Chappan Dukan Food Street & Snacks',
    subArea: 'New Palasia Corridor',
    category: 'Quick Food & Snacks',
    cx: 235,
    cy: 130,
    radius: 46,
    ordersPerHour: 39,
    surgeMultiplier: '1.4x',
    surgeBonus: 25,
    activeCouriers: 6,
    intensityColor: '#f97316',
    densityLevel: 'High Surge',
    activeMerchants: 22,
    highlightText: '⚡ 39 Pickups/hr • +₹25 Surge Bonus',
    avgPickupWaitMins: 2,
  },
  {
    id: 'zone-palasia',
    name: 'Palasia Commercial & Electronics Square',
    subArea: 'Old Palasia & Janjeerwala',
    category: 'Retail & Electronics',
    cx: 295,
    cy: 195,
    radius: 48,
    ordersPerHour: 31,
    surgeMultiplier: '1.35x',
    surgeBonus: 20,
    activeCouriers: 9,
    intensityColor: '#f59e0b',
    densityLevel: 'Moderate',
    activeMerchants: 18,
    highlightText: '🟡 31 Pickups/hr • +₹20 Surge Bonus',
    avgPickupWaitMins: 4,
  },
  {
    id: 'zone-transport-nagar',
    name: 'Transport Nagar Hardware & Tools Zone',
    subArea: 'Ring Road Hardware Hub',
    category: 'Heavy Tools & Hardware',
    cx: 85,
    cy: 85,
    radius: 42,
    ordersPerHour: 24,
    surgeMultiplier: '1.3x',
    surgeBonus: 30,
    activeCouriers: 5,
    intensityColor: '#f97316',
    densityLevel: 'Moderate',
    activeMerchants: 15,
    highlightText: '⚡ 24 Heavy Orders/hr • +₹30 Cargo Bonus',
    avgPickupWaitMins: 5,
  },
];

export const DriverPartnerPortal: React.FC = () => {
  const {
    drivers,
    activeDriverId,
    setActiveDriverId,
    currentDriver,
    registerDriver,
    updateDriverProfile,
    toggleDriverStatus,
    deleteDriverAccount,
    deleteDriverAccountPermanently,
    registerRoleAccount,
    checkPhoneConflict,
    openAuthModalFor,
    toggleDriverOnline,
    driverTasks,
    updateDriverTaskStatus,
    completeDriverDeliveryWithOtp,
    formatPrice,
    showToast,
    driverMilestoneProgress,
    setDriverRadiusFilterKm,
    claimDriverMilestoneBonus,
    driverBroadcastOrders,
    acceptDriverBroadcastOrder,
    rejectDriverBroadcastOrder,
    activeVentureBookingCall,
    acceptVentureBuddyCall,
    declineVentureBuddyCall,
    settings,
    accountLifecycleConfig,
    deactivateDriverAccount,
    deleteDriverAccountAndConvertToCustomer,
    setIsAddStoryModalOpen,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'trips' | 'status' | 'incentives' | 'wallet' | 'vehicle' | 'account-settings'>('trips');
  const [selectedTaskId, setSelectedTaskId] = useState<string>(driverTasks?.[0]?.id || '');
  const [enteredOtp, setEnteredOtp] = useState<string>('');
  const [signatureName, setSignatureName] = useState<string>('');
  const [isVerifyingOtp, setIsVerifyingOtp] = useState<boolean>(false);
  const [isPhotoCaptured, setIsPhotoCaptured] = useState<boolean>(false);

  // Quick Filter & Search State for Delivery Tasks Queue
  const [taskFilter, setTaskFilter] = useState<'ALL' | 'HIGHEST_PAYOUT' | 'FASTEST_DELIVERY' | 'SHORTEST_ROUTE' | 'IN_TRANSIT' | 'COD' | 'PREPAID'>('ALL');
  const [taskSearchQuery, setTaskSearchQuery] = useState<string>('');

  // Delivery Heatmap & High-Demand Surge Radar State
  const [showDeliveryHeatmap, setShowDeliveryHeatmap] = useState<boolean>(true);
  const [selectedHeatZoneId, setSelectedHeatZoneId] = useState<string | null>(null);
  const [isMapExpanded, setIsMapExpanded] = useState<boolean>(false);
  const [heatmapViewMode, setHeatmapViewMode] = useState<'ALL_ZONES' | 'HOTSPOTS_ONLY' | 'ROUTE_ONLY'>('ALL_ZONES');

  // Driver Vehicle Login / Registration Modal State
  const [isVehicleModalOpen, setIsVehicleModalOpen] = useState(false);
  const [driverVehicleType, setDriverVehicleType] = useState('Motorcycle / Bike');
  const [driverVehicleNumber, setDriverVehicleNumber] = useState('MP-09-EV-8842');
  const [driverLicenseNumber, setDriverLicenseNumber] = useState('DL-INDORE-2024-998');
  const [driverUpiId, setDriverUpiId] = useState('driver@okaxis');

  // Convert Credits to Real Rupees State
  const [creditsToConvert, setCreditsToConvert] = useState<number>(100);
  const [isConvertingCredits, setIsConvertingCredits] = useState<boolean>(false);

  // Direct Driver Registration & Full KYC Modal State
  const [isKycModalOpen, setIsKycModalOpen] = useState(false);
  const [kycForm, setKycForm] = useState({
    name: currentDriver?.name || 'Vikas Verma',
    phone: currentDriver?.phone || '+91 94258 21388',
    email: currentDriver?.email || 'driver@antifly.com',
    city: currentDriver?.city || 'Indore',
    vehicleType: 'Electric Bike',
    vehicleNumber: 'MP-09-EV-8899',
    bikeRcDocumentUrl: 'https://images.unsplash.com/photo-1617788138017-80ad40651399?w=600&auto=format&fit=crop&q=80',
    bikeInsuranceDocUrl: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80',
    bikePhotoUrl: 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?w=600&auto=format&fit=crop&q=80',
    drivingLicense: 'DL-MP09-2024-00192',
    drivingLicenseFrontUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80',
    aadhaarNumber: '7829 4410 9921',
    aadhaarFrontUrl: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=600&auto=format&fit=crop&q=80',
    voterIdNumber: 'MP/24/098/120938',
    voterIdDocUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=600&auto=format&fit=crop&q=80',
    selfieUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
  });

  // Deactivation / Conversion Modal State
  const [isDeactivateModalOpen, setIsDeactivateModalOpen] = useState(false);
  const [deactivationReason, setDeactivationReason] = useState('Taking personal leave / pausing deliveries');
  const [selectedDeactivateAction, setSelectedDeactivateAction] = useState<'7_DAY_FREEZE' | 'DELETE_CONVERT_CUSTOMER'>('7_DAY_FREEZE');

  // Credit Incentive Simulation
  const driverCredits = currentDriver?.walletBalance ? Math.floor(currentDriver.walletBalance * 1) + 20 : 140; // 1 credit = ₹1
  const completedCount = currentDriver?.completedDeliveries || 8;

  const pendingTasks = driverTasks.filter((t) => t.status !== 'Delivered');
  const completedTasks = driverTasks.filter((t) => t.status === 'Delivered');

  // Quick Filter & Sort Computation
  const displayedTasks = useMemo(() => {
    let list = [...pendingTasks];

    if (taskSearchQuery.trim()) {
      const q = taskSearchQuery.toLowerCase();
      list = list.filter(
        (t) =>
          t.customerName?.toLowerCase().includes(q) ||
          t.sellerName?.toLowerCase().includes(q) ||
          t.customerAddress?.toLowerCase().includes(q) ||
          t.orderId?.toLowerCase().includes(q) ||
          t.trackingNumber?.toLowerCase().includes(q)
      );
    }

    switch (taskFilter) {
      case 'HIGHEST_PAYOUT':
        return list.sort((a, b) => ((b.payoutFee || 0) + (b.tipAmount || 0)) - ((a.payoutFee || 0) + (a.tipAmount || 0)));
      case 'FASTEST_DELIVERY':
        return list.sort((a, b) => (a.estimatedMinutes || 99) - (b.estimatedMinutes || 99));
      case 'SHORTEST_ROUTE':
        return list.sort((a, b) => (a.distanceKm || 99) - (b.distanceKm || 99));
      case 'IN_TRANSIT':
        return list.filter((t) => t.status === 'In Transit' || t.status === 'Heading to Pickup' || t.status === 'Picked Up');
      case 'COD':
        return list.filter((t) => t.paymentMode === 'COD');
      case 'PREPAID':
        return list.filter((t) => t.paymentMode === 'PREPAID');
      case 'ALL':
      default:
        return list;
    }
  }, [pendingTasks, taskFilter, taskSearchQuery]);

  const activeTask = driverTasks?.find((t) => t.id === selectedTaskId) || displayedTasks[0] || pendingTasks[0] || null;

  const isPendingKyc = currentDriver?.kycStatus === 'PENDING_ADMIN_VERIFICATION' || (!currentDriver?.isVerified && currentDriver?.kycStatus !== 'REJECTED');
  const isApprovedKyc = currentDriver?.kycStatus === 'APPROVED' || currentDriver?.isVerified;
  const isRejectedKyc = currentDriver?.kycStatus === 'REJECTED';

  const handleVehicleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentDriver) {
      updateDriverProfile(currentDriver.id, {
        vehicleType: driverVehicleType,
        vehicleNumber: driverVehicleNumber,
        drivingLicense: driverLicenseNumber,
      });
      showToast(`🚗 Vehicle Logged in: ${driverVehicleType} (${driverVehicleNumber})! +20 Login Bonus Credits Credited!`);
      setIsVehicleModalOpen(false);
    }
  };

  const handleKycRegistrationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const slaHours = accountLifecycleConfig.driverVerificationSlaHours || 24;
    const slaExpiresAt = new Date(Date.now() + slaHours * 3600000).toISOString();

    const kycDocs: DriverKycDocuments = {
      bikeRegistrationNumber: kycForm.vehicleNumber,
      bikeRcDocumentUrl: kycForm.bikeRcDocumentUrl,
      bikeInsuranceDocUrl: kycForm.bikeInsuranceDocUrl,
      bikePhotoUrl: kycForm.bikePhotoUrl,
      drivingLicenseNumber: kycForm.drivingLicense,
      drivingLicenseFrontUrl: kycForm.drivingLicenseFrontUrl,
      aadhaarNumber: kycForm.aadhaarNumber,
      aadhaarFrontUrl: kycForm.aadhaarFrontUrl,
      voterIdNumber: kycForm.voterIdNumber,
      voterIdDocUrl: kycForm.voterIdDocUrl,
      selfieUrl: kycForm.selfieUrl,
      submittedAt: new Date().toISOString(),
      slaExpiresAt,
    };

    if (currentDriver) {
      await updateDriverProfile(currentDriver.id, {
        name: kycForm.name,
        phone: kycForm.phone,
        email: kycForm.email,
        city: kycForm.city,
        vehicleType: kycForm.vehicleType,
        vehicleNumber: kycForm.vehicleNumber,
        drivingLicense: kycForm.drivingLicense,
        kycStatus: 'PENDING_ADMIN_VERIFICATION',
        isVerified: false,
        isActive: false,
        badge: 'KYC Under 24h Review ⏳',
        kycDocs,
      });
    } else {
      await registerDriver({
        name: kycForm.name,
        phone: kycForm.phone,
        email: kycForm.email,
        city: kycForm.city,
        vehicleType: kycForm.vehicleType,
        vehicleNumber: kycForm.vehicleNumber,
        drivingLicense: kycForm.drivingLicense,
        kycDocs,
      });
    }

    setIsKycModalOpen(false);
    showToast('📄 KYC Documents submitted! Admin will verify Bike RC, DL, Aadhaar & Voter ID within 24 hours.');
  };

  const handleDeactivateOrConvert = async () => {
    if (!currentDriver) return;

    if (selectedDeactivateAction === '7_DAY_FREEZE') {
      await deactivateDriverAccount(currentDriver.id, deactivationReason, accountLifecycleConfig.driverGraceDays);
      setIsDeactivateModalOpen(false);
    } else {
      await deleteDriverAccountAndConvertToCustomer(currentDriver.id, deactivationReason);
      setIsDeactivateModalOpen(false);
    }
  };

  const handleConvertCreditsToRupees = () => {
    if (creditsToConvert <= 0) {
      showToast('Please enter a valid credit amount');
      return;
    }
    setIsConvertingCredits(true);
    setTimeout(() => {
      setIsConvertingCredits(false);
      showToast(`🎉 Success! Converted ${creditsToConvert} Credits into ₹${creditsToConvert} Real Rupees and sent to UPI: ${driverUpiId}!`);
    }, 800);
  };

  return (
    <div id="driver-partner-portal-white" className="min-h-screen bg-white text-slate-900 font-sans pb-28">
      {/* Top Driver Header Strip */}
      <div className="bg-slate-50 border-b border-slate-200 py-3 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-600 flex items-center justify-center text-white font-black text-lg shadow-sm">
              <Bike className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-base sm:text-lg text-slate-900">
                  Antifly Buddy Partner
                </h1>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black border border-emerald-300">
                  {currentDriver?.isOnline ? '🟢 ONLINE' : '⚪ OFFLINE'}
                </span>
                {isApprovedKyc && (
                  <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-black flex items-center gap-1 border border-blue-200">
                    <ShieldCheck className="w-3 h-3 text-blue-600" />
                    Verified Partner
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Partner: <strong>{currentDriver?.name || 'Driver Partner'}</strong> &bull; Vehicle: <strong>{currentDriver?.vehicleType || 'Electric Bike'}</strong> ({currentDriver?.vehicleNumber || 'MP-09-EV-2024'})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
            {/* Real Credit Balance Widget */}
            <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-2xl">
              <Coins className="w-4 h-4 text-amber-600 fill-amber-400" />
              <div>
                <div className="text-[10px] text-amber-800 font-bold uppercase tracking-wider">Incentive Credits</div>
                <div className="text-xs sm:text-sm font-black text-slate-900">
                  {driverCredits} Credits <span className="text-[11px] text-emerald-700 font-extrabold">(= ₹{driverCredits})</span>
                </div>
              </div>
            </div>

            {/* Post 24h Delivery Status Button */}
            <button
              onClick={() => setIsAddStoryModalOpen(true)}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-2 rounded-2xl text-xs font-black transition cursor-pointer shadow-xs"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Post Delivery Status</span>
            </button>

            {/* KYC Upload & Register Button */}
            <button
              onClick={() => setIsKycModalOpen(true)}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-2 rounded-2xl text-xs font-black transition cursor-pointer shadow-xs"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>{isApprovedKyc ? 'Update KYC Proofs' : 'Upload KYC Proofs'}</span>
            </button>

            {/* Vehicle Login / Switch Button */}
            <button
              onClick={() => setIsVehicleModalOpen(true)}
              className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 px-3 py-2 rounded-2xl text-xs font-black transition cursor-pointer border border-slate-200"
            >
              <Car className="w-3.5 h-3.5 text-blue-600" />
              <span>Vehicle Setup</span>
            </button>

            {/* Online / Offline Toggle */}
            <button
              onClick={() => currentDriver && toggleDriverOnline(currentDriver.id)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-black transition cursor-pointer shadow-xs ${
                currentDriver?.isOnline
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
              }`}
            >
              <Power className="w-3.5 h-3.5" />
              <span>{currentDriver?.isOnline ? 'Go Offline' : 'Go Online'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 24-HOUR KYC REVIEW SLA BANNER */}
      {isPendingKyc && (
        <div className="bg-amber-500 text-slate-800 px-4 py-3 border-b border-amber-600">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 font-bold">
              <Clock className="w-4 h-4 animate-spin shrink-0 text-slate-800" />
              <span>
                <strong>24-Hour Admin Verification in Progress</strong>: Your bike registration, driving license, Aadhaar card, and voter ID are under admin verification. Features will be enabled within 24 hours. Once approved, you can log in to begin deliveries within 24 hours.
              </span>
            </div>
            <button
              onClick={() => setIsKycModalOpen(true)}
              className="px-3 py-1 bg-white text-white rounded-xl text-[11px] font-black uppercase tracking-wider hover:bg-slate-800 shrink-0 cursor-pointer shadow-xs"
            >
              View Uploaded Proofs
            </button>
          </div>
        </div>
      )}

      {/* Main Navigation Tabs */}
      <div className="border-b border-slate-200 bg-white sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center gap-2 overflow-x-auto py-2">
          <button
            onClick={() => setActiveTab('trips')}
            className={`py-2 px-4 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap ${
              activeTab === 'trips'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            📦 Active Delivery Trips ({pendingTasks.length})
          </button>

          <button
            onClick={() => setActiveTab('status')}
            className={`py-2 px-4 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'status'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>📱 24h Buddy Status & Stories</span>
          </button>

          <button
            onClick={() => setActiveTab('incentives')}
            className={`py-2 px-4 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'incentives'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 text-amber-500" />
            <span>Daily Incentives & Milestone Rewards</span>
          </button>

          <button
            onClick={() => setActiveTab('wallet')}
            className={`py-2 px-4 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'wallet'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Wallet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Credit Payouts & Real ₹ Transfer</span>
          </button>

          <button
            onClick={() => setActiveTab('vehicle')}
            className={`py-2 px-4 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'vehicle'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Car className="w-3.5 h-3.5 text-blue-600" />
            <span>My Registered Vehicle</span>
          </button>

          <button
            onClick={() => setActiveTab('account-settings')}
            className={`py-2 px-4 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'account-settings'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-purple-600" />
            <span>KYC & 7-Day Account Deactivation</span>
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {/* INCOMING VENTURE BROADCAST CALL BANNER (5KM RADAR) */}
        {activeVentureBookingCall && activeVentureBookingCall.status === 'RINGING' && (
          <div className="mb-6 bg-gradient-to-r from-amber-600 via-rose-600 to-amber-600 p-5 rounded-3xl text-white shadow-2xl border-2 border-amber-300 animate-pulse flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-white text-rose-600 flex items-center justify-center font-black shadow-lg animate-bounce shrink-0">
                <Phone className="w-7 h-7" />
              </div>
              <div>
                <span className="px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-800 font-black text-[10px] uppercase tracking-wider">
                  ⚡ Hyperlocal Direct Booking Call
                </span>
                <h3 className="text-xl font-black text-white mt-1">
                  Venture Store: {activeVentureBookingCall.ventureName}
                </h3>
                <p className="text-xs text-amber-100 font-medium">
                  Pickup: {activeVentureBookingCall.ventureStoreAddress} &bull; Delivery: {activeVentureBookingCall.customerAddress}
                </p>
                <div className="mt-2 flex items-center gap-3 text-xs font-bold">
                  <span className="bg-slate-900/50 px-2.5 py-1 rounded-xl">
                    Distance: <strong>{activeVentureBookingCall.deliveryDistanceKm} km</strong>
                  </span>
                  <span className="bg-emerald-500 text-slate-800 px-2.5 py-1 rounded-xl font-black">
                    Driver Fare: ₹{activeVentureBookingCall.totalAmount} (Guaranteed Min ₹30)
                  </span>
                  <span className="bg-slate-900/50 px-2.5 py-1 rounded-xl text-amber-200">
                    Season: {activeVentureBookingCall.seasonApplied} (+₹{activeVentureBookingCall.seasonalSurge})
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => currentDriver && acceptVentureBuddyCall(activeVentureBookingCall.id, currentDriver.id)}
                className="px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-800 rounded-2xl font-black text-sm transition cursor-pointer shadow-lg animate-pulse"
              >
                Accept Order (₹{activeVentureBookingCall.totalAmount})
              </button>
              <button
                onClick={() => currentDriver && declineVentureBuddyCall(activeVentureBookingCall.id, currentDriver.id)}
                className="px-4 py-3 bg-white/20 hover:bg-white/30 text-white rounded-2xl font-bold text-xs transition cursor-pointer"
              >
                Decline
              </button>
            </div>
          </div>
        )}

        {/* TAB 0: 24-HOUR BUDDY STATUS & STORIES */}
        {activeTab === 'status' && (
          <div className="bg-white rounded-3xl border border-slate-200 p-4 sm:p-6 shadow-sm">
            <WhatsAppStatusHub />
          </div>
        )}

        {/* TAB 1: ACTIVE TRIPS */}
        {activeTab === 'trips' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Task List Panel */}
            <div className="lg:col-span-1 space-y-3.5">
              {/* Header & Search */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <SlidersHorizontal className="w-4 h-4 text-slate-700" />
                    <h2 className="text-sm font-black uppercase tracking-wider text-slate-800">
                      Delivery Queue
                    </h2>
                  </div>
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                    {displayedTasks.length} {displayedTasks.length === 1 ? 'Order' : 'Orders'}
                  </span>
                </div>

                {/* Instant Search Bar */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={taskSearchQuery}
                    onChange={(e) => setTaskSearchQuery(e.target.value)}
                    placeholder="Search by customer, area, store..."
                    className="w-full pl-8 pr-7 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500 transition"
                  />
                  {taskSearchQuery && (
                    <button
                      onClick={() => setTaskSearchQuery('')}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* QUICK FILTER BUTTONS BAR */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  <span>Quick Filters</span>
                  {taskFilter !== 'ALL' && (
                    <button
                      onClick={() => setTaskFilter('ALL')}
                      className="text-red-600 hover:underline font-extrabold cursor-pointer"
                    >
                      Reset
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-1.5">
                  {/* Highest Payout */}
                  <button
                    onClick={() => {
                      setTaskFilter('HIGHEST_PAYOUT');
                      if (displayedTasks.length > 0) setSelectedTaskId(displayedTasks[0].id);
                    }}
                    className={`p-2 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                      taskFilter === 'HIGHEST_PAYOUT'
                        ? 'bg-emerald-600 text-white border-emerald-700 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <IndianRupee className={`w-3.5 h-3.5 ${taskFilter === 'HIGHEST_PAYOUT' ? 'text-white' : 'text-emerald-600'}`} />
                      <span className={`text-[9px] font-black px-1.5 py-0.2 rounded-md uppercase ${
                        taskFilter === 'HIGHEST_PAYOUT' ? 'bg-white/20 text-white' : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        Max ₹
                      </span>
                    </div>
                    <span className="text-xs font-black leading-tight mt-1">Highest Payout</span>
                  </button>

                  {/* Fastest Delivery */}
                  <button
                    onClick={() => {
                      setTaskFilter('FASTEST_DELIVERY');
                      if (displayedTasks.length > 0) setSelectedTaskId(displayedTasks[0].id);
                    }}
                    className={`p-2 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                      taskFilter === 'FASTEST_DELIVERY'
                        ? 'bg-amber-500 text-white border-amber-600 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-amber-400 hover:bg-amber-50/50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <Zap className={`w-3.5 h-3.5 ${taskFilter === 'FASTEST_DELIVERY' ? 'text-white' : 'text-amber-500'}`} />
                      <span className={`text-[9px] font-black px-1.5 py-0.2 rounded-md uppercase ${
                        taskFilter === 'FASTEST_DELIVERY' ? 'bg-white/20 text-white' : 'bg-amber-100 text-amber-800'
                      }`}>
                        ETA
                      </span>
                    </div>
                    <span className="text-xs font-black leading-tight mt-1">Fastest Delivery</span>
                  </button>

                  {/* Shortest Route */}
                  <button
                    onClick={() => {
                      setTaskFilter('SHORTEST_ROUTE');
                      if (displayedTasks.length > 0) setSelectedTaskId(displayedTasks[0].id);
                    }}
                    className={`p-2 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                      taskFilter === 'SHORTEST_ROUTE'
                        ? 'bg-blue-600 text-white border-blue-700 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-blue-400 hover:bg-blue-50/50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <Navigation className={`w-3.5 h-3.5 ${taskFilter === 'SHORTEST_ROUTE' ? 'text-white' : 'text-blue-600'}`} />
                      <span className={`text-[9px] font-black px-1.5 py-0.2 rounded-md uppercase ${
                        taskFilter === 'SHORTEST_ROUTE' ? 'bg-white/20 text-white' : 'bg-blue-100 text-blue-800'
                      }`}>
                        KM
                      </span>
                    </div>
                    <span className="text-xs font-black leading-tight mt-1">Shortest Route</span>
                  </button>
                </div>

                {/* Secondary Quick-Filter Badges */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar pt-1">
                  <button
                    onClick={() => setTaskFilter('ALL')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1 ${
                      taskFilter === 'ALL'
                        ? 'bg-slate-900 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    <span>All</span>
                    <span className="text-[10px] opacity-75">({pendingTasks.length})</span>
                  </button>

                  <button
                    onClick={() => setTaskFilter('IN_TRANSIT')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1 ${
                      taskFilter === 'IN_TRANSIT'
                        ? 'bg-red-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    <Flame className="w-3 h-3 text-red-500" />
                    <span>In-Transit</span>
                  </button>

                  <button
                    onClick={() => setTaskFilter('COD')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1 ${
                      taskFilter === 'COD'
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    <Banknote className="w-3 h-3 text-amber-600" />
                    <span>COD</span>
                  </button>

                  <button
                    onClick={() => setTaskFilter('PREPAID')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1 ${
                      taskFilter === 'PREPAID'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    <CreditCard className="w-3 h-3 text-emerald-600" />
                    <span>Prepaid</span>
                  </button>
                </div>
              </div>

              {/* Active Filter State Banner */}
              {taskFilter !== 'ALL' && (
                <div className="px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-between text-[11px] text-slate-700">
                  <span className="font-medium flex items-center gap-1">
                    <ArrowUpDown className="w-3 h-3 text-slate-500" />
                    Sorted by: <strong>
                      {taskFilter === 'HIGHEST_PAYOUT' && '💰 Highest Payout'}
                      {taskFilter === 'FASTEST_DELIVERY' && '⚡ Fastest Delivery'}
                      {taskFilter === 'SHORTEST_ROUTE' && '📍 Shortest Route'}
                      {taskFilter === 'IN_TRANSIT' && '🔥 Active / In-Transit'}
                      {taskFilter === 'COD' && '💵 Cash on Delivery'}
                      {taskFilter === 'PREPAID' && '💳 Prepaid Orders'}
                    </strong>
                  </span>
                  <button
                    onClick={() => setTaskFilter('ALL')}
                    className="text-red-600 hover:underline font-bold text-[10px] cursor-pointer"
                  >
                    Clear
                  </button>
                </div>
              )}

              {/* Task Items List */}
              {displayedTasks.length === 0 ? (
                <div className="bg-slate-50 border border-slate-200 rounded-3xl p-8 text-center space-y-2">
                  <Package className="w-8 h-8 text-slate-400 mx-auto" />
                  <h3 className="text-sm font-bold text-slate-700">No Orders Match Filter</h3>
                  <p className="text-xs text-slate-500">
                    Try selecting "All" or clearing the search query.
                  </p>
                  <button
                    onClick={() => {
                      setTaskFilter('ALL');
                      setTaskSearchQuery('');
                    }}
                    className="px-3 py-1 bg-red-600 text-white rounded-lg text-xs font-bold mt-2 cursor-pointer"
                  >
                    Show All Orders
                  </button>
                </div>
              ) : (
                displayedTasks.map((task) => {
                  const isSelected = selectedTaskId === task.id || (activeTask && activeTask.id === task.id);
                  const totalEarnings = (task.payoutFee || 45) + (task.tipAmount || 0);

                  return (
                    <div
                      key={task.id}
                      onClick={() => setSelectedTaskId(task.id)}
                      className={`p-4 rounded-2xl border transition cursor-pointer space-y-2.5 ${
                        isSelected
                          ? 'bg-red-50/70 border-red-500 ring-2 ring-red-500/20 shadow-xs'
                          : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-xs'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-md ${
                          task.status === 'In Transit'
                            ? 'bg-red-100 text-red-700 animate-pulse'
                            : task.status === 'Picked Up'
                            ? 'bg-purple-100 text-purple-700'
                            : task.status === 'Heading to Pickup'
                            ? 'bg-amber-100 text-amber-700'
                            : 'bg-blue-100 text-blue-700'
                        }`}>
                          {task.status}
                        </span>

                        <div className="text-right">
                          <span className="text-xs font-extrabold text-emerald-700 font-mono block">
                            +₹{totalEarnings}
                          </span>
                          {task.tipAmount ? (
                            <span className="text-[10px] font-bold text-amber-600 block">
                              (incl. ₹{task.tipAmount} tip)
                            </span>
                          ) : null}
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center justify-between">
                          <h4 className="font-extrabold text-sm text-slate-900 truncate">
                            {task.customerName}
                          </h4>
                          <span className="text-[10px] font-mono text-slate-400">
                            #{task.orderId}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 truncate mt-0.5">
                          {task.sellerName} &bull; {task.customerAddress}
                        </p>
                      </div>

                      {/* Route & Quick Stats Strip */}
                      <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-slate-100 text-[11px] text-slate-600 font-bold">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100">
                          <MapPin className="w-3 h-3 text-red-500" />
                          {task.distanceKm || 2.4} km
                        </span>

                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100">
                          <Clock className="w-3 h-3 text-blue-500" />
                          {task.estimatedMinutes || 15}m ETA
                        </span>

                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md ${
                          task.paymentMode === 'COD'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}>
                          {task.paymentMode === 'COD' ? `COD ₹${task.codAmountToCollect}` : 'Prepaid ⚡'}
                        </span>

                        {/* Top metric tag */}
                        {task.payoutFee >= 180 && (
                          <span className="text-[10px] font-black text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                            🔥 High Payout
                          </span>
                        )}
                        {task.estimatedMinutes <= 10 && task.estimatedMinutes > 0 && (
                          <span className="text-[10px] font-black text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                            ⚡ Express
                          </span>
                        )}
                        {task.distanceKm <= 2.0 && (
                          <span className="text-[10px] font-black text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">
                            📍 Nearby
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Selected Task Details & Verification Card */}
            <div className="lg:col-span-2">
              {activeTask ? (
                <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-xs space-y-6">
                  <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
                    <div>
                      <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">
                        Delivery Task #{activeTask.id} &bull; Order #{activeTask.orderId}
                      </span>
                      <h3 className="text-lg font-black text-slate-900 mt-0.5">
                        {activeTask.customerName}
                      </h3>
                      <p className="text-xs text-slate-500 flex items-center gap-2">
                        <span>{activeTask.customerPhone}</span>
                        <span>&bull;</span>
                        <span className="text-emerald-700 font-bold">{activeTask.paymentMode === 'COD' ? `COD Cash: ₹${activeTask.codAmountToCollect}` : 'Prepaid (Online)'}</span>
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="text-xs text-slate-400 font-bold block">Total Courier Payout</span>
                      <span className="text-xl font-black text-emerald-600">
                        ₹{(activeTask.payoutFee || 45) + (activeTask.tipAmount || 0)}
                      </span>
                      {activeTask.tipAmount ? (
                        <span className="text-[10px] text-amber-600 font-bold block">
                          Base ₹{activeTask.payoutFee || 45} + Tip ₹{activeTask.tipAmount}
                        </span>
                      ) : null}
                    </div>
                  </div>

                  {/* Route Overview Metric Badges */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-center">
                      <span className="text-[10px] font-black uppercase text-slate-400 block">Distance</span>
                      <span className="text-base font-black text-slate-900 flex items-center justify-center gap-1 mt-0.5">
                        <MapPin className="w-3.5 h-3.5 text-red-500" />
                        {activeTask.distanceKm || 2.4} km
                      </span>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-center">
                      <span className="text-[10px] font-black uppercase text-slate-400 block">Est. Time</span>
                      <span className="text-base font-black text-slate-900 flex items-center justify-center gap-1 mt-0.5">
                        <Clock className="w-3.5 h-3.5 text-blue-500" />
                        {activeTask.estimatedMinutes || 15} mins
                      </span>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-center">
                      <span className="text-[10px] font-black uppercase text-slate-400 block">Payment</span>
                      <span className={`text-xs font-black px-2 py-0.5 rounded-md inline-block mt-1 ${
                        activeTask.paymentMode === 'COD' ? 'bg-amber-100 text-amber-900' : 'bg-emerald-100 text-emerald-900'
                      }`}>
                        {activeTask.paymentMode === 'COD' ? `COD ₹${activeTask.codAmountToCollect}` : 'Prepaid ⚡'}
                      </span>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-center">
                      <span className="text-[10px] font-black uppercase text-slate-400 block">Items Count</span>
                      <span className="text-base font-black text-slate-900 flex items-center justify-center gap-1 mt-0.5">
                        <Package className="w-3.5 h-3.5 text-purple-500" />
                        {activeTask.itemsCount || 1} pkg
                      </span>
                    </div>
                  </div>

                  {/* LIVE GPS ROUTE & DELIVERY HEATMAP VISUALIZER */}
                  <div
                    id="driver-delivery-map-section"
                    className="border border-slate-200 rounded-3xl overflow-hidden bg-slate-900 shadow-sm transition-all duration-200"
                  >
                    {/* Map Header Controls & Delivery Heatmap Toggle */}
                    <div className="px-4 py-3 bg-white/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2.5">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-black text-white tracking-wide uppercase">
                              City Demand Radar & Route Map
                            </span>
                            <span className="text-[10px] font-black px-2 py-0.5 rounded-md bg-red-500/20 text-red-400 border border-red-500/30 font-mono">
                              LIVE GPS
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400">
                            Navigating from <strong>{activeTask.sellerName}</strong> to <strong>{activeTask.customerName}</strong>
                          </p>
                        </div>
                      </div>

                      {/* Controls Group */}
                      <div className="flex items-center gap-2 flex-wrap">
                        {/* Delivery Heatmap Toggle Switch */}
                        <button
                          id="delivery-heatmap-toggle"
                          type="button"
                          onClick={() => {
                            const next = !showDeliveryHeatmap;
                            setShowDeliveryHeatmap(next);
                            if (next) setSelectedHeatZoneId(null);
                          }}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer shadow-xs border ${
                            showDeliveryHeatmap
                              ? 'bg-gradient-to-r from-red-600 via-orange-600 to-amber-600 text-white border-red-500 ring-2 ring-red-500/30'
                              : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                          }`}
                        >
                          <Flame className={`w-3.5 h-3.5 ${showDeliveryHeatmap ? 'text-amber-200 animate-pulse' : 'text-slate-400'}`} />
                          <span>Delivery Heatmap: {showDeliveryHeatmap ? 'ON' : 'OFF'}</span>
                          <span
                            className={`w-2 h-2 rounded-full ${
                              showDeliveryHeatmap ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'
                            }`}
                          />
                        </button>

                        {/* Expand / Minimize Map Toggle */}
                        <button
                          type="button"
                          onClick={() => setIsMapExpanded(!isMapExpanded)}
                          className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700 text-xs transition cursor-pointer"
                          title={isMapExpanded ? 'Collapse Map' : 'Expand Full Map'}
                        >
                          <SlidersHorizontal className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Surge Active Notice Ribbon */}
                    {showDeliveryHeatmap && (
                      <div className="bg-gradient-to-r from-red-950/90 via-amber-950/70 to-slate-950/90 border-b border-red-900/40 px-4 py-2 flex items-center justify-between text-xs text-amber-200">
                        <div className="flex items-center gap-2">
                          <Flame className="w-3.5 h-3.5 text-red-400 shrink-0 animate-bounce" />
                          <span className="font-bold">
                            High-Demand Pickup Zones Active &bull; <span className="text-white font-black">+₹20 to +₹45 Surge Bonus</span> per delivery from highlighted hubs.
                          </span>
                        </div>
                        <span className="text-[10px] font-black text-amber-400 bg-red-900/40 px-2 py-0.5 rounded border border-red-700/50 hidden sm:inline-block">
                          5 Active Surge Clusters
                        </span>
                      </div>
                    )}

                    {/* SVG Interactive Map Canvas */}
                    <div className="relative bg-white overflow-hidden select-none">
                      {/* Sub-grid pattern background */}
                      <div
                        className="absolute inset-0 opacity-15"
                        style={{
                          backgroundImage: `radial-gradient(#94a3b8 1px, transparent 1px)`,
                          backgroundSize: '24px 24px',
                        }}
                      />

                      <svg
                        className={`w-full transition-all duration-300 ${
                          isMapExpanded ? 'h-[440px]' : 'h-[300px] sm:h-[340px]'
                        }`}
                        viewBox="0 0 520 280"
                        fill="none"
                      >
                        <defs>
                          {/* Radial Gradients for Translucent High-Demand Heat Overlays */}
                          <radialGradient id="heatUltra" cx="50%" cy="50%" r="50%">
                            <stop offset="0%" stopColor="#ef4444" stopOpacity="0.8" />
                            <stop offset="35%" stopColor="#f97316" stopOpacity="0.5" />
                            <stop offset="70%" stopColor="#fbbf24" stopOpacity="0.25" />
                            <stop offset="100%" stopColor="#ef4444" stopOpacity="0" />
                          </radialGradient>

                          <radialGradient id="heatHigh" cx="50%" cy="50%" r="50%">
                            <stop offset="0%" stopColor="#f97316" stopOpacity="0.75" />
                            <stop offset="40%" stopColor="#fbbf24" stopOpacity="0.45" />
                            <stop offset="80%" stopColor="#f97316" stopOpacity="0.15" />
                            <stop offset="100%" stopColor="#f97316" stopOpacity="0" />
                          </radialGradient>

                          <radialGradient id="heatModerate" cx="50%" cy="50%" r="50%">
                            <stop offset="0%" stopColor="#eab308" stopOpacity="0.7" />
                            <stop offset="50%" stopColor="#f59e0b" stopOpacity="0.35" />
                            <stop offset="100%" stopColor="#eab308" stopOpacity="0" />
                          </radialGradient>

                          {/* Glow Filter for Silk Smooth Heat Bleed */}
                          <filter id="heatGlowBlur" x="-30%" y="-30%" width="160%" height="160%">
                            <feGaussianBlur stdDeviation="8" result="blur" />
                            <feComposite in="SourceGraphic" in2="blur" operator="over" />
                          </filter>

                          <linearGradient id="routeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stopColor="#10b981" />
                            <stop offset="50%" stopColor="#38bdf8" />
                            <stop offset="100%" stopColor="#ef4444" />
                          </linearGradient>
                        </defs>

                        {/* 1. Road Network Grid & Highways */}
                        {/* AB Road Expressway */}
                        <path d="M 40 40 L 480 240" stroke="#1e293b" strokeWidth="16" strokeLinecap="round" />
                        <path d="M 40 40 L 480 240" stroke="#334155" strokeWidth="4" strokeDasharray="6 6" />

                        {/* MG Road Heritage Central Corridor */}
                        <path d="M 60 180 L 460 160" stroke="#1e293b" strokeWidth="14" strokeLinecap="round" />
                        <path d="M 60 180 L 460 160" stroke="#334155" strokeWidth="3" strokeDasharray="4 4" />

                        {/* Ring Road Bypass */}
                        <path d="M 70 80 Q 260 20 450 90" stroke="#1e293b" strokeWidth="12" fill="none" strokeLinecap="round" />
                        <path d="M 70 80 Q 260 20 450 90" stroke="#334155" strokeWidth="3" fill="none" strokeDasharray="5 5" />

                        {/* Secondary Connectors */}
                        <path d="M 140 60 L 140 230" stroke="#0f172a" strokeWidth="8" strokeLinecap="round" />
                        <path d="M 240 40 L 240 250" stroke="#0f172a" strokeWidth="8" strokeLinecap="round" />
                        <path d="M 345 50 L 345 250" stroke="#0f172a" strokeWidth="8" strokeLinecap="round" />
                        <path d="M 80 120 L 450 120" stroke="#0f172a" strokeWidth="7" strokeLinecap="round" />
                        <path d="M 120 220 L 380 220" stroke="#0f172a" strokeWidth="7" strokeLinecap="round" />

                        {/* Watermark City Locality Labels */}
                        <text x="75" y="65" fill="#475569" fontSize="9" fontWeight="bold" letterSpacing="1">
                          TRANSPORT NAGAR
                        </text>
                        <text x="315" y="45" fill="#475569" fontSize="9" fontWeight="bold" letterSpacing="1">
                          VIJAY NAGAR IT HUB
                        </text>
                        <text x="100" y="215" fill="#475569" fontSize="9" fontWeight="bold" letterSpacing="1">
                          RAJWADA MARKET
                        </text>
                        <text x="260" y="240" fill="#475569" fontSize="9" fontWeight="bold" letterSpacing="1">
                          PALASIA SQUARE
                        </text>
                        <text x="210" y="105" fill="#475569" fontSize="9" fontWeight="bold" letterSpacing="1">
                          CHAPPAN DUKAN
                        </text>

                        {/* 2. TRANSLUCENT HIGH-DEMAND PICKUP HEATMAP OVERLAYS */}
                        {showDeliveryHeatmap && (
                          <g id="delivery-heatmap-layers">
                            {HIGH_DEMAND_PICKUP_ZONES.map((zone) => {
                              const isSelected = selectedHeatZoneId === zone.id;
                              const gradId =
                                zone.densityLevel === 'Ultra High'
                                  ? 'url(#heatUltra)'
                                  : zone.densityLevel === 'High Surge'
                                  ? 'url(#heatHigh)'
                                  : 'url(#heatModerate)';

                              return (
                                <g
                                  key={zone.id}
                                  className="cursor-pointer transition-all duration-300"
                                  onClick={() => setSelectedHeatZoneId(isSelected ? null : zone.id)}
                                >
                                  {/* Outer translucent thermal bloom layer */}
                                  <circle
                                    cx={zone.cx}
                                    cy={zone.cy}
                                    r={zone.radius * 1.3}
                                    fill={gradId}
                                    filter="url(#heatGlowBlur)"
                                    className="animate-pulse"
                                    style={{ animationDuration: '3s' }}
                                  />

                                  {/* Mid translucent heat core */}
                                  <circle
                                    cx={zone.cx}
                                    cy={zone.cy}
                                    r={zone.radius * 0.85}
                                    fill={gradId}
                                    opacity={0.85}
                                  />

                                  {/* Peak surge pulse ring */}
                                  <circle
                                    cx={zone.cx}
                                    cy={zone.cy}
                                    r={zone.radius * 0.45}
                                    stroke={zone.intensityColor}
                                    strokeWidth={isSelected ? '3' : '1.5'}
                                    strokeDasharray="4 2"
                                    fill="none"
                                    className="animate-spin"
                                    style={{ transformOrigin: `${zone.cx}px ${zone.cy}px`, animationDuration: '10s' }}
                                  />

                                  {/* Zone Center Hotspot Node */}
                                  <circle
                                    cx={zone.cx}
                                    cy={zone.cy}
                                    r="14"
                                    fill={zone.intensityColor}
                                    fillOpacity={0.9}
                                    stroke="#ffffff"
                                    strokeWidth="2"
                                  />

                                  {/* Flame / Surge Tag */}
                                  <text
                                    x={zone.cx}
                                    y={zone.cy + 4}
                                    textAnchor="middle"
                                    fill="#ffffff"
                                    fontSize="10"
                                    fontWeight="bold"
                                  >
                                    🔥
                                  </text>

                                  {/* Hotspot Floating Label Pill */}
                                  <g transform={`translate(${zone.cx}, ${zone.cy - zone.radius * 0.5 - 12})`}>
                                    <rect
                                      x="-48"
                                      y="-10"
                                      width="96"
                                      height="18"
                                      rx="9"
                                      fill="#0f172a"
                                      fillOpacity="0.9"
                                      stroke={zone.intensityColor}
                                      strokeWidth="1.5"
                                    />
                                    <text
                                      x="0"
                                      y="2"
                                      textAnchor="middle"
                                      fill="#f8fafc"
                                      fontSize="8"
                                      fontWeight="bold"
                                    >
                                      {zone.name.split(' ')[0]} +₹{zone.surgeBonus}
                                    </text>
                                  </g>
                                </g>
                              );
                            })}
                          </g>
                        )}

                        {/* 3. ACTIVE DELIVERY ROUTE PATH */}
                        {/* Dynamic Path Connecting Store Pickup to Customer Drop */}
                        <path
                          d="M 140 175 Q 240 110 345 80"
                          stroke="#047857"
                          strokeWidth="12"
                          strokeLinecap="round"
                          opacity="0.3"
                        />
                        <path
                          d="M 140 175 Q 240 110 345 80"
                          stroke="url(#routeGrad)"
                          strokeWidth="4"
                          strokeLinecap="round"
                          strokeDasharray="6 4"
                          className="animate-pulse"
                        />

                        {/* Origin: Merchant Pickup Store Pin */}
                        <g transform="translate(140, 175)">
                          <circle r="18" fill="#10b981" fillOpacity="0.2" className="animate-ping" />
                          <circle r="12" fill="#059669" stroke="#ffffff" strokeWidth="2" />
                          <text y="4" textAnchor="middle" fill="#ffffff" fontSize="9" fontWeight="black">
                            🏬
                          </text>
                          {/* Label */}
                          <g transform="translate(0, 24)">
                            <rect x="-42" y="-9" width="84" height="18" rx="6" fill="#022c22" stroke="#059669" strokeWidth="1" />
                            <text x="0" y="3" textAnchor="middle" fill="#34d399" fontSize="8" fontWeight="bold">
                              Pickup: {activeTask.sellerName.slice(0, 12)}
                            </text>
                          </g>
                        </g>

                        {/* Moving Live Courier / Rider Marker */}
                        <g transform="translate(242, 125)">
                          <circle r="22" fill="#38bdf8" fillOpacity="0.25" className="animate-ping" />
                          <circle r="14" fill="#0284c7" stroke="#ffffff" strokeWidth="2.5" />
                          <text y="4" textAnchor="middle" fill="#ffffff" fontSize="10">
                            🛵
                          </text>
                          <g transform="translate(0, -18)">
                            <rect x="-35" y="-8" width="70" height="16" rx="5" fill="#082f49" stroke="#38bdf8" strokeWidth="1" />
                            <text x="0" y="3" textAnchor="middle" fill="#7dd3fc" fontSize="8" fontWeight="black">
                              Rider In-Transit
                            </text>
                          </g>
                        </g>

                        {/* Destination: Customer Drop Marker */}
                        <g transform="translate(345, 80)">
                          <circle r="18" fill="#ef4444" fillOpacity="0.2" className="animate-ping" />
                          <circle r="12" fill="#dc2626" stroke="#ffffff" strokeWidth="2" />
                          <text y="4" textAnchor="middle" fill="#ffffff" fontSize="9" fontWeight="black">
                            📍
                          </text>
                          <g transform="translate(0, 24)">
                            <rect x="-40" y="-9" width="80" height="18" rx="6" fill="#450a0a" stroke="#dc2626" strokeWidth="1" />
                            <text x="0" y="3" textAnchor="middle" fill="#fca5a5" fontSize="8" fontWeight="bold">
                              Drop: {activeTask.customerName.slice(0, 10)}
                            </text>
                          </g>
                        </g>
                      </svg>

                      {/* Map Floating HUD Legend & Stats */}
                      <div className="absolute bottom-2.5 left-2.5 right-2.5 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
                        {/* Heatmap Scale Legend */}
                        {showDeliveryHeatmap ? (
                          <div className="pointer-events-auto bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-xl px-3 py-1.5 flex items-center gap-3 text-[10px] text-slate-300">
                            <span className="font-bold text-slate-400 uppercase text-[9px]">Demand Scale:</span>
                            <span className="flex items-center gap-1">
                              <span className="w-2 h-2 rounded-full bg-red-500" /> Ultra (45+ orders/h)
                            </span>
                            <span className="flex items-center gap-1">
                              <span className="w-2 h-2 rounded-full bg-orange-500" /> High (30-45)
                            </span>
                            <span className="flex items-center gap-1">
                              <span className="w-2 h-2 rounded-full bg-amber-500" /> Moderate (15-30)
                            </span>
                          </div>
                        ) : (
                          <div className="pointer-events-auto bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-xl px-3 py-1.5 text-[10px] text-slate-400">
                            GPS Route Only &bull; Turn on <strong>Delivery Heatmap</strong> above to see surge zones
                          </div>
                        )}

                        <div className="pointer-events-auto flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setSelectedHeatZoneId('zone-vijay-nagar')}
                            className="px-2.5 py-1 rounded-lg bg-red-600/90 hover:bg-red-600 text-white text-[10px] font-black transition cursor-pointer flex items-center gap-1 shadow-xs"
                          >
                            <Flame className="w-3 h-3 text-amber-300" />
                            <span>Top Surge Zone</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => setSelectedHeatZoneId(null)}
                            className="px-2.5 py-1 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-200 text-[10px] font-bold transition cursor-pointer border border-slate-700"
                          >
                            <Crosshair className="w-3 h-3" />
                            <span>Center Route</span>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Selected Heat Zone Detail Drawer */}
                    {showDeliveryHeatmap && selectedHeatZoneId && (() => {
                      const zone = HIGH_DEMAND_PICKUP_ZONES.find((z) => z.id === selectedHeatZoneId);
                      if (!zone) return null;

                      return (
                        <div className="p-4 bg-white border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs animate-in fade-in duration-150">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-red-500/20 text-red-400 border border-red-500/40">
                                {zone.densityLevel}
                              </span>
                              <h4 className="font-extrabold text-sm text-white">{zone.name}</h4>
                            </div>
                            <p className="text-slate-400 text-[11px]">
                              {zone.subArea} &bull; Category: <strong className="text-slate-200">{zone.category}</strong>
                            </p>
                          </div>

                          <div className="flex items-center gap-3 flex-wrap">
                            <div className="text-right">
                              <span className="text-[10px] text-slate-400 block font-bold uppercase">Order Velocity</span>
                              <span className="text-sm font-black text-amber-400">{zone.ordersPerHour} Pickups / hr</span>
                            </div>

                            <div className="text-right">
                              <span className="text-[10px] text-slate-400 block font-bold uppercase">Surge Multiplier</span>
                              <span className="text-sm font-black text-emerald-400">+{zone.surgeBonus} ₹ ({zone.surgeMultiplier})</span>
                            </div>

                            <button
                              type="button"
                              onClick={() => {
                                setTaskSearchQuery(zone.name.split(' ')[0]);
                                showToast(`Filtered orders near ${zone.name}`);
                              }}
                              className="px-3 py-2 bg-gradient-to-r from-red-600 to-amber-600 text-white rounded-xl font-black text-xs transition cursor-pointer hover:opacity-90 shadow-xs"
                            >
                              View Orders in this Zone
                            </button>

                            <button
                              type="button"
                              onClick={() => setSelectedHeatZoneId(null)}
                              className="p-1.5 text-slate-400 hover:text-white transition cursor-pointer"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })()}

                    {/* Quick High-Demand Hotspot Pills */}
                    {showDeliveryHeatmap && (
                      <div className="px-4 py-2.5 bg-slate-900 border-t border-slate-800/80 flex items-center gap-2 overflow-x-auto no-scrollbar">
                        <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider whitespace-nowrap flex items-center gap-1">
                          <Activity className="w-3 h-3 text-amber-400" /> Hotspots:
                        </span>
                        {HIGH_DEMAND_PICKUP_ZONES.map((zone) => {
                          const isSelected = selectedHeatZoneId === zone.id;
                          return (
                            <button
                              key={zone.id}
                              type="button"
                              onClick={() => setSelectedHeatZoneId(isSelected ? null : zone.id)}
                              className={`px-2.5 py-1 rounded-xl text-[11px] font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 border ${
                                isSelected
                                  ? 'bg-red-600 text-white border-red-500 shadow-xs'
                                  : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border-slate-700/60'
                              }`}
                            >
                              <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
                              <span>{zone.name.split(' ')[0]}</span>
                              <span className="text-[10px] text-amber-400 font-extrabold">
                                +₹{zone.surgeBonus}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                      <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
                        <MapPin className="w-4 h-4 text-red-500" />
                        <span>Pickup Merchant Store</span>
                      </div>
                      <strong className="text-xs text-slate-900 block">{activeTask.sellerName}</strong>
                      <p className="text-xs text-slate-500">{activeTask.sellerAddress}</p>
                    </div>

                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                      <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
                        <Navigation className="w-4 h-4 text-emerald-600" />
                        <span>Customer Drop Location</span>
                      </div>
                      <strong className="text-xs text-slate-900 block">{activeTask.customerName}</strong>
                      <p className="text-xs text-slate-500">{activeTask.customerAddress}</p>
                    </div>
                  </div>

                  {/* Task Status Transition Action Bar */}
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider block">
                      Update Live Task Status
                    </span>
                    <div className="flex flex-wrap items-center gap-2">
                      {['Assigned', 'Heading to Pickup', 'Picked Up', 'In Transit', 'Arrived at Drop'].map((st) => (
                        <button
                          key={st}
                          onClick={() => updateDriverTaskStatus(activeTask.id, st as any)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                            activeTask.status === st
                              ? 'bg-red-600 text-white shadow-xs'
                              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {st}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* OTP & Delivery Completion */}
                  <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-3">
                    <h4 className="font-black text-sm text-emerald-950 flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      <span>Complete Delivery with Customer OTP (Default OTP: 4821)</span>
                    </h4>

                    <div className="flex flex-col sm:flex-row items-center gap-3">
                      <input
                        type="text"
                        maxLength={4}
                        value={enteredOtp}
                        onChange={(e) => setEnteredOtp(e.target.value)}
                        placeholder="Enter 4-digit OTP"
                        className="w-full sm:w-48 px-4 py-2.5 bg-white border border-emerald-300 rounded-xl text-sm font-black text-slate-900 text-center tracking-widest focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />

                      <button
                        onClick={async () => {
                          setIsVerifyingOtp(true);
                          const ok = await completeDriverDeliveryWithOtp(activeTask.id, enteredOtp || '4821');
                          setIsVerifyingOtp(false);
                          if (ok) setEnteredOtp('');
                        }}
                        disabled={isVerifyingOtp}
                        className="w-full sm:w-auto px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-black text-xs transition cursor-pointer shadow-xs"
                      >
                        {isVerifyingOtp ? 'Verifying OTP...' : 'Verify OTP & Mark Delivered (+₹45)'}
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-slate-50 border border-slate-200 rounded-3xl p-12 text-center text-slate-500">
                  Select a delivery trip to view navigation and customer contact.
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: INCENTIVES & MILESTONES */}
        {activeTab === 'incentives' && (
          <div className="space-y-6">
            <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-xs space-y-4">
              <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-500" />
                <span>Daily Partner Incentive Milestones</span>
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Complete daily trip milestones to unlock extra rupee cash bonuses directly credited to your wallet.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-5 rounded-2xl bg-amber-50 border border-amber-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-amber-900">Tier 1 Target: 5 Trips</span>
                    <span className="px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 text-[10px] font-black">
                      +₹100 Bonus
                    </span>
                  </div>
                  <div className="w-full bg-amber-200 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-amber-600 h-full rounded-full"
                      style={{ width: `${Math.min(100, (completedCount / 5) * 100)}%` }}
                    />
                  </div>
                  <span className="text-[10px] font-bold text-amber-800 block">
                    {completedCount >= 5 ? '🎉 Achieved!' : `${completedCount}/5 Trips Completed`}
                  </span>
                </div>

                <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-emerald-900">Tier 2 Target: 10 Trips</span>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-200 text-emerald-900 text-[10px] font-black">
                      +₹250 Bonus
                    </span>
                  </div>
                  <div className="w-full bg-emerald-200 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-emerald-600 h-full rounded-full"
                      style={{ width: `${Math.min(100, (completedCount / 10) * 100)}%` }}
                    />
                  </div>
                  <span className="text-[10px] font-bold text-emerald-800 block">
                    {completedCount >= 10 ? '🎉 Achieved!' : `${completedCount}/10 Trips Completed`}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: WALLET & CREDITS TO REAL ₹ TRANSFER */}
        {activeTab === 'wallet' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">
                    Available Partner Balance
                  </span>
                  <h3 className="text-2xl font-black text-emerald-600 mt-0.5">
                    ₹{currentDriver?.walletBalance || 500}
                  </h3>
                </div>
                <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-black">
                  <IndianRupee className="w-6 h-6" />
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 text-xs space-y-1.5">
                <div className="flex justify-between text-slate-600">
                  <span>Today's Trip Earnings:</span>
                  <strong className="text-slate-900">₹{currentDriver?.todayEarnings || 360}</strong>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Incentive Bonus Credits:</span>
                  <strong className="text-amber-700">{driverCredits} Credits</strong>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>COD Cash in Hand:</span>
                  <strong className="text-slate-900">₹{currentDriver?.cashInHand || 0}</strong>
                </div>
              </div>
            </div>

            {/* Convert Incentive Credits to Real Rupees */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-xs space-y-4">
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Coins className="w-5 h-5 text-amber-500" />
                <span>Transfer Incentive Credits into Real Bank / UPI</span>
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                1 Incentive Credit = <strong>₹1 Real Rupee</strong>. Withdrawals are instant via UPI.
              </p>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Credits to Convert (1 Credit = ₹1)
                  </label>
                  <input
                    type="number"
                    max={driverCredits}
                    min={10}
                    value={creditsToConvert}
                    onChange={(e) => setCreditsToConvert(Number(e.target.value))}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-black text-slate-900 focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Receiver UPI ID / VPA
                  </label>
                  <input
                    type="text"
                    value={driverUpiId}
                    onChange={(e) => setDriverUpiId(e.target.value)}
                    placeholder="e.g. drivername@okaxis or 9876543210@ybl"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-red-500"
                  />
                </div>

                <button
                  onClick={handleConvertCreditsToRupees}
                  disabled={isConvertingCredits}
                  className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-2xl text-xs sm:text-sm font-black transition cursor-pointer shadow-xs mt-2"
                >
                  {isConvertingCredits ? 'Processing UPI Transfer...' : `Convert ${creditsToConvert} Credits to ₹${creditsToConvert} Real Rupees`}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: VEHICLE SETUP */}
        {activeTab === 'vehicle' && (
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-xs space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-slate-900">Registered Buddy Vehicle</h3>
                <p className="text-xs text-slate-500 font-medium">
                  Login your own vehicle to claim +20 welcome credits and start delivering immediately.
                </p>
              </div>

              <button
                onClick={() => setIsVehicleModalOpen(true)}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer shadow-xs"
              >
                Edit Vehicle Details
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] font-black text-slate-400 uppercase">Vehicle Type</span>
                <h4 className="font-extrabold text-base text-slate-900 mt-1 flex items-center gap-1.5">
                  <Bike className="w-4 h-4 text-blue-600" />
                  <span>{currentDriver?.vehicleType || 'Electric Bike'}</span>
                </h4>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] font-black text-slate-400 uppercase">Number Plate (RC)</span>
                <h4 className="font-extrabold text-base text-slate-900 mt-1 font-mono">
                  {currentDriver?.vehicleNumber || 'MP-09-EV-2024'}
                </h4>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] font-black text-slate-400 uppercase">Driving License</span>
                <h4 className="font-extrabold text-base text-slate-900 mt-1 font-mono">
                  {currentDriver?.drivingLicense || 'DL-MP09-202488'}
                </h4>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: KYC VERIFICATION & 7-DAY DYNAMIC DEACTIVATION */}
        {activeTab === 'account-settings' && (
          <div className="space-y-6">
            {/* KYC Status & Document Summary Card */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-xs space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                <div>
                  <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-emerald-600" />
                    <span>Driver KYC Proofs & Verification Status</span>
                  </h3>
                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    Original Bike documents, Driving License, Aadhaar card, and Voter ID card verification.
                  </p>
                </div>

                <button
                  onClick={() => setIsKycModalOpen(true)}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer shadow-xs"
                >
                  {isApprovedKyc ? 'Update KYC Documents' : 'Upload / Re-submit Proofs'}
                </button>
              </div>

              {/* Status Banner */}
              <div
                className={`p-4 rounded-2xl border flex items-center gap-3 text-xs ${
                  isApprovedKyc
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                    : isPendingKyc
                    ? 'bg-amber-50 border-amber-200 text-amber-950'
                    : 'bg-rose-50 border-rose-200 text-rose-950'
                }`}
              >
                {isApprovedKyc ? (
                  <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
                ) : isPendingKyc ? (
                  <Clock className="w-5 h-5 text-amber-600 shrink-0 animate-spin" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
                )}
                <div>
                  <strong className="block font-black text-sm">
                    {isApprovedKyc
                      ? '✅ KYC Approved & Features Enabled'
                      : isPendingKyc
                      ? '⏳ KYC Under Admin Review (24-Hour SLA)'
                      : '❌ KYC Verification Incomplete / Rejected'}
                  </strong>
                  <span>
                    {isApprovedKyc
                      ? 'All original proofs verified. You can log in and accept all order delivery tasks.'
                      : isPendingKyc
                      ? 'Admin will verify your bike documents, DL, Aadhaar card, and voter ID within 24 hours. After admin verification, features will be enabled and you should log in to start accepting delivery tasks within 24 hours.'
                      : currentDriver?.kycDocs?.rejectionReason || 'Please upload clear original photos of your bike RC, driving license, Aadhaar card, and voter ID.'}
                  </span>
                </div>
              </div>

              {/* Proofs Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl">
                  <span className="text-[10px] text-slate-400 font-bold block uppercase">Bike RC Proof</span>
                  <strong className="text-slate-900 block mt-0.5">{currentDriver?.vehicleNumber || 'MP-09-EV-8899'}</strong>
                  <span className="text-[10px] text-emerald-600 font-bold">✓ Original RC Uploaded</span>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl">
                  <span className="text-[10px] text-slate-400 font-bold block uppercase">Driving License</span>
                  <strong className="text-slate-900 block mt-0.5 font-mono">{currentDriver?.drivingLicense || 'DL-MP09-2024'}</strong>
                  <span className="text-[10px] text-emerald-600 font-bold">✓ DL Proof Uploaded</span>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl">
                  <span className="text-[10px] text-slate-400 font-bold block uppercase">Aadhaar Card</span>
                  <strong className="text-slate-900 block mt-0.5 font-mono">{currentDriver?.kycDocs?.aadhaarNumber || '7829 4410 9921'}</strong>
                  <span className="text-[10px] text-emerald-600 font-bold">✓ Aadhaar Verified</span>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl">
                  <span className="text-[10px] text-slate-400 font-bold block uppercase">Voter ID Card</span>
                  <strong className="text-slate-900 block mt-0.5 font-mono">{currentDriver?.kycDocs?.voterIdNumber || 'MP/24/098/120938'}</strong>
                  <span className="text-[10px] text-emerald-600 font-bold">✓ Voter ID Verified</span>
                </div>
              </div>
            </div>

            {/* 7-Day Deactivation & Convert to Customer Card */}
            <div className="bg-white border border-rose-200 rounded-3xl p-6 sm:p-7 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-black text-rose-950 flex items-center gap-2">
                    <Trash2 className="w-5 h-5 text-rose-600" />
                    <span>Account Deactivation & Customer Role Conversion ({accountLifecycleConfig.driverGraceDays}-Day Dynamic)</span>
                  </h3>
                  <p className="text-xs text-rose-700 font-medium mt-0.5">
                    If you want to deactivate your driver account, there is a dynamic {accountLifecycleConfig.driverGraceDays}-day freeze option. Upon deleting or completing {accountLifecycleConfig.driverGraceDays} days, your account is automatically converted into a normal customer.
                  </p>
                </div>

                <button
                  onClick={() => setIsDeactivateModalOpen(true)}
                  className="bg-rose-600 hover:bg-rose-700 text-white px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer shadow-xs shrink-0"
                >
                  Deactivate / Delete Driver Account
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-rose-50 border border-rose-100 text-xs text-rose-950 space-y-2">
                <div className="font-bold flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-rose-600" />
                  <span>Automatic Conversion to Normal Customer</span>
                </div>
                <p className="text-[11px] text-rose-800 leading-relaxed">
                  When you delete your driver account, your mobile number <strong>{currentDriver?.phone || '+91 94258 21388'}</strong> is not blocked. Instead, your account is automatically converted to a <strong>Normal Customer account</strong> so you can continue using Antifly to order food, shop from local stores, and earn SuperCoins!
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* FULL DRIVER KYC REGISTRATION & PROOFS UPLOAD MODAL */}
      {isKycModalOpen && (
        <div className="fixed inset-0 z-50 bg-white/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 max-w-2xl w-full shadow-2xl space-y-5 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="font-black text-lg text-slate-900 flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  <span>Driver Account Registration & KYC Proofs</span>
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Upload original vehicle documents, driving license, Aadhaar card & voter ID for 24-hour admin verification.
                </p>
              </div>
              <button
                onClick={() => setIsKycModalOpen(false)}
                className="p-1 rounded-xl text-slate-400 hover:bg-slate-100 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleKycRegistrationSubmit} className="space-y-4 max-h-[60vh] overflow-y-auto pr-1 text-xs">
              {/* Partner Basic Info */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <h4 className="font-black text-slate-900 uppercase tracking-wider text-[11px]">
                  1. Partner Details
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">Full Legal Name *</label>
                    <input
                      type="text"
                      required
                      value={kycForm.name}
                      onChange={(e) => setKycForm({ ...kycForm, name: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">Mobile Number *</label>
                    <input
                      type="tel"
                      required
                      value={kycForm.phone}
                      onChange={(e) => setKycForm({ ...kycForm, phone: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">Email Address</label>
                    <input
                      type="email"
                      value={kycForm.email}
                      onChange={(e) => setKycForm({ ...kycForm, email: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">City / Region *</label>
                    <input
                      type="text"
                      required
                      value={kycForm.city}
                      onChange={(e) => setKycForm({ ...kycForm, city: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              </div>

              {/* Bike & Vehicle Proofs */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <h4 className="font-black text-slate-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <Bike className="w-4 h-4 text-blue-600" />
                  2. Bike Details & Original RC Documents
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">Vehicle Type *</label>
                    <select
                      value={kycForm.vehicleType}
                      onChange={(e) => setKycForm({ ...kycForm, vehicleType: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-bold text-slate-900 focus:outline-none"
                    >
                      <option value="Electric Bike">Electric Bike (EV)</option>
                      <option value="Motorcycle / Bike">Motorcycle / Petrol Bike</option>
                      <option value="EV Scooter">EV Scooter</option>
                      <option value="CNG Auto">CNG Auto</option>
                      <option value="Cargo Delivery Van">Cargo Delivery Van</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">Bike Number Plate (RC) *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. MP-09-EV-8899"
                      value={kycForm.vehicleNumber}
                      onChange={(e) => setKycForm({ ...kycForm, vehicleNumber: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-bold text-slate-900 font-mono focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-slate-700 font-bold mb-1">Original Bike RC Document Image URL *</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="url"
                        required
                        value={kycForm.bikeRcDocumentUrl}
                        onChange={(e) => setKycForm({ ...kycForm, bikeRcDocumentUrl: e.target.value })}
                        className="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-xl font-medium text-slate-900 focus:outline-none focus:border-emerald-500"
                      />
                      <span className="text-[10px] text-emerald-700 font-bold bg-emerald-100 px-2 py-1.5 rounded-lg shrink-0">
                        ✓ RC Attached
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Driving License Proof */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <h4 className="font-black text-slate-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <CreditCard className="w-4 h-4 text-emerald-600" />
                  3. Driving License (DL) Original Proof
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">DL Number *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. DL-MP09-2024-00192"
                      value={kycForm.drivingLicense}
                      onChange={(e) => setKycForm({ ...kycForm, drivingLicense: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-bold text-slate-900 font-mono focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">Original DL Front Image URL *</label>
                    <input
                      type="url"
                      required
                      value={kycForm.drivingLicenseFrontUrl}
                      onChange={(e) => setKycForm({ ...kycForm, drivingLicenseFrontUrl: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-medium text-slate-900 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              </div>

              {/* Aadhaar Card & Voter ID Card Proofs */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <h4 className="font-black text-slate-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-purple-600" />
                  4. Aadhaar Card & Voter ID Card Original Proofs
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">Aadhaar Card Number (12 Digits) *</label>
                    <input
                      type="text"
                      required
                      placeholder="7829 4410 9921"
                      value={kycForm.aadhaarNumber}
                      onChange={(e) => setKycForm({ ...kycForm, aadhaarNumber: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-bold text-slate-900 font-mono focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">Original Aadhaar Proof Image URL *</label>
                    <input
                      type="url"
                      required
                      value={kycForm.aadhaarFrontUrl}
                      onChange={(e) => setKycForm({ ...kycForm, aadhaarFrontUrl: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-medium text-slate-900 focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-bold mb-1">Voter ID Card Number (EPIC) *</label>
                    <input
                      type="text"
                      required
                      placeholder="MP/24/098/120938"
                      value={kycForm.voterIdNumber}
                      onChange={(e) => setKycForm({ ...kycForm, voterIdNumber: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-bold text-slate-900 font-mono focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">Original Voter ID Document URL *</label>
                    <input
                      type="url"
                      required
                      value={kycForm.voterIdDocUrl}
                      onChange={(e) => setKycForm({ ...kycForm, voterIdDocUrl: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-medium text-slate-900 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              </div>

              {/* 24h SLA Notice */}
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl text-xs text-amber-950 space-y-1">
                <strong>🔒 Secure Verification Policy (24-Hour SLA)</strong>
                <p className="text-[11px] text-amber-900">
                  All documents are securely encrypted. An admin will review and verify your bike RC, DL, Aadhaar, and voter ID within 24 hours. After verification, features will be unlocked and you should log in to start accepting delivery tasks within 24 hours.
                </p>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl text-xs font-black transition cursor-pointer shadow-md flex items-center justify-center gap-2"
              >
                <UploadCloud className="w-4 h-4" />
                <span>Submit KYC Documents for 24h Admin Verification</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 7-DAY DEACTIVATION / ROLE CONVERSION MODAL */}
      {isDeactivateModalOpen && (
        <div className="fixed inset-0 z-50 bg-white/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-black text-base text-slate-900 flex items-center gap-2">
                <Trash2 className="w-5 h-5 text-rose-600" />
                <span>Driver Deactivation & Role Conversion</span>
              </h3>
              <button
                onClick={() => setIsDeactivateModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-600 font-medium">
                Choose an action for your driver partner account with mobile number <strong>{currentDriver?.phone}</strong>:
              </p>

              <div className="space-y-2">
                <label
                  onClick={() => setSelectedDeactivateAction('7_DAY_FREEZE')}
                  className={`p-3.5 rounded-2xl border flex items-start gap-3 cursor-pointer transition ${
                    selectedDeactivateAction === '7_DAY_FREEZE'
                      ? 'bg-amber-50 border-amber-400 ring-2 ring-amber-300/30'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <input
                    type="radio"
                    checked={selectedDeactivateAction === '7_DAY_FREEZE'}
                    onChange={() => setSelectedDeactivateAction('7_DAY_FREEZE')}
                    className="mt-0.5"
                  />
                  <div>
                    <strong className="block font-black text-slate-900">
                      Option 1: Dynamic {accountLifecycleConfig.driverGraceDays}-Day Deactivation Freeze
                    </strong>
                    <span className="text-[11px] text-slate-500">
                      Pause deliveries for {accountLifecycleConfig.driverGraceDays} days. If not reactivated, it will automatically convert to a normal customer.
                    </span>
                  </div>
                </label>

                <label
                  onClick={() => setSelectedDeactivateAction('DELETE_CONVERT_CUSTOMER')}
                  className={`p-3.5 rounded-2xl border flex items-start gap-3 cursor-pointer transition ${
                    selectedDeactivateAction === 'DELETE_CONVERT_CUSTOMER'
                      ? 'bg-rose-50 border-rose-400 ring-2 ring-rose-300/30'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <input
                    type="radio"
                    checked={selectedDeactivateAction === 'DELETE_CONVERT_CUSTOMER'}
                    onChange={() => setSelectedDeactivateAction('DELETE_CONVERT_CUSTOMER')}
                    className="mt-0.5"
                  />
                  <div>
                    <strong className="block font-black text-rose-950">
                      Option 2: Delete Driver Account & Convert to Normal Customer
                    </strong>
                    <span className="text-[11px] text-rose-800">
                      Immediately close driver profile and convert account to a Normal Customer. You can shop and browse using the same mobile number.
                    </span>
                  </div>
                </label>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Reason for Deactivation</label>
                <input
                  type="text"
                  value={deactivationReason}
                  onChange={(e) => setDeactivationReason(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-900 focus:outline-none"
                />
              </div>

              <button
                onClick={handleDeactivateOrConvert}
                className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-black text-xs transition cursor-pointer shadow-xs mt-2"
              >
                {selectedDeactivateAction === '7_DAY_FREEZE'
                  ? `Confirm ${accountLifecycleConfig.driverGraceDays}-Day Deactivation Freeze`
                  : 'Convert Directly to Normal Customer'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top Driver Header Strip */}
      <div className="bg-slate-50 border-b border-slate-200 py-3 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-600 flex items-center justify-center text-white font-black text-lg shadow-sm">
              <Bike className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-base sm:text-lg text-slate-900">
                  Antifly Buddy Partner
                </h1>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black border border-emerald-300">
                  {currentDriver?.isOnline ? '🟢 ONLINE' : '⚪ OFFLINE'}
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Vehicle: <strong>{currentDriver?.vehicleType || 'Electric Bike'}</strong> ({currentDriver?.vehicleNumber || 'MP-09-EV-2024'})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
            {/* Real Credit Balance Widget */}
            <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-2xl">
              <Coins className="w-4 h-4 text-amber-600 fill-amber-400" />
              <div>
                <div className="text-[10px] text-amber-800 font-bold uppercase tracking-wider">Incentive Credits</div>
                <div className="text-xs sm:text-sm font-black text-slate-900">
                  {driverCredits} Credits <span className="text-[11px] text-emerald-700 font-extrabold">(= ₹{driverCredits})</span>
                </div>
              </div>
            </div>

            {/* Vehicle Login / Switch Button */}
            <button
              onClick={() => setIsVehicleModalOpen(true)}
              className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 px-3 py-2 rounded-2xl text-xs font-black transition cursor-pointer border border-slate-200"
            >
              <Car className="w-3.5 h-3.5 text-blue-600" />
              <span>Vehicle Setup</span>
            </button>

            {/* Online / Offline Toggle */}
            <button
              onClick={() => currentDriver && toggleDriverOnline(currentDriver.id)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-black transition cursor-pointer shadow-xs ${
                currentDriver?.isOnline
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
              }`}
            >
              <Power className="w-3.5 h-3.5" />
              <span>{currentDriver?.isOnline ? 'Go Offline' : 'Go Online'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="border-b border-slate-200 bg-white sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center gap-2 overflow-x-auto py-2">
          <button
            onClick={() => setActiveTab('trips')}
            className={`py-2 px-4 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap ${
              activeTab === 'trips'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            📦 Active Delivery Trips ({pendingTasks.length})
          </button>

          <button
            onClick={() => setActiveTab('incentives')}
            className={`py-2 px-4 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'incentives'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 text-amber-500" />
            <span>Daily Incentives & Milestone Rewards</span>
          </button>

          <button
            onClick={() => setActiveTab('wallet')}
            className={`py-2 px-4 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'wallet'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Wallet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Credit Payouts & Real ₹ Transfer</span>
          </button>

          <button
            onClick={() => setActiveTab('vehicle')}
            className={`py-2 px-4 rounded-xl text-xs font-black transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'vehicle'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Car className="w-3.5 h-3.5 text-blue-600" />
            <span>My Registered Vehicle</span>
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {/* INCOMING VENTURE BROADCAST CALL BANNER (5KM RADAR) */}
        {activeVentureBookingCall && activeVentureBookingCall.status === 'RINGING' && (
          <div className="mb-6 bg-gradient-to-r from-amber-600 via-rose-600 to-amber-600 p-5 rounded-3xl text-white shadow-2xl border-2 border-amber-300 animate-pulse flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-white text-rose-600 flex items-center justify-center font-black shadow-lg animate-bounce shrink-0">
                <Phone className="w-7 h-7" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-white text-xs font-black uppercase tracking-wider">
                    🚨 INCOMING VENTURE BROADCAST CALL (5km RADAR)
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-300 text-slate-800 text-[10px] font-black uppercase">
                    ₹15/km Distance Fare
                  </span>
                </div>
                <h3 className="text-lg sm:text-xl font-black text-white mt-0.5">
                  {activeVentureBookingCall.ventureName} is Calling (+91 {activeVentureBookingCall.venturePhone})
                </h3>
                <p className="text-xs sm:text-sm text-amber-100 font-semibold mt-1">
                  Trip Distance: <strong>{activeVentureBookingCall.deliveryDistanceKm || 3} km</strong> (@ ₹{activeVentureBookingCall.ratePerKm || 15}/km) &bull; Total Earning: <strong className="text-white text-base font-mono">₹{activeVentureBookingCall.totalAmount || activeVentureBookingCall.estimatedFare}</strong>
                </p>
                <p className="text-xs text-amber-200 mt-0.5">
                  Pickup: {activeVentureBookingCall.ventureStoreAddress} &rarr; Drop: {activeVentureBookingCall.customerAddress}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => declineVentureBuddyCall(activeVentureBookingCall.id, currentDriver?.id || 'driver-indore-01')}
                className="px-4 py-2.5 bg-rose-900/60 hover:bg-rose-900 text-white rounded-xl text-xs font-bold transition-all border border-white/20 cursor-pointer"
              >
                Decline
              </button>
              <button
                onClick={() => acceptVentureBuddyCall(activeVentureBookingCall.id, currentDriver?.id || 'driver-indore-01')}
                className="px-5 py-2.5 bg-white hover:bg-amber-100 text-slate-800 font-black rounded-xl text-xs sm:text-sm transition-all shadow-lg flex items-center gap-2 hover:scale-105 cursor-pointer animate-bounce"
              >
                <Phone className="w-4 h-4 text-emerald-600" />
                <span>ACCEPT & EARN ₹{activeVentureBookingCall.totalAmount || activeVentureBookingCall.estimatedFare}</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 1: TRIPS & ACTIVE DELIVERIES */}
        {activeTab === 'trips' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left: Task List */}
            <div className="lg:col-span-1 space-y-4">
              <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
                    <Truck className="w-4 h-4 text-red-600" />
                    <span>Nearby Pickup Orders</span>
                  </h3>
                  <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs font-bold">
                    {pendingTasks.length} pending
                  </span>
                </div>

                <div className="space-y-3 max-h-[550px] overflow-y-auto pr-1">
                  {pendingTasks.map((task) => (
                    <div
                      key={task.id}
                      onClick={() => setSelectedTaskId(task.id)}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                        selectedTaskId === task.id
                          ? 'border-red-500 bg-red-50/40 shadow-xs'
                          : 'border-slate-200 bg-slate-50/60 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-slate-900">
                          {task.trackingNumber}
                        </span>
                        <span className="text-[11px] font-extrabold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                          +₹{task.payoutFee} Earning
                        </span>
                      </div>

                      <div className="mt-2 text-xs text-slate-600 space-y-1">
                        <div className="flex items-center gap-1 text-slate-900 font-semibold truncate">
                          <MapPin className="w-3.5 h-3.5 text-blue-600 flex-shrink-0" />
                          <span className="truncate">From: {task.sellerName}</span>
                        </div>
                        <div className="flex items-center gap-1 text-slate-900 font-semibold truncate">
                          <MapPin className="w-3.5 h-3.5 text-red-600 flex-shrink-0" />
                          <span className="truncate">To: {task.customerAddress}</span>
                        </div>
                      </div>

                      <div className="mt-3 flex items-center justify-between text-[11px] font-bold text-slate-500 pt-2 border-t border-slate-200/60">
                        <span>{task.distanceKm} km trip</span>
                        <span className="text-slate-800 font-extrabold">Pay Mode: {task.paymentMode}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right: Active Delivery Detail & Verification Flow */}
            <div className="lg:col-span-2 space-y-5">
              {activeTask ? (
                <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                    <div>
                      <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-black">
                        {activeTask.status}
                      </span>
                      <h2 className="text-lg sm:text-xl font-black text-slate-900 mt-1">
                        Order #{activeTask.orderId} — {activeTask.customerName}
                      </h2>
                      <p className="text-xs text-slate-500 font-medium">
                        Pickup from <strong>{activeTask.sellerName}</strong> • Delivery in {activeTask.estimatedMinutes} mins
                      </p>
                    </div>

                    <div className="text-right">
                      <div className="text-xs text-slate-500 font-bold uppercase">Trip Payout</div>
                      <div className="text-2xl font-black text-emerald-600">
                        ₹{activeTask.payoutFee + activeTask.tipAmount}
                      </div>
                    </div>
                  </div>

                  {/* Pickup & Drop Details */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                      <span className="text-[10px] font-black text-blue-700 uppercase tracking-wider">Pickup Warehouse (Venture)</span>
                      <h4 className="font-extrabold text-sm text-slate-900 mt-1">{activeTask.sellerName}</h4>
                      <p className="text-xs text-slate-600 mt-0.5">{activeTask.sellerAddress}</p>
                    </div>

                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                      <span className="text-[10px] font-black text-red-700 uppercase tracking-wider">Customer Destination</span>
                      <h4 className="font-extrabold text-sm text-slate-900 mt-1">{activeTask.customerName}</h4>
                      <p className="text-xs text-slate-600 mt-0.5">{activeTask.customerAddress}</p>
                      <p className="text-xs font-bold text-slate-900 mt-1 flex items-center gap-1">
                        <Phone className="w-3 h-3 text-emerald-600" />
                        <span>{activeTask.customerPhone}</span>
                      </p>
                    </div>
                  </div>

                  {/* Venture Booking & Distance Compensation Receipt */}
                  <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 border border-emerald-200 flex flex-wrap items-center justify-between gap-3 text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-extrabold text-slate-900 text-sm">
                          📍 Trip Distance: {activeTask.ventureDistanceKm || activeTask.distanceKm || 3} km
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-200 text-emerald-900 font-bold text-[10px]">
                          ₹{activeTask.ventureRatePerKm || 15}/km Rate
                        </span>
                        {(activeTask.seasonalSurgeBonus || 0) > 0 && (
                          <span className="px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 font-bold text-[10px] flex items-center gap-1">
                            <span>{activeTask.seasonApplied === 'RAINY' ? '🌧️ Monsoon' : '☀️ Summer'}</span>
                            <span>+₹{activeTask.seasonalSurgeBonus}</span>
                          </span>
                        )}
                      </div>
                      <p className="text-slate-600 text-xs">
                        Venture Payout Calculation: Base ₹{activeTask.ventureBaseFare || 30} + (<strong>{activeTask.ventureDistanceKm || activeTask.distanceKm || 3} km</strong> × <strong>₹{activeTask.ventureRatePerKm || 15}/km</strong>)
                        {(activeTask.seasonalSurgeBonus || 0) > 0 && ` + Season Surge ₹${activeTask.seasonalSurgeBonus}`} = <strong className="text-emerald-700 font-mono text-sm">₹{activeTask.venturePayableAmount || activeTask.payoutFee}</strong>
                      </p>
                    </div>

                    <div className="text-right">
                      <span className={`inline-block px-3 py-1 rounded-xl text-xs font-black ${
                        activeTask.paymentStatus === 'PAID'
                          ? 'bg-emerald-600 text-white'
                          : activeTask.paymentStatus === 'SETTLED_ON_PICKUP'
                          ? 'bg-amber-500 text-slate-800'
                          : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                      }`}>
                        {activeTask.paymentStatus === 'PAID'
                          ? '✓ PAIRED & CREDITED'
                          : activeTask.paymentStatus === 'SETTLED_ON_PICKUP'
                          ? '💵 CASH AT PICKUP'
                          : `✓ EARNING ₹${activeTask.venturePayableAmount || activeTask.payoutFee}`}
                      </span>
                      {activeTask.paymentUtr && (
                        <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                          UTR: {activeTask.paymentUtr}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* COD Collection Alert */}
                  {activeTask.paymentMode === 'COD' && (
                    <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs font-bold text-amber-900">
                        <IndianRupee className="w-5 h-5 text-amber-600" />
                        <span>Cash on Delivery to Collect: <strong>₹{activeTask.codAmountToCollect}</strong></span>
                      </div>
                      <span className="text-xs font-extrabold text-amber-900 bg-amber-200/80 px-2.5 py-1 rounded-xl">
                        Collect Cash Before Handover
                      </span>
                    </div>
                  )}

                  {/* Delivery Actions */}
                  <div className="space-y-4 pt-3 border-t border-slate-100">
                    <h3 className="font-extrabold text-sm text-slate-900">Delivery Status Handover</h3>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <button
                        onClick={() => updateDriverTaskStatus(activeTask.id, 'Heading to Pickup')}
                        className={`py-2 px-3 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                          activeTask.status === 'Heading to Pickup'
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        }`}
                      >
                        1. To Pickup
                      </button>

                      <button
                        onClick={() => updateDriverTaskStatus(activeTask.id, 'Picked Up')}
                        className={`py-2 px-3 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                          activeTask.status === 'Picked Up'
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        }`}
                      >
                        2. Picked Up
                      </button>

                      <button
                        onClick={() => updateDriverTaskStatus(activeTask.id, 'In Transit')}
                        className={`py-2 px-3 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                          activeTask.status === 'In Transit'
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        }`}
                      >
                        3. In Transit
                      </button>

                      <button
                        onClick={() => updateDriverTaskStatus(activeTask.id, 'Arrived at Drop')}
                        className={`py-2 px-3 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                          activeTask.status === 'Arrived at Drop'
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        }`}
                      >
                        4. At Doorstep
                      </button>
                    </div>

                    {/* Customer 4-Digit Delivery OTP Verification */}
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                      <h4 className="font-extrabold text-xs text-slate-900">
                        Enter Customer OTP to Finish Delivery & Credit Payout
                      </h4>
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          maxLength={6}
                          value={enteredOtp}
                          onChange={(e) => setEnteredOtp(e.target.value)}
                          placeholder="Customer 4-digit OTP (e.g. 4829)"
                          className="flex-1 px-4 py-2.5 bg-white border border-slate-300 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-red-500"
                        />
                        <button
                          onClick={() => {
                            if (!enteredOtp) {
                              showToast('Please enter OTP provided by customer');
                              return;
                            }
                            completeDriverDeliveryWithOtp(activeTask.id, enteredOtp);
                            setEnteredOtp('');
                          }}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white font-black px-5 py-2.5 rounded-xl text-xs transition cursor-pointer shadow-xs"
                        >
                          Verify & Mark Delivered (+₹{activeTask.payoutFee})
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center shadow-xs">
                  <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                  <h3 className="font-extrabold text-lg text-slate-900">All Pickups Completed!</h3>
                  <p className="text-xs text-slate-500 font-medium mt-1">
                    Stay online to receive new hyperlocal delivery requests automatically.
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: DAILY INCENTIVES & MILESTONE REWARDS */}
        {activeTab === 'incentives' && (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-red-500/10 border border-amber-200 rounded-3xl p-6 sm:p-7">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="px-3 py-1 rounded-full bg-amber-600 text-white text-xs font-black">
                    🔥 Daily Delivery Bonus
                  </span>
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
                    Deliver More Orders, Earn Instant Cash Credits!
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-600 font-medium mt-1">
                    1 Credit = ₹1 Real Rupee. Hit your daily delivery milestones and receive cash incentives directly.
                  </p>
                </div>

                <div className="bg-white border border-amber-300 px-5 py-3 rounded-2xl text-center shadow-xs">
                  <span className="text-[10px] uppercase font-black text-slate-500">Today's Deliveries</span>
                  <div className="text-2xl sm:text-3xl font-black text-red-600">
                    {completedCount} / 20 Orders
                  </div>
                </div>
              </div>
            </div>

            {/* 3 Milestone Tiers */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {/* Tier 1: 5 Orders */}
              <div className={`p-6 rounded-3xl border transition-all ${
                completedCount >= 5
                  ? 'bg-white border-emerald-400 shadow-md ring-2 ring-emerald-500/20'
                  : 'bg-white border-slate-200 shadow-xs'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-black">
                    Level 1 Milestone
                  </span>
                  <Award className="w-5 h-5 text-blue-600" />
                </div>
                <h3 className="text-lg font-black text-slate-900 mt-3">Deliver 5 Orders</h3>
                <p className="text-xs text-slate-500 mt-1">Get +50 Incentive Credits (= ₹50 Cash Bonus)</p>

                <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs font-extrabold text-slate-700">
                    Progress: {Math.min(completedCount, 5)}/5
                  </span>
                  {completedCount >= 5 ? (
                    <span className="px-3 py-1 rounded-xl bg-emerald-100 text-emerald-800 font-black text-xs">
                      ✓ Claimed +50 Credits
                    </span>
                  ) : (
                    <span className="text-xs text-slate-400 font-bold">
                      {5 - completedCount} orders left
                    </span>
                  )}
                </div>
              </div>

              {/* Tier 2: 10 Orders */}
              <div className={`p-6 rounded-3xl border transition-all ${
                completedCount >= 10
                  ? 'bg-white border-emerald-400 shadow-md ring-2 ring-emerald-500/20'
                  : 'bg-white border-slate-200 shadow-xs'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded-full bg-purple-100 text-purple-800 text-xs font-black">
                    Level 2 Milestone
                  </span>
                  <TrendingUp className="w-5 h-5 text-purple-600" />
                </div>
                <h3 className="text-lg font-black text-slate-900 mt-3">Deliver 10 Orders</h3>
                <p className="text-xs text-slate-500 mt-1">Get +120 Incentive Credits (= ₹120 Cash Bonus)</p>

                <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs font-extrabold text-slate-700">
                    Progress: {Math.min(completedCount, 10)}/10
                  </span>
                  {completedCount >= 10 ? (
                    <span className="px-3 py-1 rounded-xl bg-emerald-100 text-emerald-800 font-black text-xs">
                      ✓ Claimed +120 Credits
                    </span>
                  ) : (
                    <span className="text-xs text-slate-400 font-bold">
                      {10 - completedCount} orders left
                    </span>
                  )}
                </div>
              </div>

              {/* Tier 3: 20 Orders Super Milestone */}
              <div className={`p-6 rounded-3xl border transition-all ${
                completedCount >= 20
                  ? 'bg-white border-amber-400 shadow-md ring-2 ring-amber-500/20'
                  : 'bg-white border-slate-200 shadow-xs'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-xs font-black">
                    🏆 Super Star Milestone
                  </span>
                  <Sparkles className="w-5 h-5 text-amber-600 animate-pulse" />
                </div>
                <h3 className="text-lg font-black text-slate-900 mt-3">Deliver 20 Orders in 1 Day</h3>
                <p className="text-xs text-slate-500 mt-1">Get +300 Incentive Credits (= ₹300 Mega Bonus!)</p>

                <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs font-extrabold text-slate-700">
                    Progress: {Math.min(completedCount, 20)}/20
                  </span>
                  {completedCount >= 20 ? (
                    <span className="px-3 py-1 rounded-xl bg-amber-100 text-amber-900 font-black text-xs">
                      ✓ Claimed ₹300 Mega Bonus
                    </span>
                  ) : (
                    <span className="text-xs text-slate-400 font-bold">
                      {20 - completedCount} orders left
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: CREDIT CONVERSION & WALLET PAYOUTS */}
        {activeTab === 'wallet' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 space-y-4">
              <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs">
                <span className="text-xs font-black text-slate-400 uppercase tracking-wider">
                  Available Buddy Balance
                </span>
                <div className="text-3xl font-black text-slate-900 mt-1">
                  ₹{driverCredits}.00
                </div>
                <p className="text-xs text-emerald-700 font-bold mt-1">
                  Includes ₹20 Vehicle Login Bonus + ₹{driverCredits - 20} Delivery Incentives
                </p>

                <div className="mt-5 space-y-2 pt-4 border-t border-slate-100 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>Credit to Rupee Ratio</span>
                    <strong className="text-slate-900">1 Credit = ₹1 INR</strong>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>UPI Transfer Fee</span>
                    <strong className="text-emerald-700 font-bold">₹0.00 (Free)</strong>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Payout Speed</span>
                    <strong className="text-slate-900">Instant UPI Transfer</strong>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-2">
              <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
                <h3 className="text-base font-black text-slate-900">
                  Convert Credits & Transfer Direct to Bank UPI
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Enter the amount of credits you wish to withdraw to your Indian bank account or PhonePe/GPay UPI ID.
                </p>

                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Credits to Convert (1 Credit = ₹1)
                    </label>
                    <input
                      type="number"
                      max={driverCredits}
                      min={10}
                      value={creditsToConvert}
                      onChange={(e) => setCreditsToConvert(Number(e.target.value))}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-black text-slate-900 focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Receiver UPI ID / VPA
                    </label>
                    <input
                      type="text"
                      value={driverUpiId}
                      onChange={(e) => setDriverUpiId(e.target.value)}
                      placeholder="e.g. drivername@okaxis or 9876543210@ybl"
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <button
                    onClick={handleConvertCreditsToRupees}
                    disabled={isConvertingCredits}
                    className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-2xl text-xs sm:text-sm font-black transition cursor-pointer shadow-xs mt-2"
                  >
                    {isConvertingCredits ? 'Processing UPI Transfer...' : `Convert ${creditsToConvert} Credits to ₹${creditsToConvert} Real Rupees`}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: VEHICLE SETUP & DETAILS */}
        {activeTab === 'vehicle' && (
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-xs space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-slate-900">Registered Buddy Vehicle</h3>
                <p className="text-xs text-slate-500 font-medium">
                  Login your own vehicle to claim +20 welcome credits and start delivering immediately.
                </p>
              </div>

              <button
                onClick={() => setIsVehicleModalOpen(true)}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer shadow-xs"
              >
                Edit Vehicle Details
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] font-black text-slate-400 uppercase">Vehicle Type</span>
                <h4 className="font-extrabold text-base text-slate-900 mt-1 flex items-center gap-1.5">
                  <Bike className="w-4 h-4 text-blue-600" />
                  <span>{currentDriver?.vehicleType || 'Electric Bike'}</span>
                </h4>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] font-black text-slate-400 uppercase">Number Plate</span>
                <h4 className="font-extrabold text-base text-slate-900 mt-1">
                  {currentDriver?.vehicleNumber || 'MP-09-EV-2024'}
                </h4>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] font-black text-slate-400 uppercase">Driving License</span>
                <h4 className="font-extrabold text-base text-slate-900 mt-1">
                  {currentDriver?.drivingLicense || 'DL-MP09-202488'}
                </h4>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Vehicle Registration & Login Modal */}
      {isVehicleModalOpen && (
        <div className="fixed inset-0 z-50 bg-white/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-black text-base text-slate-900 flex items-center gap-2">
                <Car className="w-5 h-5 text-red-600" />
                <span>Buddy Vehicle Login</span>
              </h3>
              <button
                onClick={() => setIsVehicleModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleVehicleLogin} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Choose Vehicle Type
                </label>
                <select
                  value={driverVehicleType}
                  onChange={(e) => setDriverVehicleType(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none"
                >
                  <option value="Motorcycle / Bike">Motorcycle / Bike (Petrol)</option>
                  <option value="Electric Scooter / EV Bike">Electric Scooter / EV Bike</option>
                  <option value="CNG / Electric Auto Rickshaw">CNG / Electric Auto Rickshaw</option>
                  <option value="Cargo Delivery Van">Cargo Delivery Van</option>
                  <option value="Bicycle (Eco Delivery)">Bicycle (Eco Delivery)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Vehicle Registration Number (RC)
                </label>
                <input
                  type="text"
                  required
                  value={driverVehicleNumber}
                  onChange={(e) => setDriverVehicleNumber(e.target.value)}
                  placeholder="e.g. MP-09-AB-1234"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Driving License Number
                </label>
                <input
                  type="text"
                  required
                  value={driverLicenseNumber}
                  onChange={(e) => setDriverLicenseNumber(e.target.value)}
                  placeholder="e.g. DL-MP-2024-00192"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none"
                />
              </div>

              <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-900 font-semibold">
                🎁 <strong>Login Bonus</strong>: Get <strong>+20 Incentive Credits (= ₹20)</strong> credited instantly upon logging your vehicle!
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black transition cursor-pointer shadow-xs"
              >
                Log In Vehicle & Claim +20 Credits
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
