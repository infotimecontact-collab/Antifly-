import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Bell,
  CheckCircle2,
  Tag,
  Package,
  Sparkles,
  Zap,
  Clock,
  Trash2,
  Check,
} from 'lucide-react';

export const MobileNotificationsScreen: React.FC = () => {
  const { notifications, markNotificationAsRead, markAllNotificationsAsRead, showToast } = useApp();
  const [filter, setFilter] = useState<'all' | 'orders' | 'deals' | 'social'>('all');

  const filteredNotifications = notifications.filter((n) => {
    if (filter === 'orders') return n.type === 'order';
    if (filter === 'deals') return n.type === 'promo' || n.type === 'alert';
    if (filter === 'social') return n.type === 'message' || n.type === 'system';
    return true;
  });

  return (
    <div className="p-3 space-y-3 text-xs pb-10">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
            <Bell className="w-4 h-4 text-amber-500" />
            <span>Notifications ({notifications.filter((n) => !n.isRead).length} New)</span>
          </h2>
          <p className="text-[10px] text-slate-500 dark:text-slate-400">
            Real-time updates on orders, price drops & live sales
          </p>
        </div>

        <button
          onClick={() => {
            markAllNotificationsAsRead();
            showToast('✅ All notifications marked as read');
          }}
          className="text-[10px] font-bold text-amber-600 dark:text-amber-400 hover:underline"
        >
          Mark all read
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
        {[
          { id: 'all', label: 'All Updates' },
          { id: 'orders', label: '📦 Orders' },
          { id: 'deals', label: '🔥 Offers & Deals' },
          { id: 'social', label: '💬 Social & Chats' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilter(tab.id as any)}
            className={`px-3 py-1 rounded-xl font-bold text-[11px] whitespace-nowrap transition-all ${
              filter === tab.id
                ? 'bg-amber-500 text-slate-800 shadow-sm'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Notifications List */}
      {filteredNotifications.length === 0 ? (
        <div className="py-16 text-center space-y-2 text-slate-400">
          <Bell className="w-12 h-12 mx-auto stroke-1 text-slate-300 dark:text-slate-600" />
          <p className="font-bold text-sm text-slate-700 dark:text-slate-300">All caught up!</p>
          <p className="text-[11px]">No new notifications at this time.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filteredNotifications.map((notif) => (
            <div
              key={notif.id}
              onClick={() => markNotificationAsRead(notif.id)}
              className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 ${
                notif.isRead
                  ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                  : 'bg-amber-50/80 dark:bg-amber-950/40 border-amber-300 dark:border-amber-900/60 shadow-xs'
              }`}
            >
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                  notif.type === 'order'
                    ? 'bg-blue-100 dark:bg-blue-950 text-blue-600'
                    : notif.type === 'promo'
                    ? 'bg-rose-100 dark:bg-rose-950 text-rose-600'
                    : 'bg-amber-100 dark:bg-amber-950 text-amber-600'
                }`}
              >
                {notif.type === 'order' ? (
                  <Package className="w-4 h-4" />
                ) : notif.type === 'promo' ? (
                  <Zap className="w-4 h-4" />
                ) : (
                  <Bell className="w-4 h-4" />
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1">
                  <h4 className="font-extrabold text-[11px] text-slate-900 dark:text-white truncate">
                    {notif.title}
                  </h4>
                  <span className="text-[9px] text-slate-400 font-medium shrink-0">
                    {new Date(notif.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <p className="text-[10px] text-slate-600 dark:text-slate-300 mt-0.5 leading-relaxed">
                  {notif.message}
                </p>
              </div>

              {!notif.isRead && (
                <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0 mt-1" />
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
