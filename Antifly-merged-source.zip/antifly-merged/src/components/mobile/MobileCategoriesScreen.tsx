import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../common/ProductCard';
import { ChevronRight, Grid, ArrowLeft } from 'lucide-react';

export const MobileCategoriesScreen: React.FC = () => {
  const { categories, products, selectedCategorySlug, setSelectedCategorySlug } = useApp();
  const [activeSubcat, setActiveSubcat] = useState<string | null>(null);

  const selectedCategory = categories.find((c) => c.slug === selectedCategorySlug);
  const categoryProducts = selectedCategorySlug === 'all'
    ? products
    : products.filter(
        (p) =>
          p.category.toLowerCase() === selectedCategorySlug.toLowerCase() ||
          p.subcategory.toLowerCase() === selectedCategorySlug.toLowerCase()
      );

  return (
    <div className="p-3 space-y-4 text-xs pb-8">
      {/* Category Pills Header */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        <button
          onClick={() => {
            setSelectedCategorySlug('all');
            setActiveSubcat(null);
          }}
          className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap text-[11px] transition-all ${
            selectedCategorySlug === 'all'
              ? 'bg-amber-500 text-slate-800 shadow-sm'
              : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
          }`}
        >
          All Items ({products.length})
        </button>

        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => {
              setSelectedCategorySlug(cat.slug);
              setActiveSubcat(null);
            }}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap text-[11px] transition-all ${
              selectedCategorySlug === cat.slug
                ? 'bg-amber-500 text-slate-800 shadow-sm'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* Subcategory Pills if category selected */}
      {selectedCategory && selectedCategory.subcategories.length > 0 && (
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {selectedCategory.subcategories.map((sub, idx) => (
            <span
              key={idx}
              className="px-2.5 py-1 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[10px] font-semibold flex-shrink-0"
            >
              {sub}
            </span>
          ))}
        </div>
      )}

      {/* Products Grid */}
      <div className="grid grid-cols-2 gap-2.5">
        {categoryProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};
