import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../common/ProductCard';
import {
  Heart,
  Bookmark,
  FolderPlus,
  Layers,
  Sparkles,
  ShoppingBag,
  Store,
  Film,
  MessageSquare,
  ChevronRight,
  Plus,
} from 'lucide-react';
import { UniversalSaveButton } from '../favorites/UniversalSaveButton';

export const MobileFavoritesScreen: React.FC = () => {
  const {
    savedItems,
    customCollections,
    products,
    sellers,
    reels,
    setIsFavoritesHubOpen,
    setIsSaveToCollectionOpen,
    addToCart,
    showToast,
  } = useApp();

  const [selectedCollection, setSelectedCollection] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<'all' | 'product' | 'seller' | 'reel' | 'post'>('all');

  const defaultCollections = [
    { id: 'all', name: 'All Vault Items', icon: '🌟' },
    { id: 'Fashion', name: 'Fashion & Looks', icon: '👗' },
    { id: 'Electronics', name: 'Electronics', icon: '⚡' },
    { id: 'Home', name: 'Home & Kitchen', icon: '🏡' },
    { id: 'Gifts', name: 'Gifts & Festive', icon: '🎁' },
    { id: 'Wishlist', name: 'Wishlist', icon: '❤️' },
    { id: 'Buy Later', name: 'Buy Later', icon: '🛒' },
    { id: 'My Collection', name: 'My Collection', icon: '📁' },
  ];

  const filteredItems = savedItems.filter((item) => {
    if (selectedCollection !== 'all' && item.collectionName !== selectedCollection) {
      return false;
    }
    if (selectedType !== 'all' && item.itemType !== selectedType) {
      return false;
    }
    return true;
  });

  return (
    <div className="p-3 space-y-3.5 text-xs pb-10">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
            <Bookmark className="w-4 h-4 text-rose-500 fill-rose-500" />
            <span>Universal Favorites & Vault ({savedItems.length})</span>
          </h2>
          <p className="text-[10px] text-slate-500 dark:text-slate-400">
            Products, Creators, Reels & Custom Collections
          </p>
        </div>

        <button
          onClick={() => setIsFavoritesHubOpen(true)}
          className="text-[10px] font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 px-2.5 py-1 rounded-xl border border-amber-300 dark:border-amber-900 flex items-center gap-1"
        >
          <Layers className="w-3 h-3" />
          <span>Full Hub</span>
        </button>
      </div>

      {/* Collection Moodboard Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
        {defaultCollections.map((col) => (
          <button
            key={col.id}
            onClick={() => setSelectedCollection(col.id)}
            className={`px-2.5 py-1 rounded-xl font-bold text-[10px] whitespace-nowrap transition-all flex items-center gap-1 ${
              selectedCollection === col.id
                ? 'bg-rose-500 text-white shadow-sm'
                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
            }`}
          >
            <span>{col.icon}</span>
            <span>{col.name}</span>
          </button>
        ))}
      </div>

      {/* Item Type Quick Filter */}
      <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-900 p-1 rounded-xl">
        {[
          { id: 'all', label: 'All' },
          { id: 'product', label: 'Products' },
          { id: 'seller', label: 'Sellers' },
          { id: 'reel', label: 'Reels' },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setSelectedType(t.id as any)}
            className={`flex-1 py-1 rounded-lg font-bold text-[10px] transition-all text-center ${
              selectedType === t.id
                ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs'
                : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Saved Items Grid */}
      {filteredItems.length === 0 ? (
        <div className="py-16 text-center space-y-2 text-slate-400">
          <Bookmark className="w-12 h-12 mx-auto stroke-1 text-slate-300 dark:text-slate-600" />
          <p className="font-bold text-sm text-slate-700 dark:text-slate-300">No items saved here yet</p>
          <p className="text-[11px]">
            Tap the heart or save icon on any product, reel, or store to collect them here!
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-2.5">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs flex flex-col justify-between"
            >
              <div className="relative aspect-square overflow-hidden bg-slate-100 dark:bg-slate-800">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2 right-2">
                  <UniversalSaveButton
                    targetId={item.targetId}
                    itemType={item.itemType}
                    title={item.title}
                    imageUrl={item.imageUrl}
                    iconType="heart"
                    size="xs"
                  />
                </div>
                {item.badge && (
                  <span className="absolute bottom-2 left-2 bg-rose-600 text-white text-[8px] font-extrabold px-1.5 py-0.5 rounded">
                    {item.badge}
                  </span>
                )}
              </div>

              <div className="p-2.5 space-y-1.5 flex-1 flex flex-col justify-between">
                <div>
                  <span className="text-[9px] font-bold text-rose-500 uppercase tracking-wider block">
                    {item.itemType}
                  </span>
                  <h4 className="font-bold text-[11px] text-slate-900 dark:text-white line-clamp-1">
                    {item.title}
                  </h4>
                  {item.subtitle && (
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-1">
                      {item.subtitle}
                    </p>
                  )}
                </div>

                {item.price !== undefined && (
                  <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800">
                    <span className="font-extrabold text-xs text-slate-900 dark:text-white">
                      ₹{item.price.toLocaleString('en-IN')}
                    </span>
                    <button
                      onClick={() => {
                        addToCart(item.targetId, 1);
                        showToast(`🛒 Added ${item.title} to bag!`);
                      }}
                      className="bg-amber-500 text-slate-800 px-2 py-1 rounded-lg text-[9px] font-extrabold flex items-center gap-1 shadow-2xs"
                    >
                      <ShoppingBag className="w-2.5 h-2.5" />
                      <span>Add</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
