import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  User,
  Package,
  MapPin,
  CreditCard,
  Sparkles,
  Truck,
  RotateCcw,
  ChevronRight,
  ShieldCheck,
  Gift,
  Bell,
  Trash2,
  LogIn,
} from 'lucide-react';

export const MobileAccountScreen: React.FC = () => {
  const {
    currentCustomer,
    orders,
    setActiveTrackingOrder,
    setIsWiseAIOpen,
    setIsNotificationDrawerOpen,
    openAuthModalFor,
    deleteCustomerAccountPermanently,
  } = useApp();

  const customerOrders = orders.filter(
    (o) => o.customerId === currentCustomer.id || o.customerEmail === currentCustomer.email
  );

  return (
    <div className="p-3 space-y-4 text-xs pb-10">
      {/* Profile Header */}
      <div className="p-4 rounded-2xl bg-gradient-to-tr from-slate-900 to-slate-800 text-white flex items-center justify-between shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-amber-500 flex items-center justify-center text-slate-800 font-black text-lg shadow">
            {currentCustomer.name.charAt(0)}
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="font-extrabold text-sm">{currentCustomer.name}</h3>
              <span className="px-1.5 py-0.2 bg-amber-500/20 text-amber-300 text-[9px] font-bold rounded">
                Customer
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono">{currentCustomer.phone}</p>
          </div>
        </div>

        <button
          onClick={() => openAuthModalFor('customer')}
          className="p-2 rounded-xl bg-slate-700/80 hover:bg-slate-700 text-slate-200"
          title="Switch / Sign In with another number"
        >
          <LogIn className="w-4 h-4 text-indigo-400" />
        </button>
      </div>

      {/* Live Order Card if any order exists */}
      {customerOrders?.[0] && (
        <div className="p-3.5 bg-amber-50 dark:bg-amber-950/30 rounded-2xl border border-amber-300 dark:border-amber-900/60 space-y-2">
          <div className="flex items-center justify-between text-[11px] font-bold text-amber-900 dark:text-amber-300">
            <span className="flex items-center gap-1">
              <Truck className="w-3.5 h-3.5 text-amber-600" />
              <span>Latest Order #{customerOrders?.[0]?.orderNumber}</span>
            </span>
            <span className="text-[10px] uppercase font-mono">{customerOrders?.[0]?.status}</span>
          </div>

          <div className="flex items-center justify-between pt-1">
            <div className="text-[10px] text-slate-600 dark:text-slate-400">
              <span>{customerOrders?.[0]?.items?.length || 0} items &bull; ₹{customerOrders?.[0]?.totalAmount?.toLocaleString('en-IN')}</span>
            </div>
            <button
              onClick={() => {
                const firstOrder = customerOrders?.[0];
                if (firstOrder) setActiveTrackingOrder(firstOrder);
              }}
              className="bg-amber-500 text-slate-800 font-bold px-3 py-1 rounded-xl text-[10px] shadow"
            >
              Track Package
            </button>
          </div>
        </div>
      )}

      {/* Menu Options List */}
      <div className="space-y-1 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-2">
        <div
          onClick={() => {
            const firstOrder = customerOrders?.[0];
            if (firstOrder) setActiveTrackingOrder(firstOrder);
          }}
          className="p-2.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl cursor-pointer"
        >
          <div className="flex items-center gap-2.5 text-slate-800 dark:text-slate-200 font-semibold">
            <Package className="w-4 h-4 text-amber-500" />
            <span>Order History ({(customerOrders || []).length})</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </div>

        <div
          onClick={() => setIsWiseAIOpen(true)}
          className="p-2.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl cursor-pointer"
        >
          <div className="flex items-center gap-2.5 text-slate-800 dark:text-slate-200 font-semibold">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>WiseAI Concierge</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </div>

        <div
          onClick={() => setIsNotificationDrawerOpen(true)}
          className="p-2.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl cursor-pointer"
        >
          <div className="flex items-center gap-2.5 text-slate-800 dark:text-slate-200 font-semibold">
            <Bell className="w-4 h-4 text-amber-500" />
            <span>Notifications & Alerts</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </div>

        {/* Delete Customer Account to free mobile number */}
        <div
          onClick={async () => {
            if (
              window.confirm(
                `Delete customer account? This will permanently remove customer profile and free mobile number (${currentCustomer.phone}) to be used for Driver or Seller accounts.`
              )
            ) {
              await deleteCustomerAccountPermanently(currentCustomer.phone);
            }
          }}
          className="p-2.5 flex items-center justify-between hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-xl cursor-pointer text-rose-500"
        >
          <div className="flex items-center gap-2.5 font-semibold">
            <Trash2 className="w-4 h-4 text-rose-500" />
            <span>Delete Account & Free Mobile</span>
          </div>
          <ChevronRight className="w-4 h-4 text-rose-400" />
        </div>
      </div>
    </div>
  );
};
