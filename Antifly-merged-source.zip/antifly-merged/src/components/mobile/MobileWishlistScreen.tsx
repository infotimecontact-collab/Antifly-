import React from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../common/ProductCard';
import { Heart, ShoppingBag } from 'lucide-react';

export const MobileWishlistScreen: React.FC = () => {
  const { wishlist, products } = useApp();

  const savedProducts = products.filter((p) => wishlist.includes(p.id));

  return (
    <div className="p-3 space-y-3 text-xs pb-8">
      <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
        <h2 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
          <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
          <span>My Wishlist ({savedProducts.length})</span>
        </h2>
      </div>

      {savedProducts.length === 0 ? (
        <div className="py-16 text-center space-y-2 text-slate-400">
          <Heart className="w-12 h-12 mx-auto stroke-1 text-slate-300" />
          <p className="font-bold text-sm text-slate-700 dark:text-slate-300">Your wishlist is empty</p>
          <p className="text-[11px]">Save products to track price drops and special offers.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-2.5">
          {savedProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};
