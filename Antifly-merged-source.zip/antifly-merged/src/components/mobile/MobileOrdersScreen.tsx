import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Package,
  Truck,
  RotateCcw,
  CheckCircle2,
  Clock,
  ChevronRight,
  Download,
  AlertCircle,
  ShoppingBag,
  ExternalLink,
  MessageSquare,
} from 'lucide-react';

export const MobileOrdersScreen: React.FC = () => {
  const {
    currentCustomer,
    orders,
    setActiveTrackingOrder,
    setIsInvoiceModalOpen,
    setSelectedInvoiceOrder,
    openStoreChat,
    showToast,
    formatPrice,
  } = useApp();

  const [activeFilter, setActiveFilter] = useState<'all' | 'active' | 'delivered' | 'returned'>('all');

  const customerOrders = orders.filter(
    (o) => o.customerId === currentCustomer.id || o.customerEmail === currentCustomer.email
  );

  const filteredOrders = customerOrders.filter((order) => {
    if (activeFilter === 'active') {
      return ['Pending', 'Confirmed', 'Packed', 'Shipped', 'Out for delivery'].includes(order.status);
    }
    if (activeFilter === 'delivered') {
      return order.status === 'Delivered';
    }
    if (activeFilter === 'returned') {
      return ['Returned', 'Refunded', 'Cancelled'].includes(order.status);
    }
    return true;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Delivered':
        return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border-emerald-300';
      case 'Out for delivery':
      case 'Shipped':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300 border-blue-300 animate-pulse';
      case 'Processing':
      case 'Confirmed':
      case 'Pending':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border-amber-300';
      case 'Cancelled':
      case 'Returned':
        return 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300 border-rose-300';
      default:
        return 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300 border-slate-300';
    }
  };

  return (
    <div className="p-3 space-y-3.5 text-xs pb-10">
      {/* Orders Top Bar */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
            <Package className="w-4 h-4 text-amber-500" />
            <span>My Orders ({customerOrders.length})</span>
          </h2>
          <p className="text-[10px] text-slate-500 dark:text-slate-400">
            Track deliveries & manage returns in real-time
          </p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
        {[
          { id: 'all', label: 'All Orders' },
          { id: 'active', label: '🚚 In Transit' },
          { id: 'delivered', label: '✅ Delivered' },
          { id: 'returned', label: '🔄 Returns & Cancelled' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveFilter(tab.id as any)}
            className={`px-3 py-1.5 rounded-xl font-bold text-[11px] whitespace-nowrap transition-all ${
              activeFilter === tab.id
                ? 'bg-amber-500 text-slate-800 shadow-sm'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Orders List */}
      {filteredOrders.length === 0 ? (
        <div className="py-16 text-center space-y-2 text-slate-400">
          <ShoppingBag className="w-12 h-12 mx-auto stroke-1 text-slate-300 dark:text-slate-600" />
          <p className="font-bold text-sm text-slate-700 dark:text-slate-300">No orders found in this filter</p>
          <p className="text-[11px]">Explore trending collections and place your first order!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredOrders.map((order) => (
            <div
              key={order.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-3.5 shadow-xs space-y-3"
            >
              {/* Order Header */}
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-extrabold text-[11px] text-slate-900 dark:text-white">
                      #{order.orderNumber}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold border ${getStatusBadge(order.status)}`}>
                      {order.status}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    Placed on {new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </span>
                </div>

                <div className="text-right">
                  <span className="font-extrabold text-sm text-slate-900 dark:text-white block">
                    ₹{formatPrice(order.totalAmount)}
                  </span>
                  <span className="text-[9px] text-slate-400 font-medium">
                    {order.paymentMethod}
                  </span>
                </div>
              </div>

              {/* Order Items Snapshot */}
              <div className="space-y-2 pt-1 border-t border-slate-100 dark:border-slate-800/60">
                {order.items.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2.5">
                    <img
                      src={item.productImage}
                      alt={item.productName}
                      className="w-11 h-11 rounded-xl object-cover border border-slate-200 dark:border-slate-800 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-[11px] text-slate-900 dark:text-white truncate">
                        {item.productName}
                      </h4>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400">
                        Qty: {item.quantity} • ₹{formatPrice(item.price)} each
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Order Actions */}
              <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={() => setActiveTrackingOrder(order)}
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-slate-800 font-extrabold py-1.5 px-3 rounded-xl text-[11px] shadow-xs flex items-center justify-center gap-1.5 transition"
                >
                  <Truck className="w-3.5 h-3.5" />
                  <span>Live Tracking</span>
                </button>

                <button
                  onClick={() => {
                    setSelectedInvoiceOrder(order);
                    setIsInvoiceModalOpen(true);
                  }}
                  className="p-1.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:text-slate-800 rounded-xl transition"
                  title="Download GST Invoice"
                >
                  <Download className="w-4 h-4" />
                </button>

                {order.sellerId && (
                  <button
                    onClick={() => openStoreChat(order.sellerId!)}
                    className="p-1.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:text-indigo-500 rounded-xl transition"
                    title="Chat with Seller"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
