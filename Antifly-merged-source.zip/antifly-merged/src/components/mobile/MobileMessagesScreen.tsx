import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ChatInbox } from '../chat/ChatInbox';
import { ChatConversation } from '../chat/ChatConversation';
import { MessageSquare, Plus, Search, ShieldCheck } from 'lucide-react';
import { StoreChatSession } from '../../types';

export const MobileMessagesScreen: React.FC = () => {
  const { storeChatSessions, activeChatSessionId, setActiveChatSessionId } = useApp();
  const [inConversation, setInConversation] = useState(false);

  const activeSession = (storeChatSessions || []).find((s) => s.id === activeChatSessionId) || storeChatSessions?.[0] || null;

  const handleSelectChat = (session: StoreChatSession) => {
    setActiveChatSessionId(session.id);
    setInConversation(true);
  };

  const handleBackToInbox = () => {
    setInConversation(false);
  };

  return (
    <div className="h-full min-h-[580px] max-h-[700px] flex flex-col bg-white dark:bg-white text-slate-900 dark:text-white">
      {inConversation && activeSession ? (
        <div className="flex-1 flex flex-col h-full overflow-hidden">
          <ChatConversation session={activeSession} onBack={handleBackToInbox} />
        </div>
      ) : (
        <div className="flex-1 flex flex-col h-full overflow-hidden">
          <div className="p-3 bg-white dark:bg-white border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white font-black text-xs shadow-md">
                <MessageSquare className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-extrabold text-xs text-slate-900 dark:text-white">
                  Direct Messages
                </h3>
                <span className="text-[10px] text-slate-500 dark:text-slate-400">
                  Sellers, Creators & Group Chats
                </span>
              </div>
            </div>
            <span className="text-[9px] bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-300">
              End-to-End Encrypted
            </span>
          </div>

          <div className="flex-1 overflow-y-auto">
            <ChatInbox onSelectChat={handleSelectChat} selectedChatId={activeChatSessionId} />
          </div>
        </div>
      )}
    </div>
  );
};
