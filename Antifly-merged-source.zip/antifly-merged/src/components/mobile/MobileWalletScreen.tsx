import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Coins,
  Gem,
  Sparkles,
  Gift,
  ArrowRight,
  TrendingUp,
  Award,
  Zap,
  CheckCircle2,
  Calendar,
  Layers,
} from 'lucide-react';

export const MobileWalletScreen: React.FC = () => {
  const {
    superCoinsBalance,
    diamondsBalance,
    superCoinRewards,
    superCoinTransactions,
    diamondTransactions,
    redeemSuperCoinReward,
    convertDiamondsToCoins,
    addDiamonds,
    showToast,
    setIsSuperCoinsModalOpen,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'overview' | 'rewards' | 'history'>('overview');
  const [isSpinning, setIsSpinning] = useState(false);
  const [spinResult, setSpinResult] = useState<number | null>(null);

  const handleSpinWheel = () => {
    if (isSpinning) return;
    setIsSpinning(true);
    setSpinResult(null);

    setTimeout(() => {
      const wonDiamonds = Math.floor(Math.random() * 30) + 10;
      addDiamonds(wonDiamonds, `🎡 Daily Lucky Spin (+${wonDiamonds} 💎)`);
      setSpinResult(wonDiamonds);
      setIsSpinning(false);
      showToast(`🎉 You won ${wonDiamonds} Diamonds!`);
    }, 1200);
  };

  return (
    <div className="p-3 space-y-3.5 text-xs pb-10">
      {/* Wallet Top Balance Card */}
      <div className="p-4 rounded-3xl bg-gradient-to-tr from-amber-500 via-amber-600 to-yellow-500 text-slate-800 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-slate-200/10">
              <Coins className="w-6 h-6 text-slate-800 fill-amber-300" />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider bg-white text-amber-400 px-2 py-0.5 rounded-full">
                WiseRewards Economy
              </span>
              <h3 className="font-extrabold text-sm text-slate-800 mt-0.5">My SuperWallet</h3>
            </div>
          </div>

          <button
            onClick={() => setIsSuperCoinsModalOpen(true)}
            className="text-[10px] font-black bg-white text-white px-2.5 py-1 rounded-xl shadow-xs"
          >
            VIP Zone →
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2 pt-1">
          <div className="bg-white/30 backdrop-blur-sm p-2.5 rounded-2xl border border-white/40">
            <div className="flex items-center gap-1 text-[10px] font-extrabold text-slate-900">
              <Coins className="w-3.5 h-3.5 fill-current" />
              <span>SuperCoins</span>
            </div>
            <div className="text-xl font-black text-slate-800 mt-1">{superCoinsBalance}</div>
            <span className="text-[9px] font-semibold text-slate-800">₹{superCoinsBalance} Cash Value</span>
          </div>

          <div className="bg-white/20 backdrop-blur-sm p-2.5 rounded-2xl border border-white/20">
            <div className="flex items-center gap-1 text-[10px] font-extrabold text-slate-900">
              <Gem className="w-3.5 h-3.5 fill-current text-sky-700" />
              <span>Diamonds</span>
            </div>
            <div className="text-xl font-black text-slate-800 mt-1">{diamondsBalance}</div>
            <span className="text-[9px] font-semibold text-slate-800">Convertible to Coins</span>
          </div>
        </div>
      </div>

      {/* Daily Lucky Spin Streak */}
      <div className="bg-gradient-to-r from-purple-900 to-indigo-950 text-white rounded-3xl p-3.5 border border-purple-800/60 flex items-center justify-between shadow-md">
        <div className="space-y-0.5">
          <div className="flex items-center gap-1 text-[10px] font-black uppercase text-purple-300">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Daily Lucky Spin</span>
          </div>
          <p className="text-[11px] font-bold">Spin to win up to 50 💎 Diamonds daily</p>
          {spinResult !== null && (
            <span className="text-[10px] text-emerald-400 font-extrabold block">
              + {spinResult} 💎 Added to wallet!
            </span>
          )}
        </div>

        <button
          onClick={handleSpinWheel}
          disabled={isSpinning}
          className="bg-amber-400 hover:bg-amber-300 text-slate-800 font-black px-3 py-1.5 rounded-xl text-xs shadow-md transition active:scale-90"
        >
          {isSpinning ? 'Spinning...' : 'Spin 🎡'}
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-900 p-1 rounded-xl">
        {[
          { id: 'overview', label: 'Earning Ways' },
          { id: 'rewards', label: 'Redeem Vouchers' },
          { id: 'history', label: 'Passbook' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex-1 py-1 rounded-lg font-bold text-[10px] transition-all text-center ${
              activeTab === tab.id
                ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs'
                : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Earning Ways Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-2">
          {[
            {
              title: 'Buy & Earn 5% Cashback',
              desc: 'Earn 1 SuperCoin for every ₹20 spent on any product or live show.',
              reward: '+5% Coins',
              icon: '🛍️',
            },
            {
              title: 'Review Products with Photos',
              desc: 'Share genuine unboxing photos to earn 20 Diamonds.',
              reward: '+20 💎',
              icon: '⭐',
            },
            {
              title: 'Share & Resell WhatsApp Catalog',
              desc: 'Earn your customized margin + 50 bonus coins per successful customer order.',
              reward: '+₹500/order',
              icon: '💼',
            },
            {
              title: 'Refer Friends & Family',
              desc: 'Get 100 SuperCoins when your friend completes their first purchase.',
              reward: '+100 Coins',
              icon: '🎁',
            },
          ].map((item, idx) => (
            <div
              key={idx}
              className="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 shadow-2xs"
            >
              <div className="flex items-center gap-2.5">
                <span className="text-xl">{item.icon}</span>
                <div>
                  <h4 className="font-extrabold text-[11px] text-slate-900 dark:text-white">
                    {item.title}
                  </h4>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-snug">
                    {item.desc}
                  </p>
                </div>
              </div>
              <span className="bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 font-extrabold text-[10px] px-2 py-0.5 rounded-full shrink-0 border border-amber-300">
                {item.reward}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Rewards Catalog */}
      {activeTab === 'rewards' && (
        <div className="space-y-2">
          {superCoinRewards.map((reward) => (
            <div
              key={reward.id}
              className="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 shadow-2xs"
            >
              <div className="flex items-center gap-2.5">
                <img
                  src={reward.imageUrl}
                  alt={reward.title}
                  className="w-11 h-11 rounded-xl object-cover border border-slate-200 dark:border-slate-800 shrink-0"
                />
                <div>
                  <h4 className="font-extrabold text-[11px] text-slate-900 dark:text-white">
                    {reward.title}
                  </h4>
                  <span className="text-[10px] text-slate-400 block">{reward.category}</span>
                  <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400">
                    🪙 {reward.coinCost} SuperCoins
                  </span>
                </div>
              </div>

              <button
                onClick={() => redeemSuperCoinReward(reward.id)}
                disabled={superCoinsBalance < reward.coinCost}
                className={`px-3 py-1.5 rounded-xl font-bold text-[10px] shadow-xs transition ${
                  superCoinsBalance >= reward.coinCost
                    ? 'bg-amber-500 hover:bg-amber-400 text-slate-800'
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                }`}
              >
                Claim
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Passbook History */}
      {activeTab === 'history' && (
        <div className="space-y-2">
          {superCoinTransactions.map((tx) => (
            <div
              key={tx.id}
              className="bg-white dark:bg-slate-900 p-2.5 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between"
            >
              <div>
                <span className="font-bold text-[11px] text-slate-900 dark:text-white block">
                  {tx.description}
                </span>
                <span className="text-[9px] text-slate-400">
                  {new Date(tx.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                </span>
              </div>
              <span
                className={`font-black text-xs ${
                  tx.type === 'EARNED' ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                }`}
              >
                {tx.type === 'EARNED' ? `+${tx.amount}` : `-${tx.amount}`} 🪙
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
