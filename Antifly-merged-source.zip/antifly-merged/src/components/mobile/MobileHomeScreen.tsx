import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../common/ProductCard';
import { RealisticDynamicClock } from '../common/RealisticDynamicClock';
import {
  Sparkles,
  Zap,
  Tag,
  Clock,
  ArrowRight,
  TrendingUp,
  Percent,
  Gift,
  Coins,
  Store,
  Users,
  Timer,
  Gem,
  Radio,
  AudioLines,
  Glasses,
  ShoppingBag,
  Truck,
  Heart,
  Navigation,
  Crosshair,
  Sliders,
  CheckCircle2,
  ShieldCheck,
  Camera,
  Layers,
} from 'lucide-react';

interface MobileHomeScreenProps {
  onSelectCategory: () => void;
  onOpenWiseAI: () => void;
}

export const MobileHomeScreen: React.FC<MobileHomeScreenProps> = ({
  onSelectCategory,
  onOpenWiseAI,
}) => {
  const {
    products,
    categories,
    banners,
    setSelectedCategorySlug,
    applyCouponCode,
    showToast,
    superCoinsBalance,
    setIsSuperCoinsModalOpen,
    setIsResellerModalOpen,
    setIsStyleCastModalOpen,
    setIsGroupBuyModalOpen,
    setIsContentLifecycleModalOpen,
    setIsRewardsEconomyModalOpen,
    diamondWallet,
    setIsLiveShoppingOpen,
    setIsMultilingualStudioOpen,
    openVirtualTryOn,
    setIsOneTapSellOpen,
    setIsUniversalIdentityOpen,
    setIsAdminCommandCenterOpen,
    setIsDestinationDetourOpen,
    setIsCommunityNetworkOpen,
    setIsSmartDeliveryDecisionOpen,
    userUniversalCapabilities,
    toggleUserUniversalCapability,
  } = useApp();

  const [activeBannerIdx, setActiveBannerIdx] = useState(0);
  const [selectedMobileOpp, setSelectedMobileOpp] = useState<number>(0);

  const isDeliveryModeActive = !!userUniversalCapabilities.delivery;

  const handleToggleDelivery = () => {
    toggleUserUniversalCapability('delivery');
    if (!isDeliveryModeActive) {
      showToast('🚚 Mobile Delivery Mode ENABLED! Radar synced with Admin.');
    } else {
      showToast('⚪ Delivery Mode paused.');
    }
  };

  const mobileDeliveryOpps = [
    {
      store: 'Agarwal General Store',
      location: 'Rajwada ➔ Vijaynagar',
      distance: '3.8 km',
      time: '18 min',
      payout: 85,
      routeMatch: '96% on route',
    },
    {
      store: 'Apna Sweets & Namkeen',
      location: 'AB Road ➔ Scheme 54',
      distance: '1.2 km',
      time: '11 min',
      payout: 60,
      routeMatch: '99% on route',
    },
    {
      store: 'Sarafa Artisan Gifts',
      location: 'Sarafa ➔ Palasia',
      distance: '4.5 km',
      time: '24 min',
      payout: 130,
      routeMatch: '88% on route',
    },
  ];

  // App-exclusive banners
  const mobileBanners = banners.filter((b) => b.isActive);
  const flashSaleProducts = products.filter((p) => p.discountPercentage >= 30);
  const trendingProducts = products.filter((p) => p.isTrending || p.isFeatured);

  const handleApplyAppCoupon = async (code: string) => {
    const res = await applyCouponCode(code);
    showToast(res.message);
  };

  return (
    <div className="p-3 space-y-3.5 text-xs pb-6">
      {/* 0. Live Dynamic Real-Time Clock & Deal Sync Bar */}
      <div className="p-2.5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white border border-slate-700/80 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-2">
          <RealisticDynamicClock
            size="sm"
            variant="luxury"
            showDigitalTime={true}
            showSeconds={true}
            badgeLabel="LIVE SYNC"
          />
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsAdminCommandCenterOpen(true)}
            className="px-2 py-1 bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-extrabold text-[9px] rounded-lg hover:bg-emerald-900/60 transition cursor-pointer flex items-center gap-1"
          >
            <Sliders className="w-2.5 h-2.5" />
            <span>Admin Sync</span>
          </button>
          <button
            onClick={() => setIsUniversalIdentityOpen(true)}
            className="px-2 py-1 bg-purple-950/80 border border-purple-500/40 text-purple-300 font-extrabold text-[9px] rounded-lg hover:bg-purple-900/60 transition cursor-pointer flex items-center gap-1"
          >
            <span>Universal ID</span>
          </button>
        </div>
      </div>

      {/* 0.5 FIVE UNIVERSAL HUMAN ACTIONS BAR (BUY, SELL, HELP, EARN, CONNECT) */}
      <div className="bg-white p-2.5 rounded-2xl border border-slate-800 space-y-2">
        <div className="flex items-center justify-between px-1">
          <span className="text-[9px] font-black uppercase tracking-wider text-slate-400">
            5 Core Ecosystem Actions
          </span>
          <span className="text-[9px] font-bold text-cyan-400">
            {isDeliveryModeActive ? '🟢 Delivery ON' : '⚪ Shopper Mode'}
          </span>
        </div>
        <div className="grid grid-cols-5 gap-1.5 text-center">
          <button
            onClick={onSelectCategory}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/50 flex flex-col items-center gap-1 text-slate-300 hover:text-white transition cursor-pointer"
          >
            <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-black text-xs">
              🛍
            </div>
            <span className="text-[9px] font-black leading-tight">BUY</span>
          </button>

          <button
            onClick={() => setIsOneTapSellOpen(true)}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-emerald-500/50 flex flex-col items-center gap-1 text-slate-300 hover:text-white transition cursor-pointer"
          >
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black text-xs">
              🏪
            </div>
            <span className="text-[9px] font-black leading-tight">SELL</span>
          </button>

          <button
            onClick={handleToggleDelivery}
            className={`p-2 rounded-xl border flex flex-col items-center gap-1 transition cursor-pointer ${
              isDeliveryModeActive
                ? 'bg-cyan-500 text-slate-800 font-black border-white shadow-md shadow-cyan-500/30'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-cyan-500/50 hover:text-white'
            }`}
          >
            <div
              className={`w-7 h-7 rounded-lg flex items-center justify-center font-black text-xs ${
                isDeliveryModeActive ? 'bg-white text-cyan-400' : 'bg-cyan-500/20 text-cyan-400'
              }`}
            >
              🚚
            </div>
            <span className="text-[9px] font-black leading-tight">HELP</span>
          </button>

          <button
            onClick={() => setIsDestinationDetourOpen(true)}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-teal-500/50 flex flex-col items-center gap-1 text-slate-300 hover:text-white transition cursor-pointer"
          >
            <div className="w-7 h-7 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center font-black text-xs">
              💰
            </div>
            <span className="text-[9px] font-black leading-tight">EARN</span>
          </button>

          <button
            onClick={() => setIsCommunityNetworkOpen(true)}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-purple-500/50 flex flex-col items-center gap-1 text-slate-300 hover:text-white transition cursor-pointer"
          >
            <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center font-black text-xs">
              ❤️
            </div>
            <span className="text-[9px] font-black leading-tight">CONNECT</span>
          </button>
        </div>
      </div>

      {/* 0.8 MOBILE DELIVERY OPPORTUNITY RADAR (ACTIVE WHEN DELIVERY MODE IS ON) */}
      {isDeliveryModeActive && (
        <div className="p-3 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 rounded-2xl border border-cyan-400/50 space-y-2.5 shadow-xl shadow-cyan-500/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span className="text-[10px] font-black text-cyan-400 uppercase tracking-wide">
                Delivery Radar: 3 Matches Found
              </span>
            </div>
            <span className="text-[9px] bg-cyan-950 text-cyan-300 border border-cyan-700 px-2 py-0.5 rounded-full font-bold">
              Up to ₹130
            </span>
          </div>

          <div className="space-y-1.5">
            {mobileDeliveryOpps.map((opp, idx) => (
              <div
                key={opp.store}
                onClick={() => setSelectedMobileOpp(idx)}
                className={`p-2.5 rounded-xl border transition cursor-pointer flex items-center justify-between ${
                  selectedMobileOpp === idx
                    ? 'bg-slate-900 border-cyan-400 text-white'
                    : 'bg-white/80 border-slate-800/80 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="space-y-0.5 min-w-0 pr-2">
                  <div className="flex items-center gap-1.5">
                    <span className="font-black text-[11px] truncate text-white">{opp.store}</span>
                    <span className="text-[8px] bg-emerald-950 text-emerald-300 px-1.5 py-0.2 rounded font-bold">
                      {opp.routeMatch}
                    </span>
                  </div>
                  <p className="text-[9px] text-slate-400">
                    {opp.location} • {opp.distance} ({opp.time})
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-xs font-black text-emerald-400 block">₹{opp.payout}</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsSmartDeliveryDecisionOpen(true);
                    }}
                    className="mt-1 px-2 py-0.5 bg-cyan-500 hover:bg-cyan-400 text-slate-800 text-[9px] font-black rounded-md"
                  >
                    Accept
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 1. App-Only Special Voucher Banner */}
      <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-800 flex items-center justify-between shadow-md">
        <div className="space-y-0.5">
          <div className="flex items-center gap-1 font-extrabold text-[11px] uppercase tracking-wider">
            <Gift className="w-3.5 h-3.5" />
            <span>App-Only Perk: 15% OFF</span>
          </div>
          <p className="text-[10px] font-medium opacity-90">
            Use code <strong className="font-mono bg-white/30 px-1 py-0.5 rounded">APPEXCLUSIVE15</strong>
          </p>
        </div>
        <button
          onClick={() => handleApplyAppCoupon('APPEXCLUSIVE15')}
          className="bg-white text-white font-bold px-3 py-1.5 rounded-xl text-[10px] shadow"
        >
          Claim Now
        </button>
      </div>

      {/* 1.5 Quick E-Commerce Pillars (WiseCoins, WiseReseller, WiseStyle, Squad Buy, Auto-Delete) */}
      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => setIsRewardsEconomyModalOpen(true)}
          className="p-2.5 bg-gradient-to-r from-amber-500/20 to-amber-500/10 border border-amber-500/40 rounded-2xl flex items-center gap-2 text-left hover:bg-amber-500/25 transition shadow-2xs"
        >
          <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-800 flex items-center justify-center font-bold shadow-2xs">
            <Coins className="w-4 h-4 fill-slate-950" />
          </div>
          <div>
            <span className="text-[9px] font-bold text-amber-900 dark:text-amber-300 block">Rewards Hub</span>
            <span className="text-[11px] font-black text-slate-900 dark:text-white flex items-center gap-1">
              <span>{superCoinsBalance}</span>
              <span className="text-[9px] text-amber-600 font-bold">🪙</span>
              <span className="text-slate-300">|</span>
              <span className="text-cyan-700 dark:text-cyan-400">{diamondWallet.availableDiamonds} 💎</span>
            </span>
          </div>
        </button>

        <button
          onClick={() => setIsContentLifecycleModalOpen(true)}
          className="p-2.5 bg-emerald-500/15 border border-emerald-500/30 rounded-2xl flex items-center gap-2 text-left hover:bg-emerald-500/25 transition shadow-2xs"
        >
          <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold shadow-2xs">
            <Timer className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[9px] font-bold text-emerald-800 dark:text-emerald-300 block">Auto-Delete Hub</span>
            <span className="text-[11px] font-black text-slate-900 dark:text-white">Content Lifecycle</span>
          </div>
        </button>

        <button
          onClick={() => setIsResellerModalOpen(true)}
          className="p-2.5 bg-pink-500/15 border border-pink-500/30 rounded-2xl flex items-center gap-2 text-left hover:bg-pink-500/25 transition"
        >
          <div className="w-8 h-8 rounded-xl bg-pink-600 text-white flex items-center justify-center font-bold">
            <Store className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[9px] font-bold text-pink-700 dark:text-pink-300 block">WiseReseller</span>
            <span className="text-[11px] font-black text-slate-900 dark:text-white">Earn ₹0 Inv</span>
          </div>
        </button>

        <button
          onClick={() => setIsGroupBuyModalOpen(true)}
          className="p-2.5 bg-indigo-500/15 border border-indigo-500/30 rounded-2xl flex items-center gap-2 text-left hover:bg-indigo-500/25 transition"
        >
          <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold">
            <Users className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[9px] font-bold text-indigo-700 dark:text-indigo-300 block">Squad Group Buy</span>
            <span className="text-[11px] font-black text-slate-900 dark:text-white">Save Up to 40%</span>
          </div>
        </button>
      </div>

      {/* 1.8 Next-Gen Innovation Suite: Live Stream Commerce, 12-Lang Voice & 3D AR Studio */}
      <div className="p-3 rounded-2xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30 text-white space-y-2.5 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" />
            <span className="text-[10px] font-black tracking-wider uppercase text-amber-300">
              Next-Gen Shopping Suite
            </span>
          </div>
          <span className="bg-red-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded-full animate-pulse">
            LIVE NOW
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {/* Live Shows Button */}
          <button
            onClick={() => setIsLiveShoppingOpen(true)}
            className="p-2 rounded-xl bg-red-600/30 hover:bg-red-600/50 border border-red-500/50 flex flex-col items-center justify-center text-center gap-1 transition active:scale-95"
          >
            <Radio className="w-5 h-5 text-rose-400 animate-pulse" />
            <span className="text-[10px] font-black text-white leading-tight">Live Shows</span>
            <span className="text-[8px] text-rose-200">Watch & Buy</span>
          </button>

          {/* Multilingual Voice Studio Button */}
          <button
            onClick={() => setIsMultilingualStudioOpen(true)}
            className="p-2 rounded-xl bg-violet-600/30 hover:bg-violet-600/50 border border-violet-500/50 flex flex-col items-center justify-center text-center gap-1 transition active:scale-95"
          >
            <AudioLines className="w-5 h-5 text-violet-400" />
            <span className="text-[10px] font-black text-white leading-tight">Voice Studio</span>
            <span className="text-[8px] text-violet-200">12 Languages</span>
          </button>

          {/* 3D AR Try-On Button */}
          <button
            onClick={() => openVirtualTryOn()}
            className="p-2 rounded-xl bg-emerald-600/30 hover:bg-emerald-600/50 border border-emerald-500/50 flex flex-col items-center justify-center text-center gap-1 transition active:scale-95"
          >
            <Glasses className="w-5 h-5 text-emerald-400" />
            <span className="text-[10px] font-black text-white leading-tight">3D Try-On</span>
            <span className="text-[8px] text-emerald-200">Virtual Fit</span>
          </button>
        </div>
      </div>

      {/* 2. Circular Story-Style Category Pills */}
      <div className="flex items-center gap-3 overflow-x-auto pb-1 no-scrollbar">
        {categories.map((cat) => (
          <div
            key={cat.id}
            onClick={() => {
              setSelectedCategorySlug(cat.slug);
              onSelectCategory();
            }}
            className="flex flex-col items-center gap-1 cursor-pointer flex-shrink-0"
          >
            <div className="w-14 h-14 rounded-full p-0.5 bg-gradient-to-tr from-amber-500 to-orange-500 shadow-sm">
              <img
                src={cat.image}
                alt={cat.name}
                className="w-full h-full rounded-full object-cover border-2 border-white dark:border-slate-200"
              />
            </div>
            <span className="text-[10px] font-semibold text-slate-800 dark:text-slate-200 truncate w-14 text-center">
              {cat?.name ? cat.name.split(' ')?.[0] || cat.name : 'Item'}
            </span>
          </div>
        ))}
      </div>

      {/* 3. Hero Carousel Banner */}
      {mobileBanners && mobileBanners.length > 0 && (
        <div className="relative rounded-2xl overflow-hidden shadow-lg border border-slate-200 dark:border-slate-800">
          <img
            src={
              mobileBanners?.[activeBannerIdx]?.mobileImage ||
              mobileBanners?.[activeBannerIdx]?.desktopImage ||
              mobileBanners?.[0]?.mobileImage ||
              mobileBanners?.[0]?.desktopImage ||
              'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=800'
            }
            alt="Promotion"
            className="w-full h-44 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent flex flex-col justify-end p-3.5 text-white">
            {mobileBanners?.[activeBannerIdx]?.discountBadge && (
              <span className="bg-amber-500 text-slate-800 px-2 py-0.5 rounded-md font-extrabold text-[9px] w-fit mb-1">
                {mobileBanners?.[activeBannerIdx]?.discountBadge}
              </span>
            )}
            <h3 className="font-extrabold text-sm leading-snug">
              {mobileBanners?.[activeBannerIdx]?.title}
            </h3>
            <p className="text-[10px] text-slate-300 line-clamp-1">
              {mobileBanners?.[activeBannerIdx]?.subtitle}
            </p>
          </div>
        </div>
      )}

      {/* 4. WiseAI Stylist Prompt Card */}
      <div
        onClick={onOpenWiseAI}
        className="p-3 bg-slate-900 text-white rounded-2xl border border-slate-800 flex items-center justify-between cursor-pointer shadow-md hover:border-amber-500 transition-all"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h4 className="font-bold text-xs">Need fashion advice?</h4>
            <p className="text-[10px] text-slate-400">Ask WiseAI: "Wedding kurta under ₹3000"</p>
          </div>
        </div>
        <ArrowRight className="w-4 h-4 text-amber-400" />
      </div>

      {/* 5. Flash Deals Section */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-amber-500" />
            <h3 className="font-extrabold text-xs text-slate-900 dark:text-white uppercase tracking-wider">
              Flash Deals of the Day
            </h3>
          </div>
          <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400">
            Ends Soon
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {flashSaleProducts.slice(0, 4).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>

      {/* 6. Trending Catalog */}
      <div className="space-y-2 pt-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <TrendingUp className="w-4 h-4 text-amber-500" />
            <h3 className="font-extrabold text-xs text-slate-900 dark:text-white uppercase tracking-wider">
              Trending Modern Indian Wear
            </h3>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {trendingProducts.slice(0, 4).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
};
