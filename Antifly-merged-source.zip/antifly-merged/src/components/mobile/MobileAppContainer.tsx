import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { MobileHomeScreen } from './MobileHomeScreen';
import { MobileCategoriesScreen } from './MobileCategoriesScreen';
import { MobileWishlistScreen } from './MobileWishlistScreen';
import { MobileAccountScreen } from './MobileAccountScreen';
import { MobileSearchScreen } from './MobileSearchScreen';
import { MobileReelsScreen } from './MobileReelsScreen';
import { MobileOrdersScreen } from './MobileOrdersScreen';
import { MobileMessagesScreen } from './MobileMessagesScreen';
import { MobileNotificationsScreen } from './MobileNotificationsScreen';
import { MobileFavoritesScreen } from './MobileFavoritesScreen';
import { MobileWalletScreen } from './MobileWalletScreen';
import { SellerCentralPortal } from '../seller/SellerCentralPortal';
import { DriverPartnerPortal } from '../driver/DriverPartnerPortal';
import { WhatsAppStatusHub } from '../social/WhatsAppStatusHub';
import { RealisticDynamicClock } from '../common/RealisticDynamicClock';
import {
  Wifi,
  Battery,
  Signal,
  Search,
  Mic,
  Store,
  Truck,
  ShoppingBag,
  Home,
  Compass,
  Film,
  Grid,
  Package,
  MessageSquare,
  Bell,
  Bookmark,
  User,
  Coins,
  Glasses,
  Zap,
  Camera,
  Sparkles,
} from 'lucide-react';

export type MobileTab =
  | 'home'
  | 'discover'
  | 'reels'
  | 'shop'
  | 'orders'
  | 'messages'
  | 'notifications'
  | 'favorites'
  | 'profile'
  | 'wallet'
  | 'status';

export const MobileAppContainer: React.FC = () => {
  const {
    deviceMode,
    cart,
    wishlist,
    notifications,
    setIsCartOpen,
    setIsWiseAIOpen,
    setIsVoiceSearchOpen,
    setIsImageSearchOpen,
    searchQuery,
    setSearchQuery,
    stories,
    setIsAddStoryModalOpen,
    storeChatSessions,
    setIsStoreChatOpen,
    setIsFavoritesHubOpen,
    savedItems,
    openVirtualTryOn,
    openFreeTrialUpload,
    setIsAutonomousZeroAdminOpen,
    setIsJustAwayHubOpen,
    awayModeActive,
  } = useApp();

  const totalChatUnread = storeChatSessions.reduce((acc, s) => acc + (s.unreadCount || 0), 0);
  const unreadNotifications = notifications.filter((n) => !n.isRead).length;

  const [mobileAppRole, setMobileAppRole] = useState<'customer' | 'seller' | 'driver'>('customer');
  const [activeTab, setActiveTab] = useState<MobileTab>('home');
  const [currentTime, setCurrentTime] = useState('9:41');

  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      const hours = d.getHours() % 12 || 12;
      const mins = String(d.getMinutes()).padStart(2, '0');
      setCurrentTime(`${hours}:${mins}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  const isIOS = deviceMode === 'mobile-ios';
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const mainTenTabs = [
    { id: 'home', label: 'Home', Icon: Home, badge: undefined },
    { id: 'discover', label: 'Discover', Icon: Compass, badge: undefined },
    { id: 'reels', label: 'Reels', Icon: Film, badge: 'LIVE' },
    { id: 'shop', label: 'Shop', Icon: Grid, badge: undefined },
    { id: 'orders', label: 'Orders', Icon: Package, badge: undefined },
    { id: 'messages', label: 'Messages', Icon: MessageSquare, badge: totalChatUnread > 0 ? totalChatUnread : undefined },
    { id: 'notifications', label: 'Alerts', Icon: Bell, badge: unreadNotifications > 0 ? unreadNotifications : undefined },
    { id: 'favorites', label: 'Vault', Icon: Bookmark, badge: savedItems.length > 0 ? savedItems.length : undefined },
    { id: 'profile', label: 'Profile', Icon: User, badge: undefined },
    { id: 'wallet', label: 'Wallet', Icon: Coins, badge: 'Rewards' },
  ];

  return (
    <div className="min-h-screen bg-white/90 py-4 sm:py-8 pb-28 flex items-center justify-center p-2">
      {/* Smartphone Device Frame */}
      <div
        id="mobile-phone-hardware-frame"
        className={`w-full max-w-[420px] h-[860px] bg-white rounded-[50px] p-3 shadow-2xl border-4 ${
          isIOS ? 'border-slate-700 ring-4 ring-slate-800' : 'border-slate-800 ring-2 ring-slate-700'
        } flex flex-col relative overflow-hidden transition-all duration-300`}
      >
        {/* Device Inner Screen */}
        <div className="w-full h-full bg-slate-50 dark:bg-white rounded-[40px] overflow-hidden flex flex-col relative border border-slate-800 text-slate-900 dark:text-white">
          {/* Native Mobile Status Bar */}
          <div className="px-7 pt-3 pb-1 flex items-center justify-between text-xs font-semibold select-none bg-white/90 dark:bg-white/90 backdrop-blur-sm z-30">
            <span className="font-bold tracking-tight text-xs">{currentTime}</span>

            {/* Dynamic Island for iOS / Punch-hole for Android */}
            {isIOS ? (
              <div className="w-28 h-5 bg-slate-900 rounded-full flex items-center justify-center gap-2 px-2 shadow-inner border border-slate-800">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-800 border border-slate-700" />
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500/80 animate-pulse" />
              </div>
            ) : (
              <div className="w-3.5 h-3.5 rounded-full bg-slate-900 border border-slate-800 shadow-inner" />
            )}

            {/* System Icons */}
            <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
              <Signal className="w-3.5 h-3.5" />
              <Wifi className="w-3.5 h-3.5" />
              <Battery className="w-4 h-4" />
            </div>
          </div>

          {/* In-Phone 3-App Switcher Bar */}
          <div className="px-2 py-1 bg-slate-900 border-b border-slate-800 flex items-center justify-center gap-1.5 z-20">
            <button
              onClick={() => setMobileAppRole('customer')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold transition-all cursor-pointer ${
                mobileAppRole === 'customer'
                  ? 'bg-amber-500 text-slate-800 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Customer</span>
            </button>
            <button
              onClick={() => setMobileAppRole('seller')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold transition-all cursor-pointer ${
                mobileAppRole === 'seller'
                  ? 'bg-orange-500 text-slate-800 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Store className="w-3.5 h-3.5" />
              <span>Venture</span>
            </button>
            <button
              onClick={() => setMobileAppRole('driver')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold transition-all cursor-pointer ${
                mobileAppRole === 'driver'
                  ? 'bg-emerald-500 text-slate-800 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Truck className="w-3.5 h-3.5" />
              <span>Buddy</span>
            </button>
          </div>

          {/* Active Screen Body (Scrollable) */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden">
            {mobileAppRole === 'customer' && (
              <>
                {/* App Top Bar for Customer Store */}
                <div className="px-3 py-2 bg-white/90 dark:bg-white/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800/80 flex items-center justify-between gap-1.5 z-20">
                  <div
                    onClick={() => setActiveTab('home')}
                    className="flex items-center gap-1.5 cursor-pointer flex-shrink-0"
                  >
                    <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-600 flex items-center justify-center text-white font-black text-xs shadow-xs">
                      W
                    </div>
                  </div>

                  {/* Dynamic Realistic Clock in Customer Header */}
                  <RealisticDynamicClock
                    size="xs"
                    variant="customer"
                    showDigitalTime={true}
                    showSeconds={true}
                  />

                  {/* Top Search Input */}
                  <div className="flex-1 max-w-[130px] relative">
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search..."
                      className="w-full pl-6 pr-6 py-1 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-full text-[10px] text-slate-900 dark:text-white focus:outline-none"
                    />
                    <Search className="w-2.5 h-2.5 text-slate-400 absolute left-2 top-2" />
                    <div className="absolute right-1 top-0.5 flex items-center">
                      <button
                        type="button"
                        onClick={() => setIsVoiceSearchOpen(true)}
                        className="p-0.5 text-slate-400 hover:text-amber-500 cursor-pointer"
                      >
                        <Mic className="w-2.5 h-2.5" />
                      </button>
                    </div>
                  </div>

                  {/* 1-to-1 Direct Messages */}
                  <div
                    id="mobile-header-messages-btn"
                    onClick={() => setIsStoreChatOpen(true)}
                    title="Direct 1-to-1 Chat"
                    className="relative p-1 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer flex-shrink-0"
                  >
                    <MessageSquare className="w-4 h-4" />
                    {totalChatUnread > 0 && (
                      <span className="absolute -top-1 -right-1 bg-indigo-600 text-white text-[7px] font-black px-1 rounded-full">
                        {totalChatUnread}
                      </span>
                    )}
                  </div>

                  {/* Saved Vault & Collections */}
                  <div
                    id="mobile-header-saved-vault-btn"
                    onClick={() => setIsFavoritesHubOpen(true)}
                    title="Saved Vault & Collections"
                    className="relative p-1 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer flex-shrink-0"
                  >
                    <Bookmark className="w-4 h-4" />
                    {savedItems.length > 0 && (
                      <span className="absolute -top-1 -right-1 bg-amber-400 text-slate-800 text-[7px] font-black px-1 rounded-full">
                        {savedItems.length}
                      </span>
                    )}
                  </div>

                  {/* JustAway Spontaneous Escapes */}
                  <div
                    id="mobile-header-justaway-btn"
                    onClick={() => setIsJustAwayHubOpen(true)}
                    title="JustAway: 'Just go. Just away.' Spontaneous Escapes"
                    className="relative p-1 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer flex-shrink-0"
                  >
                    <Compass className="w-4 h-4" />
                    <span className="absolute -top-1 -right-1 bg-amber-400 text-slate-800 text-[7px] font-black px-0.5 rounded-full">
                      {awayModeActive ? 'AWAY' : 'GO'}
                    </span>
                  </div>

                  {/* Zero-Admin */}
                  <div
                    id="mobile-header-zero-admin-btn"
                    onClick={() => setIsAutonomousZeroAdminOpen(true)}
                    title="Zero-Admin Autonomous Operations"
                    className="relative p-1 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer flex-shrink-0"
                  >
                    <Zap className="w-4 h-4 text-emerald-500" />
                  </div>

                  {/* Free Trial & Virtual Try-On */}
                  <div
                    id="mobile-header-tryon-btn"
                    onClick={() => openVirtualTryOn()}
                    title="Free Product Trial & Try-On"
                    className="relative p-1 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer flex-shrink-0"
                  >
                    <Glasses className="w-4 h-4 text-teal-500" />
                  </div>

                  {/* Bag */}
                  <div
                    onClick={() => setIsCartOpen(true)}
                    className="relative p-1 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer flex-shrink-0"
                    title="Shopping Bag"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    {cartCount > 0 && (
                      <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[7px] font-black px-1 rounded-full">
                        {cartCount}
                      </span>
                    )}
                  </div>
                </div>

                {/* Top 10-Tab Quick Switcher Carousel */}
                <div className="bg-white/95 dark:bg-slate-900/95 px-2 py-1.5 border-b border-slate-200/80 dark:border-slate-800 flex items-center gap-1.5 overflow-x-auto no-scrollbar shadow-2xs z-10">
                  {mainTenTabs.map((tab) => {
                    const isActive = activeTab === tab.id;
                    const TabIcon = tab.Icon;
                    return (
                      <button
                        key={tab.id}
                        id={`mobile-tab-pill-${tab.id}`}
                        onClick={() => setActiveTab(tab.id as MobileTab)}
                        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-extrabold whitespace-nowrap transition-all flex-shrink-0 cursor-pointer ${
                          isActive
                            ? 'bg-amber-500 text-slate-800 shadow-xs font-black'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                        }`}
                      >
                        <TabIcon className="w-3 h-3" />
                        <span>{tab.label}</span>
                        {tab.badge !== undefined && (
                          <span className={`text-[8px] font-black px-1.5 py-0.2 rounded-full ${
                            isActive ? 'bg-white text-amber-300' : 'bg-rose-500 text-white'
                          }`}>
                            {tab.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Content according to Nav (All 10 Core Modes) */}
                {activeTab === 'home' && (
                  <MobileHomeScreen
                    onSelectCategory={() => setActiveTab('shop')}
                    onOpenWiseAI={() => setIsWiseAIOpen(true)}
                  />
                )}
                {activeTab === 'discover' && <MobileSearchScreen />}
                {activeTab === 'reels' && <MobileReelsScreen />}
                {activeTab === 'shop' && <MobileCategoriesScreen />}
                {activeTab === 'orders' && <MobileOrdersScreen />}
                {activeTab === 'messages' && <MobileMessagesScreen />}
                {activeTab === 'notifications' && <MobileNotificationsScreen />}
                {activeTab === 'favorites' && <MobileFavoritesScreen />}
                {activeTab === 'profile' && <MobileAccountScreen />}
                {activeTab === 'wallet' && <MobileWalletScreen />}
                {activeTab === 'status' && <WhatsAppStatusHub />}
              </>
            )}

            {mobileAppRole === 'seller' && (
              <div>
                {/* Header for Seller in Mobile App */}
                <div className="px-3 py-2 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-2 text-white">
                  <div className="flex items-center gap-1.5">
                    <div className="w-6 h-6 rounded-md bg-orange-500 flex items-center justify-center text-slate-800 font-black text-xs">
                      <Store className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <div className="text-[11px] font-extrabold leading-tight">Venture Seller</div>
                      <div className="flex items-center gap-1 text-[9px] text-emerald-400 font-bold">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        <span>STORE LIVE</span>
                      </div>
                    </div>
                  </div>

                  {/* Dynamic Realistic Clock for Seller */}
                  <RealisticDynamicClock
                    size="xs"
                    variant="seller"
                    badgeLabel="SELLER"
                    showDigitalTime={true}
                    showSeconds={true}
                  />
                </div>

                <div className="p-2">
                  {activeTab === 'status' ? <WhatsAppStatusHub /> : <SellerCentralPortal />}
                </div>
              </div>
            )}

            {mobileAppRole === 'driver' && (
              <div>
                {/* Header for Driver in Mobile App */}
                <div className="px-3 py-2 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-2 text-white">
                  <div className="flex items-center gap-1.5">
                    <div className="w-6 h-6 rounded-md bg-emerald-500 flex items-center justify-center text-slate-800 font-black text-xs">
                      <Truck className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <div className="text-[11px] font-extrabold leading-tight">Buddy Driver</div>
                      <div className="flex items-center gap-1 text-[9px] text-emerald-400 font-bold">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        <span>ON DUTY (GPS ON)</span>
                      </div>
                    </div>
                  </div>

                  {/* Dynamic Realistic Clock for Driver */}
                  <RealisticDynamicClock
                    size="xs"
                    variant="driver"
                    badgeLabel="SHIFT"
                    showDigitalTime={true}
                    showSeconds={true}
                  />
                </div>

                <div className="p-2">
                  {activeTab === 'status' ? <WhatsAppStatusHub /> : <DriverPartnerPortal />}
                </div>
              </div>
            )}
          </div>

          {/* Native Bottom App Navigation Bar */}
          <div className="px-2 py-1.5 bg-white/95 dark:bg-white/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 flex items-center justify-around z-30 select-none">
            <button
              onClick={() => setActiveTab('home')}
              className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer ${
                activeTab === 'home'
                  ? 'text-amber-600 dark:text-amber-400 font-bold'
                  : 'text-slate-500 dark:text-slate-400 opacity-80'
              }`}
            >
              <Home className="w-5 h-5" />
              <span className="text-[10px] font-bold">
                {mobileAppRole === 'seller' ? 'Store' : mobileAppRole === 'driver' ? 'Shift' : 'Home'}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('discover')}
              className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer ${
                activeTab === 'discover'
                  ? 'text-cyan-600 dark:text-cyan-400 font-bold'
                  : 'text-slate-500 dark:text-slate-400 opacity-80'
              }`}
            >
              <Compass className="w-5 h-5" />
              <span className="text-[10px] font-bold">Discover</span>
            </button>

            {/* WhatsApp-Style 24H STATUS / STORY FLOATING CENTER MENU */}
            <button
              id="mobile-center-status-menu-btn"
              onClick={() => setActiveTab('status')}
              className="flex flex-col items-center gap-0.5 -mt-4 py-0.5 px-2 group relative cursor-pointer"
              title="24h Status & Stories (Contacts & Followers)"
            >
              <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-500 flex items-center justify-center text-white shadow-md relative">
                <Camera className="w-5 h-5" />
                {stories.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[7px] font-black px-1 rounded-full">
                    LIVE
                  </span>
                )}
              </div>
              <span
                className={`text-[10px] font-black tracking-tight mt-0.5 ${
                  activeTab === 'status'
                    ? 'text-emerald-500 font-extrabold'
                    : 'text-slate-600 dark:text-slate-300 font-semibold'
                }`}
              >
                Status
              </span>
            </button>

            <button
              onClick={() => setActiveTab('shop')}
              className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer ${
                activeTab === 'shop'
                  ? 'text-orange-600 dark:text-orange-400 font-bold'
                  : 'text-slate-500 dark:text-slate-400 opacity-80'
              }`}
            >
              <Grid className="w-5 h-5" />
              <span className="text-[10px] font-bold">Shop</span>
            </button>

            <button
              onClick={() => setActiveTab('profile')}
              className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer ${
                activeTab === 'profile'
                  ? 'text-purple-600 dark:text-purple-400 font-bold'
                  : 'text-slate-500 dark:text-slate-400 opacity-80'
              }`}
            >
              <User className="w-5 h-5" />
              <span className="text-[10px] font-bold">Profile</span>
            </button>
          </div>

          {/* iOS Bottom Home Bar */}
          {isIOS && (
            <div className="w-32 h-1 bg-slate-400 dark:bg-slate-600 rounded-full mx-auto my-1.5 select-none" />
          )}
        </div>
      </div>
    </div>
  );
};
