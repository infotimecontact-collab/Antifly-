import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../common/ProductCard';
import {
  Search,
  Mic,
  Camera,
  Store,
  Sparkles,
  ShoppingBag,
  Tv,
  UtensilsCrossed,
  Film,
  CheckCircle2,
  QrCode,
  MessageCircle,
  TrendingUp,
} from 'lucide-react';
import { DirectSellerPaymentModal } from '../common/DirectSellerPaymentModal';
import { SellerProfile } from '../../types';

export const MobileSearchScreen: React.FC = () => {
  const {
    products,
    sellers,
    shortVideoReels,
    openReelPlayer,
    openStoreChat,
    setIsVoiceSearchOpen,
    setIsImageSearchOpen,
    setIsOTTModalOpen,
    setIsFoodDeliveryModalOpen,
  } = useApp();

  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'products' | 'ventures' | 'reels'>('all');
  const [selectedSellerForQR, setSelectedSellerForQR] = useState<SellerProfile | null>(null);
  const [isQRModalOpen, setIsQRModalOpen] = useState(false);

  const quickTags = ['All', 'Namkeen', 'Silk Sarees', 'Groceries', 'Electronics', 'Footwear', 'OTT'];

  const q = query.toLowerCase().trim();

  const filteredProducts = products.filter(
    (p) =>
      !q ||
      p.name.toLowerCase().includes(q) ||
      p.description?.toLowerCase().includes(q) ||
      p.brand?.toLowerCase().includes(q) ||
      p.tags?.some((t) => t.toLowerCase().includes(q))
  );

  const filteredSellers = sellers.filter(
    (s) =>
      !q ||
      s.storeName.toLowerCase().includes(q) ||
      s.city?.toLowerCase().includes(q) ||
      s.locality?.toLowerCase().includes(q) ||
      s.category?.toLowerCase().includes(q)
  );

  const filteredReels = shortVideoReels.filter(
    (r) =>
      !q ||
      r.title.toLowerCase().includes(q) ||
      r.storeName.toLowerCase().includes(q)
  );

  return (
    <div id="mobile-search-screen" className="p-3 space-y-4 text-xs pb-10">
      {/* Search Input Card */}
      <div className="relative flex items-center">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search products, ventures, reels..."
          className="w-full pl-9 pr-20 py-2.5 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500/20"
        />
        <Search className="w-4 h-4 text-slate-400 absolute left-3" />
        <div className="absolute right-2 flex items-center gap-1">
          <button
            type="button"
            onClick={() => setIsVoiceSearchOpen(true)}
            className="p-1.5 text-slate-500 hover:text-amber-500 rounded-lg"
          >
            <Mic className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setIsImageSearchOpen(true)}
            className="p-1.5 text-slate-500 hover:text-amber-500 rounded-lg"
          >
            <Camera className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Quick Tag Filter Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        {quickTags.map((tag) => (
          <button
            key={tag}
            onClick={() => setQuery(tag === 'All' ? '' : tag)}
            className={`px-3 py-1 rounded-xl text-[11px] font-bold whitespace-nowrap transition-all ${
              (tag === 'All' && !query) || query.toLowerCase() === tag.toLowerCase()
                ? 'bg-amber-500 text-slate-800 shadow-sm'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            {tag}
          </button>
        ))}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 border-b border-slate-200 dark:border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('all')}
          className={`px-3 py-1 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'all'
              ? 'bg-red-600 text-white shadow-xs'
              : 'bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300'
          }`}
        >
          All
        </button>
        <button
          onClick={() => setActiveTab('products')}
          className={`px-3 py-1 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
            activeTab === 'products'
              ? 'bg-red-600 text-white shadow-xs'
              : 'bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300'
          }`}
        >
          <ShoppingBag className="w-3 h-3" />
          <span>Products ({filteredProducts.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('ventures')}
          className={`px-3 py-1 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
            activeTab === 'ventures'
              ? 'bg-red-600 text-white shadow-xs'
              : 'bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300'
          }`}
        >
          <Store className="w-3 h-3" />
          <span>Ventures ({filteredSellers.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('reels')}
          className={`px-3 py-1 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
            activeTab === 'reels'
              ? 'bg-red-600 text-white shadow-xs'
              : 'bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300'
          }`}
        >
          <Film className="w-3 h-3" />
          <span>Reels ({filteredReels.length})</span>
        </button>
      </div>

      {/* Ventures Section */}
      {(activeTab === 'all' || activeTab === 'ventures') && filteredSellers.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center justify-between text-[11px] font-bold text-slate-500">
            <span className="flex items-center gap-1">
              <Store className="w-3.5 h-3.5 text-red-600" />
              <span>Matching Ventures ({filteredSellers.length})</span>
            </span>
          </div>
          <div className="space-y-2">
            {filteredSellers.slice(0, 4).map((seller) => (
              <div
                key={seller.id}
                className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-between gap-2 shadow-xs"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-red-100 dark:bg-red-950 text-red-600 dark:text-red-400 font-black flex items-center justify-center text-xs">
                    {seller.storeName.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-1">
                      <h4 className="font-extrabold text-xs text-slate-900 dark:text-white">{seller.storeName}</h4>
                      <CheckCircle2 className="w-3 h-3 text-blue-500" />
                    </div>
                    <p className="text-[10px] text-slate-500">
                      📍 {seller.locality || seller.city || 'Indore'} &bull; ⭐ {seller.rating || 4.8}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      setSelectedSellerForQR(seller);
                      setIsQRModalOpen(true);
                    }}
                    className="p-2 bg-slate-100 dark:bg-slate-800 hover:bg-red-50 text-slate-700 dark:text-slate-300 rounded-xl"
                    title="Direct Pay QR"
                  >
                    <QrCode className="w-3.5 h-3.5 text-red-600" />
                  </button>
                  <button
                    onClick={() => openStoreChat(seller.id)}
                    className="px-2.5 py-1.5 bg-red-600 text-white rounded-xl text-[10px] font-black"
                  >
                    Chat
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Products Grid */}
      {(activeTab === 'all' || activeTab === 'products') && (
        <div className="space-y-2">
          <div className="flex items-center justify-between text-[11px] font-bold text-slate-500">
            <span className="flex items-center gap-1">
              <ShoppingBag className="w-3.5 h-3.5 text-red-600" />
              <span>Products ({filteredProducts.length})</span>
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      )}

      {/* Direct Payment QR Modal */}
      <DirectSellerPaymentModal
        seller={selectedSellerForQR}
        isOpen={isQRModalOpen}
        onClose={() => setIsQRModalOpen(false)}
      />
    </div>
  );
};
