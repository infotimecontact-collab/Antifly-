import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  ShoppingBag,
  Sparkles,
  Volume2,
  VolumeX,
  Play,
  Pause,
  CheckCircle2,
  Radio,
  Store,
  Tag,
  ArrowRight,
} from 'lucide-react';
import { UniversalSaveButton } from '../favorites/UniversalSaveButton';

export const MobileReelsScreen: React.FC = () => {
  const {
    reels,
    products,
    likeReel,
    addToCart,
    openStoreChat,
    showToast,
    formatPrice,
    setIsProductDetailOpen,
    setSelectedProductId,
  } = useApp();

  const [activeReelIndex, setActiveReelIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [showComments, setShowComments] = useState(false);
  const [commentsMap, setCommentsMap] = useState<Record<string, string[]>>({
    'reel-1': ['Amazing quality! Is this pure cotton?', 'Just ordered the blue variant 🔥', 'Delivery was super fast!'],
    'reel-2': ['Looks stunning!', 'Can you share the sizing guide?'],
  });

  const activeReel = (reels && reels.length > 0) ? (reels[activeReelIndex] || reels?.[0] || null) : null;
  const linkedProduct = products.find((p) => p.id === activeReel?.linkedProductId);

  const handleNext = () => {
    if (activeReelIndex < reels.length - 1) {
      setActiveReelIndex(activeReelIndex + 1);
    } else {
      setActiveReelIndex(0);
    }
  };

  const handlePrev = () => {
    if (activeReelIndex > 0) {
      setActiveReelIndex(activeReelIndex - 1);
    } else {
      setActiveReelIndex(reels.length - 1);
    }
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !activeReel) return;
    const currentList = commentsMap[activeReel.id] || [];
    setCommentsMap({
      ...commentsMap,
      [activeReel.id]: [...currentList, commentText.trim()],
    });
    setCommentText('');
    showToast('💬 Comment posted!');
  };

  if (!activeReel) {
    return (
      <div className="p-8 text-center text-slate-400">
        <Sparkles className="w-10 h-10 mx-auto mb-2 text-amber-500" />
        <p className="font-bold text-sm">No Reels Available</p>
      </div>
    );
  }

  const currentComments = commentsMap[activeReel.id] || [
    'Super stylish collection! 🔥',
    'Love the fit and fabric quality.',
  ];

  return (
    <div className="relative h-full min-h-[600px] max-h-[720px] bg-white text-white rounded-2xl overflow-hidden flex flex-col justify-between select-none">
      {/* Background Reel Media Simulation */}
      <div
        className="absolute inset-0 cursor-pointer"
        onClick={() => setIsPlaying(!isPlaying)}
      >
        <img
          src={activeReel.thumbnailUrl}
          alt={activeReel.title}
          className="w-full h-full object-cover opacity-90 transition-transform duration-700"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-900/50 via-transparent to-slate-900/90" />

        {!isPlaying && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-900/30">
            <div className="w-12 h-12 rounded-full bg-white/90 text-rose-600 flex items-center justify-center shadow-lg">
              <Play className="w-6 h-6 fill-current ml-1" />
            </div>
          </div>
        )}
      </div>

      {/* Top Reel Navigation & Controls */}
      <div className="relative z-10 p-3 pt-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1 bg-red-600/90 backdrop-blur-md px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider text-white shadow-xs">
            <Radio className="w-3 h-3 animate-pulse" />
            LIVE REELS
          </span>
          <span className="text-[10px] text-white/80 font-mono">
            {activeReelIndex + 1}/{reels.length}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsMuted(!isMuted);
            }}
            className="p-1.5 rounded-full bg-slate-900/60 backdrop-blur-md text-white hover:bg-slate-900/80"
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Right-Side Social Action Stack */}
      <div className="absolute right-3 bottom-24 z-20 flex flex-col items-center gap-3.5">
        {/* Like Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            likeReel(activeReel.id);
          }}
          className="flex flex-col items-center gap-1 group cursor-pointer"
        >
          <div
            className={`w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-md transition-transform active:scale-75 ${
              activeReel.isLiked
                ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/50 scale-110'
                : 'bg-slate-900/60 text-white hover:bg-slate-900/80'
            }`}
          >
            <Heart className={`w-5 h-5 ${activeReel.isLiked ? 'fill-current' : ''}`} />
          </div>
          <span className="text-[9px] font-bold drop-shadow">
            {(activeReel.likesCount || 120).toLocaleString()}
          </span>
        </button>

        {/* Comment Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            setShowComments(!showComments);
          }}
          className="flex flex-col items-center gap-1 group cursor-pointer"
        >
          <div className="w-10 h-10 rounded-full bg-slate-900/60 backdrop-blur-md flex items-center justify-center text-white hover:bg-slate-900/80 transition">
            <MessageCircle className="w-5 h-5" />
          </div>
          <span className="text-[9px] font-bold drop-shadow">{currentComments.length}</span>
        </button>

        {/* Universal Save / Bookmark Button */}
        <div className="flex flex-col items-center gap-1">
          <UniversalSaveButton
            targetId={activeReel.id}
            itemType="reel"
            title={activeReel.title}
            subtitle={activeReel.storeName}
            imageUrl={activeReel.thumbnailUrl}
            iconType="heart"
            size="sm"
            className="shadow-lg"
          />
          <span className="text-[9px] font-bold drop-shadow">Save</span>
        </div>

        {/* Share Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            if (navigator.share) {
              navigator.share({
                title: activeReel.title,
                text: `Watch this reel on Antifly: ${activeReel.title}`,
                url: window.location.href,
              }).catch(() => {});
            } else {
              navigator.clipboard.writeText(window.location.href);
              showToast('🔗 Reel link copied to clipboard!');
            }
          }}
          className="flex flex-col items-center gap-1 group cursor-pointer"
        >
          <div className="w-10 h-10 rounded-full bg-slate-900/60 backdrop-blur-md flex items-center justify-center text-white hover:bg-slate-900/80 transition">
            <Share2 className="w-4 h-4" />
          </div>
          <span className="text-[9px] font-bold drop-shadow">Share</span>
        </button>
      </div>

      {/* Bottom Creator Info & Tagged Commerce Card */}
      <div className="relative z-10 p-3 space-y-2 pb-3">
        {/* Creator Identity */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-500 to-rose-500 p-0.5 shadow-md">
            <img
              src={`https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=60`}
              alt={activeReel.storeName}
              className="w-full h-full rounded-full object-cover"
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-xs text-white drop-shadow">
                {activeReel.storeName || 'Wise Creator'}
              </span>
              <CheckCircle2 className="w-3.5 h-3.5 text-sky-400 fill-sky-400" />
            </div>
            <p className="text-[10px] text-slate-300 line-clamp-1">{activeReel.title}</p>
          </div>
        </div>

        {/* Tagged Product Commerce Pill (Direct View / Buy / Cart) */}
        {linkedProduct && (
          <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-2xl p-2 text-slate-900 dark:text-white border border-white/20 shadow-xl flex items-center justify-between gap-2 animate-slide-in-up">
            <div
              onClick={() => {
                setSelectedProductId(linkedProduct.id);
                setIsProductDetailOpen(true);
              }}
              className="flex items-center gap-2 cursor-pointer flex-1 min-w-0"
            >
              <img
                src={linkedProduct.images?.[0] || linkedProduct.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200'}
                alt={linkedProduct.name}
                className="w-10 h-10 rounded-xl object-cover border border-slate-200 dark:border-slate-800 shrink-0"
              />
              <div className="min-w-0 flex-1">
                <span className="text-[9px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider block">
                  Tagged Product
                </span>
                <h4 className="font-bold text-[11px] truncate text-slate-900 dark:text-white">
                  {linkedProduct.name}
                </h4>
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-xs text-slate-900 dark:text-white">
                    ₹{formatPrice(linkedProduct.price)}
                  </span>
                  {linkedProduct.discountPercentage > 0 && (
                    <span className="text-[9px] text-rose-600 font-bold">
                      {linkedProduct.discountPercentage}% OFF
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1 shrink-0">
              <button
                onClick={() => {
                  addToCart(linkedProduct.id, 1);
                  showToast(`🛒 Added ${linkedProduct.name} to bag!`);
                }}
                className="bg-amber-500 hover:bg-amber-400 text-slate-800 px-2.5 py-1.5 rounded-xl font-extrabold text-[10px] shadow-sm flex items-center gap-1 transition cursor-pointer"
              >
                <ShoppingBag className="w-3 h-3" />
                <span>Buy</span>
              </button>
            </div>
          </div>
        )}

        {/* Up / Down Quick Reels Navigation */}
        <div className="flex items-center justify-between pt-1 text-[10px] text-slate-400">
          <button
            onClick={handlePrev}
            className="hover:text-white transition px-2 py-0.5 bg-slate-900/60 rounded-lg"
          >
            ▲ Prev Reel
          </button>
          <button
            onClick={handleNext}
            className="hover:text-white transition px-2 py-0.5 bg-slate-900/60 rounded-lg font-bold text-amber-400"
          >
            Next Reel ▼
          </button>
        </div>
      </div>

      {/* Interactive Comments Drawer Overlay */}
      {showComments && (
        <div className="absolute inset-x-0 bottom-0 top-1/3 bg-slate-900/98 backdrop-blur-xl z-30 rounded-t-3xl p-4 flex flex-col justify-between border-t border-slate-700 animate-slide-in-up">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h4 className="font-bold text-xs text-white flex items-center gap-1.5">
              <MessageCircle className="w-3.5 h-3.5 text-amber-400" />
              <span>Comments ({currentComments.length})</span>
            </h4>
            <button
              onClick={() => setShowComments(false)}
              className="text-xs text-slate-400 hover:text-white"
            >
              ✕ Close
            </button>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 py-2 text-xs">
            {currentComments.map((cmt, idx) => (
              <div key={idx} className="p-2 rounded-xl bg-slate-800/60 flex items-start gap-2">
                <div className="w-5 h-5 rounded-full bg-slate-700 flex items-center justify-center font-bold text-[9px] text-amber-400">
                  U
                </div>
                <div className="flex-1">
                  <span className="text-[10px] font-bold text-slate-300 block">Verified Shopper</span>
                  <p className="text-[11px] text-white">{cmt}</p>
                </div>
              </div>
            ))}
          </div>

          <form onSubmit={handleAddComment} className="pt-2 flex items-center gap-2">
            <input
              type="text"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder="Add a friendly comment..."
              className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-amber-500"
            />
            <button
              type="submit"
              className="bg-amber-500 text-slate-800 font-bold px-3 py-1.5 rounded-xl text-xs"
            >
              Post
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
