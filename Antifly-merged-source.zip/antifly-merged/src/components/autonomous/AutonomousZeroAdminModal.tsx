import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Zap,
  X,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Cpu,
  Clock,
  DollarSign,
  Store,
  Truck,
  RotateCcw,
  Sparkles,
  Search,
  Check,
  ChevronRight,
  UserCheck,
  Sliders,
  FileCheck,
  RefreshCw,
  QrCode,
  Layers,
  ArrowRight,
  Eye,
  Info,
  Building2,
  Package,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { AutonomousPlatformConfig, AutonomousDisputeCase } from '../../types';
import { ZERO_ADMIN_BENEFITS } from '../../data/autonomousGovernanceData';

interface AutonomousZeroAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type TabKey = 'overview' | 'seller-kyc' | 'ai-disputes' | 'instant-payouts' | 'audit-ledger' | 'self-service';

export const AutonomousZeroAdminModal: React.FC<AutonomousZeroAdminModalProps> = ({
  isOpen,
  onClose,
}) => {
  const {
    autonomousConfig,
    updateAutonomousConfig,
    autonomousAuditLogs,
    autonomousDisputes,
    resolveDisputeAutonomously,
    sellers,
    instantVerifySellerKYC,
    products,
    instantApproveProduct,
    instantReleaseSellerPayout,
    orders,
    selfServiceCancelOrder,
    selfServiceUpdateAddress,
    formatPrice,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<TabKey>('overview');
  const [selectedSellerId, setSelectedSellerId] = useState<string>(sellers[0]?.id || '');
  const [selectedDisputeId, setSelectedDisputeId] = useState<string>(autonomousDisputes[0]?.id || '');
  const [customRefundAmount, setCustomRefundAmount] = useState<number>(1500);
  const [testOrderId, setTestOrderId] = useState<string>(orders[0]?.id || 'ORD-9821');
  const [newAddressInput, setNewAddressInput] = useState<string>('Flat 402, Lotus Grandeur, MG Road, Indore');
  const [cancelReasonInput, setCancelReasonInput] = useState<string>('Ordered by mistake, want different size');

  if (!isOpen) return null;

  const activeDispute = autonomousDisputes.find((d) => d.id === selectedDisputeId) || autonomousDisputes[0];
  const activeSeller = sellers.find((s) => s.id === selectedSellerId) || sellers[0];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[150] flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-white/80 backdrop-blur-md"
        />

        {/* Modal Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-5xl max-h-[92vh] flex flex-col bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden text-slate-100 z-10"
        >
          {/* Top Hero Banner */}
          <div className="relative p-5 sm:p-6 bg-gradient-to-r from-emerald-950 via-slate-900 to-amber-950 border-b border-slate-700/80 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-800 flex items-center justify-center font-black shadow-lg flex-shrink-0">
                <Zap className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2.5">
                  <h2 className="text-lg sm:text-xl font-black tracking-tight text-white">
                    Zero-Admin Autonomous Operations
                  </h2>
                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Zero Touch Engine
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5 font-medium">
                  Instant merchant onboarding, AI auto-approvals, 24x7 instant UPI payouts &amp; autonomous dispute resolution.
                </p>
              </div>
            </div>

            {/* Quick Autonomous Status Pill & Close */}
            <div className="flex items-center gap-3">
              <button
                onClick={() =>
                  updateAutonomousConfig({
                    zeroTouchModeEnabled: !autonomousConfig.zeroTouchModeEnabled,
                  })
                }
                className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer border ${
                  autonomousConfig.zeroTouchModeEnabled
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                    : 'bg-rose-500/20 text-rose-300 border-rose-500/40 hover:bg-rose-500/30'
                }`}
              >
                <Cpu className="w-3.5 h-3.5" />
                <span>{autonomousConfig.zeroTouchModeEnabled ? '⚡ Zero-Admin Active' : '⏸ Manual Mode'}</span>
              </button>

              <button
                onClick={onClose}
                className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition border border-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="px-5 pt-3 bg-slate-900/90 border-b border-slate-800 flex items-center gap-2 overflow-x-auto no-scrollbar">
            {[
              { id: 'overview', label: 'Autonomous Hub', icon: Zap },
              { id: 'seller-kyc', label: 'Instant Auto-KYC', icon: UserCheck },
              { id: 'ai-disputes', label: 'AI Dispute Arbitrator', icon: ShieldCheck },
              { id: 'instant-payouts', label: '24x7 UPI Payouts', icon: DollarSign },
              { id: 'self-service', label: 'Buyer Self-Service', icon: Sparkles },
              { id: 'audit-ledger', label: '0-Touch Audit Ledger', icon: FileCheck },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as TabKey)}
                  className={`px-3.5 py-2.5 rounded-t-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap cursor-pointer border-b-2 ${
                    isActive
                      ? 'bg-slate-800 text-amber-400 border-amber-400 shadow-xs'
                      : 'text-slate-400 hover:text-slate-200 border-transparent hover:bg-slate-800/40'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Modal Body */}
          <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
            {/* TAB: OVERVIEW */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* 4 Pillars of Zero-Admin */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                  {ZERO_ADMIN_BENEFITS.map((b, idx) => (
                    <div
                      key={idx}
                      className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 hover:border-amber-500/30 transition flex flex-col justify-between"
                    >
                      <div>
                        <span className="text-[10px] font-black text-amber-400 uppercase tracking-wider">
                          {b.label}
                        </span>
                        <div className="text-2xl font-black text-white mt-1">{b.metric}</div>
                        <h4 className="text-xs font-bold text-slate-200 mt-1">{b.title}</h4>
                        <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                          {b.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Autonomous Switchboard */}
                <div className="p-5 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-black text-white flex items-center gap-2">
                        <Sliders className="w-4 h-4 text-emerald-400" />
                        Autonomous Rule Switchboard
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Toggle autonomous rule sets to eliminate manual admin review queues.
                      </p>
                    </div>
                    <span className="text-xs font-black text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
                      100% Autonomous Active
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                    {[
                      {
                        key: 'autoApproveSellers',
                        title: 'Instant Seller Auto-KYC',
                        desc: 'Instant GSTIN & PAN OCR check. Store goes live under 30s with zero admin queue.',
                      },
                      {
                        key: 'autoApproveProducts',
                        title: 'Instant Product Auto-Publish',
                        desc: 'AI neural classifier screens prohibited items & safe pricing before instant live listing.',
                      },
                      {
                        key: 'instantEscrowPayouts',
                        title: '24x7 Instant UPI Escrow Release',
                        desc: 'Smart contract escrow auto-releases payouts on OTP delivery completion without admin sign-off.',
                      },
                      {
                        key: 'aiDisputeArbitration',
                        title: 'Autonomous AI Defect Arbitrator',
                        desc: 'AI vision inspects damaged item photos and releases auto-refunds in 3 seconds.',
                      },
                      {
                        key: 'directPeerPaymentsEnabled',
                        title: 'Direct Peer-to-Peer UPI Gateway',
                        desc: 'Direct seller QR payment bypassing platform hold for trusted merchant relationships.',
                      },
                      {
                        key: 'selfServiceOrderControl',
                        title: '1-Click Buyer Self-Service',
                        desc: 'Self-service pre-dispatch address edit, 1-click cancellation, and direct replacement.',
                      },
                    ].map((rule) => {
                      const isEnabled = (autonomousConfig as any)[rule.key];
                      return (
                        <div
                          key={rule.key}
                          onClick={() =>
                            updateAutonomousConfig({
                              [rule.key]: !isEnabled,
                            } as Partial<AutonomousPlatformConfig>)
                          }
                          className={`p-3.5 rounded-xl border transition cursor-pointer flex items-start justify-between gap-3 ${
                            isEnabled
                              ? 'bg-emerald-950/30 border-emerald-500/40 text-slate-200'
                              : 'bg-slate-800/40 border-slate-700 text-slate-400'
                          }`}
                        >
                          <div>
                            <div className="text-xs font-black text-white flex items-center gap-1.5">
                              {isEnabled ? (
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                              ) : (
                                <Clock className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
                              )}
                              <span>{rule.title}</span>
                            </div>
                            <p className="text-[11px] text-slate-400 mt-1 leading-snug">{rule.desc}</p>
                          </div>
                          <div
                            className={`w-9 h-5 rounded-full transition-colors relative flex-shrink-0 p-0.5 ${
                              isEnabled ? 'bg-emerald-500' : 'bg-slate-700'
                            }`}
                          >
                            <div
                              className={`w-4 h-4 rounded-full bg-white transition-transform ${
                                isEnabled ? 'translate-x-4' : 'translate-x-0'
                              }`}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Quick Demonstration Actions */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <button
                    onClick={() => setActiveTab('seller-kyc')}
                    className="p-4 rounded-2xl bg-gradient-to-br from-amber-500/10 to-orange-500/10 border border-amber-500/30 hover:border-amber-500 text-left transition group cursor-pointer"
                  >
                    <UserCheck className="w-5 h-5 text-amber-400 mb-2 group-hover:scale-110 transition-transform" />
                    <div className="text-xs font-black text-white">Test Instant Auto-KYC</div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Instantly approve any seller store with zero human delay.
                    </p>
                  </button>

                  <button
                    onClick={() => setActiveTab('ai-disputes')}
                    className="p-4 rounded-2xl bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/30 hover:border-emerald-500 text-left transition group cursor-pointer"
                  >
                    <ShieldCheck className="w-5 h-5 text-emerald-400 mb-2 group-hover:scale-110 transition-transform" />
                    <div className="text-xs font-black text-white">AI Dispute Arbitrator</div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Simulate 3-second defect vision check and auto-refund release.
                    </p>
                  </button>

                  <button
                    onClick={() => setActiveTab('instant-payouts')}
                    className="p-4 rounded-2xl bg-gradient-to-br from-sky-500/10 to-blue-500/10 border border-sky-500/30 hover:border-sky-500 text-left transition group cursor-pointer"
                  >
                    <DollarSign className="w-5 h-5 text-sky-400 mb-2 group-hover:scale-110 transition-transform" />
                    <div className="text-xs font-black text-white">Instant UPI Withdrawals</div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Trigger 24x7 merchant smart escrow payouts with 0 admin hold.
                    </p>
                  </button>
                </div>
              </div>
            )}

            {/* TAB: INSTANT SELLER AUTO-KYC */}
            {activeTab === 'seller-kyc' && (
              <div className="space-y-5">
                <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
                  <Sparkles className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                  <div className="text-xs">
                    <span className="font-black text-white">Autonomous KYC Pipeline</span>: Eliminates the 3–5 day manual admin verification queue.
                    When a merchant submits GSTIN, PAN, or Aadhaar, neural OCR cross-references public registries and immediately marks the store active with verified trust badges.
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Select Seller */}
                  <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3">
                    <label className="text-xs font-black text-slate-300 uppercase tracking-wider block">
                      Select Registered Store to Auto-Verify
                    </label>
                    <select
                      value={selectedSellerId}
                      onChange={(e) => setSelectedSellerId(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-amber-500 font-bold cursor-pointer"
                    >
                      {sellers.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.storeName} ({s.city}) — {s.isActive ? '🟢 Active' : '🟡 Pending KYC'}
                        </option>
                      ))}
                    </select>

                    <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2 text-xs">
                      <div className="flex items-center justify-between text-slate-400">
                        <span>Store Name:</span>
                        <span className="font-bold text-white">{activeSeller?.storeName}</span>
                      </div>
                      <div className="flex items-center justify-between text-slate-400">
                        <span>GSTIN Number:</span>
                        <span className="font-mono text-amber-400">{activeSeller?.gstNumber || '23AABCI1234F1Z5'}</span>
                      </div>
                      <div className="flex items-center justify-between text-slate-400">
                        <span>Category:</span>
                        <span className="font-bold text-slate-200">{activeSeller?.category}</span>
                      </div>
                      <div className="flex items-center justify-between text-slate-400">
                        <span>Current Status:</span>
                        <span className={`font-black ${activeSeller?.isActive ? 'text-emerald-400' : 'text-amber-400'}`}>
                          {activeSeller?.isActive ? 'ACTIVE & VERIFIED' : 'PENDING ACTIVATION'}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => instantVerifySellerKYC(activeSeller.id)}
                      className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:brightness-110 text-slate-800 font-black text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <UserCheck className="w-4 h-4" />
                      <span>Run Instant AI Auto-KYC (0s Admin Wait)</span>
                    </button>
                  </div>

                  {/* Auto-Publish Products for this Seller */}
                  <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3">
                    <label className="text-xs font-black text-slate-300 uppercase tracking-wider block">
                      Autonomous Product Auto-Publisher
                    </label>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Sellers upload items directly. AI screens safety, text clarity, and catalog integrity instantly.
                    </p>

                    <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                      {products.slice(0, 4).map((prod) => (
                        <div
                          key={prod.id}
                          className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-2"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <img
                              src={prod.image}
                              alt={prod.name}
                              className="w-8 h-8 rounded-lg object-cover flex-shrink-0"
                            />
                            <div className="truncate text-xs font-bold text-slate-200">
                              {prod.name}
                            </div>
                          </div>
                          <button
                            onClick={() => instantApproveProduct(prod.id)}
                            className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-slate-800 text-[10px] font-black rounded-lg transition border border-amber-500/30 flex-shrink-0 cursor-pointer"
                          >
                            Auto-Publish Live
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: AI DISPUTE ARBITRATOR */}
            {activeTab === 'ai-disputes' && (
              <div className="space-y-5">
                <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-3">
                  <ShieldCheck className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <div className="text-xs">
                    <span className="font-black text-white">Autonomous AI Arbitrator</span>: When a buyer reports a damaged, wrong, or late item with photo proof, our vision pipeline analyzes defects against baseline catalog imagery and automatically releases refunds or dispatches instant replacements without human support ticket delays.
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Select Dispute Case */}
                  <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3">
                    <label className="text-xs font-black text-slate-300 uppercase tracking-wider block">
                      Active Dispute Queue (Auto-Monitored)
                    </label>
                    <div className="space-y-2">
                      {autonomousDisputes.map((disp) => (
                        <div
                          key={disp.id}
                          onClick={() => setSelectedDisputeId(disp.id)}
                          className={`p-3 rounded-xl border transition cursor-pointer flex items-center justify-between gap-3 ${
                            selectedDisputeId === disp.id
                              ? 'bg-amber-500/10 border-amber-500/50 text-white'
                              : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-900'
                          }`}
                        >
                          <div>
                            <div className="text-xs font-bold text-slate-200">{disp.productName}</div>
                            <div className="text-[10px] text-slate-400 mt-0.5">
                              Claim: {formatPrice(disp.claimAmount)} • {disp.claimReason.replace(/_/g, ' ')}
                            </div>
                          </div>
                          <span
                            className={`text-[9px] font-black px-2 py-0.5 rounded-full ${
                              disp.status === 'RESOLVED_INSTANTLY'
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            }`}
                          >
                            {disp.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* AI Vision Case Inspection & Decision */}
                  <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-black text-white uppercase tracking-wider">
                        AI Neural Case Analysis
                      </h4>
                      <span className="text-[10px] font-black text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-full border border-emerald-500/30">
                        {activeDispute?.aiConfidenceScore}% AI Confidence
                      </span>
                    </div>

                    {activeDispute?.photoEvidenceUrl && (
                      <div className="relative rounded-xl overflow-hidden border border-slate-700 h-36 bg-white">
                        <img
                          src={activeDispute.photoEvidenceUrl}
                          alt="Evidence"
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute bottom-2 left-2 px-2 py-1 bg-white/80 backdrop-blur-md rounded-lg text-[9px] font-mono text-emerald-300 border border-emerald-500/30">
                          ✓ Defect Pattern Verified: Tear / Mismatch Detected
                        </div>
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                        <span className="text-[10px] text-slate-500 block">Buyer</span>
                        <span className="font-bold text-white">{activeDispute?.customerName}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                        <span className="text-[10px] text-slate-500 block">Claim Amount</span>
                        <span className="font-bold text-emerald-400">{formatPrice(activeDispute?.claimAmount || 0)}</span>
                      </div>
                    </div>

                    {/* AI Decision Triggers */}
                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <button
                        onClick={() => resolveDisputeAutonomously(activeDispute.id, 'AUTO_REFUND_FULL')}
                        className="py-2.5 px-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:brightness-110 text-slate-800 font-black text-xs rounded-xl shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Zap className="w-3.5 h-3.5" />
                        <span>Instant UPI Refund</span>
                      </button>
                      <button
                        onClick={() =>
                          resolveDisputeAutonomously(activeDispute.id, 'INSTANT_EXCHANGE_DISPATCHED')
                        }
                        className="py-2.5 px-3 bg-slate-800 hover:bg-slate-750 text-white font-bold text-xs rounded-xl border border-slate-700 transition flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                        <span>Auto-Exchange</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: 24x7 INSTANT UPI PAYOUTS */}
            {activeTab === 'instant-payouts' && (
              <div className="space-y-5">
                <div className="p-4 rounded-2xl bg-sky-500/10 border border-sky-500/30 flex items-start gap-3">
                  <DollarSign className="w-5 h-5 text-sky-400 flex-shrink-0 mt-0.5" />
                  <div className="text-xs">
                    <span className="font-black text-white">Zero Admin Payout Bottleneck</span>: Sellers no longer wait 7–14 days for manual accounting clearance.
                    As soon as a customer verifies delivery via OTP or receipt, smart escrow unlocks the payout instantly for 24x7 direct UPI IMPS withdrawals.
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-4">
                  <h4 className="text-xs font-black text-white uppercase tracking-wider">
                    Instant 24x7 Merchant Withdrawal Simulator
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                      <span className="text-[10px] text-slate-500 font-bold uppercase">Store Name</span>
                      <div className="text-xs font-black text-white">{activeSeller?.storeName}</div>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                      <span className="text-[10px] text-slate-500 font-bold uppercase">Registered UPI ID</span>
                      <div className="text-xs font-mono text-amber-400">merchant@hdfcbank</div>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                      <span className="text-[10px] text-slate-500 font-bold uppercase">Available Escrow</span>
                      <div className="text-xs font-black text-emerald-400">{formatPrice(74250)}</div>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center gap-3">
                    <div className="relative flex-1 w-full">
                      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">₹</span>
                      <input
                        type="number"
                        value={customRefundAmount}
                        onChange={(e) => setCustomRefundAmount(Number(e.target.value))}
                        className="w-full pl-8 pr-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500 font-bold"
                        placeholder="Enter payout amount"
                      />
                    </div>
                    <button
                      onClick={() => instantReleaseSellerPayout(activeSeller.id, customRefundAmount)}
                      className="w-full sm:w-auto px-6 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:brightness-110 text-slate-800 font-black text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer flex-shrink-0"
                    >
                      <Zap className="w-4 h-4" />
                      <span>Release Instant 24x7 Payout</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: BUYER SELF-SERVICE */}
            {activeTab === 'self-service' && (
              <div className="space-y-5">
                <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
                  <Sparkles className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                  <div className="text-xs">
                    <span className="font-black text-white">Self-Service Automation Hub</span>: Customers can edit pre-dispatch delivery landmarks, cancel orders with instant auto-refunds, and book doorstep trial pickups without dialing customer care.
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Self-Service Address Update */}
                  <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3">
                    <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-2">
                      <span>1-Click Address &amp; Landmark Update</span>
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      Update your delivery location before the delivery partner departs.
                    </p>

                    <input
                      type="text"
                      value={newAddressInput}
                      onChange={(e) => setNewAddressInput(e.target.value)}
                      placeholder="Enter new street/flat/landmark"
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
                    />

                    <button
                      onClick={() => selfServiceUpdateAddress(testOrderId, newAddressInput)}
                      className="w-full py-2.5 bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs rounded-xl transition flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <span>Update Address Instantly</span>
                    </button>
                  </div>

                  {/* 1-Click Self-Service Cancellation */}
                  <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3">
                    <h4 className="text-xs font-black text-white uppercase tracking-wider">
                      1-Click Instant Cancellation &amp; Refund
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      Pre-dispatch orders cancel immediately with instant automated refund release.
                    </p>

                    <input
                      type="text"
                      value={cancelReasonInput}
                      onChange={(e) => setCancelReasonInput(e.target.value)}
                      placeholder="Cancellation reason"
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
                    />

                    <button
                      onClick={() => selfServiceCancelOrder(testOrderId, cancelReasonInput)}
                      className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl transition flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <span>Cancel Order &amp; Auto-Refund</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: AUDIT LEDGER */}
            {activeTab === 'audit-ledger' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-black text-white flex items-center gap-2">
                      <FileCheck className="w-4 h-4 text-emerald-400" />
                      Zero-Touch Autonomous Execution Ledger
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      All platform actions resolved autonomously with exactly 0 human admin touches.
                    </p>
                  </div>
                  <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
                    {autonomousAuditLogs.length} Actions Verified
                  </span>
                </div>

                <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
                  {autonomousAuditLogs.map((log) => (
                    <div
                      key={log.id}
                      className="p-3.5 rounded-2xl bg-slate-800/70 border border-slate-700/80 space-y-2 text-xs"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-emerald-400" />
                          <span className="font-black text-white">{log.summary}</span>
                        </div>
                        <span className="text-[10px] font-mono text-slate-400">{log.timestamp}</span>
                      </div>

                      <p className="text-[11px] text-slate-400 leading-relaxed pl-4">
                        {log.decisionReason}
                      </p>

                      <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-800 text-[10px]">
                        <div className="flex items-center gap-3 text-slate-400">
                          <span>Actor: <strong className="text-slate-200">{log.actorName}</strong></span>
                          <span>Execution Time: <strong className="text-amber-400">{log.executionTimeMs}ms</strong></span>
                        </div>
                        <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 font-mono font-black">
                          0 Human Admin Touches
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-4 sm:p-5 bg-white border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-slate-400 text-[11px]">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Decentralized Autonomous Trust &amp; 100% Peer Reliability</span>
            </div>

            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold transition cursor-pointer"
            >
              Close Hub
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
