import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Zap,
  X,
  Activity,
  Cpu,
  Navigation,
  ShieldCheck,
  Compass,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw,
  Sparkles,
  TrendingUp,
  Boxes,
  Lock,
  Layers,
  Thermometer,
  Eye,
  Plane,
  Truck,
  Bot,
  QrCode,
  Radio,
  Search,
  Filter,
  Check,
  ArrowRight,
  Info,
} from 'lucide-react';
import {
  AutonomousDeliveryAgent,
  PackageDigitalPassport,
  FutureDemandForecast,
  WhatIfScenarioSimulation,
} from '../../types';
import {
  AUTONOMOUS_PILLARS_60,
  INITIAL_AUTONOMOUS_AGENTS,
  INITIAL_DIGITAL_PASSPORTS,
  INITIAL_FUTURE_FORECASTS,
  INITIAL_WHAT_IF_SCENARIOS,
  AutonomousPillar,
} from '../../data/autonomousData';

interface AutonomousDeliveryBrainModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type TabType = 'PILLARS' | 'DEMAND_FORECAST' | 'AGENT_DNA' | 'DIGITAL_PASSPORT' | 'DIGITAL_TWIN' | 'TIME_AUCTION';

export const AutonomousDeliveryBrainModal: React.FC<AutonomousDeliveryBrainModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('PILLARS');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedPillar, setSelectedPillar] = useState<AutonomousPillar | null>(
    AUTONOMOUS_PILLARS_60?.[0] || null
  );

  // Forecast state
  const [activeForecastIdx, setActiveForecastIdx] = useState<number>(0);
  const currentForecast: FutureDemandForecast =
    INITIAL_FUTURE_FORECASTS?.[activeForecastIdx] ||
    INITIAL_FUTURE_FORECASTS?.[0] || {
      timeframe: '30_MIN',
      predictedOrders: 420,
      highDemandZones: [],
      aiActionTaken: 'Fleet pre-positioned',
    };
  const [isPrepositioning, setIsPrepositioning] = useState<boolean>(false);
  const [prepositionSuccess, setPrepositionSuccess] = useState<boolean>(false);

  // Agent DNA state
  const [agents, setAgents] = useState<AutonomousDeliveryAgent[]>(INITIAL_AUTONOMOUS_AGENTS || []);
  const [selectedAgent, setSelectedAgent] = useState<AutonomousDeliveryAgent | null>(
    INITIAL_AUTONOMOUS_AGENTS?.[0] || null
  );
  const [testOrderType, setTestOrderType] = useState<'HOT_FOOD' | 'URGENT_MEDICINE' | 'FRAGILE_SILK' | 'BULK_CARGO'>('HOT_FOOD');

  // Digital Passport state
  const [passports] = useState<PackageDigitalPassport[]>(INITIAL_DIGITAL_PASSPORTS || []);
  const [activePassportIdx, setActivePassportIdx] = useState<number>(0);
  const currentPassport: PackageDigitalPassport =
    passports?.[activePassportIdx] ||
    passports?.[0] ||
    INITIAL_DIGITAL_PASSPORTS?.[0] || {
      packageId: 'PKG-PASSPORT-9901',
      orderNumber: 'WB-948201',
      qrHash: 'SHA256:8f4c2e91a0b36d8e72c41f05e39b98ac14f',
      senderBusiness: 'Sarafa Kitchens',
      recipientAddress: 'Indore',
      dimensionsCm: { length: 28, width: 22, height: 16 },
      weightKg: 1.45,
      fragilityLevel: 'TEMPERATURE_SENSITIVE',
      requiredTempCelsius: { min: 55, max: 75 },
      currentTempCelsius: 64.2,
      shockGForceMax: 0.3,
      tamperSealVerified: true,
      transitHistory: [],
    };
  const [simulatedTemp, setSimulatedTemp] = useState<number>(currentPassport?.currentTempCelsius ?? 64.2);
  const [isTamperTested, setIsTamperTested] = useState<boolean>(false);

  // Digital Twin state
  const [scenarios] = useState<WhatIfScenarioSimulation[]>(INITIAL_WHAT_IF_SCENARIOS || []);
  const [customSurge, setCustomSurge] = useState<number>(200);
  const [customDriverShortage, setCustomDriverShortage] = useState<number>(15);
  const [customRain, setCustomRain] = useState<'NONE' | 'MODERATE' | 'HEAVY_MONSOON'>('MODERATE');
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simulationResult, setSimulationResult] = useState<{
    avgDeliveryMin: number;
    slaPercent: number;
    selfHealCount: number;
    relayHops: number;
    dronesUsed: number;
  } | null>(null);

  // Time Auction state
  const [flexDeliverySelected, setFlexDeliverySelected] = useState<boolean>(false);
  const [auctionSpeed, setAuctionSpeed] = useState<'TURBO_DRONE' | 'STANDARD_EV' | 'FLEX_BATCH'>('STANDARD_EV');

  if (!isOpen) return null;

  const filteredPillars = AUTONOMOUS_PILLARS_60.filter((p) => {
    const matchesSearch =
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.number.toString().includes(searchQuery);
    const matchesCategory = selectedCategory === 'ALL' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleRunSimulation = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const rainPenalty = customRain === 'HEAVY_MONSOON' ? 6 : customRain === 'MODERATE' ? 3 : 0;
      const surgeDelay = Math.round((customSurge / 100) * 4);
      const shortageDelay = Math.round((customDriverShortage / 10) * 1.5);
      const baseMin = 14;

      const calcMin = baseMin + rainPenalty + surgeDelay + shortageDelay;
      const calcRate = Math.max(88, 100 - (customDriverShortage * 0.25) - (rainPenalty * 1.2));
      const autoRecoveries = Math.round(customSurge * 0.2 + customDriverShortage * 1.8);
      const relayHops = Math.round(customSurge * 0.15 + (customRain === 'HEAVY_MONSOON' ? 20 : 8));
      const drones = customRain === 'HEAVY_MONSOON' ? 8 : Math.round(customSurge * 0.08 + 12);

      setSimulationResult({
        avgDeliveryMin: Math.min(35, calcMin),
        slaPercent: Math.min(99.8, calcRate),
        selfHealCount: autoRecoveries,
        relayHops,
        dronesUsed: drones,
      });
      setIsSimulating(false);
    }, 800);
  };

  const handlePrepositionFleet = () => {
    setIsPrepositioning(true);
    setTimeout(() => {
      setIsPrepositioning(false);
      setPrepositionSuccess(true);
      setTimeout(() => setPrepositionSuccess(false), 4000);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-white/80 backdrop-blur-md overflow-hidden">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.96 }}
        className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-6xl h-[92vh] flex flex-col shadow-2xl overflow-hidden text-slate-100"
      >
        {/* TOP HEADER */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-white/70 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-teal-500 to-emerald-500 flex items-center justify-center text-slate-800 shadow-lg shadow-cyan-500/20">
              <Cpu className="w-5 h-5 font-bold animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                  Autonomous Commerce & Delivery Brain
                </h2>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                  60 Pillars Live
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Self-Operating Hyperlocal Logistics • Dynamic DNA • Digital Twin Simulator • Universal Agent Engine
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end md:self-center">
            {/* Live SLA telemetry */}
            <div className="hidden lg:flex items-center gap-3 px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700 text-xs">
              <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                <Activity className="w-3.5 h-3.5 animate-pulse" />
                <span>99.4% On-Time SLA</span>
              </div>
              <div className="h-3 w-px bg-slate-700" />
              <div className="flex items-center gap-1.5 text-cyan-400 font-semibold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Self-Healing v4.9 Active</span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-all"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* NAVIGATION TABS */}
        <div className="flex items-center gap-1.5 px-4 py-2 border-b border-slate-800 bg-slate-900/60 overflow-x-auto text-xs font-semibold shrink-0">
          <button
            onClick={() => setActiveTab('PILLARS')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'PILLARS'
                ? 'bg-gradient-to-r from-cyan-600 to-teal-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>1. 60 Pillars Navigator</span>
          </button>

          <button
            onClick={() => setActiveTab('DEMAND_FORECAST')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'DEMAND_FORECAST'
                ? 'bg-gradient-to-r from-cyan-600 to-teal-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>2. Predictive Demand Map</span>
          </button>

          <button
            onClick={() => setActiveTab('AGENT_DNA')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'AGENT_DNA'
                ? 'bg-gradient-to-r from-cyan-600 to-teal-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Bot className="w-3.5 h-3.5" />
            <span>3. Dynamic Delivery DNA & Agents</span>
          </button>

          <button
            onClick={() => setActiveTab('DIGITAL_PASSPORT')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'DIGITAL_PASSPORT'
                ? 'bg-gradient-to-r from-cyan-600 to-teal-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>4. Package Digital Passport</span>
          </button>

          <button
            onClick={() => setActiveTab('DIGITAL_TWIN')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'DIGITAL_TWIN'
                ? 'bg-gradient-to-r from-cyan-600 to-teal-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>5. "What-If?" Digital Twin</span>
          </button>

          <button
            onClick={() => setActiveTab('TIME_AUCTION')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'TIME_AUCTION'
                ? 'bg-gradient-to-r from-cyan-600 to-teal-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>6. Delivery Auction & Flex Route</span>
          </button>
        </div>

        {/* BODY CONTENT AREA */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-white/40">
          {/* TAB 1: 60 PILLARS NAVIGATOR */}
          {activeTab === 'PILLARS' && (
            <div className="space-y-6">
              {/* Search and Category Filters */}
              <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
                <div className="relative w-full sm:w-80">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search all 60 pillars (e.g. DNA, drone, passport)..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
                  {['ALL', 'AI_BRAIN', 'PREDICTIVE_LOGISTICS', 'DISPATCH_ROUTING', 'HARDWARE_AGENTS', 'SECURITY_TRUST', 'SELF_HEALING'].map(
                    (cat) => (
                      <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                          selectedCategory === cat
                            ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                            : 'bg-slate-800/60 text-slate-400 hover:text-white border border-slate-700/50'
                        }`}
                      >
                        {cat.replace('_', ' ')}
                      </button>
                    )
                  )}
                </div>
              </div>

              {/* Grid + Inspector Layout */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                {/* Pillars List (7 cols) */}
                <div className="lg:col-span-7 space-y-2.5 max-h-[58vh] overflow-y-auto pr-1">
                  <div className="text-xs text-slate-400 font-semibold mb-2">
                    Showing {filteredPillars.length} of 60 Architectural Innovations
                  </div>
                  {filteredPillars.map((p) => {
                    const isSelected = selectedPillar?.number === p.number;
                    return (
                      <div
                        key={p.number}
                        onClick={() => setSelectedPillar(p)}
                        className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
                          isSelected
                            ? 'bg-cyan-950/40 border-cyan-500/80 shadow-md shadow-cyan-900/20 ring-1 ring-cyan-500/40'
                            : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
                        }`}
                      >
                        <div
                          className={`w-7 h-7 rounded-lg shrink-0 flex items-center justify-center font-bold text-xs ${
                            isSelected ? 'bg-cyan-500 text-slate-800' : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          #{p.number}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2">
                            <h4 className="text-xs font-bold text-white truncate">{p.title}</h4>
                            <span className="text-[10px] uppercase font-bold text-cyan-400/90 bg-cyan-950/80 px-2 py-0.5 rounded-md border border-cyan-800/50 shrink-0">
                              {p.category.replace('_', ' ')}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                            {p.summary}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Selected Pillar Detailed Specs Card (5 cols) */}
                <div className="lg:col-span-5 bg-slate-900 border border-slate-700 rounded-2xl p-5 space-y-4 shadow-xl sticky top-0">
                  {selectedPillar ? (
                    <>
                      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-1 rounded-lg bg-cyan-500 text-slate-800 font-black text-xs">
                            Pillar #{selectedPillar.number}
                          </span>
                          <span className="text-xs font-bold text-cyan-400">
                            {selectedPillar.category.replace('_', ' ')}
                          </span>
                        </div>
                        <Sparkles className="w-4 h-4 text-cyan-400" />
                      </div>

                      <div>
                        <h3 className="text-base font-extrabold text-white">{selectedPillar.title}</h3>
                        <p className="text-xs text-slate-300 mt-2 leading-relaxed bg-white/60 p-3 rounded-xl border border-slate-800">
                          {selectedPillar.summary}
                        </p>
                      </div>

                      <div>
                        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                          Architectural Specifications & Operational Flow
                        </h4>
                        <div className="text-xs text-slate-300 space-y-2 bg-slate-800/40 p-3.5 rounded-xl border border-slate-700/60">
                          <div className="flex items-start gap-2">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                            <span>{selectedPillar.detailedSpecs}</span>
                          </div>
                          <div className="flex items-start gap-2">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                            <span>Autonomous validation with cryptographic telemetry verification.</span>
                          </div>
                          <div className="flex items-start gap-2">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                            <span>Zero human overhead: Continuous Self-Healing loop & Swarm Optimization.</span>
                          </div>
                        </div>
                      </div>

                      {/* Interactive Demo Launcher for this Pillar */}
                      <div className="pt-2">
                        <button
                          onClick={() => {
                            if (selectedPillar.interactiveDemoType === 'DEMAND_MAP') setActiveTab('DEMAND_FORECAST');
                            else if (selectedPillar.interactiveDemoType === 'DNA_MATCHER') setActiveTab('AGENT_DNA');
                            else if (selectedPillar.interactiveDemoType === 'DIGITAL_TWIN') setActiveTab('DIGITAL_TWIN');
                            else if (selectedPillar.interactiveDemoType === 'PASS_SENSOR') setActiveTab('DIGITAL_PASSPORT');
                            else if (selectedPillar.interactiveDemoType === 'TIME_AUCTION') setActiveTab('TIME_AUCTION');
                            else setActiveTab('DIGITAL_TWIN');
                          }}
                          className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-800 font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 transition-all"
                        >
                          <Play className="w-3.5 h-3.5" />
                          <span>Launch Live Interactive Simulation</span>
                          <ArrowRight className="w-3.5 h-3.5 ml-1" />
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="p-8 text-center text-slate-500 text-xs">
                      Select a pillar to view system specs and simulation controls.
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PREDICTIVE DEMAND MAP (Pillars 2, 17, 18, 21) */}
          {activeTab === 'DEMAND_FORECAST' && (
            <div className="space-y-6">
              {/* Forecast Timeframe Selector */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-cyan-400" />
                    Future Demand Forecasting Engine (Pillars #2 & #18)
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Forecasts demand bursts before checkout, pre-warming drone corridors and staging micro-fleets.
                  </p>
                </div>

                <div className="flex items-center gap-1.5 bg-white p-1 rounded-xl border border-slate-800">
                  {INITIAL_FUTURE_FORECASTS.map((fc, idx) => (
                    <button
                      key={fc.timeframe}
                      onClick={() => setActiveForecastIdx(idx)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                        activeForecastIdx === idx
                          ? 'bg-cyan-500 text-slate-800 shadow-xs'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {fc.timeframe.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Demand Map Metrics & Prepositioning Action */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
                  <span className="text-xs text-slate-400 font-semibold">Predicted Hyperlocal Orders</span>
                  <div className="text-2xl font-black text-cyan-400 mt-1">{currentForecast.predictedOrders} Orders</div>
                  <span className="text-[11px] text-emerald-400 flex items-center gap-1 mt-1">
                    <TrendingUp className="w-3 h-3" /> +28% surge vs baseline week
                  </span>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
                  <span className="text-xs text-slate-400 font-semibold">Target Surge Zones</span>
                  <div className="text-2xl font-black text-amber-400 mt-1">
                    {currentForecast.highDemandZones.length} Key Hubs
                  </div>
                  <span className="text-[11px] text-slate-400 mt-1 block truncate">
                    {currentForecast.highDemandZones.map((z) => z.zoneName).join(', ')}
                  </span>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between">
                  <div>
                    <span className="text-xs text-slate-400 font-semibold">Autonomous Prepositioning</span>
                    <p className="text-[11px] text-slate-300 mt-1">{currentForecast.aiActionTaken}</p>
                  </div>
                  <button
                    onClick={handlePrepositionFleet}
                    disabled={isPrepositioning}
                    className="mt-3 py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-800 font-extrabold text-xs flex items-center justify-center gap-2 transition-all disabled:opacity-50"
                  >
                    {isPrepositioning ? (
                      <span className="animate-spin">🌀</span>
                    ) : prepositionSuccess ? (
                      <Check className="w-3.5 h-3.5" />
                    ) : (
                      <Navigation className="w-3.5 h-3.5" />
                    )}
                    <span>
                      {isPrepositioning
                        ? 'Balancing Fleet...'
                        : prepositionSuccess
                        ? 'Fleets Prepositioned!'
                        : 'Preposition Staged Fleet Now'}
                    </span>
                  </button>
                </div>
              </div>

              {/* High Demand Clusters Map View */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Live Spatial Demand Polygons & Fleet Density
                  </h4>
                  <span className="text-xs text-cyan-400 font-semibold">Self-Optimizing Polygons (Pillar #54)</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {currentForecast.highDemandZones.map((zone) => (
                    <div
                      key={zone.zoneId}
                      className="bg-white border border-slate-800 rounded-xl p-4 space-y-3 relative overflow-hidden"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <h5 className="text-sm font-extrabold text-white">{zone.zoneName}</h5>
                          <span className="text-xs text-slate-400">{zone.category}</span>
                        </div>
                        <span className="px-2 py-1 rounded-md bg-amber-500/10 text-amber-400 border border-amber-500/30 text-xs font-bold">
                          {zone.expectedSurgeFactor}x Surge
                        </span>
                      </div>

                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between text-slate-400">
                          <span>Top Predicted SKU:</span>
                          <span className="text-slate-200 font-medium">{zone.topPredictedItem}</span>
                        </div>
                        <div className="flex justify-between text-slate-400">
                          <span>Recommended Staging Fleet:</span>
                          <span className="text-cyan-400 font-bold">{zone.recommendedPrepositionFleet} Couriers / Drones</span>
                        </div>
                      </div>

                      {/* Animated Progress Bar */}
                      <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-amber-500 to-red-500 h-full rounded-full"
                          style={{ width: `${Math.min(100, zone.expectedSurgeFactor * 32)}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: DYNAMIC DELIVERY DNA & AGENT MATCHER (Pillars 3, 4, 5, 51) */}
          {activeTab === 'AGENT_DNA' && (
            <div className="space-y-6">
              {/* Context Selector */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Bot className="w-4 h-4 text-cyan-400" />
                    Dynamic Delivery DNA & Universal Agent API (Pillars #3 & #51)
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Multi-factor live scoring across Human EV Couriers, Autonomous Drones, Sidewalk Rovers, and Smart Lockers.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400 font-semibold">Test Order Context:</span>
                  <select
                    value={testOrderType}
                    onChange={(e) => setTestOrderType(e.target.value as any)}
                    className="bg-white border border-slate-700 text-xs text-white rounded-xl px-3 py-1.5 focus:outline-none focus:border-cyan-500"
                  >
                    <option value="HOT_FOOD">Hot Food (Need Thermal Control)</option>
                    <option value="URGENT_MEDICINE">Urgent Medicine (Need Sub-10m Sky Drone)</option>
                    <option value="FRAGILE_SILK">Fragile Silk Saree (Need 100% Care)</option>
                    <option value="BULK_CARGO">Bulk B2B Cargo (Need High Payload)</option>
                  </select>
                </div>
              </div>

              {/* Agent Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {agents.map((ag) => {
                  const isSelected = selectedAgent.id === ag.id;
                  return (
                    <div
                      key={ag.id}
                      onClick={() => setSelectedAgent(ag)}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between gap-4 ${
                        isSelected
                          ? 'bg-slate-900 border-cyan-500 shadow-lg shadow-cyan-500/10 ring-1 ring-cyan-500'
                          : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={ag.avatar}
                            alt={ag.name}
                            className="w-11 h-11 rounded-xl object-cover border border-slate-700"
                          />
                          <div>
                            <h4 className="text-xs font-bold text-white">{ag.name}</h4>
                            <span className="text-[10px] font-semibold text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
                              {ag.type.replace('_', ' ')}
                            </span>
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="text-xs font-black text-emerald-400">{ag.dnaScore} DNA</div>
                          <span className="text-[10px] text-slate-400">{ag.batteryOrFuelPercent}% SoC</span>
                        </div>
                      </div>

                      {/* DNA Radar Metrics Bars */}
                      <div className="space-y-1.5 text-[11px] bg-white/60 p-2.5 rounded-xl border border-slate-800/80">
                        <div className="flex justify-between">
                          <span className="text-slate-400">Pickup Efficiency:</span>
                          <span className="text-slate-200 font-bold">{ag.metrics.pickupEfficiency}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Weather Capability:</span>
                          <span className="text-slate-200 font-bold">{ag.metrics.weatherRating}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Fragile Care Score:</span>
                          <span className="text-slate-200 font-bold">{ag.metrics.fragileCareRating}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Cancellation Risk:</span>
                          <span className="text-emerald-400 font-bold">{ag.metrics.cancellationRisk}%</span>
                        </div>
                      </div>

                      {/* Active Mission Status */}
                      {ag.currentMission ? (
                        <div className="text-[10px] bg-amber-500/10 border border-amber-500/20 text-amber-300 p-2 rounded-lg">
                          <div className="font-bold flex items-center justify-between">
                            <span>Mission: {ag.currentMission.id}</span>
                            <span>ETA {ag.currentMission.etaMinutes}m</span>
                          </div>
                          <div className="truncate mt-0.5 text-slate-300">
                            {ag.currentMission.pickup} ➔ {ag.currentMission.dropoff}
                          </div>
                        </div>
                      ) : (
                        <div className="text-[10px] bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 p-2 rounded-lg font-bold text-center">
                          Ready for Dynamic Relay / Mission
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 4: DIGITAL PACKAGE PASSPORT & SENSORS (Pillars 25, 26, 27, 28) */}
          {activeTab === 'DIGITAL_PASSPORT' && (
            <div className="space-y-6">
              {/* Header Selector */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <QrCode className="w-4 h-4 text-cyan-400" />
                    Package Digital Passport & Cryptographic Chain of Custody (Pillar #27)
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Immutable SHA-256 telemetry ledger, active thermal monitoring, tamper seals, and zero-knowledge proof.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {passports.map((p, idx) => (
                    <button
                      key={p.packageId}
                      onClick={() => {
                        setActivePassportIdx(idx);
                        setSimulatedTemp(p.currentTempCelsius || 64.2);
                        setIsTamperTested(false);
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                        activePassportIdx === idx
                          ? 'bg-cyan-500 text-slate-800'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {p.packageId} ({p.orderNumber})
                    </button>
                  ))}
                </div>
              </div>

              {/* Live Passport Card */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Passport Card (7 cols) */}
                <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div>
                      <span className="text-[10px] uppercase font-black text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
                        {currentPassport.fragilityLevel}
                      </span>
                      <h4 className="text-base font-extrabold text-white mt-1">
                        Passport ID: {currentPassport.packageId}
                      </h4>
                    </div>
                    <div className="text-right text-xs">
                      <div className="text-slate-400 font-mono text-[10px]">{currentPassport.qrHash}</div>
                      <span className="text-emerald-400 font-bold flex items-center gap-1 justify-end mt-0.5">
                        <CheckCircle2 className="w-3 h-3" /> Cryptographically Verified
                      </span>
                    </div>
                  </div>

                  {/* Physical Specs & Sensor Telemetry */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div className="bg-white p-3 rounded-xl border border-slate-800">
                      <span className="text-slate-500">Weight:</span>
                      <div className="font-extrabold text-white text-sm mt-0.5">{currentPassport.weightKg} kg</div>
                    </div>
                    <div className="bg-white p-3 rounded-xl border border-slate-800">
                      <span className="text-slate-500">Max G-Shock:</span>
                      <div className="font-extrabold text-emerald-400 text-sm mt-0.5">
                        {currentPassport.shockGForceMax} G (Safe)
                      </div>
                    </div>
                    <div className="bg-white p-3 rounded-xl border border-slate-800">
                      <span className="text-slate-500">Current Temp:</span>
                      <div className="font-extrabold text-cyan-400 text-sm mt-0.5">{simulatedTemp.toFixed(1)}°C</div>
                    </div>
                    <div className="bg-white p-3 rounded-xl border border-slate-800">
                      <span className="text-slate-500">Tamper Seal:</span>
                      <div className="font-extrabold text-emerald-400 text-sm mt-0.5">
                        {isTamperTested ? 'TRIGGERED (Alert)' : '100% Intact'}
                      </div>
                    </div>
                  </div>

                  {/* Chain of Custody Timeline */}
                  <div>
                    <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                      Immutable Chain of Custody Handshakes
                    </h5>
                    <div className="space-y-2.5">
                      {currentPassport.transitHistory.map((t, i) => (
                        <div
                          key={i}
                          className="flex items-start gap-3 bg-white/70 p-3 rounded-xl border border-slate-800/80 text-xs"
                        >
                          <span className="w-2 h-2 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-white">{t.stage}</span>
                              <span className="text-[10px] text-slate-500">{t.timestamp}</span>
                            </div>
                            <div className="text-slate-400 text-[11px] mt-0.5">
                              {t.agentName} • {t.location}
                            </div>
                          </div>
                          <span className="text-[9px] font-mono bg-slate-800 text-cyan-300 px-2 py-0.5 rounded">
                            {t.verificationType}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Interactive Sensor Stress Tester (5 cols) */}
                <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                    <Thermometer className="w-4 h-4 text-cyan-400" />
                    Live Thermal & Tamper Testing Simulator
                  </h4>

                  <div className="space-y-4 bg-white p-4 rounded-xl border border-slate-800 text-xs">
                    <div>
                      <div className="flex justify-between text-slate-300 mb-1">
                        <span>Simulate Ambient Temp Change:</span>
                        <span className="font-bold text-cyan-400">{simulatedTemp.toFixed(1)}°C</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="80"
                        step="0.5"
                        value={simulatedTemp}
                        onChange={(e) => setSimulatedTemp(parseFloat(e.target.value))}
                        className="w-full accent-cyan-400"
                      />
                    </div>

                    <div className="pt-2 flex items-center justify-between">
                      <span className="text-slate-300">Test Tamper Breach Sensor:</span>
                      <button
                        onClick={() => setIsTamperTested(!isTamperTested)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                          isTamperTested ? 'bg-red-500 text-white' : 'bg-slate-800 text-slate-300 hover:text-white'
                        }`}
                      >
                        {isTamperTested ? 'Reset Seal' : 'Simulate Box Opening'}
                      </button>
                    </div>

                    {isTamperTested && (
                      <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-xs flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 shrink-0" />
                        <span>Tamper breach logged! Customer notified & photo verification required.</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: LOGISTICS DIGITAL TWIN & WHAT-IF SIMULATOR (Pillars 50, 52, 53) */}
          {activeTab === 'DIGITAL_TWIN' && (
            <div className="space-y-6">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-cyan-400" />
                    Logistics Digital Twin & "What If?" Scenario Stress-Tester (Pillars #52 & #53)
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Simulates extreme real-world stress conditions (rain storms, flash sales, traffic gridlocks) before operational changes.
                  </p>
                </div>

                <button
                  onClick={handleRunSimulation}
                  disabled={isSimulating}
                  className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-800 font-extrabold text-xs flex items-center gap-2 shadow-lg shadow-cyan-500/20 transition-all disabled:opacity-50"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>{isSimulating ? 'Simulating 1,000 Neural Paths...' : 'Execute Digital Twin Simulation'}</span>
                </button>
              </div>

              {/* Parameter Controls */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400 font-semibold">Order Volume Surge:</span>
                    <span className="text-cyan-400 font-bold">+{customSurge}%</span>
                  </div>
                  <input
                    type="range"
                    min="50"
                    max="500"
                    step="25"
                    value={customSurge}
                    onChange={(e) => setCustomSurge(parseInt(e.target.value))}
                    className="w-full accent-cyan-400"
                  />
                  <span className="text-[10px] text-slate-500 block">Simulates sudden festival bursts or lightning sales</span>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400 font-semibold">Driver Shortage Factor:</span>
                    <span className="text-amber-400 font-bold">{customDriverShortage}% Shortage</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="50"
                    step="5"
                    value={customDriverShortage}
                    onChange={(e) => setCustomDriverShortage(parseInt(e.target.value))}
                    className="w-full accent-amber-400"
                  />
                  <span className="text-[10px] text-slate-500 block">Simulates offline battery recharging or shift rotations</span>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
                  <span className="text-xs text-slate-400 font-semibold block">Weather Scenario:</span>
                  <div className="grid grid-cols-3 gap-1.5">
                    {(['NONE', 'MODERATE', 'HEAVY_MONSOON'] as const).map((r) => (
                      <button
                        key={r}
                        onClick={() => setCustomRain(r)}
                        className={`py-1.5 rounded-lg text-[11px] font-bold transition-all ${
                          customRain === r
                            ? 'bg-cyan-500 text-slate-800'
                            : 'bg-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {r.replace('_', ' ')}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Simulation Result Dashboard */}
              {simulationResult && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-slate-900 border border-cyan-500/60 rounded-2xl p-5 space-y-4 shadow-xl"
                >
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-2">
                      <Sparkles className="w-4 h-4" />
                      Self-Healing Network Projected Outcome
                    </h4>
                    <span className="text-xs text-emerald-400 font-extrabold">Auto-Balance Feasible</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
                    <div className="bg-white p-3.5 rounded-xl border border-slate-800">
                      <span className="text-slate-500">Avg Delivery Speed:</span>
                      <div className="text-xl font-black text-white mt-1">{simulationResult.avgDeliveryMin} min</div>
                    </div>
                    <div className="bg-white p-3.5 rounded-xl border border-slate-800">
                      <span className="text-slate-500">On-Time SLA Rate:</span>
                      <div className="text-xl font-black text-emerald-400 mt-1">
                        {simulationResult.slaPercent.toFixed(1)}%
                      </div>
                    </div>
                    <div className="bg-white p-3.5 rounded-xl border border-slate-800">
                      <span className="text-slate-500">Self-Healed Reroutes:</span>
                      <div className="text-xl font-black text-cyan-400 mt-1">{simulationResult.selfHealCount}</div>
                    </div>
                    <div className="bg-white p-3.5 rounded-xl border border-slate-800">
                      <span className="text-slate-500">Relay Hops Activated:</span>
                      <div className="text-xl font-black text-purple-400 mt-1">{simulationResult.relayHops}</div>
                    </div>
                    <div className="bg-white p-3.5 rounded-xl border border-slate-800">
                      <span className="text-slate-500">Drone Air Corridors:</span>
                      <div className="text-xl font-black text-teal-400 mt-1">{simulationResult.dronesUsed} Active</div>
                    </div>
                  </div>
                </motion.div>
              )}
            </div>
          )}

          {/* TAB 6: DELIVERY TIME AUCTION & WAIT FOR BEST ROUTE (Pillars 55 & 56) */}
          {activeTab === 'TIME_AUCTION' && (
            <div className="space-y-6">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Zap className="w-4 h-4 text-cyan-400" />
                    Delivery Time Auction & "Wait for Best Route" Flex Savings (Pillars #55 & #56)
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Customers choose price vs speed based on real network capacity. Save up to 40% with pooled eco-routes.
                  </p>
                </div>
              </div>

              {/* Delivery Speed Slices */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div
                  onClick={() => setAuctionSpeed('TURBO_DRONE')}
                  className={`p-5 rounded-2xl border transition-all cursor-pointer space-y-3 ${
                    auctionSpeed === 'TURBO_DRONE'
                      ? 'bg-slate-900 border-cyan-500 ring-1 ring-cyan-500 shadow-xl'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      PRIORITY TURBO
                    </span>
                    <Plane className="w-4 h-4 text-cyan-400" />
                  </div>
                  <div className="text-2xl font-black text-white">₹95 • 12 Mins</div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Direct Point-to-Point SkyHex Drone or Priority Green Corridor EV. Dispatched immediately without batching.
                  </p>
                </div>

                <div
                  onClick={() => setAuctionSpeed('STANDARD_EV')}
                  className={`p-5 rounded-2xl border transition-all cursor-pointer space-y-3 ${
                    auctionSpeed === 'STANDARD_EV'
                      ? 'bg-slate-900 border-emerald-500 ring-1 ring-emerald-500 shadow-xl'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      STANDARD HYPERLOCAL
                    </span>
                    <Truck className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-2xl font-black text-white">₹40 • 28 Mins</div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Optimized EV courier dispatch with synchronized zero-wait restaurant / store pickup.
                  </p>
                </div>

                <div
                  onClick={() => setAuctionSpeed('FLEX_BATCH')}
                  className={`p-5 rounded-2xl border transition-all cursor-pointer space-y-3 ${
                    auctionSpeed === 'FLEX_BATCH'
                      ? 'bg-slate-900 border-purple-500 ring-1 ring-purple-500 shadow-xl'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      FLEX ECO-BATCH (40% OFF)
                    </span>
                    <Sparkles className="w-4 h-4 text-purple-400" />
                  </div>
                  <div className="text-2xl font-black text-purple-400">₹24 • 45 Mins</div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Allows AI to delay dispatch slightly to bundle with nearby neighborhood drops. Zero net extra carbon footprint.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
