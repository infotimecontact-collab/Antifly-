import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Product, Order, DriverProfile } from '../../types';
import {
  TrendingUp,
  Package,
  ShoppingBag,
  CreditCard,
  Sliders,
  Plus,
  Search,
  Camera,
  ChevronRight,
  ShieldCheck,
  Zap,
  MapPin,
  Clock,
  Truck,
  CheckCircle2,
  X,
  Sparkles,
  ArrowUpRight,
  RefreshCw,
  QrCode,
  Store,
  Wallet,
  Settings,
  Flame,
} from 'lucide-react';

export const SellerIOSApp: React.FC = () => {
  const {
    currentSeller,
    sellers,
    setActiveSellerId,
    products,
    orders,
    drivers,
    addSellerProduct,
    updateSellerProduct,
    deleteSellerProduct,
    updateSellerInventory,
    requestSellerPayout,
    sellerPayouts,
    assignDriverToOrder,
    calculateDistanceKm,
    showToast,
    viewOrderInvoice,
  } = useApp();

  const [iosTab, setIosTab] = useState<'today' | 'inventory' | 'orders' | 'wallet' | 'settings'>('today');
  const [currentTime, setCurrentTime] = useState('9:41');
  const [activeIsland, setActiveIsland] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSegment, setSelectedSegment] = useState<'all' | 'electrical' | 'cosmetics' | 'furniture' | 'ethnic-wear'>('all');

  // Modals
  const [isAddSheetOpen, setIsAddSheetOpen] = useState(false);
  const [isAssignSheetOpen, setIsAssignSheetOpen] = useState(false);
  const [selectedOrderForDriver, setSelectedOrderForDriver] = useState<Order | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('electrical');
  const [price, setPrice] = useState<number>(1899);
  const [mrp, setMrp] = useState<number>(2999);
  const [stock, setStock] = useState<number>(35);
  const [imageUrl, setImageUrl] = useState('');
  const [payoutAmount, setPayoutAmount] = useState<number>(20000);
  const [isProcessingPayout, setIsProcessingPayout] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      const hours = d.getHours() % 12 || 12;
      const mins = String(d.getMinutes()).padStart(2, '0');
      setCurrentTime(`${hours}:${mins}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  // Filter products for current seller
  const sellerProducts = products.filter(
    (p) =>
      p.sellerId === currentSeller.id ||
      p.brand.toLowerCase().includes(currentSeller.storeName.toLowerCase()) ||
      p.storeName?.toLowerCase() === currentSeller.storeName.toLowerCase() ||
      p.specifications?.some((s) => s.value === currentSeller.storeName) ||
      p.tags.includes(currentSeller.storeName)
  );

  const filteredProducts = sellerProducts.filter((p) => {
    const matchSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchSeg = selectedSegment === 'all' || p.category.toLowerCase() === selectedSegment.toLowerCase();
    return matchSearch && matchSeg;
  });

  // Calculate nearby drivers
  const nearbyDrivers = drivers.map((d) => {
    const dist = calculateDistanceKm(currentSeller.lat, currentSeller.lng, d.lat, d.lng);
    return {
      ...d,
      distanceKm: dist,
    };
  }).sort((a, b) => a.distanceKm - b.distanceKm);

  // Seller orders
  const sellerOrders = orders.filter((o) =>
    o.items.some((i) =>
      sellerProducts.some((p) => p.id === i.productId || p.name === i.productName)
    )
  );

  const pendingOrders = sellerOrders.filter(
    (o) => o.status === 'Pending' || o.status === 'Confirmed' || o.status === 'Packed'
  );

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      showToast('Please enter title');
      return;
    }
    await addSellerProduct({
      name: title,
      title: title,
      category,
      price,
      mrp,
      stock,
      image:
        imageUrl ||
        'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=600&auto=format&fit=crop&q=80',
      description: `Published via iOS Seller Pro App for ${currentSeller.storeName}.`,
    });
    setIsAddSheetOpen(false);
    setTitle('');
    setImageUrl('');
    showToast(`✓ Published "${title}" to iOS & Web storefronts!`);
  };

  const handlePayout = async () => {
    if (payoutAmount <= 0 || payoutAmount > currentSeller.balanceAvailable) {
      showToast('Invalid payout amount');
      return;
    }
    setIsProcessingPayout(true);
    await requestSellerPayout(currentSeller.id, payoutAmount);
    setIsProcessingPayout(false);
    showToast(`✓ Apple Pay IMPS Payout of ₹${payoutAmount.toLocaleString('en-IN')} confirmed!`);
  };

  return (
    <div className="min-h-screen bg-white py-4 sm:py-8 flex items-center justify-center p-2">
      {/* iPhone Hardware Shell */}
      <div
        id="ios-seller-hardware"
        className="w-full max-w-[420px] h-[870px] bg-slate-900 rounded-[52px] p-3 shadow-2xl border-4 border-slate-700 ring-4 ring-slate-800 flex flex-col relative overflow-hidden font-sans select-none"
      >
        {/* iOS Inner Screen */}
        <div className="w-full h-full bg-white rounded-[42px] overflow-hidden flex flex-col relative text-slate-100">
          {/* iOS Status Bar */}
          <div className="px-7 pt-3 pb-1 flex items-center justify-between text-xs font-semibold bg-slate-900/90 backdrop-blur-md z-30">
            <span className="font-bold text-white tracking-tight">{currentTime}</span>

            {/* iOS Dynamic Island */}
            <div
              onClick={() => setActiveIsland(!activeIsland)}
              className={`bg-slate-100 text-white rounded-full flex items-center justify-between px-3 py-1 cursor-pointer transition-all duration-300 shadow-inner ${
                activeIsland ? 'w-48 h-7 text-[10px]' : 'w-24 h-5 text-[9px]'
              }`}
            >
              {activeIsland ? (
                <>
                  <span className="flex items-center gap-1 text-emerald-400 font-bold">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    Rider 0.6 km
                  </span>
                  <span className="text-[10px] text-amber-400 font-mono font-bold">#IND-881</span>
                </>
              ) : (
                <div className="w-full flex items-center justify-center">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                </div>
              )}
            </div>

            <div className="flex items-center gap-1 text-slate-200 text-[11px]">
              <span className="font-bold text-[10px]">5G</span>
              <span>100%</span>
            </div>
          </div>

          {/* iOS Navigation Header */}
          <header className="px-4 py-2 bg-slate-900/80 backdrop-blur-xl border-b border-slate-800 flex items-center justify-between z-20">
            <div>
              <span className="text-[9px] font-bold uppercase tracking-widest text-amber-400">
                Seller Pro iOS
              </span>
              <h1 className="text-sm font-black text-white line-clamp-1 max-w-[170px]">
                {currentSeller?.storeName || 'Wise Store'}
              </h1>
            </div>

            <div className="flex items-center gap-2">
              {/* Store Switcher */}
              <select
                value={currentSeller?.id || ''}
                onChange={(e) => setActiveSellerId(e.target.value)}
                className="bg-slate-800 text-xs font-bold text-slate-200 px-2 py-1 rounded-xl border border-slate-700 focus:outline-none"
              >
                {sellers.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.storeName}
                  </option>
                ))}
              </select>

              <button
                onClick={() => setIsAddSheetOpen(true)}
                className="w-8 h-8 rounded-full bg-amber-500 text-slate-800 flex items-center justify-center font-black shadow-md hover:bg-amber-400"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </header>

          {/* Scrollable Screen Content */}
          <main className="flex-1 overflow-y-auto p-3.5 space-y-4 pb-20">
            {/* TAB 1: TODAY (DASHBOARD) */}
            {iosTab === 'today' && (
              <div className="space-y-3.5">
                {/* iOS Glassmorphism Metric Card */}
                <div className="p-4 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 border border-slate-700/70 shadow-xl space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400 font-semibold">Today's Revenue</span>
                    <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 font-bold rounded-full text-[10px]">
                      +18.4% Today ↗
                    </span>
                  </div>

                  <div className="text-3xl font-black text-white font-mono tracking-tight">
                    ₹42,890<span className="text-xs text-slate-400 font-normal">.50</span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800 text-center">
                    <div className="p-2 bg-white/60 rounded-2xl">
                      <span className="text-[9px] text-slate-400 block font-medium">Orders</span>
                      <span className="font-bold text-amber-400 text-xs">{sellerOrders.length || 18}</span>
                    </div>
                    <div className="p-2 bg-white/60 rounded-2xl">
                      <span className="text-[9px] text-slate-400 block font-medium">Pending</span>
                      <span className="font-bold text-orange-400 text-xs">{pendingOrders.length || 2}</span>
                    </div>
                    <div className="p-2 bg-white/60 rounded-2xl">
                      <span className="text-[9px] text-slate-400 block font-medium">Rating</span>
                      <span className="font-bold text-emerald-400 text-xs">⭐ 4.9</span>
                    </div>
                  </div>
                </div>

                {/* Incoming Orders Awaiting Fulfillment */}
                {pendingOrders.length > 0 && (
                  <div className="p-3.5 bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/40 rounded-2xl flex items-center justify-between shadow-md">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-amber-500 text-slate-800 flex items-center justify-center font-bold">
                        ⚡
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-white">
                          {pendingOrders.length} New Orders Ready
                        </h4>
                        <p className="text-[10px] text-amber-300">Indore hyperlocal courier standing by</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setIosTab('orders')}
                      className="px-3 py-1.5 bg-amber-500 text-slate-800 rounded-xl text-xs font-bold shadow"
                    >
                      View →
                    </button>
                  </div>
                )}

                {/* Hyperlocal Fleet Radar */}
                <div className="p-3.5 bg-slate-900/70 border border-slate-800 rounded-3xl space-y-2.5">
                  <div className="flex items-center justify-between text-xs">
                    <h3 className="font-bold text-white flex items-center gap-1.5">
                      <Truck className="w-3.5 h-3.5 text-emerald-400" />
                      Live Nearby Delivery Fleet
                    </h3>
                    <span className="text-[10px] text-emerald-400 font-bold">
                      {nearbyDrivers.length} Available
                    </span>
                  </div>

                  <div className="space-y-1.5">
                    {nearbyDrivers.slice(0, 3).map((drv) => (
                      <div
                        key={drv.id}
                        className="p-2 bg-white rounded-2xl border border-slate-800 flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <img src={drv.avatar} alt={drv.name} className="w-7 h-7 rounded-full border border-emerald-500" />
                          <div>
                            <div className="font-bold text-white text-[11px]">{drv.name}</div>
                            <div className="text-[9px] text-slate-400">{drv.vehicleNumber}</div>
                          </div>
                        </div>
                        <span className="text-[10px] font-bold text-emerald-400">
                          📍 {drv.distanceKm.toFixed(1)} km
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Quick Add Preset Buttons */}
                <div className="p-3.5 bg-slate-900/70 border border-slate-800 rounded-3xl space-y-2">
                  <h3 className="text-xs font-bold text-white">1-Click SKU Listing Presets</h3>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <button
                      onClick={() => {
                        setTitle('Havells 16A Modular Socket');
                        setCategory('electrical');
                        setPrice(340);
                        setMrp(520);
                        setIsAddSheetOpen(true);
                      }}
                      className="p-2.5 bg-white border border-slate-800 rounded-2xl text-left hover:border-amber-400 transition-all"
                    >
                      <span className="font-bold text-white text-[11px] block">⚡ 16A Modular Socket</span>
                      <span className="text-[10px] text-amber-400 font-bold">₹340</span>
                    </button>

                    <button
                      onClick={() => {
                        setTitle('Organic Rose Hydrating Serum');
                        setCategory('cosmetics');
                        setPrice(650);
                        setMrp(999);
                        setIsAddSheetOpen(true);
                      }}
                      className="p-2.5 bg-white border border-slate-800 rounded-2xl text-left hover:border-amber-400 transition-all"
                    >
                      <span className="font-bold text-white text-[11px] block">💄 Rose Face Serum</span>
                      <span className="text-[10px] text-amber-400 font-bold">₹650</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: INVENTORY */}
            {iosTab === 'inventory' && (
              <div className="space-y-3">
                {/* Search Bar */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl px-3 py-2 flex items-center gap-2 text-xs">
                  <Search className="w-3.5 h-3.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search store inventory..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-transparent text-white focus:outline-none text-xs"
                  />
                </div>

                {/* Cupertino Segmented Control */}
                <div className="p-1 bg-slate-900 rounded-xl border border-slate-800 flex text-[10px]">
                  {['all', 'electrical', 'cosmetics', 'furniture', 'ethnic-wear'].map((seg) => (
                    <button
                      key={seg}
                      onClick={() => setSelectedSegment(seg as any)}
                      className={`flex-1 py-1 rounded-lg font-bold uppercase transition-all ${
                        selectedSegment === seg
                          ? 'bg-amber-500 text-slate-800 shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {seg === 'ethnic-wear' ? 'Cloths' : seg}
                    </button>
                  ))}
                </div>

                {/* Grouped Products */}
                <div className="space-y-2">
                  {filteredProducts.map((p) => (
                    <div
                      key={p.id}
                      className="p-3 bg-slate-900/90 border border-slate-800/80 rounded-2xl flex items-center justify-between gap-3 shadow-xs"
                    >
                      <div className="flex items-center gap-2.5">
                        <img
                          src={p.images?.[0] || 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=600&auto=format&fit=crop&q=80'}
                          alt={p.name}
                          className="w-12 h-12 rounded-xl object-cover border border-slate-700 shrink-0"
                        />
                        <div>
                          <h4 className="font-bold text-white text-xs line-clamp-1">{p.name}</h4>
                          <span className="text-[10px] text-slate-400 capitalize">{p.category}</span>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <span className="text-xs font-mono font-bold text-amber-400">
                              ₹{p.price.toLocaleString('en-IN')}
                            </span>
                            <span className="text-[9px] text-slate-500 line-through">₹{p.mrp}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col items-end gap-1">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                            (p.stock || 0) > 0
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : 'bg-rose-500/20 text-rose-400'
                          }`}
                        >
                          {(p.stock || 0) > 0 ? `${p.stock} In Stock` : 'Out of Stock'}
                        </span>

                        <button
                          onClick={() => {
                            const newStk = (p.stock || 0) > 0 ? 0 : 45;
                            updateSellerInventory(p.id, newStk);
                            showToast(`Updated inventory to ${newStk}`);
                          }}
                          className="text-[10px] text-amber-400 hover:underline font-semibold"
                        >
                          {(p.stock || 0) > 0 ? 'Mark OOS' : 'Restock'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 3: ORDERS */}
            {iosTab === 'orders' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <h3 className="font-bold text-white">Live Store Orders</h3>
                  <span className="text-[10px] font-bold text-amber-400">{sellerOrders.length} Total</span>
                </div>

                <div className="space-y-2">
                  {sellerOrders.map((ord) => (
                    <div
                      key={ord.id}
                      className="p-3.5 bg-slate-900 border border-slate-800 rounded-2xl space-y-2 shadow-sm"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-mono font-bold text-white">{ord.orderNumber}</span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                            ord.status === 'Delivered'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : 'bg-amber-500/20 text-amber-300'
                          }`}
                        >
                          {ord.status}
                        </span>
                      </div>

                      <div className="text-[11px] text-slate-300">
                        {ord.items.map((it, idx) => (
                          <div key={idx} className="flex justify-between py-0.5">
                            <span className="line-clamp-1">{it.quantity}x {it.productName}</span>
                            <span className="font-mono text-amber-400 font-bold">₹{it.price * it.quantity}</span>
                          </div>
                        ))}
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                        <span className="font-bold text-emerald-400 font-mono">
                          ₹{ord.totalAmount.toLocaleString('en-IN')}
                        </span>

                        <div className="flex gap-1.5">
                          <button
                            onClick={() => viewOrderInvoice(ord)}
                            className="px-2.5 py-1 bg-slate-800 text-slate-200 text-[10px] rounded-lg font-medium"
                          >
                            Invoice
                          </button>
                          {ord.status !== 'Delivered' && (
                            <button
                              onClick={() => {
                                setSelectedOrderForDriver(ord);
                                setIsAssignSheetOpen(true);
                              }}
                              className="px-3 py-1 bg-amber-500 text-slate-800 text-[10px] font-bold rounded-lg shadow-sm"
                            >
                              Assign Rider
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 4: WALLET */}
            {iosTab === 'wallet' && (
              <div className="space-y-3.5">
                <div className="p-5 bg-gradient-to-br from-slate-900 via-amber-950/30 to-slate-900 border border-amber-500/40 rounded-3xl space-y-3 shadow-xl">
                  <div className="flex items-center justify-between text-xs text-slate-300">
                    <span className="flex items-center gap-1.5 font-bold">
                      <CreditCard className="w-4 h-4 text-amber-400" />
                      Apple Cash & Bank Settlement
                    </span>
                    <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-[9px] font-bold rounded-full">
                      IMPS 24/7 ⚡
                    </span>
                  </div>

                  <div className="text-3xl font-black text-amber-400 font-mono">
                    ₹{currentSeller.balanceAvailable.toLocaleString('en-IN')}
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <label className="text-[10px] text-slate-400 block font-semibold">
                      Instant Payout Amount (INR ₹):
                    </label>
                    <input
                      type="number"
                      value={payoutAmount}
                      onChange={(e) => setPayoutAmount(Number(e.target.value))}
                      max={currentSeller.balanceAvailable}
                      className="w-full bg-white border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono font-bold"
                    />

                    <button
                      onClick={handlePayout}
                      disabled={isProcessingPayout || currentSeller.balanceAvailable <= 0}
                      className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-800 font-black rounded-xl text-xs shadow-md mt-2 disabled:opacity-50"
                    >
                      {isProcessingPayout ? 'Processing IMPS Transfer...' : 'Instant Bank Payout ➔'}
                    </button>
                  </div>
                </div>

                {/* Settlement History */}
                <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-2xl space-y-2">
                  <h4 className="text-xs font-bold text-white">Recent Settlements</h4>
                  <div className="space-y-1.5 text-[11px]">
                    {sellerPayouts.slice(0, 3).map((pay) => (
                      <div
                        key={pay.id}
                        className="p-2 bg-white rounded-xl border border-slate-800 flex items-center justify-between"
                      >
                        <div>
                          <span className="font-bold text-white">₹{pay.amount.toLocaleString('en-IN')}</span>
                          <p className="text-[9px] text-slate-400 font-mono">UTR: {pay.utrNumber}</p>
                        </div>
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-500/20 text-emerald-300">
                          {pay.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 5: SETTINGS */}
            {iosTab === 'settings' && (
              <div className="space-y-3">
                <div className="p-4 bg-slate-900 border border-slate-800 rounded-3xl space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-amber-500 text-slate-800 flex items-center justify-center font-black text-xl shadow-md">
                      🏪
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-white">{currentSeller.storeName}</h3>
                      <p className="text-[10px] text-slate-400">{currentSeller.email}</p>
                      <span className="text-[9px] font-bold px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded-full mt-1 inline-block">
                        {currentSeller.badge || 'Verified iOS Merchant'}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2 text-xs divide-y divide-slate-800 pt-2">
                    <div className="pt-2 flex justify-between">
                      <span className="text-slate-400">Category:</span>
                      <span className="font-bold text-white capitalize">{currentSeller.category}</span>
                    </div>
                    <div className="pt-2 flex justify-between">
                      <span className="text-slate-400">Delivery Radius:</span>
                      <span className="font-bold text-emerald-400">{currentSeller.deliveryRadiusKm} km</span>
                    </div>
                    <div className="pt-2 flex justify-between">
                      <span className="text-slate-400">GSTIN:</span>
                      <span className="font-mono text-slate-300 text-[11px]">{currentSeller.gstNumber}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </main>

          {/* iOS Cupertino Tab Bar */}
          <nav className="absolute bottom-0 inset-x-0 bg-slate-900/95 backdrop-blur-xl border-t border-slate-800 px-3 py-2 flex items-center justify-around z-30">
            <button
              onClick={() => setIosTab('today')}
              className={`flex flex-col items-center gap-1 ${
                iosTab === 'today' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span className="text-[10px]">Today</span>
            </button>

            <button
              onClick={() => setIosTab('inventory')}
              className={`flex flex-col items-center gap-1 ${
                iosTab === 'inventory' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Package className="w-4 h-4" />
              <span className="text-[10px]">Inventory</span>
            </button>

            <button
              onClick={() => setIosTab('orders')}
              className={`flex flex-col items-center gap-1 relative ${
                iosTab === 'orders' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="text-[10px]">Orders</span>
              {pendingOrders.length > 0 && (
                <span className="absolute -top-1 -right-2 w-4 h-4 rounded-full bg-amber-500 text-slate-800 font-black text-[9px] flex items-center justify-center">
                  {pendingOrders.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setIosTab('wallet')}
              className={`flex flex-col items-center gap-1 ${
                iosTab === 'wallet' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              <span className="text-[10px]">Wallet</span>
            </button>

            <button
              onClick={() => setIosTab('settings')}
              className={`flex flex-col items-center gap-1 ${
                iosTab === 'settings' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span className="text-[10px]">Settings</span>
            </button>
          </nav>

          {/* iOS ADD PRODUCT SHEET */}
          {isAddSheetOpen && (
            <div className="absolute inset-0 bg-slate-100/80 backdrop-blur-sm z-40 flex items-end">
              <div className="w-full max-h-[85%] bg-slate-900 border-t-2 border-amber-500 rounded-t-3xl p-4 overflow-y-auto space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <h3 className="font-bold text-white text-xs">New Product SKU</h3>
                  <button onClick={() => setIsAddSheetOpen(false)} className="text-slate-400 hover:text-white">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <form onSubmit={handleCreateProduct} className="space-y-3 text-xs">
                  <div>
                    <label className="text-slate-300 block mb-1 font-semibold">Title *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Havells MCB Switch"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="w-full bg-white border border-slate-700 rounded-xl px-3 py-2 text-white"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-slate-300 block mb-1 font-semibold">Category</label>
                      <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full bg-white border border-slate-700 rounded-xl px-2 py-2 text-white text-xs"
                      >
                        <option value="electrical">⚡ Electrical</option>
                        <option value="cosmetics">💄 Cosmetics</option>
                        <option value="furniture">🪑 Furniture</option>
                        <option value="ethnic-wear">👕 Cloths</option>
                        <option value="commercial-hardware">🛠️ Commercial</option>
                        <option value="gadgets">📱 Electronics</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-semibold">Stock</label>
                      <input
                        type="number"
                        min={1}
                        value={stock}
                        onChange={(e) => setStock(Number(e.target.value))}
                        className="w-full bg-white border border-slate-700 rounded-xl px-3 py-2 text-emerald-400 font-bold"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-slate-300 block mb-1 font-semibold">Price (₹)</label>
                      <input
                        type="number"
                        required
                        min={1}
                        value={price}
                        onChange={(e) => setPrice(Number(e.target.value))}
                        className="w-full bg-white border border-slate-700 rounded-xl px-3 py-2 text-amber-400 font-bold"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-semibold">MRP (₹)</label>
                      <input
                        type="number"
                        required
                        min={1}
                        value={mrp}
                        onChange={(e) => setMrp(Number(e.target.value))}
                        className="w-full bg-white border border-slate-700 rounded-xl px-3 py-2 text-slate-300"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-800 font-black rounded-xl text-xs shadow-md mt-2"
                  >
                    Publish to Storefront ➔
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* ASSIGN RIDER SHEET */}
          {isAssignSheetOpen && selectedOrderForDriver && (
            <div className="absolute inset-0 bg-slate-100/80 backdrop-blur-sm z-40 flex items-end">
              <div className="w-full bg-slate-900 border-t border-slate-700 rounded-t-3xl p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <h3 className="font-bold text-white text-xs">
                    Dispatch Order {selectedOrderForDriver.orderNumber}
                  </h3>
                  <button onClick={() => setIsAssignSheetOpen(false)} className="text-slate-400 hover:text-white">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-2 max-h-56 overflow-y-auto">
                  {nearbyDrivers.map((drv) => (
                    <div
                      key={drv.id}
                      className="p-2.5 bg-white border border-slate-800 rounded-xl flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <img src={drv.avatar} alt={drv.name} className="w-8 h-8 rounded-full border border-emerald-500" />
                        <div>
                          <div className="font-bold text-white text-xs">{drv.name}</div>
                          <div className="text-[10px] text-emerald-400 font-bold">📍 {drv.distanceKm.toFixed(1)} km</div>
                        </div>
                      </div>
                      <button
                        onClick={async () => {
                          const res = await assignDriverToOrder(selectedOrderForDriver.id, drv.id);
                          setIsAssignSheetOpen(false);
                          showToast(res.message);
                        }}
                        className="px-3 py-1.5 bg-amber-500 text-slate-800 font-bold text-xs rounded-lg shadow-sm"
                      >
                        Assign Rider
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
