import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Product, Order, DriverProfile } from '../../types';
import {
  Store,
  Plus,
  Package,
  ShoppingBag,
  TrendingUp,
  Wallet,
  Truck,
  MapPin,
  Clock,
  Phone,
  CheckCircle,
  AlertCircle,
  Search,
  Camera,
  QrCode,
  Bell,
  Sliders,
  ChevronRight,
  RefreshCw,
  Zap,
  ShieldCheck,
  X,
  Sparkles,
  ArrowUpRight,
  Filter,
  Check,
  Share2,
} from 'lucide-react';

export const SellerAndroidApp: React.FC = () => {
  const {
    currentSeller,
    sellers,
    setActiveSellerId,
    products,
    orders,
    drivers,
    addSellerProduct,
    updateSellerProduct,
    deleteSellerProduct,
    updateSellerInventory,
    requestSellerPayout,
    sellerPayouts,
    assignDriverToOrder,
    calculateDistanceKm,
    userLocation,
    formatPrice,
    showToast,
    viewOrderInvoice,
  } = useApp();

  const [androidTab, setAndroidTab] = useState<'pulse' | 'catalog' | 'orders' | 'wallet' | 'store'>('pulse');
  const [currentTime, setCurrentTime] = useState('10:24');
  const [isOnline, setIsOnline] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState('all');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isQrModalOpen, setIsQrModalOpen] = useState(false);
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [selectedOrderForDriver, setSelectedOrderForDriver] = useState<Order | null>(null);

  // New Product Form State
  const [newTitle, setNewTitle] = useState('');
  const [newCat, setNewCat] = useState('electrical');
  const [newCustomCat, setNewCustomCat] = useState('');
  const [newPrice, setNewPrice] = useState<number>(1450);
  const [newMrp, setNewMrp] = useState<number>(2200);
  const [newStock, setNewStock] = useState<number>(40);
  const [newImage, setNewImage] = useState('');
  const [newDesc, setNewDesc] = useState('');

  // Payout State
  const [payoutInput, setPayoutInput] = useState<number>(15000);
  const [isPayingOut, setIsPayingOut] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      const hours = d.getHours() % 12 || 12;
      const mins = String(d.getMinutes()).padStart(2, '0');
      setCurrentTime(`${hours}:${mins}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  // Filter products for current seller
  const sellerProducts = products.filter(
    (p) =>
      p.sellerId === currentSeller.id ||
      p.brand.toLowerCase().includes(currentSeller.storeName.toLowerCase()) ||
      p.storeName?.toLowerCase() === currentSeller.storeName.toLowerCase() ||
      p.specifications?.some((s) => s.value === currentSeller.storeName) ||
      p.tags.includes(currentSeller.storeName)
  );

  const filteredProducts = sellerProducts.filter((p) => {
    const matchSearch =
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchCat =
      selectedCategoryFilter === 'all' || p.category.toLowerCase() === selectedCategoryFilter.toLowerCase();
    return matchSearch && matchCat;
  });

  // Calculate nearby drivers
  const nearbyDrivers = drivers.map((d) => {
    const dist = calculateDistanceKm(currentSeller.lat, currentSeller.lng, d.lat, d.lng);
    return {
      ...d,
      distanceKm: dist,
    };
  }).sort((a, b) => a.distanceKm - b.distanceKm);

  // Seller orders
  const sellerOrders = orders.filter((o) =>
    o.items.some((i) =>
      sellerProducts.some((p) => p.id === i.productId || p.name === i.productName)
    )
  );

  const pendingOrders = sellerOrders.filter(
    (o) => o.status === 'Pending' || o.status === 'Confirmed' || o.status === 'Packed'
  );

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) {
      showToast('Please enter product title');
      return;
    }
    const finalCat = newCat === 'custom' && newCustomCat ? newCustomCat : newCat;
    await addSellerProduct({
      name: newTitle,
      title: newTitle,
      category: finalCat,
      price: newPrice,
      mrp: newMrp,
      stock: newStock,
      image:
        newImage ||
        'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=600&auto=format&fit=crop&q=80',
      description: newDesc || `Listed on Android Seller App from ${currentSeller.storeName}.`,
    });
    setIsAddModalOpen(false);
    setNewTitle('');
    setNewImage('');
    setNewDesc('');
    showToast(`✓ Published "${newTitle}" live to customers!`);
  };

  const handleQuickPreset = (preset: { name: string; cat: string; price: number; mrp: number; img: string }) => {
    setNewTitle(preset.name);
    setNewCat(preset.cat);
    setNewPrice(preset.price);
    setNewMrp(preset.mrp);
    setNewImage(preset.img);
    setNewDesc(`Authentic ${preset.cat} stock from ${currentSeller.storeName}, Indore.`);
    showToast(`Filled template: ${preset.name}`);
  };

  const handleAssignDriver = async (driverId: string) => {
    if (!selectedOrderForDriver) return;
    const res = await assignDriverToOrder(selectedOrderForDriver.id, driverId);
    setIsAssignModalOpen(false);
    setSelectedOrderForDriver(null);
    showToast(res.message);
  };

  const handleRequestPayout = async () => {
    if (payoutInput <= 0 || payoutInput > currentSeller.balanceAvailable) {
      showToast('Invalid payout amount');
      return;
    }
    setIsPayingOut(true);
    await requestSellerPayout(currentSeller.id, payoutInput);
    setIsPayingOut(false);
    showToast(`✓ IMPS Payout of ₹${payoutInput.toLocaleString('en-IN')} transferred to your bank account!`);
  };

  return (
    <div className="min-h-screen bg-white py-4 sm:py-8 flex items-center justify-center p-2">
      {/* Android Device Hardware Container */}
      <div
        id="android-seller-hardware"
        className="w-full max-w-[420px] h-[870px] bg-slate-900 rounded-[44px] p-2.5 shadow-2xl border-4 border-slate-700 ring-2 ring-emerald-500/30 flex flex-col relative overflow-hidden"
      >
        {/* Inner Screen */}
        <div className="w-full h-full bg-white rounded-[36px] overflow-hidden flex flex-col relative text-slate-100 font-sans select-none">
          {/* Android Material 3 Status Bar */}
          <div className="px-6 pt-3 pb-1 flex items-center justify-between text-xs font-semibold bg-slate-900/90 backdrop-blur-md z-30 border-b border-slate-800/80">
            <span className="font-bold text-emerald-400">{currentTime}</span>
            {/* Front Camera Punch-hole */}
            <div className="w-3.5 h-3.5 rounded-full bg-slate-100 border border-slate-700 shadow-inner" />
            <div className="flex items-center gap-1.5 text-slate-300 text-[11px]">
              <span className="text-[10px] font-bold px-1 bg-emerald-500/20 text-emerald-400 rounded">5G</span>
              <span>98%</span>
            </div>
          </div>

          {/* Android App Top App Bar */}
          <header className="px-4 py-2.5 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 flex items-center justify-between z-20">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-slate-800 font-black text-sm shadow-md">
                ⚡
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h1 className="text-xs font-black text-white line-clamp-1 max-w-[150px]">
                    {currentSeller.storeName}
                  </h1>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                </div>
                <p className="text-[10px] text-slate-400 font-medium">
                  Android Seller Hub &bull; {currentSeller.warehouseAddress?.city || 'Indore'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              {/* Store Online / Offline Toggle */}
              <button
                onClick={() => {
                  setIsOnline(!isOnline);
                  showToast(isOnline ? 'Store switched to OFFLINE' : 'Store is LIVE for incoming orders!');
                }}
                className={`px-2.5 py-1 rounded-full text-[10px] font-black transition-all border ${
                  isOnline
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                }`}
              >
                {isOnline ? '● OPEN' : '○ CLOSED'}
              </button>

              <button
                onClick={() => setIsQrModalOpen(true)}
                className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center text-slate-300 hover:text-white"
                title="Counter UPI QR"
              >
                <QrCode className="w-4 h-4 text-amber-400" />
              </button>

              <button
                onClick={() => setIsAddModalOpen(true)}
                className="w-7 h-7 rounded-lg bg-emerald-500 flex items-center justify-center text-slate-800 font-bold hover:bg-emerald-400 shadow-md"
                title="Add SKU"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </header>

          {/* Quick Store Switcher Pill Carousel */}
          <div className="px-3 py-1.5 bg-slate-900/60 border-b border-slate-800/80 overflow-x-auto flex gap-1.5 text-[10px] no-scrollbar">
            {sellers.map((s) => (
              <button
                key={s.id}
                onClick={() => setActiveSellerId(s.id)}
                className={`px-2.5 py-1 rounded-full whitespace-nowrap font-semibold transition-all ${
                  s.id === currentSeller?.id
                    ? 'bg-amber-500 text-slate-800 font-bold shadow-xs'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {s.storeName?.split(' ')?.[0] || s.storeName || 'Store'} ({s.category})
              </button>
            ))}
          </div>

          {/* Screen Body with Tab Views */}
          <main className="flex-1 overflow-y-auto p-3 space-y-3.5 pb-20">
            {/* TAB 1: PULSE / DASHBOARD */}
            {androidTab === 'pulse' && (
              <div className="space-y-3">
                {/* Real-time Sales Card */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-850 to-emerald-950/40 border border-emerald-500/30 shadow-lg">
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                    <span>Today's Total GMV Sales</span>
                    <span className="text-emerald-400 font-bold flex items-center gap-1">
                      <ArrowUpRight className="w-3.5 h-3.5" /> +24.8%
                    </span>
                  </div>
                  <div className="text-2xl font-black text-white font-mono">
                    ₹38,450<span className="text-xs text-slate-400 font-normal">.00</span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-slate-800 text-center text-xs">
                    <div className="bg-slate-900/80 p-2 rounded-xl border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Orders</span>
                      <span className="font-bold text-amber-400">{sellerOrders.length || 14}</span>
                    </div>
                    <div className="bg-slate-900/80 p-2 rounded-xl border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Pending</span>
                      <span className="font-bold text-orange-400">{pendingOrders.length || 3}</span>
                    </div>
                    <div className="bg-slate-900/80 p-2 rounded-xl border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Active SKUs</span>
                      <span className="font-bold text-emerald-400">{sellerProducts.length}</span>
                    </div>
                  </div>
                </div>

                {/* Live Order Incoming Alert Banner */}
                {pendingOrders.length > 0 && (
                  <div className="p-3 bg-amber-500/10 border-2 border-amber-500/40 rounded-2xl flex items-center justify-between gap-3 shadow-md">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-amber-500 text-slate-800 flex items-center justify-center font-bold animate-bounce">
                        🔔
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-white">
                          {pendingOrders.length} Orders Awaiting Rider Dispatch
                        </h4>
                        <p className="text-[10px] text-amber-300">Ready for instant Indore bike pickup</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setAndroidTab('orders')}
                      className="px-2.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-800 text-[10px] font-bold rounded-lg shadow-sm"
                    >
                      Dispatch →
                    </button>
                  </div>
                )}

                {/* Hyperlocal Active Drivers Radar */}
                <div className="p-3.5 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Truck className="w-3.5 h-3.5 text-emerald-400" />
                      Nearest Hyperlocal Delivery Riders
                    </h3>
                    <span className="text-[10px] font-bold text-emerald-400">
                      {nearbyDrivers.filter((d) => d.isOnline).length} Riders Online
                    </span>
                  </div>

                  <div className="space-y-1.5">
                    {nearbyDrivers.slice(0, 3).map((drv) => (
                      <div
                        key={drv.id}
                        className="p-2 bg-white border border-slate-800/80 rounded-xl flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <img
                            src={drv.avatar}
                            alt={drv.name}
                            className="w-7 h-7 rounded-full object-cover border border-emerald-500"
                          />
                          <div>
                            <div className="font-bold text-white text-[11px]">{drv.name}</div>
                            <div className="text-[9px] text-slate-400">
                              {drv.vehicleType} &bull; {drv.vehicleNumber}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] font-bold text-emerald-400 block">
                            📍 {drv.distanceKm.toFixed(1)} km away
                          </span>
                          <span className="text-[9px] text-amber-300">⭐ {drv.rating}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Quick 1-Tap SKU Creation Actions */}
                <div className="p-3.5 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Plus className="w-3.5 h-3.5 text-amber-400" />
                      Quick 1-Tap Catalog Presets
                    </h3>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[10px]">
                    <button
                      onClick={() =>
                        handleQuickPreset({
                          name: 'Havells 32A MCB Board',
                          cat: 'electrical',
                          price: 1650,
                          mrp: 2400,
                          img: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=600&auto=format&fit=crop&q=80',
                        })
                      }
                      className="p-2 bg-white border border-slate-800 rounded-xl text-left hover:border-amber-400 transition-colors"
                    >
                      <span className="font-bold text-white block">⚡ MCB Switch Board</span>
                      <span className="text-amber-400 font-bold">₹1,650</span>
                    </button>

                    <button
                      onClick={() =>
                        handleQuickPreset({
                          name: 'Luxe Velvet Matte Lipstick',
                          cat: 'cosmetics',
                          price: 799,
                          mrp: 1299,
                          img: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=600&auto=format&fit=crop&q=80',
                        })
                      }
                      className="p-2 bg-white border border-slate-800 rounded-xl text-left hover:border-amber-400 transition-colors"
                    >
                      <span className="font-bold text-white block">💄 Matte Lipstick</span>
                      <span className="text-amber-400 font-bold">₹799</span>
                    </button>

                    <button
                      onClick={() =>
                        handleQuickPreset({
                          name: 'Sheesham Solid Study Desk',
                          cat: 'furniture',
                          price: 8999,
                          mrp: 14999,
                          img: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=600&auto=format&fit=crop&q=80',
                        })
                      }
                      className="p-2 bg-white border border-slate-800 rounded-xl text-left hover:border-amber-400 transition-colors"
                    >
                      <span className="font-bold text-white block">🪑 Solid Wood Desk</span>
                      <span className="text-amber-400 font-bold">₹8,999</span>
                    </button>

                    <button
                      onClick={() =>
                        handleQuickPreset({
                          name: 'Chanderi Silk Handloom Kurta',
                          cat: 'ethnic-wear',
                          price: 2499,
                          mrp: 4299,
                          img: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&auto=format&fit=crop&q=80',
                        })
                      }
                      className="p-2 bg-white border border-slate-800 rounded-xl text-left hover:border-amber-400 transition-colors"
                    >
                      <span className="font-bold text-white block">👕 Chanderi Silk Kurta</span>
                      <span className="text-amber-400 font-bold">₹2,499</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: PRODUCTS & INVENTORY */}
            {androidTab === 'catalog' && (
              <div className="space-y-3">
                {/* Search Bar & Barcode Scanner Button */}
                <div className="flex gap-2">
                  <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 flex items-center gap-2 text-xs">
                    <Search className="w-3.5 h-3.5 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Search store inventory..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full bg-transparent text-white focus:outline-none text-xs"
                    />
                  </div>
                  <button
                    onClick={() => setIsScannerOpen(true)}
                    className="p-2 bg-slate-900 border border-slate-800 rounded-xl text-amber-400 hover:text-white flex items-center justify-center"
                    title="Scan Barcode"
                  >
                    <Camera className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setIsAddModalOpen(true)}
                    className="px-3 py-2 bg-emerald-500 text-slate-800 rounded-xl font-bold text-xs flex items-center gap-1 shadow-md"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </div>

                {/* Category Filter Chips */}
                <div className="flex gap-1.5 overflow-x-auto pb-1 text-[10px] no-scrollbar">
                  {['all', 'electrical', 'cosmetics', 'furniture', 'ethnic-wear', 'commercial-hardware'].map((c) => (
                    <button
                      key={c}
                      onClick={() => setSelectedCategoryFilter(c)}
                      className={`px-2.5 py-1 rounded-full font-bold uppercase whitespace-nowrap transition-all ${
                        selectedCategoryFilter === c
                          ? 'bg-amber-500 text-slate-800'
                          : 'bg-slate-900 text-slate-400 border border-slate-800'
                      }`}
                    >
                      {c === 'all' ? 'All Items' : c}
                    </button>
                  ))}
                </div>

                {/* Products List */}
                <div className="space-y-2">
                  {filteredProducts.map((prod) => (
                    <div
                      key={prod.id}
                      className="p-3 bg-slate-900/90 border border-slate-800 rounded-2xl flex items-center justify-between gap-3 shadow-sm"
                    >
                      <div className="flex items-center gap-2.5">
                        <img
                          src={prod.images?.[0] || 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=600&auto=format&fit=crop&q=80'}
                          alt={prod.name}
                          className="w-12 h-12 rounded-xl object-cover border border-slate-700 shrink-0"
                        />
                        <div>
                          <h4 className="font-bold text-white text-xs line-clamp-1">{prod.name}</h4>
                          <span className="text-[10px] text-slate-400 capitalize">{prod.category}</span>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-xs font-black text-amber-400">₹{prod.price.toLocaleString('en-IN')}</span>
                            <span className="text-[10px] text-slate-500 line-through">₹{prod.mrp}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col items-end gap-1.5">
                        {/* Stock status pill */}
                        <span
                          className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                            (prod.stock || 0) > 0
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {(prod.stock || 0) > 0 ? `${prod.stock} in stock` : 'Out of Stock'}
                        </span>

                        <div className="flex gap-1">
                          <button
                            onClick={() => {
                              const newStk = (prod.stock || 0) > 0 ? 0 : 50;
                              updateSellerInventory(prod.id, newStk);
                              showToast(`Updated stock to ${newStk}`);
                            }}
                            className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] rounded-lg font-semibold border border-slate-700"
                          >
                            {(prod.stock || 0) > 0 ? 'Mark OOS' : 'Restock'}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 3: ORDERS & DISPATCH */}
            {androidTab === 'orders' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <h3 className="font-bold text-white flex items-center gap-1.5">
                    <ShoppingBag className="w-3.5 h-3.5 text-amber-400" />
                    Incoming Orders & Dispatch
                  </h3>
                  <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-500/20 text-amber-300 rounded-lg">
                    {sellerOrders.length} Total
                  </span>
                </div>

                <div className="space-y-2.5">
                  {sellerOrders.map((ord) => (
                    <div
                      key={ord.id}
                      className="p-3 bg-slate-900 border border-slate-800 rounded-2xl space-y-2 shadow-sm"
                    >
                      <div className="flex items-center justify-between text-xs border-b border-slate-800/80 pb-2">
                        <div>
                          <span className="font-mono font-bold text-white">{ord.orderNumber}</span>
                          <p className="text-[10px] text-slate-400">{ord.shippingAddress.fullName} &bull; {ord.shippingAddress.city}</p>
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            ord.status === 'Delivered'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : ord.status === 'Out for delivery'
                              ? 'bg-teal-500/20 text-teal-300'
                              : 'bg-amber-500/20 text-amber-300 animate-pulse'
                          }`}
                        >
                          {ord.status}
                        </span>
                      </div>

                      <div className="text-[11px] text-slate-300">
                        {ord.items.map((item, idx) => (
                          <div key={idx} className="flex justify-between py-0.5">
                            <span className="line-clamp-1">{item.quantity}x {item.productName}</span>
                            <span className="font-mono text-amber-400 font-bold">₹{item.price * item.quantity}</span>
                          </div>
                        ))}
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                        <span className="font-bold text-emerald-400 font-mono">
                          Total: ₹{ord.totalAmount.toLocaleString('en-IN')}
                        </span>

                        <div className="flex gap-1.5">
                          <button
                            onClick={() => viewOrderInvoice(ord)}
                            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] rounded-lg font-semibold"
                          >
                            Invoice
                          </button>

                          {ord.status !== 'Delivered' && (
                            <button
                              onClick={() => {
                                setSelectedOrderForDriver(ord);
                                setIsAssignModalOpen(true);
                              }}
                              className="px-3 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-800 text-[10px] font-bold rounded-lg shadow-sm flex items-center gap-1"
                            >
                              <Truck className="w-3 h-3" />
                              <span>Assign Rider</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 4: WALLET & SETTLEMENTS */}
            {androidTab === 'wallet' && (
              <div className="space-y-3">
                <div className="p-4 bg-gradient-to-br from-emerald-900/40 via-slate-900 to-slate-950 border border-emerald-500/40 rounded-2xl space-y-3 shadow-lg">
                  <div className="flex items-center justify-between text-xs text-slate-300">
                    <span className="flex items-center gap-1.5">
                      <Wallet className="w-4 h-4 text-amber-400" />
                      Available Store Balance
                    </span>
                    <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-[10px] font-bold rounded">
                      Instant IMPS ⚡
                    </span>
                  </div>

                  <div className="text-3xl font-black text-amber-400 font-mono">
                    ₹{currentSeller.balanceAvailable.toLocaleString('en-IN')}
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <label className="text-[10px] text-slate-400 block font-semibold">
                      Instant Payout Amount (INR ₹):
                    </label>
                    <input
                      type="number"
                      value={payoutInput}
                      onChange={(e) => setPayoutInput(Number(e.target.value))}
                      max={currentSeller.balanceAvailable}
                      className="w-full bg-white border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono font-bold"
                    />

                    <div className="flex gap-1.5 text-[10px]">
                      {[10000, 25000, currentSeller.balanceAvailable].map((amt, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setPayoutInput(amt)}
                          className="px-2 py-1 bg-slate-800 text-slate-300 rounded-lg font-medium"
                        >
                          ₹{amt.toLocaleString('en-IN')}
                        </button>
                      ))}
                    </div>

                    <button
                      onClick={handleRequestPayout}
                      disabled={isPayingOut || currentSeller.balanceAvailable <= 0}
                      className="w-full py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-800 font-black rounded-xl text-xs transition-all shadow-md mt-2 disabled:opacity-50"
                    >
                      {isPayingOut ? 'Transferring...' : 'Transfer to Verified Bank Account ➔'}
                    </button>
                  </div>
                </div>

                {/* Recent Payouts */}
                <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-2xl space-y-2">
                  <h4 className="text-xs font-bold text-white">Recent Bank Settlements</h4>
                  <div className="space-y-1.5 text-[11px]">
                    {sellerPayouts.slice(0, 3).map((pay) => (
                      <div
                        key={pay.id}
                        className="p-2 bg-white rounded-xl border border-slate-800 flex items-center justify-between"
                      >
                        <div>
                          <span className="font-bold text-white">₹{pay.amount.toLocaleString('en-IN')}</span>
                          <p className="text-[9px] text-slate-400 font-mono">UTR: {pay.utrNumber}</p>
                        </div>
                        <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-300">
                          {pay.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 5: STORE PROFILE */}
            {androidTab === 'store' && (
              <div className="space-y-3">
                <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-amber-500 text-slate-800 flex items-center justify-center font-black text-xl shadow-lg">
                      🏪
                    </div>
                    <div>
                      <h3 className="font-black text-sm text-white">{currentSeller.storeName}</h3>
                      <p className="text-[10px] text-slate-400">{currentSeller.ownerName} &bull; {currentSeller.email}</p>
                      <span className="text-[9px] font-bold px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded mt-1 inline-block">
                        {currentSeller.badge || 'Verified Merchant ⭐'}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2 text-xs divide-y divide-slate-800 pt-2">
                    <div className="pt-2 flex justify-between">
                      <span className="text-slate-400">Business Category:</span>
                      <span className="font-bold text-white capitalize">{currentSeller.category}</span>
                    </div>
                    <div className="pt-2 flex justify-between">
                      <span className="text-slate-400">Hyperlocal Delivery Radius:</span>
                      <span className="font-bold text-emerald-400">{currentSeller.deliveryRadiusKm} km</span>
                    </div>
                    <div className="pt-2 flex justify-between">
                      <span className="text-slate-400">Warehouse City:</span>
                      <span className="font-bold text-white">{currentSeller.warehouseAddress?.city || 'Indore'}</span>
                    </div>
                    <div className="pt-2 flex justify-between">
                      <span className="text-slate-400">GSTIN Tax Registration:</span>
                      <span className="font-mono text-slate-300 text-[11px]">{currentSeller.gstNumber}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </main>

          {/* Android Material 3 Bottom Navigation Bar */}
          <nav className="absolute bottom-0 inset-x-0 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 px-3 py-2 flex items-center justify-around z-30">
            <button
              onClick={() => setAndroidTab('pulse')}
              className={`flex flex-col items-center gap-1 transition-all ${
                androidTab === 'pulse' ? 'text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span className="text-[10px]">Pulse</span>
            </button>

            <button
              onClick={() => setAndroidTab('catalog')}
              className={`flex flex-col items-center gap-1 transition-all ${
                androidTab === 'catalog' ? 'text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Package className="w-4 h-4" />
              <span className="text-[10px]">Catalog</span>
            </button>

            <button
              onClick={() => setAndroidTab('orders')}
              className={`flex flex-col items-center gap-1 relative transition-all ${
                androidTab === 'orders' ? 'text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="text-[10px]">Orders</span>
              {pendingOrders.length > 0 && (
                <span className="absolute -top-1 -right-2 w-4 h-4 rounded-full bg-amber-500 text-slate-800 font-black text-[9px] flex items-center justify-center animate-pulse">
                  {pendingOrders.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setAndroidTab('wallet')}
              className={`flex flex-col items-center gap-1 transition-all ${
                androidTab === 'wallet' ? 'text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Wallet className="w-4 h-4" />
              <span className="text-[10px]">Wallet</span>
            </button>

            <button
              onClick={() => setAndroidTab('store')}
              className={`flex flex-col items-center gap-1 transition-all ${
                androidTab === 'store' ? 'text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Store className="w-4 h-4" />
              <span className="text-[10px]">Store</span>
            </button>
          </nav>

          {/* ADD PRODUCT MODAL (Android Bottom Sheet) */}
          {isAddModalOpen && (
            <div className="absolute inset-0 bg-slate-100/80 backdrop-blur-sm z-40 flex items-end">
              <div className="w-full max-h-[85%] bg-slate-900 border-t-2 border-emerald-500 rounded-t-3xl p-4 overflow-y-auto space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <Plus className="w-4 h-4 text-emerald-400" />
                    <h3 className="font-bold text-white text-xs">Add Product to {currentSeller.storeName}</h3>
                  </div>
                  <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-white">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <form onSubmit={handleCreateProduct} className="space-y-3 text-xs">
                  <div>
                    <label className="text-slate-300 block mb-1 font-semibold">Title / Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Havells MCB Switch / Matte Lipstick / Sheesham Desk"
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      className="w-full bg-white border border-slate-700 rounded-xl px-3 py-2 text-white"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-slate-300 block mb-1 font-semibold">Category</label>
                      <select
                        value={newCat}
                        onChange={(e) => setNewCat(e.target.value)}
                        className="w-full bg-white border border-slate-700 rounded-xl px-2 py-2 text-white text-xs"
                      >
                        <option value="electrical">⚡ Electrical</option>
                        <option value="cosmetics">💄 Cosmetics</option>
                        <option value="furniture">🪑 Furniture</option>
                        <option value="ethnic-wear">👕 Cloths</option>
                        <option value="commercial-hardware">🛠️ Commercial</option>
                        <option value="gadgets">📱 Electronics</option>
                        <option value="custom">➕ Custom</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-semibold">Stock Units</label>
                      <input
                        type="number"
                        min={1}
                        value={newStock}
                        onChange={(e) => setNewStock(Number(e.target.value))}
                        className="w-full bg-white border border-slate-700 rounded-xl px-3 py-2 text-emerald-400 font-bold"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-slate-300 block mb-1 font-semibold">Price (₹)</label>
                      <input
                        type="number"
                        required
                        min={1}
                        value={newPrice}
                        onChange={(e) => setNewPrice(Number(e.target.value))}
                        className="w-full bg-white border border-slate-700 rounded-xl px-3 py-2 text-amber-400 font-bold"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-semibold">MRP (₹)</label>
                      <input
                        type="number"
                        required
                        min={1}
                        value={newMrp}
                        onChange={(e) => setNewMrp(Number(e.target.value))}
                        className="w-full bg-white border border-slate-700 rounded-xl px-3 py-2 text-slate-300"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-slate-300 block mb-1 font-semibold">Image URL (Optional)</label>
                    <input
                      type="url"
                      placeholder="https://images.unsplash.com/..."
                      value={newImage}
                      onChange={(e) => setNewImage(e.target.value)}
                      className="w-full bg-white border border-slate-700 rounded-xl px-3 py-2 text-white"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 text-slate-800 font-black rounded-xl text-xs shadow-md mt-2"
                  >
                    Publish to Live App ➔
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* COUNTER QR CODE MODAL */}
          {isQrModalOpen && (
            <div className="absolute inset-0 bg-slate-100/80 backdrop-blur-sm z-40 flex items-center justify-center p-4">
              <div className="w-full max-w-xs bg-slate-900 border border-slate-700 rounded-3xl p-5 text-center space-y-3">
                <h3 className="font-bold text-white text-sm">Store Counter UPI QR</h3>
                <p className="text-[10px] text-slate-400">
                  Customers can scan this QR to pay directly into your merchant wallet with 0 gateway charge.
                </p>
                <div className="w-44 h-44 mx-auto bg-white p-3 rounded-2xl flex items-center justify-center shadow-inner">
                  <img
                    src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=upi://pay?pa=seller.antifly@hdfcbank&pn=AntiflySeller"
                    alt="Store QR"
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="text-[11px] font-mono text-emerald-400 font-bold">
                  UPI ID: seller.antifly@hdfcbank
                </div>
                <button
                  onClick={() => setIsQrModalOpen(false)}
                  className="w-full py-2 bg-slate-800 text-slate-200 rounded-xl text-xs font-semibold"
                >
                  Close
                </button>
              </div>
            </div>
          )}

          {/* ASSIGN RIDER MODAL */}
          {isAssignModalOpen && selectedOrderForDriver && (
            <div className="absolute inset-0 bg-slate-100/80 backdrop-blur-sm z-40 flex items-end">
              <div className="w-full bg-slate-900 border-t border-slate-700 rounded-t-3xl p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <h3 className="font-bold text-white text-xs">
                    Dispatch Order {selectedOrderForDriver.orderNumber}
                  </h3>
                  <button onClick={() => setIsAssignModalOpen(false)} className="text-slate-400 hover:text-white">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-[10px] text-slate-400">Select a verified nearby hyperlocal rider in Indore:</p>

                <div className="space-y-2 max-h-56 overflow-y-auto">
                  {nearbyDrivers.map((drv) => (
                    <div
                      key={drv.id}
                      className="p-2.5 bg-white border border-slate-800 rounded-xl flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <img src={drv.avatar} alt={drv.name} className="w-8 h-8 rounded-full border border-emerald-500" />
                        <div>
                          <div className="font-bold text-white text-xs">{drv.name}</div>
                          <div className="text-[10px] text-emerald-400 font-bold">📍 {drv.distanceKm.toFixed(1)} km &bull; ⭐ {drv.rating}</div>
                        </div>
                      </div>
                      <button
                        onClick={() => handleAssignDriver(drv.id)}
                        className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-bold text-xs rounded-lg shadow-sm"
                      >
                        Assign Rider
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
