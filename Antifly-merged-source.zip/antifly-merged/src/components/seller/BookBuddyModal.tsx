import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Phone,
  PhoneCall,
  PhoneOff,
  Navigation,
  MapPin,
  Bike,
  Package,
  Clock,
  CheckCircle2,
  AlertCircle,
  X,
  Radio,
  Sparkles,
  ShieldCheck,
  User,
  TrendingUp,
  Volume2,
  VolumeX,
  RefreshCw,
  ArrowRight,
  Truck,
  ExternalLink,
  DollarSign,
  IndianRupee,
  Wallet,
  CreditCard,
  Banknote,
  Receipt,
  Calculator,
} from 'lucide-react';
import { Order, DriverProfile } from '../../types';

interface BookBuddyModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedOrder?: Order | null;
}

export const BookBuddyModal: React.FC<BookBuddyModalProps> = ({
  isOpen,
  onClose,
  preselectedOrder,
}) => {
  const {
    currentSeller,
    drivers,
    orders,
    calculateDistanceKm,
    activeVentureBookingCall,
    initiateVentureBuddyBroadcast,
    cancelVentureBuddyBroadcast,
    acceptVentureBuddyCall,
    payDriverForBooking,
    ventureBookingHistory,
    showToast,
    formatPrice,
    setDeviceMode,
    adminDriverRateConfig,
    calculateDynamicDriverPayout,
  } = useApp();

  const [radiusKm, setRadiusKm] = useState<number>(5);
  const [venturePhoneNumber, setVenturePhoneNumber] = useState<string>(
    currentSeller.phone || '9425821388'
  );
  const [selectedOrderId, setSelectedOrderId] = useState<string>(
    preselectedOrder?.id || ''
  );
  const [customerName, setCustomerName] = useState<string>(
    preselectedOrder?.customerName || 'Harshita Sharma'
  );
  const [customerPhone, setCustomerPhone] = useState<string>(
    preselectedOrder?.customerPhone || '+91 98260 88771'
  );
  const [customerAddress, setCustomerAddress] = useState<string>(
    preselectedOrder?.shippingAddress
      ? `${preselectedOrder.shippingAddress.street}, ${preselectedOrder.shippingAddress.city}`
      : 'Bhawarkua Main Road, Near Tower Square, Indore'
  );
  const [parcelDesc, setParcelDesc] = useState<string>(
    preselectedOrder
      ? `${(preselectedOrder?.items || []).map((i) => i.productName).join(', ')} (${preselectedOrder?.items?.length || 0} items)`
      : 'Electronics & Fast-Delivery Package (1.5 kg)'
  );

  // Distance & Dynamic Rate Calculation State
  const [deliveryDistanceKm, setDeliveryDistanceKm] = useState<number>(3.0);
  const [ratePerKm, setRatePerKm] = useState<number>(adminDriverRateConfig?.ratePerKm || 15);
  const [basePickupFee, setBasePickupFee] = useState<number>(adminDriverRateConfig?.baseFare || 30);
  const [paymentMethod, setPaymentMethod] = useState<'VENTURE_WALLET' | 'DIRECT_UPI' | 'CASH_ON_PICKUP'>('VENTURE_WALLET');

  const [activeSubTab, setActiveSubTab] = useState<'broadcast' | 'history' | 'calculator'>('broadcast');
  const [isBroadcasting, setIsBroadcasting] = useState<boolean>(false);
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);

  // Sync state when admin changes config
  useEffect(() => {
    if (adminDriverRateConfig) {
      setRatePerKm(adminDriverRateConfig.ratePerKm);
      setBasePickupFee(adminDriverRateConfig.baseFare);
    }
  }, [adminDriverRateConfig]);

  // Dynamic calculated payout with seasonal surges
  const dynamicPayoutInfo = calculateDynamicDriverPayout(deliveryDistanceKm, {
    customSeason: adminDriverRateConfig.currentSeason,
  });
  const calculatedTotalFare = dynamicPayoutInfo.totalPayout;

  // Sync preselected order if changed
  useEffect(() => {
    if (preselectedOrder) {
      setSelectedOrderId(preselectedOrder.id);
      setCustomerName(preselectedOrder.customerName);
      setCustomerPhone(preselectedOrder.customerPhone || '+91 98260 88771');
      if (preselectedOrder.shippingAddress) {
        setCustomerAddress(
          `${preselectedOrder.shippingAddress.street}, ${preselectedOrder.shippingAddress.city}`
        );
      }
      setParcelDesc(
        `${(preselectedOrder?.items || []).map((i) => i.productName).join(', ')} (${preselectedOrder?.items?.length || 0} items)`
      );
      const dist = preselectedOrder.distanceKm || 3.0;
      setDeliveryDistanceKm(dist);
    }
  }, [preselectedOrder]);

  const sellerLat = currentSeller.lat || 22.7196;
  const sellerLng = currentSeller.lng || 75.8577;

  // Calculate distance for all online drivers
  const driversWithDistance = drivers.map((driver) => {
    const dist = calculateDistanceKm(
      driver.currentLat || sellerLat,
      driver.currentLng || sellerLng,
      sellerLat,
      sellerLng
    );
    return {
      ...driver,
      distanceToStore: dist,
      isWithinRadius: dist <= radiusKm,
    };
  }).sort((a, b) => a.distanceToStore - b.distanceToStore);

  const nearbyDrivers = driversWithDistance.filter((d) => d.isWithinRadius && d.isOnline);
  const otherDrivers = driversWithDistance.filter((d) => !d.isWithinRadius || !d.isOnline);

  const currentCall = activeVentureBookingCall;
  const isRinging = currentCall && currentCall.status === 'RINGING';
  const isAccepted = currentCall && currentCall.status === 'ACCEPTED';

  // Handle Order Selection from dropdown
  const handleOrderChange = (orderId: string) => {
    setSelectedOrderId(orderId);
    if (orderId === 'custom') {
      setCustomerName('Walk-in / Phone Customer');
      setCustomerPhone('+91 98260 55441');
      setCustomerAddress('Vijay Nagar, Indore');
      setParcelDesc('Direct Store Dispatch Parcel');
      setDeliveryDistanceKm(3.0);
    } else {
      const found = orders.find((o) => o.id === orderId);
      if (found) {
        setCustomerName(found.customerName);
        setCustomerPhone(found.customerPhone || '+91 98260 88771');
        if (found.shippingAddress) {
          setCustomerAddress(`${found.shippingAddress.street}, ${found.shippingAddress.city}`);
        }
        setParcelDesc(
          `${(found.items || []).map((i) => i.productName).join(', ')} (${found?.items?.length || 0} items)`
        );
        const dist = found.distanceKm || 3.5;
        setDeliveryDistanceKm(dist);
      }
    }
  };

  // Trigger Broadcast Ring to All Nearby Buddies with calculated distance fare
  const handleStartBroadcast = async () => {
    setIsBroadcasting(true);
    try {
      await initiateVentureBuddyBroadcast({
        orderId: selectedOrderId !== 'custom' ? selectedOrderId : undefined,
        customerName,
        customerPhone,
        customerAddress,
        parcelDescription: parcelDesc,
        estimatedFare: calculatedTotalFare,
        radiusKm,
        customVenturePhone: venturePhoneNumber,
        deliveryDistanceKm,
        ratePerKm,
        baseFee: basePickupFee,
        paymentMethod,
      });
    } catch (e) {
      console.error(e);
    } finally {
      setIsBroadcasting(false);
    }
  };

  // Simulate a specific buddy answering the call immediately
  const handleSimulateAnswer = async (driverId: string) => {
    if (!currentCall) return;
    await acceptVentureBuddyCall(currentCall.id, driverId);
  };

  // Process instant payout for booking
  const handleDirectPayDriver = async (bookingId: string) => {
    setIsProcessingPayment(true);
    try {
      await payDriverForBooking(bookingId, paymentMethod);
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessingPayment(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-white/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden font-sans text-white">
        
        {/* MODAL HEADER */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 flex items-center justify-between gap-3 text-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white text-amber-400 flex items-center justify-center font-black shadow-md">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white tracking-tight">
                  Book a Buddy & Direct Payment
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-white/80 text-amber-300 text-[10px] font-black uppercase tracking-wider">
                  ₹15/km Distance Rate
                </span>
              </div>
              <p className="text-xs text-amber-100 font-medium">
                Venture simultaneously calls buddies within 5km & pays direct fare based on km traveled
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex bg-white/40 p-1 rounded-xl border border-amber-400/30">
              <button
                onClick={() => setActiveSubTab('broadcast')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                  activeSubTab === 'broadcast'
                    ? 'bg-amber-400 text-slate-800 shadow-xs'
                    : 'text-amber-100 hover:text-white'
                }`}
              >
                🛵 Dispatch
              </button>
              <button
                onClick={() => setActiveSubTab('calculator')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                  activeSubTab === 'calculator'
                    ? 'bg-amber-400 text-slate-800 shadow-xs'
                    : 'text-amber-100 hover:text-white'
                }`}
              >
                🧮 Rate Card
              </button>
              <button
                onClick={() => setActiveSubTab('history')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                  activeSubTab === 'history'
                    ? 'bg-amber-400 text-slate-800 shadow-xs'
                    : 'text-amber-100 hover:text-white'
                }`}
              >
                📋 History
              </button>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/40 hover:bg-white text-white flex items-center justify-center transition-all cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* MODAL BODY */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          
          {/* SUBTAB 1: BROADCAST RADAR & DISPATCH */}
          {activeSubTab === 'broadcast' && (
            <div className="space-y-6">
              
              {/* LIVE RINGING BANNER IF CALL IS CURRENTLY ACTIVE */}
              {isRinging && (
                <div className="bg-gradient-to-r from-rose-950/80 via-amber-950/80 to-rose-950/80 border-2 border-rose-500/80 p-4 sm:p-5 rounded-2xl animate-pulse shadow-lg space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-rose-500 text-white flex items-center justify-center font-black animate-bounce">
                        <PhoneCall className="w-6 h-6" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-rose-400 animate-ping" />
                          <h3 className="text-sm sm:text-base font-black text-rose-200">
                            BROADCAST CALL IN PROGRESS...
                          </h3>
                        </div>
                        <p className="text-xs text-rose-300/90 font-medium">
                          Simultaneously calling <strong>{currentCall?.ringingDriverIds?.length || 0} nearby Buddies</strong> from Venture Caller ID: <strong className="text-white">+{currentCall.venturePhone}</strong>
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="text-right bg-white/60 px-3 py-1.5 rounded-xl border border-rose-500/40">
                        <span className="text-[10px] text-slate-400 font-bold uppercase block">Direct Payout</span>
                        <span className="text-sm font-black text-emerald-400 font-mono">
                          {formatPrice(currentCall.totalAmount || currentCall.estimatedFare)}
                        </span>
                      </div>

                      <button
                        onClick={() => cancelVentureBuddyBroadcast(currentCall.id)}
                        className="px-3.5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-md cursor-pointer"
                      >
                        <PhoneOff className="w-3.5 h-3.5" />
                        <span>Cancel Call</span>
                      </button>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-rose-800/50 flex flex-wrap items-center justify-between gap-2 text-xs text-rose-300">
                    <span>
                      🎯 <strong>First Buddy to answer</strong> gets this {currentCall.deliveryDistanceKm || 3}km trip and receives <strong>{formatPrice(currentCall.totalAmount || currentCall.estimatedFare)}</strong> directly from you ({currentSeller.storeName})!
                    </span>
                    <span className="text-amber-300 font-bold">
                      💡 Tip: Click any ringing Buddy below to test answering as that Buddy!
                    </span>
                  </div>
                </div>
              )}

              {/* ACCEPTED BANNER IF CALL WAS ACCEPTED */}
              {isAccepted && (
                <div className="bg-gradient-to-r from-emerald-950/90 via-teal-950/90 to-emerald-950/90 border-2 border-emerald-500/80 p-5 rounded-2xl shadow-xl space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-slate-800 flex items-center justify-center font-black">
                        <CheckCircle2 className="w-6 h-6" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded bg-emerald-500 text-slate-800 text-[10px] font-black">
                            CALL ACCEPTED
                          </span>
                          <h3 className="text-sm sm:text-base font-black text-emerald-200">
                            Buddy {currentCall.acceptedByDriverName} is En Route!
                          </h3>
                        </div>
                        <p className="text-xs text-emerald-300/90 mt-0.5">
                          Phone: <strong>{currentCall.acceptedByDriverPhone}</strong> &bull; ETA to Store: <strong className="text-white">~{currentCall.etaMinutes || 4} Minutes</strong> ({currentCall.acceptedByDriverDistanceKm} km away)
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          showToast(`📞 Dialing Buddy ${currentCall.acceptedByDriverName} at ${currentCall.acceptedByDriverPhone}...`);
                        }}
                        className="px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-800 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        <span>Call Buddy</span>
                      </button>
                      <button
                        onClick={() => {
                          onClose();
                          setDeviceMode('driver');
                          showToast('Switched to Buddy Portal view to see the live pickup route!');
                        }}
                        className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/40 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <span>View in Buddy App</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Payment Settlement Box */}
                  <div className="p-3.5 bg-slate-900/90 rounded-xl border border-emerald-500/40 flex flex-wrap items-center justify-between gap-3 text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-black text-amber-400">
                          💰 Payable Amount to Driver: {formatPrice(currentCall.totalAmount || currentCall.estimatedFare)}
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-black ${
                          currentCall.paymentStatus === 'PAID'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : currentCall.paymentStatus === 'SETTLED_ON_PICKUP'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                        }`}>
                          {currentCall.paymentStatus === 'PAID'
                            ? '✅ PAID VIA WALLET'
                            : currentCall.paymentStatus === 'SETTLED_ON_PICKUP'
                            ? '💵 CASH ON PICKUP'
                            : '⏳ PENDING SETTLEMENT'}
                        </span>
                      </div>
                      <p className="text-slate-300 text-[11px]">
                        Calculation: <strong>{currentCall.deliveryDistanceKm || 3} km</strong> × <strong>₹{currentCall.ratePerKm || 15}/km</strong> = <strong>₹{currentCall.totalAmount || currentCall.estimatedFare}</strong>
                        {currentCall.paymentUtr && ` • Ref: ${currentCall.paymentUtr}`}
                      </p>
                    </div>

                    {currentCall.paymentStatus !== 'PAID' && (
                      <button
                        onClick={() => handleDirectPayDriver(currentCall.id)}
                        disabled={isProcessingPayment}
                        className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-800 font-black rounded-xl text-xs transition-all shadow-md flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        <Wallet className="w-3.5 h-3.5" />
                        <span>{isProcessingPayment ? 'Processing...' : `Pay Driver ${formatPrice(currentCall.totalAmount || currentCall.estimatedFare)} Now`}</span>
                      </button>
                    )}
                  </div>

                  <div className="p-3 bg-slate-900/80 rounded-xl border border-emerald-500/30 grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                    <div>
                      <span className="text-slate-400 block">Pickup Security OTP:</span>
                      <span className="font-mono text-base font-black text-amber-400">{currentCall.pickupOtp || '4829'}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Pickup Store Address:</span>
                      <span className="text-slate-200 font-medium truncate block">{currentCall.ventureStoreAddress}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Customer Destination:</span>
                      <span className="text-slate-200 font-medium truncate block">{currentCall.customerAddress}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* 2-COLUMN GRID: DISPATCH SETTINGS & 5KM RADAR BUDDIES */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* LEFT: BOOKING DETAILS & PARCEL CONFIG (5 Cols) */}
                <div className="lg:col-span-5 space-y-4">
                  <div className="bg-slate-800/90 border border-slate-700 p-4 sm:p-5 rounded-2xl space-y-4">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Package className="w-4 h-4 text-amber-400" />
                      1. Venture Caller ID & Parcel Info
                    </h3>

                    {/* Venture Phone Number (Caller ID) */}
                    <div>
                      <label className="text-xs font-semibold text-amber-300 block mb-1">
                        Venture Caller Phone Number (Appears on Drivers' Screens) *
                      </label>
                      <div className="relative">
                        <Phone className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                        <input
                          type="text"
                          value={venturePhoneNumber}
                          onChange={(e) => setVenturePhoneNumber(e.target.value)}
                          placeholder="e.g. 9425821388"
                          className="w-full bg-slate-900 border border-amber-500/50 rounded-xl pl-9 pr-3 py-2 text-sm text-white font-mono font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
                        />
                      </div>
                      <span className="text-[10px] text-slate-400 mt-1 block">
                        When broadcasting, all nearby buddies will see: <strong>"Incoming Call from {currentSeller.storeName} (+91 {venturePhoneNumber})"</strong>
                      </span>
                    </div>

                    {/* Order Selection */}
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">
                        Select Order / Parcel to Dispatch:
                      </label>
                      <select
                        value={selectedOrderId}
                        onChange={(e) => handleOrderChange(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                      >
                        <option value="custom">📦 Custom Parcel / Walk-in Customer Package</option>
                        {orders.map((ord) => (
                          <option key={ord.id} value={ord.id}>
                            Order #{ord.orderNumber} - {ord.customerName} ({ord.distanceKm || 3} km - ₹{ord.totalAmount})
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Customer Drop Address */}
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">
                        Customer Drop Address & Phone:
                      </label>
                      <div className="space-y-2">
                        <input
                          type="text"
                          value={customerName}
                          onChange={(e) => setCustomerName(e.target.value)}
                          placeholder="Customer Name"
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white"
                        />
                        <input
                          type="text"
                          value={customerPhone}
                          onChange={(e) => setCustomerPhone(e.target.value)}
                          placeholder="Customer Phone"
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white"
                        />
                        <textarea
                          rows={2}
                          value={customerAddress}
                          onChange={(e) => setCustomerAddress(e.target.value)}
                          placeholder="Drop location details..."
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white"
                        />
                      </div>
                    </div>

                    {/* DYNAMIC DISTANCE-BASED CALCULATION ($15/KM) */}
                    <div className="p-3.5 bg-white/80 rounded-2xl border border-amber-500/40 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                          <Calculator className="w-3.5 h-3.5 text-amber-400" />
                          <span>Distance-Based Payout to Driver</span>
                        </span>
                        <span className="text-[11px] font-extrabold text-slate-400">
                          Formula: Distance × Rate
                        </span>
                      </div>

                      {/* Distance Slider & Input */}
                      <div>
                        <div className="flex items-center justify-between text-xs font-bold text-slate-300 mb-1">
                          <span>Delivery Distance:</span>
                          <span className="text-amber-400 font-mono text-sm">{deliveryDistanceKm} Kilometers</span>
                        </div>
                        <input
                          type="range"
                          min={1}
                          max={15}
                          step={0.5}
                          value={deliveryDistanceKm}
                          onChange={(e) => setDeliveryDistanceKm(Number(e.target.value))}
                          className="w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
                        />
                        <div className="flex justify-between text-[10px] text-slate-500 font-bold mt-1">
                          <span>1 km (₹{1 * ratePerKm})</span>
                          <span>2 km (₹{2 * ratePerKm})</span>
                          <span>3 km (₹{3 * ratePerKm})</span>
                          <span>4 km (₹{4 * ratePerKm})</span>
                          <span>5 km (₹{5 * ratePerKm})</span>
                        </div>
                      </div>

                      {/* Rate per Km selector */}
                      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
                        <div>
                          <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                            Rate per Km (₹ / $)
                          </label>
                          <select
                            value={ratePerKm}
                            onChange={(e) => setRatePerKm(Number(e.target.value))}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white font-bold"
                          >
                            <option value={10}>₹10 / km</option>
                            <option value={15}>₹15 / km (Standard)</option>
                            <option value={20}>₹20 / km (Priority)</option>
                            <option value={25}>₹25 / km (Express)</option>
                          </select>
                        </div>

                        <div>
                          <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                            Radar Radius
                          </label>
                          <select
                            value={radiusKm}
                            onChange={(e) => setRadiusKm(Number(e.target.value))}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-amber-300 font-bold"
                          >
                            <option value={2}>2 Km Radius</option>
                            <option value={5}>5 Km (Standard 5km)</option>
                            <option value={10}>10 Km (Citywide)</option>
                          </select>
                        </div>
                      </div>

                      {/* Payment Method Selector */}
                      <div>
                        <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                          How Venture Will Pay Driver:
                        </label>
                        <div className="grid grid-cols-3 gap-1.5 text-[11px]">
                          <button
                            type="button"
                            onClick={() => setPaymentMethod('VENTURE_WALLET')}
                            className={`p-2 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                              paymentMethod === 'VENTURE_WALLET'
                                ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                                : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                            }`}
                          >
                            <Wallet className="w-3.5 h-3.5 mx-auto mb-0.5 text-amber-400" />
                            <span>Venture Wallet</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => setPaymentMethod('DIRECT_UPI')}
                            className={`p-2 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                              paymentMethod === 'DIRECT_UPI'
                                ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                                : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                            }`}
                          >
                            <CreditCard className="w-3.5 h-3.5 mx-auto mb-0.5 text-blue-400" />
                            <span>Instant UPI</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => setPaymentMethod('CASH_ON_PICKUP')}
                            className={`p-2 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                              paymentMethod === 'CASH_ON_PICKUP'
                                ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                                : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                            }`}
                          >
                            <Banknote className="w-3.5 h-3.5 mx-auto mb-0.5 text-emerald-400" />
                            <span>Cash on Pickup</span>
                          </button>
                        </div>
                      </div>

                      {/* LIVE BREAKDOWN RESULT WITH SEASONAL PRICING */}
                      <div className="p-3.5 bg-gradient-to-r from-emerald-950/80 to-teal-950/80 rounded-xl border border-emerald-500/40 space-y-2">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="text-[10px] text-emerald-300 font-bold uppercase block">
                              Total Payable by Venture to Driver:
                            </span>
                            <span className="text-xs text-slate-300">
                              Base ₹{dynamicPayoutInfo.baseFare} + ({deliveryDistanceKm}km × ₹{dynamicPayoutInfo.ratePerKm}/km)
                              {dynamicPayoutInfo.seasonalSurge > 0 && ` + ${dynamicPayoutInfo.seasonApplied} Surge ₹${dynamicPayoutInfo.seasonalSurge}`}
                            </span>
                          </div>
                          <span className="text-xl font-black text-emerald-400 font-mono">
                            ₹{calculatedTotalFare}
                          </span>
                        </div>

                        {dynamicPayoutInfo.seasonalSurge > 0 && (
                          <div className="px-2 py-1 bg-amber-500/20 rounded-lg text-[11px] font-bold text-amber-300 flex items-center justify-between border border-amber-500/30">
                            <span>
                              {dynamicPayoutInfo.seasonApplied === 'RAINY' ? '🌧️ Monsoon Hazard Surge Active' : '☀️ Summer Heat Allowance Active'}
                            </span>
                            <span>+₹{dynamicPayoutInfo.seasonalSurge}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* BIG BROADCAST CALL BUTTON */}
                    <button
                      onClick={handleStartBroadcast}
                      disabled={isBroadcasting || isRinging}
                      className="w-full bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 text-slate-800 font-black py-3.5 rounded-2xl text-sm transition-all shadow-xl flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
                    >
                      <PhoneCall className="w-5 h-5 animate-bounce" />
                      <span>
                        {isRinging
                          ? 'Ringing Buddies in Progress...'
                          : `🚨 Ring & Call All Buddies in ${radiusKm}km (Pay ₹${calculatedTotalFare})`}
                      </span>
                    </button>
                  </div>
                </div>

                {/* RIGHT: LIVE 5KM NEARBY BUDDY RADAR & SIMULTANEOUS STATUS (7 Cols) */}
                <div className="lg:col-span-7 space-y-4">
                  <div className="bg-slate-800/90 border border-slate-700 p-4 sm:p-5 rounded-2xl space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <h3 className="text-sm font-bold text-white flex items-center gap-2">
                          <Navigation className="w-4 h-4 text-emerald-400" />
                          2. Nearby Buddies within {radiusKm}km of {currentSeller.warehouseAddress?.city || 'Indore'}
                        </h3>
                        <p className="text-xs text-slate-400">
                          {nearbyDrivers.length} active delivery buddies ready to receive your call
                        </p>
                      </div>
                      <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold rounded-lg">
                        {nearbyDrivers.length} Online in {radiusKm}km
                      </span>
                    </div>

                    {/* BUDDIES LIST */}
                    <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
                      {nearbyDrivers.map((driver) => {
                        const isThisDriverRinging = isRinging && currentCall?.ringingDriverIds.includes(driver.id);
                        const isThisDriverAccepted = isAccepted && currentCall?.acceptedByDriverId === driver.id;

                        return (
                          <div
                            key={driver.id}
                            className={`p-3.5 rounded-2xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                              isThisDriverAccepted
                                ? 'bg-emerald-950/60 border-emerald-500 shadow-md'
                                : isThisDriverRinging
                                ? 'bg-amber-950/50 border-amber-500 animate-pulse shadow-lg'
                                : 'bg-slate-900/90 border-slate-700 hover:border-slate-600'
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <div className="relative">
                                <img
                                  src={driver.avatar}
                                  alt={driver.name}
                                  className="w-12 h-12 rounded-full object-cover border-2 border-emerald-500"
                                />
                                {isThisDriverRinging && (
                                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white rounded-full flex items-center justify-center text-[9px] font-bold animate-ping">
                                    📞
                                  </span>
                                )}
                              </div>
                              <div>
                                <div className="flex items-center gap-2">
                                  <h4 className="font-bold text-white text-sm">{driver.name}</h4>
                                  <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                                    ONLINE
                                  </span>
                                </div>
                                <p className="text-xs text-slate-400">
                                  {driver.vehicleType} &bull; {driver.vehicleNumber}
                                </p>
                                <div className="flex items-center gap-2 mt-0.5 text-xs">
                                  <span className="text-amber-300 font-semibold">⭐ {driver.rating}</span>
                                  <span className="text-slate-400 font-mono text-[11px]">{driver.phone}</span>
                                </div>
                              </div>
                            </div>

                            <div className="flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto gap-2">
                              <div className="text-left sm:text-right">
                                <span className="text-xs font-black text-emerald-400 block">
                                  📍 {driver.distanceToStore} km away
                                </span>
                                <span className="text-[10px] text-slate-400">
                                  ~{Math.round(driver.distanceToStore * 2.5 + 2)} mins to store
                                </span>
                              </div>

                              {isThisDriverRinging ? (
                                <button
                                  onClick={() => handleSimulateAnswer(driver.id)}
                                  className="px-3 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-800 text-xs font-black rounded-lg transition-all animate-bounce shadow-md flex items-center gap-1 cursor-pointer"
                                >
                                  <span>Answer as {driver.name?.split(' ')?.[0] || driver.name || 'Driver'} (Get ₹{calculatedTotalFare})</span>
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                </button>
                              ) : isThisDriverAccepted ? (
                                <span className="px-2.5 py-1 bg-emerald-500 text-slate-800 text-xs font-black rounded-lg flex items-center gap-1">
                                  <span>Accepted Call ✓</span>
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 text-[10px] font-medium border border-slate-700">
                                  Earning: ₹{calculatedTotalFare}
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })}

                      {nearbyDrivers.length === 0 && (
                        <div className="p-8 text-center bg-slate-900/50 rounded-2xl border border-dashed border-slate-700 text-slate-400">
                          <Bike className="w-8 h-8 mx-auto mb-2 text-slate-500" />
                          <p className="text-sm font-semibold">No buddies online within {radiusKm} km.</p>
                          <p className="text-xs text-slate-500 mt-1">
                            Try extending radius to 10 km to alert nearby drivers in surrounding sectors.
                          </p>
                        </div>
                      )}
                    </div>

                    {/* DRIVERS BEYOND 5KM */}
                    {otherDrivers.length > 0 && (
                      <div className="pt-3 border-t border-slate-800">
                        <span className="text-xs text-slate-500 font-semibold block mb-2">
                          Other Drivers in City (&gt; {radiusKm} km radius):
                        </span>
                        <div className="flex flex-wrap gap-2">
                          {otherDrivers.map((d) => (
                            <div
                              key={d.id}
                              className="px-2.5 py-1 bg-slate-900 rounded-lg border border-slate-800 text-[11px] text-slate-400 flex items-center gap-1.5"
                            >
                              <span>{d.name}</span>
                              <span className="text-slate-500">({d.distanceToStore} km)</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SUBTAB 2: DISTANCE RATE CARD & CALCULATION MATRIX */}
          {activeSubTab === 'calculator' && (
            <div className="space-y-6">
              <div className="bg-slate-800/80 border border-slate-700 p-5 rounded-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <Calculator className="w-5 h-5 text-amber-400" />
                      Distance-Based Venture to Driver Rate Card
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Transparent standard rate table: ₹15 per kilometer traveled by the Buddy
                    </p>
                  </div>
                  <span className="px-3 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-xl text-xs font-black">
                    Standard ₹15/km
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    { km: 1, fare: 15, label: '1 Kilometer' },
                    { km: 2, fare: 30, label: '2 Kilometers' },
                    { km: 3, fare: 45, label: '3 Kilometers' },
                    { km: 4, fare: 60, label: '4 Kilometers' },
                    { km: 5, fare: 75, label: '5 Kilometers' },
                    { km: 6, fare: 90, label: '6 Kilometers' },
                    { km: 8, fare: 120, label: '8 Kilometers' },
                    { km: 10, fare: 150, label: '10 Kilometers' },
                  ].map((tier) => (
                    <div
                      key={tier.km}
                      onClick={() => {
                        setDeliveryDistanceKm(tier.km);
                        setActiveSubTab('broadcast');
                        showToast(`Set distance to ${tier.km} km (₹${tier.fare}) for booking.`);
                      }}
                      className="p-4 bg-slate-900/90 hover:bg-amber-950/40 border border-slate-700 hover:border-amber-500/60 rounded-2xl transition-all cursor-pointer space-y-2 group"
                    >
                      <div className="flex items-center justify-between text-xs font-bold text-slate-400 group-hover:text-amber-300">
                        <span>{tier.label}</span>
                        <span>{tier.km} × ₹15</span>
                      </div>
                      <div className="text-2xl font-black text-emerald-400 font-mono">
                        ₹{tier.fare}
                      </div>
                      <div className="text-[10px] text-slate-500 group-hover:text-slate-300">
                        Click to quick-select {tier.km}km
                      </div>
                    </div>
                  ))}
                </div>

                {/* Rules Box */}
                <div className="p-4 bg-slate-900/80 rounded-2xl border border-slate-700 space-y-2 text-xs text-slate-300">
                  <h4 className="font-bold text-amber-300 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>How Payment is Handled:</span>
                  </h4>
                  <ul className="list-disc list-inside space-y-1 text-slate-300">
                    <li><strong>Venture Wallet Auto-Debit:</strong> Automatically deducted from your Venture seller balance and directly credited to the driver partner upon acceptance or dispatch.</li>
                    <li><strong>Instant UPI QR:</strong> Generates UPI intent so the venture can pay straight from PhonePe, GPay, or Paytm to driver's bank VPA.</li>
                    <li><strong>Cash on Pickup:</strong> Driver collects cash directly from the store counter upon arriving at the pickup location.</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* SUBTAB 3: BOOKING & PAYMENT HISTORY */}
          {activeSubTab === 'history' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-400" />
                  Recent Venture Buddy Booking & Driver Payment Logs
                </h3>
                <span className="text-xs text-slate-400">
                  {ventureBookingHistory.length} total call dispatches
                </span>
              </div>

              <div className="space-y-3">
                {ventureBookingHistory.map((call) => (
                  <div
                    key={call.id}
                    className="p-4 bg-slate-800/80 border border-slate-700 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white">{call.id}</span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            call.status === 'ACCEPTED'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : call.status === 'RINGING'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          }`}
                        >
                          {call.status}
                        </span>
                        <span className="text-slate-400">{call.initiatedAt}</span>
                      </div>
                      <p className="text-slate-300">
                        Caller ID: <strong>+{call.venturePhone}</strong> &bull; Distance: <strong>{call.deliveryDistanceKm || 3} km (@ ₹{call.ratePerKm || 15}/km)</strong>
                      </p>
                      <p className="text-slate-400 text-[11px]">
                        Drop: {call.customerAddress} ({call.customerName})
                      </p>
                      {call.paymentUtr && (
                        <p className="text-[10px] text-emerald-400 font-mono">
                          UTR: {call.paymentUtr} &bull; Mode: {call.paymentMethod || 'VENTURE_WALLET'}
                        </p>
                      )}
                    </div>

                    <div className="text-right space-y-1">
                      {call.acceptedByDriverName ? (
                        <div>
                          <span className="text-emerald-400 font-bold block">
                            Buddy: {call.acceptedByDriverName}
                          </span>
                          <span className="text-slate-400 text-[11px]">{call.acceptedByDriverPhone}</span>
                        </div>
                      ) : (
                        <span className="text-slate-500">
                          {call?.ringingDriverIds?.length || 0} Buddies Alerted (5km)
                        </span>
                      )}
                      <div className="font-bold text-amber-400">
                        Paid to Driver: {formatPrice(call.totalAmount || call.estimatedFare)}
                      </div>
                      {call.paymentStatus !== 'PAID' && call.acceptedByDriverId && (
                        <button
                          onClick={() => handleDirectPayDriver(call.id)}
                          className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-black rounded-lg text-[10px] transition-all cursor-pointer"
                        >
                          Pay Driver Now
                        </button>
                      )}
                    </div>
                  </div>
                ))}

                {ventureBookingHistory.length === 0 && (
                  <div className="p-8 text-center bg-slate-900/40 rounded-2xl border border-slate-800 text-slate-400">
                    <Radio className="w-8 h-8 mx-auto mb-2 text-slate-500" />
                    <p className="text-sm font-semibold">No booking calls recorded yet.</p>
                    <p className="text-xs text-slate-500 mt-1">
                      Click the "Dispatch" tab to initiate a 5km buddy ring!
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

        </div>

        {/* MODAL FOOTER */}
        <div className="p-4 bg-white border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Antifly Hyperlocal Buddy Network &bull; Automated 5km broadcast routing &bull; ₹15/km driver compensation</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold transition-all cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
