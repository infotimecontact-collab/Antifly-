import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Store,
  Package,
  TrendingUp,
  Wallet,
  AlertTriangle,
  Plus,
  Truck,
  CheckCircle,
  Clock,
  ArrowUpRight,
  RefreshCw,
  Search,
  ExternalLink,
  ShieldCheck,
  Building2,
  FileText,
  DollarSign,
  Barcode,
  Layers,
  ChevronRight,
  Filter,
  MapPin,
  Phone,
  Power,
  Trash2,
  Edit2,
  Gift,
  UserCheck,
  Send,
  Navigation,
  Sparkles,
  X,
  MessageSquare,
  Users,
  Tag,
  ThumbsUp,
  Check,
  XCircle,
  FileSpreadsheet,
  Video,
  Share2,
  Wrench,
  Zap,
  Radio,
  PhoneCall,
  PhoneOff,
  QrCode,
  Scan,
  Cpu,
} from 'lucide-react';
import { Product, SellerProfile, Order } from '../../types';
import { BulkProductUploadModal } from '../admin/BulkProductUploadModal';
import { BookBuddyModal } from './BookBuddyModal';
import { ProductInventoryQRModal } from '../common/ProductInventoryQRModal';

export const SellerCentralPortal: React.FC = () => {
  const [selectedQRProduct, setSelectedQRProduct] = useState<Product | null>(null);
  const [isQRModalOpen, setIsQRModalOpen] = useState(false);
  const {
    sellers,
    activeSellerId,
    setActiveSellerId,
    currentSeller,
    sellerPayouts,
    registerSeller,
    updateSellerProfile,
    toggleSellerStatus,
    deleteSellerAccount,
    deleteSellerAccountPermanently,
    registerRoleAccount,
    checkPhoneConflict,
    openAuthModalFor,
    addSellerProduct,
    updateSellerProduct,
    deleteSellerProduct,
    updateSellerInventory,
    requestSellerPayout,
    assignDriverToOrder,
    drivers,
    calculateDistanceKm,
    userLocation,
    products,
    orders,
    customers,
    formatPrice,
    t,
    showToast,
    viewOrderInvoice,
    updateDriverTaskStatus,
    driverTasks,
    storeCommunities,
    communityPosts,
    storeChatSessions,
    respondToBargainOffer,
    sendStoreChatMessage,
    createCommunityPost,
    likeCommunityPost,
    startSellerToCustomerChat,
    sellerFollowCustomer,
    toggleFollowSeller,
    isBookBuddyModalOpen,
    setIsBookBuddyModalOpen,
    activeVentureBookingCall,
    initiateVentureBuddyBroadcast,
    cancelVentureBuddyBroadcast,
    acceptVentureBuddyCall,
    isAutonomousZeroAdminOpen,
    setIsAutonomousZeroAdminOpen,
    autonomousConfig,
    instantVerifySellerKYC,
    instantReleaseSellerPayout,
  } = useApp();

  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'inventory' | 'orders' | 'dispatch-drivers' | 'book-buddy' | 'community-chat' | 'finance' | 'add-product' | 'account-settings'
  >('dashboard');
  const [selectedOrderForBuddy, setSelectedOrderForBuddy] = useState<Order | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [payoutAmountInput, setPayoutAmountInput] = useState<number>(50000);
  const [isRequestingPayout, setIsRequestingPayout] = useState(false);

  // Store Community Post creation state
  const [newPostTitle, setNewPostTitle] = useState('');
  const [newPostContent, setNewPostContent] = useState('');
  const [newPostTag, setNewPostTag] = useState('Flash Sale');
  const [newPostDiscount, setNewPostDiscount] = useState('20% Off');
  const [newPostMediaUrl, setNewPostMediaUrl] = useState('');
  const [newPostMediaType, setNewPostMediaType] = useState<'image' | 'video' | 'reel'>('image');
  const [isCreatingPost, setIsCreatingPost] = useState(false);

  // Bulk Product Upload Modal State
  const [isBulkUploadOpen, setIsBulkUploadOpen] = useState(false);

  // Service Provider Profile Settings State (for Electricians, Plumbers, Handymen)
  const [spEnabled, setSpEnabled] = useState<boolean>(currentSeller.isServiceProvider ?? false);
  const [spType, setSpType] = useState<string>(currentSeller.serviceType || 'electrician');
  const [spVisitFee, setSpVisitFee] = useState<number>(currentSeller.serviceVisitFee || 250);
  const [spHourlyRate, setSpHourlyRate] = useState<number>(currentSeller.serviceHourlyRate || 350);
  const [spEmergency, setSpEmergency] = useState<boolean>(currentSeller.serviceEmergencyAvailable ?? true);
  const [spRadius, setSpRadius] = useState<number>(currentSeller.deliveryRadiusKm || 15);
  const [isSavingSp, setIsSavingSp] = useState<boolean>(false);

  // Counter offer state
  const [counterPriceInput, setCounterPriceInput] = useState<Record<string, number>>({});
  const [counterNoteInput, setCounterNoteInput] = useState<Record<string, string>>({});

  // New Store Registration Modal State
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
  const [regStoreName, setRegStoreName] = useState('');
  const [regOwnerName, setRegOwnerName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regCategory, setRegCategory] = useState('electrical');
  const [regCustomCategory, setRegCustomCategory] = useState('');
  const [regCity, setRegCity] = useState('Indore');
  const [regStreet, setRegStreet] = useState('Maharani Road Electric Market');
  const [regGst, setRegGst] = useState('23AABCI9921K1Z5');
  const [regRadiusKm, setRegRadiusKm] = useState(20);
  const [isRegistering, setIsRegistering] = useState(false);

  // Edit Product Modal State
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [editPrice, setEditPrice] = useState<number>(0);
  const [editMrp, setEditMrp] = useState<number>(0);
  const [editStock, setEditStock] = useState<number>(0);
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [editIsWholesale, setEditIsWholesale] = useState(false);
  const [editMinOrderQuantity, setEditMinOrderQuantity] = useState(12);
  const [editWholesaleUnitPrice, setEditWholesaleUnitPrice] = useState(0);
  const [editIsDealership, setEditIsDealership] = useState(false);
  const [editIsSingleVendor, setEditIsSingleVendor] = useState(false);

  // New Product Form State
  const [newProdName, setNewProdName] = useState('');
  const [newProdCategory, setNewProdCategory] = useState('electrical');
  const [newProdCustomCategory, setNewProdCustomCategory] = useState('');
  const [newProdSubcategory, setNewProdSubcategory] = useState('');
  const [newProdPrice, setNewProdPrice] = useState<number>(1450);
  const [newProdMrp, setNewProdMrp] = useState<number>(2200);
  const [newProdStock, setNewProdStock] = useState<number>(50);
  const [newProdImage, setNewProdImage] = useState('');
  const [newProdDesc, setNewProdDesc] = useState('');
  const [newProdIsWholesale, setNewProdIsWholesale] = useState(false);
  const [newProdMinOrderQty, setNewProdMinOrderQty] = useState<number>(12);
  const [newProdWholesaleUnitPrice, setNewProdWholesaleUnitPrice] = useState<number>(0);
  const [newProdIsDealership, setNewProdIsDealership] = useState(false);
  const [newProdIsSingleVendor, setNewProdIsSingleVendor] = useState(false);
  const [isSubmittingProd, setIsSubmittingProd] = useState(false);

  // Store Registration Wholesale State
  const [regIsWholesaleSeller, setRegIsWholesaleSeller] = useState(false);
  const [regIsDealership, setRegIsDealership] = useState(false);
  const [regIsSingleVendor, setRegIsSingleVendor] = useState(false);

  // Selected Order for Driver Assignment
  const [selectedOrderToAssign, setSelectedOrderToAssign] = useState<string | null>(null);
  const [assigningDriverId, setAssigningDriverId] = useState<string | null>(null);

  // Filter products belonging to current seller or brand
  const sellerProducts = products.filter(
    (p) =>
      p.sellerId === currentSeller.id ||
      p.brand.toLowerCase().includes(currentSeller.storeName.toLowerCase()) ||
      p.storeName?.toLowerCase() === currentSeller.storeName.toLowerCase() ||
      p.specifications?.some((s) => s.value === currentSeller.storeName) ||
      p.tags.includes(currentSeller.storeName)
  );

  const filteredProducts = sellerProducts.filter(
    (p) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const lowStockProducts = sellerProducts.filter((p) => (p.stock || 0) < 15);

  const handleRegisterStore = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regStoreName.trim()) {
      showToast('Please enter store name');
      return;
    }
    const targetPhone = regPhone || '+91 98260 11223';
    const conflict = checkPhoneConflict(targetPhone, 'seller');
    if (conflict.hasConflict) {
      showToast(conflict.conflictMessage || 'Role exclusivity conflict: mobile number is registered under another role.');
      return;
    }

    setIsRegistering(true);
    const finalCategory = regCategory === 'custom' && regCustomCategory ? regCustomCategory : regCategory;
    const res = await registerRoleAccount({
      phone: targetPhone,
      role: 'seller',
      name: regOwnerName || regStoreName,
      email: regEmail || 'seller@store.in',
      storeName: regStoreName,
      category: finalCategory,
      city: regCity,
      isWholesaler: regIsWholesaleSeller,
      isDealership: regIsDealership,
      isSingleSellerVendor: regIsSingleVendor,
    });
    setIsRegistering(false);
    if (res.success) {
      setIsRegisterModalOpen(false);
    }
  };

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName.trim()) {
      showToast('Please enter product title');
      return;
    }
    setIsSubmittingProd(true);
    const finalCategory = newProdCategory === 'custom' && newProdCustomCategory ? newProdCustomCategory : newProdCategory;
    await addSellerProduct({
      name: newProdName,
      title: newProdName,
      category: finalCategory,
      subcategory: newProdSubcategory || 'General',
      price: newProdPrice,
      mrp: newProdMrp,
      stock: newProdStock,
      image:
        newProdImage ||
        'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=600&auto=format&fit=crop&q=80',
      description: newProdDesc || `Authentic ${finalCategory} listing from ${currentSeller.storeName}, ${currentSeller.warehouseAddress?.city || 'Indore'}.`,
      isWholesale: newProdIsWholesale,
      minOrderQuantity: newProdIsWholesale ? newProdMinOrderQty : 1,
      wholesalePricePerUnit: newProdIsWholesale
        ? (newProdWholesaleUnitPrice || Math.round(newProdPrice / newProdMinOrderQty))
        : undefined,
      wholesaleLotSize: newProdIsWholesale ? newProdMinOrderQty : undefined,
      wholesaleLotPrice: newProdIsWholesale ? newProdPrice : undefined,
      isDealershipProduct: newProdIsDealership,
      isSingleSellerVendor: newProdIsSingleVendor,
    });
    setIsSubmittingProd(false);
    setNewProdName('');
    setNewProdImage('');
    setNewProdDesc('');
    setNewProdCustomCategory('');
    setNewProdIsWholesale(false);
    setNewProdIsDealership(false);
    setNewProdIsSingleVendor(false);
    setActiveTab('inventory');
  };

  // Quick Preset Product Templates for one-click testing
  const applyProductPreset = (preset: {
    name: string;
    category: string;
    price: number;
    mrp: number;
    image: string;
    desc: string;
    isWholesale?: boolean;
    minOrderQty?: number;
    wholesaleUnitPrice?: number;
    isDealership?: boolean;
    isSingleVendor?: boolean;
  }) => {
    setNewProdName(preset.name);
    setNewProdCategory(preset.category);
    setNewProdPrice(preset.price);
    setNewProdMrp(preset.mrp);
    setNewProdImage(preset.image);
    setNewProdDesc(preset.desc);
    setNewProdIsWholesale(preset.isWholesale ?? false);
    setNewProdMinOrderQty(preset.minOrderQty ?? 12);
    setNewProdWholesaleUnitPrice(preset.wholesaleUnitPrice ?? Math.round(preset.price / (preset.minOrderQty || 12)));
    setNewProdIsDealership(preset.isDealership ?? false);
    setNewProdIsSingleVendor(preset.isSingleVendor ?? false);
    showToast(`⚡ Filled template for "${preset.name}"!`);
  };

  const handleOpenEditProduct = (prod: Product) => {
    setEditingProduct(prod);
    setEditName(prod.name);
    setEditPrice(prod.price);
    setEditMrp(prod.mrp);
    setEditStock(prod.stock || 0);
    setEditDesc(prod.description || '');
    setEditIsWholesale(prod.isWholesale ?? false);
    setEditMinOrderQuantity(prod.minOrderQuantity ?? 12);
    setEditWholesaleUnitPrice(prod.wholesalePricePerUnit ?? (prod.isWholesale ? Math.round(prod.price / (prod.minOrderQuantity || 12)) : 0));
    setEditIsDealership(prod.isDealershipProduct ?? false);
    setEditIsSingleVendor(prod.isSingleSellerVendor ?? false);
  };

  const handleSaveProductEdit = async () => {
    if (!editingProduct) return;
    await updateSellerProduct(editingProduct.id, {
      name: editName,
      title: editName,
      price: editPrice,
      mrp: editMrp,
      stock: editStock,
      description: editDesc,
      isWholesale: editIsWholesale,
      minOrderQuantity: editIsWholesale ? editMinOrderQuantity : 1,
      wholesalePricePerUnit: editIsWholesale ? (editWholesaleUnitPrice || Math.round(editPrice / editMinOrderQuantity)) : undefined,
      isDealershipProduct: editIsDealership,
      isSingleSellerVendor: editIsSingleVendor,
    });
    setEditingProduct(null);
  };

  const handleDeleteProductConfirm = async (productId: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete "${name}" from your store catalog?`)) {
      await deleteSellerProduct(productId);
    }
  };

  const handlePayoutSubmit = async () => {
    if (payoutAmountInput <= 0 || payoutAmountInput > currentSeller.balanceAvailable) {
      showToast('Invalid payout amount or exceeds available balance.');
      return;
    }
    setIsRequestingPayout(true);
    await requestSellerPayout(currentSeller.id, payoutAmountInput);
    setIsRequestingPayout(false);
  };

  const handleAssignDriver = async (orderId: string, driverId: string) => {
    setAssigningDriverId(driverId);
    await assignDriverToOrder(orderId, driverId);
    setAssigningDriverId(null);
    setSelectedOrderToAssign(null);
  };

  // Nearby active drivers with distance calculation
  const storeLat = currentSeller.lat || 22.7196;
  const storeLng = currentSeller.lng || 75.8577;
  const nearbyDrivers = drivers.map((d) => {
    const dist = calculateDistanceKm(d.currentLat || storeLat, d.currentLng || storeLng, storeLat, storeLng);
    return { ...d, distanceToStore: dist };
  }).sort((a, b) => a.distanceToStore - b.distanceToStore);

  return (
    <div id="seller-central-portal" className="min-h-screen bg-slate-900 text-slate-100 pb-28">
      {/* Top Seller Bar */}
      <div className="bg-white border-b border-slate-800 px-4 sm:px-8 py-4 sticky top-12 z-30 shadow-md">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-slate-800 font-black shadow-lg">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-bold tracking-tight text-white">
                  {currentSeller.storeName}
                </h1>
                <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {currentSeller.tier}
                </span>
                <span
                  className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                    currentSeller.isActive
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  }`}
                >
                  {currentSeller.isActive ? '🟢 Active Venture' : '⏸️ Deactivated'}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                📍 {currentSeller.warehouseAddress?.city || 'Indore'} &bull; Radius: {currentSeller.deliveryRadiusKm || 15} km &bull; Rating: ⭐ {currentSeller.rating}
              </p>
            </div>
          </div>

          {/* Seller Switcher & Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            <select
              id="select-seller-account"
              value={activeSellerId}
              onChange={(e) => setActiveSellerId(e.target.value)}
              className="bg-slate-800 text-white text-xs border border-slate-700 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-amber-500"
            >
              {sellers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.storeName} ({s.warehouseAddress?.city || 'India'})
                </option>
              ))}
            </select>

            <button
              id="register-new-store-btn"
              onClick={() => setIsRegisterModalOpen(true)}
              className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded-lg text-xs transition-all shadow-md"
            >
              <Gift className="w-3.5 h-3.5 text-amber-300" />
              <span>+ Register Venture (+₹2,500)</span>
            </button>

            <button
              id="seller-bulk-upload-top-btn"
              onClick={() => setIsBulkUploadOpen(true)}
              className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold px-3 py-1.5 rounded-lg text-xs transition-all shadow-md"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Bulk Upload (Excel/CSV)</span>
            </button>

            <button
              id="seller-add-product-top-btn"
              onClick={() => setActiveTab('add-product')}
              className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 font-bold px-3 py-1.5 rounded-lg text-xs transition-all shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>List Product</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 mt-6">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-3 overflow-x-auto">
          {[
            { id: 'dashboard', label: 'Overview Dashboard', icon: TrendingUp },
            { id: 'book-buddy', label: '🚨 Book a Buddy (5km Broadcast)', icon: Radio },
            { id: 'inventory', label: `Inventory & SKUs (${sellerProducts.length})`, icon: Package },
            { id: 'orders', label: 'Order Dispatches', icon: Truck },
            { id: 'dispatch-drivers', label: 'Nearby Buddies Fleet 🛵', icon: Navigation },
            { id: 'community-chat', label: `Community & Bargains 💬`, icon: MessageSquare },
            { id: 'finance', label: 'Wallet & Bank Payouts', icon: Wallet },
            { id: 'add-product', label: '+ New Listing', icon: Plus },
            { id: 'account-settings', label: 'Venture Account & Deactivation', icon: ShieldCheck },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-amber-500 text-slate-800 shadow-md font-bold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* TAB 1: OVERVIEW DASHBOARD */}
        {activeTab === 'dashboard' && (
          <div className="mt-6 space-y-6">
            {/* Onboarding Reward Banner */}
            <div className="bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-amber-500/10 border border-amber-500/40 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-800 flex items-center justify-center font-black">
                  <Gift className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-amber-200">
                    Venture Partner Welcome Credit: ₹2,500 Active
                  </h3>
                  <p className="text-xs text-amber-300/80">
                    Pan-India & Local Indore Delivery Range (10–20 km hyperlocal with automated buddy matching)
                  </p>
                </div>
              </div>
              <span className="px-3 py-1 bg-amber-500 text-slate-800 text-xs font-black rounded-lg">
                Claimed & Verified ⭐
              </span>
            </div>

            {/* 🚨 FEATURE BANNER: BOOK A BUDDY 5KM BROADCAST CALL */}
            <div className="bg-gradient-to-r from-amber-600 via-orange-600 to-rose-600 p-5 rounded-2xl text-slate-800 flex flex-wrap items-center justify-between gap-4 shadow-xl border border-amber-400/40">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-white text-amber-400 flex items-center justify-center font-black shadow-md shrink-0">
                  <Radio className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-white text-amber-300 text-[10px] font-black uppercase tracking-wider">
                      NEW HYPERLOCAL FEATURE
                    </span>
                    <h3 className="text-base sm:text-lg font-black text-white">
                      Book a Buddy &bull; Simultaneous 5km Broadcast Call
                    </h3>
                  </div>
                  <p className="text-xs sm:text-sm text-amber-100 font-medium mt-0.5">
                    Ring all <strong>{nearbyDrivers.filter((d) => d.isOnline).length} nearby Buddies</strong> within 5km of your venture. The first buddy who picks up your call (+91 {currentSeller.phone || '9425821388'}) will come to collect the parcel!
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <button
                  onClick={() => {
                    setSelectedOrderForBuddy(null);
                    setIsBookBuddyModalOpen(true);
                  }}
                  className="px-4 py-2.5 bg-white hover:bg-slate-900 text-amber-400 font-black rounded-xl text-xs sm:text-sm transition-all shadow-md flex items-center gap-2 hover:scale-105 cursor-pointer border border-amber-400/30"
                >
                  <PhoneCall className="w-4 h-4 animate-bounce text-amber-400" />
                  <span>🚨 Ring & Book Buddy Now</span>
                </button>
                <button
                  onClick={() => setActiveTab('book-buddy')}
                  className="px-3.5 py-2.5 bg-amber-500/20 hover:bg-amber-500/30 text-white font-bold rounded-xl text-xs transition-all border border-white/20"
                >
                  <span>Open 5km Radar</span>
                </button>
              </div>
            </div>

            {/* ZERO-ADMIN AUTONOMOUS DIRECT EMPOWERMENT BANNER */}
            <div className="bg-gradient-to-r from-emerald-950/80 via-slate-900 to-amber-950/80 border border-emerald-500/40 p-4 sm:p-5 rounded-2xl flex flex-wrap items-center justify-between gap-4 shadow-lg">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-800 flex items-center justify-center font-black shadow-md flex-shrink-0">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-black text-white">
                      Zero-Admin Merchant Autonomy
                    </span>
                    <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-black px-2 py-0.5 rounded-full border border-emerald-500/30 uppercase">
                      ⚡ 0s Admin Queue
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Your store runs 100% autonomously: Instant AI KYC, live product publishing, 24x7 instant UPI payouts &amp; direct buyer negotiations.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2.5 w-full sm:w-auto">
                {!currentSeller.isActive && (
                  <button
                    onClick={() => instantVerifySellerKYC(currentSeller.id)}
                    className="flex-1 sm:flex-none px-3.5 py-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:brightness-110 text-slate-800 font-black text-xs rounded-xl shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <UserCheck className="w-4 h-4" />
                    <span>Instant AI KYC (1.2s)</span>
                  </button>
                )}

                <button
                  onClick={() => setIsAutonomousZeroAdminOpen(true)}
                  className="flex-1 sm:flex-none px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs rounded-xl border border-amber-500/40 transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Cpu className="w-4 h-4 text-amber-400" />
                  <span>Autonomous Governance Hub</span>
                </button>
              </div>
            </div>

            {/* KPI Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-slate-800/80 border border-slate-700/80 p-4 rounded-2xl">
                <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
                  <span>Gross Sales Volume</span>
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-2xl font-black text-white mt-2">
                  {formatPrice(currentSeller.totalRevenue)}
                </div>
                <div className="text-xs text-emerald-400 mt-1 font-semibold flex items-center gap-1">
                  <ArrowUpRight className="w-3.5 h-3.5" />
                  +18.4% this week
                </div>
              </div>

              <div className="bg-slate-800/80 border border-slate-700/80 p-4 rounded-2xl">
                <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
                  <span>Available for Payout</span>
                  <Wallet className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-2xl font-black text-amber-400 mt-2">
                  {formatPrice(currentSeller.balanceAvailable)}
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  Escrow: {formatPrice(currentSeller.balanceEscrow)}
                </div>
              </div>

              <div className="bg-slate-800/80 border border-slate-700/80 p-4 rounded-2xl">
                <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
                  <span>Nearby Active Drivers</span>
                  <Navigation className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-2xl font-black text-white mt-2">
                  {nearbyDrivers.filter((d) => d.isOnline).length} Online
                </div>
                <div className="text-xs text-emerald-400 mt-1 font-semibold">
                  Closest rider: {nearbyDrivers?.[0]?.distanceToStore || 1.2} km away
                </div>
              </div>

              <div className="bg-slate-800/80 border border-slate-700/80 p-4 rounded-2xl">
                <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
                  <span>Total Fulfilled Orders</span>
                  <Package className="w-4 h-4 text-blue-400" />
                </div>
                <div className="text-2xl font-black text-white mt-2">
                  {currentSeller.totalOrders.toLocaleString()}
                </div>
                <div className="text-xs text-blue-400 mt-1 font-semibold">
                  99.4% On-time dispatch rate
                </div>
              </div>
            </div>

            {/* Low Inventory Alert */}
            {lowStockProducts.length > 0 && (
              <div className="bg-amber-950/40 border border-amber-500/40 p-4 rounded-2xl flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <h4 className="text-sm font-bold text-amber-300">
                    Low Stock Alert on {lowStockProducts.length} Products
                  </h4>
                  <p className="text-xs text-amber-200/80 mt-0.5">
                    Replenish inventory to maintain instant hyperlocal delivery badge in {currentSeller.warehouseAddress?.city || 'Indore'}.
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('inventory')}
                  className="bg-amber-500 text-slate-800 font-bold px-3 py-1.5 rounded-lg text-xs hover:bg-amber-400 transition-all shrink-0"
                >
                  Manage Stocks
                </button>
              </div>
            )}

            {/* Merchant Details & Warehouse Box */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-slate-800/60 border border-slate-700/70 p-5 rounded-2xl">
                <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-3">
                  <Building2 className="w-4 h-4 text-amber-400" />
                  Warehouse & Local Dispatch Hub
                </h3>
                <div className="space-y-2 text-xs text-slate-300">
                  <div className="flex justify-between py-1 border-b border-slate-700/50">
                    <span className="text-slate-400">Street Address:</span>
                    <span className="font-medium text-right">{currentSeller.warehouseAddress?.street}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-700/50">
                    <span className="text-slate-400">City / State / Pincode:</span>
                    <span className="font-medium text-right">
                      {currentSeller.warehouseAddress?.city}, {currentSeller.warehouseAddress?.state} - {currentSeller.warehouseAddress?.pincode}
                    </span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-700/50">
                    <span className="text-slate-400">Hyperlocal Delivery Radius:</span>
                    <span className="font-bold text-emerald-400 text-right">{currentSeller.deliveryRadiusKm || 15} Kilometers</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-slate-400">Merchant Contact:</span>
                    <span className="font-medium text-right">{currentSeller.phone} ({currentSeller.email})</span>
                  </div>
                </div>
              </div>

              <div className="bg-slate-800/60 border border-slate-700/70 p-5 rounded-2xl">
                <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-3">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  Verified Bank Settlement Account
                </h3>
                <div className="space-y-2 text-xs text-slate-300">
                  <div className="flex justify-between py-1 border-b border-slate-700/50">
                    <span className="text-slate-400">Beneficiary Name:</span>
                    <span className="font-medium text-right">{currentSeller.bankAccount?.beneficiaryName || currentSeller.ownerName}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-700/50">
                    <span className="text-slate-400">Bank Name:</span>
                    <span className="font-medium text-right">{currentSeller.bankAccount?.bankName || 'HDFC Bank'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-700/50">
                    <span className="text-slate-400">Account Number:</span>
                    <span className="font-mono text-right text-emerald-300">
                      •••• •••• {(currentSeller.bankAccount?.accountNumber || '99881122').slice(-4)}
                    </span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-slate-400">IFSC / Routing Code:</span>
                    <span className="font-mono text-right">{currentSeller.bankAccount?.ifscCode || 'HDFC0001099'}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: INVENTORY & SKUs (With Edit & Delete) */}
        {activeTab === 'inventory' && (
          <div className="mt-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-800/70 p-3 rounded-2xl border border-slate-700">
              <div className="flex items-center gap-2 bg-slate-900 px-3 py-2 rounded-xl border border-slate-700 w-full sm:w-80">
                <Search className="w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search SKU, dress, cloth title..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="bg-transparent text-xs text-white focus:outline-none w-full"
                />
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsBulkUploadOpen(true)}
                  className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold px-3 py-2 rounded-xl text-xs transition-all shadow-md"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Bulk Upload (Excel/CSV)</span>
                </button>
                <button
                  onClick={() => setActiveTab('add-product')}
                  className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-600 text-slate-800 font-bold px-3 py-2 rounded-xl text-xs transition-all shadow-md"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New Product SKU</span>
                </button>
              </div>
            </div>

            {/* Inventory Table */}
            <div className="bg-slate-800/80 border border-slate-700 rounded-2xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-white text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-700">
                    <tr>
                      <th className="px-4 py-3">Product / SKU</th>
                      <th className="px-4 py-3">Category</th>
                      <th className="px-4 py-3">Price & MRP</th>
                      <th className="px-4 py-3">Live Stock</th>
                      <th className="px-4 py-3 text-center">In-Store QR</th>
                      <th className="px-4 py-3">Actions (Edit / Delete)</th>
                      <th className="px-4 py-3 text-right">Quick Restock</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/60">
                    {filteredProducts.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="text-center py-8 text-slate-400">
                          No products found for this store. Click "Add New Product SKU" to list a dress, t-shirt, or cloth.
                        </td>
                      </tr>
                    ) : (
                      filteredProducts.map((p) => (
                        <tr key={p.id} className="hover:bg-slate-750/50 transition-colors">
                          <td className="px-4 py-3">
                            <div
                              onClick={() => {
                                setSelectedQRProduct(p);
                                setIsQRModalOpen(true);
                              }}
                              className="flex items-center gap-3 cursor-pointer group"
                            >
                              <img
                                src={p.image}
                                alt={p.name}
                                className="w-10 h-10 rounded-lg object-cover bg-slate-900 border border-slate-700 group-hover:border-amber-500 transition"
                              />
                              <div>
                                <p className="font-bold text-white max-w-xs truncate group-hover:text-amber-300 transition flex items-center gap-1.5">
                                  {p.name}
                                  <QrCode className="w-3 h-3 text-slate-500 group-hover:text-amber-400" />
                                </p>
                                <span className="text-[10px] text-slate-400 font-mono">ID: {p.id}</span>
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-slate-300 capitalize">{p.category}</td>
                          <td className="px-4 py-3">
                            <span className="font-bold text-amber-400">{formatPrice(p.price)}</span>
                            <span className="text-slate-400 line-through text-[10px] ml-1.5">{formatPrice(p.mrp)}</span>
                          </td>
                          <td className="px-4 py-3">
                            <span
                              className={`px-2 py-0.5 rounded-md font-bold text-xs ${
                                (p.stock || 0) < 10
                                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                  : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              }`}
                            >
                              {p.stock || 0} in stock
                            </span>
                          </td>
                          <td className="px-4 py-3 text-center">
                            <button
                              onClick={() => {
                                setSelectedQRProduct(p);
                                setIsQRModalOpen(true);
                              }}
                              className="px-2.5 py-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-lg font-bold text-xs inline-flex items-center gap-1 transition shadow-sm cursor-pointer"
                              title="Generate In-Store POS & Checkout QR"
                            >
                              <QrCode className="w-3.5 h-3.5" />
                              <span>QR Code</span>
                            </button>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => handleOpenEditProduct(p)}
                                className="flex items-center gap-1 px-2.5 py-1 bg-slate-700 hover:bg-slate-600 text-amber-300 rounded font-medium text-xs transition-all"
                                title="Edit Product Details"
                              >
                                <Edit2 className="w-3 h-3" />
                                <span>Edit</span>
                              </button>
                              <button
                                onClick={() => handleDeleteProductConfirm(p.id, p.name)}
                                className="flex items-center gap-1 px-2.5 py-1 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 rounded font-medium text-xs transition-all"
                                title="Delete from Catalog"
                              >
                                <Trash2 className="w-3 h-3" />
                                <span>Delete</span>
                              </button>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => updateSellerInventory(p.id, Math.max(0, (p.stock || 0) - 5))}
                                className="px-2 py-1 bg-slate-700 hover:bg-slate-600 rounded text-slate-200 text-xs font-bold"
                              >
                                -5
                              </button>
                              <button
                                onClick={() => updateSellerInventory(p.id, (p.stock || 0) + 10)}
                                className="px-2 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 rounded text-xs font-bold"
                              >
                                +10
                              </button>
                              <button
                                onClick={() => updateSellerInventory(p.id, (p.stock || 0) + 50)}
                                className="px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 rounded text-xs font-bold"
                              >
                                +50
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: ORDER DISPATCHES (With Nearby Driver Selection) */}
        {activeTab === 'orders' && (
          <div className="mt-6 space-y-4">
            <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Truck className="w-4 h-4 text-amber-400" />
                  Store Fulfillment & Order Dispatches
                </h3>
                <span className="text-xs text-slate-400">
                  Select nearby driver within {currentSeller.deliveryRadiusKm || 15}km to deliver directly to customer
                </span>
              </div>

              <div className="divide-y divide-slate-700/60">
                {orders.map((ord) => {
                  const assignedDriver = drivers.find((d) => d.id === ord.assignedDriverId);

                  return (
                    <div
                      key={ord.id}
                      className="py-4 flex flex-wrap items-start justify-between gap-3 text-xs border-b border-slate-700/50 last:border-0"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm font-mono">{ord.orderNumber || ord.id}</span>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              ord.status === 'Delivered'
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                : ord.status === 'Out for delivery' || ord.status === 'Shipped'
                                ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                                : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            }`}
                          >
                            {ord.status}
                          </span>
                          {ord.deliveryOtp && (
                            <span className="text-[10px] bg-slate-900 px-2 py-0.5 rounded text-amber-400 font-mono border border-amber-500/30">
                              Customer Delivery OTP: {ord.deliveryOtp}
                            </span>
                          )}
                        </div>

                        <p className="text-slate-300">
                          Customer: <span className="font-semibold text-white">{ord.customerName}</span> &bull; Phone:{' '}
                          {ord.customerPhone || '+91 98260 99881'} &bull; Total: {formatPrice(ord.totalAmount)}
                        </p>

                        {ord.shippingAddress && (
                          <p className="text-slate-400 flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                            {ord.shippingAddress.street}, {ord.shippingAddress.city}, {ord.shippingAddress.state} -{' '}
                            {ord.shippingAddress.pincode}
                          </p>
                        )}

                        {assignedDriver ? (
                          <div className="mt-2 p-2 rounded-lg bg-emerald-950/30 border border-emerald-500/30 flex items-center gap-2">
                            <img
                              src={assignedDriver.avatar}
                              alt={assignedDriver.name}
                              className="w-6 h-6 rounded-full object-cover"
                            />
                            <span className="text-emerald-300 text-xs">
                              Assigned Buddy: <strong>{assignedDriver.name}</strong> ({assignedDriver.vehicleType} &bull;{' '}
                              {assignedDriver.phone})
                            </span>
                          </div>
                        ) : (
                          <div className="mt-1 text-amber-400 text-xs flex items-center gap-1">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            Pending Buddy Assignment — Pick from nearby buddies below
                          </div>
                        )}
                      </div>

                      <div className="flex flex-col sm:flex-row items-end sm:items-center gap-2">
                        <button
                          onClick={() => viewOrderInvoice(ord)}
                          className="flex items-center gap-1 px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg font-medium transition-all"
                        >
                          <FileText className="w-3.5 h-3.5 text-amber-400" />
                          <span>Invoice</span>
                        </button>

                        <button
                          onClick={() => {
                            setSelectedOrderForBuddy(ord);
                            setIsBookBuddyModalOpen(true);
                          }}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg transition-all shadow-md animate-pulse cursor-pointer"
                          title="Simultaneously ring all buddies within 5km from your venture phone"
                        >
                          <PhoneCall className="w-3.5 h-3.5" />
                          <span>📞 5km Broadcast Ring</span>
                        </button>

                        <button
                          onClick={() => {
                            setSelectedOrderToAssign(selectedOrderToAssign === ord.id ? null : ord.id);
                          }}
                          className="flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-800 font-bold rounded-lg transition-all shadow-md"
                        >
                          <Navigation className="w-3.5 h-3.5" />
                          <span>{assignedDriver ? 'Reassign Buddy' : 'Assign Nearby Buddy'}</span>
                        </button>
                      </div>

                      {/* Driver Selection Accordion */}
                      {selectedOrderToAssign === ord.id && (
                        <div className="w-full mt-3 p-3 bg-slate-900 rounded-xl border border-amber-500/40 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-amber-300 text-xs">
                              Select Nearby Buddy Partner in {currentSeller.warehouseAddress?.city || 'Indore'}:
                            </span>
                            <button
                              onClick={() => setSelectedOrderToAssign(null)}
                              className="text-slate-400 hover:text-white"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-2">
                            {nearbyDrivers.map((drv) => (
                              <div
                                key={drv.id}
                                className={`p-2.5 rounded-lg border text-xs flex flex-col justify-between gap-2 ${
                                  ord.assignedDriverId === drv.id
                                    ? 'bg-amber-500/10 border-amber-500 text-white'
                                    : 'bg-slate-800 border-slate-700 text-slate-300'
                                }`}
                              >
                                <div>
                                  <div className="flex items-center justify-between">
                                    <span className="font-bold text-white">{drv.name}</span>
                                    <span
                                      className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                                        drv.isOnline ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-700 text-slate-400'
                                      }`}
                                    >
                                      {drv.isOnline ? 'ONLINE' : 'OFFLINE'}
                                    </span>
                                  </div>
                                  <p className="text-[11px] text-slate-400">
                                    {drv.vehicleType} ({drv.vehicleNumber}) &bull; ⭐ {drv.rating}
                                  </p>
                                  <p className="text-[11px] text-emerald-400 font-semibold mt-0.5">
                                    📍 {drv.distanceToStore} km away from venture
                                  </p>
                                </div>

                                <button
                                  onClick={() => handleAssignDriver(ord.id, drv.id)}
                                  disabled={assigningDriverId === drv.id}
                                  className="w-full bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold py-1 rounded text-xs transition-all disabled:opacity-50"
                                >
                                  {assigningDriverId === drv.id ? 'Dispatching...' : `Assign (${drv.distanceToStore} km)`}
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: NEARBY DRIVER FLEET DISPATCHER */}
        {activeTab === 'dispatch-drivers' && (
          <div className="mt-6 space-y-6">
            <div className="bg-slate-800/80 border border-slate-700 p-5 rounded-2xl">
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <Navigation className="w-5 h-5 text-emerald-400" />
                    Live Nearby Buddy Fleet ({currentSeller.warehouseAddress?.city || 'Indore'})
                  </h3>
                  <p className="text-xs text-slate-400">
                    Hyperlocal buddy matching within 10 km (standard) to 20 km (max delivery radius)
                  </p>
                </div>
                <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold rounded-lg">
                  {nearbyDrivers.filter((d) => d.isOnline).length} Active Buddies Available
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {nearbyDrivers.map((drv) => (
                  <div
                    key={drv.id}
                    className="bg-slate-900/90 border border-slate-700 p-4 rounded-xl flex flex-col justify-between gap-3"
                  >
                    <div className="flex items-start gap-3">
                      <img
                        src={drv.avatar}
                        alt={drv.name}
                        className="w-12 h-12 rounded-full object-cover border-2 border-emerald-500"
                      />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h4 className="font-bold text-white text-sm">{drv.name}</h4>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              drv.isOnline
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                : 'bg-slate-700 text-slate-400'
                            }`}
                          >
                            {drv.isOnline ? 'ONLINE' : 'OFFLINE'}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400">
                          {drv.vehicleType} &bull; {drv.vehicleNumber}
                        </p>
                        <p className="text-xs text-amber-300 font-semibold mt-1">
                          ⭐ {drv.rating} ({drv.completedDeliveries} trips completed)
                        </p>
                        <p className="text-xs text-emerald-400 font-bold mt-0.5">
                          📍 {drv.distanceToStore} km away from your shop
                        </p>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                      <span className="text-slate-400">Phone: {drv.phone}</span>
                      <span className="text-slate-300 font-mono">ID: {drv.id}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB: 5KM RADAR & SIMULTANEOUS BROADCAST CALL TO ALL BUDDIES */}
        {activeTab === 'book-buddy' && (
          <div className="mt-6 space-y-6">
            <div className="bg-gradient-to-r from-amber-600 via-orange-600 to-rose-600 p-6 rounded-3xl text-slate-800 shadow-2xl flex flex-wrap items-center justify-between gap-4 border border-amber-400/40">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-white text-amber-400 flex items-center justify-center font-black shadow-lg">
                  <Radio className="w-7 h-7 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-white text-amber-300 text-xs font-black uppercase tracking-wider">
                      Venture Hyperlocal Call System
                    </span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black text-white mt-0.5">
                    Book a Buddy (5km Broadcast Call)
                  </h3>
                  <p className="text-xs sm:text-sm text-amber-100 font-medium mt-1 max-w-2xl">
                    Broadcast a delivery call to all buddies within 5km of {currentSeller.storeName}. All nearby buddies will receive an incoming phone ring from your Venture caller ID (+91 {currentSeller.phone || '9425821388'}). The first buddy to answer gets the pickup job.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    setSelectedOrderForBuddy(null);
                    setIsBookBuddyModalOpen(true);
                  }}
                  className="px-5 py-3 bg-white hover:bg-slate-900 text-amber-400 font-black rounded-2xl text-sm transition-all shadow-xl flex items-center gap-2 hover:scale-105 cursor-pointer border border-amber-400/40 animate-bounce"
                >
                  <PhoneCall className="w-5 h-5 text-amber-400" />
                  <span>🚨 Ring & Call Buddies in 5km</span>
                </button>
              </div>
            </div>

            {/* LIVE 5KM RADAR GRID & CALL STATUS */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 bg-slate-800/80 border border-slate-700 p-5 rounded-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white text-base flex items-center gap-2">
                    <Navigation className="w-5 h-5 text-emerald-400" />
                    Online Buddies in 5km Proximity of {currentSeller.warehouseAddress?.city || 'Indore'}
                  </h4>
                  <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold rounded-lg">
                    {nearbyDrivers.filter((d) => d.isOnline && d.distanceToStore <= 5).length} within 5km
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {nearbyDrivers.map((drv) => {
                    const isUnder5km = drv.distanceToStore <= 5;
                    return (
                      <div
                        key={drv.id}
                        className={`p-4 rounded-2xl border transition-all flex flex-col justify-between gap-3 ${
                          isUnder5km
                            ? 'bg-slate-900/90 border-emerald-500/50 shadow-md'
                            : 'bg-slate-900/50 border-slate-800 opacity-70'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <img
                            src={drv.avatar}
                            alt={drv.name}
                            className={`w-12 h-12 rounded-full object-cover border-2 ${
                              isUnder5km ? 'border-emerald-500' : 'border-slate-700'
                            }`}
                          />
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <h5 className="font-bold text-white text-sm">{drv.name}</h5>
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  isUnder5km
                                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                    : 'bg-slate-800 text-slate-400'
                                }`}
                              >
                                {isUnder5km ? '🟢 5KM RADAR' : '⚪ >5KM'}
                              </span>
                            </div>
                            <p className="text-xs text-slate-400 mt-0.5">
                              {drv.vehicleType} &bull; {drv.vehicleNumber}
                            </p>
                            <p className="text-xs text-amber-300 font-semibold mt-1">
                              ⭐ {drv.rating} &bull; {drv.phone}
                            </p>
                            <p className="text-xs font-bold text-emerald-400 mt-0.5">
                              📍 {drv.distanceToStore} km from your store (~{Math.round(drv.distanceToStore * 2.5 + 2)} mins)
                            </p>
                          </div>
                        </div>

                        <button
                          onClick={() => {
                            setSelectedOrderForBuddy(null);
                            setIsBookBuddyModalOpen(true);
                          }}
                          className="w-full bg-slate-800 hover:bg-amber-500 hover:text-slate-800 text-amber-300 font-bold py-2 rounded-xl text-xs transition-all border border-amber-500/30 flex items-center justify-center gap-1.5"
                        >
                          <PhoneCall className="w-3.5 h-3.5" />
                          <span>Include in 5km Broadcast Ring</span>
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* HOW 5KM BROADCAST WORKS CARD */}
              <div className="bg-slate-800/80 border border-slate-700 p-5 rounded-2xl space-y-4">
                <h4 className="font-bold text-white text-sm flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  How 5km Broadcast Calling Works:
                </h4>

                <div className="space-y-3 text-xs text-slate-300">
                  <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-700/80">
                    <span className="font-bold text-amber-300 block mb-1">1. Venture Initiates Call:</span>
                    Venture enters customer drop details or selects an order. Fare calculates automatically at <strong>₹15/km</strong> based on travel distance (e.g. 2 km = ₹30, 3 km = ₹45, 4 km = ₹60).
                  </div>

                  <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-700/80">
                    <span className="font-bold text-amber-300 block mb-1">2. Simultaneous 5km Ring:</span>
                    All online buddies within 5km immediately receive an incoming phone ring displaying your Venture caller ID (+91 {currentSeller.phone || '9425821388'}) and guaranteed earnings.
                  </div>

                  <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-700/80">
                    <span className="font-bold text-emerald-300 block mb-1">3. Guaranteed Payout & Pickup:</span>
                    The first buddy to answer locks the trip. Venture pays the buddy via Venture Wallet, Cash on Pickup, or UPI at the agreed per-km rate!
                  </div>
                </div>

                <button
                  onClick={() => {
                    setSelectedOrderForBuddy(null);
                    setIsBookBuddyModalOpen(true);
                  }}
                  className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-800 font-black py-3 rounded-xl text-xs transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <Radio className="w-4 h-4 animate-pulse" />
                  <span>Launch 5km Broadcast Dispatcher</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: WALLET & FINANCES */}
        {activeTab === 'finance' && (
          <div className="mt-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Request Payout Form */}
              <div className="bg-slate-800/80 border border-slate-700 p-5 rounded-2xl">
                <h3 className="text-base font-bold text-white flex items-center gap-2 mb-2">
                  <Wallet className="w-5 h-5 text-amber-400" />
                  Instant Bank Payout Transfer
                </h3>
                <p className="text-xs text-slate-400 mb-4">
                  Transfers funds directly to your verified IFSC account ({currentSeller.bankAccount?.bankName || 'HDFC Bank'}) with 0 gateway charge.
                </p>

                <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-700/80 mb-4">
                  <span className="text-xs text-slate-400 block">Available Balance:</span>
                  <span className="text-2xl font-black text-amber-400">
                    {formatPrice(currentSeller.balanceAvailable)}
                  </span>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">Transfer Amount (INR ₹):</label>
                    <input
                      type="number"
                      value={payoutAmountInput}
                      onChange={(e) => setPayoutAmountInput(Number(e.target.value))}
                      max={currentSeller.balanceAvailable}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                    />
                  </div>

                  <div className="flex gap-2">
                    {[25000, 50000, 100000, currentSeller.balanceAvailable].map((amt, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setPayoutAmountInput(amt)}
                        className="px-2.5 py-1 bg-slate-700/70 hover:bg-slate-700 text-slate-200 text-xs rounded-lg font-medium"
                      >
                        ₹{amt.toLocaleString('en-IN')}
                      </button>
                    ))}
                  </div>

                  <button
                    id="seller-payout-submit-btn"
                    onClick={handlePayoutSubmit}
                    disabled={isRequestingPayout || currentSeller.balanceAvailable <= 0}
                    className="w-full mt-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-slate-800 font-bold py-2.5 rounded-xl text-sm transition-all shadow-lg disabled:opacity-50"
                  >
                    {isRequestingPayout ? 'Processing IMPS Transfer...' : 'Initiate Instant Bank Transfer'}
                  </button>
                </div>
              </div>

              {/* Settlement History */}
              <div className="bg-slate-800/80 border border-slate-700 p-5 rounded-2xl">
                <h3 className="text-base font-bold text-white flex items-center gap-2 mb-3">
                  <FileText className="w-5 h-5 text-emerald-400" />
                  Recent Bank Settlement History
                </h3>
                <div className="space-y-2.5">
                  {sellerPayouts.map((pay) => (
                    <div
                      key={pay.id}
                      className="bg-slate-900/80 border border-slate-700/60 p-3 rounded-xl flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white">{formatPrice(pay.amount)}</span>
                          <span className="px-2 py-0.2 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                            {pay.status}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          UTR: <span className="font-mono text-slate-300">{pay.utrNumber}</span> &bull; {pay.date}
                        </p>
                      </div>
                      <span className="text-xs text-slate-400">{pay.method}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: ADD NEW PRODUCT LISTING */}
        {activeTab === 'add-product' && (
          <div className="mt-6 max-w-3xl mx-auto bg-slate-800/80 border border-slate-700 rounded-2xl p-6 shadow-2xl space-y-6">
            <div>
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Plus className="w-5 h-5 text-amber-400" />
                  List Any Product on {currentSeller.storeName}
                </h3>
                <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold rounded-lg">
                  Flipkart-Style Open Marketplace
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                List cosmetics, electrical tools, furniture, cloths, commercial supplies, or any product. It will immediately be live to customers in {currentSeller.warehouseAddress?.city || 'Indore'} and pan-India.
              </p>
            </div>

            {/* Quick 1-Click Preset Product Templates */}
            <div className="p-4 bg-slate-900/80 rounded-xl border border-slate-700/80">
              <label className="text-xs font-bold text-amber-400 block mb-2">⚡ 1-Click Quick Category & Wholesale Presets (Click to Auto-Fill):</label>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() =>
                    applyProductPreset({
                      name: 'Smart Interactive STEM Robotic Toy Lot (Pack of 12)',
                      category: 'toys',
                      price: 9600,
                      mrp: 18000,
                      image: 'https://images.unsplash.com/photo-1535378917042-10a22c95931a?w=600&auto=format&fit=crop&q=80',
                      desc: 'Wholesale lot of 12 programmable interactive STEM robot toys with gesture control, obstacle avoidance, and rechargeable batteries.',
                      isWholesale: true,
                      minOrderQty: 12,
                      wholesaleUnitPrice: 800,
                      isDealership: true,
                      isSingleVendor: true,
                    })
                  }
                  className="px-3 py-1.5 bg-blue-900/60 hover:bg-blue-800 text-blue-200 text-xs rounded-lg font-bold border border-blue-600/50 flex items-center gap-1.5 transition-colors shadow-sm"
                >
                  <span>🧸</span>
                  <span>Toy Wholesale Lot (MOQ: 12)</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    applyProductPreset({
                      name: 'Premium Bio-Washed Combed Cotton T-Shirt Lot (Pack of 45)',
                      category: 'men',
                      price: 13500,
                      mrp: 35955,
                      image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=600&auto=format&fit=crop&q=80',
                      desc: 'Wholesale lot of 45 premium 180 GSM bio-washed 100% combed cotton round-neck t-shirts in assorted fast-selling sizes and colors.',
                      isWholesale: true,
                      minOrderQty: 45,
                      wholesaleUnitPrice: 300,
                      isDealership: true,
                      isSingleVendor: false,
                    })
                  }
                  className="px-3 py-1.5 bg-purple-900/60 hover:bg-purple-800 text-purple-200 text-xs rounded-lg font-bold border border-purple-600/50 flex items-center gap-1.5 transition-colors shadow-sm"
                >
                  <span>👕</span>
                  <span>T-Shirt Wholesale Lot (MOQ: 45)</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    applyProductPreset({
                      name: 'Havells 32A Double-Pole MCB Switch Board',
                      category: 'electrical',
                      price: 1650,
                      mrp: 2400,
                      image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=600&auto=format&fit=crop&q=80',
                      desc: 'Heavy-duty 32A modular MCB board with flame retardant enclosure and pure copper terminal contacts.',
                      isWholesale: false,
                      minOrderQty: 1,
                      isDealership: true,
                      isSingleVendor: true,
                    })
                  }
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg font-medium border border-slate-700 flex items-center gap-1.5 transition-colors"
                >
                  <span>⚡</span>
                  <span>Havells MCB / Electrician Kit</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    applyProductPreset({
                      name: 'Luxe Velvet Matte Long-Stay Lipstick (Almond Nude)',
                      category: 'cosmetics',
                      price: 799,
                      mrp: 1299,
                      image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=600&auto=format&fit=crop&q=80',
                      desc: '16-hour smudge-proof hydrating velvet matte liquid lipstick enriched with vitamin E and avocado oil.',
                    })
                  }
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg font-medium border border-slate-700 flex items-center gap-1.5 transition-colors"
                >
                  <span>💄</span>
                  <span>Cosmetics / Matte Lipstick</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    applyProductPreset({
                      name: 'Solid Sheesham Wood Minimalist Study Table Desk',
                      category: 'furniture',
                      price: 8999,
                      mrp: 14999,
                      image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=600&auto=format&fit=crop&q=80',
                      desc: 'Handcrafted solid Indian rosewood study desk with 2 storage drawers and cable grommet.',
                    })
                  }
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg font-medium border border-slate-700 flex items-center gap-1.5 transition-colors"
                >
                  <span>🪑</span>
                  <span>Solid Wood Furniture</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    applyProductPreset({
                      name: 'Pure Chanderi Silk Handloom Festive Kurta Set',
                      category: 'ethnic-wear',
                      price: 2499,
                      mrp: 4299,
                      image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&auto=format&fit=crop&q=80',
                      desc: 'Authentic Chanderi silk kurta with delicate zari embroidery, tailored trousers, and silk dupatta.',
                    })
                  }
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg font-medium border border-slate-700 flex items-center gap-1.5 transition-colors"
                >
                  <span>🥻</span>
                  <span>Handloom Silk Kurta</span>
                </button>
              </div>
            </div>

            <form onSubmit={handleCreateProduct} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Product Title (Any Product Type) *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Smart RC Robot Toys Lot (12 Units) / Combed Cotton T-Shirt Lot (45 Units) / Havells MCB"
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Product Category</label>
                  <select
                    value={newProdCategory}
                    onChange={(e) => setNewProdCategory(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="toys">🧸 Toys & Kids Games</option>
                    <option value="electrical">⚡ Electricals & Electrician Tools</option>
                    <option value="cosmetics">💄 Cosmetics, Makeup & Skincare</option>
                    <option value="furniture">🪑 Furniture & Home Living</option>
                    <option value="ethnic-wear">👗 Fashion, Ethnic Wear & Sarees</option>
                    <option value="men">👔 Men's T-Shirts, Shirts & Wear</option>
                    <option value="women">👗 Women's Dresses & Tops</option>
                    <option value="commercial-hardware">🛠️ Commercial Hardware & Tools</option>
                    <option value="electronics">📱 Electronics & Smart Devices</option>
                    <option value="grocery">🛒 Grocery & Daily Essentials</option>
                    <option value="custom">➕ Custom / Other Product Category</option>
                  </select>
                </div>

                {newProdCategory === 'custom' ? (
                  <div>
                    <label className="text-xs font-semibold text-amber-400 block mb-1">Specify Custom Category Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Industrial Automation, Organic Spices, etc."
                      value={newProdCustomCategory}
                      onChange={(e) => setNewProdCustomCategory(e.target.value)}
                      className="w-full bg-slate-900 border border-amber-500/50 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                ) : (
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">Subcategory (Optional)</label>
                    <input
                      type="text"
                      placeholder="e.g. Robot Toys, Round Neck T-Shirts, Modular Switches"
                      value={newProdSubcategory}
                      onChange={(e) => setNewProdSubcategory(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                )}
              </div>

              {/* Wholesale & Dealership Configuration Panel */}
              <div className="p-4 bg-slate-900/90 rounded-xl border border-slate-700 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="new-prod-is-wholesale"
                      checked={newProdIsWholesale}
                      onChange={(e) => setNewProdIsWholesale(e.target.checked)}
                      className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                    />
                    <label htmlFor="new-prod-is-wholesale" className="text-xs font-bold text-white cursor-pointer flex items-center gap-1.5">
                      <span>📦 Wholesaler B2B Bulk Product</span>
                      <span className="bg-blue-500/20 text-blue-300 text-[10px] px-1.5 py-0.2 rounded font-semibold border border-blue-500/30">
                        Enforce Minimum Order Quantity (MOQ)
                      </span>
                    </label>
                  </div>
                </div>

                {newProdIsWholesale && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-800">
                    <div>
                      <label className="text-xs font-semibold text-amber-300 block mb-1">
                        Minimum Order Quantity (MOQ) *
                      </label>
                      <input
                        type="number"
                        min={2}
                        value={newProdMinOrderQty}
                        onChange={(e) => {
                          const val = Number(e.target.value);
                          setNewProdMinOrderQty(val);
                          if (val > 0 && newProdPrice > 0) {
                            setNewProdWholesaleUnitPrice(Math.round(newProdPrice / val));
                          }
                        }}
                        placeholder="e.g. 12 for toys, 45 for t-shirts"
                        className="w-full bg-slate-800 border border-amber-500/50 rounded-xl px-3 py-2 text-sm text-amber-300 font-bold focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                      />
                      <span className="text-[10px] text-slate-400 mt-0.5 block">
                        E.g. Toy sellers require 12 units MOQ; T-shirt sellers require 45 units MOQ.
                      </span>
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">
                        Calculated Unit Rate (₹/unit)
                      </label>
                      <input
                        type="number"
                        min={1}
                        value={newProdWholesaleUnitPrice || (newProdMinOrderQty > 0 ? Math.round(newProdPrice / newProdMinOrderQty) : 0)}
                        onChange={(e) => setNewProdWholesaleUnitPrice(Number(e.target.value))}
                        className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                      />
                      <span className="text-[10px] text-slate-400 mt-0.5 block">
                        Bulk buyer pays ₹{Math.round((newProdWholesaleUnitPrice || (newProdPrice / newProdMinOrderQty)) * newProdMinOrderQty).toLocaleString('en-IN')} per MOQ lot.
                      </span>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-800 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                    <input
                      type="checkbox"
                      checked={newProdIsDealership}
                      onChange={(e) => setNewProdIsDealership(e.target.checked)}
                      className="w-4 h-4 rounded accent-amber-500"
                    />
                    <span>🏭 Authorized Dealership Product</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                    <input
                      type="checkbox"
                      checked={newProdIsSingleVendor}
                      onChange={(e) => setNewProdIsSingleVendor(e.target.checked)}
                      className="w-4 h-4 rounded accent-amber-500"
                    />
                    <span>🏬 Single Seller Vendor Guarantee</span>
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {newProdIsWholesale ? 'Total Lot Price (₹)' : 'Selling Price (₹)'} *
                  </label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={newProdPrice}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setNewProdPrice(val);
                      if (newProdMinOrderQty > 0) {
                        setNewProdWholesaleUnitPrice(Math.round(val / newProdMinOrderQty));
                      }
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-amber-400 font-bold focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">MRP Reference (₹)</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={newProdMrp}
                    onChange={(e) => setNewProdMrp(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Initial Stock Units</label>
                  <input
                    type="number"
                    min={1}
                    value={newProdStock}
                    onChange={(e) => setNewProdStock(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-emerald-400 font-bold focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Image URL (Optional)</label>
                <input
                  type="url"
                  placeholder="https://images.unsplash.com/photo-..."
                  value={newProdImage}
                  onChange={(e) => setNewProdImage(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Description & Specifications</label>
                <textarea
                  rows={3}
                  placeholder="Describe material, technical specs, warranty, care, package contents..."
                  value={newProdDesc}
                  onChange={(e) => setNewProdDesc(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="pt-4 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('inventory')}
                  className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded-xl text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingProd}
                  className="px-6 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 font-bold rounded-xl text-xs transition-all shadow-lg"
                >
                  {isSubmittingProd ? 'Publishing SKU...' : 'Publish Product to Live Marketplace'}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* TAB: STORE COMMUNITY & BUYER BARGAINING HUB */}
        {activeTab === 'community-chat' && (
          <div className="mt-6 space-y-6">
            {/* Header / Intro */}
            <div className="bg-gradient-to-r from-emerald-950/60 via-slate-900 to-amber-950/40 border border-emerald-500/30 p-6 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-[11px] border border-emerald-500/40 flex items-center gap-1">
                    <Users className="w-3 h-3" />
                    Store Community & Bargaining
                  </span>
                  <span className="text-slate-400 text-xs">• 1-on-1 Direct Negotiation</span>
                </div>
                <h2 className="text-xl font-bold text-white mt-1.5">
                  {currentSeller.storeName} — Community Circle & Deals Hub
                </h2>
                <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                  Broadcast exclusive deals, lot discounts, and announcements to your loyal customer community, and respond in real-time to buyer price bargaining requests.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const com = storeCommunities.find((c) => c.sellerId === currentSeller.id);
                    if (com) {
                      showToast(`Community Circle active with ${com.memberCount.toLocaleString()} members.`);
                    }
                  }}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md"
                >
                  <Users className="w-4 h-4" />
                  <span>
                    {storeCommunities.find((c) => c.sellerId === currentSeller.id)?.memberCount.toLocaleString() || '1,240'}{' '}
                    Followers
                  </span>
                </button>
              </div>
            </div>

            {/* Grid: Left Column (Community Broadcast & Posts), Right Column (Live Buyer Bargain Requests) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Column: Community Posts & Broadcasts */}
              <div className="lg:col-span-7 space-y-6">
                {/* Create Broadcast / Post Card */}
                <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4 shadow-md">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Tag className="w-4 h-4 text-amber-400" />
                      Publish Store Community Deal / Update
                    </h3>
                    <span className="text-[11px] text-slate-400">Broadcasts to all store followers</span>
                  </div>

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!newPostTitle.trim() || !newPostContent.trim()) {
                        showToast('Please provide a title and post description.');
                        return;
                      }
                      setIsCreatingPost(true);
                      createCommunityPost({
                        sellerId: currentSeller.id,
                        storeName: currentSeller.storeName,
                        authorName: `${currentSeller.storeName} (Verified Merchant)`,
                        authorRole: 'STORE_OWNER',
                        title: newPostTitle,
                        content: newPostContent,
                        tag: newPostTag,
                        discountBadge: newPostDiscount || undefined,
                      });
                      setNewPostTitle('');
                      setNewPostContent('');
                      setIsCreatingPost(false);
                    }}
                    className="space-y-3 text-xs"
                  >
                    <div>
                      <label className="text-slate-300 block mb-1 font-semibold">Post / Deal Headline *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Exclusive Weekend Wholesale Deal on LED Fixtures!"
                        value={newPostTitle}
                        onChange={(e) => setNewPostTitle(e.target.value)}
                        className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-slate-300 block mb-1 font-semibold">Post Category / Tag</label>
                        <select
                          value={newPostTag}
                          onChange={(e) => setNewPostTag(e.target.value)}
                          className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                        >
                          <option value="Flash Sale">⚡ Flash Sale</option>
                          <option value="Wholesale Deal">📦 Wholesale Deal</option>
                          <option value="New Arrival">✨ New Arrival</option>
                          <option value="Special Offer">🎁 Special Offer</option>
                          <option value="Store Announcement">📢 Store Announcement</option>
                          <option value="Product Reel / Video">🎥 Product Reel / Video</option>
                          <option value="Service Showcase">🛠️ Service Showcase</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-slate-300 block mb-1 font-semibold">Discount Badge (Optional)</label>
                        <input
                          type="text"
                          placeholder="e.g. 25% Off / Flat ₹500 Off"
                          value={newPostDiscount}
                          onChange={(e) => setNewPostDiscount(e.target.value)}
                          className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-amber-300 font-bold"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="text-slate-300 block mb-1 font-semibold">Media Type</label>
                        <select
                          value={newPostMediaType}
                          onChange={(e) => setNewPostMediaType(e.target.value as any)}
                          className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                        >
                          <option value="image">🖼️ Image / Banner</option>
                          <option value="video">📹 Video Clip</option>
                          <option value="reel">📱 Social Reel</option>
                        </select>
                      </div>
                      <div className="sm:col-span-2">
                        <label className="text-slate-300 block mb-1 font-semibold">Media / Video URL (Optional)</label>
                        <input
                          type="url"
                          placeholder="https://images.unsplash.com/... or video link"
                          value={newPostMediaUrl}
                          onChange={(e) => setNewPostMediaUrl(e.target.value)}
                          className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder:text-slate-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-semibold">Post Content & Offer Terms *</label>
                      <textarea
                        rows={3}
                        required
                        placeholder="Detail the special price, bulk tiers, warranty, or festive coupons available for community members..."
                        value={newPostContent}
                        onChange={(e) => setNewPostContent(e.target.value)}
                        className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>

                    <div className="flex justify-end pt-1">
                      <button
                        type="submit"
                        disabled={isCreatingPost}
                        className="px-5 py-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>{isCreatingPost ? 'Publishing...' : 'Publish to Store Community'}</span>
                      </button>
                    </div>
                  </form>
                </div>

                {/* Published Store Posts List */}
                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-slate-300 flex items-center justify-between">
                    <span>Active Community Posts ({communityPosts.filter((p) => p.sellerId === currentSeller.id).length})</span>
                    <span className="text-xs text-slate-500">Live for store buyers</span>
                  </h3>

                  {communityPosts.filter((p) => p.sellerId === currentSeller.id).length === 0 ? (
                    <div className="bg-slate-900/60 border border-slate-800 p-8 rounded-2xl text-center text-slate-400">
                      <MessageSquare className="w-8 h-8 mx-auto mb-2 text-slate-600" />
                      <p className="font-semibold text-sm text-slate-300">No posts published yet</p>
                      <p className="text-xs mt-1">Publish your first community post above to connect with buyers.</p>
                    </div>
                  ) : (
                    communityPosts
                      .filter((p) => p.sellerId === currentSeller.id)
                      .map((post) => (
                        <div key={post.id} className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-3">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 font-bold text-[10px] border border-amber-500/30">
                                  {post.tag}
                                </span>
                                {post.discountBadge && (
                                  <span className="px-2 py-0.5 rounded-md bg-rose-500/20 text-rose-300 font-bold text-[10px] border border-rose-500/30">
                                    {post.discountBadge}
                                  </span>
                                )}
                                <span className="text-[10px] text-slate-500">{post.createdAt}</span>
                              </div>
                              <h4 className="text-sm font-bold text-white mt-1.5">{post.title}</h4>
                            </div>
                            <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-800">
                              Active
                            </span>
                          </div>

                          <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line">{post.content}</p>

                          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                            <div className="flex items-center gap-4">
                              <button
                                onClick={() => likeCommunityPost(post.id)}
                                className="flex items-center gap-1 hover:text-amber-400 transition"
                              >
                                <ThumbsUp className="w-3.5 h-3.5" />
                                <span>{post.likes} Likes</span>
                              </button>
                              <span className="flex items-center gap-1">
                                <MessageSquare className="w-3.5 h-3.5" />
                                <span>{post?.comments?.length || 0} Comments</span>
                              </span>
                            </div>
                          </div>
                        </div>
                      ))
                  )}
                </div>
              </div>

              {/* Right Column: 1-on-1 Buyer Bargain Offers & Chats */}
              <div className="lg:col-span-5 space-y-6">
                <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4 shadow-md">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div>
                      <h3 className="text-sm font-bold text-white flex items-center gap-2">
                        <MessageSquare className="w-4 h-4 text-emerald-400" />
                        Buyer Bargains & Price Negotiations
                      </h3>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Direct custom quotes and order agreements with buyers
                      </p>
                    </div>
                  </div>

                  {storeChatSessions.filter((c) => c.sellerId === currentSeller.id).length === 0 ? (
                    <div className="bg-slate-800/50 p-6 rounded-xl text-center text-slate-400 space-y-1">
                      <Tag className="w-6 h-6 mx-auto text-slate-600 mb-1" />
                      <p className="text-xs font-semibold text-slate-300">No active bargaining sessions</p>
                      <p className="text-[11px] text-slate-500">
                        When buyers start a price negotiation on your items, they will appear here.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {storeChatSessions
                        .filter((c) => c.sellerId === currentSeller.id)
                        .map((chat) => {
                          const latestOffer = chat.messages
                            .filter((m) => m.bargainOffer)
                            .map((m) => m.bargainOffer!)
                            .slice(-1)?.[0];

                          return (
                            <div
                              key={chat.id}
                              className="bg-slate-800/90 border border-slate-700/80 p-4 rounded-xl space-y-3"
                            >
                              <div className="flex items-center justify-between">
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-bold text-white text-xs">{chat.customerName}</span>
                                    <span className="text-[10px] text-slate-400">{chat.customerPhone}</span>
                                  </div>
                                  <span className="text-[10px] text-slate-500">Last active: {chat.lastActivity}</span>
                                </div>

                                {latestOffer && (
                                  <span
                                    className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${
                                      latestOffer.status === 'PENDING'
                                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse'
                                        : latestOffer.status === 'ACCEPTED' || latestOffer.status === 'ORDERED'
                                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                        : latestOffer.status === 'COUNTERED'
                                        ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                                        : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                                    }`}
                                  >
                                    Offer: {latestOffer.status}
                                  </span>
                                )}
                              </div>

                              {/* Latest Negotiated Product Details */}
                              {latestOffer && (
                                <div className="p-3 bg-slate-900/80 rounded-lg border border-slate-700/60 space-y-2 text-xs">
                                  <div className="flex items-center justify-between">
                                    <span className="font-bold text-white truncate max-w-[200px]">
                                      {latestOffer.productName}
                                    </span>
                                    <span className="text-slate-400 font-mono">Qty: {latestOffer.quantity}</span>
                                  </div>

                                  <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 border-t border-slate-800">
                                    <div>
                                      <span className="text-slate-400 block">Catalog Price:</span>
                                      <span className="text-slate-300 font-bold font-mono">
                                        ₹{latestOffer.originalPrice.toLocaleString('en-IN')}
                                      </span>
                                    </div>
                                    <div>
                                      <span className="text-slate-400 block">Buyer Offered:</span>
                                      <span className="text-amber-400 font-black font-mono">
                                        ₹{latestOffer.offeredPrice.toLocaleString('en-IN')}
                                      </span>
                                    </div>
                                  </div>

                                  {latestOffer.counterPrice && (
                                    <div className="p-1.5 bg-sky-950/60 border border-sky-800 rounded text-[11px] text-sky-300">
                                      <span>Counter Price: ₹{latestOffer.counterPrice.toLocaleString('en-IN')}</span>
                                      {latestOffer.sellerNote && <p className="text-[10px] mt-0.5 text-slate-300">Note: {latestOffer.sellerNote}</p>}
                                    </div>
                                  )}

                                  {/* Seller Action Controls for Pending Offer */}
                                  {latestOffer.status === 'PENDING' && (
                                    <div className="pt-2 border-t border-slate-800 space-y-2">
                                      <div className="flex items-center gap-2">
                                        <button
                                          onClick={() => {
                                            respondToBargainOffer(chat.id, latestOffer.id, 'ACCEPTED');
                                          }}
                                          className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs flex items-center justify-center gap-1 shadow-sm transition"
                                        >
                                          <Check className="w-3.5 h-3.5" />
                                          <span>Accept Offer (₹{latestOffer.offeredPrice})</span>
                                        </button>
                                        <button
                                          onClick={() => {
                                            respondToBargainOffer(chat.id, latestOffer.id, 'REJECTED');
                                          }}
                                          className="py-1.5 px-3 bg-rose-900/60 hover:bg-rose-800 text-rose-300 font-bold rounded-lg text-xs flex items-center justify-center gap-1 border border-rose-700 transition"
                                        >
                                          <XCircle className="w-3.5 h-3.5" />
                                          <span>Decline</span>
                                        </button>
                                      </div>

                                      {/* Counter Offer Input Box */}
                                      <div className="pt-1 flex items-center gap-2">
                                        <input
                                          type="number"
                                          placeholder="Counter Price (₹)"
                                          value={counterPriceInput[latestOffer.id] || ''}
                                          onChange={(e) =>
                                            setCounterPriceInput((prev) => ({
                                              ...prev,
                                              [latestOffer.id]: Number(e.target.value),
                                            }))
                                          }
                                          className="w-32 bg-slate-800 border border-slate-600 rounded-lg px-2.5 py-1 text-xs text-white font-mono"
                                        />
                                        <button
                                          onClick={() => {
                                            const price = counterPriceInput[latestOffer.id];
                                            if (!price || price <= 0) {
                                              showToast('Please enter a valid counter price');
                                              return;
                                            }
                                            respondToBargainOffer(
                                              chat.id,
                                              latestOffer.id,
                                              'COUNTERED',
                                              price,
                                              'Best possible bulk rate from store'
                                            );
                                          }}
                                          className="flex-1 py-1 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-lg text-xs transition"
                                        >
                                          Send Counter-Offer
                                        </button>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              )}

                              {/* Recent Chat Messages Preview */}
                              <div className="pt-1 space-y-1.5">
                                <span className="text-[10px] font-bold text-slate-400 block">Conversation Transcript:</span>
                                <div className="max-h-32 overflow-y-auto space-y-1 pr-1 text-[11px]">
                                  {chat.messages.slice(-3).map((msg) => (
                                    <div
                                      key={msg.id}
                                      className={`p-1.5 rounded-lg ${
                                        msg.senderRole === 'STORE'
                                          ? 'bg-amber-950/40 text-amber-200 border border-amber-800/40 ml-4'
                                          : 'bg-slate-900 text-slate-300 mr-4'
                                      }`}
                                    >
                                      <div className="flex justify-between text-[9px] text-slate-400 mb-0.5">
                                        <span className="font-bold">{msg.senderName}</span>
                                        <span>{msg.timestamp}</span>
                                      </div>
                                      <p>{msg.text}</p>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>
                          );
                        })}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Customer Directory & Direct Engagement Section */}
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4 shadow-md mt-6">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-amber-400" />
                  <div>
                    <h3 className="text-sm font-bold text-white">
                      Customer Community Directory & Direct Connections
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Follow buyers, initiate 1-on-1 chats, and send tailored bulk offers.
                    </p>
                  </div>
                </div>
                <span className="text-xs text-slate-400 font-medium">
                  {customers.length} Registered Buyers Active in Network
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {customers.map((cust) => {
                  const isFollowing = currentSeller.followedCustomerIds?.includes(cust.id) ?? false;
                  return (
                    <div
                      key={cust.id}
                      className="bg-slate-800/80 border border-slate-700/70 p-3.5 rounded-xl flex items-center justify-between gap-3 hover:border-slate-600 transition"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center font-bold text-slate-800 text-xs shrink-0">
                          {cust.name ? cust.name.charAt(0).toUpperCase() : 'C'}
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-xs font-bold text-white truncate">{cust.name || 'Verified Customer'}</h4>
                          <p className="text-[10px] text-slate-400 truncate">📍 {cust.city || 'Indore'} &bull; {cust.phone || '+91 98260 00000'}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => sellerFollowCustomer(cust.id)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition flex items-center gap-1 ${
                            isFollowing
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                              : 'bg-slate-700 hover:bg-slate-600 text-slate-200'
                          }`}
                        >
                          <UserCheck className="w-3 h-3" />
                          <span>{isFollowing ? 'Following' : 'Follow'}</span>
                        </button>

                        <button
                          onClick={() => {
                            startSellerToCustomerChat(cust.id, cust.name || 'Customer');
                          }}
                          className="px-2.5 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-[11px] font-bold transition flex items-center gap-1 shadow-sm"
                        >
                          <MessageSquare className="w-3 h-3" />
                          <span>Chat</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
        {activeTab === 'account-settings' && (
          <div className="mt-6 max-w-4xl mx-auto space-y-6">
            {/* Unique Store Identity & Physical Location Card */}
            <div className="bg-slate-850 border border-slate-700/80 p-6 rounded-2xl shadow-xl space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 flex items-center justify-center font-bold">
                    <Store className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <span>{currentSeller.storeName}</span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                        Verified Physical Location
                      </span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      Unique Store ID: <span className="font-mono text-slate-300">{currentSeller.id}</span> &bull; GSTIN: <span className="font-mono text-slate-300">{currentSeller.gstNumber || '23AABCI9921K1Z5'}</span>
                    </p>
                  </div>
                </div>

                <div className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-300 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-emerald-400" />
                  <span>GPS: {currentSeller.lat?.toFixed(4) || '22.7196'}° N, {currentSeller.lng?.toFixed(4) || '75.8577'}° E</span>
                </div>
              </div>

              <div className="p-3.5 bg-slate-900/90 rounded-xl border border-slate-800 flex items-start gap-3 text-xs">
                <Building2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div className="space-y-0.5 text-slate-300">
                  <span className="font-bold text-white block">Official Street / Physical Store Address:</span>
                  <p className="text-slate-400">
                    {currentSeller.warehouseAddress?.street || 'Shop 12, Maharani Road Market'}, {currentSeller.warehouseAddress?.city || 'Indore'}, {currentSeller.warehouseAddress?.state || 'Madhya Pradesh'} - {currentSeller.warehouseAddress?.pincode || '452007'}, India
                  </p>
                  <span className="text-[11px] text-emerald-400 font-semibold block pt-0.5">
                    ✓ Stores are distinguished by physical street address & GPS coordinates so customers can identify individual branches.
                  </span>
                </div>
              </div>
            </div>

            {/* Service Provider Profile Settings (Electricians, Plumbers, Technicians, Carpenters) */}
            <div className="bg-slate-800/80 border border-slate-700 p-6 rounded-2xl shadow-xl space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-700/60 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-blue-500/20 border border-blue-500/40 text-blue-300 flex items-center justify-center font-bold">
                    <Wrench className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <span>Service Provider & Contractor Profile</span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                        Electrician, Plumber, Technician & Handyman
                      </span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      Configure your visit fee, hourly rates, and emergency service availability. Adding physical products is optional.
                    </p>
                  </div>
                </div>

                <label className="flex items-center gap-2 cursor-pointer bg-slate-900 px-3.5 py-1.5 rounded-xl border border-slate-700">
                  <input
                    type="checkbox"
                    checked={spEnabled}
                    onChange={(e) => setSpEnabled(e.target.checked)}
                    className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                  />
                  <span className="text-xs font-bold text-slate-200">
                    {spEnabled ? '⚡ Active Service Provider' : 'Enable Service Provider Mode'}
                  </span>
                </label>
              </div>

              {spEnabled && (
                <div className="space-y-4 pt-1 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-slate-300 block mb-1 font-semibold">Primary Trade / Service Type</label>
                      <select
                        value={spType}
                        onChange={(e) => setSpType(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-medium focus:outline-none focus:ring-2 focus:ring-amber-500"
                      >
                        <option value="electrician">⚡ Certified Electrician & Wiring</option>
                        <option value="plumber">🚰 Expert Plumber & Pipe Fitting</option>
                        <option value="ac-repair">❄️ AC Service, HVAC & Appliance Repair</option>
                        <option value="carpenter">🪚 Carpenter & Furniture Assembly</option>
                        <option value="handyman">🛠️ General Handyman & Home Maintenance</option>
                        <option value="tailor">✂️ Custom Tailor & Alteration Service</option>
                        <option value="cleaning">🧹 Home Deep Cleaning & Sanitization</option>
                        <option value="contractor">🏗️ Commercial & Electrical Contractor</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-semibold">Service Coverage Radius</label>
                      <select
                        value={spRadius}
                        onChange={(e) => setSpRadius(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-emerald-400 font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
                      >
                        <option value={5}>5 km (Immediate Neighborhood)</option>
                        <option value={10}>10 km (Standard Local Area)</option>
                        <option value={15}>15 km (Greater City Area)</option>
                        <option value={20}>20 km (Maximum Permitted Range)</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="text-slate-300 block mb-1 font-semibold">Diagnostic / Visiting Fee (₹)</label>
                      <input
                        type="number"
                        min={0}
                        step={50}
                        value={spVisitFee}
                        onChange={(e) => setSpVisitFee(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-amber-400 font-bold focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                      />
                      <span className="text-[10px] text-slate-400 mt-0.5 block">Standard inspection charge per visit</span>
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-semibold">Hourly Labor Rate (₹/hr)</label>
                      <input
                        type="number"
                        min={0}
                        step={50}
                        value={spHourlyRate}
                        onChange={(e) => setSpHourlyRate(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                      />
                      <span className="text-[10px] text-slate-400 mt-0.5 block">Hourly rate for repairs / installations</span>
                    </div>

                    <div className="flex flex-col justify-end">
                      <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-900 border border-slate-700 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={spEmergency}
                          onChange={(e) => setSpEmergency(e.target.checked)}
                          className="w-4 h-4 rounded accent-emerald-500 cursor-pointer"
                        />
                        <div>
                          <span className="font-bold text-white block text-[11px]">24/7 Emergency Dispatch</span>
                          <span className="text-[10px] text-emerald-400">Accept urgent short-notice calls</span>
                        </div>
                      </label>
                    </div>
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      type="button"
                      disabled={isSavingSp}
                      onClick={async () => {
                        setIsSavingSp(true);
                        await updateSellerProfile(currentSeller.id, {
                          isServiceProvider: spEnabled,
                          serviceType: spType as any,
                          serviceVisitFee: spVisitFee,
                          serviceHourlyRate: spHourlyRate,
                          serviceEmergencyAvailable: spEmergency,
                          deliveryRadiusKm: spRadius,
                        });
                        setIsSavingSp(false);
                        showToast(`✓ Updated Service Profile (${spType.toUpperCase()}) for ${currentSeller.storeName}!`);
                      }}
                      className="px-5 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md"
                    >
                      <Check className="w-4 h-4" />
                      <span>{isSavingSp ? 'Saving Rates...' : 'Save Service Configuration'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Store Account Lifecycle & Deletion */}
            <div className="bg-slate-800/80 border border-slate-700 p-6 rounded-2xl shadow-xl">
              <h3 className="text-base font-bold text-white flex items-center gap-2 mb-1">
                <ShieldCheck className="w-5 h-5 text-amber-400" />
                Store Account Management & Lifecycle
              </h3>
              <p className="text-xs text-slate-400 mb-6">
                Manage your store activation, delivery radius (10–20 km), and account deactivation/deletion.
              </p>

              <div className="space-y-4 divide-y divide-slate-700/60 text-xs">
                <div className="pt-3 flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-white">Store Active Status</h4>
                    <p className="text-slate-400">
                      When active, products and services from {currentSeller.storeName} appear in customer search and catalog.
                    </p>
                  </div>
                  <button
                    onClick={() => toggleSellerStatus(currentSeller.id)}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-xl font-bold transition-all ${
                      currentSeller.isActive
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30 hover:bg-rose-500/30'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/30'
                    }`}
                  >
                    <Power className="w-4 h-4" />
                    <span>{currentSeller.isActive ? 'Deactivate Store' : 'Activate Store'}</span>
                  </button>
                </div>

                <div className="pt-3 flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-white">Hyperlocal Delivery Radius</h4>
                    <p className="text-slate-400">
                      Default 10 km (free/standard tier), maximum allowable 20 km for hyperlocal express dispatch.
                    </p>
                  </div>
                  <select
                    value={currentSeller.deliveryRadiusKm || 15}
                    onChange={(e) => updateSellerProfile(currentSeller.id, { deliveryRadiusKm: Number(e.target.value) })}
                    className="bg-slate-900 text-emerald-400 font-bold border border-slate-700 rounded-lg px-3 py-1.5"
                  >
                    <option value={10}>10 km (Standard Local)</option>
                    <option value={15}>15 km (Greater City Area)</option>
                    <option value={20}>20 km (Maximum Permitted Range)</option>
                  </select>
                </div>

                <div className="pt-3 flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-white">Seller Registration Reward</h4>
                    <p className="text-slate-400">
                      Verified onboarding bonus credited upon store approval.
                    </p>
                  </div>
                  <span className="px-3 py-1 bg-amber-500/20 text-amber-300 font-bold rounded-lg border border-amber-500/30">
                    ₹2,500 Joining Credit Claimed
                  </span>
                </div>

                <div className="pt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-rose-500/30">
                  <div>
                    <h4 className="font-bold text-rose-400">Permanently Delete Store Account</h4>
                    <p className="text-slate-400">
                      Permanently unlists store products, release mobile number <strong className="text-white">{currentSeller.phone}</strong> so you can immediately register or log in as a Customer or Driver.
                    </p>
                  </div>
                  <button
                    id="btn-delete-seller-store-portal"
                    onClick={async () => {
                      if (
                        window.confirm(
                          `Are you sure you want to delete store "${currentSeller.storeName}"? This will free up your mobile number (${currentSeller.phone}) to be used for Customer or Driver login.`
                        )
                      ) {
                        await deleteSellerAccountPermanently(currentSeller.id);
                      }
                    }}
                    className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold transition-all shadow-md shrink-0"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Delete Store & Free Number</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* EDIT PRODUCT MODAL */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 bg-white/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <Edit2 className="w-4 h-4 text-amber-400" />
                Edit SKU: {editingProduct.name}
              </h3>
              <button onClick={() => setEditingProduct(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 block mb-1 font-semibold">Title</label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">Price (₹)</label>
                  <input
                    type="number"
                    value={editPrice}
                    onChange={(e) => setEditPrice(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-amber-400 font-bold"
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">MRP (₹)</label>
                  <input
                    type="number"
                    value={editMrp}
                    onChange={(e) => setEditMrp(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-300"
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">Stock Units</label>
                  <input
                    type="number"
                    value={editStock}
                    onChange={(e) => setEditStock(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-emerald-400 font-bold"
                  />
                </div>
              </div>

              {/* Edit Wholesale & Dealership Fields */}
              <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-200">
                  <input
                    type="checkbox"
                    checked={editIsWholesale}
                    onChange={(e) => setEditIsWholesale(e.target.checked)}
                    className="w-4 h-4 rounded accent-amber-500"
                  />
                  <span>📦 Wholesaler B2B Bulk Product</span>
                </label>

                {editIsWholesale && (
                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-700">
                    <div>
                      <label className="text-slate-400 block mb-1">Minimum Order Qty (MOQ)</label>
                      <input
                        type="number"
                        min={1}
                        value={editMinOrderQuantity}
                        onChange={(e) => setEditMinOrderQuantity(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-amber-500/50 rounded-xl px-3 py-1.5 text-amber-300 font-bold"
                      />
                    </div>
                    <div>
                      <label className="text-slate-400 block mb-1">Wholesale Unit Rate (₹/unit)</label>
                      <input
                        type="number"
                        min={1}
                        value={editWholesaleUnitPrice || (editMinOrderQuantity > 0 ? Math.round(editPrice / editMinOrderQuantity) : 0)}
                        onChange={(e) => setEditWholesaleUnitPrice(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
                      />
                    </div>
                  </div>
                )}

                <div className="flex gap-4 pt-1 text-slate-300">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editIsDealership}
                      onChange={(e) => setEditIsDealership(e.target.checked)}
                      className="w-3.5 h-3.5 rounded accent-amber-500"
                    />
                    <span>🏭 Dealership</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editIsSingleVendor}
                      onChange={(e) => setEditIsSingleVendor(e.target.checked)}
                      className="w-3.5 h-3.5 rounded accent-amber-500"
                    />
                    <span>🏬 Single Seller Vendor</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">Description</label>
                <textarea
                  rows={3}
                  value={editDesc}
                  onChange={(e) => setEditDesc(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                onClick={() => setEditingProduct(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveProductEdit}
                className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-800 rounded-xl text-xs font-bold shadow-md"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* NEW STORE REGISTRATION MODAL */}
      {isRegisterModalOpen && (
        <div className="fixed inset-0 z-50 bg-white/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Store className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-white text-base">Register New Merchant Store</h3>
              </div>
              <button onClick={() => setIsRegisterModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center gap-2 text-xs text-amber-300">
              <Gift className="w-4 h-4 shrink-0 text-amber-400" />
              <span>₹2,500 Store Onboarding Credit will be awarded directly upon registration!</span>
            </div>

            <form onSubmit={handleRegisterStore} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 block mb-1 font-semibold">Store / Brand Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Indore Electricals / Glamour Luxe Cosmetics / Royal Malwa Furniture"
                  value={regStoreName}
                  onChange={(e) => setRegStoreName(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">Store Business Type *</label>
                  <select
                    value={regCategory}
                    onChange={(e) => setRegCategory(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="toys">🧸 Toys & Kids Games Wholesaler</option>
                    <option value="men">👕 Men's Wear & T-Shirt Wholesaler</option>
                    <option value="electrical">⚡ Electrician & Electrical Dealership Mart</option>
                    <option value="cosmetics">💄 Cosmetics & Beauty Studio</option>
                    <option value="furniture">🪑 Furniture & Home Living</option>
                    <option value="ethnic-wear">👗 Fashion, Cloths & Sarees</option>
                    <option value="commercial-hardware">🛠️ Commercial & Contractor Supplies</option>
                    <option value="electronics">📱 Electronics & Smart Devices</option>
                    <option value="grocery">🛒 Supermarket & Daily Mart</option>
                    <option value="custom">➕ Other / Custom Account Type</option>
                  </select>
                </div>

                {regCategory === 'custom' ? (
                  <div>
                    <label className="text-slate-300 block mb-1 font-semibold text-amber-400">Custom Business Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Electrician Services, Bakery"
                      value={regCustomCategory}
                      onChange={(e) => setRegCustomCategory(e.target.value)}
                      className="w-full bg-slate-800 border border-amber-500/50 rounded-xl px-3 py-2 text-white"
                    />
                  </div>
                ) : (
                  <div>
                    <label className="text-slate-300 block mb-1 font-semibold">Owner Name</label>
                    <input
                      type="text"
                      placeholder="Owner full name"
                      value={regOwnerName}
                      onChange={(e) => setRegOwnerName(e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    />
                  </div>
                )}
              </div>

              {/* Wholesale / Dealership Account Setup for Sellers */}
              <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700 space-y-2">
                <span className="text-[11px] font-bold text-amber-300 block">
                  Wholesale & Dealership Account Capabilities:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={regIsWholesaleSeller}
                      onChange={(e) => setRegIsWholesaleSeller(e.target.checked)}
                      className="w-4 h-4 rounded accent-amber-500"
                    />
                    <span>🏭 Wholesaler Account (Bulk MOQ Lots)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={regIsDealership}
                      onChange={(e) => setRegIsDealership(e.target.checked)}
                      className="w-4 h-4 rounded accent-amber-500"
                    />
                    <span>🏬 Dealership & Single Vendor</span>
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {regCategory === 'custom' && (
                  <div>
                    <label className="text-slate-300 block mb-1 font-semibold">Owner Name</label>
                    <input
                      type="text"
                      placeholder="Owner full name"
                      value={regOwnerName}
                      onChange={(e) => setRegOwnerName(e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    />
                  </div>
                )}
                <div className={regCategory === 'custom' ? 'col-span-1' : 'col-span-2'}>
                  <label className="text-slate-300 block mb-1 font-semibold">City</label>
                  <select
                    value={regCity}
                    onChange={(e) => setRegCity(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="Indore">Indore (Madhya Pradesh)</option>
                    <option value="Bhopal">Bhopal</option>
                    <option value="Mumbai">Mumbai</option>
                    <option value="Delhi">Delhi NCR</option>
                    <option value="Bengaluru">Bengaluru</option>
                    <option value="Jaipur">Jaipur</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">Street / Market Address</label>
                <input
                  type="text"
                  placeholder="e.g. Shop 12, Rajwada Cloth Market, MG Road"
                  value={regStreet}
                  onChange={(e) => setRegStreet(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">Phone Number</label>
                  <input
                    type="text"
                    placeholder="+91 98260 11223"
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">GSTIN</label>
                  <input
                    type="text"
                    placeholder="23AABCI9921K1Z5"
                    value={regGst}
                    onChange={(e) => setRegGst(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">
                  Hyperlocal Delivery Radius ({regRadiusKm} km)
                </label>
                <input
                  type="range"
                  min={5}
                  max={20}
                  step={1}
                  value={regRadiusKm}
                  onChange={(e) => setRegRadiusKm(Number(e.target.value))}
                  className="w-full accent-amber-500"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>5 km</span>
                  <span>10 km (Standard)</span>
                  <span>20 km (Max Range)</span>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsRegisterModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isRegistering}
                  className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-800 rounded-xl text-xs font-bold shadow-md"
                >
                  {isRegistering ? 'Registering...' : 'Register Store & Claim ₹2,500'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* BULK PRODUCT UPLOAD MODAL */}
      <BulkProductUploadModal
        isOpen={isBulkUploadOpen}
        onClose={() => setIsBulkUploadOpen(false)}
      />

      {/* PRODUCT INVENTORY QR CODE MODAL */}
      <ProductInventoryQRModal
        isOpen={isQRModalOpen}
        onClose={() => setIsQRModalOpen(false)}
        product={selectedQRProduct}
      />
    </div>
  );
};
