import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Camera,
  RefreshCw,
  Sparkles,
  Flame,
  Check,
  Send,
  Video,
  Smile,
  Zap,
} from 'lucide-react';

interface ChatCameraModalProps {
  chatId: string;
  onClose: () => void;
  onSendSnap: (mediaUrl: string, caption: string, isViewOnce: boolean) => void;
}

const SAMPLE_CAPTURE_SHOTS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=600&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=600&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=600&auto=format&fit=crop&q=80',
];

export const ChatCameraModal: React.FC<ChatCameraModalProps> = ({
  chatId,
  onClose,
  onSendSnap,
}) => {
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isViewOnce, setIsViewOnce] = useState(true);
  const [caption, setCaption] = useState('');
  const [filterIdx, setFilterIdx] = useState(0);
  const [cameraMode, setCameraMode] = useState<'photo' | 'video'>('photo');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);

  const filters = [
    { name: 'Normal', filterClass: 'brightness-100' },
    { name: 'Warm Glow', filterClass: 'sepia-[0.25] saturate-125 contrast-105' },
    { name: 'Cool Chic', filterClass: 'hue-rotate-15 contrast-110' },
    { name: 'Vibrant', filterClass: 'saturate-150 contrast-115' },
    { name: 'B&W Luxe', filterClass: 'grayscale contrast-125' },
  ];

  const handleCapture = () => {
    const randomShot =
      SAMPLE_CAPTURE_SHOTS[Math.floor(Math.random() * SAMPLE_CAPTURE_SHOTS.length)];
    setCapturedImage(randomShot);
  };

  const handleSend = () => {
    if (!capturedImage) return;
    onSendSnap(capturedImage, caption, isViewOnce);
    onClose();
  };

  return (
    <div
      id="chat-camera-modal"
      className="fixed inset-0 z-50 bg-white flex flex-col items-center justify-between p-4 text-white animate-fade-in select-none"
    >
      {/* Top Navigation */}
      <div className="w-full max-w-md flex items-center justify-between z-10 pt-2">
        <button
          onClick={onClose}
          className="p-2.5 rounded-full bg-slate-900/60 hover:bg-slate-900/90 text-white backdrop-blur-md"
        >
          <X className="w-6 h-6" />
        </button>

        {capturedImage ? (
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsViewOnce(!isViewOnce)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 transition ${
                isViewOnce
                  ? 'bg-amber-500 text-slate-800 shadow-lg shadow-amber-500/30'
                  : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              <Flame className="w-4 h-4" />
              <span>{isViewOnce ? 'View-Once (10s)' : 'Save in Chat'}</span>
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <button
              onClick={() =>
                setFilterIdx((prev) => (prev + 1) % filters.length)
              }
              className="p-2 rounded-full bg-slate-900/60 hover:bg-slate-900/90 text-amber-300 backdrop-blur-md flex items-center gap-1 text-xs font-semibold px-3"
            >
              <Sparkles className="w-4 h-4" />
              <span>{filters[filterIdx].name}</span>
            </button>
          </div>
        )}
      </div>

      {/* Main Viewfinder / Captured Preview */}
      <div className="w-full max-w-md flex-1 flex flex-col items-center justify-center relative my-auto">
        <div className="relative w-full aspect-3/4 max-h-[520px] rounded-3xl overflow-hidden shadow-2xl border border-white/20 bg-zinc-900">
          {capturedImage ? (
            <img
              src={capturedImage}
              alt="Captured Snap"
              className={`w-full h-full object-cover ${filters[filterIdx].filterClass}`}
            />
          ) : (
            <div className="w-full h-full relative flex items-center justify-center bg-zinc-950 overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600&auto=format&fit=crop&q=80"
                alt="Live Camera Viewfinder"
                className={`w-full h-full object-cover filter ${filters[filterIdx].filterClass}`}
              />
              <div className="absolute inset-0 border-2 border-white/20 rounded-3xl pointer-events-none" />

              {/* Grid overlay */}
              <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 pointer-events-none opacity-20">
                <div className="border-r border-b border-white" />
                <div className="border-r border-b border-white" />
                <div className="border-b border-white" />
                <div className="border-r border-b border-white" />
                <div className="border-r border-b border-white" />
                <div className="border-b border-white" />
                <div className="border-r border-white" />
                <div className="border-r border-white" />
                <div />
              </div>

              {isRecording && (
                <div className="absolute top-4 left-4 bg-rose-600 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1.5 animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-white" />
                  <span>REC 00:{recordingSeconds.toString().padStart(2, '0')}</span>
                </div>
              )}
            </div>
          )}

          {/* Caption Overlay when captured */}
          {capturedImage && (
            <div className="absolute bottom-4 left-4 right-4 z-10">
              <input
                type="text"
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                placeholder="Add a caption or snap note..."
                className="w-full bg-slate-900/80 backdrop-blur-md text-white text-sm px-4 py-3 rounded-2xl border border-white/20 focus:outline-none focus:border-amber-400 placeholder:text-zinc-400"
              />
            </div>
          )}
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="w-full max-w-md pb-6 flex flex-col items-center gap-4">
        {capturedImage ? (
          <div className="w-full flex items-center justify-between px-6">
            <button
              onClick={() => setCapturedImage(null)}
              className="p-4 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold text-xs flex items-center gap-1.5"
            >
              <RefreshCw className="w-5 h-5" />
              <span>Retake</span>
            </button>

            <button
              id="btn-send-snap"
              onClick={handleSend}
              className="px-6 py-4 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-white font-extrabold text-sm flex items-center gap-2 shadow-xl shadow-amber-500/30 active:scale-95 transition"
            >
              <span>Send Snap</span>
              <Send className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="w-full flex items-center justify-around">
            <button
              onClick={() =>
                setFilterIdx((prev) => (prev + 1) % filters.length)
              }
              className="p-3.5 rounded-full bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300"
              title="Filters"
            >
              <Sparkles className="w-6 h-6" />
            </button>

            {/* Shutter Button */}
            <button
              id="btn-shutter-capture"
              onClick={handleCapture}
              className="w-20 h-20 rounded-full border-4 border-white p-1.5 hover:scale-105 active:scale-95 transition flex items-center justify-center bg-white/20 backdrop-blur-md shadow-2xl"
            >
              <div className="w-full h-full rounded-full bg-white transition hover:bg-amber-400" />
            </button>

            <button
              onClick={() => {
                setFilterIdx(Math.floor(Math.random() * filters.length));
              }}
              className="p-3.5 rounded-full bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300"
              title="Flip Camera"
            >
              <RefreshCw className="w-6 h-6" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
