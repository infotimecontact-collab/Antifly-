import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  PhoneOff,
  Mic,
  MicOff,
  Video,
  VideoOff,
  Volume2,
  VolumeX,
  Minimize2,
  Maximize2,
  ShieldCheck,
  Sparkles,
  Zap,
} from 'lucide-react';

export const ActiveCallOverlay: React.FC = () => {
  const { activeCall, endCall, toggleCallMute, toggleCallCamera, toggleCallSpeaker } = useApp();
  const [seconds, setSeconds] = useState(0);
  const [isMinimized, setIsMinimized] = useState(false);

  useEffect(() => {
    if (!activeCall || activeCall.status !== 'connected') {
      setSeconds(0);
      return;
    }
    const interval = setInterval(() => {
      setSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [activeCall?.status]);

  if (!activeCall || !activeCall.isOpen) return null;

  const partner = activeCall.partner;
  const isVideo = activeCall.type === 'video';
  const mins = Math.floor(seconds / 60);
  const secs = (seconds % 60).toString().padStart(2, '0');

  if (isMinimized) {
    return (
      <div
        id="call-minimized-floating"
        className="fixed bottom-20 right-4 z-50 bg-slate-900 text-white rounded-2xl p-3 shadow-2xl border border-slate-700 flex items-center gap-3 backdrop-blur-md animate-slide-up"
      >
        <img
          src={partner.avatar}
          alt={partner.name}
          className="w-10 h-10 rounded-full object-cover border-2 border-emerald-500"
        />
        <div>
          <h4 className="text-xs font-bold line-clamp-1">{partner.name}</h4>
          <p className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping inline-block" />
            {activeCall.status === 'ringing' ? 'Ringing...' : `${mins}:${secs}`}
          </p>
        </div>
        <div className="flex items-center gap-1.5 ml-2">
          <button
            onClick={() => setIsMinimized(false)}
            className="p-2 bg-slate-800 hover:bg-slate-700 rounded-full text-slate-300"
            title="Expand Call"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
          <button
            onClick={endCall}
            className="p-2 bg-rose-600 hover:bg-rose-700 rounded-full text-white"
            title="End Call"
          >
            <PhoneOff className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      id="active-call-modal-overlay"
      className="fixed inset-0 z-50 bg-white/90 backdrop-blur-md flex flex-col items-center justify-between p-6 text-white animate-fade-in select-none"
    >
      {/* Top Bar */}
      <div className="w-full max-w-md flex items-center justify-between z-10">
        <button
          onClick={() => setIsMinimized(true)}
          className="p-2.5 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition"
          title="Minimize call"
        >
          <Minimize2 className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-800/80 rounded-full text-xs font-semibold text-slate-300">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>End-to-End Encrypted</span>
        </div>
        <div className="w-9" />
      </div>

      {/* Main Content Area */}
      <div className="w-full max-w-md flex-1 flex flex-col items-center justify-center my-auto relative">
        {isVideo && !activeCall.isCameraOff ? (
          <div className="w-full aspect-3/4 max-h-[460px] relative rounded-3xl overflow-hidden shadow-2xl border border-slate-700 bg-slate-900">
            {/* Remote Simulated Video */}
            <img
              src={
                partner.avatar ||
                'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80'
              }
              alt={partner.name}
              className="w-full h-full object-cover filter brightness-95"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-slate-950/40" />

            {/* Self Video PIP */}
            <div className="absolute top-4 right-4 w-28 h-36 rounded-2xl overflow-hidden border-2 border-white/40 shadow-xl bg-slate-800">
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80"
                alt="Self"
                className="w-full h-full object-cover"
              />
              <span className="absolute bottom-1 left-2 text-[9px] font-bold text-white bg-slate-900/70 px-1.5 py-0.5 rounded">
                You
              </span>
            </div>

            {/* Partner Info Overlay */}
            <div className="absolute bottom-4 left-4 right-4 text-left">
              <h3 className="text-xl font-extrabold text-white flex items-center gap-2">
                {partner.name}
                {partner.isVerified && (
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                )}
              </h3>
              <p className="text-xs text-emerald-400 font-mono">
                {activeCall.status === 'ringing' ? 'Calling...' : `Live HD Video • ${mins}:${secs}`}
              </p>
            </div>
          </div>
        ) : (
          /* Voice Call View */
          <div className="flex flex-col items-center text-center">
            <div className="relative mb-6">
              <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-slate-700 shadow-2xl relative">
                <img
                  src={partner.avatar}
                  alt={partner.name}
                  className="w-full h-full object-cover"
                />
              </div>
              {activeCall.status === 'connected' && (
                <div className="absolute -inset-2 rounded-full border-2 border-emerald-500/40 animate-ping" />
              )}
            </div>

            <h3 className="text-2xl font-extrabold tracking-tight mb-1">{partner.name}</h3>
            {partner.storeName && (
              <p className="text-xs font-semibold text-emerald-400 mb-2">
                {partner.storeName}
              </p>
            )}

            <div className="px-3.5 py-1 rounded-full bg-slate-800/90 text-sm font-mono text-slate-300 mb-6 flex items-center gap-2">
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  activeCall.status === 'connected' ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400 animate-bounce'
                }`}
              />
              <span>
                {activeCall.status === 'ringing'
                  ? 'Ringing...'
                  : `${mins}:${secs} • High-Fidelity Audio`}
              </span>
            </div>

            {/* Audio Wave Visualizer Simulation */}
            {activeCall.status === 'connected' && (
              <div className="flex items-center gap-1.5 h-8 my-2">
                {[40, 75, 90, 50, 85, 100, 60, 45, 80, 95, 70, 40].map((h, i) => (
                  <span
                    key={i}
                    style={{ height: `${h}%` }}
                    className="w-1 bg-emerald-400 rounded-full animate-pulse"
                  />
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Call Controls Bar */}
      <div className="w-full max-w-md bg-slate-900/90 backdrop-blur-lg border border-slate-800 rounded-3xl p-4 flex items-center justify-around shadow-2xl z-10">
        {/* Mute Button */}
        <button
          onClick={toggleCallMute}
          className={`p-4 rounded-full transition flex flex-col items-center gap-1 ${
            activeCall.isMuted
              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
              : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
          }`}
          title={activeCall.isMuted ? 'Unmute' : 'Mute'}
        >
          {activeCall.isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
          <span className="text-[10px] font-medium">{activeCall.isMuted ? 'Muted' : 'Mute'}</span>
        </button>

        {/* Video Toggle Button (if video call) */}
        {isVideo && (
          <button
            onClick={toggleCallCamera}
            className={`p-4 rounded-full transition flex flex-col items-center gap-1 ${
              activeCall.isCameraOff
                ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
            }`}
            title={activeCall.isCameraOff ? 'Turn on Camera' : 'Turn off Camera'}
          >
            {activeCall.isCameraOff ? (
              <VideoOff className="w-6 h-6" />
            ) : (
              <Video className="w-6 h-6" />
            )}
            <span className="text-[10px] font-medium">Camera</span>
          </button>
        )}

        {/* Speaker Button */}
        <button
          onClick={toggleCallSpeaker}
          className={`p-4 rounded-full transition flex flex-col items-center gap-1 ${
            activeCall.isSpeaker
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
              : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
          }`}
          title={activeCall.isSpeaker ? 'Speaker On' : 'Speaker Off'}
        >
          {activeCall.isSpeaker ? (
            <Volume2 className="w-6 h-6" />
          ) : (
            <VolumeX className="w-6 h-6" />
          )}
          <span className="text-[10px] font-medium">Speaker</span>
        </button>

        {/* End Call Button */}
        <button
          id="btn-end-call"
          onClick={endCall}
          className="p-4 bg-rose-600 hover:bg-rose-700 active:scale-95 text-white rounded-full transition flex flex-col items-center gap-1 shadow-lg shadow-rose-600/30"
          title="End Call"
        >
          <PhoneOff className="w-6 h-6" />
          <span className="text-[10px] font-bold">End</span>
        </button>
      </div>
    </div>
  );
};
