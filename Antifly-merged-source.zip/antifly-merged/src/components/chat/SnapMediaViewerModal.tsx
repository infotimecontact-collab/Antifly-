import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { ViewOnceSnapData } from '../../types';
import { X, Flame, ShieldAlert, Camera, Sparkles, Clock } from 'lucide-react';

interface SnapMediaViewerModalProps {
  snap: ViewOnceSnapData;
  chatId: string;
  messageId: string;
  senderName: string;
  onClose: () => void;
}

export const SnapMediaViewerModal: React.FC<SnapMediaViewerModalProps> = ({
  snap,
  chatId,
  messageId,
  senderName,
  onClose,
}) => {
  const { simulateScreenshotAlert, showToast } = useApp();
  const [timeLeft, setTimeLeft] = useState<number>(snap.durationSec || 10);
  const totalSec = snap.durationSec || 10;

  useEffect(() => {
    if (timeLeft <= 0) {
      onClose();
      return;
    }
    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [timeLeft, onClose]);

  const handleTakeScreenshot = () => {
    simulateScreenshotAlert(chatId);
    showToast('📸 Screenshot taken! The sender has been notified.');
  };

  const progressPercent = ((totalSec - timeLeft) / totalSec) * 100;

  return (
    <div
      id="snap-view-once-modal"
      className="fixed inset-0 z-50 bg-white flex flex-col items-center justify-between p-4 text-white animate-fade-in select-none"
    >
      {/* Top Header Bar with Countdown Bar */}
      <div className="w-full max-w-lg z-10 pt-2">
        {/* Progress bar */}
        <div className="w-full h-1.5 bg-white/20 rounded-full overflow-hidden mb-3">
          <div
            className="h-full bg-amber-400 transition-all duration-1000 ease-linear rounded-full"
            style={{ width: `${100 - progressPercent}%` }}
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 font-bold text-xs">
              <Flame className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-white leading-tight">{senderName}</p>
              <p className="text-[10px] text-amber-300 font-medium">
                View-Once Media • Closes in {timeLeft}s
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Screenshot simulation button */}
            <button
              onClick={handleTakeScreenshot}
              className="px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-semibold flex items-center gap-1 text-slate-200 transition active:scale-95"
              title="Take Screenshot"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Capture</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Snap Content */}
      <div className="w-full max-w-lg flex-1 flex items-center justify-center relative my-auto">
        <div className="relative w-full max-h-[75vh] rounded-3xl overflow-hidden shadow-2xl border border-white/10 flex items-center justify-center bg-zinc-950">
          <img
            src={snap.mediaUrl}
            alt="View Once Snap"
            className="w-full h-auto max-h-[75vh] object-contain"
          />

          {snap.caption && (
            <div className="absolute bottom-6 left-4 right-4 bg-slate-900/80 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/10 text-center">
              <p className="text-sm font-semibold text-white">{snap.caption}</p>
            </div>
          )}
        </div>
      </div>

      {/* Footer Info */}
      <div className="w-full max-w-lg text-center pb-4">
        <p className="text-[11px] text-slate-400 flex items-center justify-center gap-1.5">
          <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
          <span>Burn-after-reading active. Screenshots will alert the conversation.</span>
        </p>
      </div>
    </div>
  );
};
