import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Search,
  Plus,
  Pin,
  ShieldCheck,
  Check,
  CheckCheck,
  VolumeX,
  Sparkles,
  Flame,
  ShoppingBag,
  Store,
  User,
  Users,
  Clock,
  ArrowRight,
  X,
  Phone,
  Video,
} from 'lucide-react';
import { StoreChatSession, ChatPartnerUser } from '../../types';

interface ChatInboxProps {
  onSelectChat: (session: StoreChatSession) => void;
  selectedChatId: string | null;
}

export const ChatInbox: React.FC<ChatInboxProps> = ({
  onSelectChat,
  selectedChatId,
}) => {
  const {
    storeChatSessions,
    sellers,
    phoneContacts,
    startDirectChatWithUser,
    acceptMessageRequest,
    declineMessageRequest,
    togglePinChat,
    toggleMuteChat,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'unread' | 'requests' | 'businesses'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isNewChatModalOpen, setIsNewChatModalOpen] = useState(false);
  const [newChatSearch, setNewChatSearch] = useState('');

  // Filtering
  const filteredSessions = storeChatSessions.filter((session) => {
    // Search query filter
    const matchesSearch =
      session.storeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (session.customerName && session.customerName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (session.partnerUser?.name && session.partnerUser.name.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesSearch) return false;

    if (activeTab === 'unread') {
      return (session.unreadCount || 0) > 0;
    }
    if (activeTab === 'requests') {
      return session.isMessageRequest === true;
    }
    if (activeTab === 'businesses') {
      return !!session.sellerId;
    }
    return true;
  });

  const pinnedSessions = filteredSessions.filter((s) => s.isPinned);
  const regularSessions = filteredSessions.filter((s) => !s.isPinned);

  const totalUnread = storeChatSessions.reduce((acc, s) => acc + (s.unreadCount || 0), 0);
  const requestCount = storeChatSessions.filter((s) => s.isMessageRequest).length;

  const handleStartNewChatWithSeller = (seller: any) => {
    startDirectChatWithUser({
      id: seller.id,
      name: seller.storeName,
      avatar: seller.logoImage || 'https://images.unsplash.com/photo-1535378917042-10a22c95931a?w=150&auto=format&fit=crop&q=80',
      isOnline: true,
      lastSeen: 'Active now',
      storeName: seller.storeName,
      isVerified: true,
    });
    setIsNewChatModalOpen(false);
  };

  const sampleDirectoryUsers: ChatPartnerUser[] = [
    {
      id: 'usr-901',
      name: 'Priya Sharma (Fashion Designer)',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      role: 'seller',
      isOnline: true,
      lastSeen: 'Active now',
      isVerified: true,
    },
    {
      id: 'usr-902',
      name: 'Aarav Patel (Gourmet Chef)',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      role: 'seller',
      isOnline: false,
      lastSeen: '15m ago',
      isVerified: true,
    },
    {
      id: 'usr-903',
      name: 'Neha Kapoor (Stylist)',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
      role: 'customer',
      isOnline: true,
      lastSeen: 'Active now',
      isVerified: false,
    },
  ];

  return (
    <div
      id="chat-inbox-container"
      className="w-full h-full flex flex-col bg-white border-r border-slate-200 select-none"
    >
      {/* Inbox Header */}
      <div className="p-4 border-b border-slate-100 bg-white">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">Messages</h2>
            {totalUnread > 0 && (
              <span className="bg-indigo-600 text-white text-[11px] font-extrabold px-2 py-0.5 rounded-full">
                {totalUnread}
              </span>
            )}
          </div>

          <button
            id="btn-new-direct-chat"
            onClick={() => setIsNewChatModalOpen(true)}
            className="p-2 bg-indigo-50 hover:bg-indigo-600 text-indigo-600 hover:text-white rounded-full transition shadow-xs flex items-center justify-center cursor-pointer"
            title="Start New Conversation"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        {/* Search Inbox */}
        <div className="relative mb-3">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search chats, stores, people..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-900 focus:outline-none focus:border-indigo-500 focus:bg-white transition"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-1">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 rounded-full text-xs font-bold transition whitespace-nowrap ${
              activeTab === 'all'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All
          </button>

          <button
            onClick={() => setActiveTab('unread')}
            className={`px-3 py-1.5 rounded-full text-xs font-bold transition whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'unread'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>Unread</span>
            {totalUnread > 0 && (
              <span className="w-2 h-2 rounded-full bg-indigo-500 inline-block" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('requests')}
            className={`px-3 py-1.5 rounded-full text-xs font-bold transition whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'requests'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>Requests</span>
            {requestCount > 0 && (
              <span className="bg-amber-500 text-slate-800 text-[10px] font-extrabold px-1.5 py-0.2 rounded-full">
                {requestCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('businesses')}
            className={`px-3 py-1.5 rounded-full text-xs font-bold transition whitespace-nowrap flex items-center gap-1 ${
              activeTab === 'businesses'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Store className="w-3 h-3 text-emerald-600" />
            <span>Stores</span>
          </button>
        </div>
      </div>

      {/* Chat Session List */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
        {filteredSessions.length === 0 ? (
          <div className="p-8 text-center text-slate-400">
            <p className="text-xs font-semibold">No conversations found</p>
          </div>
        ) : (
          <>
            {/* Pinned Chats */}
            {pinnedSessions.length > 0 && (
              <div className="bg-slate-50/50">
                <div className="px-4 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                  <Pin className="w-3 h-3 text-indigo-600" />
                  <span>Pinned Chats</span>
                </div>
                {pinnedSessions.map((session) => (
                  <ChatInboxItem
                    key={session.id}
                    session={session}
                    isSelected={session.id === selectedChatId}
                    onSelect={() => onSelectChat(session)}
                    onAcceptRequest={() => acceptMessageRequest(session.id)}
                    onDeclineRequest={() => declineMessageRequest(session.id)}
                  />
                ))}
              </div>
            )}

            {/* Regular Chats */}
            {regularSessions.map((session) => (
              <ChatInboxItem
                key={session.id}
                session={session}
                isSelected={session.id === selectedChatId}
                onSelect={() => onSelectChat(session)}
                onAcceptRequest={() => acceptMessageRequest(session.id)}
                onDeclineRequest={() => declineMessageRequest(session.id)}
              />
            ))}
          </>
        )}
      </div>

      {/* New Direct Chat Modal */}
      {isNewChatModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white w-full max-w-md rounded-3xl p-5 shadow-2xl border border-slate-200 space-y-4 animate-scale-up max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-extrabold text-slate-900 text-base">New Direct Message</h3>
                <p className="text-xs text-slate-500">Search customers, verified sellers, or contacts</p>
              </div>
              <button
                onClick={() => setIsNewChatModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={newChatSearch}
                onChange={(e) => setNewChatSearch(e.target.value)}
                placeholder="Search by name, handle, or store..."
                autoFocus
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex-1 overflow-y-auto space-y-2">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Suggested People & Stores
              </p>

              {sampleDirectoryUsers.map((user) => (
                <div
                  key={user.id}
                  onClick={() => {
                    startDirectChatWithUser(user);
                    setIsNewChatModalOpen(false);
                  }}
                  className="p-2.5 rounded-2xl hover:bg-slate-50 transition flex items-center justify-between cursor-pointer border border-transparent hover:border-slate-200"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="w-10 h-10 rounded-full object-cover border border-slate-200"
                    />
                    <div>
                      <div className="flex items-center gap-1">
                        <h4 className="text-xs font-bold text-slate-900">{user.name}</h4>
                        {user.isVerified && (
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        )}
                      </div>
                      <p className="text-[10px] text-emerald-600 font-semibold">
                        {user.isOnline ? 'Online now' : user.lastSeen}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-xl">
                    Chat
                  </span>
                </div>
              ))}

              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider pt-2">
                Verified Stores
              </p>
              {sellers.slice(0, 3).map((seller) => (
                <div
                  key={seller.id}
                  onClick={() => handleStartNewChatWithSeller(seller)}
                  className="p-2.5 rounded-2xl hover:bg-slate-50 transition flex items-center justify-between cursor-pointer border border-transparent hover:border-slate-200"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={
                        seller.logoImage ||
                        'https://images.unsplash.com/photo-1535378917042-10a22c95931a?w=150&auto=format&fit=crop&q=80'
                      }
                      alt={seller.storeName}
                      className="w-10 h-10 rounded-full object-cover border border-slate-200"
                    />
                    <div>
                      <div className="flex items-center gap-1">
                        <h4 className="text-xs font-bold text-slate-900">{seller.storeName}</h4>
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      </div>
                      <p className="text-[10px] text-slate-500">{seller.category} • {seller.city}</p>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-xl">
                    Message
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Item Component
interface ChatInboxItemProps {
  session: StoreChatSession;
  isSelected: boolean;
  onSelect: () => void;
  onAcceptRequest: () => void;
  onDeclineRequest: () => void;
}

const ChatInboxItem: React.FC<ChatInboxItemProps> = ({
  session,
  isSelected,
  onSelect,
  onAcceptRequest,
  onDeclineRequest,
}) => {
  const partner = session.partnerUser || {
    name: session.storeName || session.customerName || 'Chat Partner',
    avatar: session.storeAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    isOnline: true,
  };

  const msgs = session?.messages || [];
  const lastMessage = msgs.length > 0 ? msgs[msgs.length - 1] : null;

  return (
    <div
      onClick={onSelect}
      className={`p-3.5 transition flex items-start gap-3 cursor-pointer hover:bg-slate-50 relative group ${
        isSelected ? 'bg-indigo-50/70' : ''
      }`}
    >
      {/* Avatar with Online Ring */}
      <div className="relative shrink-0">
        <img
          src={partner.avatar}
          alt={partner.name}
          className="w-12 h-12 rounded-full object-cover border border-slate-200"
        />
        {partner.isOnline && (
          <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full" />
        )}
      </div>

      {/* Chat Content Preview */}
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-1.5 min-w-0">
            <h4 className="font-extrabold text-xs text-slate-900 line-clamp-1">
              {partner.name}
            </h4>
            {partner.isVerified && (
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            )}
            {session.isPinned && <Pin className="w-3 h-3 text-indigo-600 shrink-0" />}
            {session.isMuted && <VolumeX className="w-3 h-3 text-slate-400 shrink-0" />}
          </div>

          <span className="text-[10px] text-slate-400 font-medium whitespace-nowrap ml-2">
            {lastMessage
              ? new Date(lastMessage.timestamp).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                })
              : 'Now'}
          </span>
        </div>

        {/* Last Message Snippet */}
        <div className="flex items-center justify-between">
          <p className="text-xs text-slate-500 line-clamp-1 leading-relaxed">
            {session.isTyping ? (
              <span className="text-indigo-600 font-bold flex items-center gap-1 animate-pulse">
                <span>typing...</span>
              </span>
            ) : lastMessage ? (
              lastMessage.productCard ? (
                `🛍️ Product: ${lastMessage.productCard.name}`
              ) : lastMessage.storeCard ? (
                `🏪 Store: ${lastMessage.storeCard.name}`
              ) : lastMessage.viewOnceSnap ? (
                `📸 Photo Snap (View-Once)`
              ) : lastMessage.voiceNote ? (
                `🎙️ Voice Message (${lastMessage.voiceNote.durationSec}s)`
              ) : lastMessage.bargainOffer ? (
                `🤝 Bargain Offer: ₹${lastMessage.bargainOffer.requestedPrice}`
              ) : (
                lastMessage.text
              )
            ) : (
              'Start conversation'
            )}
          </p>

          {/* Unread Counter Badge */}
          {session.unreadCount && session.unreadCount > 0 ? (
            <span className="ml-2 bg-indigo-600 text-white text-[10px] font-extrabold px-1.5 py-0.5 rounded-full shrink-0">
              {session.unreadCount}
            </span>
          ) : null}
        </div>

        {/* Message Request Actions if pending */}
        {session.isMessageRequest && (
          <div className="mt-2 pt-2 border-t border-slate-200/60 flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
            <button
              onClick={onAcceptRequest}
              className="flex-1 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[11px] font-bold transition"
            >
              Accept
            </button>
            <button
              onClick={onDeclineRequest}
              className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-[11px] font-bold transition"
            >
              Decline
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
