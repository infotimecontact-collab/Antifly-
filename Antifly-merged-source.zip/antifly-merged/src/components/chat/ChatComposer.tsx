import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Send,
  Mic,
  MicOff,
  Camera,
  Paperclip,
  Smile,
  X,
  Tag,
  DollarSign,
  Flame,
  Clock,
  Sparkles,
  ShoppingBag,
  Store,
  User,
  Radio,
  Image as ImageIcon,
  Check,
  ChevronDown,
} from 'lucide-react';
import {
  MessageReplyQuote,
  VoiceNoteData,
  ChatMode,
} from '../../types';

interface ChatComposerProps {
  chatId: string;
  replyingTo: MessageReplyQuote | null;
  onClearReply: () => void;
  onOpenQuickBargain: () => void;
  onOpenCamera: () => void;
  onOpenShareModal: () => void;
  chatMode: ChatMode;
  disappearingTimerSec: number;
}

const COMMON_EMOJIS = ['❤️', '🔥', '👏', '😍', '😂', '🙏', '👍', '✨', '🎉', '💯', '🤩', '🥳', '🛍️', '💰'];

export const ChatComposer: React.FC<ChatComposerProps> = ({
  chatId,
  replyingTo,
  onClearReply,
  onOpenQuickBargain,
  onOpenCamera,
  onOpenShareModal,
  chatMode,
  disappearingTimerSec,
}) => {
  const { sendStoreChatMessage, showToast } = useApp();
  const [inputText, setInputText] = useState('');
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [voiceSeconds, setVoiceSeconds] = useState(0);
  const [isEmojiPickerOpen, setIsEmojiPickerOpen] = useState(false);
  const [isAttachmentMenuOpen, setIsAttachmentMenuOpen] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Voice recording timer
  useEffect(() => {
    let interval: any;
    if (isRecordingVoice) {
      setVoiceSeconds(0);
      interval = setInterval(() => {
        setVoiceSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      setVoiceSeconds(0);
    }
    return () => clearInterval(interval);
  }, [isRecordingVoice]);

  const handleSend = () => {
    if (!inputText.trim()) return;

    sendStoreChatMessage(
      chatId,
      inputText.trim(),
      undefined,
      undefined,
      undefined,
      {
        replyTo: replyingTo || undefined,
      }
    );

    setInputText('');
    onClearReply();
    setIsEmojiPickerOpen(false);
    setIsAttachmentMenuOpen(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFinishVoiceRecording = () => {
    const finalDuration = Math.max(2, voiceSeconds);
    const mockVoiceNote: VoiceNoteData = {
      audioUrl: 'https://actions.google.com/sounds/v1/ambiences/coffee_shop.ogg',
      durationSec: finalDuration,
      waveform: [30, 50, 80, 45, 95, 60, 40, 85, 100, 70, 40, 65, 90, 55, 30, 80, 60, 40],
      isPlayed: false,
    };

    sendStoreChatMessage(
      chatId,
      '',
      undefined,
      undefined,
      undefined,
      {
        voiceNote: mockVoiceNote,
        replyTo: replyingTo || undefined,
      }
    );

    setIsRecordingVoice(false);
    onClearReply();
    showToast(`🎙️ Voice message (${finalDuration}s) sent!`);
  };

  const handleCancelVoiceRecording = () => {
    setIsRecordingVoice(false);
    showToast('Voice recording cancelled');
  };

  const addEmoji = (emoji: string) => {
    setInputText((prev) => prev + emoji);
    inputRef.current?.focus();
  };

  return (
    <div
      id="chat-composer-container"
      className="bg-white border-t border-slate-200 px-3 py-2.5 relative select-none"
    >
      {/* Reply Preview Bar */}
      {replyingTo && (
        <div className="mb-2 p-2 bg-slate-50 border-l-4 border-indigo-600 rounded-r-xl flex items-center justify-between animate-slide-down">
          <div className="min-w-0 flex-1 pr-2">
            <p className="text-[11px] font-bold text-indigo-700">
              Replying to {replyingTo.senderName}
            </p>
            <p className="text-xs text-slate-600 line-clamp-1">{replyingTo.text}</p>
          </div>
          <button
            onClick={onClearReply}
            className="p-1 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-200 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Disappearing Timer & Mode Badges */}
      {disappearingTimerSec > 0 && (
        <div className="mb-1.5 flex items-center gap-1.5 text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full w-fit">
          <Clock className="w-3 h-3 text-amber-600" />
          <span>
            Disappearing Mode Active ({disappearingTimerSec < 60 ? `${disappearingTimerSec}s` : disappearingTimerSec === 60 ? '1m' : disappearingTimerSec === 86400 ? '24h' : '7d'})
          </span>
        </div>
      )}

      {/* Emoji Picker Popover */}
      {isEmojiPickerOpen && (
        <div className="absolute bottom-16 left-4 z-30 bg-white shadow-2xl border border-slate-200 rounded-2xl p-2.5 grid grid-cols-7 gap-1.5 animate-scale-up">
          {COMMON_EMOJIS.map((em, idx) => (
            <button
              key={idx}
              onClick={() => addEmoji(em)}
              className="w-9 h-9 flex items-center justify-center text-lg hover:bg-slate-100 rounded-xl transition active:scale-125"
            >
              {em}
            </button>
          ))}
        </div>
      )}

      {/* Attachment Menu Popover */}
      {isAttachmentMenuOpen && (
        <div className="absolute bottom-16 left-12 z-30 bg-white shadow-2xl border border-slate-200 rounded-2xl p-2 w-52 space-y-1 animate-scale-up">
          <button
            onClick={() => {
              setIsAttachmentMenuOpen(false);
              onOpenShareModal();
            }}
            className="w-full text-left px-3 py-2 text-xs font-semibold text-slate-800 hover:bg-indigo-50 hover:text-indigo-600 rounded-xl transition flex items-center gap-2.5"
          >
            <ShoppingBag className="w-4 h-4 text-indigo-600" />
            <span>Share Product</span>
          </button>

          <button
            onClick={() => {
              setIsAttachmentMenuOpen(false);
              onOpenShareModal();
            }}
            className="w-full text-left px-3 py-2 text-xs font-semibold text-slate-800 hover:bg-emerald-50 hover:text-emerald-600 rounded-xl transition flex items-center gap-2.5"
          >
            <Store className="w-4 h-4 text-emerald-600" />
            <span>Share Store</span>
          </button>

          <button
            onClick={() => {
              setIsAttachmentMenuOpen(false);
              onOpenShareModal();
            }}
            className="w-full text-left px-3 py-2 text-xs font-semibold text-slate-800 hover:bg-amber-50 hover:text-amber-600 rounded-xl transition flex items-center gap-2.5"
          >
            <User className="w-4 h-4 text-amber-600" />
            <span>Share Profile</span>
          </button>

          <button
            onClick={() => {
              setIsAttachmentMenuOpen(false);
              onOpenCamera();
            }}
            className="w-full text-left px-3 py-2 text-xs font-semibold text-slate-800 hover:bg-rose-50 hover:text-rose-600 rounded-xl transition flex items-center gap-2.5"
          >
            <Flame className="w-4 h-4 text-rose-600" />
            <span>Snap Camera (View-Once)</span>
          </button>
        </div>
      )}

      {/* Main Input Row */}
      {isRecordingVoice ? (
        /* Voice Recording Active Bar */
        <div className="flex items-center justify-between bg-rose-50 border border-rose-200 rounded-2xl px-4 py-2.5 animate-fade-in">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-rose-600 animate-ping inline-block" />
            <span className="text-xs font-mono font-bold text-rose-700">
              00:{voiceSeconds.toString().padStart(2, '0')}
            </span>
            <div className="flex items-center gap-1 h-5 mx-2">
              {[40, 80, 100, 60, 90, 50, 70, 90, 40].map((h, i) => (
                <span
                  key={i}
                  style={{ height: `${h}%` }}
                  className="w-0.5 bg-rose-500 rounded-full animate-pulse"
                />
              ))}
            </div>
            <span className="text-[11px] text-rose-500 hidden sm:inline">Recording Voice Note...</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCancelVoiceRecording}
              className="px-3 py-1.5 text-xs font-semibold text-rose-700 hover:bg-rose-100 rounded-xl transition"
            >
              Cancel
            </button>
            <button
              onClick={handleFinishVoiceRecording}
              className="p-2 bg-rose-600 hover:bg-rose-700 text-white rounded-full transition shadow-md shadow-rose-600/30"
              title="Send Voice Message"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        /* Normal Typing Bar */
        <div className="flex items-end gap-1.5">
          {/* Camera Button */}
          <button
            onClick={onOpenCamera}
            className="p-2.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-full transition shrink-0"
            title="Snap Camera"
          >
            <Camera className="w-5 h-5" />
          </button>

          {/* Attachment Picker */}
          <button
            onClick={() => setIsAttachmentMenuOpen(!isAttachmentMenuOpen)}
            className="p-2.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-full transition shrink-0"
            title="Attach Products/Stores"
          >
            <Paperclip className="w-5 h-5" />
          </button>

          {/* Text Area Pill */}
          <div className="flex-1 bg-slate-100 focus-within:bg-white focus-within:ring-2 focus-within:ring-indigo-500/20 border border-slate-200 rounded-2xl flex items-center px-3 py-1.5 transition">
            <button
              onClick={() => setIsEmojiPickerOpen(!isEmojiPickerOpen)}
              className="p-1 text-slate-400 hover:text-amber-500 transition mr-1"
            >
              <Smile className="w-5 h-5" />
            </button>

            <textarea
              ref={inputRef}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={
                chatMode === 'disappearing'
                  ? 'Send disappearing message...'
                  : chatMode === 'shopping'
                  ? 'Ask seller or make an offer...'
                  : 'Message...'
              }
              rows={1}
              className="w-full bg-transparent text-slate-900 text-sm focus:outline-none resize-none max-h-28 placeholder:text-slate-400 leading-tight py-1"
            />

            {/* Quick Bargain Offer Button */}
            <button
              onClick={onOpenQuickBargain}
              className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg transition shrink-0 ml-1 font-bold text-xs flex items-center gap-0.5"
              title="Make Bargain Offer"
            >
              <Tag className="w-4 h-4" />
            </button>
          </div>

          {/* Send or Voice Record Trigger */}
          {inputText.trim() ? (
            <button
              id="btn-chat-send"
              onClick={handleSend}
              className="p-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full transition shadow-md shadow-indigo-600/30 active:scale-95 shrink-0"
              title="Send Message"
            >
              <Send className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={() => setIsRecordingVoice(true)}
              className="p-3 bg-slate-100 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 rounded-full transition shrink-0"
              title="Hold to Record Voice Message"
            >
              <Mic className="w-5 h-5" />
            </button>
          )}
        </div>
      )}
    </div>
  );
};
