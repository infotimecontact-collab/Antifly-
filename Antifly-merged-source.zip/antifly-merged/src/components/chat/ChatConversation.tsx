import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ArrowLeft,
  Search,
  Phone,
  Video,
  MoreVertical,
  ShieldCheck,
  Check,
  CheckCheck,
  Clock,
  Flame,
  Volume2,
  Play,
  Pause,
  Reply,
  Copy,
  Trash2,
  Edit2,
  Pin,
  Share2,
  ShoppingBag,
  Store,
  User,
  Radio,
  Sparkles,
  Smile,
  X,
  ChevronDown,
  DollarSign,
  Tag,
  Eye,
  Camera,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import {
  StoreChatSession,
  StoreChatMessage,
  MessageReplyQuote,
  MessageReaction,
  ChatMode,
  ChatPartnerUser,
  MessageProductCard,
  MessageStoreCard,
  MessageProfileCard,
  MessagePostCard,
} from '../../types';
import { ChatComposer } from './ChatComposer';
import { ChatCameraModal } from './ChatCameraModal';
import { ShareContentModal } from './ShareContentModal';
import { SnapMediaViewerModal } from './SnapMediaViewerModal';
import { UniversalSaveButton } from '../favorites/UniversalSaveButton';

interface ChatConversationProps {
  session: StoreChatSession;
  onBack: () => void;
}

const REACTION_EMOJIS = ['❤️', '😂', '😮', '😢', '🙏', '🔥', '👏', '👍'];

export const ChatConversation: React.FC<ChatConversationProps> = ({
  session,
  onBack,
}) => {
  const {
    currentRole,
    userProfile,
    formatPrice,
    addToCart,
    sendStoreChatMessage,
    toggleMessageReaction,
    deleteChatMessage,
    editChatMessage,
    forwardChatMessage,
    setChatMode,
    setChatDisappearingTimer,
    simulateScreenshotAlert,
    togglePinChat,
    toggleMuteChat,
    toggleBlockChat,
    togglePinMessage,
    openSnapMedia,
    startCall,
    respondToBargainOffer,
    acceptBargainAndAddCart,
    showToast,
    setIsContentLifecycleModalOpen,
  } = useApp();

  const [customMinutesInput, setCustomMinutesInput] = useState<string>('');
  const [showCustomTimerInput, setShowCustomTimerInput] = useState<boolean>(false);

  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [replyingTo, setReplyingTo] = useState<MessageReplyQuote | null>(null);
  const [selectedMessageForMenu, setSelectedMessageForMenu] = useState<string | null>(null);
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isModeSelectorOpen, setIsModeSelectorOpen] = useState(false);
  const [isTimerSelectorOpen, setIsTimerSelectorOpen] = useState(false);

  // Modals
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [activeSnapToView, setActiveSnapToView] = useState<{
    snap: any;
    messageId: string;
  } | null>(null);
  const [isQuickBargainOpen, setIsQuickBargainOpen] = useState(false);
  const [bargainPriceInput, setBargainPriceInput] = useState<number>(0);
  const [bargainQtyInput, setBargainQtyInput] = useState<number>(1);

  // Voice player simulated state
  const [playingVoiceId, setPlayingVoiceId] = useState<string | null>(null);
  const [voicePlaybackSpeed, setVoicePlaybackSpeed] = useState<1 | 1.5 | 2>(1);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [session?.messages?.length]);

  const partner: ChatPartnerUser = session.partnerUser || {
    id: session.customerId || session.sellerId || 'partner-01',
    name: session.storeName || session.customerName || 'Chat Partner',
    avatar: session.storeAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    isOnline: true,
    lastSeen: 'Active now',
    storeName: session.storeName,
    isVerified: true,
  };

  const handleCopyMessage = (text: string) => {
    navigator.clipboard.writeText(text);
    showToast('Copied to clipboard');
    setSelectedMessageForMenu(null);
  };

  const handleStartAudioCall = () => {
    startCall(partner, 'audio');
  };

  const handleStartVideoCall = () => {
    startCall(partner, 'video');
  };

  const handleSaveEdit = (messageId: string) => {
    if (!editingText.trim()) return;
    editChatMessage(session.id, messageId, editingText.trim());
    setEditingMessageId(null);
    setEditingText('');
  };

  const handleSendBargainFromQuickModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (bargainPriceInput <= 0) {
      showToast('Please enter a valid bargain offer price');
      return;
    }

    sendStoreChatMessage(
      session.id,
      `🤝 Special Price Offer: ₹${bargainPriceInput} for ${bargainQtyInput} unit(s)`,
      {
        productId: 'prod-001',
        productName: 'Artisan Linen Cuban Collar Shirt',
        productImage: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400&auto=format&fit=crop&q=80',
        originalPrice: 1899,
        requestedPrice: bargainPriceInput,
        quantity: bargainQtyInput,
      }
    );

    setIsQuickBargainOpen(false);
    setBargainPriceInput(0);
  };

  const filteredMessages = session.messages.filter((m) => {
    if (!searchQuery.trim()) return true;
    return (
      m.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.productCard?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.storeCard?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.profileCard?.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  return (
    <div
      id="chat-conversation-root"
      className="w-full h-full flex flex-col bg-slate-50 relative overflow-hidden"
    >
      {/* Top Header */}
      <div className="bg-white border-b border-slate-200 px-4 py-2.5 flex items-center justify-between shadow-xs z-20">
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onBack}
            className="p-1.5 -ml-1.5 text-slate-500 hover:text-slate-900 rounded-full hover:bg-slate-100 transition"
            title="Back to inbox"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="relative shrink-0">
            <img
              src={partner.avatar}
              alt={partner.name}
              className="w-10 h-10 rounded-full object-cover border border-slate-200"
            />
            {partner.isOnline && (
              <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full" />
            )}
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <h3 className="font-extrabold text-sm text-slate-900 line-clamp-1">
                {partner.name}
              </h3>
              {partner.isVerified && (
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-1.5 py-0.2 rounded-full flex items-center gap-0.5">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  Verified
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-500 flex items-center gap-1">
              <span>{partner.isOnline ? 'Active now' : partner.lastSeen || 'Recently'}</span>
              {session.chatMode !== 'normal' && (
                <span className="text-indigo-600 font-semibold">• {session.chatMode.replace('_', ' ').toUpperCase()}</span>
              )}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1">
          {/* In-chat search toggle */}
          <button
            onClick={() => setIsSearchOpen(!isSearchOpen)}
            className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-full transition"
            title="Search conversation"
          >
            <Search className="w-4.5 h-4.5" />
          </button>

          {/* Voice Call */}
          <button
            id="btn-voice-call"
            onClick={handleStartAudioCall}
            className="p-2 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-full transition"
            title="Start Voice Call"
          >
            <Phone className="w-4.5 h-4.5" />
          </button>

          {/* Video Call */}
          <button
            id="btn-video-call"
            onClick={handleStartVideoCall}
            className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-full transition"
            title="Start Video Call"
          >
            <Video className="w-4.5 h-4.5" />
          </button>

          {/* Chat Mode Pill Selector */}
          <div className="relative">
            <button
              onClick={() => setIsModeSelectorOpen(!isModeSelectorOpen)}
              className="px-2.5 py-1 text-xs font-bold bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 text-slate-700 rounded-full transition flex items-center gap-1"
              title="Change Chat Mode"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span className="hidden sm:inline capitalize">{session.chatMode}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {isModeSelectorOpen && (
              <div className="absolute right-0 top-10 w-56 bg-white rounded-2xl shadow-2xl border border-slate-200 p-2 z-40 space-y-1 animate-scale-up">
                <p className="text-[10px] font-bold text-slate-400 px-2 py-1 uppercase tracking-wider">
                  Select Chat Experience
                </p>
                <button
                  onClick={() => {
                    setChatMode(session.id, 'normal');
                    setIsModeSelectorOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-between ${
                    session.chatMode === 'normal'
                      ? 'bg-indigo-50 text-indigo-700 font-bold'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span>💬 Normal Chat</span>
                  {session.chatMode === 'normal' && <Check className="w-4 h-4" />}
                </button>

                <button
                  onClick={() => {
                    setChatMode(session.id, 'disappearing');
                    setIsModeSelectorOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-between ${
                    session.chatMode === 'disappearing'
                      ? 'bg-indigo-50 text-indigo-700 font-bold'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span>⏳ Disappearing Mode</span>
                  {session.chatMode === 'disappearing' && <Check className="w-4 h-4" />}
                </button>

                <button
                  onClick={() => {
                    setChatMode(session.id, 'private_media');
                    setIsModeSelectorOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-between ${
                    session.chatMode === 'private_media'
                      ? 'bg-indigo-50 text-indigo-700 font-bold'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span>📸 Private Media / Snaps</span>
                  {session.chatMode === 'private_media' && <Check className="w-4 h-4" />}
                </button>

                <button
                  onClick={() => {
                    setChatMode(session.id, 'shopping');
                    setIsModeSelectorOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-between ${
                    session.chatMode === 'shopping'
                      ? 'bg-indigo-50 text-indigo-700 font-bold'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span>🛍️ Shopping & Bargain</span>
                  {session.chatMode === 'shopping' && <Check className="w-4 h-4" />}
                </button>
              </div>
            )}
          </div>

          {/* Save Chat to Vault */}
          <UniversalSaveButton
            targetId={session.id}
            itemType="chat"
            title={`Chat with ${session.participantName}`}
            subtitle={session.lastMessage || '1-to-1 conversation'}
            imageUrl={session.participantAvatar}
            tags={['Chat', session.participantRole || 'seller']}
            size="sm"
          />

          {/* More Options Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 text-slate-500 hover:text-slate-900 rounded-full hover:bg-slate-100 transition"
              title="More options"
            >
              <MoreVertical className="w-4.5 h-4.5" />
            </button>

            {isMenuOpen && (
              <div className="absolute right-0 top-10 w-52 bg-white rounded-2xl shadow-2xl border border-slate-200 p-2 z-40 space-y-1 animate-scale-up">
                <button
                  onClick={() => {
                    setIsTimerSelectorOpen(true);
                    setIsMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 flex items-center gap-2"
                >
                  <Clock className="w-4 h-4 text-amber-600" />
                  <span>Disappearing Timers</span>
                </button>

                <button
                  onClick={() => {
                    togglePinChat(session.id);
                    setIsMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 flex items-center gap-2"
                >
                  <Pin className="w-4 h-4 text-indigo-600" />
                  <span>{session.isPinned ? 'Unpin Chat' : 'Pin to Top'}</span>
                </button>

                <button
                  onClick={() => {
                    toggleMuteChat(session.id);
                    setIsMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 flex items-center gap-2"
                >
                  <Volume2 className="w-4 h-4 text-slate-600" />
                  <span>{session.isMuted ? 'Unmute Notifications' : 'Mute Notifications'}</span>
                </button>

                <button
                  onClick={() => {
                    simulateScreenshotAlert(session.id);
                    setIsMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 flex items-center gap-2"
                >
                  <Camera className="w-4 h-4 text-rose-600" />
                  <span>Simulate Screenshot</span>
                </button>

                <button
                  onClick={() => {
                    toggleBlockChat(session.id);
                    setIsMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 flex items-center gap-2"
                >
                  <AlertCircle className="w-4 h-4" />
                  <span>{session.isBlocked ? 'Unblock User' : 'Block User'}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* In-Chat Search Bar */}
      {isSearchOpen && (
        <div className="bg-indigo-50/80 px-4 py-2 border-b border-indigo-100 flex items-center justify-between gap-3 animate-slide-down">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-indigo-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search in this conversation..."
              autoFocus
              className="w-full pl-9 pr-3 py-1.5 bg-white border border-indigo-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-indigo-500"
            />
          </div>
          <span className="text-[11px] text-indigo-700 font-semibold whitespace-nowrap">
            {filteredMessages.length} matches
          </span>
          <button
            onClick={() => {
              setSearchQuery('');
              setIsSearchOpen(false);
            }}
            className="p-1 text-slate-500 hover:text-slate-800 rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Disappearing Timer Selector Modal */}
      {isTimerSelectorOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white w-full max-w-sm rounded-3xl p-5 shadow-2xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-emerald-600" />
                  <span>Disappearing Messages</span>
                </h3>
                <p className="text-[11px] text-slate-500">
                  Universal content expiration for this conversation.
                </p>
              </div>
              <button
                onClick={() => {
                  setIsTimerSelectorOpen(false);
                  setShowCustomTimerInput(false);
                }}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-1.5 pt-1 max-h-72 overflow-y-auto pr-1">
              {[
                { label: 'Off', sec: 0, desc: 'Messages stay indefinitely' },
                { label: 'After viewing (View-Once)', sec: 5, desc: 'Disappears immediately after reading' },
                { label: '10 minutes', sec: 600, desc: 'Ephemeral short discussion' },
                { label: '1 hour', sec: 3600, desc: 'Short-term exchange' },
                { label: '6 hours', sec: 21600, desc: 'Half-day lifespan' },
                { label: '24 hours', sec: 86400, desc: 'Daily cleanup' },
                { label: '3 days', sec: 259200, desc: '72 hours window' },
                { label: '7 days', sec: 604800, desc: 'Weekly cleanup' },
                { label: '14 days', sec: 1209600, desc: 'Bi-weekly retention' },
                { label: '30 days', sec: 2592000, desc: 'Default monthly policy' },
              ].map((item) => (
                <button
                  key={item.sec}
                  onClick={() => {
                    setChatDisappearingTimer(session.id, item.sec);
                    setShowCustomTimerInput(false);
                    setIsTimerSelectorOpen(false);
                    showToast(item.sec === 0 ? 'Disappearing messages turned off' : `Messages will disappear after ${item.label}.`);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center justify-between transition cursor-pointer ${
                    session.disappearingTimerSec === item.sec && !showCustomTimerInput
                      ? 'bg-emerald-600 text-white font-bold shadow-xs'
                      : 'bg-slate-50 text-slate-800 hover:bg-emerald-50 hover:text-emerald-900'
                  }`}
                >
                  <div>
                    <span className="font-bold">{item.label}</span>
                    <p className={`text-[10px] ${session.disappearingTimerSec === item.sec && !showCustomTimerInput ? 'text-emerald-100' : 'text-slate-500'}`}>
                      {item.desc}
                    </p>
                  </div>
                  {session.disappearingTimerSec === item.sec && !showCustomTimerInput && <Check className="w-4 h-4 shrink-0" />}
                </button>
              ))}

              {/* Custom Duration Option */}
              <button
                onClick={() => setShowCustomTimerInput(!showCustomTimerInput)}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center justify-between transition cursor-pointer ${
                  showCustomTimerInput
                    ? 'bg-emerald-50 text-emerald-900 border border-emerald-300 font-bold'
                    : 'bg-slate-50 text-slate-800 hover:bg-slate-100'
                }`}
              >
                <div>
                  <span className="font-bold">⏱ Custom duration...</span>
                  <p className="text-[10px] text-slate-500">Specify exact minutes or hours</p>
                </div>
                <ChevronDown className="w-4 h-4" />
              </button>

              {showCustomTimerInput && (
                <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-2 animate-scale-up">
                  <label className="text-[11px] font-bold text-emerald-900 block">
                    Enter Duration in Minutes:
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      min="1"
                      value={customMinutesInput}
                      onChange={(e) => setCustomMinutesInput(e.target.value)}
                      placeholder="e.g. 45"
                      className="flex-1 bg-white border border-emerald-300 rounded-xl px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-emerald-600"
                    />
                    <button
                      onClick={() => {
                        const mins = parseInt(customMinutesInput, 10);
                        if (!mins || mins <= 0) {
                          showToast('Please enter a valid number of minutes');
                          return;
                        }
                        const sec = mins * 60;
                        setChatDisappearingTimer(session.id, sec);
                        setShowCustomTimerInput(false);
                        setIsTimerSelectorOpen(false);
                        showToast(`Messages will disappear after ${mins} minutes.`);
                      }}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-3 py-1.5 rounded-xl text-xs cursor-pointer"
                    >
                      Apply
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
              <button
                onClick={() => {
                  setIsTimerSelectorOpen(false);
                  setIsContentLifecycleModalOpen(true);
                }}
                className="text-[11px] text-emerald-700 hover:underline font-bold flex items-center gap-1"
              >
                <span>Manage Universal Lifecycle Hub</span>
              </button>
              <button
                onClick={() => setIsTimerSelectorOpen(false)}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-3 py-1.5 rounded-xl cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Message List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {/* Disappearing Messages Informational Notice Banner */}
        {session.disappearingTimerSec && session.disappearingTimerSec > 0 && (
          <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 border border-emerald-200/80 rounded-2xl p-3 shadow-2xs animate-fade-in flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                <Clock className="w-4 h-4" />
              </div>
              <div className="leading-tight">
                <p className="text-xs font-black text-emerald-950">
                  Messages will disappear after{' '}
                  {session.disappearingTimerSec === 5
                    ? 'viewing'
                    : session.disappearingTimerSec >= 86400
                    ? `${Math.round(session.disappearingTimerSec / 86400)} days`
                    : session.disappearingTimerSec >= 3600
                    ? `${Math.round(session.disappearingTimerSec / 3600)} hours`
                    : `${Math.round(session.disappearingTimerSec / 60)} minutes`}
                  .
                </p>
                <p className="text-[10px] text-emerald-700 font-medium">
                  Auto-deleted from all devices once timer expires.
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsTimerSelectorOpen(true)}
              className="text-[11px] font-extrabold text-emerald-800 bg-white hover:bg-emerald-100/60 border border-emerald-300 px-2.5 py-1 rounded-xl whitespace-nowrap shadow-2xs cursor-pointer transition"
            >
              Change
            </button>
          </div>
        )}
        {filteredMessages.map((msg, index) => {
          const isMe = msg.senderRole === 'customer';
          const isSystem = msg.isSystemAlert;
          const isSelected = selectedMessageForMenu === msg.id;

          if (isSystem) {
            return (
              <div key={msg.id} className="flex justify-center my-2 animate-fade-in">
                <span className="px-3 py-1 bg-slate-200/80 text-slate-600 text-[11px] font-semibold rounded-full border border-slate-300/60 shadow-xs flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                  {msg.text}
                </span>
              </div>
            );
          }

          return (
            <div
              key={msg.id}
              className={`flex flex-col group relative ${isMe ? 'items-end' : 'items-start'}`}
            >
              {/* Message Bubble Container */}
              <div className="relative max-w-[82%] sm:max-w-[70%]">
                {/* Reply Quote Banner inside bubble */}
                {msg.replyTo && (
                  <div className="mb-1 p-2 bg-slate-900/5 rounded-xl border-l-3 border-indigo-600 text-[11px]">
                    <span className="font-bold text-indigo-700 block">
                      {msg.replyTo.senderName}
                    </span>
                    <span className="text-slate-600 line-clamp-1">{msg.replyTo.text}</span>
                  </div>
                )}

                {/* Main Bubble Content */}
                <div
                  className={`p-3.5 rounded-2xl text-sm transition shadow-xs relative ${
                    isMe
                      ? 'bg-indigo-600 text-white rounded-br-xs'
                      : 'bg-white text-slate-900 border border-slate-200/90 rounded-bl-xs'
                  }`}
                >
                  {/* View Once Snap Attachment Card */}
                  {msg.viewOnceSnap && (
                    <div className="mb-2">
                      {msg.viewOnceSnap.isExpired ? (
                        <div className="p-3 bg-slate-900/10 rounded-xl flex items-center gap-2 text-xs font-semibold">
                          <Flame className="w-4 h-4 text-slate-400" />
                          <span>📸 Snap expired (View-Once)</span>
                        </div>
                      ) : (
                        <button
                          onClick={() => {
                            openSnapMedia(session.id, msg.id);
                            setActiveSnapToView({
                              snap: msg.viewOnceSnap,
                              messageId: msg.id,
                            });
                          }}
                          className="w-full p-3 bg-amber-500/20 hover:bg-amber-500/30 text-amber-900 rounded-xl flex items-center gap-2 text-xs font-bold border border-amber-400/40 transition active:scale-95 cursor-pointer"
                        >
                          <Flame className="w-4 h-4 text-amber-600 animate-bounce" />
                          <span>Photo • Tap to View Once (10s)</span>
                        </button>
                      )}
                    </div>
                  )}

                  {/* Voice Note Player */}
                  {msg.voiceNote && (
                    <div className="p-2 bg-slate-900/5 rounded-xl flex items-center gap-2 mb-1.5 min-w-[200px]">
                      <button
                        onClick={() =>
                          setPlayingVoiceId(
                            playingVoiceId === msg.id ? null : msg.id
                          )
                        }
                        className={`p-2 rounded-full transition ${
                          isMe
                            ? 'bg-white text-indigo-600 hover:bg-indigo-50'
                            : 'bg-indigo-600 text-white hover:bg-indigo-700'
                        }`}
                      >
                        {playingVoiceId === msg.id ? (
                          <Pause className="w-4 h-4" />
                        ) : (
                          <Play className="w-4 h-4" />
                        )}
                      </button>

                      {/* Waveform representation */}
                      <div className="flex-1 flex items-center gap-0.5 h-6">
                        {(msg.voiceNote.waveform || [30, 60, 90, 40, 80, 50, 70, 100, 40]).map(
                          (h, idx) => (
                            <span
                              key={idx}
                              style={{ height: `${h}%` }}
                              className={`w-1 rounded-full transition-all ${
                                playingVoiceId === msg.id
                                  ? 'bg-emerald-400 animate-pulse'
                                  : isMe
                                  ? 'bg-white/60'
                                  : 'bg-slate-400'
                              }`}
                            />
                          )
                        )}
                      </div>

                      <span className="text-[10px] font-mono font-semibold">
                        0:0{msg.voiceNote.durationSec}
                      </span>
                    </div>
                  )}

                  {/* Product Card Attachment */}
                  {msg.productCard && (
                    <div className="mb-2 p-2.5 bg-slate-50 text-slate-900 border border-slate-200 rounded-xl flex flex-col gap-2">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={msg.productCard.image}
                          alt={msg.productCard.name}
                          className="w-14 h-14 rounded-lg object-cover border border-slate-200"
                        />
                        <div className="min-w-0 flex-1">
                          <h4 className="font-bold text-xs line-clamp-1">
                            {msg.productCard.name}
                          </h4>
                          <p className="text-xs font-extrabold text-emerald-600">
                            {formatPrice(msg.productCard.price)}
                            {msg.productCard.mrp && (
                              <span className="line-through text-slate-400 text-[10px] ml-1.5 font-normal">
                                {formatPrice(msg.productCard.mrp)}
                              </span>
                            )}
                          </p>
                          <span className="text-[10px] text-slate-500">
                            {msg.productCard.brand}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={async () => {
                          await addToCart({
                            productId: msg.productCard!.id,
                            variantId: 'v-01',
                            productName: msg.productCard!.name,
                            brand: msg.productCard!.brand,
                            color: 'Standard',
                            size: 'Standard',
                            price: msg.productCard!.price,
                            mrp: msg.productCard!.mrp || msg.productCard!.price,
                            image: msg.productCard!.image,
                            quantity: 1,
                            stock: 20,
                          });
                          showToast(`🛍️ Added ${msg.productCard!.name} to Bag!`);
                        }}
                        className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                        <span>Buy Now / Add to Bag</span>
                      </button>
                    </div>
                  )}

                  {/* Storefront Card Attachment */}
                  {msg.storeCard && (
                    <div className="mb-2 p-2.5 bg-slate-50 text-slate-900 border border-slate-200 rounded-xl flex items-center justify-between gap-2.5">
                      <img
                        src={msg.storeCard.avatar}
                        alt={msg.storeCard.name}
                        className="w-10 h-10 rounded-full object-cover border border-slate-200"
                      />
                      <div className="min-w-0 flex-1">
                        <h4 className="font-bold text-xs line-clamp-1">{msg.storeCard.name}</h4>
                        <p className="text-[10px] text-slate-500">
                          {msg.storeCard.city} • ★ {msg.storeCard.rating}
                        </p>
                      </div>
                      <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-lg">
                        Visit Store
                      </span>
                    </div>
                  )}

                  {/* Profile Card Attachment */}
                  {msg.profileCard && (
                    <div className="mb-2 p-2.5 bg-slate-50 text-slate-900 border border-slate-200 rounded-xl flex items-center justify-between gap-2.5">
                      <img
                        src={msg.profileCard.avatar}
                        alt={msg.profileCard.name}
                        className="w-10 h-10 rounded-full object-cover border border-slate-200"
                      />
                      <div className="min-w-0 flex-1">
                        <h4 className="font-bold text-xs line-clamp-1">{msg.profileCard.name}</h4>
                        <p className="text-[10px] text-slate-500">{msg.profileCard.handle}</p>
                      </div>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-1 rounded-lg">
                        View Profile
                      </span>
                    </div>
                  )}

                  {/* Bargain Offer Card */}
                  {msg.bargainOffer && (
                    <div className="mb-2 p-3 bg-emerald-50 text-slate-900 border border-emerald-200 rounded-xl space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-extrabold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full uppercase">
                          🤝 Bargain Offer: {msg.bargainOffer.status}
                        </span>
                        <span className="text-xs font-mono font-bold text-emerald-700">
                          ₹{msg.bargainOffer.requestedPrice} / unit
                        </span>
                      </div>
                      <p className="text-xs font-bold text-slate-900">
                        {msg.bargainOffer.productName} ({msg.bargainOffer.quantity} Units)
                      </p>

                      {/* Action buttons on bargain */}
                      {msg.bargainOffer.status === 'PENDING' && currentRole === 'seller' && (
                        <div className="flex items-center gap-1.5 pt-1">
                          <button
                            onClick={() =>
                              respondToBargainOffer(
                                session.id,
                                msg.bargainOffer!.id,
                                'ACCEPTED'
                              )
                            }
                            className="flex-1 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition"
                          >
                            Accept
                          </button>
                          <button
                            onClick={() =>
                              respondToBargainOffer(
                                session.id,
                                msg.bargainOffer!.id,
                                'REJECTED'
                              )
                            }
                            className="px-3 py-1 bg-rose-100 hover:bg-rose-200 text-rose-700 rounded-lg text-xs font-bold transition"
                          >
                            Decline
                          </button>
                        </div>
                      )}

                      {msg.bargainOffer.status === 'ACCEPTED' && (
                        <button
                          onClick={() =>
                            acceptBargainAndAddCart(session.id, msg.bargainOffer!)
                          }
                          className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>Add Bargain to Bag (₹{msg.bargainOffer.requestedPrice})</span>
                        </button>
                      )}
                    </div>
                  )}

                  {/* Regular Text or Media */}
                  {editingMessageId === msg.id ? (
                    <div className="space-y-1.5">
                      <input
                        type="text"
                        value={editingText}
                        onChange={(e) => setEditingText(e.target.value)}
                        className="w-full bg-white text-slate-900 px-2 py-1 rounded text-xs border border-slate-300 focus:outline-none"
                      />
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setEditingMessageId(null)}
                          className="px-2 py-0.5 text-[10px] font-semibold text-slate-300"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={() => handleSaveEdit(msg.id)}
                          className="px-2 py-0.5 text-[10px] font-bold bg-white text-indigo-700 rounded"
                        >
                          Save
                        </button>
                      </div>
                    </div>
                  ) : (
                    msg.text && <p className="leading-relaxed break-words">{msg.text}</p>
                  )}

                  {/* Metadata Row: Timestamp & Delivery Status */}
                  <div
                    className={`flex items-center justify-end gap-1 mt-1 text-[10px] ${
                      isMe ? 'text-indigo-200' : 'text-slate-400'
                    }`}
                  >
                    {msg.isEdited && <span className="italic">Edited • </span>}
                    <span>
                      {new Date(msg.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>

                    {/* WhatsApp style delivery status ticks */}
                    {isMe && (
                      <span className="ml-0.5">
                        {msg.deliveryStatus === 'read' ? (
                          <CheckCheck className="w-3.5 h-3.5 text-sky-300" />
                        ) : msg.deliveryStatus === 'delivered' ? (
                          <CheckCheck className="w-3.5 h-3.5 text-indigo-200" />
                        ) : (
                          <Check className="w-3.5 h-3.5 text-indigo-300" />
                        )}
                      </span>
                    )}
                  </div>
                </div>

                {/* Message Reactions Badges */}
                {msg.reactions && msg.reactions.length > 0 && (
                  <div
                    className={`absolute -bottom-2.5 flex items-center gap-0.5 bg-white border border-slate-200 shadow-xs px-1.5 py-0.5 rounded-full z-10 ${
                      isMe ? 'right-2' : 'left-2'
                    }`}
                  >
                    {msg.reactions.map((r, i) => (
                      <span
                        key={i}
                        className="text-xs hover:scale-125 transition cursor-pointer"
                        title={`Reacted by ${r.userName}`}
                      >
                        {r.emoji}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Hover Quick Actions Bar */}
              <div
                className={`flex items-center gap-1 mt-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200 ${
                  isMe ? 'justify-end' : 'justify-start'
                }`}
              >
                {/* Quick Emoji Reaction Pill */}
                <div className="flex items-center bg-white shadow-md border border-slate-200 rounded-full px-1.5 py-0.5 gap-0.5">
                  {REACTION_EMOJIS.slice(0, 4).map((emoji) => (
                    <button
                      key={emoji}
                      onClick={() => toggleMessageReaction(session.id, msg.id, emoji)}
                      className="hover:scale-125 transition text-xs p-0.5"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>

                {/* Reply */}
                <button
                  onClick={() =>
                    setReplyingTo({
                      messageId: msg.id,
                      senderName: msg.senderName,
                      text: msg.text || 'media attachment',
                    })
                  }
                  className="p-1 bg-white hover:bg-slate-100 text-slate-500 rounded-full border border-slate-200 shadow-xs transition"
                  title="Reply"
                >
                  <Reply className="w-3 h-3" />
                </button>

                {/* Copy */}
                <button
                  onClick={() => handleCopyMessage(msg.text)}
                  className="p-1 bg-white hover:bg-slate-100 text-slate-500 rounded-full border border-slate-200 shadow-xs transition"
                  title="Copy"
                >
                  <Copy className="w-3 h-3" />
                </button>

                {/* Edit (if sent by me) */}
                {isMe && !msg.isDeleted && (
                  <button
                    onClick={() => {
                      setEditingMessageId(msg.id);
                      setEditingText(msg.text);
                    }}
                    className="p-1 bg-white hover:bg-slate-100 text-slate-500 rounded-full border border-slate-200 shadow-xs transition"
                    title="Edit message"
                  >
                    <Edit2 className="w-3 h-3" />
                  </button>
                )}

                {/* Delete */}
                <button
                  onClick={() => deleteChatMessage(session.id, msg.id, isMe)}
                  className="p-1 bg-white hover:bg-rose-50 text-rose-500 rounded-full border border-slate-200 shadow-xs transition"
                  title="Delete message"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Bargain Offer Modal */}
      {isQuickBargainOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <form
            onSubmit={handleSendBargainFromQuickModal}
            className="bg-white w-full max-w-sm rounded-3xl p-5 shadow-2xl border border-slate-200 space-y-3.5"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs">
                  <Tag className="w-4 h-4" />
                </div>
                <h3 className="font-extrabold text-slate-900 text-sm">Make Price Bargain Offer</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsQuickBargainOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  Your Offer Price (₹ per unit)
                </label>
                <input
                  type="number"
                  value={bargainPriceInput || ''}
                  onChange={(e) => setBargainPriceInput(Number(e.target.value))}
                  placeholder="e.g. 1450"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  Quantity Units
                </label>
                <input
                  type="number"
                  min={1}
                  value={bargainQtyInput}
                  onChange={(e) => setBargainQtyInput(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-extrabold shadow-md shadow-emerald-600/30 transition"
            >
              Send Bargain Offer to Seller
            </button>
          </form>
        </div>
      )}

      {/* Snap Camera Modal */}
      {isCameraOpen && (
        <ChatCameraModal
          chatId={session.id}
          onClose={() => setIsCameraOpen(false)}
          onSendSnap={(mediaUrl, caption, isViewOnce) => {
            sendStoreChatMessage(
              session.id,
              caption || '',
              undefined,
              mediaUrl,
              'image',
              {
                viewOnceSnap: isViewOnce
                  ? {
                      mediaUrl,
                      caption,
                      durationSec: 10,
                      isOpened: false,
                      isExpired: false,
                      viewCount: 0,
                      maxViews: 1,
                    }
                  : undefined,
              }
            );
            showToast('📸 Snap sent to conversation!');
          }}
        />
      )}

      {/* Share Content Modal */}
      {isShareModalOpen && (
        <ShareContentModal
          chatId={session.id}
          onClose={() => setIsShareModalOpen(false)}
          onShareProduct={(prod) => {
            sendStoreChatMessage(session.id, '', undefined, undefined, undefined, {
              productCard: prod,
            });
            showToast(`Shared product "${prod.name}"`);
          }}
          onShareStore={(store) => {
            sendStoreChatMessage(session.id, '', undefined, undefined, undefined, {
              storeCard: store,
            });
            showToast(`Shared store "${store.name}"`);
          }}
          onShareProfile={(prof) => {
            sendStoreChatMessage(session.id, '', undefined, undefined, undefined, {
              profileCard: prof,
            });
            showToast(`Shared profile "${prof.name}"`);
          }}
          onSharePost={(post) => {
            sendStoreChatMessage(session.id, '', undefined, undefined, undefined, {
              postCard: post,
            });
            showToast(`Shared post "${post.title}"`);
          }}
        />
      )}

      {/* Snap View Once Modal */}
      {activeSnapToView && (
        <SnapMediaViewerModal
          snap={activeSnapToView.snap}
          chatId={session.id}
          messageId={activeSnapToView.messageId}
          senderName={partner.name}
          onClose={() => setActiveSnapToView(null)}
        />
      )}

      {/* Bottom Composer */}
      <ChatComposer
        chatId={session.id}
        replyingTo={replyingTo}
        onClearReply={() => setReplyingTo(null)}
        onOpenQuickBargain={() => setIsQuickBargainOpen(true)}
        onOpenCamera={() => setIsCameraOpen(true)}
        onOpenShareModal={() => setIsShareModalOpen(true)}
        chatMode={session.chatMode}
        disappearingTimerSec={session.disappearingTimerSec || 0}
      />
    </div>
  );
};
