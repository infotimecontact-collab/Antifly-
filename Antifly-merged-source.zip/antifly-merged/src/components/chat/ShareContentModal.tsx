import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  ShoppingBag,
  Store,
  User,
  Share2,
  Search,
  Sparkles,
  Check,
  Send,
  Radio,
} from 'lucide-react';
import {
  MessageProductCard,
  MessageProfileCard,
  MessageStoreCard,
  MessagePostCard,
} from '../../types';

interface ShareContentModalProps {
  chatId: string;
  onClose: () => void;
  onShareProduct: (product: MessageProductCard) => void;
  onShareStore: (store: MessageStoreCard) => void;
  onShareProfile: (profile: MessageProfileCard) => void;
  onSharePost: (post: MessagePostCard) => void;
}

export const ShareContentModal: React.FC<ShareContentModalProps> = ({
  chatId,
  onClose,
  onShareProduct,
  onShareStore,
  onShareProfile,
  onSharePost,
}) => {
  const { products, sellers, communityPosts, formatPrice } = useApp();
  const [activeTab, setActiveTab] = useState<'products' | 'stores' | 'profiles' | 'posts'>('products');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.brand.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredSellers = sellers.filter(
    (s) =>
      s.storeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sampleProfiles = [
    {
      id: 'cust-102',
      name: 'Rohan Mehra',
      handle: '@rohan_m',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      bio: 'Fashion enthusiast & gadget reviewer ⚡',
      badge: 'Verified Buyer',
    },
    {
      id: 'cust-103',
      name: 'Ananya Roy',
      handle: '@ananya_style',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      bio: 'Organic beauty lover & lifestyle content creator 🌸',
      badge: 'Trendsetter',
    },
    {
      id: 'cust-104',
      name: 'Vikram Rajput',
      handle: '@vikram_r',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
      bio: 'Tech enthusiast & smart home automation explorer 🏠',
      badge: 'Power Shopper',
    },
  ];

  return (
    <div
      id="share-content-modal"
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in"
    >
      <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[85vh] animate-scale-up">
        {/* Header */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center">
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 text-base">Share to Chat</h3>
              <p className="text-xs text-slate-500">Send products, stores, profiles, or posts</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-slate-200 text-slate-500 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-200 bg-white px-3 pt-2 gap-1 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('products')}
            className={`pb-2.5 px-3.5 text-xs font-bold whitespace-nowrap transition border-b-2 flex items-center gap-1.5 ${
              activeTab === 'products'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Products ({filteredProducts.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('stores')}
            className={`pb-2.5 px-3.5 text-xs font-bold whitespace-nowrap transition border-b-2 flex items-center gap-1.5 ${
              activeTab === 'stores'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Store className="w-3.5 h-3.5" />
            <span>Stores ({filteredSellers.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('profiles')}
            className={`pb-2.5 px-3.5 text-xs font-bold whitespace-nowrap transition border-b-2 flex items-center gap-1.5 ${
              activeTab === 'profiles'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Profiles</span>
          </button>

          <button
            onClick={() => setActiveTab('posts')}
            className={`pb-2.5 px-3.5 text-xs font-bold whitespace-nowrap transition border-b-2 flex items-center gap-1.5 ${
              activeTab === 'posts'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>Community Posts</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-3 border-b border-slate-100 bg-slate-50/50">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={`Search ${activeTab}...`}
              className="w-full pl-9.5 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* List Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {activeTab === 'products' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {filteredProducts.map((prod) => (
                <div
                  key={prod.id}
                  className="p-3 border border-slate-200 rounded-2xl bg-white hover:border-indigo-400 hover:shadow-md transition flex items-center justify-between gap-3 group"
                >
                  <img
                    src={prod.images?.[0] || prod.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200'}
                    alt={prod.name}
                    className="w-14 h-14 rounded-xl object-cover border border-slate-100 shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <h4 className="text-xs font-bold text-slate-900 line-clamp-1 group-hover:text-indigo-600 transition">
                      {prod.name}
                    </h4>
                    <p className="text-[11px] font-semibold text-emerald-600">
                      {formatPrice(prod.price)}
                    </p>
                    <span className="text-[10px] text-slate-400 font-medium">
                      {prod.brand}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      onShareProduct({
                        id: prod.id,
                        name: prod.name,
                        price: prod.price,
                        mrp: prod.mrp,
                        image: prod.images?.[0] || prod.image || '',
                        brand: prod.brand,
                        rating: prod.rating,
                        discountPercent: prod.discountPercentage,
                      });
                      onClose();
                    }}
                    className="p-2 rounded-xl bg-indigo-50 group-hover:bg-indigo-600 text-indigo-600 group-hover:text-white transition cursor-pointer shrink-0"
                    title="Share Product"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'stores' && (
            <div className="space-y-2">
              {filteredSellers.map((seller) => (
                <div
                  key={seller.id}
                  className="p-3 border border-slate-200 rounded-2xl bg-white hover:border-indigo-400 hover:shadow-md transition flex items-center justify-between gap-3 group"
                >
                  <img
                    src={
                      seller.logoImage ||
                      'https://images.unsplash.com/photo-1535378917042-10a22c95931a?w=150&auto=format&fit=crop&q=80'
                    }
                    alt={seller.storeName}
                    className="w-12 h-12 rounded-full object-cover border border-slate-100 shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <h4 className="text-xs font-bold text-slate-900 line-clamp-1 group-hover:text-indigo-600 transition">
                      {seller.storeName}
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      {seller.city} • {seller.category}
                    </p>
                    <p className="text-[10px] text-emerald-600 font-semibold">
                      ★ {seller.rating || '4.9'} ({seller.totalOrders} Orders)
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      onShareStore({
                        id: seller.id,
                        name: seller.storeName,
                        avatar: seller.logoImage || '',
                        category: seller.category,
                        city: seller.city,
                        rating: seller.rating || 4.9,
                        totalProducts: seller.totalOrders || 40,
                      });
                      onClose();
                    }}
                    className="p-2 rounded-xl bg-indigo-50 group-hover:bg-indigo-600 text-indigo-600 group-hover:text-white transition cursor-pointer shrink-0"
                    title="Share Store"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'profiles' && (
            <div className="space-y-2">
              {sampleProfiles.map((profile) => (
                <div
                  key={profile.id}
                  className="p-3 border border-slate-200 rounded-2xl bg-white hover:border-indigo-400 hover:shadow-md transition flex items-center justify-between gap-3 group"
                >
                  <img
                    src={profile.avatar}
                    alt={profile.name}
                    className="w-12 h-12 rounded-full object-cover border border-slate-100 shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-xs font-bold text-slate-900 line-clamp-1">
                        {profile.name}
                      </h4>
                      <span className="text-[10px] font-semibold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded-full">
                        {profile.badge}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500">{profile.handle}</p>
                    <p className="text-[10px] text-slate-400 line-clamp-1">{profile.bio}</p>
                  </div>
                  <button
                    onClick={() => {
                      onShareProfile({
                        id: profile.id,
                        name: profile.name,
                        handle: profile.handle,
                        avatar: profile.avatar,
                        bio: profile.bio,
                        badge: profile.badge,
                      });
                      onClose();
                    }}
                    className="p-2 rounded-xl bg-indigo-50 group-hover:bg-indigo-600 text-indigo-600 group-hover:text-white transition cursor-pointer shrink-0"
                    title="Share Profile"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'posts' && (
            <div className="space-y-2">
              {communityPosts.map((post) => (
                <div
                  key={post.id}
                  className="p-3 border border-slate-200 rounded-2xl bg-white hover:border-indigo-400 hover:shadow-md transition flex items-start justify-between gap-3 group"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <img
                        src={post.storeAvatar}
                        alt={post.storeName}
                        className="w-5 h-5 rounded-full object-cover"
                      />
                      <span className="text-xs font-bold text-slate-800">{post.storeName}</span>
                    </div>
                    <h4 className="text-xs font-bold text-slate-900 mb-0.5">{post.title}</h4>
                    <p className="text-[11px] text-slate-500 line-clamp-2">{post.content}</p>
                  </div>
                  <button
                    onClick={() => {
                      onSharePost({
                        id: post.id,
                        storeName: post.storeName,
                        storeAvatar: post.storeAvatar,
                        title: post.title,
                        content: post.content,
                        mediaUrl: post.mediaUrl,
                        likesCount: post.likesCount,
                      });
                      onClose();
                    }}
                    className="p-2 rounded-xl bg-indigo-50 group-hover:bg-indigo-600 text-indigo-600 group-hover:text-white transition cursor-pointer shrink-0 mt-2"
                    title="Share Post"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
