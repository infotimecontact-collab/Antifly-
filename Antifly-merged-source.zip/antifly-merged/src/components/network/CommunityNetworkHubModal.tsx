import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Zap,
  Truck,
  ShoppingBag,
  Tag,
  DollarSign,
  Share2,
  Users,
  Compass,
  Navigation,
  Clock,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  TrendingUp,
  MapPin,
  Camera,
  Repeat,
  Layers,
  Activity,
  Sliders,
  Cpu,
  RefreshCw,
  Plus,
  Radio,
  FileText,
  AlertCircle,
  ThumbsUp,
  Award,
  ChevronRight,
  Flame,
  Check,
  Info,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  UserCapabilityPowers,
  CommunityDeliveryOpportunity,
  SecondHandProductAssessment,
  ProductExchangeOffer,
  TimeToEarnOption,
  CommerceGraphNode,
  CommerceGraphEdge,
  NoCodeBusinessRule,
  LedgerFinancialEntry,
  INITIAL_CAPABILITY_POWERS,
  INITIAL_COMMUNITY_DELIVERIES,
  INITIAL_SECOND_HAND_ASSESSMENTS,
  INITIAL_EXCHANGE_OFFERS,
  INITIAL_TIME_TO_EARN_OPTIONS,
  INITIAL_COMMERCE_GRAPH_NODES,
  INITIAL_COMMERCE_GRAPH_EDGES,
  INITIAL_NO_CODE_BUSINESS_RULES,
  INITIAL_LEDGER_ENTRIES,
} from '../../data/networkCommerceData';

interface CommunityNetworkHubModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'intent' | 'deliveries' | 'detour' | 'time' | 'sell_ai' | 'exchange' | 'graph' | 'rules_ledger' | 'command_brain';
}

export const CommunityNetworkHubModal: React.FC<CommunityNetworkHubModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'intent',
}) => {
  const { showToast, formatPrice } = useApp();

  const [activeTab, setActiveTab] = useState<
    'intent' | 'deliveries' | 'detour' | 'time' | 'sell_ai' | 'exchange' | 'graph' | 'rules_ledger' | 'command_brain'
  >(initialTab);

  // Dynamic Capabilities
  const [capabilities, setCapabilities] = useState<UserCapabilityPowers>(INITIAL_CAPABILITY_POWERS);

  // Delivery opportunities state
  const [deliveries, setDeliveries] = useState<CommunityDeliveryOpportunity[]>(INITIAL_COMMUNITY_DELIVERIES);
  const [activeDeliveryId, setActiveDeliveryId] = useState<string>(INITIAL_COMMUNITY_DELIVERIES[0]?.id || '');
  const [isMultiParcelAdded, setIsMultiParcelAdded] = useState<boolean>(false);

  // Detour Matcher state
  const [detourOrigin, setDetourOrigin] = useState<string>('Indore (Vijay Nagar)');
  const [detourDest, setDetourDest] = useState<string>('Khandwa (Anand Nagar)');
  const [detourTime, setDetourTime] = useState<string>('Today 5:30 PM');
  const [detourRadiusKm, setDetourRadiusKm] = useState<number>(3.0);
  const [isDetourSearching, setIsDetourSearching] = useState<boolean>(false);

  // Time-to-Earn State
  const [selectedTimeMinutes, setSelectedTimeMinutes] = useState<number>(30);
  const [timeOptions, setTimeOptions] = useState<TimeToEarnOption[]>(INITIAL_TIME_TO_EARN_OPTIONS);

  // Sell Anything AI State
  const [assessments, setAssessments] = useState<SecondHandProductAssessment[]>(INITIAL_SECOND_HAND_ASSESSMENTS);
  const [selectedAssessmentId, setSelectedAssessmentId] = useState<string>(INITIAL_SECOND_HAND_ASSESSMENTS[0]?.id || '');
  const [isScanningPhoto, setIsScanningPhoto] = useState<boolean>(false);
  const [newListingName, setNewListingName] = useState<string>('');
  const [newListingCategory, setNewListingCategory] = useState<string>('Electronics');
  const [newListingCondition, setNewListingCondition] = useState<'Pristine (Like New)' | 'Excellent' | 'Good (Minor Signs)' | 'Fair (Used)'>('Pristine (Like New)');

  // Exchange & Barter State
  const [exchangeOffers, setExchangeOffers] = useState<ProductExchangeOffer[]>(INITIAL_EXCHANGE_OFFERS);
  const [selectedExchangeId, setSelectedExchangeId] = useState<string>(INITIAL_EXCHANGE_OFFERS[0]?.id || '');
  const [newExchangeTitle, setNewExchangeTitle] = useState<string>('');

  // Rules & Ledger State
  const [rules, setRules] = useState<NoCodeBusinessRule[]>(INITIAL_NO_CODE_BUSINESS_RULES);
  const [ledgerEntries, setLedgerEntries] = useState<LedgerFinancialEntry[]>(INITIAL_LEDGER_ENTRIES);

  // AI Command Brain Real-Time Simulation
  const [surgeZoneMultiplier, setSurgeZoneMultiplier] = useState<number>(1.25);
  const [aiInsightAccepted, setAiInsightAccepted] = useState<boolean>(false);

  if (!isOpen) return null;

  const currentDelivery = deliveries.find((d) => d.id === activeDeliveryId) || deliveries[0];
  const currentAssessment = assessments.find((a) => a.id === selectedAssessmentId) || assessments[0];
  const currentExchange = exchangeOffers.find((e) => e.id === selectedExchangeId) || exchangeOffers[0];

  const handleToggleEarnMode = () => {
    setCapabilities((prev) => ({
      ...prev,
      deliveryPower: {
        ...prev.deliveryPower,
        earnModeActive: !prev.deliveryPower.earnModeActive,
      },
    }));
    const newStatus = !capabilities.deliveryPower.earnModeActive;
    if (newStatus) {
      showToast('🟢 EARN MODE ACTIVE: You are now an available community delivery partner. Free to accept detour parcels!');
    } else {
      showToast('⚪ EARN MODE OFF: Returned to ordinary customer mode.');
    }
  };

  const handleAcceptDelivery = (oppId: string) => {
    setDeliveries((prev) =>
      prev.map((d) =>
        d.id === oppId
          ? {
              ...d,
              status: 'in_transit',
              assignedPartnerName: 'You (Community Hero)',
            }
          : d
      )
    );
    showToast(`🎉 Delivery Accepted! Secure OTP generated. Reward: ₹${currentDelivery.rewardAmountINR + (isMultiParcelAdded ? (currentDelivery.multiParcelAddon?.extraRewardINR || 0) : 0)}`);
  };

  const handleSkipDelivery = (oppId: string) => {
    setDeliveries((prev) => prev.map((d) => (d.id === oppId ? { ...d, status: 'skipped' } : d)));
    showToast('Skipped opportunity. Matching engine will re-route.');
  };

  const handleSimulateAiScan = () => {
    setIsScanningPhoto(true);
    setTimeout(() => {
      setIsScanningPhoto(false);
      const newEntry: SecondHandProductAssessment = {
        id: `sh-scan-${Date.now()}`,
        productName: newListingName || 'Apple MacBook Air M1 (256GB Space Grey)',
        category: newListingCategory,
        originalMrp: 99900,
        suggestedSellingPrice: 51500,
        photos: ['https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600'],
        sellerDeclaredCondition: newListingCondition,
        aiVisualAssessment: {
          overallGrade: 'Grade A+ (Pristine)',
          confidenceScorePct: 98.2,
          cosmeticWearObservation: 'Zero micro-scratches on aluminum chassis. Keyboard keycaps have original matte finish with zero shine.',
          screenAndDisplayStatus: 'Retina Display 100% spotless. Anti-reflective coating intact.',
          functionalIntegrityCheck: 'Battery cycle count 42 (99% health capacity). All keys, trackpad, and MagSafe operational.',
          estimatedDepreciationPct: 48.4,
          detectedAccessories: ['Original 30W USB-C Power Adapter', 'Braided Cable', 'Original Box'],
          missingAccessories: [],
          fraudRiskIndicator: 'Verified Safe',
          transparencySummary: 'AI multi-spectral verification completed. Declared condition matches physical unit perfectly.',
        },
        isExchangeEligible: true,
        sellerCity: 'Indore (Vijay Nagar)',
        sellerTrustScore: 975,
      };
      setAssessments((prev) => [newEntry, ...prev]);
      setSelectedAssessmentId(newEntry.id);
      showToast('✨ AI Visual Condition Verification Complete! Listing Passport Generated.');
    }, 1200);
  };

  const handleCreateExchangeOffer = () => {
    if (!newExchangeTitle.trim()) {
      showToast('Please enter an exchange item description.');
      return;
    }
    const newOffer: ProductExchangeOffer = {
      id: `exch-${Date.now()}`,
      title: newExchangeTitle,
      offeredItem: {
        title: newExchangeTitle,
        category: 'Lifestyle & Gadgets',
        condition: 'Excellent',
        estimatedValueINR: 24000,
        image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500',
        location: 'Indore',
      },
      targetCategoryOrItems: ['Smartwatch', 'Bicycle', 'Audio Gear'],
      cashAdjustmentINR: 0,
      tradeType: 'Direct Item Swap',
      ownerId: 'usr-you',
      ownerName: 'You (Verified Citizen)',
      ownerCity: 'Indore',
      ownerAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      communityTrustScore: 920,
      aiTradeFairnessScorePct: 96,
      status: 'open',
      datePosted: 'Just now',
    };
    setExchangeOffers((prev) => [newOffer, ...prev]);
    setSelectedExchangeId(newOffer.id);
    setNewExchangeTitle('');
    showToast('🔄 Exchange offer published to Community Barter Network!');
  };

  const handleToggleRule = (ruleId: string) => {
    setRules((prev) =>
      prev.map((r) => (r.id === ruleId ? { ...r, isActive: !r.isActive } : r))
    );
    showToast('Rule status updated.');
  };

  return (
    <div
      id="community-network-modal-overlay"
      className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-fadeIn"
    >
      <div
        id="community-network-modal-container"
        className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-6xl shadow-2xl text-slate-100 flex flex-col max-h-[94vh] overflow-hidden"
      >
        {/* TOP FLAGSHIP BAR */}
        <div className="bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-3 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center font-black text-white shadow-inner">
              <Zap className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black tracking-tight">
                  THE PEOPLE-POWERED COMMERCE NETWORK
                </h2>
                <span className="text-[10px] bg-white/20 backdrop-blur-md font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider">
                  Global Ecosystem
                </span>
              </div>
              <p className="text-xs text-white/80 font-medium">
                «ONE PERSON → BUY → SELL → DELIVER → EARN → CREATE → CONNECT»
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* EARN MODE TRIGGER */}
            <button
              id="global-earn-mode-toggle-btn"
              onClick={handleToggleEarnMode}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-full font-bold text-xs shadow-md transition cursor-pointer ${
                capabilities.deliveryPower.earnModeActive
                  ? 'bg-emerald-400 text-slate-800 ring-2 ring-emerald-300 animate-pulse'
                  : 'bg-white/20 hover:bg-white/30 text-white'
              }`}
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  capabilities.deliveryPower.earnModeActive ? 'bg-white' : 'bg-rose-300'
                }`}
              />
              <span>
                {capabilities.deliveryPower.earnModeActive ? 'EARN MODE: ON' : 'EARN MODE: OFF'}
              </span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 6 DYNAMIC POWERS STRIP */}
        <div className="bg-white/90 border-b border-slate-800 px-4 sm:px-6 py-2.5 flex items-center justify-between gap-2 overflow-x-auto text-xs scrollbar-none">
          <div className="flex items-center gap-2 min-w-max">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Your Dynamic Powers:
            </span>

            {/* Buying Power */}
            <span className="flex items-center gap-1.5 bg-emerald-950/60 border border-emerald-800/80 text-emerald-300 px-2.5 py-1 rounded-lg font-semibold">
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Buying Power (Trust: {capabilities.buyingPower.trustScore})</span>
            </span>

            {/* Selling Power */}
            <span className="flex items-center gap-1.5 bg-blue-950/60 border border-blue-800/80 text-blue-300 px-2.5 py-1 rounded-lg font-semibold">
              <Tag className="w-3.5 h-3.5" />
              <span>Selling Power ({capabilities.sellingPower.itemsListedCount} Active Items)</span>
            </span>

            {/* Delivery Power */}
            <span className="flex items-center gap-1.5 bg-amber-950/60 border border-amber-800/80 text-amber-300 px-2.5 py-1 rounded-lg font-semibold">
              <Truck className="w-3.5 h-3.5" />
              <span>Delivery Power ({capabilities.deliveryPower.deliveriesCompleted} Fulfilled)</span>
            </span>

            {/* Social Power */}
            <span className="flex items-center gap-1.5 bg-purple-950/60 border border-purple-800/80 text-purple-300 px-2.5 py-1 rounded-lg font-semibold">
              <Users className="w-3.5 h-3.5" />
              <span>Social Power ({capabilities.socialPower.followersCount} Followers)</span>
            </span>

            {/* Earning Power */}
            <span className="flex items-center gap-1.5 bg-rose-950/60 border border-rose-800/80 text-rose-300 px-2.5 py-1 rounded-lg font-semibold">
              <DollarSign className="w-3.5 h-3.5" />
              <span>Earning Wallet (₹{capabilities.earningPower.withdrawableWalletINR})</span>
            </span>
          </div>
        </div>

        {/* PRIMARY INTENT BAR: "WHAT DO YOU WANT TO DO?" */}
        <div className="bg-slate-900 border-b border-slate-800 px-4 sm:px-6 py-2.5 flex items-center justify-between gap-3 overflow-x-auto scrollbar-none">
          <div className="flex items-center gap-1.5 sm:gap-2 min-w-max">
            <span className="text-[11px] font-black text-amber-400 uppercase tracking-wider mr-1 flex items-center gap-1">
              <Compass className="w-3.5 h-3.5" /> Intent:
            </span>

            <button
              onClick={() => setActiveTab('intent')}
              className={`px-3 py-1.5 rounded-xl font-extrabold text-xs transition cursor-pointer ${
                activeTab === 'intent'
                  ? 'bg-gradient-to-r from-red-600 to-rose-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              🌟 EXPLORE
            </button>

            <button
              onClick={() => setActiveTab('deliveries')}
              className={`px-3 py-1.5 rounded-xl font-extrabold text-xs transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'deliveries'
                  ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Truck className="w-3.5 h-3.5 text-amber-400" />
              <span>DELIVER & EARN</span>
            </button>

            <button
              onClick={() => setActiveTab('detour')}
              className={`px-3 py-1.5 rounded-xl font-extrabold text-xs transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'detour'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Navigation className="w-3.5 h-3.5 text-emerald-400" />
              <span>DESTINATION DETOUR</span>
            </button>

            <button
              onClick={() => setActiveTab('time')}
              className={`px-3 py-1.5 rounded-xl font-extrabold text-xs transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'time'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Clock className="w-3.5 h-3.5 text-blue-400" />
              <span>TIME AS ASSET</span>
            </button>

            <button
              onClick={() => setActiveTab('sell_ai')}
              className={`px-3 py-1.5 rounded-xl font-extrabold text-xs transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'sell_ai'
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-300" />
              <span>SELL ANYTHING (AI)</span>
            </button>

            <button
              onClick={() => setActiveTab('exchange')}
              className={`px-3 py-1.5 rounded-xl font-extrabold text-xs transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'exchange'
                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Repeat className="w-3.5 h-3.5 text-cyan-300" />
              <span>BARTER / SWAP</span>
            </button>

            <button
              onClick={() => setActiveTab('graph')}
              className={`px-3 py-1.5 rounded-xl font-extrabold text-xs transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'graph'
                  ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-indigo-300" />
              <span>COMMERCE GRAPH</span>
            </button>

            <button
              onClick={() => setActiveTab('rules_ledger')}
              className={`px-3 py-1.5 rounded-xl font-extrabold text-xs transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'rules_ledger'
                  ? 'bg-gradient-to-r from-rose-600 to-red-700 text-white shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Sliders className="w-3.5 h-3.5 text-rose-400" />
              <span>NO-CODE RULES & LEDGER</span>
            </button>

            <button
              onClick={() => setActiveTab('command_brain')}
              className={`px-3 py-1.5 rounded-xl font-extrabold text-xs transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'command_brain'
                  ? 'bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Activity className="w-3.5 h-3.5 text-teal-300" />
              <span>AI COMMAND BRAIN</span>
            </button>
          </div>
        </div>

        {/* MODAL MAIN BODY VIEWPORT */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-white/60 space-y-6">
          {/* TAB 1: INTENT & OVERVIEW */}
          {activeTab === 'intent' && (
            <div className="space-y-6 animate-fadeIn">
              {/* Hero Banner */}
              <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 border border-indigo-900/50 p-6 sm:p-8">
                <div className="relative z-10 max-w-2xl space-y-3">
                  <div className="inline-flex items-center gap-1.5 bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 px-3 py-1 rounded-full text-xs font-bold">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>The Participatory Digital Economy</span>
                  </div>
                  <h1 className="text-2xl sm:text-3xl font-black text-white leading-tight">
                    What do you want to do right now?
                  </h1>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    You don't need separate driver accounts, seller apps, or customer logins. One verified identity dynamically unlocks buying, selling, community delivery, bartering, and micro-earning across all cities.
                  </p>
                </div>
              </div>

              {/* 6 High-Impact Action Tiles */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* 1. Deliver & Earn */}
                <div
                  onClick={() => setActiveTab('deliveries')}
                  className="bg-slate-900/90 hover:bg-slate-850 border border-amber-500/30 hover:border-amber-400 p-5 rounded-2xl cursor-pointer transition group shadow-lg flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-105 transition">
                      <Truck className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-base font-extrabold text-white group-hover:text-amber-400 transition flex items-center justify-between">
                        <span>DELIVER ON YOUR WAY</span>
                        <ArrowRight className="w-4 h-4" />
                      </h3>
                      <p className="text-xs text-slate-400 mt-1">
                        Turn your commute or spare minutes into instant earnings. Free delivery for buyer, funded by ecosystem economics.
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-amber-400 font-bold">
                    <span>{deliveries.filter((d) => d.status === 'available').length} Opportunities Available</span>
                    <span>Earn ₹80 – ₹480</span>
                  </div>
                </div>

                {/* 2. Destination Detour */}
                <div
                  onClick={() => setActiveTab('detour')}
                  className="bg-slate-900/90 hover:bg-slate-850 border border-emerald-500/30 hover:border-emerald-400 p-5 rounded-2xl cursor-pointer transition group shadow-lg flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition">
                      <Navigation className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-base font-extrabold text-white group-hover:text-emerald-400 transition flex items-center justify-between">
                        <span>DESTINATION MATCHING</span>
                        <ArrowRight className="w-4 h-4" />
                      </h3>
                      <p className="text-xs text-slate-400 mt-1">
                        Travelling Indore → Khandwa or across town? Carry compatible packages with minimal detour (0.8 km) and get rewarded.
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-emerald-400 font-bold">
                    <span>Detour Radius ≤ 3 km</span>
                    <span>Up to ₹750/trip</span>
                  </div>
                </div>

                {/* 3. Time as an Asset */}
                <div
                  onClick={() => setActiveTab('time')}
                  className="bg-slate-900/90 hover:bg-slate-850 border border-blue-500/30 hover:border-blue-400 p-5 rounded-2xl cursor-pointer transition group shadow-lg flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="w-12 h-12 rounded-2xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 group-hover:scale-105 transition">
                      <Clock className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-base font-extrabold text-white group-hover:text-blue-400 transition flex items-center justify-between">
                        <span>TIME-TO-EARN (15–120m)</span>
                        <ArrowRight className="w-4 h-4" />
                      </h3>
                      <p className="text-xs text-slate-400 mt-1">
                        "I have 30 minutes free." Instant match with nearby micro-deliveries and verified community tasks.
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-blue-400 font-bold">
                    <span>Instant UPI Settlement</span>
                    <span>15m / 30m / 60m Slots</span>
                  </div>
                </div>

                {/* 4. Sell Anything (AI Condition) */}
                <div
                  onClick={() => setActiveTab('sell_ai')}
                  className="bg-slate-900/90 hover:bg-slate-850 border border-purple-500/30 hover:border-purple-400 p-5 rounded-2xl cursor-pointer transition group shadow-lg flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 group-hover:scale-105 transition">
                      <Camera className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-base font-extrabold text-white group-hover:text-purple-400 transition flex items-center justify-between">
                        <span>SELL WITH AI VISION</span>
                        <ArrowRight className="w-4 h-4" />
                      </h3>
                      <p className="text-xs text-slate-400 mt-1">
                        Snap a photo of your phone, camera, or furniture. AI inspects wear, grades condition, and generates an honest listing.
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-purple-400 font-bold">
                    <span>Grade A+ to C Verification</span>
                    <span>Anti-Fraud Shield</span>
                  </div>
                </div>

                {/* 5. Barter & Swap */}
                <div
                  onClick={() => setActiveTab('exchange')}
                  className="bg-slate-900/90 hover:bg-slate-850 border border-cyan-500/30 hover:border-cyan-400 p-5 rounded-2xl cursor-pointer transition group shadow-lg flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-105 transition">
                      <Repeat className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-base font-extrabold text-white group-hover:text-cyan-400 transition flex items-center justify-between">
                        <span>PRODUCT BARTER & SWAP</span>
                        <ArrowRight className="w-4 h-4" />
                      </h3>
                      <p className="text-xs text-slate-400 mt-1">
                        Swap Product A for Product B, or item + cash difference. AI calculates trade fairness index.
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-cyan-400 font-bold">
                    <span>{exchangeOffers.length} Active Barter Offers</span>
                    <span>Fair-Value AI Check</span>
                  </div>
                </div>

                {/* 6. Commerce Graph & Rules */}
                <div
                  onClick={() => setActiveTab('graph')}
                  className="bg-slate-900/90 hover:bg-slate-850 border border-rose-500/30 hover:border-rose-400 p-5 rounded-2xl cursor-pointer transition group shadow-lg flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 group-hover:scale-105 transition">
                      <Layers className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-base font-extrabold text-white group-hover:text-rose-400 transition flex items-center justify-between">
                        <span>COMMERCE GRAPH & TRUST</span>
                        <ArrowRight className="w-4 h-4" />
                      </h3>
                      <p className="text-xs text-slate-400 mt-1">
                        Explore the network of People, Products, Routes, and Community Trust Scores connecting your local ecosystem.
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-rose-400 font-bold">
                    <span>10 Core Graph Nodes</span>
                    <span>Audit-Proof Ledger</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: DYNAMIC COMMUNITY DELIVERIES */}
          {activeTab === 'deliveries' && (
            <div className="space-y-6 animate-fadeIn">
              <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-black">
                    <Truck className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">Dynamic Community Delivery Market</h3>
                    <p className="text-xs text-slate-400">
                      Multi-dimensional matching engine with transparent funding and free buyer delivery
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleToggleEarnMode}
                  className={`px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-2 ${
                    capabilities.deliveryPower.earnModeActive
                      ? 'bg-emerald-500 text-slate-800 shadow-lg'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${capabilities.deliveryPower.earnModeActive ? 'bg-white animate-ping' : 'bg-slate-400'}`} />
                  <span>{capabilities.deliveryPower.earnModeActive ? 'Active in Radar (Available)' : 'Switch On EARN MODE'}</span>
                </button>
              </div>

              {/* Opportunity Selector Cards & Detail Panel */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Left List: Available Opportunities */}
                <div className="lg:col-span-5 space-y-3">
                  <span className="text-xs font-black text-slate-400 uppercase tracking-wider block">
                    Nearby Matched Opportunities ({deliveries.length})
                  </span>

                  {deliveries.map((d) => (
                    <div
                      key={d.id}
                      onClick={() => {
                        setActiveDeliveryId(d.id);
                        setIsMultiParcelAdded(false);
                      }}
                      className={`p-4 rounded-2xl border cursor-pointer transition ${
                        activeDeliveryId === d.id
                          ? 'bg-amber-950/40 border-amber-500/80 shadow-md ring-1 ring-amber-500/50'
                          : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={d.productImage}
                            alt={d.productName}
                            className="w-12 h-12 rounded-xl object-cover border border-slate-700"
                          />
                          <div>
                            <span className="text-[10px] text-amber-400 font-mono font-bold block">
                              {d.orderNumber}
                            </span>
                            <h4 className="text-xs font-bold text-white line-clamp-1">
                              {d.productName}
                            </h4>
                            <p className="text-[11px] text-slate-400 mt-0.5">
                              {d.pickup.city} → {d.destination.city} ({d.totalRouteKm} km)
                            </p>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="text-sm font-black text-emerald-400 block">
                            ₹{d.rewardAmountINR + d.surgeBonusINR}
                          </span>
                          <span className="text-[10px] bg-emerald-950 text-emerald-300 px-1.5 py-0.2 rounded font-bold">
                            {d.matchingScorePct}% Match
                          </span>
                        </div>
                      </div>

                      <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-slate-500" />
                          {d.estimatedDurationMins} mins
                        </span>
                        <span className="text-amber-300 font-medium">
                          Detour: {d.detourKm} km
                        </span>
                        <span className="text-emerald-400 font-extrabold uppercase">
                          Buyer Delivery ₹0
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Right: Selected Delivery Deep-Dive */}
                <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-amber-400">
                          {currentDelivery.orderNumber}
                        </span>
                        <span className="text-[10px] bg-indigo-950 text-indigo-300 border border-indigo-800 px-2 py-0.5 rounded-full font-bold">
                          {currentDelivery.alongRouteName}
                        </span>
                      </div>
                      <h3 className="text-base font-extrabold text-white mt-1">
                        {currentDelivery.productName}
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Parcel Value: ₹{currentDelivery.productValueINR.toLocaleString()} • {currentDelivery.parcel.size} ({currentDelivery.parcel.weightKg} kg)
                      </p>
                    </div>

                    <div className="text-right bg-emerald-950/60 border border-emerald-800/80 p-3 rounded-xl">
                      <span className="text-[10px] text-emerald-300 font-bold uppercase tracking-wider block">
                        Total Partner Reward
                      </span>
                      <span className="text-xl font-black text-emerald-400">
                        ₹
                        {currentDelivery.rewardAmountINR +
                          currentDelivery.surgeBonusINR +
                          (isMultiParcelAdded ? (currentDelivery.multiParcelAddon?.extraRewardINR || 0) : 0)}
                      </span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        Base ₹{currentDelivery.rewardAmountINR} + Surge ₹{currentDelivery.surgeBonusINR}
                      </span>
                    </div>
                  </div>

                  {/* Multi-Dimensional Matching Engine Radar */}
                  <div className="bg-white p-4 rounded-xl border border-slate-800 space-y-2.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-300 flex items-center gap-1.5">
                        <Cpu className="w-4 h-4 text-purple-400" />
                        Multi-Dimensional Match Index:
                      </span>
                      <span className="font-mono font-black text-emerald-400 text-sm">
                        {currentDelivery.matchingScorePct}% MATCH
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                      <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                        <span className="text-slate-400 block text-[10px]">Route Detour</span>
                        <span className="font-bold text-white">{currentDelivery.matchingSignals.routeCompatibilityPct}% fit ({currentDelivery.detourKm}km)</span>
                      </div>
                      <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                        <span className="text-slate-400 block text-[10px]">Vehicle Fit</span>
                        <span className="font-bold text-white">{currentDelivery.matchingSignals.vehicleSuitabilityPct}% (Motorcycle)</span>
                      </div>
                      <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                        <span className="text-slate-400 block text-[10px]">Trust Passport</span>
                        <span className="font-bold text-white">{currentDelivery.matchingSignals.trustScorePct}% (920 score)</span>
                      </div>
                      <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                        <span className="text-slate-400 block text-[10px]">Acceptance SLA</span>
                        <span className="font-bold text-white">{currentDelivery.matchingSignals.historicalAcceptancePct}% rating</span>
                      </div>
                    </div>
                  </div>

                  {/* Route & Pickup / Drop Steps */}
                  <div className="space-y-3 bg-white/80 p-4 rounded-xl border border-slate-800">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-xs mt-0.5">
                        1
                      </div>
                      <div className="flex-1 text-xs">
                        <span className="font-bold text-white">{currentDelivery.pickup.hubName}</span>
                        <p className="text-slate-400">{currentDelivery.pickup.address}, {currentDelivery.pickup.city}</p>
                        <p className="text-[10px] text-blue-400 font-mono mt-0.5">
                          Contact: {currentDelivery.pickup.contactName} • {currentDelivery.pickup.readyAt}
                        </p>
                      </div>
                    </div>

                    <div className="border-l-2 border-dashed border-slate-700 ml-3 h-4" />

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs mt-0.5">
                        2
                      </div>
                      <div className="flex-1 text-xs">
                        <span className="font-bold text-white">{currentDelivery.destination.recipientName}</span>
                        <p className="text-slate-400">{currentDelivery.destination.address}, {currentDelivery.destination.city}</p>
                        <p className="text-[10px] text-emerald-400 font-mono mt-0.5">
                          Deadline: {currentDelivery.destination.deliveryDeadline}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Transparent Economic Funding Breakdown (Free Buyer Delivery) */}
                  <div className="bg-white p-4 rounded-xl border border-slate-800 space-y-2 text-xs">
                    <div className="flex items-center justify-between text-slate-300 font-bold border-b border-slate-800 pb-1.5">
                      <span>Logistics Economics (Transparent Engine):</span>
                      <span className="text-emerald-400 font-black">Customer Charged: ₹0.00</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-[11px] text-slate-400 pt-1">
                      <div>
                        <span>Seller Contribution:</span>
                        <p className="font-bold text-white">₹{currentDelivery.fundingBreakdown.sellerLogisticsContributionINR}</p>
                      </div>
                      <div>
                        <span>Platform Subsidy:</span>
                        <p className="font-bold text-white">₹{currentDelivery.fundingBreakdown.platformSubsidyINR}</p>
                      </div>
                      <div>
                        <span>Net Platform Margin:</span>
                        <p className="font-bold text-white">₹{currentDelivery.fundingBreakdown.netPlatformMarginINR}</p>
                      </div>
                    </div>
                  </div>

                  {/* Multi-Parcel Intelligence Proposer */}
                  {currentDelivery.multiParcelEligible && currentDelivery.multiParcelAddon && (
                    <div className="bg-gradient-to-r from-amber-950/40 to-orange-950/40 border border-amber-500/40 p-4 rounded-xl flex items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-1.5 text-amber-300 font-bold text-xs">
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Multi-Parcel Opportunity (Same Route)</span>
                        </div>
                        <p className="text-xs text-slate-300 mt-0.5">
                          Add: {currentDelivery.multiParcelAddon.secondaryProductName} (+{currentDelivery.multiParcelAddon.extraDetourKm}km detour, +{currentDelivery.multiParcelAddon.extraDurationMins}m)
                        </p>
                      </div>

                      <button
                        onClick={() => {
                          setIsMultiParcelAdded(!isMultiParcelAdded);
                          showToast(
                            isMultiParcelAdded
                              ? 'Removed second parcel'
                              : `Added second delivery! +₹${currentDelivery.multiParcelAddon?.extraRewardINR} reward.`
                          );
                        }}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                          isMultiParcelAdded
                            ? 'bg-amber-400 text-slate-800'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-400/40 hover:bg-amber-500/30'
                        }`}
                      >
                        {isMultiParcelAdded ? '✓ Added (+₹' + currentDelivery.multiParcelAddon.extraRewardINR + ')' : '+ Add (+₹' + currentDelivery.multiParcelAddon.extraRewardINR + ')'}
                      </button>
                    </div>
                  )}

                  {/* Accept / Skip Action Row */}
                  <div className="flex items-center gap-3 pt-2">
                    <button
                      onClick={() => handleAcceptDelivery(currentDelivery.id)}
                      disabled={currentDelivery.status === 'in_transit'}
                      className={`flex-1 py-3 rounded-xl font-extrabold text-sm shadow-lg transition cursor-pointer flex items-center justify-center gap-2 ${
                        currentDelivery.status === 'in_transit'
                          ? 'bg-emerald-600/50 text-white cursor-not-allowed'
                          : 'bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-slate-800'
                      }`}
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>
                        {currentDelivery.status === 'in_transit'
                          ? 'IN TRANSIT (ASSIGNED TO YOU)'
                          : `ACCEPT & DELIVER (EARN ₹${currentDelivery.rewardAmountINR + currentDelivery.surgeBonusINR + (isMultiParcelAdded ? (currentDelivery.multiParcelAddon?.extraRewardINR || 0) : 0)})`}
                      </span>
                    </button>

                    <button
                      onClick={() => handleSkipDelivery(currentDelivery.id)}
                      className="px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-400 hover:text-white font-bold text-xs transition cursor-pointer"
                    >
                      SKIP
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: DESTINATION ROUTE DETOUR MATCHING ("CARRY & EARN") */}
          {activeTab === 'detour' && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-950 p-6 rounded-3xl border border-emerald-800/60 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                    <Navigation className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-white">Destination Matching: Transform Human Movement into Logistics</h3>
                    <p className="text-xs text-slate-300">
                      Already travelling between cities or neighborhoods? Enter your route and carry compatible parcels with near-zero detour.
                    </p>
                  </div>
                </div>

                {/* Route Configuration Bar */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-2">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-emerald-300 uppercase">From (Origin):</label>
                    <input
                      type="text"
                      value={detourOrigin}
                      onChange={(e) => setDetourOrigin(e.target.value)}
                      className="w-full bg-slate-900 border border-emerald-700/50 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:outline-hidden"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-emerald-300 uppercase">To (Destination):</label>
                    <input
                      type="text"
                      value={detourDest}
                      onChange={(e) => setDetourDest(e.target.value)}
                      className="w-full bg-slate-900 border border-emerald-700/50 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:outline-hidden"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-emerald-300 uppercase">Departure Time:</label>
                    <input
                      type="text"
                      value={detourTime}
                      onChange={(e) => setDetourTime(e.target.value)}
                      className="w-full bg-slate-900 border border-emerald-700/50 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:outline-hidden"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-emerald-300 uppercase">Max Allowed Detour:</label>
                    <div className="flex items-center gap-2">
                      <select
                        value={detourRadiusKm}
                        onChange={(e) => setDetourRadiusKm(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-emerald-700/50 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:outline-hidden"
                      >
                        <option value={1.5}>1.5 km Detour Max</option>
                        <option value={3.0}>3.0 km Detour Max</option>
                        <option value={5.0}>5.0 km Detour Max</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Matched Detour Opportunities on Indore -> Khandwa Route */}
              <div className="space-y-3">
                <span className="text-xs font-black text-slate-400 uppercase tracking-wider block">
                  Matched Packages Along Route ({detourOrigin} ➔ {detourDest})
                </span>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Opportunity 1: Traditional Maheshwari Saree */}
                  <div className="bg-slate-900 border border-emerald-500/40 rounded-2xl p-5 space-y-4 shadow-md">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <img
                          src="https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=500"
                          alt="Saree"
                          className="w-14 h-14 rounded-xl object-cover border border-slate-700"
                        />
                        <div>
                          <span className="text-[10px] text-emerald-400 font-mono font-bold">WISE-COMM-9940</span>
                          <h4 className="text-sm font-bold text-white">Maheshwari Pure Silk Saree</h4>
                          <p className="text-xs text-slate-400">Pickup: Chhatribagh (Indore) → Drop: Civil Lines (Khandwa)</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-lg font-black text-emerald-400">₹600</span>
                        <span className="text-[10px] text-slate-400 block">Detour Earning</span>
                      </div>
                    </div>

                    <div className="bg-white p-3 rounded-xl border border-slate-800 grid grid-cols-3 gap-2 text-xs">
                      <div>
                        <span className="text-slate-500 block text-[10px]">Detour Distance</span>
                        <span className="font-bold text-emerald-400">1.4 km only</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Parcel Size</span>
                        <span className="font-bold text-white">Small Gift Box (0.8kg)</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Match Affinity</span>
                        <span className="font-bold text-white">96% Route Match</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleAcceptDelivery('comm-del-102')}
                      className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-extrabold text-xs transition cursor-pointer shadow-md"
                    >
                      CARRY & EARN ₹600 (ON YOUR ROUTE)
                    </button>
                  </div>

                  {/* Opportunity 2: Electronics & Campus Drop */}
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-md">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <img
                          src="https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=500"
                          alt="Camera"
                          className="w-14 h-14 rounded-xl object-cover border border-slate-700"
                        />
                        <div>
                          <span className="text-[10px] text-amber-400 font-mono font-bold">WISE-COMM-6625</span>
                          <h4 className="text-sm font-bold text-white">Fujifilm Instax Camera Bundle</h4>
                          <p className="text-xs text-slate-400">Pickup: Palasia → Drop: IIT Indore (Simrol Corridor)</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-lg font-black text-amber-400">₹310</span>
                        <span className="text-[10px] text-slate-400 block">Detour Earning</span>
                      </div>
                    </div>

                    <div className="bg-white p-3 rounded-xl border border-slate-800 grid grid-cols-3 gap-2 text-xs">
                      <div>
                        <span className="text-slate-500 block text-[10px]">Detour Distance</span>
                        <span className="font-bold text-amber-400">1.8 km</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Parcel Size</span>
                        <span className="font-bold text-white">Medium Box (1.4kg)</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Match Affinity</span>
                        <span className="font-bold text-white">88% Route Match</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleAcceptDelivery('comm-del-104')}
                      className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-800 font-extrabold text-xs transition cursor-pointer shadow-md"
                    >
                      CARRY & EARN ₹310 (ON YOUR ROUTE)
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: TIME AS AN ASSET */}
          {activeTab === 'time' && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-slate-900 border border-blue-800/60 p-6 rounded-3xl space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-black">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-white">Time-To-Earn: Turn Available Minutes into Income</h3>
                    <p className="text-xs text-slate-300">
                      Specify how much free time you have right now. The engine filters rapid opportunities that fit inside your schedule.
                    </p>
                  </div>
                </div>

                {/* Time Selector Buttons */}
                <div className="flex items-center gap-2 pt-2 flex-wrap">
                  {[15, 30, 60, 120].map((mins) => (
                    <button
                      key={mins}
                      onClick={() => setSelectedTimeMinutes(mins)}
                      className={`px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-2 ${
                        selectedTimeMinutes === mins
                          ? 'bg-blue-500 text-white shadow-md ring-2 ring-blue-400'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      <Clock className="w-3.5 h-3.5" />
                      <span>{mins} MINUTES FREE</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Matched Time Slots */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {timeOptions
                  .filter((t) => t.timeWindowMinutes <= selectedTimeMinutes)
                  .map((t) => (
                    <div
                      key={t.id}
                      className="bg-slate-900 border border-slate-800 hover:border-blue-500/50 p-5 rounded-2xl space-y-3 transition"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-1">
                          <span className="text-[10px] bg-blue-950 text-blue-300 border border-blue-800 px-2 py-0.5 rounded-full font-bold">
                            ⏱️ {t.timeWindowMinutes} Mins Slot • {t.parcelSize}
                          </span>
                          <h4 className="text-sm font-bold text-white">{t.title}</h4>
                          <p className="text-xs text-slate-400">{t.routeSummary} ({t.distanceKm} km)</p>
                        </div>
                        <div className="text-right">
                          <span className="text-base font-black text-emerald-400">
                            ₹{t.estimatedEarningsINR}
                          </span>
                          <span className="text-[10px] text-slate-400 block">Instant UPI</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-3 border-t border-slate-800 text-xs">
                        <span className="text-amber-400 font-bold">{t.urgencyLevel}</span>
                        <button
                          onClick={() => showToast(`Accepted ${t.title}! Earning: ₹${t.estimatedEarningsINR}`)}
                          className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg transition cursor-pointer"
                        >
                          CLAIM TASK
                        </button>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* TAB 5: SELL ANYTHING (AI CONDITION VERIFICATION) */}
          {activeTab === 'sell_ai' && (
            <div className="space-y-6 animate-fadeIn">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Left: Quick AI Listing Creation Wizard */}
                <div className="lg:col-span-5 bg-slate-900 border border-purple-800/60 p-5 rounded-2xl space-y-4">
                  <div className="flex items-center gap-2.5 text-purple-300 font-extrabold text-sm border-b border-slate-800 pb-3">
                    <Sparkles className="w-4 h-4" />
                    <span>AI Instant Listing & Condition Scan</span>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">Item Title / Model:</label>
                      <input
                        type="text"
                        placeholder="e.g. Apple MacBook Air M1 (256GB Space Grey)"
                        value={newListingName}
                        onChange={(e) => setNewListingName(e.target.value)}
                        className="w-full bg-white border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-hidden"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-400 font-bold mb-1">Category:</label>
                        <select
                          value={newListingCategory}
                          onChange={(e) => setNewListingCategory(e.target.value)}
                          className="w-full bg-white border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-hidden"
                        >
                          <option value="Electronics">Electronics</option>
                          <option value="Cameras & Lenses">Cameras & Lenses</option>
                          <option value="Furniture">Furniture</option>
                          <option value="Fashion">Fashion</option>
                          <option value="Books">Books</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-slate-400 font-bold mb-1">Declared Condition:</label>
                        <select
                          value={newListingCondition}
                          onChange={(e) => setNewListingCondition(e.target.value as any)}
                          className="w-full bg-white border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-hidden"
                        >
                          <option value="Pristine (Like New)">Pristine (Like New)</option>
                          <option value="Excellent">Excellent</option>
                          <option value="Good (Minor Signs)">Good (Minor Signs)</option>
                          <option value="Fair (Used)">Fair (Used)</option>
                        </select>
                      </div>
                    </div>

                    <button
                      onClick={handleSimulateAiScan}
                      disabled={isScanningPhoto}
                      className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-600 via-pink-600 to-purple-700 hover:from-purple-500 hover:to-pink-500 font-black text-white transition cursor-pointer shadow-lg flex items-center justify-center gap-2"
                    >
                      {isScanningPhoto ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>AI Scanning Visual Condition...</span>
                        </>
                      ) : (
                        <>
                          <Camera className="w-4 h-4" />
                          <span>SCAN PHOTOS & VERIFY CONDITION</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Existing Listings */}
                  <div className="pt-2 space-y-2">
                    <span className="text-[11px] font-bold text-slate-400 uppercase">
                      Verified Second-Hand Listings ({assessments.length})
                    </span>
                    {assessments.map((a) => (
                      <div
                        key={a.id}
                        onClick={() => setSelectedAssessmentId(a.id)}
                        className={`p-2.5 rounded-xl border cursor-pointer flex items-center justify-between text-xs transition ${
                          selectedAssessmentId === a.id
                            ? 'bg-purple-950/50 border-purple-500 text-white'
                            : 'bg-white border-slate-800 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <img src={a.photos[0]} alt="" className="w-8 h-8 rounded-lg object-cover" />
                          <span className="truncate font-semibold">{a.productName}</span>
                        </div>
                        <span className="text-purple-300 font-bold ml-2 shrink-0">₹{a.suggestedSellingPrice.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right: AI Condition Certificate & Digital Passport */}
                <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
                  <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono bg-purple-950 text-purple-300 px-2 py-0.5 rounded font-bold">
                          {currentAssessment.aiVisualAssessment.overallGrade}
                        </span>
                        <span className="text-xs text-emerald-400 font-bold">
                          🛡️ {currentAssessment.aiVisualAssessment.fraudRiskIndicator}
                        </span>
                      </div>
                      <h3 className="text-base font-extrabold text-white mt-1">
                        {currentAssessment.productName}
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Original MRP: ₹{currentAssessment.originalMrp.toLocaleString()} • Fair Market Value: <strong className="text-emerald-400">₹{currentAssessment.suggestedSellingPrice.toLocaleString()}</strong> ({currentAssessment.aiVisualAssessment.estimatedDepreciationPct}% depreciation)
                      </p>
                    </div>

                    <img
                      src={currentAssessment.photos[0]}
                      alt={currentAssessment.productName}
                      className="w-16 h-16 rounded-xl object-cover border border-slate-700"
                    />
                  </div>

                  {/* AI Visual Inspection Transparency Matrix */}
                  <div className="space-y-3 text-xs bg-white p-4 rounded-xl border border-slate-800">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-300 flex items-center gap-1.5">
                        <ShieldCheck className="w-4 h-4 text-emerald-400" />
                        AI Optical Inspection Summary:
                      </span>
                      <span className="text-purple-300 font-mono font-bold">
                        {currentAssessment.aiVisualAssessment.confidenceScorePct}% Precision Index
                      </span>
                    </div>

                    <div className="space-y-2 pt-1">
                      <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800">
                        <span className="text-slate-400 block text-[10px] font-bold uppercase">Cosmetic & Wear Check:</span>
                        <p className="text-slate-200 mt-0.5">{currentAssessment.aiVisualAssessment.cosmeticWearObservation}</p>
                      </div>

                      <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800">
                        <span className="text-slate-400 block text-[10px] font-bold uppercase">Screen / Mechanical Health:</span>
                        <p className="text-slate-200 mt-0.5">{currentAssessment.aiVisualAssessment.screenAndDisplayStatus}</p>
                      </div>

                      <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800">
                        <span className="text-slate-400 block text-[10px] font-bold uppercase">Accessories Included vs Missing:</span>
                        <p className="text-emerald-300 mt-0.5">✓ Included: {currentAssessment.aiVisualAssessment.detectedAccessories.join(', ')}</p>
                        {currentAssessment.aiVisualAssessment.missingAccessories.length > 0 && (
                          <p className="text-rose-400 text-[11px] mt-0.5">⚠️ Missing: {currentAssessment.aiVisualAssessment.missingAccessories.join(', ')}</p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <div className="text-xs text-slate-400">
                      <span>Seller: {currentAssessment.sellerCity} • </span>
                      <span className="text-emerald-400 font-bold">Trust Score {currentAssessment.sellerTrustScore}/1000</span>
                    </div>

                    <button
                      onClick={() => showToast(`Purchased with Peer-to-Peer Escrow Protection: ₹${currentAssessment.suggestedSellingPrice}`)}
                      className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-extrabold text-xs rounded-xl transition cursor-pointer shadow-md"
                    >
                      BUY WITH ESCROW (₹{currentAssessment.suggestedSellingPrice.toLocaleString()})
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: PRODUCT EXCHANGE & BARTER NETWORK */}
          {activeTab === 'exchange' && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-slate-900 border border-cyan-800/60 p-5 rounded-2xl flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-black">
                    <Repeat className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">Product Exchange & Barter Network</h3>
                    <p className="text-xs text-slate-400">
                      Swap goods directly, exchange with cash difference, or give away to community members.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="Offer item to barter (e.g. iPad Pro 11)"
                    value={newExchangeTitle}
                    onChange={(e) => setNewExchangeTitle(e.target.value)}
                    className="bg-white border border-slate-700 px-3 py-1.5 rounded-xl text-xs text-white focus:outline-hidden w-64"
                  />
                  <button
                    onClick={handleCreateExchangeOffer}
                    className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-800 font-bold text-xs rounded-xl transition cursor-pointer"
                  >
                    POST SWAP
                  </button>
                </div>
              </div>

              {/* Barter Offers List */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {exchangeOffers.map((offer) => (
                  <div
                    key={offer.id}
                    className="bg-slate-900 border border-slate-800 hover:border-cyan-500/40 p-5 rounded-2xl space-y-3 transition flex flex-col justify-between"
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-[10px] bg-cyan-950 text-cyan-300 border border-cyan-800 px-2 py-0.5 rounded-full font-bold">
                          🔄 {offer.tradeType}
                        </span>
                        <span className="text-[10px] text-slate-400">{offer.datePosted}</span>
                      </div>

                      <div className="flex items-center gap-3">
                        <img
                          src={offer.offeredItem.image}
                          alt={offer.offeredItem.title}
                          className="w-14 h-14 rounded-xl object-cover border border-slate-700"
                        />
                        <div>
                          <h4 className="text-xs font-bold text-white line-clamp-1">
                            {offer.offeredItem.title}
                          </h4>
                          <p className="text-[11px] text-slate-400">
                            Value: ₹{offer.offeredItem.estimatedValueINR.toLocaleString()} • {offer.offeredItem.condition}
                          </p>
                        </div>
                      </div>

                      <div className="bg-white p-3 rounded-xl border border-slate-800 text-xs space-y-1">
                        <span className="text-[10px] text-cyan-300 font-bold uppercase block">Looking in Exchange:</span>
                        <p className="text-slate-200">{offer.targetCategoryOrItems.join(' • ')}</p>
                        {offer.cashAdjustmentINR !== 0 && (
                          <p className="text-emerald-400 font-bold text-[11px]">
                            + Offering Cash Difference: ₹{offer.cashAdjustmentINR.toLocaleString()}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <img src={offer.ownerAvatar} alt="" className="w-5 h-5 rounded-full object-cover" />
                        <span className="text-slate-300 text-[11px]">{offer.ownerName}</span>
                      </div>

                      <button
                        onClick={() => showToast(`Initiated Trade Proposal for: ${offer.offeredItem.title}`)}
                        className="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-lg text-xs transition cursor-pointer"
                      >
                        PROPOSE SWAP
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 7: COMMERCE GRAPH & TRUST NETWORK */}
          {activeTab === 'graph' && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-black">
                    <Layers className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">Global Commerce Graph & Trust Passport</h3>
                    <p className="text-xs text-slate-400">
                      Connected nodes of People, Products, Locations, Routes, Communities, and Deliveries
                    </p>
                  </div>
                </div>

                <span className="text-xs font-mono bg-indigo-950 text-indigo-300 border border-indigo-800 px-3 py-1 rounded-full font-bold">
                  10 Active Graph Nodes
                </span>
              </div>

              {/* Interactive Graph Nodes Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {INITIAL_COMMERCE_GRAPH_NODES.map((node) => (
                  <div
                    key={node.id}
                    className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-2 hover:border-indigo-500/50 transition"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span
                        className="text-[10px] font-bold px-2 py-0.5 rounded-full uppercase"
                        style={{ backgroundColor: `${node.color}20`, color: node.color }}
                      >
                        {node.category}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">{node.id}</span>
                    </div>

                    <h4 className="text-sm font-bold text-white">{node.label}</h4>
                    <p className="text-xs text-slate-400">{node.metrics}</p>
                  </div>
                ))}
              </div>

              {/* Relationships Stream */}
              <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Active Commerce Graph Relationships:
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                  {INITIAL_COMMERCE_GRAPH_EDGES.map((edge, idx) => (
                    <div key={idx} className="p-2.5 bg-white rounded-xl border border-slate-800/80 flex items-center justify-between">
                      <span className="font-mono text-indigo-300 text-[11px]">{edge.from}</span>
                      <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-300 font-bold">
                        → {edge.relationship} →
                      </span>
                      <span className="font-mono text-emerald-300 text-[11px]">{edge.to}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 8: NO-CODE BUSINESS ENGINE & IMMUTABLE LEDGER */}
          {activeTab === 'rules_ledger' && (
            <div className="space-y-6 animate-fadeIn">
              {/* No-Code Rules Engine */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-400 uppercase tracking-wider">
                    Admin No-Code Business Rules (IF → CONDITION → ACTION)
                  </span>
                  <span className="text-xs text-emerald-400 font-bold">4 Live Rules Active</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {rules.map((r) => (
                    <div
                      key={r.id}
                      className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold text-white">{r.name}</h4>
                        <button
                          onClick={() => handleToggleRule(r.id)}
                          className={`text-[10px] font-black px-2 py-0.5 rounded-full cursor-pointer ${
                            r.isActive ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-slate-800 text-slate-500'
                          }`}
                        >
                          {r.isActive ? 'ACTIVE' : 'DISABLED'}
                        </button>
                      </div>

                      <div className="space-y-1 text-[11px]">
                        <p className="text-amber-300">⚡ Trigger: {r.triggerEvent}</p>
                        <p className="text-slate-400">🔍 Conditions: {r.conditions.join(' AND ')}</p>
                        <p className="text-emerald-400 font-medium">🎯 Action: {r.action}</p>
                      </div>

                      <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-400">
                        Impact: {r.impactMetric}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Financial Double-Entry Ledger */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-white">Immutable Double-Entry Financial Ledger</h4>
                    <p className="text-xs text-slate-400">Cryptographically verifiable transactions and platform economics audit trail</p>
                  </div>
                  <span className="text-xs font-mono bg-emerald-950 text-emerald-300 px-2.5 py-1 rounded-lg font-bold">
                    Zero-Discrepancy Balanced
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-300">
                    <thead className="bg-white text-slate-400 font-bold uppercase text-[10px] border-b border-slate-800">
                      <tr>
                        <th className="p-2.5">Tx ID / Time</th>
                        <th className="p-2.5">Event Type</th>
                        <th className="p-2.5">Customer Charge</th>
                        <th className="p-2.5">Seller Payout</th>
                        <th className="p-2.5">Partner Reward</th>
                        <th className="p-2.5">Platform Margin</th>
                        <th className="p-2.5">Audit Hash</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {ledgerEntries.map((l) => (
                        <tr key={l.id} className="hover:bg-slate-800/40 transition font-mono text-[11px]">
                          <td className="p-2.5 font-bold text-amber-400">{l.id}<br /><span className="text-[9px] text-slate-500">{l.timestamp}</span></td>
                          <td className="p-2.5 text-slate-200">{l.eventType}</td>
                          <td className="p-2.5 text-emerald-400 font-bold">₹{l.customerChargedINR}</td>
                          <td className="p-2.5 text-slate-300">₹{l.sellerPayoutINR}</td>
                          <td className="p-2.5 text-amber-300 font-bold">₹{l.communityPartnerRewardINR}</td>
                          <td className="p-2.5 text-blue-400 font-bold">₹{l.platformCommissionINR}</td>
                          <td className="p-2.5 text-slate-500 truncate max-w-[100px]">{l.auditHash}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 9: AI COMMAND BRAIN & GEOGRAPHIC INTELLIGENCE */}
          {activeTab === 'command_brain' && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-slate-900 border border-teal-800/60 p-6 rounded-3xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-black">
                      <Cpu className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-lg font-black text-white">AI Commerce & Logistics Command Brain</h3>
                      <p className="text-xs text-slate-300">
                        Autonomous demand forecasting, self-balancing supply-demand incentives, and live network health
                      </p>
                    </div>
                  </div>

                  <span className="text-xs bg-teal-950 text-teal-300 border border-teal-800 px-3 py-1 rounded-full font-bold">
                    Autonomous Engine v4.2
                  </span>
                </div>

                {/* AI Executive Summary Box */}
                <div className="bg-white p-4 rounded-2xl border border-slate-800 space-y-3 text-xs">
                  <div className="flex items-center justify-between text-slate-300 font-bold border-b border-slate-800 pb-2">
                    <span className="flex items-center gap-1.5 text-teal-400">
                      <Sparkles className="w-4 h-4" /> AI Platform Daily Summary:
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono">Simulated at 14:00 Today</span>
                  </div>

                  <div className="space-y-1.5 text-slate-300">
                    <p>• <strong>Delivery Demand:</strong> Increased 18.4% today in Indore Vijay Nagar & Khandwa corridors.</p>
                    <p>• <strong>Partner Elasticity:</strong> 84 community partners active in EARN MODE along Highway SH-27.</p>
                    <p>• <strong>Recommended Action:</strong> Activate +25% incentive in Zone B to balance 6:00 PM evening peak transit.</p>
                  </div>

                  <div className="pt-2 flex items-center gap-3">
                    <button
                      onClick={() => {
                        setAiInsightAccepted(true);
                        showToast('✓ AI Recommendation Approved: +25% Zone B Incentive Activated!');
                      }}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                        aiInsightAccepted ? 'bg-emerald-600 text-white' : 'bg-teal-500 hover:bg-teal-400 text-slate-800'
                      }`}
                    >
                      {aiInsightAccepted ? '✓ INCENTIVE APPLIED (+25%)' : 'ACCEPT & APPLY (+25% INCENTIVE)'}
                    </button>
                    <button
                      onClick={() => showToast('AI recommendation dismissed.')}
                      className="px-4 py-2 rounded-xl bg-slate-800 text-slate-400 text-xs font-semibold hover:bg-slate-700"
                    >
                      Dismiss
                    </button>
                  </div>
                </div>
              </div>

              {/* Geographic Hubs & Corridor Health */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-2">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Indore Metro Corridor</span>
                  <div className="text-lg font-black text-emerald-400">98.6% On-Time SLA</div>
                  <p className="text-xs text-slate-400">Avg. Detour: 0.9 km • 42 Live Transits</p>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-2">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Indore ↔ Khandwa Highway</span>
                  <div className="text-lg font-black text-amber-400">3.2 hrs Avg Transit</div>
                  <p className="text-xs text-slate-400">12 Inter-City Carry Opportunities</p>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-2">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Customer Free Delivery Engine</span>
                  <div className="text-lg font-black text-blue-400">100% Subsidized</div>
                  <p className="text-xs text-slate-400">₹0 Delivery Fee Paid by 100% of Buyers</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* BOTTOM FOOTER STATUS */}
        <div className="bg-white px-6 py-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>People-Powered Network Live: Indore, Khandwa, Delhi, Mumbai, Bengaluru & Global</span>
          </div>

          <div className="flex items-center gap-4">
            <span className="text-slate-500">Double-Entry Financial Consensus: <strong className="text-emerald-400">Audited</strong></span>
            <button
              onClick={onClose}
              className="px-4 py-1 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-lg transition cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
