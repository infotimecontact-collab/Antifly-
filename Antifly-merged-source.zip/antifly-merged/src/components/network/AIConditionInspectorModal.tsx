import React, { useState } from 'react';
import { X, Camera, Sparkles, ShieldCheck, CheckCircle2, RefreshCw, AlertTriangle, ArrowRight } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { INITIAL_SECOND_HAND_ASSESSMENTS, SecondHandProductAssessment } from '../../data/networkCommerceData';

interface AIConditionInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AIConditionInspectorModal: React.FC<AIConditionInspectorModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { showToast } = useApp();
  const [assessments, setAssessments] = useState<SecondHandProductAssessment[]>(INITIAL_SECOND_HAND_ASSESSMENTS);
  const [selectedId, setSelectedId] = useState<string>(INITIAL_SECOND_HAND_ASSESSMENTS[0]?.id || '');
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [itemName, setItemName] = useState<string>('');

  if (!isOpen) return null;

  const current = assessments.find((a) => a.id === selectedId) || assessments[0];

  const handleSimulateScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      const newScan: SecondHandProductAssessment = {
        id: `scan-${Date.now()}`,
        productName: itemName || 'Sony DualSense Edge Wireless Controller',
        category: 'Gaming Accessories',
        originalMrp: 18990,
        suggestedSellingPrice: 11200,
        photos: ['https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=600'],
        sellerDeclaredCondition: 'Pristine (Like New)',
        aiVisualAssessment: {
          overallGrade: 'Grade A+ (Pristine)',
          confidenceScorePct: 98.6,
          cosmeticWearObservation: 'Grip rubber pristine. Thumbsticks zero drift detected. Triggers smooth with zero friction.',
          screenAndDisplayStatus: 'N/A',
          functionalIntegrityCheck: 'Haptic feedback and adaptive triggers calibrated at 100% precision index.',
          estimatedDepreciationPct: 41.0,
          detectedAccessories: ['Braided USB-C Cable', 'Carrying Case', 'Replaceable Stick Caps'],
          missingAccessories: [],
          fraudRiskIndicator: 'Verified Safe',
          transparencySummary: 'AI multi-angle photo analysis confirmed pristine grade with verified OEM components.',
        },
        isExchangeEligible: true,
        sellerCity: 'Indore',
        sellerTrustScore: 980,
      };
      setAssessments([newScan, ...assessments]);
      setSelectedId(newScan.id);
      setItemName('');
      showToast('✨ AI Visual Condition Verification Complete! Digital Passport Generated.');
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-slate-900 border border-purple-500/40 rounded-3xl w-full max-w-4xl shadow-2xl text-slate-100 flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-700 px-6 py-4 flex items-center justify-between text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black">AI Condition Inspector & Digital Passport</h3>
              <p className="text-xs text-purple-100">Multi-spectral visual analysis for second-hand transparency</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Scan Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <input
              type="text"
              placeholder="Enter product model to inspect (e.g. Sony DualSense Edge)"
              value={itemName}
              onChange={(e) => setItemName(e.target.value)}
              className="bg-slate-900 border border-slate-700 px-4 py-2 rounded-xl text-xs text-white flex-1 min-w-[240px] focus:outline-hidden"
            />
            <button
              onClick={handleSimulateScan}
              disabled={isScanning}
              className="px-5 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-extrabold text-xs rounded-xl transition cursor-pointer flex items-center gap-2"
            >
              {isScanning ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Camera className="w-4 h-4" />}
              <span>{isScanning ? 'Inspecting...' : 'START AI SCAN'}</span>
            </button>
          </div>

          {/* Inspection View */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-4 space-y-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                Inspected Items ({assessments.length}):
              </span>
              {assessments.map((a) => (
                <div
                  key={a.id}
                  onClick={() => setSelectedId(a.id)}
                  className={`p-3 rounded-2xl border cursor-pointer flex items-center justify-between text-xs transition ${
                    selectedId === a.id
                      ? 'bg-purple-950/50 border-purple-500 text-white'
                      : 'bg-white border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="truncate pr-2">
                    <span className="font-bold block truncate">{a.productName}</span>
                    <span className="text-[10px] text-purple-300">{a.aiVisualAssessment.overallGrade}</span>
                  </div>
                  <span className="text-emerald-400 font-bold">₹{a.suggestedSellingPrice.toLocaleString()}</span>
                </div>
              ))}
            </div>

            <div className="lg:col-span-8 bg-white border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-3">
                <div>
                  <span className="text-[10px] bg-purple-950 text-purple-300 border border-purple-800 px-2 py-0.5 rounded-full font-bold">
                    {current.aiVisualAssessment.overallGrade}
                  </span>
                  <h4 className="text-base font-extrabold text-white mt-1">{current.productName}</h4>
                  <p className="text-xs text-slate-400">
                    Original MRP: ₹{current.originalMrp.toLocaleString()} • Fair Price: <strong className="text-emerald-400">₹{current.suggestedSellingPrice.toLocaleString()}</strong>
                  </p>
                </div>
                <img src={current.photos[0]} alt="" className="w-16 h-16 rounded-xl object-cover border border-slate-800" />
              </div>

              <div className="space-y-2 text-xs">
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Optical Wear Assessment:</span>
                  <p className="text-slate-200">{current.aiVisualAssessment.cosmeticWearObservation}</p>
                </div>

                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Integrity & Functional SLA:</span>
                  <p className="text-slate-200">{current.aiVisualAssessment.functionalIntegrityCheck}</p>
                </div>

                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Detected Accessories:</span>
                  <p className="text-emerald-300">✓ {current.aiVisualAssessment.detectedAccessories.join(', ')}</p>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between">
                <span className="text-xs text-emerald-400 font-bold">🛡️ {current.aiVisualAssessment.fraudRiskIndicator}</span>
                <button
                  onClick={() => {
                    showToast(`Digital Passport linked to listing!`);
                    onClose();
                  }}
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  PUBLISH VERIFIED LISTING
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
