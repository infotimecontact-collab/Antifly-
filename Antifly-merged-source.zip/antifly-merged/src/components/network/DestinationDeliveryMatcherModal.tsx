import React, { useState } from 'react';
import { X, Navigation, MapPin, ArrowRight, CheckCircle2, Clock, ShieldCheck, Sparkles, Truck } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { INITIAL_COMMUNITY_DELIVERIES, CommunityDeliveryOpportunity } from '../../data/networkCommerceData';

interface DestinationDeliveryMatcherModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DestinationDeliveryMatcherModal: React.FC<DestinationDeliveryMatcherModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { showToast } = useApp();

  const [fromCity, setFromCity] = useState<string>('Indore (Vijay Nagar)');
  const [toCity, setToCity] = useState<string>('Khandwa (Anand Nagar)');
  const [departureTime, setDepartureTime] = useState<string>('Today 5:30 PM');
  const [maxDetourKm, setMaxDetourKm] = useState<number>(2.5);

  const [opportunities, setOpportunities] = useState<CommunityDeliveryOpportunity[]>(INITIAL_COMMUNITY_DELIVERIES);

  if (!isOpen) return null;

  const handleClaimOpportunity = (opp: CommunityDeliveryOpportunity) => {
    setOpportunities((prev) =>
      prev.map((o) => (o.id === opp.id ? { ...o, status: 'in_transit' } : o))
    );
    showToast(`🚗 Opportunity Claimed! You will carry parcel "${opp.productName}" on your way to ${toCity}. Total Earning: ₹${opp.rewardAmountINR + opp.surgeBonusINR}`);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl w-full max-w-2xl shadow-2xl text-slate-100 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-700 px-6 py-4 flex items-center justify-between text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center">
              <Navigation className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black">Destination Route Matching</h3>
              <p className="text-xs text-emerald-100">Carry & Earn along your scheduled journey</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Origin & Destination Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-800 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] font-bold text-emerald-400 uppercase block mb-1">
                  Starting Point (Origin):
                </label>
                <input
                  type="text"
                  value={fromCity}
                  onChange={(e) => setFromCity(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-emerald-400 uppercase block mb-1">
                  Destination:
                </label>
                <input
                  type="text"
                  value={toCity}
                  onChange={(e) => setToCity(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                  Departure Time:
                </label>
                <input
                  type="text"
                  value={departureTime}
                  onChange={(e) => setDepartureTime(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                  Maximum Detour Tolerance:
                </label>
                <select
                  value={maxDetourKm}
                  onChange={(e) => setMaxDetourKm(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                >
                  <option value={1.5}>Up to 1.5 km Detour</option>
                  <option value={2.5}>Up to 2.5 km Detour</option>
                  <option value={5.0}>Up to 5.0 km Detour</option>
                </select>
              </div>
            </div>
          </div>

          {/* Matched Detour Packages */}
          <div className="space-y-3">
            <span className="text-xs font-black text-slate-400 uppercase tracking-wider block">
              Compatible Parcels on {fromCity} ➔ {toCity} Corridor:
            </span>

            {opportunities.map((opp) => (
              <div
                key={opp.id}
                className="bg-white border border-emerald-500/30 hover:border-emerald-400 p-4 rounded-2xl space-y-3 transition"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={opp.productImage}
                      alt={opp.productName}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-700"
                    />
                    <div>
                      <span className="text-[10px] text-emerald-400 font-mono font-bold">
                        {opp.orderNumber}
                      </span>
                      <h4 className="text-xs font-bold text-white">{opp.productName}</h4>
                      <p className="text-[11px] text-slate-400">
                        {opp.pickup.city} → {opp.destination.city} (Detour: {opp.detourKm} km)
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-base font-black text-emerald-400">
                      ₹{opp.rewardAmountINR + opp.surgeBonusINR}
                    </span>
                    <span className="text-[10px] text-slate-400 block">Detour Earning</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                  <span className="text-slate-400">
                    {opp.parcel.size} ({opp.parcel.weightKg}kg) • {opp.estimatedDurationMins} mins
                  </span>

                  <button
                    onClick={() => handleClaimOpportunity(opp)}
                    disabled={opp.status === 'in_transit'}
                    className={`px-4 py-1.5 rounded-xl font-bold text-xs transition cursor-pointer ${
                      opp.status === 'in_transit'
                        ? 'bg-slate-800 text-slate-500'
                        : 'bg-emerald-500 hover:bg-emerald-400 text-slate-800 shadow-md'
                    }`}
                  >
                    {opp.status === 'in_transit' ? 'Claimed' : `CARRY & EARN (₹${opp.rewardAmountINR + opp.surgeBonusINR})`}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
