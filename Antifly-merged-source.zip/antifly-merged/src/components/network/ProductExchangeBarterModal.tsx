import React, { useState } from 'react';
import { X, Repeat, Sparkles, Plus, ArrowRight, ShieldCheck, CheckCircle2, DollarSign } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { INITIAL_EXCHANGE_OFFERS, ProductExchangeOffer } from '../../data/networkCommerceData';

interface ProductExchangeBarterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProductExchangeBarterModal: React.FC<ProductExchangeBarterModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { showToast } = useApp();
  const [offers, setOffers] = useState<ProductExchangeOffer[]>(INITIAL_EXCHANGE_OFFERS);
  const [itemToOffer, setItemToOffer] = useState<string>('');
  const [lookingFor, setLookingFor] = useState<string>('');
  const [cashDifference, setCashDifference] = useState<number>(0);
  const [tradeType, setTradeType] = useState<'Direct Item Swap' | 'Item + Cash Difference' | 'Free Community Giveaway'>('Direct Item Swap');

  if (!isOpen) return null;

  const handlePostTrade = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemToOffer.trim()) {
      showToast('Please enter an item title to offer.');
      return;
    }

    const newOffer: ProductExchangeOffer = {
      id: `trade-${Date.now()}`,
      title: `${itemToOffer} ↔ Looking for ${lookingFor || 'Anything Useful'}`,
      offeredItem: {
        title: itemToOffer,
        category: 'Gadgets & Lifestyle',
        condition: 'Pristine (Like New)',
        estimatedValueINR: 18500,
        image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500',
        location: 'Indore',
      },
      targetCategoryOrItems: [lookingFor || 'Similar Value Items'],
      cashAdjustmentINR: Number(cashDifference) || 0,
      tradeType: tradeType,
      ownerId: 'usr-you',
      ownerName: 'You (Verified Citizen)',
      ownerCity: 'Indore',
      ownerAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      communityTrustScore: 920,
      aiTradeFairnessScorePct: 97,
      status: 'open',
      datePosted: 'Just now',
    };

    setOffers([newOffer, ...offers]);
    setItemToOffer('');
    setLookingFor('');
    setCashDifference(0);
    showToast('✨ Exchange Proposal Published! AI Trade Fair-Value Assessment: 97% match.');
  };

  const handleProposeTrade = (offer: ProductExchangeOffer) => {
    showToast(`🔄 Swap proposal sent to ${offer.ownerName} for "${offer.offeredItem.title}"!`);
  };

  return (
    <div className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-slate-900 border border-cyan-500/40 rounded-3xl w-full max-w-4xl shadow-2xl text-slate-100 flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-cyan-600 to-blue-700 px-6 py-4 flex items-center justify-between text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center">
              <Repeat className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black">Product Exchange & Peer Barter Network</h3>
              <p className="text-xs text-cyan-100">Swap goods, trade with cash differences, or give away</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Post New Exchange Proposal */}
          <form onSubmit={handlePostTrade} className="bg-white p-5 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" /> Propose New Product Trade:
              </span>
              <span className="text-[10px] text-slate-400">AI Fair-Value Guaranteed</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="space-y-1">
                <label className="text-slate-400 font-bold block">What are you offering?</label>
                <input
                  type="text"
                  placeholder="e.g. Sony WH-1000XM4 Headphones"
                  value={itemToOffer}
                  onChange={(e) => setItemToOffer(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-400 font-bold block">What do you want in exchange?</label>
                <input
                  type="text"
                  placeholder="e.g. Mechanical Keyboard or iPad"
                  value={lookingFor}
                  onChange={(e) => setLookingFor(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-400 font-bold block">Trade Structure:</label>
                <select
                  value={tradeType}
                  onChange={(e) => setTradeType(e.target.value as any)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden"
                >
                  <option value="Direct Item Swap">Direct Item Swap (1:1)</option>
                  <option value="Item + Cash Difference">Item + Cash Difference</option>
                  <option value="Free Community Giveaway">Free Community Giveaway</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-extrabold text-xs rounded-xl transition cursor-pointer shadow-md"
            >
              POST EXCHANGE PROPOSAL TO COMMUNITY
            </button>
          </form>

          {/* Active Offers Grid */}
          <div className="space-y-3">
            <span className="text-xs font-black text-slate-400 uppercase tracking-wider block">
              Active Community Exchange Offers ({offers.length}):
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {offers.map((offer) => (
                <div
                  key={offer.id}
                  className="bg-white border border-slate-800 hover:border-cyan-500/50 p-4 rounded-2xl space-y-3 transition flex flex-col justify-between"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="bg-cyan-950 text-cyan-300 border border-cyan-800 px-2 py-0.5 rounded-full font-bold text-[10px]">
                        {offer.tradeType}
                      </span>
                      <span className="text-slate-500">{offer.datePosted}</span>
                    </div>

                    <div className="flex items-center gap-3 pt-1">
                      <img
                        src={offer.offeredItem.image}
                        alt=""
                        className="w-12 h-12 rounded-xl object-cover border border-slate-800"
                      />
                      <div>
                        <h4 className="text-xs font-bold text-white line-clamp-1">{offer.offeredItem.title}</h4>
                        <p className="text-[11px] text-emerald-400 font-semibold">
                          Valued at ₹{offer.offeredItem.estimatedValueINR.toLocaleString()}
                        </p>
                      </div>
                    </div>

                    <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 text-[11px] space-y-0.5">
                      <span className="text-[10px] text-cyan-400 font-bold uppercase block">Looking for:</span>
                      <p className="text-slate-300">{offer.targetCategoryOrItems.join(', ')}</p>
                      {offer.cashAdjustmentINR !== 0 && (
                        <p className="text-emerald-400 font-bold text-[10px]">
                          + Offering Extra ₹{offer.cashAdjustmentINR.toLocaleString()} Cash
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                    <span className="text-[11px] text-slate-400">{offer.ownerName} ({offer.ownerCity})</span>
                    <button
                      onClick={() => handleProposeTrade(offer)}
                      className="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-lg text-xs transition cursor-pointer"
                    >
                      PROPOSE
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
