import React, { useState } from 'react';
import { X, Clock, Zap, DollarSign, CheckCircle2, ArrowRight } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { INITIAL_TIME_TO_EARN_OPTIONS, TimeToEarnOption } from '../../data/networkCommerceData';

interface TimeToEarnModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TimeToEarnModal: React.FC<TimeToEarnModalProps> = ({ isOpen, onClose }) => {
  const { showToast } = useApp();
  const [selectedMinutes, setSelectedMinutes] = useState<number>(30);
  const [tasks, setTasks] = useState<TimeToEarnOption[]>(INITIAL_TIME_TO_EARN_OPTIONS);

  if (!isOpen) return null;

  const handleClaim = (task: TimeToEarnOption) => {
    showToast(`🎯 Micro-Task Claimed: "${task.title}". Instant payout of ₹${task.estimatedEarningsINR} queued!`);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-slate-900 border border-blue-500/40 rounded-3xl w-full max-w-2xl shadow-2xl text-slate-100 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-700 px-6 py-4 flex items-center justify-between text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black">Time-To-Earn: Time as an Asset</h3>
              <p className="text-xs text-blue-100">Monetize your spare 15m, 30m, 60m, or 120m blocks</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          {/* Time Selector Buttons */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
              How much free time do you have right now?
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[15, 30, 60, 120].map((mins) => (
                <button
                  key={mins}
                  onClick={() => setSelectedMinutes(mins)}
                  className={`py-2.5 rounded-xl text-xs font-black transition cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
                    selectedMinutes === mins
                      ? 'bg-blue-500 text-white shadow-lg ring-2 ring-blue-400'
                      : 'bg-white border border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-sm">{mins}m</span>
                  <span className="text-[9px] uppercase tracking-wider">Free</span>
                </button>
              ))}
            </div>
          </div>

          {/* Task cards */}
          <div className="space-y-3">
            <span className="text-xs font-black text-slate-400 uppercase tracking-wider block">
              Matched Tasks Fitting Inside Your {selectedMinutes}m Window:
            </span>

            {tasks
              .filter((t) => t.timeWindowMinutes <= selectedMinutes)
              .map((t) => (
                <div
                  key={t.id}
                  className="bg-white border border-slate-800 hover:border-blue-500/50 p-4 rounded-2xl space-y-3 transition"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] bg-blue-950 text-blue-300 border border-blue-800 px-2 py-0.5 rounded-full font-bold">
                          ⏱️ {t.timeWindowMinutes} Mins
                        </span>
                        <span className="text-[10px] text-amber-400 font-bold">{t.urgencyLevel}</span>
                      </div>
                      <h4 className="text-xs font-bold text-white mt-1">{t.title}</h4>
                      <p className="text-[11px] text-slate-400 mt-0.5">{t.routeSummary} ({t.distanceKm} km)</p>
                    </div>

                    <div className="text-right">
                      <span className="text-base font-black text-emerald-400">₹{t.estimatedEarningsINR}</span>
                      <span className="text-[10px] text-slate-500 block">Instant Payout</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                    <span className="text-slate-400 text-[11px]">{t.parcelSize}</span>
                    <button
                      onClick={() => handleClaim(t)}
                      className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition cursor-pointer shadow-md"
                    >
                      START & EARN (₹{t.estimatedEarningsINR})
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};
