import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Star,
  Heart,
  ShoppingBag,
  Zap,
  Truck,
  ShieldCheck,
  RotateCcw,
  Sparkles,
  MapPin,
  Check,
  Send,
  Scale,
  Ruler,
  Clock,
  Coins,
  Store,
  Share2,
  Bell,
  Layers,
  Upload,
  Camera,
  ThumbsUp,
  Image as ImageIcon,
  CheckCircle2,
  Plus,
  Trash2,
  Maximize2,
  MessageSquare,
  BadgePercent,
  UserCheck,
  Video,
  Flame,
  Glasses,
  Radio,
  AudioLines,
} from 'lucide-react';
import { Product, ProductReview } from '../../types';
import { getProductReviews } from '../../data/defaultReviewsData';
import { Analytics } from '../../utils/analytics';

export const ProductDetailModal: React.FC = () => {
  const {
    activePdpId,
    setActivePdpId,
    products,
    sellers,
    addToCart,
    wishlist,
    toggleWishlist,
    addToComparison,
    setIsCheckoutOpen,
    setIsSizeAssistantOpen,
    sizeProfile,
    resellerConfig,
    setIsResellerModalOpen,
    superCoinsBalance,
    lookBundles,
    addBundleToCart,
    priceDropWatchlist,
    togglePriceDropAlert,
    formatPrice,
    addProductReview,
    voteReviewHelpful,
    currentCustomer,
    openStoreCommunity,
    openStoreChat,
    toggleFollowSeller,
    sendStoreChatMessage,
    showToast,
    openVirtualTryOn,
    openFreeTrialUpload,
    addCustomUploadedProduct,
    setIsLiveShoppingOpen,
  } = useApp();

  const product = products.find((p) => p.id === activePdpId);
  const seller = sellers.find((s) => s.id === product?.sellerId);
  const isFollowingSeller = seller && currentCustomer.followingSellerIds?.includes(seller.id);

  // States
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [pincode, setPincode] = useState('');
  const [pincodeStatus, setPincodeStatus] = useState<string | null>(null);
  const [pincodeChecking, setPincodeChecking] = useState(false);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'specs' | 'care' | 'reviews' | 'shipping'>('specs');
  const [wholesaleQty, setWholesaleQty] = useState<number>(1);
  const [isBargainFormOpen, setIsBargainFormOpen] = useState(false);
  const [bargainPriceInput, setBargainPriceInput] = useState('');
  const [bargainQtyInput, setBargainQtyInput] = useState(1);
  const [bargainNoteInput, setBargainNoteInput] = useState('');

  // Customer Reviews & Photo Upload States
  const [isWriteReviewOpen, setIsWriteReviewOpen] = useState(false);
  const [newRating, setNewRating] = useState(5);
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewComment, setReviewComment] = useState('');
  const [reviewPros, setReviewPros] = useState('');
  const [reviewCons, setReviewCons] = useState('');
  const [reviewPhotos, setReviewPhotos] = useState<string[]>([]);
  const [activePhotoLightbox, setActivePhotoLightbox] = useState<string | null>(null);
  const [reviewFilter, setReviewFilter] = useState<'all' | 'photos' | '5star' | 'verified'>('all');
  const reviewFileInputRef = useRef<HTMLInputElement>(null);

  // WiseAI PDP Q&A state
  const [aiQuestion, setAiQuestion] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiAnswer, setAiAnswer] = useState<{
    answer: string;
    stylingTips?: string[];
    sizeRecommendation?: string;
  } | null>(null);

  // Initialize selected options when product opens & track GA4
  useEffect(() => {
    if (product) {
      setSelectedImage(product.images?.[0] || product.image || '');
      setSelectedColor(product.colors?.[0]?.name || '');
      setSelectedSize(product.sizes?.[0] || '');
      setWholesaleQty(product.isWholesale ? (product.minOrderQuantity || 1) : 1);
      setAiAnswer(null);
      setPincodeStatus(null);
      setIsWriteReviewOpen(false);

      // Track Google Analytics 4 View Item Event
      Analytics.viewItem({
        id: product.id,
        name: product.name,
        brand: product.brand,
        category: product.category,
        price: product.price,
      });
    }
  }, [product]);

  if (!product) return null;

  const isWishlisted = wishlist.includes(product.id);
  const isWatchingPrice = priceDropWatchlist.includes(product.id);

  // Find variant matching color and size
  const currentVariant =
    product.variants?.find((v) => v.color === selectedColor && v.size === selectedSize) ||
    product.variants?.[0];

  const handleAddToCart = () => {
    const finalQuantity = product.isWholesale ? Math.max(wholesaleQty, product.minOrderQuantity || 1) : 1;
    addToCart({
      productId: product.id,
      variantId: currentVariant?.id || product.variants?.[0]?.id || 'default',
      productName: product.name,
      brand: product.brand,
      color: selectedColor || product.colors?.[0]?.name || 'Standard',
      size: selectedSize || product.sizes?.[0] || 'Standard',
      price: product.price,
      mrp: product.mrp,
      image: product.images?.[0] || product.image || '',
      quantity: finalQuantity,
      stock: currentVariant?.stock || product.totalStock,
      isWholesale: product.isWholesale,
      minOrderQuantity: product.minOrderQuantity,
      wholesalePricePerUnit: product.wholesalePricePerUnit,
      wholesaleLotSize: product.wholesaleLotSize,
      wholesaleLotPrice: product.wholesaleLotPrice,
      isDealershipProduct: product.isDealershipProduct,
      isSingleSellerVendor: product.isSingleSellerVendor,
    });
  };

  const handleBuyNow = () => {
    handleAddToCart();
    setActivePdpId(null);
    setIsCheckoutOpen(true);
  };

  const handleCheckPincode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pincode || pincode.length < 6) return;
    setPincodeChecking(true);
    setTimeout(() => {
      setPincodeChecking(false);
      if (['400001', '110001', '560001', '500001', '600001', '700001'].includes(pincode)) {
        setPincodeStatus('⚡ Priority Express: Guaranteed Next-Day Delivery available. COD Supported.');
      } else {
        setPincodeStatus('📦 Standard Delivery: Expected within 2-3 business days. COD Supported.');
      }
    }, 400);
  };

  const handleAskWiseAI = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiQuestion.trim() || aiLoading) return;
    setAiLoading(true);
    try {
      const res = await fetch('/api/wiseai/pdp-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId: product.id, question: aiQuestion }),
      });
      const data = await res.json();
      setAiAnswer(data);
    } catch (err) {
      console.error(err);
    } finally {
      setAiLoading(false);
    }
  };

  const coinsToEarn = Math.round((product.price / 100) * 4);
  const resellerMargin = Math.round(product.price * (resellerConfig.resellerMarginPercentage / 100));
  const resellerCustomerPrice = product.price + resellerMargin;
  const matchingBundle = lookBundles.find((b) => b.mainProductId === product.id);

  return (
    <div
      id="pdp-modal-overlay"
      className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 lg:p-6 animate-fade-in overflow-y-auto"
    >
      <div className="bg-white dark:bg-slate-900 w-full max-w-5xl rounded-3xl shadow-2xl border border-stone-200 dark:border-slate-800 overflow-hidden flex flex-col my-auto max-h-[95vh]">
        {/* Top Close Header */}
        <div className="px-5 py-3 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3 text-xs text-slate-300">
            <span className="font-semibold text-amber-400 uppercase tracking-wider">
              {product.brand}
            </span>
            <span className="text-slate-600">•</span>
            {/* SuperCoin badge */}
            <span className="flex items-center gap-1 text-amber-300 font-bold bg-amber-400/20 px-2 py-0.5 rounded-full">
              <Coins className="w-3 h-3 text-amber-400 fill-amber-400" /> Earn {coinsToEarn} SuperCoins
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => togglePriceDropAlert(product.id)}
              className={`flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-xl transition ${
                isWatchingPrice
                  ? 'bg-amber-400 text-slate-800 shadow-sm'
                  : 'bg-white/10 text-white hover:bg-white/20'
              }`}
              title="Track Price Drop"
            >
              <Bell className="w-3.5 h-3.5" />
              <span>{isWatchingPrice ? 'Tracking Drop' : 'Price Alert'}</span>
            </button>

            <button
              onClick={() => setActivePdpId(null)}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-10">
            {/* Image Gallery */}
            <div>
              <div className="relative rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 h-[320px] sm:h-[400px] group">
                <img
                  src={selectedImage || product.images?.[0] || product.image || ''}
                  alt={product.name}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                />

                {/* 3D AR Virtual Try-On Floating Launch Button */}
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between gap-2">
                  <button
                    onClick={() => openVirtualTryOn(product.id)}
                    className="bg-white/85 hover:bg-white backdrop-blur-md text-emerald-400 border border-emerald-500/50 hover:border-emerald-400 font-extrabold px-3 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow-xl transition-all hover:scale-105 cursor-pointer"
                  >
                    <Glasses className="w-4 h-4 text-emerald-400 animate-pulse" />
                    <span>👓 3D / AR Virtual Try-On</span>
                  </button>

                  <button
                    onClick={() => setIsLiveShoppingOpen(true)}
                    className="bg-red-600/90 hover:bg-red-600 backdrop-blur-md text-white font-extrabold px-3 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow-xl transition-all hover:scale-105 cursor-pointer"
                    title="Watch Live Show"
                  >
                    <Radio className="w-3.5 h-3.5" />
                    <span>LIVE Stream</span>
                  </button>
                </div>
              </div>

              {/* Thumbnail strip */}
              <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
                {(product.images || []).map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImage(img)}
                    className={`w-16 h-16 rounded-xl overflow-hidden border-2 flex-shrink-0 transition-all ${
                      selectedImage === img
                        ? 'border-amber-500 ring-2 ring-amber-500/30'
                        : 'border-transparent opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="thumb" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            {/* Product Meta & Selectors */}
            <div>
              {/* Brand & Ratings */}
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-amber-400">
                  {product.brand}
                </span>
                <div className="flex items-center gap-1.5 bg-amber-50 dark:bg-amber-950/60 px-2 py-1 rounded-md text-xs font-bold text-amber-700 dark:text-amber-300 border border-amber-200/50 dark:border-amber-900/40">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span>{product.rating}</span>
                  <span className="text-slate-400 font-normal">({product.reviewCount} Verified Reviews)</span>
                </div>
              </div>

              {/* Title & Short Description */}
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white mt-1.5 leading-snug">
                {product.name}
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-2 leading-relaxed">
                {product.shortDescription}
              </p>

              {/* Price & Tax notice */}
              <div className="mt-4 p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-800">
                <div className="flex items-baseline justify-between">
                  <div className="flex items-baseline gap-2.5">
                    <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
                      ₹{product.price.toLocaleString('en-IN')}
                    </span>
                    {product.mrp > product.price && (
                      <span className="text-sm text-slate-400 line-through">
                        ₹{product.mrp.toLocaleString('en-IN')}
                      </span>
                    )}
                    <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                      Save ₹{(product.mrp - product.price).toLocaleString('en-IN')}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500 font-medium">Inclusive of all taxes</span>
                </div>

                {/* Wholesale & Dealership Breakdown */}
                {product.isWholesale && (
                  <div className="mt-2.5 pt-2.5 border-t border-slate-200/80 dark:border-slate-700/80 flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-1.5 text-blue-700 dark:text-blue-300 font-bold">
                      <span className="bg-blue-100 dark:bg-blue-900/60 px-2 py-0.5 rounded text-[11px]">
                        Wholesale Unit Rate: ₹{product.wholesalePricePerUnit || Math.round(product.price / (product.minOrderQuantity || 1))} / pc
                      </span>
                      <span>• MOQ: {product.minOrderQuantity || 12} Units</span>
                    </div>
                    <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                      Margin: ~{Math.round(((product.mrp - product.price) / product.mrp) * 100)}% ROI
                    </span>
                  </div>
                )}
              </div>

              {/* Dealership & Single Seller Vendor Notice */}
              {(product.isDealershipProduct || product.isSingleSellerVendor) && (
                <div className="mt-3 p-3 bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-amber-500/10 border border-amber-500/30 rounded-2xl flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-600 dark:text-amber-400 flex-shrink-0">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div className="flex-1 text-xs">
                    <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span>Authorized Dealership & Single-Seller Vendor</span>
                      <span className="bg-amber-400/30 text-amber-900 dark:text-amber-200 text-[10px] px-1.5 py-0.2 rounded font-black">
                        DIRECT WHOLESALER
                      </span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300 text-[11px] mt-0.5">
                      100% Genuine wholesale supply directly from authorized manufacturer hub. Dealer warranty included.
                    </p>
                  </div>
                </div>
              )}

              {/* Wholesale MOQ & Lot Quantity Selector */}
              {product.isWholesale && (
                <div className="mt-4 p-3.5 bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 rounded-2xl">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-blue-900 dark:text-blue-200">
                      <Layers className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                      <span>Wholesale Quantity (Min. Order: {product.minOrderQuantity || 12} units)</span>
                    </div>
                    <span className="text-[11px] font-bold text-blue-700 dark:text-blue-300">
                      Total: ₹{(product.wholesalePricePerUnit ? product.wholesalePricePerUnit * wholesaleQty : product.price * (wholesaleQty / (product.minOrderQuantity || 1))).toLocaleString('en-IN')}
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="flex items-center bg-white dark:bg-slate-800 border border-blue-300 dark:border-blue-700 rounded-xl overflow-hidden shadow-xs">
                      <button
                        type="button"
                        onClick={() => setWholesaleQty(Math.max((product.minOrderQuantity || 1), wholesaleQty - (product.minOrderQuantity || 1)))}
                        className="px-3 py-2 text-slate-700 dark:text-slate-200 hover:bg-blue-100 dark:hover:bg-blue-900/50 font-black text-sm"
                        title={`Decrease by ${product.minOrderQuantity || 1}`}
                      >
                        -
                      </button>
                      <input
                        type="number"
                        min={product.minOrderQuantity || 1}
                        value={wholesaleQty}
                        onChange={(e) => {
                          const val = parseInt(e.target.value, 10);
                          if (!isNaN(val)) setWholesaleQty(Math.max(1, val));
                        }}
                        className="w-16 text-center font-bold text-xs bg-transparent py-1.5 focus:outline-none text-slate-900 dark:text-white"
                      />
                      <button
                        type="button"
                        onClick={() => setWholesaleQty(wholesaleQty + (product.minOrderQuantity || 1))}
                        className="px-3 py-2 text-slate-700 dark:text-slate-200 hover:bg-blue-100 dark:hover:bg-blue-900/50 font-black text-sm"
                        title={`Increase by ${product.minOrderQuantity || 1}`}
                      >
                        +
                      </button>
                    </div>

                    <div className="flex gap-1.5 flex-wrap flex-1">
                      {[1, 2, 4].map((multiplier) => {
                        const count = (product.minOrderQuantity || 12) * multiplier;
                        return (
                          <button
                            key={multiplier}
                            type="button"
                            onClick={() => setWholesaleQty(count)}
                            className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition ${
                              wholesaleQty === count
                                ? 'bg-blue-700 text-white shadow-xs'
                                : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-blue-400'
                            }`}
                          >
                            {count} Pcs ({multiplier}x Lot)
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {wholesaleQty < (product.minOrderQuantity || 1) && (
                    <p className="text-[11px] text-rose-600 dark:text-rose-400 font-bold mt-1.5">
                      ⚠️ Note: Minimum wholesale order required is {product.minOrderQuantity || 12} units.
                    </p>
                  )}
                </div>
              )}

              {/* Color Swatches */}
              <div className="mt-4">
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Select Shade: <span className="font-bold text-slate-900 dark:text-white">{selectedColor}</span>
                  </label>
                </div>
                <div className="flex items-center gap-2">
                  {product.colors.map((c, i) => (
                    <button
                      key={i}
                      onClick={() => setSelectedColor(c.name)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all ${
                        selectedColor === c.name
                          ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 ring-1 ring-amber-500'
                          : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-slate-300 shadow-xs"
                        style={{ backgroundColor: c.hex }}
                      />
                      <span>{c.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Size Selector with WiseFit™ AI Button */}
              <div className="mt-4">
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Select Size:
                  </label>
                  <div className="flex items-center gap-2">
                    {/* WiseFit Predictor */}
                    <button
                      onClick={() => setIsSizeAssistantOpen(true)}
                      className="text-xs text-pink-600 dark:text-pink-400 font-bold flex items-center gap-1 hover:underline bg-pink-50 dark:bg-pink-950/40 px-2 py-0.5 rounded-md"
                    >
                      <Sparkles className="w-3 h-3 text-pink-500" />
                      Find My Fit (WiseFit™ AI)
                    </button>

                    <button
                      onClick={() => setIsSizeGuideOpen(!isSizeGuideOpen)}
                      className="text-xs text-orange-600 dark:text-amber-400 font-semibold flex items-center gap-1 hover:underline"
                    >
                      <Ruler className="w-3.5 h-3.5" />
                      Size Chart
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {product.sizes.map((s, i) => {
                    const isAiMatch = sizeProfile.recommendedSize === s;
                    return (
                      <button
                        key={i}
                        onClick={() => setSelectedSize(s)}
                        className={`relative w-11 h-10 rounded-xl font-bold text-xs flex items-center justify-center border transition-all ${
                          selectedSize === s
                            ? 'bg-white text-white dark:bg-amber-500 dark:text-slate-800 border-slate-200 dark:border-amber-500 shadow-md'
                            : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-400'
                        }`}
                      >
                        {s}
                        {isAiMatch && (
                          <span
                            className="absolute -top-1.5 -right-1.5 w-3 h-3 bg-pink-500 rounded-full ring-2 ring-white"
                            title="Your AI Recommended Size"
                          />
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Popover Size Guide */}
                {isSizeGuideOpen && (
                  <div className="mt-2.5 p-3 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs border border-slate-300 dark:border-slate-700">
                    <p className="font-bold text-slate-800 dark:text-slate-200 mb-1.5">
                      Standard Indian Size Chart (Chest / Inches):
                    </p>
                    <div className="grid grid-cols-5 text-center font-mono text-[11px] gap-1 bg-white dark:bg-slate-900 p-2 rounded-lg">
                      <div><strong>S</strong>: 38"</div>
                      <div><strong>M</strong>: 40"</div>
                      <div><strong>L</strong>: 42"</div>
                      <div><strong>XL</strong>: 44"</div>
                      <div><strong>XXL</strong>: 46"</div>
                    </div>
                  </div>
                )}
              </div>

              {/* WiseReseller 1-Click Margin Feature */}
              <div className="mt-4 p-3 bg-pink-50 dark:bg-pink-950/30 rounded-2xl border border-pink-200 dark:border-pink-900/50 flex items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wider text-pink-700 dark:text-pink-300">
                    <Store className="w-3.5 h-3.5 text-pink-600" />
                    WiseReseller Boutique Mode
                  </div>
                  <p className="text-xs text-stone-700 dark:text-slate-300 mt-0.5">
                    Resell for <strong>₹{resellerCustomerPrice}</strong> • Your Margin: <span className="font-bold text-emerald-600">+₹{resellerMargin}</span>
                  </p>
                </div>

                <button
                  onClick={() => setIsResellerModalOpen(true)}
                  className="px-3 py-1.5 bg-pink-600 hover:bg-pink-500 text-white font-bold text-xs rounded-xl shadow-sm transition flex items-center gap-1 whitespace-nowrap"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  Share & Earn
                </button>
              </div>

              {/* Delivery Pincode Checker */}
              <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800">
                <form onSubmit={handleCheckPincode} className="flex gap-2">
                  <div className="relative flex-1">
                    <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      maxLength={6}
                      value={pincode}
                      onChange={(e) => setPincode(e.target.value.replace(/\D/g, ''))}
                      placeholder="Enter 6-digit Pincode (e.g. 400001)"
                      className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={pincode.length < 6 || pincodeChecking}
                    className="bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white px-4 py-2 rounded-xl text-xs font-semibold disabled:opacity-50"
                  >
                    {pincodeChecking ? 'Checking...' : 'Check Delivery'}
                  </button>
                </form>
                {pincodeStatus && (
                  <p className="text-xs font-medium text-emerald-600 dark:text-emerald-400 mt-2 flex items-center gap-1.5">
                    <Check className="w-3.5 h-3.5" />
                    {pincodeStatus}
                  </p>
                )}
              </div>

              {/* Free Trial & 3D Virtual Try-On Feature Card */}
              <div className="mt-4 p-3.5 bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-rose-500/10 rounded-2xl border border-amber-500/30 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 text-slate-800 flex items-center justify-center font-black shadow-md flex-shrink-0">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black text-slate-900 dark:text-white">
                        ₹0 Free 3-Day Home Doorstep Trial
                      </span>
                      <span className="bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 text-[9px] font-black px-2 py-0.5 rounded-full border border-emerald-500/30">
                        100% FREE
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-0.5">
                      Try on your person virtually or upload your own shirt photo to fit!
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    onClick={() => openVirtualTryOn(product.id)}
                    className="flex-1 sm:flex-none px-3.5 py-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:brightness-110 text-slate-800 font-black text-xs rounded-xl shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Try On Person</span>
                  </button>
                  <button
                    onClick={() => openFreeTrialUpload(product.image)}
                    className="flex-1 sm:flex-none px-3.5 py-2 bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white font-bold text-xs rounded-xl border border-slate-700 transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5 text-amber-400" />
                    <span>Upload &amp; Fit</span>
                  </button>
                </div>
              </div>

              {/* Action Buttons: Add to Cart & Buy Now */}
              <div className="mt-6 flex flex-col sm:flex-row gap-2.5">
                <button
                  id="pdp-add-to-cart-btn"
                  onClick={handleAddToCart}
                  className="flex-1 bg-white hover:bg-orange-600 text-white font-bold py-3.5 px-5 rounded-xl text-sm transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-orange-600/20"
                >
                  <ShoppingBag className="w-4 h-4" />
                  {product.isWholesale ? `Add Wholesale Lot (${wholesaleQty} Pcs)` : 'Add to Bag'}
                </button>

                <button
                  id="pdp-buy-now-btn"
                  onClick={handleBuyNow}
                  className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 font-bold py-3.5 px-5 rounded-xl text-sm transition-all flex items-center justify-center gap-2 shadow-lg"
                >
                  <Zap className="w-4 h-4 text-slate-800 fill-slate-950" />
                  {product.isWholesale ? `Order Lot (${wholesaleQty} Pcs)` : 'Buy Now • Instant Checkout'}
                </button>

                {/* Wishlist & Compare toggles */}
                <button
                  onClick={() => toggleWishlist(product.id)}
                  className={`p-3.5 rounded-xl border transition-all ${
                    isWishlisted
                      ? 'bg-rose-50 dark:bg-rose-950 border-rose-300 text-rose-600'
                      : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:text-rose-500'
                  }`}
                  title="Wishlist"
                >
                  <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-rose-500' : ''}`} />
                </button>

                <button
                  onClick={() => addToComparison(product)}
                  className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:text-amber-500"
                  title="Compare"
                >
                  <Scale className="w-5 h-5" />
                </button>
              </div>

              {/* Verified Store Merchant & Community Interaction Hub */}
              <div className="mt-4 p-4 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 border border-amber-500/30 text-white space-y-3 shadow-md">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 flex items-center justify-center font-bold">
                      <Store className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-xs sm:text-sm font-black text-white">
                          {seller?.storeName || product.storeName || product.brand}
                        </h3>
                        <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[9px] font-black px-1.5 py-0.5 rounded-full">
                          Verified Store
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400">
                        📍 {product.storeCity || seller?.city || 'Indore'} &bull; {seller?.followersCount || 128} Followers &bull; 4.9★ Merchant
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => seller && toggleFollowSeller(seller.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                      isFollowingSeller
                        ? 'bg-amber-400 text-slate-800 shadow-sm'
                        : 'bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/40'
                    }`}
                  >
                    <UserCheck className="w-3.5 h-3.5" />
                    <span>{isFollowingSeller ? 'Following Store' : 'Follow Store'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800">
                  <button
                    onClick={() => {
                      if (seller) {
                        openStoreChat(seller.id);
                      } else {
                        showToast('Connecting you to Store Chat...');
                      }
                    }}
                    className="py-2 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center justify-center gap-1.5 transition border border-slate-700"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-sky-400" />
                    <span className="truncate">Chat with Store</span>
                  </button>

                  <button
                    onClick={() => {
                      if (seller) {
                        openStoreCommunity(seller.id);
                      } else {
                        showToast('Opening Store Community...');
                      }
                    }}
                    className="py-2 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center justify-center gap-1.5 transition border border-slate-700"
                  >
                    <Video className="w-3.5 h-3.5 text-pink-400" />
                    <span className="truncate">Reels & Deals</span>
                  </button>

                  <button
                    onClick={() => setIsBargainFormOpen(!isBargainFormOpen)}
                    className="py-2 px-2 rounded-xl bg-gradient-to-r from-amber-500/20 to-orange-500/20 hover:from-amber-500/30 hover:to-orange-500/30 text-amber-300 text-xs font-black flex items-center justify-center gap-1.5 transition border border-amber-500/40"
                  >
                    <BadgePercent className="w-3.5 h-3.5 text-amber-400" />
                    <span className="truncate">Bargain Price</span>
                  </button>
                </div>

                {/* Live Real-Time Bargaining Proposal Form */}
                {isBargainFormOpen && (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const offered = Number(bargainPriceInput);
                      if (!offered || offered <= 0) {
                        showToast('Please specify a valid offered price in ₹.');
                        return;
                      }
                      if (seller) {
                        sendStoreChatMessage(
                          seller.id,
                          `🤝 [Bargain Offer] Customer proposes ₹${offered} for ${product.name} (Qty: ${bargainQtyInput} pcs). ${bargainNoteInput ? `Note: "${bargainNoteInput}"` : ''}`,
                          {
                            bargainOffer: {
                              productId: product.id,
                              productName: product.name,
                              originalPrice: product.price,
                              offeredPrice: offered,
                              quantity: bargainQtyInput,
                              status: 'PENDING',
                            },
                          }
                        );
                        showToast(`🤝 Bargain proposal of ₹${offered} sent to ${seller.storeName}! Check your chat for updates.`);
                        setIsBargainFormOpen(false);
                        setBargainPriceInput('');
                        setBargainNoteInput('');
                      } else {
                        showToast('Bargain submitted to verified merchant!');
                        setIsBargainFormOpen(false);
                      }
                    }}
                    className="p-3.5 rounded-xl bg-white border border-amber-500/40 space-y-3 text-xs animate-in fade-in duration-150"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 font-bold text-amber-400">
                        <Flame className="w-4 h-4 text-orange-400" />
                        <span>Propose Your Target Price to {seller?.storeName || 'Merchant'}</span>
                      </div>
                      <span className="text-[10px] text-slate-400">Catalog Price: ₹{product.price}</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-slate-300 block mb-1 font-semibold text-[11px]">Your Target Price (₹) *</label>
                        <input
                          type="number"
                          required
                          min={1}
                          max={product.price}
                          placeholder={`e.g. ₹${Math.round(product.price * 0.7)}`}
                          value={bargainPriceInput}
                          onChange={(e) => setBargainPriceInput(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-amber-300 font-bold text-xs focus:ring-1 focus:ring-amber-400 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="text-slate-300 block mb-1 font-semibold text-[11px]">Quantity (Pcs)</label>
                        <input
                          type="number"
                          min={1}
                          value={bargainQtyInput}
                          onChange={(e) => setBargainQtyInput(Math.max(1, Number(e.target.value)))}
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-bold text-xs focus:ring-1 focus:ring-amber-400 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-semibold text-[11px]">Negotiation Note / Reason (Optional)</label>
                      <input
                        type="text"
                        placeholder="e.g. Buying multiple units for office renovation"
                        value={bargainNoteInput}
                        onChange={(e) => setBargainNoteInput(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-200 text-xs focus:ring-1 focus:ring-amber-400 focus:outline-none"
                      />
                    </div>

                    <div className="flex justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setIsBargainFormOpen(false)}
                        className="px-3 py-1.5 rounded-lg text-slate-400 hover:text-white text-xs"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 font-black rounded-lg text-xs flex items-center gap-1 shadow-md transition"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Send Offer to Merchant</span>
                      </button>
                    </div>
                  </form>
                )}
              </div>

              {/* Complete the Look Bundle (WiseLook Outfit Matcher) */}
              {matchingBundle && (
                <div className="mt-5 p-4 rounded-2xl bg-amber-50/70 dark:bg-slate-800 border border-amber-200 dark:border-slate-700 space-y-2.5">
                  <div className="flex justify-between items-center">
                    <span className="text-[11px] font-black uppercase text-amber-900 dark:text-amber-300 flex items-center gap-1">
                      <Layers className="w-3.5 h-3.5 text-amber-600" />
                      Complete The Look Set ({matchingBundle.bundleDiscountPercent}% OFF)
                    </span>
                  </div>
                  <h4 className="font-extrabold text-xs text-stone-900 dark:text-white">
                    {matchingBundle.title}
                  </h4>
                  <button
                    onClick={() => addBundleToCart(matchingBundle.id)}
                    className="w-full py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold text-xs rounded-xl flex items-center justify-center gap-2 hover:bg-slate-800 transition"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    Add All Set Items to Bag & Save {matchingBundle.bundleDiscountPercent}%
                  </button>
                </div>
              )}

              {/* Trust Badges */}
              <div className="mt-4 grid grid-cols-3 gap-2 py-3 border-y border-slate-200 dark:border-slate-800 text-center">
                <div className="flex flex-col items-center text-[11px] text-slate-600 dark:text-slate-300">
                  <ShieldCheck className="w-4 h-4 text-amber-500 mb-0.5" />
                  <span>100% Original</span>
                </div>
                <div className="flex flex-col items-center text-[11px] text-slate-600 dark:text-slate-300">
                  <RotateCcw className="w-4 h-4 text-emerald-500 mb-0.5" />
                  <span>7-Day Easy Returns</span>
                </div>
                <div className="flex flex-col items-center text-[11px] text-slate-600 dark:text-slate-300">
                  <Truck className="w-4 h-4 text-blue-500 mb-0.5" />
                  <span>WiseExpress Shipping</span>
                </div>
              </div>

              {/* "Ask WiseAI" In-Store Product Assistant Box */}
              <div className="mt-5 p-4 rounded-xl bg-gradient-to-br from-amber-500/10 via-orange-500/5 to-transparent border border-amber-500/30">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-800 dark:text-amber-300 mb-2">
                  <Sparkles className="w-4 h-4 text-amber-500 animate-spin-slow" />
                  <span>Ask WiseAI About This Product</span>
                </div>

                <form onSubmit={handleAskWiseAI} className="flex gap-2">
                  <input
                    type="text"
                    value={aiQuestion}
                    onChange={(e) => setAiQuestion(e.target.value)}
                    placeholder="e.g. Is this fabric suitable for hot summers? How to style it?"
                    className="flex-1 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                  <button
                    type="submit"
                    disabled={!aiQuestion.trim() || aiLoading}
                    className="bg-amber-500 hover:bg-amber-600 text-slate-800 p-2 rounded-lg text-xs font-bold flex items-center justify-center disabled:opacity-50"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </form>

                {aiLoading && (
                  <p className="text-[11px] text-amber-600 dark:text-amber-400 mt-2 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 animate-spin" /> WiseAI is reviewing fabric specs & care instructions...
                  </p>
                )}

                {aiAnswer && (
                  <div className="mt-3 p-3 bg-white dark:bg-slate-900/90 rounded-lg border border-amber-500/20 text-xs text-slate-800 dark:text-slate-200 space-y-1.5">
                    <p className="font-medium">{aiAnswer.answer}</p>
                    {aiAnswer.stylingTips && (
                      <div className="pt-1.5 border-t border-slate-100 dark:border-slate-800">
                        <strong className="text-amber-600 dark:text-amber-400 text-[11px]">Styling Advice:</strong>
                        <ul className="list-disc pl-4 text-[11px] text-slate-600 dark:text-slate-300 mt-0.5 space-y-0.5">
                          {aiAnswer.stylingTips.map((tip, i) => (
                            <li key={i}>{tip}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Tabbed Specs, Materials & Reviews */}
        <div className="px-6 py-4 bg-slate-50 dark:bg-white border-t border-slate-200 dark:border-slate-800">
          <div className="flex border-b border-slate-200 dark:border-slate-800 gap-6 text-xs font-bold uppercase tracking-wider">
            <button
              onClick={() => setActiveTab('specs')}
              className={`pb-2 border-b-2 transition-all ${
                activeTab === 'specs'
                  ? 'border-orange-600 text-orange-600 dark:text-amber-400'
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Specifications
            </button>
            <button
              onClick={() => setActiveTab('care')}
              className={`pb-2 border-b-2 transition-all ${
                activeTab === 'care'
                  ? 'border-orange-600 text-orange-600 dark:text-amber-400'
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Fabric & Care
            </button>
            <button
              onClick={() => setActiveTab('shipping')}
              className={`pb-2 border-b-2 transition-all ${
                activeTab === 'shipping'
                  ? 'border-orange-600 text-orange-600 dark:text-amber-400'
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Shipping & Returns
            </button>
            <button
              onClick={() => setActiveTab('reviews')}
              className={`pb-2 border-b-2 transition-all ${
                activeTab === 'reviews'
                  ? 'border-orange-600 text-orange-600 dark:text-amber-400'
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Customer Reviews ({product?.reviews?.length || getProductReviews(product.id)?.length || 0})
            </button>
          </div>

          <div className="py-4 text-xs">
            {activeTab === 'specs' && (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {(product?.specifications || []).map((spec, i) => (
                  <div key={i} className="p-2.5 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 block text-[10px] uppercase font-semibold">{spec.label}</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{spec.value}</span>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'care' && (
              <div className="space-y-2 text-slate-700 dark:text-slate-300">
                <p><strong>Crafted From:</strong> {(product?.materials || []).join(', ') || 'Premium Quality Material'}</p>
                <p><strong>Care Instructions:</strong> Machine wash cold with similar shades. Low tumble dry or hang dry in shade to preserve premium weave elasticity. Warm iron if necessary.</p>
              </div>
            )}

            {activeTab === 'shipping' && (
              <div className="space-y-2 text-slate-700 dark:text-slate-300">
                <p><strong>Shipping Speed:</strong> {product.shippingInfo}</p>
                <p><strong>Doorstep Returns:</strong> {product.returnPolicy}</p>
                <p className="text-[11px] text-slate-500">Antifly offers reverse pickup in 24 hours across 19,000+ Indian pincodes.</p>
              </div>
            )}

            {activeTab === 'reviews' && (() => {
              const allProductReviews = product.reviews && product.reviews.length > 0
                ? product.reviews
                : getProductReviews(product.id);

              // Gather all customer photos from reviews
              const allCustomerPhotos = allProductReviews
                .flatMap((r) => r.images || [])
                .filter(Boolean);

              // Filtered reviews
              const filteredReviews = allProductReviews.filter((r) => {
                if (reviewFilter === 'photos') return (r.images?.length || 0) > 0;
                if (reviewFilter === '5star') return r.rating === 5;
                if (reviewFilter === 'verified') return r.isVerified || r.verifiedPurchase;
                return true;
              });

              // Rating distribution calculation
              const totalCount = allProductReviews.length || 1;
              const fiveStarCount = allProductReviews.filter((r) => r.rating === 5).length;
              const fourStarCount = allProductReviews.filter((r) => r.rating === 4).length;
              const threeStarCount = allProductReviews.filter((r) => r.rating === 3).length;
              const twoStarCount = allProductReviews.filter((r) => r.rating === 2).length;
              const oneStarCount = allProductReviews.filter((r) => r.rating === 1).length;

              const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
                const files = e.target.files;
                if (!files || files.length === 0) return;

                Array.from(files).forEach((file: File) => {
                  const reader = new FileReader();
                  reader.onloadend = () => {
                    if (reader.result) {
                      setReviewPhotos((prev) => [...prev, reader.result as string]);
                    }
                  };
                  reader.readAsDataURL(file);
                });
              };

              const handleSubmitReview = (e: React.FormEvent) => {
                e.preventDefault();
                if (!reviewTitle.trim() || !reviewComment.trim()) return;

                const parsedPros = reviewPros
                  .split(',')
                  .map((p) => p.trim())
                  .filter(Boolean);
                const parsedCons = reviewCons
                  .split(',')
                  .map((c) => c.trim())
                  .filter(Boolean);

                addProductReview(product.id, {
                  rating: newRating,
                  title: reviewTitle,
                  comment: reviewComment,
                  userName: currentCustomer.name || 'Verified Buyer',
                  images: reviewPhotos,
                  pros: parsedPros,
                  cons: parsedCons,
                  isVerified: true,
                  location: 'Bengaluru, India',
                });

                // Reset form
                setReviewTitle('');
                setReviewComment('');
                setReviewPros('');
                setReviewCons('');
                setReviewPhotos([]);
                setIsWriteReviewOpen(false);
              };

              return (
                <div className="space-y-5">
                  {/* Rating Overview & Breakdown Header */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                    <div className="flex flex-col items-center justify-center p-2 text-center md:border-r border-slate-200 dark:border-slate-800">
                      <div className="text-4xl font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                        <span>{product.rating.toFixed(1)}</span>
                        <Star className="w-7 h-7 text-amber-500 fill-amber-500" />
                      </div>
                      <p className="text-xs text-slate-500 mt-1">Based on {allProductReviews.length} verified ratings</p>
                      <span className="mt-2 text-[11px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full">
                        ✓ 96% of buyers recommend this product
                      </span>
                    </div>

                    {/* Star Rating Breakdown Bars */}
                    <div className="space-y-1.5 justify-center flex flex-col px-2">
                      {[
                        { stars: 5, count: fiveStarCount },
                        { stars: 4, count: fourStarCount },
                        { stars: 3, count: threeStarCount },
                        { stars: 2, count: twoStarCount },
                        { stars: 1, count: oneStarCount },
                      ].map((item) => {
                        const percent = Math.round((item.count / totalCount) * 100);
                        return (
                          <div key={item.stars} className="flex items-center gap-2 text-[11px]">
                            <span className="w-6 font-semibold text-slate-600 dark:text-slate-400">{item.stars}★</span>
                            <div className="flex-1 h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                              <div
                                className="h-full bg-amber-500 rounded-full"
                                style={{ width: `${percent}%` }}
                              />
                            </div>
                            <span className="w-8 text-right text-slate-400">{percent}%</span>
                          </div>
                        );
                      })}
                    </div>

                    {/* Write Review CTA Button */}
                    <div className="flex flex-col items-center justify-center p-2 md:border-l border-slate-200 dark:border-slate-800 gap-2">
                      <p className="text-xs text-slate-600 dark:text-slate-400 text-center font-medium">
                        Have you used this product? Share your real photos & feedback!
                      </p>
                      <button
                        onClick={() => setIsWriteReviewOpen(!isWriteReviewOpen)}
                        className="w-full py-2.5 px-4 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-800 font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md transition"
                      >
                        <Camera className="w-4 h-4" />
                        <span>{isWriteReviewOpen ? 'Close Review Form' : 'Write Review & Upload Photos'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Customer Uploaded Photos & Unboxing Strip */}
                  {allCustomerPhotos.length > 0 && (
                    <div className="p-3.5 bg-slate-100/80 dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                          <ImageIcon className="w-3.5 h-3.5 text-amber-500" />
                          <span>Customer Unboxing & Fit Photos ({allCustomerPhotos.length})</span>
                        </span>
                        <span className="text-[10px] text-slate-500">Click any photo to zoom in full HD</span>
                      </div>
                      <div className="flex gap-2.5 overflow-x-auto pb-1.5 no-scrollbar">
                        {allCustomerPhotos.map((photoUrl, idx) => (
                          <div
                            key={idx}
                            onClick={() => setActivePhotoLightbox(photoUrl)}
                            className="relative flex-shrink-0 w-20 h-20 rounded-xl overflow-hidden cursor-pointer border-2 border-transparent hover:border-amber-500 shadow-sm transition group"
                          >
                            <img
                              src={photoUrl}
                              alt={`Customer photo ${idx + 1}`}
                              className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute inset-0 bg-slate-100/30 opacity-0 group-hover:opacity-100 transition flex items-center justify-center text-white">
                              <Maximize2 className="w-4 h-4" />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Write Review Form Collapsible */}
                  {isWriteReviewOpen && (
                    <form
                      onSubmit={handleSubmitReview}
                      className="p-5 bg-white dark:bg-slate-900 rounded-2xl border-2 border-amber-500/30 shadow-lg space-y-4 animate-in fade-in slide-in-from-top-2 duration-200"
                    >
                      <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />
                          <h4 className="font-extrabold text-slate-900 dark:text-white text-sm">
                            Write a Customer Review & Upload Buyer Photos
                          </h4>
                        </div>
                        <span className="text-[11px] text-slate-500">Verified Purchase Experience</span>
                      </div>

                      {/* Interactive 5-Star Rating Selector */}
                      <div>
                        <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                          Overall Rating *
                        </label>
                        <div className="flex items-center gap-2">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <button
                              key={star}
                              type="button"
                              onClick={() => setNewRating(star)}
                              className="p-1 hover:scale-110 transition"
                            >
                              <Star
                                className={`w-6 h-6 ${
                                  star <= newRating
                                    ? 'text-amber-500 fill-amber-500'
                                    : 'text-slate-300 dark:text-slate-700'
                                }`}
                              />
                            </button>
                          ))}
                          <span className="text-xs font-bold text-amber-600 ml-2">
                            {newRating === 5
                              ? '5.0 / 5.0 - Excellent & Highly Recommended'
                              : newRating === 4
                              ? '4.0 / 5.0 - Very Good'
                              : newRating === 3
                              ? '3.0 / 5.0 - Average'
                              : newRating === 2
                              ? '2.0 / 5.0 - Below Expectations'
                              : '1.0 / 5.0 - Poor'}
                          </span>
                        </div>
                      </div>

                      {/* Review Title */}
                      <div>
                        <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                          Review Headline / Summary *
                        </label>
                        <input
                          type="text"
                          required
                          value={reviewTitle}
                          onChange={(e) => setReviewTitle(e.target.value)}
                          placeholder="e.g. Luxurious linen drape and flawless stitching!"
                          className="w-full text-xs bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                        />
                      </div>

                      {/* Review Comment */}
                      <div>
                        <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                          Detailed Feedback & Fit Experience *
                        </label>
                        <textarea
                          rows={3}
                          required
                          value={reviewComment}
                          onChange={(e) => setReviewComment(e.target.value)}
                          placeholder="Share details about size accuracy, fabric breathability, color match, delivery speed..."
                          className="w-full text-xs bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                        />
                      </div>

                      {/* Pros and Cons */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-bold text-emerald-600 dark:text-emerald-400 mb-1">
                            👍 Pros (comma separated)
                          </label>
                          <input
                            type="text"
                            value={reviewPros}
                            onChange={(e) => setReviewPros(e.target.value)}
                            placeholder="e.g. 100% Breathable, True to Size"
                            className="w-full text-xs bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-rose-500 mb-1">
                            👎 Cons (optional)
                          </label>
                          <input
                            type="text"
                            value={reviewCons}
                            onChange={(e) => setReviewCons(e.target.value)}
                            placeholder="e.g. Needs gentle ironing"
                            className="w-full text-xs bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-rose-500"
                          />
                        </div>
                      </div>

                      {/* Photo Upload Area (Device / Camera / File) */}
                      <div>
                        <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                          📸 Upload Customer Photos & Unboxing Snaps (from App / Gallery / Camera)
                        </label>
                        <input
                          type="file"
                          ref={reviewFileInputRef}
                          onChange={handlePhotoUpload}
                          accept="image/*"
                          multiple
                          className="hidden"
                        />

                        <div className="flex flex-wrap gap-2.5 items-center">
                          <button
                            type="button"
                            onClick={() => reviewFileInputRef.current?.click()}
                            className="px-4 py-3 border-2 border-dashed border-amber-500/40 hover:border-amber-500 rounded-xl bg-amber-500/5 hover:bg-amber-500/10 text-amber-700 dark:text-amber-300 text-xs font-bold flex items-center gap-2 transition"
                          >
                            <Camera className="w-4 h-4" />
                            <span>Take Photo / Select from Device</span>
                          </button>

                          {reviewPhotos.map((photo, i) => (
                            <div key={i} className="relative w-14 h-14 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 group">
                              <img src={photo} alt="Upload preview" className="w-full h-full object-cover" />
                              <button
                                type="button"
                                onClick={() => setReviewPhotos(reviewPhotos.filter((_, idx) => idx !== i))}
                                className="absolute top-1 right-1 bg-red-600 text-white p-0.5 rounded-md opacity-90 hover:opacity-100"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Submit / Cancel Action Bar */}
                      <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100 dark:border-slate-800">
                        <button
                          type="button"
                          onClick={() => setIsWriteReviewOpen(false)}
                          className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl text-xs hover:bg-slate-200 transition"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-5 py-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-800 font-extrabold rounded-xl text-xs shadow-md transition flex items-center gap-1.5"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Publish Customer Review</span>
                        </button>
                      </div>
                    </form>
                  )}

                  {/* Review Filter Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                    <span className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
                      Showing {filteredReviews.length} Reviews
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {[
                        { id: 'all', label: 'All Reviews' },
                        { id: 'photos', label: `📸 With Photos (${allCustomerPhotos.length})` },
                        { id: '5star', label: '⭐ 5 Stars Only' },
                        { id: 'verified', label: '✓ Verified Buyers' },
                      ].map((tab) => (
                        <button
                          key={tab.id}
                          onClick={() => setReviewFilter(tab.id as any)}
                          className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                            reviewFilter === tab.id
                              ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-sm'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Reviews List */}
                  <div className="space-y-3">
                    {filteredReviews.length === 0 ? (
                      <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
                        <p className="text-xs text-slate-500 font-medium">No reviews match the selected filter.</p>
                      </div>
                    ) : (
                      filteredReviews.map((rev) => (
                        <div
                          key={rev.id}
                          className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2.5 shadow-sm"
                        >
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                            <div className="flex items-center gap-2.5">
                              {rev.userAvatar ? (
                                <img
                                  src={rev.userAvatar}
                                  alt={rev.userName}
                                  className="w-8 h-8 rounded-full object-cover border border-amber-500/40"
                                />
                              ) : (
                                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-500 to-orange-500 text-slate-800 font-extrabold flex items-center justify-center text-xs">
                                  {rev.userName ? rev.userName.charAt(0) : 'U'}
                                </div>
                              )}
                              <div>
                                <div className="flex items-center gap-1.5">
                                  <span className="font-extrabold text-slate-900 dark:text-white text-xs">
                                    {rev.userName}
                                  </span>
                                  {rev.isVerified && (
                                    <span className="bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[10px] px-1.5 py-0.2 rounded-md font-bold flex items-center gap-0.5">
                                      <Check className="w-2.5 h-2.5" /> Verified Buyer
                                    </span>
                                  )}
                                </div>
                                <span className="text-[10px] text-slate-400">
                                  {rev.location || 'India'} &bull; {rev.date}
                                </span>
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              <div className="flex text-amber-400">
                                {Array.from({ length: 5 }).map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`w-3.5 h-3.5 ${
                                      i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300 dark:text-slate-700'
                                    }`}
                                  />
                                ))}
                              </div>
                            </div>
                          </div>

                          {/* Review Headline & Text */}
                          <div>
                            <h5 className="font-bold text-slate-900 dark:text-white text-xs">{rev.title}</h5>
                            <p className="text-slate-700 dark:text-slate-300 text-xs mt-0.5 leading-relaxed">
                              {rev.comment}
                            </p>
                          </div>

                          {/* Pros & Cons Pills */}
                          {((rev.pros && rev.pros.length > 0) || (rev.cons && rev.cons.length > 0)) && (
                            <div className="flex flex-wrap gap-1.5 pt-1">
                              {rev.pros?.map((pro, pIdx) => (
                                <span
                                  key={pIdx}
                                  className="text-[10px] font-bold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded-md border border-emerald-500/20"
                                >
                                  👍 {pro}
                                </span>
                              ))}
                              {rev.cons?.map((con, cIdx) => (
                                <span
                                  key={cIdx}
                                  className="text-[10px] font-bold bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 px-2 py-0.5 rounded-md border border-rose-500/20"
                                >
                                  👎 {con}
                                </span>
                              ))}
                            </div>
                          )}

                          {/* Review Photo Uploads Gallery */}
                          {rev.images && rev.images.length > 0 && (
                            <div className="flex flex-wrap gap-2 pt-1.5">
                              {rev.images.map((imgUrl, imgIdx) => (
                                <div
                                  key={imgIdx}
                                  onClick={() => setActivePhotoLightbox(imgUrl)}
                                  className="relative w-16 h-16 rounded-xl overflow-hidden cursor-pointer border border-slate-200 dark:border-slate-700 hover:border-amber-500 transition group"
                                >
                                  <img
                                    src={imgUrl}
                                    alt={`Review image ${imgIdx + 1}`}
                                    className="w-full h-full object-cover group-hover:scale-105 transition"
                                    referrerPolicy="no-referrer"
                                  />
                                </div>
                              ))}
                            </div>
                          )}

                          {/* Helpful Vote Action */}
                          <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500">
                            <span>Was this review helpful?</span>
                            <button
                              onClick={() => voteReviewHelpful(product.id, rev.id)}
                              className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-amber-500/10 hover:text-amber-600 rounded-lg font-bold flex items-center gap-1.5 transition text-slate-700 dark:text-slate-300"
                            >
                              <ThumbsUp className="w-3 h-3" />
                              <span>Helpful ({rev.helpfulCount || 0})</span>
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              );
            })()}
          </div>
        </div>

        {/* High-Resolution Photo Lightbox Modal */}
        {activePhotoLightbox && (
          <div
            className="fixed inset-0 z-[999] bg-slate-100/90 backdrop-blur-md flex items-center justify-center p-4"
            onClick={() => setActivePhotoLightbox(null)}
          >
            <div className="relative max-w-3xl max-h-[90vh] bg-white rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
              <button
                onClick={() => setActivePhotoLightbox(null)}
                className="absolute top-3 right-3 z-10 p-2 bg-slate-100/60 text-white rounded-full hover:bg-slate-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
              <img
                src={activePhotoLightbox}
                alt="High resolution customer photo"
                className="max-w-full max-h-[85vh] object-contain mx-auto"
                referrerPolicy="no-referrer"
              />
              <div className="p-3 bg-slate-900/90 text-center text-xs font-semibold text-slate-300">
                📸 Verified Customer Uploaded Photo & Unboxing Detail
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
