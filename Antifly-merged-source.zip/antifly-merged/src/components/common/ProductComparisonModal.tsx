import React from 'react';
import { useApp } from '../../context/AppContext';
import { X, Scale, Star, ShoppingBag, Check, Sparkles } from 'lucide-react';

export const ProductComparisonModal: React.FC = () => {
  const {
    isComparisonOpen,
    setIsComparisonOpen,
    comparisonList,
    removeFromComparison,
    clearComparison,
    addToCart,
    setActivePdpId,
  } = useApp();

  if (!isComparisonOpen || comparisonList.length === 0) return null;

  return (
    <div
      id="comparison-modal-overlay"
      className="fixed inset-0 z-50 bg-white/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fade-in"
    >
      <div className="bg-white dark:bg-slate-900 w-full max-w-5xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400">
              <Scale className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm tracking-wide">Product Comparison Matrix</h3>
              <p className="text-[11px] text-slate-400">
                Comparing {comparisonList.length} Antifly product{comparisonList.length > 1 ? 's' : ''}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={clearComparison}
              className="text-xs text-slate-400 hover:text-rose-400 px-2.5 py-1 rounded transition-all"
            >
              Clear All
            </button>
            <button
              onClick={() => setIsComparisonOpen(false)}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Matrix Comparison Table */}
        <div className="p-6 overflow-x-auto overflow-y-auto flex-1">
          <div
            className="grid gap-4"
            style={{
              gridTemplateColumns: `160px repeat(${comparisonList.length}, minmax(220px, 1fr))`,
            }}
          >
            {/* Header Row: Images & Names */}
            <div className="font-bold text-xs uppercase tracking-wider text-slate-400 flex items-end pb-4">
              Products
            </div>
            {comparisonList.map((p) => (
              <div key={p.id} className="relative bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700/80 flex flex-col justify-between">
                <button
                  onClick={() => removeFromComparison(p.id)}
                  className="absolute top-2 right-2 p-1 bg-white/80 dark:bg-slate-700/80 rounded-full hover:text-rose-500"
                  title="Remove from comparison"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
                <div>
                  <img
                    src={p.images?.[0] || p.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200'}
                    alt={p.name}
                    className="w-full h-40 object-cover rounded-lg mb-3 cursor-pointer"
                    onClick={() => {
                      setActivePdpId(p.id);
                      setIsComparisonOpen(false);
                    }}
                  />
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                    {p.brand}
                  </span>
                  <h4
                    className="font-bold text-sm text-slate-900 dark:text-white hover:text-orange-600 cursor-pointer line-clamp-2"
                    onClick={() => {
                      setActivePdpId(p.id);
                      setIsComparisonOpen(false);
                    }}
                  >
                    {p.name}
                  </h4>
                </div>
                <div className="mt-4">
                  <div className="flex items-baseline gap-2 mb-2">
                    <span className="text-lg font-bold text-slate-900 dark:text-white">
                      ₹{p.price.toLocaleString('en-IN')}
                    </span>
                    <span className="text-xs text-slate-400 line-through">₹{p.mrp}</span>
                    <span className="text-xs text-orange-600 font-bold">
                      {p.discountPercentage}% OFF
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      addToCart({
                        productId: p.id,
                        variantId: p.variants?.[0]?.id || 'default',
                        productName: p.name,
                        brand: p.brand,
                        color: p.colors?.[0]?.name || 'Standard',
                        size: p.sizes?.[0] || 'Standard',
                        price: p.price,
                        mrp: p.mrp,
                        image: p.images?.[0] || p.image || '',
                        quantity: 1,
                        stock: p.totalStock,
                      });
                    }}
                    className="w-full bg-amber-500 hover:bg-amber-600 text-slate-800 font-semibold py-2 rounded-lg text-xs flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    Add to Cart
                  </button>
                </div>
              </div>
            ))}

            {/* Row: Rating */}
            <div className="font-semibold text-xs text-slate-500 dark:text-slate-400 py-3 border-t border-slate-200 dark:border-slate-800 flex items-center">
              Customer Rating
            </div>
            {comparisonList.map((p) => (
              <div
                key={p.id}
                className="py-3 border-t border-slate-200 dark:border-slate-800 flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200"
              >
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span>{p.rating} / 5.0</span>
                <span className="text-slate-400 font-normal">({p.reviewCount} reviews)</span>
              </div>
            ))}

            {/* Row: Materials */}
            <div className="font-semibold text-xs text-slate-500 dark:text-slate-400 py-3 border-t border-slate-200 dark:border-slate-800 flex items-center">
              Fabric / Materials
            </div>
            {comparisonList.map((p) => (
              <div
                key={p.id}
                className="py-3 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300"
              >
                {p.materials.join(', ')}
              </div>
            ))}

            {/* Row: Sizes & Stock */}
            <div className="font-semibold text-xs text-slate-500 dark:text-slate-400 py-3 border-t border-slate-200 dark:border-slate-800 flex items-center">
              Sizes Available
            </div>
            {comparisonList.map((p) => (
              <div
                key={p.id}
                className="py-3 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300"
              >
                <div className="flex flex-wrap gap-1">
                  {p.sizes.map((s, idx) => (
                    <span
                      key={idx}
                      className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-[11px] font-medium"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            ))}

            {/* Row: Return Policy */}
            <div className="font-semibold text-xs text-slate-500 dark:text-slate-400 py-3 border-t border-slate-200 dark:border-slate-800 flex items-center">
              Return & Exchange
            </div>
            {comparisonList.map((p) => (
              <div
                key={p.id}
                className="py-3 border-t border-slate-200 dark:border-slate-800 text-xs text-emerald-600 dark:text-emerald-400 flex items-center gap-1 font-medium"
              >
                <Check className="w-3.5 h-3.5" />
                {p.returnPolicy}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
