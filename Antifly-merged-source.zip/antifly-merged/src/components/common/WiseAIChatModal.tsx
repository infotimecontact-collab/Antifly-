import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  X,
  Send,
  Mic,
  Camera,
  Bot,
  User,
  ShoppingBag,
  ArrowRight,
  RefreshCw,
  HelpCircle,
} from 'lucide-react';
import { Product } from '../../types';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  matchedProducts?: Product[];
  suggestedFollowUps?: string[];
  timestamp: string;
}

export const WiseAIChatModal: React.FC = () => {
  const {
    isWiseAIOpen,
    setIsWiseAIOpen,
    products,
    setActivePdpId,
    addToCart,
    setIsVoiceSearchOpen,
    setIsImageSearchOpen,
  } = useApp();

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-welcome',
      role: 'assistant',
      content:
        "Namaste! I am **WiseAI**, your personal luxury styling and shopping concierge at Antifly. I can help you discover outfits, verify fabrics, find items within your budget, or recommend trending essentials.",
      suggestedFollowUps: [
        'Show me black oversized t-shirts under ₹1,500',
        'Find breathable linen shirts for summer',
        'Recommend premium gifts under ₹3,000',
        'Best wireless ANC headphones with warranty',
      ],
      timestamp: 'Just now',
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  if (!isWiseAIOpen) return null;

  const handleSendMessage = async (textToSend?: string) => {
    const queryText = (textToSend || input).trim();
    if (!queryText || loading) return;

    const userMessage: ChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      content: queryText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const chatHistory = messages.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const res = await fetch('/api/wiseai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: queryText, history: chatHistory }),
      });
      const data = await res.json();

      let matchedProds: Product[] = [];
      if (data.matchedProductIds && Array.isArray(data.matchedProductIds)) {
        matchedProds = products.filter((p) => data.matchedProductIds.includes(p.id));
      }

      const assistantMessage: ChatMessage = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content: data.message || 'Here are the best items from our catalog matching your request:',
        matchedProducts: matchedProds.length > 0 ? matchedProds : undefined,
        suggestedFollowUps: data.suggestedFollowUps || [
          'Show more similar items',
          'Sort by best price',
          'Check delivery to my pincode',
        ],
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          id: `ai-err-${Date.now()}`,
          role: 'assistant',
          content: 'Here are our top recommendations tailored from the Antifly collection:',
          matchedProducts: products.slice(0, 3),
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      id="wiseai-modal-overlay"
      className="fixed inset-0 z-50 bg-white/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fade-in"
    >
      <div
        id="wiseai-chat-window"
        className="bg-white dark:bg-slate-900 w-full max-w-2xl h-[90vh] max-h-[720px] rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden"
      >
        {/* Chat Header */}
        <div className="px-4 py-3.5 bg-gradient-to-r from-slate-900 via-slate-800 to-amber-950 text-white flex items-center justify-between border-b border-slate-700/80">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center shadow-md">
              <Sparkles className="w-5 h-5 text-white animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base tracking-wide">WiseAI Assistant</h3>
                <span className="bg-emerald-500/20 text-emerald-400 text-[10px] font-semibold px-2 py-0.5 rounded-full border border-emerald-500/30">
                  Online &bull; Catalog Synced
                </span>
              </div>
              <p className="text-xs text-slate-300">Intelligent Shopping & Style Recommendations</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                setIsWiseAIOpen(false);
                setIsVoiceSearchOpen(true);
              }}
              className="p-2 text-slate-300 hover:text-amber-400 hover:bg-slate-800 rounded-lg transition-all"
              title="Switch to Voice AI"
            >
              <Mic className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                setIsWiseAIOpen(false);
                setIsImageSearchOpen(true);
              }}
              className="p-2 text-slate-300 hover:text-amber-400 hover:bg-slate-800 rounded-lg transition-all"
              title="Upload Photo for AI Search"
            >
              <Camera className="w-4 h-4" />
            </button>
            <button
              id="close-wiseai-modal-btn"
              onClick={() => setIsWiseAIOpen(false)}
              className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Message Log */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 bg-slate-50/50 dark:bg-white/50">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`flex gap-2.5 max-w-[90%] sm:max-w-[85%] ${
                  msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'
                }`}
              >
                {/* Avatar */}
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold ${
                    msg.role === 'user'
                      ? 'bg-orange-600 text-white'
                      : 'bg-gradient-to-tr from-amber-500 to-orange-500 text-white shadow-sm'
                  }`}
                >
                  {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                {/* Message Bubble */}
                <div
                  className={`p-3.5 rounded-2xl text-sm leading-relaxed shadow-sm ${
                    msg.role === 'user'
                      ? 'bg-orange-600 text-white rounded-tr-none'
                      : 'bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 border border-slate-200/80 dark:border-slate-800 rounded-tl-none'
                  }`}
                >
                  <p className="whitespace-pre-line">{msg.content}</p>

                  {/* Matched Product Cards Inside Chat */}
                  {msg.matchedProducts && msg.matchedProducts.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {msg.matchedProducts.map((p) => (
                        <div
                          key={p.id}
                          onClick={() => {
                            setActivePdpId(p.id);
                            setIsWiseAIOpen(false);
                          }}
                          className="bg-slate-50 dark:bg-slate-800/80 p-2 rounded-xl border border-slate-200 dark:border-slate-700/80 flex gap-2.5 items-center hover:border-amber-400 dark:hover:border-amber-500 cursor-pointer transition-all hover:shadow-md"
                        >
                          <img
                            src={p.images?.[0] || p.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200'}
                            alt={p.name}
                            className="w-14 h-14 object-cover rounded-lg flex-shrink-0"
                          />
                          <div className="flex-1 min-w-0">
                            <h4 className="font-semibold text-xs text-slate-900 dark:text-white truncate">
                              {p.name}
                            </h4>
                            <p className="text-[11px] text-slate-500 dark:text-slate-400">
                              {p.brand} &bull; {p.category}
                            </p>
                            <div className="flex items-center justify-between mt-1">
                              <span className="font-bold text-xs text-orange-600 dark:text-amber-400">
                                ₹{p.price.toLocaleString('en-IN')}
                              </span>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  addToCart({
                                    productId: p.id,
                                    variantId: p.variants?.[0]?.id || 'default',
                                    productName: p.name,
                                    brand: p.brand,
                                    color: p.colors?.[0]?.name || 'Standard',
                                    size: p.sizes?.[0] || 'Standard',
                                    price: p.price,
                                    mrp: p.mrp,
                                    image: p.images?.[0] || p.image || '',
                                    quantity: 1,
                                    stock: p.totalStock,
                                  });
                                }}
                                className="p-1 bg-amber-500 hover:bg-amber-600 text-slate-800 rounded-md text-[10px] font-semibold flex items-center gap-1"
                                title="Add to Cart"
                              >
                                <ShoppingBag className="w-3 h-3" />
                                + Cart
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="text-[10px] text-slate-400 dark:text-slate-500 mt-1.5 text-right">
                    {msg.timestamp}
                  </div>
                </div>
              </div>

              {/* Suggested Follow-Ups Pills */}
              {msg.suggestedFollowUps && msg.suggestedFollowUps.length > 0 && (
                <div className="mt-2.5 flex flex-wrap gap-1.5 ml-9 max-w-[85%]">
                  {msg.suggestedFollowUps.map((prompt, i) => (
                    <button
                      key={i}
                      onClick={() => handleSendMessage(prompt)}
                      className="text-xs bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:text-amber-600 dark:hover:text-amber-400 hover:bg-amber-50 dark:hover:bg-slate-700/80 px-2.5 py-1 rounded-full border border-slate-200 dark:border-slate-700 transition-all text-left flex items-center gap-1"
                    >
                      <ArrowRight className="w-2.5 h-2.5 text-amber-500" />
                      {prompt}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2.5 text-slate-500 dark:text-slate-400 text-xs ml-9">
              <div className="w-6 h-6 rounded-full bg-amber-500/20 flex items-center justify-center animate-spin">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              </div>
              <span>WiseAI is analyzing catalog specifications & availability...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              id="wiseai-chat-input"
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask WiseAI (e.g., 'Find black Cuban shirt under ₹2000' or 'What size for 40 chest?')..."
              className="flex-1 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500/50"
            />
            <button
              id="wiseai-send-btn"
              type="submit"
              disabled={!input.trim() || loading}
              className="bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 disabled:opacity-50 text-white p-2.5 rounded-xl font-medium shadow-md transition-all flex items-center justify-center"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
