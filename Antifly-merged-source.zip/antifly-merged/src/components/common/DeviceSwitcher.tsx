import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Monitor,
  Smartphone,
  ShieldCheck,
  Store,
  Truck,
  Code,
  Sparkles,
  Mic,
  Camera,
  Bell,
  Scale,
  Globe,
  BarChart3,
  Search,
  Share2,
  ArrowRightLeft,
  MessageSquare,
  CheckCircle2,
  Bot,
  Crown,
} from 'lucide-react';
import { DeviceMode, LanguageCode } from '../../types';
import { SUPPORTED_LANGUAGES } from '../../utils/i18n';

export const DeviceSwitcher: React.FC = () => {
  const {
    deviceMode,
    setDeviceMode,
    notifications,
    setIsNotificationDrawerOpen,
    setIsWiseAIOpen,
    setIsVoiceSearchOpen,
    setIsImageSearchOpen,
    setIsProductFinderOpen,
    setIsGA4ModalOpen,
    setIsSEOModalOpen,
    comparisonList,
    setIsComparisonOpen,
    language,
    setLanguage,
    t,
    setIsRoleSwitcherOpen,
    setIsConnectMembershipModalOpen,
    setIsVerifiedBadgeModalOpen,
    setIsSupportChatbotOpen,
    setIsAutonomousBrainModalOpen,
    setIsCommunityNetworkOpen,
    setIsDestinationDetourOpen,
    setIsTimeToEarnOpen,
    customerConnectState,
    userPersonaProfile,
  } = useApp();

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <header
      id="antifly-global-control-bar"
      className="sticky top-0 z-50 bg-white/95 text-slate-800 backdrop-blur-md border-b border-slate-200 px-2 sm:px-6 py-2 shadow-xs"
    >
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2 text-xs sm:text-sm">
        {/* Brand identity & Language selector */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-gradient-to-r from-red-600 via-rose-600 to-red-700 px-2.5 py-1 rounded-lg text-white font-black tracking-wider text-xs shadow-md">
            <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
            ANTIFLY
          </div>

          {/* Unified Role Switcher Trigger (Vice-Versa Capability) */}
          <button
            onClick={() => setIsRoleSwitcherOpen(true)}
            className="flex items-center gap-1.5 bg-gradient-to-r from-red-50 to-amber-50 hover:from-red-100 hover:to-amber-100 text-red-950 px-2.5 py-1 rounded-lg border border-red-200 font-bold transition shadow-2xs cursor-pointer"
            title="Single Account: Switch between Customer, Venture, and Buddy"
          >
            <ArrowRightLeft className="w-3.5 h-3.5 text-red-600" />
            <span className="font-extrabold capitalize">{userPersonaProfile.activePersona === 'seller' ? 'Venture' : userPersonaProfile.activePersona === 'driver' ? 'Buddy' : userPersonaProfile.activePersona} Mode</span>
            <span className="text-[10px] bg-red-600 text-white px-1.5 py-0.2 rounded-full uppercase">
              Switch 🔄
            </span>
          </button>

          {/* $1 Vendor Connect Membership Quick Trigger */}
          <button
            onClick={() => setIsConnectMembershipModalOpen(true)}
            className="hidden lg:flex items-center gap-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-950 px-2.5 py-1 rounded-lg border border-emerald-300 font-bold transition shadow-2xs cursor-pointer"
            title="$1 Venture Connect Membership (3-Month Free Trial Active)"
          >
            <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
            <span>$1 Connect</span>
            <span className="text-[9px] bg-emerald-600 text-white font-black px-1.5 py-0.2 rounded-full uppercase">
              3-Mo Free
            </span>
          </button>

          {/* Verified Tick Mark Upgrade Trigger */}
          <button
            onClick={() => setIsVerifiedBadgeModalOpen(true)}
            className="hidden xl:flex items-center gap-1 bg-blue-50 hover:bg-blue-100 text-blue-950 px-2.5 py-1 rounded-lg border border-blue-300 font-bold transition shadow-2xs cursor-pointer"
            title="Get Blue/Gold Verified Tick Mark ($10/mo venture, $2/yr customer)"
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 fill-blue-600" />
            <span>Verified Tick</span>
          </button>

          {/* 12-Language Switcher */}
          <div className="flex items-center bg-slate-100 px-2 py-1 rounded-lg border border-slate-200">
            <Globe className="w-3.5 h-3.5 text-slate-500 mr-1 shrink-0" />
            <select
              id="global-language-select"
              value={language}
              onChange={(e) => setLanguage(e.target.value as LanguageCode)}
              className="bg-transparent text-slate-800 text-xs font-semibold focus:outline-none cursor-pointer"
              title="Select Worldwide Language"
            >
              {SUPPORTED_LANGUAGES.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.flag} {lang.nativeName} ({lang.code.toUpperCase()})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* 3-in-1 Omnichannel SuperApp Switcher */}
        <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 overflow-x-auto max-w-full">
          {/* Customer Storefront Dropdown / Button */}
          <button
            id="switch-to-website"
            onClick={() => setDeviceMode('website')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg transition-all font-bold whitespace-nowrap text-xs ${
              deviceMode === 'website'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-700 hover:text-slate-800 hover:bg-slate-200/70'
            }`}
            title="1. Customer Web Storefront"
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>1. Customer</span>
          </button>

          <div className="h-4 w-px bg-slate-300 mx-1 hidden sm:block" />

          {/* VENTURE SUITE */}
          <button
            id="switch-to-seller-portal"
            onClick={() => setDeviceMode('seller')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg transition-all font-bold whitespace-nowrap text-xs ${
              deviceMode === 'seller'
                ? 'bg-orange-500 text-white shadow-xs'
                : 'text-slate-700 hover:text-slate-800 hover:bg-slate-200/70'
            }`}
            title="Venture Central Web Portal (Desktop)"
          >
            <Store className="w-3.5 h-3.5" />
            <span>2. Venture</span>
          </button>

          <button
            id="switch-to-seller-android"
            onClick={() => setDeviceMode('seller-android')}
            className={`hidden md:flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition-all font-bold whitespace-nowrap text-xs ${
              deviceMode === 'seller-android'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-700 hover:text-slate-800 hover:bg-slate-200/70'
            }`}
            title="Venture Android Mobile App (Material You)"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-500" />
            <span>Venture App</span>
          </button>

          <div className="h-4 w-px bg-slate-300 mx-1 hidden sm:block" />

          {/* Buddy Partner Logistics */}
          <button
            id="switch-to-driver-portal"
            onClick={() => setDeviceMode('driver')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg transition-all font-bold whitespace-nowrap text-xs ${
              deviceMode === 'driver'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'text-slate-700 hover:text-slate-800 hover:bg-slate-200/70'
            }`}
            title="3. Buddy Delivery Logistics App"
          >
            <Truck className="w-3.5 h-3.5" />
            <span>3. Buddy</span>
          </button>

          {/* Admin Command Center */}
          <button
            id="switch-to-admin-portal"
            onClick={() => setDeviceMode('admin')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg transition-all font-bold whitespace-nowrap text-xs ${
              deviceMode === 'admin'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'text-slate-700 hover:text-slate-800 hover:bg-slate-200/70'
            }`}
            title="Admin Command Center & Real-Time Analytics"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Admin</span>
          </button>

          {/* Customer Mobile Apps */}
          <button
            id="switch-to-mobile-android"
            onClick={() => setDeviceMode('mobile-android')}
            className={`hidden lg:flex items-center gap-1 px-2 py-1.5 rounded-lg transition-all font-semibold whitespace-nowrap text-xs ${
              deviceMode === 'mobile-android'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-800 hover:bg-slate-200/60'
            }`}
            title="Customer Mobile App (10-Tab Experience)"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Mobile App</span>
          </button>
        </div>

        {/* AI Chatbot, Support, & Search */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Community-Powered Commerce & Delivery Network (ONE PERSON: Buy-Sell-Deliver-Earn) */}
          <button
            onClick={() => setIsCommunityNetworkOpen(true)}
            className="flex items-center gap-1.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-700 hover:to-cyan-700 text-white px-2.5 py-1.5 rounded-xl shadow-md transition-all text-xs font-black ring-2 ring-emerald-400/40 cursor-pointer animate-pulse"
            title="ONE PERSON: BUY • SELL • DELIVER • EARN • CREATE • CONNECT"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-200" />
            <span className="hidden sm:inline">⚡ Community Network</span>
            <span className="text-[9px] bg-emerald-950 text-emerald-300 px-1.5 py-0.2 rounded-full font-black border border-emerald-500/50 uppercase">
              Earn Mode
            </span>
          </button>

          {/* Autonomous Commerce & Delivery Brain (60 Pillars) Trigger */}
          <button
            onClick={() => setIsAutonomousBrainModalOpen(true)}
            className="flex items-center gap-1.5 bg-gradient-to-r from-cyan-600 via-teal-600 to-emerald-600 hover:from-cyan-700 hover:to-emerald-700 text-white px-2.5 py-1.5 rounded-xl shadow-xs transition-all text-xs font-bold ring-1 ring-cyan-400/30"
            title="Next-Gen Autonomous Commerce & Delivery Brain (60 Pillars & Digital Twin)"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-200" />
            <span className="hidden sm:inline">AI Autonomous Brain</span>
            <span className="text-[10px] bg-cyan-950 text-cyan-300 px-1.5 py-0.2 rounded-full font-extrabold border border-cyan-500/40">
              60⚡
            </span>
          </button>

          {/* WiseBot AI 24/7 Support Trigger */}
          <button
            onClick={() => setIsSupportChatbotOpen(true)}
            className="flex items-center gap-1.5 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white px-2.5 py-1.5 rounded-xl shadow-xs transition-all text-xs font-bold"
            title="Ask WiseBot AI or Live Help Desk"
          >
            <Bot className="w-3.5 h-3.5" />
            <span>24/7 Support</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          </button>

          {/* Product Finder (Gemini AI recommendations) */}
          <button
            id="top-product-finder-trigger"
            onClick={() => setIsProductFinderOpen(true)}
            className="hidden sm:flex items-center gap-1 bg-amber-50 hover:bg-amber-100 text-amber-900 px-2.5 py-1.5 rounded-xl border border-amber-200 transition-all text-xs font-bold"
            title="AI Interactive Product Finder"
          >
            <Search className="w-3.5 h-3.5 text-amber-600" />
            <span className="hidden md:inline">Finder</span>
          </button>

          {/* Notifications / Transaction Emails Drawer */}
          <button
            id="top-notifications-trigger"
            onClick={() => setIsNotificationDrawerOpen(true)}
            className="relative p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-all"
            title="Notifications & Transactional Center"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute top-0.5 right-0.5 w-2 h-2 bg-red-600 rounded-full ring-2 ring-white" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};

