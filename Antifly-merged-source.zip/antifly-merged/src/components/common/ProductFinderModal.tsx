import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Search,
  X,
  Sparkles,
  ShoppingBag,
  Heart,
  ChevronRight,
  Filter,
  CheckCircle,
  Tag,
  Star,
} from 'lucide-react';
import { Product } from '../../types';

export const ProductFinderModal: React.FC = () => {
  const {
    isProductFinderOpen,
    setIsProductFinderOpen,
    products,
    formatPrice,
    addToCart,
    toggleWishlist,
    wishlist,
    setActivePdpId,
    t,
    showToast,
  } = useApp();

  const [step, setStep] = useState<number>(1);
  const [occasion, setOccasion] = useState<string>('festive');
  const [recipient, setRecipient] = useState<string>('women');
  const [budget, setBudget] = useState<string>('mid');
  const [fabric, setFabric] = useState<string>('silk');

  if (!isProductFinderOpen) return null;

  const occasions = [
    { id: 'wedding', label: 'Wedding & Bridal', emoji: '💍', desc: 'Grand heavy zari and heirloom weaves' },
    { id: 'festive', label: 'Festivals (Diwali / Puja)', emoji: '🪔', desc: 'Vibrant auspicious tones and rich borders' },
    { id: 'party', label: 'Party & Evening Soiree', emoji: '✨', desc: 'Modern silhouettes, sequins and chic styling' },
    { id: 'office', label: 'Work & Daily Elegance', emoji: '💼', desc: 'Breathable linen, tussar, and subtle prints' },
    { id: 'gift', label: 'Luxury Heritage Gifting', emoji: '🎁', desc: 'Curated collector weaves in presentation boxes' },
  ];

  const recipients = [
    { id: 'women', label: 'Women (Sarees & Lehengas)', emoji: '👗' },
    { id: 'men', label: 'Men (Kurta Sets & Sherwanis)', emoji: '👔' },
    { id: 'couple', label: 'Couple Matching Ensembles', emoji: '✨' },
    { id: 'home', label: 'Home & Temple Decor', emoji: '🪔' },
  ];

  const budgets = [
    { id: 'budget', label: 'Under ₹2,000', sub: 'Affordable Everyday' },
    { id: 'mid', label: '₹2,000 - ₹8,000', sub: 'Premium Festive' },
    { id: 'luxury', label: 'Above ₹8,000', sub: 'Pure Zari Heirloom' },
  ];

  const fabrics = [
    { id: 'silk', label: 'Pure Kanjeevaram & Banarasi Silk' },
    { id: 'cotton', label: 'Handloom Chanderi & Mulmul' },
    { id: 'organza', label: 'Modern Organza & Tissue' },
    { id: 'all', label: 'Show All Fabrics' },
  ];

  // Matched products computation
  const matchedProducts = products
    .filter((p) => {
      if (budget === 'budget') return p.price < 2500;
      if (budget === 'luxury') return p.price >= 8000;
      return p.price >= 2500 && p.price < 8000;
    })
    .slice(0, 4);

  // Fallback to top products if empty
  const finalResults = matchedProducts.length > 0 ? matchedProducts : products.slice(0, 4);

  const handleQuickAdd = async (product: Product) => {
    await addToCart({
      productId: product.id,
      productName: product.name,
      productImage: product.image || product.images?.[0] || '',
      price: product.price,
      mrp: product.mrp,
      quantity: 1,
      variantId: product.variants?.[0]?.id,
      color: product.variants?.[0]?.color,
      size: product.variants?.[0]?.size,
    });
  };

  return (
    <div id="product-finder-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl text-slate-100 overflow-hidden">
        {/* Header */}
        <div className="bg-white px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-slate-800 font-black shadow-md">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">
                AI Guided Product Finder & Matcher
              </h2>
              <p className="text-xs text-slate-400">
                Answer 3 quick preferences to discover tailored outfits and handcrafted pieces.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsProductFinderOpen(false)}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stepper Wizard Bar */}
        <div className="bg-slate-850 px-6 py-2.5 border-b border-slate-800 flex items-center justify-between text-xs font-semibold text-slate-400">
          <button
            onClick={() => setStep(1)}
            className={`flex items-center gap-1.5 ${step === 1 ? 'text-amber-400 font-bold' : ''}`}
          >
            <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-[10px]">1</span>
            <span>Occasion</span>
          </button>
          <ChevronRight className="w-3.5 h-3.5 text-slate-600" />
          <button
            onClick={() => setStep(2)}
            className={`flex items-center gap-1.5 ${step === 2 ? 'text-amber-400 font-bold' : ''}`}
          >
            <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-[10px]">2</span>
            <span>Budget & Fabric</span>
          </button>
          <ChevronRight className="w-3.5 h-3.5 text-slate-600" />
          <button
            onClick={() => setStep(3)}
            className={`flex items-center gap-1.5 ${step === 3 ? 'text-amber-400 font-bold' : ''}`}
          >
            <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-[10px]">3</span>
            <span>Recommendations</span>
          </button>
        </div>

        {/* Wizard Steps */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5 text-xs">
          {/* STEP 1: OCCASION & RECIPIENT */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-bold text-white block mb-2">What is the special occasion?</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {occasions.map((occ) => (
                    <div
                      key={occ.id}
                      onClick={() => setOccasion(occ.id)}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex items-start gap-3 ${
                        occasion === occ.id
                          ? 'bg-amber-500/20 border-amber-500 text-amber-200 shadow-md ring-1 ring-amber-500'
                          : 'bg-white border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <span className="text-2xl">{occ.emoji}</span>
                      <div>
                        <p className="font-bold text-white text-xs">{occ.label}</p>
                        <p className="text-[11px] text-slate-400 mt-0.5">{occ.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2">
                <label className="text-sm font-bold text-white block mb-2">Who is this for?</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {recipients.map((rec) => (
                    <div
                      key={rec.id}
                      onClick={() => setRecipient(rec.id)}
                      className={`p-3 rounded-xl border text-center cursor-pointer transition-all ${
                        recipient === rec.id
                          ? 'bg-amber-500/20 border-amber-500 text-amber-200 font-bold'
                          : 'bg-white border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <span className="text-xl block mb-1">{rec.emoji}</span>
                      <span className="text-xs">{rec.label}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  onClick={() => setStep(2)}
                  className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold rounded-xl text-xs transition-all shadow-lg flex items-center gap-1.5"
                >
                  <span>Continue to Budget</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: BUDGET & FABRIC */}
          {step === 2 && (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-bold text-white block mb-2">Preferred Price Range</label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {budgets.map((b) => (
                    <div
                      key={b.id}
                      onClick={() => setBudget(b.id)}
                      className={`p-3.5 rounded-xl border text-center cursor-pointer transition-all ${
                        budget === b.id
                          ? 'bg-amber-500/20 border-amber-500 text-amber-200 shadow-md ring-1 ring-amber-500'
                          : 'bg-white border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <p className="font-bold text-white text-sm">{b.label}</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">{b.sub}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2">
                <label className="text-sm font-bold text-white block mb-2">Fabric / Craft Preference</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {fabrics.map((f) => (
                    <div
                      key={f.id}
                      onClick={() => setFabric(f.id)}
                      className={`p-3 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                        fabric === f.id
                          ? 'bg-amber-500/20 border-amber-500 text-amber-200 font-bold'
                          : 'bg-white border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <span>{f.label}</span>
                      {fabric === f.id && <CheckCircle className="w-4 h-4 text-amber-400" />}
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 flex justify-between">
                <button
                  onClick={() => setStep(1)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl text-xs"
                >
                  Back
                </button>
                <button
                  onClick={() => setStep(3)}
                  className="px-6 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 font-black rounded-xl text-xs transition-all shadow-lg flex items-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Reveal AI Matched Curations</span>
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: MATCHED RESULTS */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-amber-500/10 border border-amber-500/30 p-3 rounded-2xl">
                <div className="flex items-center gap-2 text-amber-300">
                  <Sparkles className="w-4 h-4" />
                  <span className="font-bold">AI Match Found: {finalResults.length} Curated Options</span>
                </div>
                <button
                  onClick={() => setStep(1)}
                  className="text-xs text-amber-400 hover:underline font-semibold"
                >
                  Modify Filters
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {finalResults.map((p, idx) => (
                  <div
                    key={p.id}
                    className="bg-white border border-slate-800 rounded-2xl p-3 flex flex-col justify-between hover:border-slate-700 transition-all shadow-md"
                  >
                    <div>
                      <div className="relative rounded-xl overflow-hidden mb-2">
                        <img src={p.image || p.images?.[0]} alt={p.name} className="w-full h-40 object-cover" />
                        <span className="absolute top-2 left-2 bg-amber-500 text-slate-800 font-bold px-2 py-0.5 rounded text-[10px]">
                          {98 - idx * 2}% Match
                        </span>
                        <button
                          onClick={() => toggleWishlist(p.id)}
                          className={`absolute top-2 right-2 p-1.5 rounded-full backdrop-blur-md ${
                            wishlist.includes(p.id) ? 'bg-rose-500 text-white' : 'bg-slate-900/80 text-white'
                          }`}
                        >
                          <Heart className="w-3.5 h-3.5 fill-current" />
                        </button>
                      </div>

                      <span className="text-[10px] text-slate-400 uppercase font-semibold">{p.brand}</span>
                      <h4 className="font-bold text-white text-xs line-clamp-1">{p.name}</h4>
                      <div className="flex items-center gap-1.5 mt-1">
                        <span className="font-bold text-amber-400 text-sm">{formatPrice(p.price)}</span>
                        <span className="text-slate-500 text-xs line-through">{formatPrice(p.mrp)}</span>
                      </div>
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center gap-2">
                      <button
                        onClick={() => {
                          setActivePdpId(p.id);
                          setIsProductFinderOpen(false);
                        }}
                        className="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-semibold text-center text-xs"
                      >
                        Quick Details
                      </button>
                      <button
                        onClick={() => handleQuickAdd(p)}
                        className="p-1.5 bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold rounded-xl shadow-md"
                        title="Add to Cart"
                      >
                        <ShoppingBag className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
