import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Heart,
  Share2,
  ShoppingBag,
  MessageCircle,
  Volume2,
  VolumeX,
  Store,
  Play,
  Pause,
  CheckCircle2,
  Bookmark,
} from 'lucide-react';
import { UniversalSaveButton } from '../favorites/UniversalSaveButton';

export const ShortReelPlayerModal: React.FC = () => {
  const {
    isReelModalOpen,
    setIsReelModalOpen,
    activeReel,
    likeReel,
    openStoreChat,
    addToCart,
    products,
    shareStoreToEarnPoints,
  } = useApp();

  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);

  useEffect(() => {
    if (!isReelModalOpen || !isPlaying) return;

    setProgress(0);
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          return 0; // loop 5-second video
        }
        return prev + 2;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [isReelModalOpen, isPlaying, activeReel]);

  if (!isReelModalOpen || !activeReel) return null;

  const linkedProduct = products.find((p) => p.id === activeReel.linkedProductId);

  return (
    <div
      id="short-reel-player-modal"
      className="fixed inset-0 z-50 bg-slate-100/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4"
    >
      <div className="relative w-full max-w-sm h-[85vh] sm:h-[80vh] max-h-[720px] bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between border border-slate-800">
        {/* Progress Bar Header */}
        <div className="absolute top-3 left-3 right-3 z-30 flex items-center gap-1">
          <div className="flex-1 h-1 bg-white/30 rounded-full overflow-hidden">
            <div
              className="h-full bg-red-600 rounded-full transition-all duration-100"
              style={{ width: `${progress}%` }}
            />
          </div>
          <button
            onClick={() => setIsReelModalOpen(false)}
            className="p-1 rounded-full bg-slate-100/60 hover:bg-slate-100 text-white transition ml-2 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Video simulation / Thumbnail layer */}
        <div
          onClick={() => setIsPlaying(!isPlaying)}
          className="absolute inset-0 z-0 bg-slate-900 cursor-pointer overflow-hidden"
        >
          <img
            src={activeReel.thumbnailUrl}
            alt={activeReel.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-90 scale-105 transition-transform duration-1000"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-slate-100/50 via-transparent to-slate-100/90" />

          {!isPlaying && (
            <div className="absolute inset-0 flex items-center justify-center bg-slate-100/40">
              <div className="w-14 h-14 rounded-full bg-white/90 text-red-600 flex items-center justify-center shadow-lg">
                <Play className="w-7 h-7 fill-current ml-1" />
              </div>
            </div>
          )}
        </div>

        {/* Top Channel Info */}
        <div className="relative z-20 pt-8 px-4 flex items-center justify-between text-white">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-red-600 flex items-center justify-center text-xs font-black border border-white">
              {activeReel.sellerName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-1">
                <p className="font-extrabold text-xs text-white">
                  {activeReel.sellerName}
                </p>
                <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 fill-blue-500 text-slate-800" />
              </div>
              <p className="text-[10px] text-slate-300">5-Second Store Reel</p>
            </div>
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsMuted(!isMuted);
            }}
            className="p-2 rounded-full bg-slate-100/50 text-white hover:bg-slate-100/80 transition cursor-pointer"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>

        {/* Floating Right Actions */}
        <div className="relative z-20 self-end mr-3 mb-20 flex flex-col items-center gap-4 text-white">
          <button
            onClick={() => likeReel(activeReel.id)}
            className="flex flex-col items-center gap-1 group cursor-pointer"
          >
            <div className="w-10 h-10 rounded-full bg-slate-100/60 group-hover:bg-red-600/80 backdrop-blur-md flex items-center justify-center shadow-md transition">
              <Heart className="w-5 h-5 fill-red-500 text-red-500" />
            </div>
            <span className="text-[11px] font-bold">{activeReel.likesCount}</span>
          </button>

          <button
            onClick={() => openStoreChat(activeReel.sellerId)}
            className="flex flex-col items-center gap-1 group cursor-pointer"
          >
            <div className="w-10 h-10 rounded-full bg-slate-100/60 group-hover:bg-blue-600/80 backdrop-blur-md flex items-center justify-center shadow-md transition">
              <MessageCircle className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold">Chat</span>
          </button>

          {/* Universal Save Reel Button */}
          <div className="flex flex-col items-center gap-1">
            <UniversalSaveButton
              targetId={activeReel.id}
              itemType="reel"
              title={activeReel.title}
              subtitle={`by ${activeReel.sellerName}`}
              imageUrl={activeReel.videoThumbnail}
              tags={[activeReel.sellerName, 'Reel', 'Video']}
              size="md"
            />
            <span className="text-[10px] font-bold">Save</span>
          </div>

          <button
            onClick={() => shareStoreToEarnPoints(activeReel.sellerId, activeReel.sellerName)}
            className="flex flex-col items-center gap-1 group cursor-pointer"
          >
            <div className="w-10 h-10 rounded-full bg-slate-100/60 group-hover:bg-emerald-600/80 backdrop-blur-md flex items-center justify-center shadow-md transition">
              <Share2 className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold">+2 Pts</span>
          </button>
        </div>

        {/* Bottom Product Info & CTA */}
        <div className="relative z-20 p-4 space-y-2 bg-gradient-to-t from-slate-100 via-slate-100/80 to-transparent">
          <p className="text-sm font-bold text-white leading-tight">
            {activeReel.title}
          </p>

          {linkedProduct && (
            <div className="flex items-center justify-between p-2.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15">
              <div className="flex items-center gap-2 min-w-0">
                <img
                  src={linkedProduct.image}
                  alt={linkedProduct.name}
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-xl object-cover"
                />
                <div className="min-w-0">
                  <p className="text-xs font-bold text-white truncate">
                    {linkedProduct.name}
                  </p>
                  <p className="text-xs font-black text-amber-300">
                    ₹{linkedProduct.price}
                  </p>
                </div>
              </div>

              <button
                onClick={() =>
                  addToCart({
                    productId: linkedProduct.id,
                    product: linkedProduct,
                    quantity: 1,
                  })
                }
                className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black shadow-sm transition cursor-pointer flex items-center gap-1"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Buy</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
