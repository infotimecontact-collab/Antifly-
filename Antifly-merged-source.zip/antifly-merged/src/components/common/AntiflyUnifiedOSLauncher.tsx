import React, { useEffect, useState } from 'react';
import { Brain, Compass, Layers, X, Rocket, Sparkles } from 'lucide-react';
import { LegacyZololinkApp } from '../../legacy-z/LegacyZololinkApp';
import { useApp } from '../../context/AppContext';

/**
 * Antifly Unified Personal OS bridge.
 * NAVA remains the mission/social layer; the original LifeOS implementation is
 * preserved in a sandboxed legacy provider so no LifeOS capability is dropped.
 */
export const AntiflyUnifiedOSLauncher: React.FC = () => {
  const { openNavaSocialHub } = useApp();
  const [open, setOpen] = useState(false);
  const [view, setView] = useState<'overview' | 'lifeos'>('overview');

  useEffect(() => {
    const handler = () => { setView('overview'); setOpen(true); };
    window.addEventListener('antifly:open-unified-os', handler);
    return () => window.removeEventListener('antifly:open-unified-os', handler);
  }, []);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-white/95 backdrop-blur-md flex items-center justify-center p-2 sm:p-4">
      <div className="relative w-full h-full max-w-[1600px] rounded-3xl bg-white border border-slate-200 shadow-2xl overflow-hidden flex flex-col">
        <header className="shrink-0 px-4 sm:px-6 py-3 border-b border-slate-200 bg-gradient-to-r from-white via-indigo-50 to-cyan-50 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-500 to-cyan-500 text-white grid place-items-center shadow-lg">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-black text-slate-900 tracking-tight">Antifly Personal OS</h2>
              <p className="text-[11px] text-slate-500">LifeOS + NAVA • one unified destination for life, missions, social discovery and commerce</p>
            </div>
          </div>
          <button onClick={() => setOpen(false)} className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 grid place-items-center" aria-label="Close Antifly Personal OS">
            <X className="w-5 h-5" />
          </button>
        </header>

        <div className="shrink-0 p-3 border-b border-slate-200 bg-white flex flex-wrap gap-2">
          <button onClick={() => setView('overview')} className={`px-3 py-2 rounded-xl text-xs font-black flex items-center gap-2 ${view === 'overview' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-700'}`}>
            <Layers className="w-4 h-4" /> Unified OS
          </button>
          <button onClick={() => setView('lifeos')} className={`px-3 py-2 rounded-xl text-xs font-black flex items-center gap-2 ${view === 'lifeos' ? 'bg-cyan-600 text-white' : 'bg-slate-100 text-slate-700'}`}>
            <Sparkles className="w-4 h-4" /> LifeOS
          </button>
          <button onClick={() => openNavaSocialHub()} className="px-3 py-2 rounded-xl text-xs font-black flex items-center gap-2 bg-violet-600 text-white">
            <Rocket className="w-4 h-4" /> Open NAVA
          </button>
        </div>

        <main className="flex-1 min-h-0 overflow-auto">
          {view === 'overview' ? (
            <div className="max-w-6xl mx-auto p-5 sm:p-8 grid grid-cols-1 md:grid-cols-2 gap-5">
              <section className="rounded-3xl border border-cyan-200 bg-cyan-50 p-6">
                <div className="flex items-center gap-3 mb-3"><Sparkles className="text-cyan-600" /><h3 className="font-black text-lg text-slate-900">LifeOS</h3></div>
                <p className="text-sm text-slate-600 mb-5">Goals, planner, journal, memories, worlds, synchronicity, social graph, opportunity radar, future-you, agent swarm, stories, camera and the full original LifeOS feature set.</p>
                <button onClick={() => setView('lifeos')} className="px-4 py-2.5 rounded-xl bg-cyan-600 text-white text-sm font-black flex items-center gap-2"><Compass className="w-4 h-4" /> Enter LifeOS</button>
              </section>
              <section className="rounded-3xl border border-violet-200 bg-violet-50 p-6">
                <div className="flex items-center gap-3 mb-3"><Rocket className="text-violet-600" /><h3 className="font-black text-lg text-slate-900">NAVA</h3></div>
                <p className="text-sm text-slate-600 mb-5">Missions, circles, proof of progress, help exchange, time wallet, AI coach, real-world network, trust passport, goal graph and future-self profile.</p>
                <button onClick={() => openNavaSocialHub()} className="px-4 py-2.5 rounded-xl bg-violet-600 text-white text-sm font-black">Open NAVA</button>
              </section>
              <section className="md:col-span-2 rounded-3xl border border-slate-200 bg-white p-6">
                <h3 className="font-black text-slate-900 mb-2">Unified rule</h3>
                <p className="text-sm text-slate-600">NAVA is treated as the mission/community layer of Antifly Personal OS, while LifeOS is the broader life-management, discovery and agent layer. Neither feature set is removed; overlapping concepts are presented as complementary views.</p>
              </section>
            </div>
          ) : (
            <LegacyZololinkApp />
          )}
        </main>
      </div>
    </div>
  );
};
