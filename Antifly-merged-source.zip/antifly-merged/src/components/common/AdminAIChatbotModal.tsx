import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Bot,
  Send,
  Sparkles,
  ShieldCheck,
  Headphones,
  User,
  MessageSquare,
  Plus,
  CheckCircle2,
  Clock,
  AlertCircle,
  ChevronRight,
  PhoneCall,
  Phone,
  HelpCircle,
  Briefcase,
} from 'lucide-react';
import { SupportTicket, SupportMessage } from '../../types';

export const AdminAIChatbotModal: React.FC = () => {
  const {
    isSupportChatbotOpen,
    setIsSupportChatbotOpen,
    userPersonaProfile,
    supportTickets,
    createAdminSupportTicket,
    sendSupportMessage,
    settings,
    showToast,
  } = useApp();

  const [activeMode, setActiveMode] = useState<'talk_wise_india' | 'wise_india_person' | 'contact_support'>('talk_wise_india');
  const [aiMessages, setAiMessages] = useState<
    Array<{ id: string; sender: 'user' | 'ai'; text: string; time: string }>
  >([
    {
      id: 'ai-init',
      sender: 'ai',
      text: `Namaste ${userPersonaProfile.name}! 👋 Welcome to Antifly. How can we assist you today?
• Talk to Antifly AI Assistant
• Talk to Antifly person for live support
• 24/7 contact helpline Antifly: ${settings.contactPhone || '+91 98765 43210'}
• Inquire about Ventures, Buddy Deliveries, or Businessman Solutions!`,
      time: 'Just now',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);

  // New ticket form
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketCategory, setTicketCategory] = useState<SupportTicket['category']>('Orders & Delivery');
  const [ticketPriority, setTicketPriority] = useState<SupportTicket['priority']>('Normal');
  const [ticketInitialMsg, setTicketInitialMsg] = useState('');

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [aiMessages, selectedTicketId]);

  if (!isSupportChatbotOpen) return null;

  const handleSendAiMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const userText = inputText.trim();
    const userMsg = {
      id: `usr-${Date.now()}`,
      sender: 'user' as const,
      text: userText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setAiMessages((prev) => [...prev, userMsg]);
    setInputText('');

    // Generate intelligent AI Response
    setTimeout(() => {
      let reply = '';
      const lower = userText.toLowerCase();

      if (lower.includes('membership') || lower.includes('connect') || lower.includes('1 dollar') || lower.includes('$1') || lower.includes('trial')) {
        reply = `✨ **Vendor Connect Membership**: You currently have a **3-Month 100% Free Trial** active! After 3 months, packages start at just $1 (₹85) for 10 ventures, $2 for 100 ventures, $5 for 500 ventures, or $10 for 1,000 ventures to chat & bargain directly!`;
      } else if (lower.includes('tick') || lower.includes('verify') || lower.includes('verified') || lower.includes('badge')) {
        reply = `⭐ **Verified Tick Badges**:
• **Ventures**: $10/month (₹850) OR automatically free with 10–20 daily orders!
• **Customers**: $2/year (₹170) for VIP priority & verified reviewer status!
• **Buddies**: Verified through Driving License & Vehicle RC proofs.`;
      } else if (lower.includes('buddy') || lower.includes('delivery') || lower.includes('milestone') || lower.includes('incentive') || lower.includes('bonus') || lower.includes('evening') || lower.includes('radius')) {
        reply = `🛵 **Buddy Partner Incentives & Radius**:
• Deliver within **2km, 5km, or max 10km** nearby radius.
• **5 Deliveries in a day** -> **+$10 (₹850) Daily Reward Bonus**!
• **10 Deliveries in a day** -> **+$25 (₹2,100) Super Buddy Incentive**!
• Morning shopkeepers can deliver for 2 hours in the evening under the same single account!`;
      } else if (lower.includes('businessman') || lower.includes('human') || lower.includes('person') || lower.includes('support') || lower.includes('helpline')) {
        reply = `👨‍💼 **Talk to Antifly Person**: I can connect you directly with a Antifly representative right now. Click on the **'Talk to Antifly person'** tab above or call our **24/7 contact helpline Antifly** at **${settings.contactPhone || '+91 98765 43210'}**!`;
      } else if (lower.includes('venture') || lower.includes('shop') || lower.includes('vice versa') || lower.includes('role')) {
        reply = `🔄 **Unified Vice-Versa SuperApp**: You have one central account! You can run your venture in the morning (Venture mode), shop anytime (Customer mode), and deliver packages for 2 hours at night (Buddy mode).`;
      } else {
        reply = `Thank you for your question! As part of Antifly's hyperlocal superapp ecosystem, you can browse nearby ventures, chat & bargain directly with merchants, deliver evening orders within 2–10km as a Buddy, or connect with a Antifly person for personalized support.`;
      }

      setAiMessages((prev) => [
        ...prev,
        {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: reply,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    }, 600);
  };

  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketSubject.trim() || !ticketInitialMsg.trim()) {
      showToast('Please provide a subject and description for your ticket.');
      return;
    }

    createAdminSupportTicket(ticketSubject, ticketInitialMsg, ticketPriority, ticketCategory);
    showToast('🎫 Support ticket created! A Antifly person will respond shortly.');
    setTicketSubject('');
    setTicketInitialMsg('');
    setActiveMode('wise_india_person');
  };

  const selectedTicket = supportTickets.find((t) => t.id === selectedTicketId);

  return (
    <div
      id="admin-ai-chatbot-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-red-500/30 overflow-hidden flex flex-col h-[650px] max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shadow-inner">
              <Headphones className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black tracking-tight">
                  Antifly Support & Helpline
                </h2>
                <span className="bg-emerald-400 text-slate-800 text-[10px] font-black uppercase px-2 py-0.5 rounded-full shadow-xs flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                  24/7 Helpline
                </span>
              </div>
              <p className="text-xs text-rose-100">
                24/7 contact helpline Antifly &bull; Talk to Antifly person
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsSupportChatbotOpen(false)}
            className="p-2 rounded-xl text-rose-100 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 24/7 Contact Helpline Banner */}
        <div className="bg-amber-500/10 border-b border-amber-500/20 px-4 py-2 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-amber-900 dark:text-amber-300 font-bold">
            <PhoneCall className="w-3.5 h-3.5 text-red-600" />
            <span>24/7 contact helpline Antifly:</span>
            <a href={`tel:${settings.contactPhone || '+919876543210'}`} className="text-red-600 dark:text-red-400 font-black hover:underline">
              {settings.contactPhone || '+91 98765 43210'}
            </a>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-600 text-white font-black">
            Antifly Direct
          </span>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-white px-4 pt-2 gap-2 text-xs font-bold overflow-x-auto">
          <button
            onClick={() => {
              setActiveMode('talk_wise_india');
              setSelectedTicketId(null);
            }}
            className={`pb-2 px-3 border-b-2 flex items-center gap-1.5 transition whitespace-nowrap cursor-pointer ${
              activeMode === 'talk_wise_india'
                ? 'border-red-600 text-red-600 dark:text-red-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Talk to Antifly</span>
          </button>

          <button
            onClick={() => {
              setActiveMode('wise_india_person');
              setSelectedTicketId(null);
            }}
            className={`pb-2 px-3 border-b-2 flex items-center gap-1.5 transition whitespace-nowrap cursor-pointer ${
              activeMode === 'wise_india_person'
                ? 'border-red-600 text-red-600 dark:text-red-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Headphones className="w-3.5 h-3.5" />
            <span>Talk to Antifly person ({supportTickets.length})</span>
          </button>

          <button
            onClick={() => {
              setActiveMode('contact_support');
              setSelectedTicketId(null);
            }}
            className={`pb-2 px-3 border-b-2 flex items-center gap-1.5 transition whitespace-nowrap cursor-pointer ${
              activeMode === 'contact_support'
                ? 'border-red-600 text-red-600 dark:text-red-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Talk to contact support to Antifly</span>
          </button>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-hidden flex flex-col bg-slate-100/50 dark:bg-slate-900/50">
          {/* 1. TALK TO ANTIFLY (AI BOT MODE) */}
          {activeMode === 'talk_wise_india' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="flex-1 p-4 overflow-y-auto space-y-3">
                {aiMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex items-start gap-2.5 max-w-[85%] ${
                      msg.sender === 'user' ? 'ml-auto flex-row-reverse' : ''
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                        msg.sender === 'user'
                          ? 'bg-red-600 text-white'
                          : 'bg-gradient-to-tr from-amber-500 to-red-500 text-white'
                      }`}
                    >
                      {msg.sender === 'user' ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
                    </div>

                    <div>
                      <div
                        className={`p-3.5 rounded-2xl text-xs leading-relaxed ${
                          msg.sender === 'user'
                            ? 'bg-red-600 text-white rounded-tr-none'
                            : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-tl-none shadow-xs whitespace-pre-line'
                        }`}
                      >
                        {msg.text}
                      </div>
                      <span className="text-[10px] text-slate-400 mt-1 block px-1">
                        {msg.time}
                      </span>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>

              {/* Quick AI Prompts */}
              <div className="p-2 px-4 bg-white dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex gap-2 overflow-x-auto no-scrollbar">
                {[
                  'Talk to Antifly person',
                  '24/7 contact helpline Antifly',
                  'How does $1 connect membership work?',
                  'Verified Tick badge details',
                  'Buddy $10–$25 daily milestone bonus',
                ].map((prompt, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setInputText(prompt);
                    }}
                    className="whitespace-nowrap text-[11px] font-semibold bg-slate-100 dark:bg-slate-700 hover:bg-red-50 dark:hover:bg-red-950/40 text-slate-700 dark:text-slate-200 hover:text-red-600 px-2.5 py-1 rounded-full border border-slate-200 dark:border-slate-600 transition cursor-pointer"
                  >
                    {prompt}
                  </button>
                ))}
              </div>

              {/* AI Chat Input Form */}
              <form
                onSubmit={handleSendAiMessage}
                className="p-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex gap-2"
              >
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Talk to Antifly or ask any question..."
                  className="flex-1 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-red-500"
                />
                <button
                  type="submit"
                  disabled={!inputText.trim()}
                  className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition disabled:opacity-50 shadow-md cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send</span>
                </button>
              </form>
            </div>
          )}

          {/* 2. TALK TO ANTIFLY PERSON / TICKETS */}
          {activeMode === 'wise_india_person' && (
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {selectedTicket ? (
                <div className="space-y-4">
                  <button
                    onClick={() => setSelectedTicketId(null)}
                    className="text-xs font-bold text-red-600 dark:text-red-400 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    &larr; Back to all Antifly conversations
                  </button>

                  <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-slate-400">
                            #{selectedTicket.ticketNumber}
                          </span>
                          <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                            {selectedTicket.subject}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-500">
                          Category: {selectedTicket.category} &bull; Created: {selectedTicket.createdAt}
                        </span>
                      </div>

                      <span className="px-2.5 py-1 rounded-full text-[10px] font-black bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-500/30 uppercase">
                        {selectedTicket.status}
                      </span>
                    </div>

                    {/* Messages in ticket */}
                    <div className="space-y-3 max-h-[250px] overflow-y-auto p-2">
                      {selectedTicket.messages.map((m) => (
                        <div
                          key={m.id}
                          className={`p-3 rounded-xl text-xs ${
                            m.sender === 'admin'
                              ? 'bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/50 text-slate-900 dark:text-white'
                              : 'bg-slate-100 dark:bg-slate-700/50 text-slate-800 dark:text-slate-200 ml-4'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1 font-bold">
                            <span className="flex items-center gap-1 text-red-600 dark:text-red-400">
                              {m.sender === 'admin' ? <ShieldCheck className="w-3.5 h-3.5" /> : <User className="w-3.5 h-3.5" />}
                              {m.sender === 'admin' ? 'Antifly Support Person' : m.senderName}
                            </span>
                            <span className="text-[10px] text-slate-400 font-normal">{m.timestamp}</span>
                          </div>
                          <p className="leading-relaxed">{m.text}</p>
                        </div>
                      ))}
                    </div>

                    {/* Send reply */}
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (!inputText.trim()) return;
                        sendSupportMessage(selectedTicket.id, inputText.trim());
                        setInputText('');
                        showToast('Message sent to Antifly support person!');
                      }}
                      className="flex gap-2 pt-2 border-t border-slate-100 dark:border-slate-700"
                    >
                      <input
                        type="text"
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)}
                        placeholder="Reply to Antifly person..."
                        className="flex-1 bg-slate-100 dark:bg-slate-700/50 border border-slate-200 dark:border-slate-600 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-red-500"
                      />
                      <button
                        type="submit"
                        className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-xl text-xs font-bold cursor-pointer"
                      >
                        Reply
                      </button>
                    </form>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-extrabold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                      Talk to Antifly Person &bull; Tickets ({supportTickets.length})
                    </span>
                    <button
                      onClick={() => setActiveMode('contact_support')}
                      className="text-xs font-bold text-red-600 dark:text-red-400 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Create New Request
                    </button>
                  </div>

                  {supportTickets.length === 0 ? (
                    <div className="p-8 text-center bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                      <Headphones className="w-10 h-10 text-red-600 mx-auto" />
                      <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200">Talk to Antifly Person</h4>
                      <p className="text-xs text-slate-500 max-w-sm mx-auto">
                        Need personal assistance? Contact support to Antifly or call our 24/7 helpline anytime.
                      </p>
                      <button
                        onClick={() => setActiveMode('contact_support')}
                        className="px-4 py-2 bg-red-600 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer hover:bg-red-700 transition"
                      >
                        Talk to contact support to Antifly
                      </button>
                    </div>
                  ) : (
                    supportTickets.map((t) => (
                      <div
                        key={t.id}
                        onClick={() => setSelectedTicketId(t.id)}
                        className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-red-400 cursor-pointer transition shadow-xs flex items-center justify-between"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-[11px] font-mono text-slate-400">#{t.ticketNumber}</span>
                            <h4 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white">
                              {t.subject}
                            </h4>
                          </div>
                          <p className="text-[11px] text-slate-500 mt-1">
                            {t.category} &bull; {t?.messages?.length || 0} messages &bull; Last update: {t?.messages?.[(t?.messages?.length || 1) - 1]?.timestamp || t.createdAt}
                          </p>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                            t.status === 'Resolved' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                          }`}>
                            {t.status}
                          </span>
                          <ChevronRight className="w-4 h-4 text-slate-400" />
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          )}

          {/* 3. TALK TO CONTACT SUPPORT TO ANTIFLY (NEW TICKET FORM) */}
          {activeMode === 'contact_support' && (
            <form onSubmit={handleCreateTicket} className="p-6 overflow-y-auto space-y-4">
              <div>
                <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
                  Talk to contact support to Antifly
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Our dedicated Antifly executive team responds within 15–30 minutes.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Subject *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Query regarding venture orders, buddy payout, or account"
                  value={ticketSubject}
                  onChange={(e) => setTicketSubject(e.target.value)}
                  className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Category
                  </label>
                  <select
                    value={ticketCategory}
                    onChange={(e) => setTicketCategory(e.target.value as any)}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-red-500"
                  >
                    <option value="Orders & Delivery">Orders & Delivery</option>
                    <option value="Seller Payout">Venture Payout</option>
                    <option value="Driver Milestone">Buddy Milestone Bonus</option>
                    <option value="Vendor Connect">Vendor Connect Membership</option>
                    <option value="Verified Badge">Verified Badge</option>
                    <option value="Technical">Technical & Business</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Priority
                  </label>
                  <select
                    value={ticketPriority}
                    onChange={(e) => setTicketPriority(e.target.value as any)}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-red-500"
                  >
                    <option value="Normal">Normal</option>
                    <option value="High">High</option>
                    <option value="Urgent">Urgent (Immediate Callback)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Message / Details *
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="Describe your issue or request in detail so our Antifly person can resolve it..."
                  value={ticketInitialMsg}
                  onChange={(e) => setTicketInitialMsg(e.target.value)}
                  className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-extrabold rounded-xl text-xs shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Talk to contact support to Antifly</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
