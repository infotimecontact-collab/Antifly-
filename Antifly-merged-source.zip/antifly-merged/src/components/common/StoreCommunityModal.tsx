import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { StoreCommunity, StoreCommunityPost, Product, Customer } from '../../types';
import {
  Users,
  MessageSquare,
  Sparkles,
  Search,
  Filter,
  CheckCircle,
  Plus,
  Heart,
  Share2,
  Tag,
  ShoppingBag,
  Send,
  X,
  Store,
  ShieldCheck,
  Zap,
  Bookmark,
  Pin,
  TrendingUp,
  Image as ImageIcon,
  Check,
  Video,
  Play,
  Film,
  UserPlus,
  UserCheck,
  MapPin,
  Wrench,
  Clock,
  Phone,
  FileSpreadsheet,
} from 'lucide-react';
import { UniversalSaveButton } from '../favorites/UniversalSaveButton';

interface StoreCommunityModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialSellerId?: string;
}

export const StoreCommunityModal: React.FC<StoreCommunityModalProps> = ({
  isOpen,
  onClose,
  initialSellerId,
}) => {
  const {
    storeCommunities,
    communityPosts,
    joinOrLeaveStoreCommunity,
    createCommunityPost,
    likeCommunityPost,
    addCommunityPostComment,
    openStoreChat,
    startSellerToCustomerChat,
    createStoreCommunity,
    toggleFollowSeller,
    sellerFollowCustomer,
    currentCustomer,
    currentSeller,
    currentRole,
    sellers,
    customers,
    products,
    addToCart,
    showToast,
  } = useApp();

  const [selectedSellerId, setSelectedSellerId] = useState<string>(
    initialSellerId || 'all'
  );

  useEffect(() => {
    if (initialSellerId) {
      setSelectedSellerId(initialSellerId);
    }
  }, [initialSellerId, isOpen]);

  const [searchQuery, setSearchQuery] = useState('');
  const [activeTopic, setActiveTopic] = useState<string>('all');
  const [newCommentText, setNewCommentText] = useState<{ [postId: string]: string }>({});
  const [activeTab, setActiveTab] = useState<'feed' | 'members' | 'reels'>('feed');

  // Video playback modal state
  const [playingVideoUrl, setPlayingVideoUrl] = useState<string | null>(null);

  // New Broadcast Post Modal (For Sellers)
  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);
  const [postTitle, setPostTitle] = useState('');
  const [postContent, setPostContent] = useState('');
  const [postMediaUrl, setPostMediaUrl] = useState('');
  const [postMediaType, setPostMediaType] = useState<'image' | 'video' | 'reel'>('image');
  const [postDiscountBadge, setPostDiscountBadge] = useState('COMMUNITY EXCLUSIVE: 15% OFF');
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>([]);

  // Create Community Modal (For Sellers without community)
  const [isCreateCommunityOpen, setIsCreateCommunityOpen] = useState(false);
  const [communityTagline, setCommunityTagline] = useState('');
  const [communityTopicsInput, setCommunityTopicsInput] = useState('New Drops, Wholesale Deals, Q&A');

  if (!isOpen) return null;

  const currentUserId = currentCustomer.id || 'cust-101';
  const isCustomerFollowingActiveSeller = (sellerId: string) => {
    return currentCustomer.followingSellerIds?.includes(sellerId) ?? false;
  };

  // Filtered communities
  const filteredCommunities = storeCommunities.filter((com) => {
    const matchesSearch =
      com.storeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      com.tagline.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSearch;
  });

  // Selected community details if not 'all'
  const activeCommunity = storeCommunities.find((c) => c.sellerId === selectedSellerId);
  const activeSellerObj = sellers.find((s) => s.id === selectedSellerId);

  // Filtered posts
  const filteredPosts = communityPosts.filter((post) => {
    if (selectedSellerId !== 'all' && post.sellerId !== selectedSellerId) {
      return false;
    }
    if (activeTab === 'reels' && post.mediaType !== 'reel' && post.mediaType !== 'video') {
      return false;
    }
    if (searchQuery.trim()) {
      const matchText =
        post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.storeName.toLowerCase().includes(searchQuery.toLowerCase());
      if (!matchText) return false;
    }
    return true;
  });

  // Seller's own community check
  const sellerHasCommunity = storeCommunities.some(
    (c) => c.sellerId === currentSeller.id
  );

  const handlePublishPost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!postTitle.trim() || !postContent.trim()) {
      showToast('Please enter title and content for your community post');
      return;
    }

    createCommunityPost({
      sellerId: currentSeller.id,
      title: postTitle.trim(),
      content: postContent.trim(),
      mediaUrl: postMediaUrl.trim() || 'https://images.unsplash.com/photo-1558060370-d644479cb6f7?w=800&auto=format&fit=crop&q=80',
      mediaType: postMediaType,
      videoThumbnail: postMediaType !== 'image' ? (postMediaUrl.trim() || 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=800&auto=format&fit=crop&q=80') : undefined,
      discountBadge: postDiscountBadge.trim() || undefined,
      featuredProductIds: selectedProductIds,
      pinned: true,
    });

    setPostTitle('');
    setPostContent('');
    setPostMediaUrl('');
    setSelectedProductIds([]);
    setIsCreatePostOpen(false);
  };

  const handleCreateCommunitySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createStoreCommunity({
      sellerId: currentSeller.id,
      tagline: communityTagline.trim() || `${currentSeller.storeName} Official Community Circle`,
      topics: communityTopicsInput.split(',').map((s) => s.trim()).filter(Boolean),
    });
    setIsCreateCommunityOpen(false);
  };

  const handleBuyFeaturedProduct = async (prod: Product) => {
    await addToCart({
      productId: prod.id,
      productName: `[Community Deal] ${prod.name}`,
      price: prod.price,
      quantity: 1,
      image: prod.images?.[0] || prod.image || '',
    });
    showToast(`Added ${prod.name} to cart!`);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-fade-in">
      <div className="bg-white w-full max-w-5xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Top Header Banner */}
        <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white p-5 sm:p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-slate-300 hover:text-white bg-white/10 hover:bg-white/20 rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="bg-blue-500/20 text-blue-300 text-xs font-black px-2.5 py-1 rounded-full border border-blue-400/30 flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5" />
                  Hyperlocal Venture Communities & Feeds
                </span>
                <span className="bg-amber-500/20 text-amber-300 text-xs font-black px-2.5 py-1 rounded-full border border-amber-400/30 flex items-center gap-1">
                  <Tag className="w-3 h-3" />
                  Direct 1-on-1 Bargaining
                </span>
                <span className="bg-purple-500/20 text-purple-300 text-xs font-black px-2.5 py-1 rounded-full border border-purple-400/30 flex items-center gap-1">
                  <Film className="w-3 h-3" />
                  Venture Video Reels & Chats
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight">
                Venture Communities & Interactive Social Feeds
              </h2>
              <p className="text-xs text-slate-300 max-w-2xl">
                Follow local ventures, watch venture video reels, join community circles, and chat 1-on-1 with ventures to negotiate custom prices (e.g. ₹50 products for ₹20).
              </p>
            </div>

            {/* Quick Action (Create Post / Launch Community) */}
            <div className="flex items-center gap-2">
              {sellerHasCommunity ? (
                <button
                  onClick={() => setIsCreatePostOpen(true)}
                  className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Post Reel / Product Drop</span>
                </button>
              ) : (
                <button
                  onClick={() => setIsCreateCommunityOpen(true)}
                  className="bg-emerald-500 hover:bg-emerald-600 text-white px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Launch My Venture Community</span>
                </button>
              )}
            </div>
          </div>

          {/* Search & Store Circles Selector Bar */}
          <div className="mt-4 pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
            {/* Search Input */}
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search ventures, locations, reels or posts..."
                className="w-full pl-9 pr-3 py-1.5 bg-white/10 border border-white/20 rounded-xl text-xs text-white placeholder:text-slate-400 focus:outline-none focus:bg-white/20"
              />
            </div>

            {/* Venture Circles Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto scrollbar-none pb-1 sm:pb-0">
              <button
                onClick={() => setSelectedSellerId('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                  selectedSellerId === 'all'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'bg-white/10 text-white hover:bg-white/20'
                }`}
              >
                🌐 All Venture Circles ({communityPosts.length})
              </button>

              {storeCommunities.map((com) => {
                const isSelected = selectedSellerId === com.sellerId;
                const isMember = com.memberUserIds.includes(currentUserId);
                const isFollowing = isCustomerFollowingActiveSeller(com.sellerId);

                return (
                  <button
                    key={com.sellerId}
                    onClick={() => setSelectedSellerId(com.sellerId)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                      isSelected
                        ? 'bg-blue-500 text-white shadow-sm'
                        : 'bg-white/10 text-white hover:bg-white/20'
                    }`}
                  >
                    <img
                      src={com.avatarUrl}
                      alt={com.storeName}
                      className="w-4 h-4 rounded-full object-cover"
                    />
                    <span className="truncate max-w-[130px]">{com.storeName}</span>
                    {isFollowing && <span className="text-[10px] text-amber-300">★</span>}
                    {isMember && <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full"></span>}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Navigation Tabs (Feed / Reels / Community Members) */}
        {activeCommunity && (
          <div className="bg-slate-100 px-6 py-2 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('feed')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'feed'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5 text-blue-600" />
                Community Feed
              </button>
              <button
                onClick={() => setActiveTab('reels')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'reels'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Film className="w-3.5 h-3.5 text-purple-600" />
                Video Reels & Clips
              </button>
              <button
                onClick={() => setActiveTab('members')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'members'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Users className="w-3.5 h-3.5 text-emerald-600" />
                Members & Followers ({activeCommunity.membersCount})
              </button>
            </div>

            {/* Following Indicator */}
            <div className="text-xs text-slate-500 font-semibold hidden sm:flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-rose-500" />
              <span>{activeSellerObj?.warehouseAddress?.street || 'Shop #14, Rajwada Main Market, Indore'}</span>
            </div>
          </div>
        )}

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 bg-slate-50">
          
          {/* Active Community Spotlight Banner */}
          {activeCommunity && (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="h-36 w-full relative">
                <img
                  src={activeCommunity.bannerUrl}
                  alt={activeCommunity.storeName}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent flex items-end p-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between w-full gap-3 text-white">
                    <div className="flex items-center gap-3">
                      <img
                        src={activeCommunity.avatarUrl}
                        alt={activeCommunity.storeName}
                        className="w-14 h-14 rounded-2xl object-cover border-2 border-white shadow-md"
                      />
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h3 className="text-base font-extrabold">{activeCommunity.storeName}</h3>
                          <ShieldCheck className="w-4 h-4 text-blue-400 fill-blue-400/20" />
                          {activeSellerObj?.isServiceProvider && (
                            <span className="bg-amber-500 text-slate-800 text-[10px] font-black px-2 py-0.5 rounded-md flex items-center gap-1">
                              <Wrench className="w-3 h-3" />
                              Service Provider ({activeSellerObj.serviceType})
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-200 mt-0.5">{activeCommunity.tagline}</p>
                        <p className="text-[11px] text-slate-300 flex items-center gap-1 mt-1 font-medium">
                          <MapPin className="w-3 h-3 text-rose-400" />
                          <span>{activeSellerObj?.warehouseAddress?.street || 'Shop #14, Rajwada Main Market, Indore'} • 1.2 km away</span>
                        </p>
                      </div>
                    </div>

                    {/* Followers count badge */}
                    <div className="bg-white/10 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/20 text-right">
                      <span className="text-[10px] uppercase font-bold text-slate-300 block">Community Followers</span>
                      <span className="text-base font-black text-white">
                        {(activeSellerObj?.followersCount || activeCommunity.membersCount).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Service Provider Specs Bar if applicable */}
              {activeSellerObj?.isServiceProvider && (
                <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 flex items-center justify-between flex-wrap gap-2 text-xs">
                  <div className="flex items-center gap-3">
                    <span className="font-extrabold text-amber-900 flex items-center gap-1">
                      <Zap className="w-3.5 h-3.5 text-amber-600" />
                      Visit Charge: ₹{activeSellerObj.serviceVisitFee || 149}
                    </span>
                    <span className="text-amber-300">•</span>
                    <span className="font-extrabold text-amber-900 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-amber-600" />
                      Hourly Rate: ₹{activeSellerObj.serviceHourlyRate || 199}/hr
                    </span>
                    {activeSellerObj.serviceEmergencyAvailable && (
                      <>
                        <span className="text-amber-300">•</span>
                        <span className="bg-emerald-600 text-white text-[10px] font-black px-2 py-0.5 rounded-md">
                          ⚡ 30-Min Emergency Dispatch Available
                        </span>
                      </>
                    )}
                  </div>
                  <span className="text-[11px] text-amber-800 font-semibold">
                    Chat directly to request electrician / plumber quotes
                  </span>
                </div>
              )}

              {/* Action Buttons Bar */}
              <div className="p-4 flex flex-wrap items-center justify-between gap-3 bg-white">
                <div className="flex items-center gap-3 text-xs">
                  <span className="font-bold text-slate-800 flex items-center gap-1">
                    <Users className="w-4 h-4 text-blue-600" />
                    <strong>{activeCommunity.membersCount.toLocaleString()}</strong> Members
                  </span>
                  <span className="text-slate-300">•</span>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {activeCommunity.topics.map((t, idx) => (
                      <span
                        key={idx}
                        className="bg-slate-100 text-slate-700 font-semibold px-2 py-0.5 rounded-md text-[10px]"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {/* Universal Save Store / Seller Button */}
                  <UniversalSaveButton
                    targetId={activeCommunity.sellerId}
                    itemType="seller"
                    title={activeCommunity.storeName}
                    subtitle={activeCommunity.tagline}
                    imageUrl={activeCommunity.avatarUrl}
                    tags={activeCommunity.topics}
                    variant="text-with-icon"
                  />

                  {/* Customer Follow/Unfollow Venture Button */}
                  <button
                    onClick={() => toggleFollowSeller(activeCommunity.sellerId)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer ${
                      isCustomerFollowingActiveSeller(activeCommunity.sellerId)
                        ? 'bg-amber-50 text-amber-800 border border-amber-300 hover:bg-amber-100'
                        : 'bg-slate-900 hover:bg-slate-800 text-white shadow-xs'
                    }`}
                  >
                    {isCustomerFollowingActiveSeller(activeCommunity.sellerId) ? (
                      <>
                        <UserCheck className="w-3.5 h-3.5 text-amber-600" />
                        <span>Following Venture ★</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Follow Venture</span>
                      </>
                    )}
                  </button>

                  {/* Join / Leave Community Button */}
                  <button
                    onClick={() => joinOrLeaveStoreCommunity(activeCommunity.sellerId)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer ${
                      activeCommunity.memberUserIds.includes(currentUserId)
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-300 hover:bg-emerald-100'
                        : 'bg-blue-600 hover:bg-blue-700 text-white shadow-xs'
                    }`}
                  >
                    {activeCommunity.memberUserIds.includes(currentUserId) ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Circle Member</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-3.5 h-3.5" />
                        <span>Join Circle</span>
                      </>
                    )}
                  </button>

                  {/* Direct 1-on-1 Bargain & Support Chat */}
                  <button
                    onClick={() => {
                      openStoreChat(activeCommunity.sellerId);
                      onClose();
                    }}
                    className="px-4 py-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 rounded-xl text-xs font-black flex items-center gap-1.5 shadow-xs transition cursor-pointer"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Chat & Bargain (e.g. ₹50 → ₹20)</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Tab Content: Community Members (Allows Sellers to follow customers and message them directly) */}
          {activeCommunity && activeTab === 'members' && (
            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-xs">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                    <Users className="w-4 h-4 text-blue-600" />
                    Community Members & Customers
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Sellers can connect with anyone who joins their community, follow them, or send a direct message.
                  </p>
                </div>
                <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-lg">
                  {customers.length} Active Connected Customers
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                {customers.map((cust) => {
                  const isFollowedBySeller = activeSellerObj?.followedCustomerIds?.includes(cust.id) ?? false;

                  return (
                    <div
                      key={cust.id}
                      className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={cust.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                          alt={cust.name}
                          className="w-10 h-10 rounded-full object-cover border border-slate-200"
                        />
                        <div>
                          <h4 className="font-bold text-xs text-slate-900">{cust.name}</h4>
                          <p className="text-[11px] text-slate-500">{cust.city || 'Indore'} • Verified Customer</p>
                          <span className="text-[10px] text-blue-600 font-semibold">
                            {cust.totalOrders || 5} Orders Placed
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        {/* Seller Follows Customer Button */}
                        <button
                          onClick={() => sellerFollowCustomer(activeCommunity.sellerId, cust.id)}
                          className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition flex items-center gap-1 cursor-pointer ${
                            isFollowedBySeller
                              ? 'bg-amber-100 text-amber-900 border border-amber-300'
                              : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          {isFollowedBySeller ? (
                            <>
                              <UserCheck className="w-3 h-3 text-amber-600" />
                              <span>Following</span>
                            </>
                          ) : (
                            <>
                              <UserPlus className="w-3 h-3" />
                              <span>Follow</span>
                            </>
                          )}
                        </button>

                        {/* Seller Direct Message Customer */}
                        <button
                          onClick={() => {
                            startSellerToCustomerChat(activeCommunity.sellerId, cust.id);
                            onClose();
                          }}
                          className="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[11px] font-bold flex items-center gap-1 transition cursor-pointer"
                        >
                          <MessageSquare className="w-3 h-3" />
                          <span>Message</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Communities Directory Grid (If all is selected) */}
          {selectedSellerId === 'all' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                  <Store className="w-4 h-4 text-blue-600" />
                  Explore Hyperlocal Store Communities & Neighborhood Sellers
                </h3>
                <span className="text-xs text-slate-500">
                  {storeCommunities.length} Active Verified Merchant Circles
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredCommunities.map((com) => {
                  const isMember = com.memberUserIds.includes(currentUserId);
                  const isFollowing = isCustomerFollowingActiveSeller(com.sellerId);
                  const sellerInfo = sellers.find((s) => s.id === com.sellerId);

                  return (
                    <div
                      key={com.sellerId}
                      className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs hover:border-slate-300 transition flex flex-col justify-between space-y-3"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={com.avatarUrl}
                            alt={com.storeName}
                            className="w-12 h-12 rounded-xl object-cover border border-slate-200 shadow-xs"
                          />
                          <div>
                            <div className="flex items-center gap-1">
                              <h4 className="font-extrabold text-xs text-slate-900 line-clamp-1">
                                {com.storeName}
                              </h4>
                              <ShieldCheck className="w-3.5 h-3.5 text-blue-500" />
                            </div>
                            <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                              {com.tagline}
                            </p>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-[10px] font-bold text-blue-600">
                                {com.membersCount.toLocaleString()} Members
                              </span>
                              <span className="text-slate-300">•</span>
                              <span className="text-[10px] text-slate-500 flex items-center gap-0.5">
                                <MapPin className="w-2.5 h-2.5 text-rose-500" />
                                {sellerInfo?.warehouseAddress?.street || 'Shop #14, Rajwada, Indore'}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-col gap-1 shrink-0">
                          <button
                            onClick={() => toggleFollowSeller(com.sellerId)}
                            className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold transition cursor-pointer ${
                              isFollowing
                                ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                            }`}
                          >
                            {isFollowing ? '★ Following' : '+ Follow'}
                          </button>
                          <button
                            onClick={() => joinOrLeaveStoreCommunity(com.sellerId)}
                            className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold transition cursor-pointer ${
                              isMember
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : 'bg-blue-600 hover:bg-blue-700 text-white'
                            }`}
                          >
                            {isMember ? 'Joined' : 'Join'}
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
                        <button
                          onClick={() => setSelectedSellerId(com.sellerId)}
                          className="text-blue-600 hover:underline font-bold text-xs"
                        >
                          View Community Feed & Reels &rarr;
                        </button>

                        <button
                          onClick={() => {
                            openStoreChat(com.sellerId);
                            onClose();
                          }}
                          className="text-amber-800 font-extrabold text-xs flex items-center gap-1 hover:text-amber-950 cursor-pointer"
                        >
                          <MessageSquare className="w-3.5 h-3.5 text-amber-600" />
                          Chat & Bargain
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Community Post & Video Reel Feed */}
          {activeTab !== 'members' && (
            <div className="space-y-4 pt-2">
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-orange-500" />
                  {activeTab === 'reels' ? 'Store Video Reels & Live Demos' : 'Broadcasts, Video Reels & Member Deals'}
                </h3>
                <span className="text-xs text-slate-500">{filteredPosts.length} Posts & Reels</span>
              </div>

              {filteredPosts.map((post) => {
                const isLiked = post.likedByUserIds.includes(currentUserId);
                const postProducts = products.filter((p) =>
                  post.featuredProductIds?.includes(p.id)
                );
                const isReel = post.mediaType === 'reel' || post.mediaType === 'video';

                return (
                  <div
                    key={post.id}
                    className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4"
                  >
                    {/* Post Author Header */}
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={post.storeAvatar}
                          alt={post.storeName}
                          className="w-10 h-10 rounded-full object-cover border border-slate-200"
                        />
                        <div>
                          <div className="flex items-center gap-1.5">
                            <h4 className="font-extrabold text-xs text-slate-900">
                              {post.storeName}
                            </h4>
                            <ShieldCheck className="w-3.5 h-3.5 text-blue-500" />
                            {isReel && (
                              <span className="bg-purple-100 text-purple-800 text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1">
                                <Film className="w-2.5 h-2.5" /> Video Reel
                              </span>
                            )}
                            {post.pinned && (
                              <span className="bg-amber-100 text-amber-800 text-[10px] font-extrabold px-1.5 py-0.2 rounded-md flex items-center gap-0.5">
                                <Pin className="w-2.5 h-2.5" /> Pinned
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-400">
                            {new Date(post.createdAt).toLocaleDateString(undefined, {
                              month: 'short',
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>
                      </div>

                      {post.discountBadge && (
                        <span className="bg-rose-50 text-rose-700 border border-rose-200 text-[10px] font-black uppercase px-2.5 py-1 rounded-full flex items-center gap-1">
                          <Tag className="w-3 h-3 text-rose-500" />
                          {post.discountBadge}
                        </span>
                      )}
                    </div>

                    {/* Post Content */}
                    <div className="space-y-2">
                      <h3 className="font-extrabold text-sm text-slate-900">{post.title}</h3>
                      <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">
                        {post.content}
                      </p>
                    </div>

                    {/* Post Media (Image or Interactive Video Reel) */}
                    {post.mediaUrl && (
                      <div className="relative rounded-2xl overflow-hidden max-h-80 border border-slate-200 bg-white group">
                        <img
                          src={post.mediaUrl}
                          alt={post.title}
                          className={`w-full h-full object-cover ${isReel ? 'opacity-90' : ''}`}
                        />
                        {isReel && (
                          <div 
                            onClick={() => setPlayingVideoUrl(post.mediaUrl)}
                            className="absolute inset-0 bg-white/40 hover:bg-white/20 transition flex flex-col items-center justify-center cursor-pointer"
                          >
                            <div className="w-14 h-14 bg-white/90 hover:bg-white text-slate-900 rounded-full flex items-center justify-center shadow-lg transition transform hover:scale-110">
                              <Play className="w-7 h-7 fill-slate-900 translate-x-0.5" />
                            </div>
                            <span className="mt-2 text-xs font-bold text-white bg-slate-900/80 px-3 py-1 rounded-full backdrop-blur-xs">
                              Click to Watch Store Reel & Demo 🎥
                            </span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Embedded Tagged Store Products Section */}
                    {postProducts.length > 0 && (
                      <div className="bg-slate-50/80 border border-slate-200/80 rounded-2xl p-3.5 space-y-2.5">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-black text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                            <ShoppingBag className="w-3.5 h-3.5 text-blue-600" />
                            Featured Products in this Video / Broadcast
                          </span>
                          <span className="text-[10px] text-slate-500 font-bold">
                            Direct from {post.storeName}
                          </span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          {postProducts.map((p) => (
                            <div
                              key={p.id}
                              className="bg-white p-3 rounded-xl border border-slate-200 flex items-center justify-between gap-3 shadow-2xs"
                            >
                              <div className="flex items-center gap-2.5 min-w-0">
                                <img
                                  src={p.images?.[0] || p.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200'}
                                  alt={p.name}
                                  className="w-12 h-12 rounded-lg object-cover border border-slate-100 shrink-0"
                                />
                                <div className="min-w-0">
                                  <h5 className="font-bold text-xs text-slate-900 truncate">
                                    {p.name}
                                  </h5>
                                  <div className="flex items-center gap-2 mt-0.5">
                                    <span className="font-black text-xs text-slate-900">
                                      ₹{p.price}
                                    </span>
                                    {p.mrp > p.price && (
                                      <span className="text-[10px] text-slate-400 line-through">
                                        ₹{p.mrp}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </div>

                              <div className="flex flex-col gap-1 shrink-0">
                                <button
                                  onClick={() => handleBuyFeaturedProduct(p)}
                                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-black shadow-2xs transition cursor-pointer"
                                >
                                  Buy Deal
                                </button>
                                <button
                                  onClick={() => {
                                    openStoreChat(post.sellerId, p);
                                    onClose();
                                  }}
                                  className="px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 rounded-lg text-[10px] font-extrabold flex items-center justify-center gap-1 transition cursor-pointer"
                                >
                                  <Tag className="w-2.5 h-2.5" />
                                  Bargain
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Post Footer: Likes, Comments, Chat CTA */}
                    <div className="pt-2 flex items-center justify-between border-t border-slate-100 text-xs">
                      <div className="flex items-center gap-4">
                        {/* Like Button */}
                        <button
                          onClick={() => likeCommunityPost(post.id)}
                          className={`flex items-center gap-1.5 font-bold transition cursor-pointer ${
                            isLiked ? 'text-rose-600' : 'text-slate-500 hover:text-rose-600'
                          }`}
                        >
                          <Heart
                            className={`w-4 h-4 ${
                              isLiked ? 'fill-rose-600 text-rose-600' : ''
                            }`}
                          />
                          <span>{post.likesCount}</span>
                        </button>

                        {/* Comments Count */}
                        <span className="flex items-center gap-1.5 text-slate-500 font-bold">
                          <MessageSquare className="w-4 h-4 text-slate-400" />
                          <span>{post.commentsCount} Comments</span>
                        </span>
                      </div>

                      {/* Chat with Store button */}
                      <button
                        onClick={() => {
                          openStoreChat(post.sellerId);
                          onClose();
                        }}
                        className="text-amber-800 hover:text-amber-950 font-black flex items-center gap-1 cursor-pointer"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-amber-600" />
                        <span>Chat & Bargain with {post.storeName}</span>
                      </button>
                    </div>

                    {/* Comments Thread */}
                    {post?.comments && post.comments.length > 0 && (
                      <div className="space-y-2 pt-2 border-t border-slate-100 bg-slate-50/50 p-3 rounded-xl">
                        {(post.comments || []).map((c) => (
                          <div key={c.id} className="text-xs flex items-start gap-2">
                            <img
                              src={
                                c.userAvatar ||
                                'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'
                              }
                              alt={c.userName}
                              className="w-6 h-6 rounded-full object-cover mt-0.5"
                            />
                            <div className="flex-1 bg-white p-2 rounded-xl border border-slate-200">
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-[11px] text-slate-800">
                                  {c.userName}
                                </span>
                                <span className="text-[9px] text-slate-400">
                                  {new Date(c.timestamp).toLocaleTimeString([], {
                                    hour: '2-digit',
                                    minute: '2-digit',
                                  })}
                                </span>
                              </div>
                              <p className="text-slate-700 text-[11px] mt-0.5">{c.text}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Add Comment Input */}
                    <div className="flex items-center gap-2 pt-1">
                      <input
                        type="text"
                        value={newCommentText[post.id] || ''}
                        onChange={(e) =>
                          setNewCommentText({
                            ...newCommentText,
                            [post.id]: e.target.value,
                          })
                        }
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && (newCommentText[post.id] || '').trim()) {
                            addCommunityPostComment(post.id, newCommentText[post.id]);
                            setNewCommentText({ ...newCommentText, [post.id]: '' });
                          }
                        }}
                        placeholder="Write a public comment or bargain query..."
                        className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-xs text-slate-900 focus:outline-none focus:border-blue-500"
                      />
                      <button
                        onClick={() => {
                          if ((newCommentText[post.id] || '').trim()) {
                            addCommunityPostComment(post.id, newCommentText[post.id]);
                            setNewCommentText({ ...newCommentText, [post.id]: '' });
                          }
                        }}
                        className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition cursor-pointer"
                      >
                        Post
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Video Reel Playback Modal */}
        {playingVideoUrl && (
          <div className="fixed inset-0 z-70 bg-white/90 flex items-center justify-center p-4">
            <div className="bg-slate-900 rounded-3xl p-4 max-w-lg w-full space-y-4 shadow-2xl border border-slate-700 relative text-white">
              <button
                onClick={() => setPlayingVideoUrl(null)}
                className="absolute top-4 right-4 p-2 text-slate-300 hover:text-white bg-white/10 hover:bg-white/20 rounded-full transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
              <h3 className="font-bold text-sm flex items-center gap-2">
                <Film className="w-4 h-4 text-purple-400" />
                Live Store Demonstration & Video Reel
              </h3>
              <div className="rounded-2xl overflow-hidden bg-slate-100 aspect-video flex items-center justify-center relative">
                <img
                  src={playingVideoUrl}
                  alt="Video Player Demo"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-transparent flex items-end p-4">
                  <div className="space-y-1">
                    <span className="bg-rose-600 text-white text-[10px] font-black px-2 py-0.5 rounded-md">LIVE STORE REEL</span>
                    <p className="text-xs font-bold text-white">Unboxing & Handloom Cotton Quality Inspection</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between pt-2">
                <span className="text-xs text-slate-400">Streamed from Shop #14 Rajwada Main Market</span>
                <button
                  onClick={() => {
                    setPlayingVideoUrl(null);
                    if (activeCommunity) {
                      openStoreChat(activeCommunity.sellerId);
                      onClose();
                    }
                  }}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-800 rounded-xl text-xs font-black"
                >
                  Chat & Bargain Now
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal: Create Community Post / Reel (Seller Tool) */}
        {isCreatePostOpen && (
          <div className="fixed inset-0 z-60 bg-slate-900/70 flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <h3 className="font-black text-base text-slate-900 flex items-center gap-2">
                  <Plus className="w-5 h-5 text-blue-600" />
                  Publish Video Reel or Community Post
                </h3>
                <button
                  onClick={() => setIsCreatePostOpen(false)}
                  className="p-1 rounded-lg hover:bg-slate-100"
                >
                  <X className="w-5 h-5 text-slate-500" />
                </button>
              </div>

              <form onSubmit={handlePublishPost} className="space-y-3.5 text-xs">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Media Format:</label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setPostMediaType('image')}
                      className={`p-2 rounded-xl font-bold border flex items-center justify-center gap-1.5 transition ${
                        postMediaType === 'image'
                          ? 'bg-blue-50 border-blue-500 text-blue-900'
                          : 'bg-white border-slate-200 text-slate-600'
                      }`}
                    >
                      <ImageIcon className="w-3.5 h-3.5" />
                      Image Post
                    </button>
                    <button
                      type="button"
                      onClick={() => setPostMediaType('reel')}
                      className={`p-2 rounded-xl font-bold border flex items-center justify-center gap-1.5 transition ${
                        postMediaType === 'reel'
                          ? 'bg-purple-50 border-purple-500 text-purple-900'
                          : 'bg-white border-slate-200 text-slate-600'
                      }`}
                    >
                      <Film className="w-3.5 h-3.5" />
                      Short Reel
                    </button>
                    <button
                      type="button"
                      onClick={() => setPostMediaType('video')}
                      className={`p-2 rounded-xl font-bold border flex items-center justify-center gap-1.5 transition ${
                        postMediaType === 'video'
                          ? 'bg-amber-50 border-amber-500 text-amber-900'
                          : 'bg-white border-slate-200 text-slate-600'
                      }`}
                    >
                      <Video className="w-3.5 h-3.5" />
                      Video Demo
                    </button>
                  </div>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Headline:</label>
                  <input
                    type="text"
                    value={postTitle}
                    onChange={(e) => setPostTitle(e.target.value)}
                    placeholder="e.g. 🎥 Store Reel: Fresh Handloom Cotton Lot from ₹50!"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900"
                    required
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Description & Details:</label>
                  <textarea
                    value={postContent}
                    onChange={(e) => setPostContent(e.target.value)}
                    rows={3}
                    placeholder="Share product specs, unboxing video notes, or bargain details..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 leading-relaxed"
                    required
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Media / Video URL:</label>
                  <input
                    type="text"
                    value={postMediaUrl}
                    onChange={(e) => setPostMediaUrl(e.target.value)}
                    placeholder="https://images.unsplash.com/photo-..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Discount Badge (Optional):</label>
                  <input
                    type="text"
                    value={postDiscountBadge}
                    onChange={(e) => setPostDiscountBadge(e.target.value)}
                    placeholder="e.g. OPEN FOR DIRECT BARGAINING (FROM ₹50)"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-rose-700"
                  />
                </div>

                {/* Tag Products from Inventory */}
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    Tag Products from Store Catalog:
                  </label>
                  <div className="space-y-1.5 max-h-36 overflow-y-auto p-2 bg-slate-50 border border-slate-200 rounded-xl">
                    {products.map((p) => {
                      const isSelected = selectedProductIds.includes(p.id);
                      return (
                        <div
                          key={p.id}
                          onClick={() => {
                            if (isSelected) {
                              setSelectedProductIds(selectedProductIds.filter((id) => id !== p.id));
                            } else {
                              setSelectedProductIds([...selectedProductIds, p.id]);
                            }
                          }}
                          className={`p-2 rounded-lg border flex items-center justify-between cursor-pointer transition ${
                            isSelected
                              ? 'bg-blue-50 border-blue-500 text-blue-950 font-bold'
                              : 'bg-white border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          <span className="truncate">{p.name}</span>
                          <span className="font-black text-emerald-700">₹{p.price}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsCreatePostOpen(false)}
                    className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-black shadow-sm"
                  >
                    Publish Post / Reel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal: Create Store Community Wizard (For Sellers) */}
        {isCreateCommunityOpen && (
          <div className="fixed inset-0 z-60 bg-slate-900/70 flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl border border-slate-200">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <h3 className="font-black text-base text-slate-900 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-amber-500" />
                  Launch Store Community Circle
                </h3>
                <button
                  onClick={() => setIsCreateCommunityOpen(false)}
                  className="p-1 rounded-lg hover:bg-slate-100"
                >
                  <X className="w-5 h-5 text-slate-500" />
                </button>
              </div>

              <form onSubmit={handleCreateCommunitySubmit} className="space-y-3.5 text-xs">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Store Name:</label>
                  <input
                    type="text"
                    value={currentSeller.storeName}
                    disabled
                    className="w-full p-2.5 bg-slate-100 border border-slate-200 rounded-xl font-bold text-slate-600"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Community Tagline / Headline:</label>
                  <input
                    type="text"
                    value={communityTagline}
                    onChange={(e) => setCommunityTagline(e.target.value)}
                    placeholder="e.g. Neighborhood Grocery, Handloom & Daily Essentials Hub 🏪✨"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900"
                    required
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Topic Tags (comma-separated):</label>
                  <input
                    type="text"
                    value={communityTopicsInput}
                    onChange={(e) => setCommunityTopicsInput(e.target.value)}
                    placeholder="Handloom Hankies, Live Video Bargaining, 30-Min Delivery"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsCreateCommunityOpen(false)}
                    className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-black shadow-sm"
                  >
                    Create Circle
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

