import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Truck,
  PackageCheck,
  MapPin,
  Clock,
  CheckCircle2,
  AlertCircle,
  PhoneCall,
  RotateCcw,
  FileText,
  ExternalLink,
  ShieldCheck,
  Navigation,
  Store,
  Copy,
} from 'lucide-react';
import { Order } from '../../types';

export const OrderTrackingModal: React.FC = () => {
  const {
    activeTrackingOrder,
    setActiveTrackingOrder,
    submitReturnRequest,
    openLiveMapForOrder,
    viewOrderInvoice,
    setDeviceMode,
    showToast,
  } = useApp();

  const [isReturnModalOpen, setIsReturnModalOpen] = useState(false);
  const [returnType, setReturnType] = useState<'Exchange' | 'Refund'>('Exchange');
  const [returnReason, setReturnReason] = useState('Size is too small, need one size up');
  const [exchangeSize, setExchangeSize] = useState('L');
  const [selectedProductIndex, setSelectedProductIndex] = useState(0);

  if (!activeTrackingOrder) return null;

  const order: Order = activeTrackingOrder;
  const currentStatus = order.status;
  const deliveryOtp = order.deliveryOtp || '8492';

  const copyOtpToClipboard = () => {
    navigator.clipboard.writeText(deliveryOtp);
    showToast(`Copied Handover OTP (${deliveryOtp}) to clipboard`);
  };

  const steps = [
    { title: 'Order Placed', desc: 'Received and verified', icon: PackageCheck },
    { title: 'Packed & Dispatched', desc: 'Securely packed at Warehouse', icon: PackageCheck },
    { title: 'In Transit', desc: order.courierName ? `Dispatched via ${order.courierName}` : 'Express Logistics', icon: Truck },
    { title: 'Out for Delivery', desc: 'Delivery partner on the way', icon: MapPin },
    { title: 'Delivered', desc: `Expected by ${order.estimatedDelivery}`, icon: CheckCircle2 },
  ];

  const getStepProgressIndex = (status: Order['status']) => {
    switch (status) {
      case 'Pending':
      case 'Confirmed':
        return 0;
      case 'Packed':
        return 1;
      case 'Shipped':
        return 2;
      case 'Out for delivery':
        return 3;
      case 'Delivered':
        return 4;
      case 'Returned':
      case 'Refunded':
        return 4;
      default:
        return 0;
    }
  };

  const activeIndex = getStepProgressIndex(currentStatus);

  const handleCreateReturn = async (e: React.FormEvent) => {
    e.preventDefault();
    const item = order?.items?.[selectedProductIndex] || order?.items?.[0];
    if (!item) return;

    await submitReturnRequest({
      orderId: order.id,
      orderNumber: order.orderNumber,
      productId: item.productId,
      productName: item.productName,
      productImage: item.image,
      reason: returnReason,
      type: returnType,
      requestedExchangeSize: returnType === 'Exchange' ? exchangeSize : undefined,
    });

    setIsReturnModalOpen(false);
    showToast(`Return/Exchange request submitted for ${item.productName}`);
  };

  return (
    <div
      id="order-tracking-modal-overlay"
      className="fixed inset-0 z-50 bg-white/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fade-in overflow-y-auto"
    >
      <div
        id="order-tracking-modal-card"
        className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm sm:text-base">Order #{order.orderNumber}</h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300">
                  {order.source}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Placed on {new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveTrackingOrder(null)}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          {/* Status highlight banner */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
                Current Shipment Status
              </span>
              <h4 className="text-base font-extrabold text-slate-900 dark:text-white">
                {currentStatus === 'Delivered'
                  ? 'Delivered Successfully'
                  : currentStatus === 'Cancelled'
                  ? 'Order Cancelled'
                  : currentStatus === 'Returned'
                  ? 'Return Completed'
                  : `In Transit: Estimated by ${order.estimatedDelivery}`}
              </h4>
              {order.courierName && (
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                  Courier: <strong>{order.courierName}</strong> &bull; AWB: <span className="font-mono">{order.trackingNumber}</span>
                </p>
              )}
            </div>

            {order.returnStatus && order.returnStatus !== 'None' && (
              <span className="px-3 py-1 bg-purple-500/20 text-purple-700 dark:text-purple-300 font-bold rounded-lg text-xs border border-purple-500/30">
                Return: {order.returnStatus}
              </span>
            )}
          </div>

          {/* Secure Handover OTP Card */}
          {currentStatus !== 'Delivered' && currentStatus !== 'Cancelled' && currentStatus !== 'Returned' && (
            <div className="p-4 rounded-xl bg-slate-900 text-white border border-amber-500/30 shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-black">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-bold tracking-widest text-amber-400">
                      Doorstep Verification OTP
                    </span>
                    <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded font-mono">
                      CONFIDENTIAL
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">
                    Share this 4-digit code with the Delivery Partner upon arrival
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-start">
                <div className="px-4 py-2 bg-slate-800 border border-amber-500/40 rounded-xl flex items-center gap-2">
                  <span className="font-mono font-black text-lg tracking-widest text-amber-400">
                    {deliveryOtp}
                  </span>
                  <button
                    onClick={copyOtpToClipboard}
                    className="p-1 hover:text-amber-400 text-slate-400 transition-colors"
                    title="Copy OTP"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Interactive Omnichannel Action Hub */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              onClick={() => {
                setActiveTrackingOrder(null);
                openLiveMapForOrder(order);
              }}
              className="p-2.5 rounded-xl bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30 text-blue-700 dark:text-blue-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>Live GPS Map</span>
            </button>

            <button
              onClick={() => {
                setActiveTrackingOrder(null);
                viewOrderInvoice(order);
              }}
              className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
            >
              <FileText className="w-3.5 h-3.5 text-amber-600" />
              <span>GST Tax Invoice</span>
            </button>

            <button
              onClick={() => {
                setActiveTrackingOrder(null);
                setDeviceMode('driver');
                showToast(`🚚 Switched to Driver Partner App for Order #${order.orderNumber}`);
              }}
              className="p-2.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
            >
              <Truck className="w-3.5 h-3.5" />
              <span>Driver Partner</span>
            </button>

            <button
              onClick={() => {
                setActiveTrackingOrder(null);
                setDeviceMode('seller');
                showToast(`🏪 Switched to Seller Central for Order #${order.orderNumber}`);
              }}
              className="p-2.5 rounded-xl bg-orange-500/10 hover:bg-orange-500/20 border border-orange-500/30 text-orange-700 dark:text-orange-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
            >
              <Store className="w-3.5 h-3.5" />
              <span>Seller Central</span>
            </button>
          </div>

          {/* Stepper tracking visualization */}
          <div className="space-y-4">
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-500">
              Live Transit Milestones
            </h4>
            <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200 dark:before:bg-slate-800">
              {steps.map((st, i) => {
                const isDone = i <= activeIndex;
                const isCurrent = i === activeIndex;
                const IconComponent = st.icon;

                return (
                  <div key={i} className="relative flex items-start gap-3.5">
                    <div
                      className={`absolute -left-6 top-0.5 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ring-4 ring-white dark:ring-slate-900 ${
                        isDone
                          ? isCurrent
                            ? 'bg-amber-500 text-white animate-pulse'
                            : 'bg-emerald-500 text-white'
                          : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                      }`}
                    >
                      {isDone ? '✓' : i + 1}
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h5
                          className={`text-xs font-bold ${
                            isCurrent
                              ? 'text-amber-600 dark:text-amber-400'
                              : isDone
                              ? 'text-slate-900 dark:text-white'
                              : 'text-slate-400'
                          }`}
                        >
                          {st.title}
                        </h5>
                        {isCurrent && (
                          <span className="text-[10px] bg-amber-500/20 text-amber-700 dark:text-amber-300 px-2 py-0.5 rounded font-semibold">
                            Active Step
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        {st.desc}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Ordered items summary */}
          <div className="space-y-3 pt-3 border-t border-slate-200 dark:border-slate-800">
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-500">
              Package Contents ({order?.items?.length || 0} Products)
            </h4>
            <div className="space-y-2.5">
              {(order?.items || []).map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700"
                >
                  <img
                    src={item.image}
                    alt={item.productName}
                    className="w-12 h-14 object-cover rounded-lg"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {item.productName}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Color: {item.color} &bull; Size: {item.size} &bull; Qty: {item.quantity}
                    </p>
                    <p className="text-xs font-bold text-slate-800 dark:text-slate-200 mt-0.5">
                      ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Delivery & Billing info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
            <div>
              <span className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                📍 Delivery Address
              </span>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                <strong>{order.shippingAddress.fullName}</strong> ({order.shippingAddress.phone})
                <br />
                {order.shippingAddress.street}
                <br />
                {order.shippingAddress.city}, {order.shippingAddress.state} - {order.shippingAddress.pincode}
              </p>
            </div>
            <div>
              <span className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                💳 Payment Details
              </span>
              <p className="text-slate-600 dark:text-slate-400 space-y-1">
                <span>Method: <strong>{order.paymentMethod}</strong></span>
                <br />
                <span>Status: <strong className="text-emerald-600">{order.paymentStatus}</strong></span>
                <br />
                <span>Total: <strong>₹{order.totalAmount.toLocaleString('en-IN')}</strong></span>
              </p>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-100 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
          {order.status === 'Delivered' ? (
            <button
              onClick={() => setIsReturnModalOpen(true)}
              className="bg-slate-900 dark:bg-slate-700 hover:bg-slate-800 text-white font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Easy Return or Exchange</span>
            </button>
          ) : (
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <Clock className="w-4 h-4 text-amber-500" />
              <span>Updates dispatched every 4 hours</span>
            </div>
          )}

          <button
            onClick={() => setActiveTrackingOrder(null)}
            className="bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-800 dark:text-slate-200 font-bold px-4 py-2.5 rounded-xl text-xs"
          >
            Close
          </button>
        </div>

        {/* Sub-modal: Return / Exchange Request Form */}
        {isReturnModalOpen && (
          <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 animate-scale-in">
              <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <RotateCcw className="w-4 h-4 text-amber-500" />
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                    Antifly 7-Day Hassle-Free Return / Exchange
                  </h4>
                </div>
                <button onClick={() => setIsReturnModalOpen(false)}>
                  <X className="w-4 h-4 text-slate-400 hover:text-slate-600" />
                </button>
              </div>

              <form onSubmit={handleCreateReturn} className="space-y-3.5 text-xs">
                <div>
                  <label className="block text-slate-500 mb-1 font-semibold">Select Request Type</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setReturnType('Exchange')}
                      className={`p-2.5 rounded-xl font-bold border transition-all ${
                        returnType === 'Exchange'
                          ? 'bg-amber-500 text-slate-800 border-amber-500'
                          : 'border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      Exchange Size/Color
                    </button>
                    <button
                      type="button"
                      onClick={() => setReturnType('Refund')}
                      className={`p-2.5 rounded-xl font-bold border transition-all ${
                        returnType === 'Refund'
                          ? 'bg-amber-500 text-slate-800 border-amber-500'
                          : 'border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      Full Refund to Bank/UPI
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-500 mb-1 font-semibold">Select Item</label>
                  <select
                    value={selectedProductIndex}
                    onChange={(e) => setSelectedProductIndex(Number(e.target.value))}
                    className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs"
                  >
                    {order.items.map((item, i) => (
                      <option key={i} value={i}>
                        {item.productName} ({item.size}, {item.color})
                      </option>
                    ))}
                  </select>
                </div>

                {returnType === 'Exchange' && (
                  <div>
                    <label className="block text-slate-500 mb-1 font-semibold">Desired Replacement Size</label>
                    <div className="flex gap-2">
                      {['S', 'M', 'L', 'XL', 'XXL'].map((sz) => (
                        <button
                          key={sz}
                          type="button"
                          onClick={() => setExchangeSize(sz)}
                          className={`w-10 h-8 rounded-lg font-bold border text-xs ${
                            exchangeSize === sz
                              ? 'bg-amber-500 text-slate-800 border-amber-500'
                              : 'border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {sz}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-slate-500 mb-1 font-semibold">Reason for Request</label>
                  <textarea
                    rows={3}
                    value={returnReason}
                    onChange={(e) => setReturnReason(e.target.value)}
                    placeholder="Tell us why you are returning or exchanging..."
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="submit"
                    className="flex-1 bg-amber-500 hover:bg-amber-600 text-slate-800 font-bold py-2.5 rounded-xl"
                  >
                    Submit Request
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsReturnModalOpen(false)}
                    className="px-4 bg-slate-200 dark:bg-slate-700 font-semibold rounded-xl text-slate-700 dark:text-slate-300"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
