import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Mic,
  MicOff,
  Volume2,
  Languages,
  Sparkles,
  ArrowRight,
  ShoppingBag,
  Search,
  CheckCircle2,
  CornerDownRight,
  Globe,
  Radio,
  Share2,
} from 'lucide-react';
import { DEFAULT_VOICE_PRESETS } from '../../data/ecosystemData';
import { LanguageCode, MultilingualTranslationRecord } from '../../types';

export const MultilingualVoiceStudioModal: React.FC = () => {
  const {
    isMultilingualStudioOpen,
    setIsMultilingualStudioOpen,
    selectedLanguage,
    setSelectedLanguage,
    showToast,
    setSearchQuery,
    setSelectedCategorySlug,
    addToCart,
    products,
  } = useApp();

  const [activeLang, setActiveLang] = useState<LanguageCode>(selectedLanguage || 'hi');
  const [isListening, setIsListening] = useState(false);
  const [spokenText, setSpokenText] = useState('इंदौर के सबसे प्रसिद्ध महेश्वरी सिल्क सूट और पोहा-जलेबी खोजो');
  const [translatedText, setTranslatedText] = useState('Search for Indore\'s most famous Maheshwari silk suits and authentic Poha-Jalebi');
  const [detectedIntent, setDetectedIntent] = useState<'search' | 'cart' | 'bargain' | 'order_status'>('search');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [history, setHistory] = useState<MultilingualTranslationRecord[]>([
    {
      id: 'tr-1',
      sourceLang: 'hi',
      targetLang: 'en',
      sourceText: 'इंदौर के सबसे बेस्ट पोहा-जलेबी ऑर्डर करो',
      translatedText: 'Order top-rated authentic Indore Poha-Jalebi combo',
      detectedIntent: 'cart',
      timestamp: '2m ago',
    },
    {
      id: 'tr-2',
      sourceLang: 'mr',
      targetLang: 'hi',
      sourceText: 'माझ्या ऑर्डरची सद्यस्थिती काय आहे?',
      translatedText: 'मेरी ऑर्डर की ताज़ा स्थिति क्या है?',
      detectedIntent: 'order_status',
      timestamp: '10m ago',
    },
  ]);

  const currentPreset = DEFAULT_VOICE_PRESETS?.find((p) => p.code === activeLang) || (DEFAULT_VOICE_PRESETS && DEFAULT_VOICE_PRESETS.length > 0 ? DEFAULT_VOICE_PRESETS?.[0] : null);

  const handleSelectPresetPhrase = (phrase?: string) => {
    if (!phrase) return;
    setSpokenText(phrase);

    // Dynamic translation mock based on selected language
    if (activeLang === 'hi') {
      setTranslatedText(`Found matching verified Indore merchants for: "${phrase}"`);
      setDetectedIntent(phrase.includes('ऑर्डर') ? 'cart' : 'search');
    } else if (activeLang === 'mr') {
      setTranslatedText(`मराठी व्हॉइस कमांड: "${phrase}" साठी उत्पादने लोड होत आहेत`);
      setDetectedIntent('search');
    } else if (activeLang === 'gu') {
      setTranslatedText(`ગુજરાતી વોઇસ શોધ: "${phrase}" ની શ્રેષ્ઠ ઑફર્સ`);
      setDetectedIntent('search');
    } else if (activeLang === 'ta') {
      setTranslatedText(`குரல் தேடல் முடிவுகள்: "${phrase}"`);
      setDetectedIntent('search');
    } else {
      setTranslatedText(`Executing Indian Vernacular AI Assistant query: "${phrase}"`);
      setDetectedIntent('search');
    }
  };

  const handleToggleListening = () => {
    if (isListening) {
      setIsListening(false);
      showToast('🎤 Voice recording paused');
    } else {
      setIsListening(true);
      showToast('🎙️ Listening in ' + (currentPreset?.name || 'Vernacular') + '... Speak clearly');
      setTimeout(() => {
        setIsListening(false);
        const phrases = currentPreset?.samplePhrases || ['Best sarees under 2000'];
        const randomPhrase = phrases[Math.floor(Math.random() * phrases.length)];
        handleSelectPresetPhrase(randomPhrase);
        showToast('✨ Voice AI processed vernacular speech successfully');
      }, 2500);
    }
  };

  const handleSpeakText = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.pitch = 1.0;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    } else {
      showToast('🔊 Audio synthesis active');
    }
  };

  const handleExecuteVoiceAction = () => {
    setSelectedLanguage(activeLang);

    if (detectedIntent === 'search' || detectedIntent === 'cart') {
      setSearchQuery(spokenText ? (spokenText.split(' ')?.[0] || 'silk') : 'silk');
      showToast(`🔍 Applied Vernacular Search: "${spokenText}"`);
    }

    const newRecord: MultilingualTranslationRecord = {
      id: `rec-${Date.now()}`,
      sourceLang: activeLang,
      targetLang: 'en',
      sourceText: spokenText,
      translatedText: translatedText,
      detectedIntent: detectedIntent,
      timestamp: 'Just now',
    };

    setHistory((prev) => [newRecord, ...prev]);
    setIsMultilingualStudioOpen(false);
  };

  if (!isMultilingualStudioOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-white/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-3xl overflow-hidden shadow-2xl relative text-slate-100 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-slate-800 bg-gradient-to-r from-red-950/40 via-slate-900 to-amber-950/40 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-br from-red-500 to-amber-500 rounded-2xl text-slate-800 shadow-lg shadow-amber-500/20">
              <Languages className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white">AI Vernacular Voice Studio</h2>
                <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                  12 Indian Languages
                </span>
              </div>
              <p className="text-xs text-slate-400">Real-time multilingual speech translation & smart voice actions</p>
            </div>
          </div>
          <button
            onClick={() => setIsMultilingualStudioOpen(false)}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 flex-1">
          
          {/* Language Selector Grid */}
          <div>
            <label className="block text-xs font-black uppercase tracking-wider text-slate-400 mb-2">
              Select Speaking Dialect / भाषा चुनें:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {DEFAULT_VOICE_PRESETS.map((preset) => (
                <button
                  key={preset.code}
                  onClick={() => {
                    setActiveLang(preset.code);
                    handleSelectPresetPhrase(preset.samplePhrases?.[0]);
                  }}
                  className={`p-2.5 rounded-2xl border text-left transition flex items-center gap-2 cursor-pointer ${
                    activeLang === preset.code
                      ? 'bg-amber-500/20 border-amber-400 text-white shadow-md shadow-amber-500/10'
                      : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:border-slate-500'
                  }`}
                >
                  <span className="text-lg">{preset.flag}</span>
                  <div className="min-w-0">
                    <div className="text-xs font-black truncate">{preset.name}</div>
                    <div className="text-[10px] text-slate-400 truncate">{preset.nativeName}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Interactive Microphone & Live Waveform Stage */}
          <div className="bg-white/90 border border-slate-800 rounded-3xl p-5 text-center relative overflow-hidden space-y-4">
            
            {/* Pulsing Waveform */}
            <div className="h-14 flex items-center justify-center gap-1">
              {[40, 65, 85, 30, 90, 45, 75, 100, 60, 80, 50, 95, 35, 70, 40].map((h, i) => (
                <div
                  key={i}
                  style={{
                    height: isListening ? `${h}%` : '15%',
                    transition: 'height 0.15s ease',
                  }}
                  className={`w-1.5 rounded-full ${
                    isListening ? 'bg-gradient-to-t from-red-500 via-amber-400 to-amber-200' : 'bg-slate-700'
                  }`}
                />
              ))}
            </div>

            {/* Mic Toggle Button */}
            <div className="flex justify-center">
              <button
                onClick={handleToggleListening}
                className={`p-5 rounded-full text-white shadow-2xl transition transform hover:scale-105 cursor-pointer ${
                  isListening
                    ? 'bg-red-600 animate-pulse ring-8 ring-red-600/30'
                    : 'bg-gradient-to-r from-red-600 to-amber-500 hover:from-red-500 hover:to-amber-400 ring-4 ring-amber-500/20'
                }`}
              >
                {isListening ? <Mic className="w-8 h-8 animate-spin" /> : <Mic className="w-8 h-8" />}
              </button>
            </div>
            <div className="text-xs font-bold text-slate-300">
              {isListening ? '🎙️ Listening to Indian Vernacular Audio...' : 'Tap microphone to speak or choose a sample below'}
            </div>

            {/* Spoken Text & Translation Box */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-left space-y-3">
              <div>
                <div className="text-[10px] uppercase tracking-wider font-black text-amber-400 flex items-center justify-between">
                  <span>Detected Speech ({currentPreset.name}):</span>
                  <button
                    onClick={() => handleSpeakText(spokenText)}
                    className="flex items-center gap-1 text-slate-300 hover:text-white"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>Play Audio</span>
                  </button>
                </div>
                <p className="text-sm font-semibold text-white mt-1 leading-relaxed">{spokenText}</p>
              </div>

              <div className="h-px bg-slate-800" />

              <div>
                <div className="text-[10px] uppercase tracking-wider font-black text-emerald-400 flex items-center justify-between">
                  <span>AI Real-time Translation:</span>
                  <span className="text-[10px] font-mono text-slate-400">Intent: {detectedIntent.toUpperCase()}</span>
                </div>
                <p className="text-sm font-semibold text-emerald-300 mt-1 leading-relaxed">{translatedText}</p>
              </div>
            </div>

            {/* Preset Sample Phrases */}
            <div className="text-left">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                Quick Sample Vernacular Prompts:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {currentPreset.samplePhrases.map((phrase, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSelectPresetPhrase(phrase)}
                    className="text-xs bg-slate-800/80 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-xl border border-slate-700 transition flex items-center gap-1"
                  >
                    <CornerDownRight className="w-3 h-3 text-amber-400" />
                    <span>{phrase}</span>
                  </button>
                ))}
              </div>
            </div>

          </div>

        </div>

        {/* Footer Action */}
        <div className="p-4 border-t border-slate-800 bg-white/60 flex items-center justify-between gap-3">
          <button
            onClick={() => handleSpeakText(spokenText)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 transition cursor-pointer"
          >
            <Volume2 className="w-4 h-4 text-amber-400" />
            <span>Hear Pronunciation</span>
          </button>

          <button
            onClick={handleExecuteVoiceAction}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-xs font-black text-slate-800 shadow-lg shadow-amber-500/20 transition hover:scale-105 cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>Execute Voice Command & Shop</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
