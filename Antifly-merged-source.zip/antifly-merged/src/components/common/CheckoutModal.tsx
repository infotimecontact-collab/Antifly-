import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  ShieldCheck,
  CreditCard,
  QrCode,
  Smartphone,
  Banknote,
  Truck,
  CheckCircle,
  ArrowRight,
  ArrowLeft,
  Lock,
  Tag,
  Sparkles,
  Navigation,
  Store,
  FileText,
  Copy,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { PaymentMethod, Order } from '../../types';

export const CheckoutModal: React.FC = () => {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    cart,
    clearCart,
    activeAppliedCoupon,
    placeOrder,
    currentCustomer,
    settings,
    deviceMode,
    setActiveTrackingOrder,
    appliedBankOffer,
    applyBankOffer,
    removeBankOffer,
    setIsBankOffersModalOpen,
    wiseOneSubscription,
    setIsWiseOneModalOpen,
    openLiveMapForOrder,
    setDeviceMode,
    showToast,
    viewOrderInvoice,
    currentSeller,
    calculateDistanceKm,
    calculateDeliveryFee,
    userLocation,
    userProfile,
  } = useApp();

  const [step, setStep] = useState<'address' | 'payment' | 'success'>('address');
  const [placedOrder, setPlacedOrder] = useState<Order | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Address form state
  const [selectedAddressIndex, setSelectedAddressIndex] = useState(0);
  const [useCustomAddress, setUseCustomAddress] = useState(false);
  const [formData, setFormData] = useState({
    fullName: currentCustomer?.name || 'Aarav Sharma',
    phone: currentCustomer?.phone || '+91 98765 43210',
    street: 'Flat 402, Lotus Tower, MG Road',
    apartment: 'Near Metro Station',
    city: userLocation.city || 'Indore',
    state: 'Madhya Pradesh',
    pincode: '452001',
    country: 'India',
    type: 'Home' as 'Home' | 'Work' | 'Other',
  });

  // Payment method state
  const [selectedPayment, setSelectedPayment] = useState<PaymentMethod>('Credit/Debit Card');
  const [upiId, setUpiId] = useState('aarav@okhdfcbank');
  const [cardDetails, setCardDetails] = useState({
    number: '4532 •••• •••• 8891',
    name: 'Aarav Sharma',
    expiry: '08/29',
    cvv: '•••',
  });

  if (!isCheckoutOpen) return null;

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const couponDiscountAmount = activeAppliedCoupon ? activeAppliedCoupon.discountAmount : 0;
  
  // Calculate Bank Card Instant Discount
  let bankDiscountAmount = 0;
  if (appliedBankOffer && subtotal >= appliedBankOffer.minOrderValue) {
    bankDiscountAmount = Math.min(
      appliedBankOffer.maxDiscount,
      Math.round((subtotal * appliedBankOffer.discountPercent) / 100)
    );
  }

  // Hyperlocal Distance & Tiered Delivery Fee Calculation
  const storeLat = currentSeller.lat || 22.7196;
  const storeLng = currentSeller.lng || 75.8577;
  const deliveryDistanceKm = calculateDistanceKm(userLocation.lat, userLocation.lng, storeLat, storeLng);

  // WiseOne VIP Discount & Free shipping vs Hyperlocal Tiered Delivery
  const isWiseOneFreeShipping = wiseOneSubscription.isActive;
  const computedDeliveryFee = calculateDeliveryFee(deliveryDistanceKm, subtotal);
  const shippingFee = isWiseOneFreeShipping || subtotal === 0 ? 0 : computedDeliveryFee;
  
  const totalDiscount = couponDiscountAmount + bankDiscountAmount;
  const gstAmount = Math.round(((subtotal - totalDiscount) * (settings.gstPercentage || 12)) / 100);
  const totalAmount = Math.max(0, subtotal - totalDiscount + shippingFee);

  const handleCompleteOrder = async () => {
    setIsProcessing(true);
    const orderAddress = useCustomAddress
      ? { ...formData, id: `addr-${Date.now()}`, isDefault: false }
      : currentCustomer?.addresses?.[selectedAddressIndex] || currentCustomer?.addresses?.[0] || {
          id: 'addr-default',
          ...formData,
          isDefault: true,
        };

    const source =
      deviceMode === 'mobile-android'
        ? 'Android App'
        : deviceMode === 'mobile-ios'
        ? 'iOS App'
        : 'Website';

    try {
      const order = await placeOrder({
        source,
        shippingAddress: orderAddress,
        items: cart.map((item) => ({
          productId: item.productId,
          variantId: item.variantId,
          productName: item.productName,
          brand: item.brand,
          color: item.color,
          size: item.size,
          price: item.price,
          mrp: item.mrp,
          quantity: item.quantity,
          image: item.image,
        })),
        subtotal,
        discount: totalDiscount,
        couponCode: activeAppliedCoupon?.code,
        tax: gstAmount,
        shippingFee,
        totalAmount,
        paymentMethod: selectedPayment,
        paymentStatus: selectedPayment === 'Cash on Delivery' ? 'Pending' : 'Paid',
      });

      setPlacedOrder(order);
      setStep('success');
      // Trigger festive celebration
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (e) {
        // Ignore in environments without canvas
      }
    } catch (err) {
      console.error('Failed to place order', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleClose = () => {
    setIsCheckoutOpen(false);
    setStep('address');
    setPlacedOrder(null);
  };

  return (
    <div
      id="checkout-modal-overlay"
      className="fixed inset-0 z-50 bg-white/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fade-in overflow-y-auto"
    >
      <div
        id="checkout-modal-card"
        className="bg-white dark:bg-slate-900 w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base leading-tight">
                {step === 'success' ? 'Order Confirmed!' : 'Secure Express Checkout'}
              </h3>
              <p className="text-[11px] text-slate-400">
                {step === 'success'
                  ? 'Thank you for shopping with Antifly'
                  : '256-Bit Encrypted & RBI Guideline Compliant'}
              </p>
            </div>
          </div>
          <button
            id="close-checkout-btn"
            onClick={handleClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stepper indicator if not success */}
        {step !== 'success' && (
          <div className="bg-slate-100 dark:bg-slate-800/60 px-6 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs font-semibold">
            <div
              className={`flex items-center gap-2 ${
                step === 'address' ? 'text-amber-600 dark:text-amber-400 font-bold' : 'text-emerald-600'
              }`}
            >
              <div
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                  step === 'address'
                    ? 'bg-amber-500 text-white font-bold'
                    : 'bg-emerald-500 text-white font-bold'
                }`}
              >
                1
              </div>
              <span>Delivery Address</span>
            </div>
            <div className="w-12 h-0.5 bg-slate-300 dark:bg-slate-700" />
            <div
              className={`flex items-center gap-2 ${
                step === 'payment'
                  ? 'text-amber-600 dark:text-amber-400 font-bold'
                  : 'text-slate-400 dark:text-slate-500'
              }`}
            >
              <div
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                  step === 'payment'
                    ? 'bg-amber-500 text-white font-bold'
                    : 'bg-slate-300 dark:bg-slate-700 text-slate-600 dark:text-slate-400 font-bold'
                }`}
              >
                2
              </div>
              <span>Payment Options</span>
            </div>
          </div>
        )}

        {/* Body content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {step === 'address' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Address Selection Column */}
              <div className="md:col-span-2 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                    Select Delivery Destination
                  </h4>
                  <span className="text-xs text-amber-600 dark:text-amber-400 font-medium">
                    ⚡ Free Pan-India Delivery on ₹999+
                  </span>
                </div>

                {/* Saved addresses */}
                <div className="space-y-3">
                  {currentCustomer?.addresses?.map((addr, idx) => (
                    <div
                      key={addr.id || idx}
                      onClick={() => {
                        setSelectedAddressIndex(idx);
                        setUseCustomAddress(false);
                      }}
                      className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                        !useCustomAddress && selectedAddressIndex === idx
                          ? 'border-amber-500 bg-amber-50/50 dark:bg-amber-950/20 ring-2 ring-amber-500/20'
                          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          <input
                            type="radio"
                            checked={!useCustomAddress && selectedAddressIndex === idx}
                            onChange={() => {
                              setSelectedAddressIndex(idx);
                              setUseCustomAddress(false);
                            }}
                            className="accent-amber-600"
                          />
                          <span className="font-bold text-xs text-slate-900 dark:text-white">
                            {addr.fullName}
                          </span>
                          <span className="px-2 py-0.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 text-[10px] rounded font-semibold uppercase">
                            {addr.type}
                          </span>
                        </div>
                        <span className="text-xs text-slate-500">{addr.phone}</span>
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 pl-5">
                        {addr.street}, {addr.apartment && `${addr.apartment}, `}
                        {addr.city}, {addr.state} - {addr.pincode}
                      </p>
                    </div>
                  ))}

                  {/* Option to use custom address */}
                  <div
                    onClick={() => setUseCustomAddress(true)}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                      useCustomAddress
                        ? 'border-amber-500 bg-amber-50/50 dark:bg-amber-950/20'
                        : 'border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <input
                        type="radio"
                        checked={useCustomAddress}
                        onChange={() => setUseCustomAddress(true)}
                        className="accent-amber-600"
                      />
                      <span className="font-bold text-xs text-slate-900 dark:text-white">
                        + Deliver to a Different Address
                      </span>
                    </div>

                    {useCustomAddress && (
                      <div className="grid grid-cols-2 gap-3 mt-3 pt-3 border-t border-slate-200 dark:border-slate-700 text-xs">
                        <div className="col-span-2 sm:col-span-1">
                          <label className="block text-slate-500 mb-1">Full Name</label>
                          <input
                            type="text"
                            value={formData.fullName}
                            onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                            className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                          />
                        </div>
                        <div className="col-span-2 sm:col-span-1">
                          <label className="block text-slate-500 mb-1">Mobile Number</label>
                          <input
                            type="text"
                            value={formData.phone}
                            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                            className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                          />
                        </div>
                        <div className="col-span-2">
                          <label className="block text-slate-500 mb-1">Flat, House no., Building, Street</label>
                          <input
                            type="text"
                            value={formData.street}
                            onChange={(e) => setFormData({ ...formData, street: e.target.value })}
                            className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-500 mb-1">City</label>
                          <input
                            type="text"
                            value={formData.city}
                            onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                            className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-500 mb-1">Pincode</label>
                          <input
                            type="text"
                            value={formData.pincode}
                            onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
                            className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Order Summary Column */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3 h-fit">
                <h4 className="font-bold text-xs uppercase tracking-wider text-slate-500">
                  Order Summary ({cart.length} Items)
                </h4>
                <div className="max-h-40 overflow-y-auto space-y-2 pr-1">
                  {cart.map((item) => (
                    <div key={item.id} className="flex items-center gap-2 text-xs">
                      <img
                        src={item.image}
                        alt={item.productName}
                        className="w-10 h-10 object-cover rounded-md"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-slate-900 dark:text-white truncate">
                          {item.productName}
                        </p>
                        <p className="text-[10px] text-slate-500">
                          Qty: {item.quantity} &bull; ₹{item.price.toLocaleString('en-IN')}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="pt-2 border-t border-slate-200 dark:border-slate-700 space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>₹{subtotal.toLocaleString('en-IN')}</span>
                  </div>
                  {couponDiscountAmount > 0 && (
                    <div className="flex justify-between text-emerald-600 font-semibold">
                      <span>Discount ({activeAppliedCoupon?.code})</span>
                      <span>-₹{couponDiscountAmount.toLocaleString('en-IN')}</span>
                    </div>
                  )}
                  {bankDiscountAmount > 0 && (
                    <div className="flex justify-between text-sky-600 font-semibold">
                      <span>Bank Offer ({appliedBankOffer?.bankName})</span>
                      <span>-₹{bankDiscountAmount.toLocaleString('en-IN')}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>Delivery Fee</span>
                    {isWiseOneFreeShipping ? (
                      <span className="font-bold text-amber-600">👑 FREE (WiseOne)</span>
                    ) : shippingFee === 0 ? (
                      <strong className="text-emerald-600">FREE</strong>
                    ) : (
                      `₹${shippingFee}`
                    )}
                  </div>
                  <div className="flex justify-between font-bold text-sm text-slate-900 dark:text-white pt-2 border-t border-slate-200 dark:border-slate-700">
                    <span>Grand Total</span>
                    <span>₹{totalAmount.toLocaleString('en-IN')}</span>
                  </div>
                </div>

                <button
                  id="proceed-to-payment-step-btn"
                  onClick={() => setStep('payment')}
                  className="w-full bg-slate-900 dark:bg-amber-500 hover:bg-slate-800 text-white dark:text-slate-800 font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 mt-3 shadow-md"
                >
                  <span>Continue to Payment</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {step === 'payment' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Payment Methods */}
              <div className="md:col-span-2 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                    Select Secure Payment Method
                  </h4>
                  <button
                    onClick={() => setIsBankOffersModalOpen(true)}
                    className="text-xs font-bold text-sky-600 hover:text-sky-700 flex items-center gap-1 cursor-pointer bg-sky-50 dark:bg-sky-950 px-2.5 py-1 rounded-lg border border-sky-200 dark:border-sky-800"
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>View All Bank Offers (10% Off) &gt;</span>
                  </button>
                </div>

                {/* Applied Bank Offer Banner */}
                {appliedBankOffer && (
                  <div className="p-3 rounded-xl bg-gradient-to-r from-sky-50 to-indigo-50 dark:from-sky-950/40 dark:to-indigo-950/40 border border-sky-200 dark:border-sky-800 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-sky-600 text-white font-black text-[10px]">
                        {appliedBankOffer.logoText}
                      </span>
                      <div>
                        <span className="font-bold text-slate-900 dark:text-white block">
                          {appliedBankOffer.bankName} 10% Instant Off Applied!
                        </span>
                        <span className="text-[11px] text-slate-500">
                          Saving ₹{bankDiscountAmount} on this order
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={removeBankOffer}
                      className="text-rose-600 font-bold hover:underline text-[11px]"
                    >
                      Remove
                    </button>
                  </div>
                )}

                <div className="space-y-3">
                  {/* UPI */}
                  <div
                    onClick={() => setSelectedPayment('UPI')}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      selectedPayment === 'UPI'
                        ? 'border-amber-500 bg-amber-50/50 dark:bg-amber-950/20 ring-2 ring-amber-500/20'
                        : 'border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-emerald-500/10 text-emerald-600 flex items-center justify-center font-bold">
                          <QrCode className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-bold text-xs text-slate-900 dark:text-white">
                            Instant UPI / QR Payment
                          </p>
                          <p className="text-[11px] text-slate-500">GPay, PhonePe, Paytm, CRED, BHIM</p>
                        </div>
                      </div>
                      <input
                        type="radio"
                        checked={selectedPayment === 'UPI'}
                        onChange={() => setSelectedPayment('UPI')}
                        className="accent-amber-600"
                      />
                    </div>

                    {selectedPayment === 'UPI' && (
                      <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700">
                        <label className="block text-[11px] text-slate-500 mb-1">Enter UPI ID</label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={upiId}
                            onChange={(e) => setUpiId(e.target.value)}
                            placeholder="username@bank"
                            className="flex-1 p-2 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-mono"
                          />
                          <button
                            type="button"
                            className="bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-2 rounded-lg text-xs font-semibold"
                          >
                            Verify & Pay
                          </button>
                        </div>
                        <p className="text-[10px] text-emerald-600 dark:text-emerald-400 mt-1 font-medium">
                          ✓ Instant 1-click verification enabled
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Credit/Debit Cards */}
                  <div
                    onClick={() => setSelectedPayment('Credit/Debit Card')}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      selectedPayment === 'Credit/Debit Card'
                        ? 'border-amber-500 bg-amber-50/50 dark:bg-amber-950/20 ring-2 ring-amber-500/20'
                        : 'border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-blue-500/10 text-blue-600 flex items-center justify-center font-bold">
                          <CreditCard className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-bold text-xs text-slate-900 dark:text-white">
                            Credit / Debit Cards
                          </p>
                          <p className="text-[11px] text-slate-500">Visa, Mastercard, RuPay, Amex</p>
                        </div>
                      </div>
                      <input
                        type="radio"
                        checked={selectedPayment === 'Credit/Debit Card'}
                        onChange={() => setSelectedPayment('Credit/Debit Card')}
                        className="accent-amber-600"
                      />
                    </div>

                    {selectedPayment === 'Credit/Debit Card' && (
                      <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700 grid grid-cols-2 gap-2 text-xs">
                        <div className="col-span-2">
                          <label className="block text-[11px] text-slate-500 mb-0.5">Card Number</label>
                          <input
                            type="text"
                            value={cardDetails.number}
                            onChange={(e) => setCardDetails({ ...cardDetails, number: e.target.value })}
                            className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-mono text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-500 mb-0.5">Valid Thru</label>
                          <input
                            type="text"
                            value={cardDetails.expiry}
                            onChange={(e) => setCardDetails({ ...cardDetails, expiry: e.target.value })}
                            className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-500 mb-0.5">CVV</label>
                          <input
                            type="password"
                            value={cardDetails.cvv}
                            onChange={(e) => setCardDetails({ ...cardDetails, cvv: e.target.value })}
                            className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Cash on Delivery */}
                  <div
                    onClick={() => setSelectedPayment('Cash on Delivery')}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      selectedPayment === 'Cash on Delivery'
                        ? 'border-amber-500 bg-amber-50/50 dark:bg-amber-950/20 ring-2 ring-amber-500/20'
                        : 'border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-amber-500/10 text-amber-600 flex items-center justify-center font-bold">
                          <Banknote className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-bold text-xs text-slate-900 dark:text-white">
                            Cash on Delivery (COD)
                          </p>
                          <p className="text-[11px] text-slate-500">Pay via cash or UPI at your doorstep</p>
                        </div>
                      </div>
                      <input
                        type="radio"
                        checked={selectedPayment === 'Cash on Delivery'}
                        onChange={() => setSelectedPayment('Cash on Delivery')}
                        className="accent-amber-600"
                      />
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setStep('address')}
                  className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 mt-2"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> Back to Delivery Address
                </button>
              </div>

              {/* Total Card & Final Pay Button */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3 h-fit">
                <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 p-2.5 rounded-lg border border-emerald-200 dark:border-emerald-800">
                  <Lock className="w-4 h-4" />
                  <span>Guaranteed Safe Checkout</span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                  <div className="flex justify-between">
                    <span>Items Total</span>
                    <span>₹{subtotal.toLocaleString('en-IN')}</span>
                  </div>
                  {couponDiscountAmount > 0 && (
                    <div className="flex justify-between text-emerald-600 font-semibold">
                      <span>Coupon Discount</span>
                      <span>-₹{couponDiscountAmount.toLocaleString('en-IN')}</span>
                    </div>
                  )}
                  {bankDiscountAmount > 0 && (
                    <div className="flex justify-between text-sky-600 dark:text-sky-400 font-semibold">
                      <span>{appliedBankOffer?.bankName} Card 10% Instant Off</span>
                      <span>-₹{bankDiscountAmount.toLocaleString('en-IN')}</span>
                    </div>
                  )}
                  <div className="flex justify-between items-center">
                    <div>
                      <span>Hyperlocal Delivery</span>
                      <span className="block text-[10px] text-slate-400">
                        📍 {deliveryDistanceKm.toFixed(1)} km from {currentSeller.storeName} ({currentSeller.warehouseAddress?.city || 'Indore'})
                      </span>
                    </div>
                    {isWiseOneFreeShipping ? (
                      <span className="font-bold text-amber-600 dark:text-amber-400 flex items-center gap-1">
                        👑 FREE (WiseOne VIP)
                      </span>
                    ) : shippingFee === 0 ? (
                      <span className="font-bold text-emerald-600">FREE (&lt;10km promo)</span>
                    ) : (
                      <span className="font-bold text-slate-900 dark:text-white">₹{shippingFee}</span>
                    )}
                  </div>
                  {deliveryDistanceKm > 10 && (
                    <div className="p-2 rounded bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 text-[10px] text-amber-700 dark:text-amber-300">
                      {deliveryDistanceKm <= 20
                        ? `🛵 10–20 km Distance Tier: Base ₹40 + ₹10/km for ${Math.round(deliveryDistanceKm - 10)} km`
                        : `⚠️ Long Distance (>20 km): Express out-of-zone delivery surcharge applied`}
                    </div>
                  )}
                  <div className="flex justify-between font-bold text-base text-slate-900 dark:text-white pt-2 border-t border-slate-200 dark:border-slate-700">
                    <span>Amount Payable</span>
                    <span>₹{totalAmount.toLocaleString('en-IN')}</span>
                  </div>
                </div>

                <button
                  id="confirm-place-order-btn"
                  onClick={handleCompleteOrder}
                  disabled={isProcessing}
                  className="w-full bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold py-3 px-4 rounded-xl text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-orange-600/20 disabled:opacity-50"
                >
                  {isProcessing ? (
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Authorizing Payment...
                    </span>
                  ) : (
                    <span>Pay ₹{totalAmount.toLocaleString('en-IN')} & Confirm</span>
                  )}
                </button>
              </div>
            </div>
          )}

          {step === 'success' && placedOrder && (
            <div className="text-center py-5 px-3 space-y-4 max-w-lg mx-auto animate-scale-in">
              <div className="w-14 h-14 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 mx-auto flex items-center justify-center shadow-lg shadow-emerald-500/20">
                <CheckCircle className="w-9 h-9" />
              </div>

              <div>
                <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
                  Order Placed Successfully!
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Order ID: <strong className="font-mono text-slate-800 dark:text-slate-200">{placedOrder.orderNumber}</strong>
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Dispatched to fulfillment & driver assigned in real time.
                </p>
              </div>

              {/* Secure Delivery OTP */}
              <div className="p-3.5 bg-slate-900 text-white rounded-xl border border-amber-500/40 text-left shadow-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                        Delivery Handover OTP
                      </p>
                      <p className="text-[11px] text-slate-300">
                        Share with driver upon doorstep delivery
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-amber-500/30">
                    <span className="font-mono font-black text-base text-amber-400 tracking-widest">
                      {placedOrder.deliveryOtp || '8492'}
                    </span>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(placedOrder.deliveryOtp || '8492');
                        showToast(`Copied OTP (${placedOrder.deliveryOtp || '8492'})`);
                      }}
                      className="text-slate-400 hover:text-amber-400"
                      title="Copy OTP"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/80 rounded-xl text-left border border-slate-200 dark:border-slate-700 text-xs space-y-1.5">
                <div className="flex justify-between font-semibold text-slate-700 dark:text-slate-300">
                  <span>Estimated Delivery:</span>
                  <span className="text-amber-600 font-bold">{placedOrder.estimatedDelivery}</span>
                </div>
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>Payment Mode:</span>
                  <span>{placedOrder.paymentMethod} ({placedOrder.paymentStatus})</span>
                </div>
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>Delivery Address:</span>
                  <span className="truncate max-w-[200px]">{placedOrder.shippingAddress.city}, {placedOrder.shippingAddress.state}</span>
                </div>
                <div className="flex justify-between font-bold text-slate-900 dark:text-white pt-1.5 border-t border-slate-200 dark:border-slate-700">
                  <span>Total Paid:</span>
                  <span>₹{placedOrder.totalAmount.toLocaleString('en-IN')}</span>
                </div>
              </div>

              {/* Omnichannel Flow Testing Shortcuts */}
              <div className="space-y-2 pt-1">
                <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider text-left">
                  🚀 Real-Time Omnichannel Simulation
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    id="view-live-tracking-btn"
                    onClick={() => {
                      handleClose();
                      openLiveMapForOrder(placedOrder);
                    }}
                    className="p-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all shadow-sm"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>Live GPS Map</span>
                  </button>

                  <button
                    onClick={() => {
                      handleClose();
                      setDeviceMode('driver');
                      showToast(`🚚 Switched to Driver Partner App for Order #${placedOrder.orderNumber}`);
                    }}
                    className="p-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all shadow-sm"
                  >
                    <Truck className="w-3.5 h-3.5" />
                    <span>Open Driver App</span>
                  </button>

                  <button
                    onClick={() => {
                      handleClose();
                      setDeviceMode('seller');
                      showToast(`🏪 Switched to Seller Central for Order #${placedOrder.orderNumber}`);
                    }}
                    className="p-2.5 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all shadow-sm"
                  >
                    <Store className="w-3.5 h-3.5" />
                    <span>Seller Central</span>
                  </button>

                  <button
                    onClick={() => {
                      handleClose();
                      setActiveTrackingOrder(placedOrder);
                    }}
                    className="p-2.5 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-100 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all shadow-sm"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Order Details</span>
                  </button>
                </div>

                <button
                  onClick={handleClose}
                  className="w-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold py-2.5 px-4 rounded-xl text-xs transition-colors"
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
