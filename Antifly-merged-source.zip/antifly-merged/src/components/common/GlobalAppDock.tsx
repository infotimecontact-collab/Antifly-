import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  ArrowLeftRight,
  ShoppingBag,
  Store,
  Truck,
  Camera,
  User,
  Sparkles,
  Rocket,
  Bot,
  Brain,
} from 'lucide-react';
import { DeviceMode } from '../../types';

export const GlobalAppDock: React.FC = () => {
  const {
    deviceMode,
    setDeviceMode,
    cart,
    driverTasks,
    orders,
    setIsRoleSwitcherOpen,
    userPersonaProfile,
    setIsLiveShoppingOpen,
    setIsMultilingualStudioOpen,
    openNavaSocialHub,
    setIsCommunityNetworkOpen,
    setIsOneTapSellOpen,
    setIsUniversalIdentityOpen,
    setIsSupportChatbotOpen,
  } = useApp();

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const pendingDeliveries = driverTasks.filter((t) => t.status !== 'Delivered').length;
  const sellerPendingOrders = orders.filter((o) => o.status === 'Processing' || o.status === 'Confirmed').length;

  return (
    <aside
      id="global-ecosystem-app-dock"
      aria-label="App Ecosystem Switcher"
      className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 max-w-[98vw] sm:max-w-max"
    >
      <div className="bg-white/95 backdrop-blur-xl border border-red-500/30 rounded-2xl p-1.5 shadow-2xl flex items-center gap-1 sm:gap-1.5 ring-1 ring-red-500/20">
        {/* Vice-Versa Persona Switcher */}
        <button
          onClick={() => setIsRoleSwitcherOpen(true)}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 text-white text-xs font-black shadow-md hover:brightness-110 transition cursor-pointer"
          title="Single Unified Account: Click to switch between Customer, Venture, and Buddy"
        >
          <ArrowLeftRight className="w-3.5 h-3.5 text-white" />
          <span className="hidden sm:inline capitalize">
            {userPersonaProfile.activePersona === 'seller' ? 'Venture' : userPersonaProfile.activePersona === 'driver' ? 'Buddy' : 'Customer'}
          </span>
          <span className="sm:hidden">Role</span>
        </button>

        <div className="h-5 w-px bg-slate-800 mx-0.5" />

        {/* 1. Customer Mode Button */}
        <button
          onClick={() => setDeviceMode('website')}
          className={`relative flex items-center gap-1.5 px-2.5 sm:px-3 py-1 rounded-xl text-xs transition-all whitespace-nowrap cursor-pointer ${
            deviceMode === 'website'
              ? 'bg-red-600 text-white shadow-lg shadow-red-600/30 font-bold'
              : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
          }`}
          title="1. Customer Marketplace"
        >
          <div className="relative">
            <ShoppingBag className="w-4 h-4" />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-amber-400 text-slate-800 text-[9px] font-black rounded-full min-w-[14px] h-[14px] flex items-center justify-center px-0.5">
                {cartCount}
              </span>
            )}
          </div>
          <div className="text-left leading-tight">
            <p className="text-xs font-bold">Customer</p>
            <p className={`text-[9px] hidden md:block ${deviceMode === 'website' ? 'opacity-90' : 'text-slate-400'}`}>
              Shop
            </p>
          </div>
        </button>

        {/* 2. Venture Mode Button */}
        <button
          onClick={() => setDeviceMode('seller')}
          className={`relative flex items-center gap-1.5 px-2.5 sm:px-3 py-1 rounded-xl text-xs transition-all whitespace-nowrap cursor-pointer ${
            deviceMode === 'seller'
              ? 'bg-orange-600 text-white shadow-lg shadow-orange-600/30 font-bold'
              : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
          }`}
          title="2. Venture Store Hub"
        >
          <div className="relative">
            <Store className="w-4 h-4 text-amber-300" />
            {sellerPendingOrders > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-amber-400 text-slate-800 text-[9px] font-black rounded-full min-w-[14px] h-[14px] flex items-center justify-center px-0.5">
                {sellerPendingOrders}
              </span>
            )}
          </div>
          <div className="text-left leading-tight">
            <p className="text-xs font-bold">Venture</p>
            <p className={`text-[9px] hidden md:block ${deviceMode === 'seller' ? 'opacity-90' : 'text-slate-400'}`}>
              My Store
            </p>
          </div>
        </button>

        {/* 3. Buddy Mode Button */}
        <button
          onClick={() => setDeviceMode('driver')}
          className={`relative flex items-center gap-1.5 px-2.5 sm:px-3 py-1 rounded-xl text-xs transition-all whitespace-nowrap cursor-pointer ${
            deviceMode === 'driver'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30 font-bold'
              : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
          }`}
          title="3. Delivery Buddy"
        >
          <div className="relative">
            <Truck className="w-4 h-4 text-emerald-300" />
            {pendingDeliveries > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-emerald-400 text-slate-800 text-[9px] font-black rounded-full min-w-[14px] h-[14px] flex items-center justify-center px-0.5">
                {pendingDeliveries}
              </span>
            )}
          </div>
          <div className="text-left leading-tight">
            <p className="text-xs font-bold">Buddy</p>
            <p className={`text-[9px] hidden md:block ${deviceMode === 'driver' ? 'opacity-90' : 'text-slate-400'}`}>
              Deliver
            </p>
          </div>
        </button>

        <div className="h-5 w-px bg-slate-800 mx-0.5" />

        {/* Antifly Unified Personal OS */}
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('antifly:open-unified-os'))}
          className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1 rounded-xl text-xs font-black bg-cyan-600 hover:bg-cyan-700 text-white transition cursor-pointer border border-cyan-500/40"
          title="Antifly Personal OS — LifeOS + NAVA"
        >
          <Brain className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">LifeOS + NAVA</span>
          <span className="sm:hidden">OS</span>
        </button>

        {/* 1-Tap Sell Trigger */}
        <button
          onClick={() => setIsOneTapSellOpen(true)}
          className="flex items-center gap-1 px-2 sm:px-2.5 py-1 rounded-xl text-xs font-black bg-teal-600/30 hover:bg-teal-600 text-teal-300 hover:text-white transition cursor-pointer border border-teal-500/30"
          title="One-Tap Photo to Listing"
        >
          <Camera className="w-3.5 h-3.5 text-teal-300" />
          <span className="hidden sm:inline">1-Tap Sell</span>
        </button>

        {/* Universal Profile Trigger */}
        <button
          onClick={() => setIsUniversalIdentityOpen(true)}
          className="flex items-center gap-1 px-2 sm:px-2.5 py-1 rounded-xl text-xs font-black bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer border border-slate-700"
          title="Universal Identity (Buy/Sell/Deliver/Earn)"
        >
          <User className="w-3.5 h-3.5 text-slate-300" />
          <span className="hidden sm:inline">Identity</span>
        </button>

        {/* Community Commerce & Elastic Delivery Network Trigger */}
        <button
          onClick={() => setIsCommunityNetworkOpen(true)}
          className="relative flex items-center gap-1.5 px-2.5 sm:px-3 py-1 rounded-xl text-xs font-black bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white shadow-lg shadow-emerald-600/40 transition cursor-pointer border border-emerald-400/40"
          title="ONE PERSON: BUY • SELL • DELIVER • EARN • CREATE • CONNECT"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-200" />
          <span>Network</span>
        </button>

        {/* NAVA Next-Gen Social Hub Trigger */}
        <button
          onClick={() => openNavaSocialHub()}
          className="relative flex items-center gap-1.5 px-2.5 sm:px-3 py-1 rounded-xl text-xs font-black bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white shadow-lg shadow-indigo-600/40 transition cursor-pointer border border-indigo-400/40"
          title="Open NAVA — Next-Gen Social Network & Mission Ecosystem"
        >
          <Rocket className="w-3.5 h-3.5 text-cyan-200" />
          <span className="hidden sm:inline">NAVA</span>
        </button>

        {/* AI Chatbot Quick Trigger */}
        <button
          onClick={() => setIsSupportChatbotOpen(true)}
          className="flex items-center gap-1 p-1.5 rounded-xl text-xs font-bold text-red-300 hover:text-white hover:bg-red-950/50 transition cursor-pointer"
          title="Talk to Antifly & 24/7 AI Helpline"
        >
          <Bot className="w-4 h-4 text-rose-400" />
        </button>
      </div>
    </aside>
  );
};

