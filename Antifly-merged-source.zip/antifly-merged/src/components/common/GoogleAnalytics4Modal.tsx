import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  BarChart3,
  X,
  Check,
  Zap,
  Activity,
  Send,
  Sliders,
  Shield,
  Layers,
  Sparkles,
  ExternalLink,
  Code,
  Copy,
} from 'lucide-react';
import { GA4EventName } from '../../types';

export const GoogleAnalytics4Modal: React.FC = () => {
  const {
    isGA4ModalOpen,
    setIsGA4ModalOpen,
    ga4Config,
    setGA4Config,
    ga4EventLog,
    trackEvent,
    selectedCurrency,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'config' | 'events' | 'simulator'>('simulator');
  const [testEventName, setTestEventName] = useState<GA4EventName>('purchase');
  const [testValue, setTestValue] = useState<number>(3499);

  if (!isGA4ModalOpen) return null;

  const handleToggleTracking = () => {
    setGA4Config((prev) => ({ ...prev, enabled: !prev.enabled }));
    showToast(!ga4Config.enabled ? '🟢 GA4 Real-time Tracking Enabled' : '🔴 GA4 Tracking Paused');
  };

  const handleSimulateEvent = () => {
    trackEvent(testEventName, {
      value: testValue,
      currency: selectedCurrency,
      transaction_id: `TXN-GA4-${Date.now().toString().slice(-6)}`,
      items: [
        { item_id: 'prod-001', item_name: 'Handcrafted Kanjeevaram Saree', price: testValue, quantity: 1 },
      ],
    });
    showToast(`📊 GA4 Event "${testEventName}" dispatched!`);
  };

  return (
    <div id="ga4-analytics-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl text-slate-100 overflow-hidden">
        {/* Modal Header */}
        <div className="bg-white px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white">
                  Google Analytics 4 Enhanced E-commerce
                </h2>
                <span
                  className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                    ga4Config.enabled
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  }`}
                >
                  {ga4Config.enabled ? 'ACTIVE STREAM' : 'PAUSED'}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Measurement ID: <span className="font-mono text-blue-400">{ga4Config.measurementId}</span> &bull; gtag.js v4.0
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsGA4ModalOpen(false)}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sub-navigation tabs */}
        <div className="flex items-center gap-2 px-6 pt-4 border-b border-slate-800 bg-slate-900">
          <button
            onClick={() => setActiveTab('simulator')}
            className={`flex items-center gap-2 px-4 py-2 rounded-t-xl text-xs sm:text-sm font-semibold border-b-2 transition-all ${
              activeTab === 'simulator'
                ? 'border-blue-500 text-blue-400 bg-slate-850'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Zap className="w-4 h-4" />
            <span>Real-time Event Stream ({ga4EventLog.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('config')}
            className={`flex items-center gap-2 px-4 py-2 rounded-t-xl text-xs sm:text-sm font-semibold border-b-2 transition-all ${
              activeTab === 'config'
                ? 'border-blue-500 text-blue-400 bg-slate-850'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>GA4 Configuration</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5 text-xs">
          {/* TAB 1: LIVE EVENT STREAM & SIMULATOR */}
          {activeTab === 'simulator' && (
            <div className="space-y-4">
              {/* Event Simulator Controls */}
              <div className="bg-white border border-slate-800 p-4 rounded-2xl">
                <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-blue-400" />
                  Dispatch Test E-Commerce Event to GA4
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-slate-400 block mb-1">Standard GA4 Event</label>
                    <select
                      value={testEventName}
                      onChange={(e) => setTestEventName(e.target.value as GA4EventName)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="page_view">page_view</option>
                      <option value="view_item">view_item</option>
                      <option value="add_to_cart">add_to_cart</option>
                      <option value="begin_checkout">begin_checkout</option>
                      <option value="purchase">purchase</option>
                      <option value="search">search</option>
                      <option value="refund">refund</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-slate-400 block mb-1">Event Value ({selectedCurrency})</label>
                    <input
                      type="number"
                      value={testValue}
                      onChange={(e) => setTestValue(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div className="flex items-end">
                    <button
                      onClick={handleSimulateEvent}
                      className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2 rounded-xl text-xs transition-all shadow-md flex items-center justify-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Trigger Event</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Real-time Event Log */}
              <div className="bg-white border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
                <div className="px-4 py-3 bg-slate-900/80 border-b border-slate-800 flex justify-between items-center">
                  <span className="font-bold text-slate-300">Live Dispatched Events Feed</span>
                  <span className="text-[11px] text-slate-400 font-mono">gtag('event', name, params)</span>
                </div>
                <div className="divide-y divide-slate-800 max-h-72 overflow-y-auto font-mono text-xs">
                  {ga4EventLog.length === 0 ? (
                    <div className="p-6 text-center text-slate-500">
                      No events captured yet. Trigger a test event or interact with the store.
                    </div>
                  ) : (
                    ga4EventLog.map((ev) => (
                      <div key={ev.id} className="p-3.5 hover:bg-slate-900 transition-colors">
                        <div className="flex items-center justify-between">
                          <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30 font-bold">
                            {ev.eventName}
                          </span>
                          <span className="text-slate-500 text-[11px]">{ev.timestamp}</span>
                        </div>
                        <div className="mt-2 text-slate-300 text-[11px] bg-slate-900 p-2.5 rounded-lg border border-slate-800/80 overflow-x-auto">
                          <pre className="text-emerald-300">{JSON.stringify(ev.params || {}, null, 2)}</pre>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: CONFIGURATION */}
          {activeTab === 'config' && (
            <div className="space-y-4">
              <div className="bg-white p-5 rounded-2xl border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-white text-sm">GA4 Measurement Property</h4>
                    <p className="text-slate-400 text-xs">Send telemetry directly to your Google Analytics dashboard.</p>
                  </div>
                  <button
                    onClick={handleToggleTracking}
                    className={`px-4 py-1.5 rounded-xl font-bold text-xs transition-all ${
                      ga4Config.enabled
                        ? 'bg-emerald-500 text-slate-800'
                        : 'bg-slate-700 text-slate-300'
                    }`}
                  >
                    {ga4Config.enabled ? 'Enabled' : 'Disabled'}
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="text-slate-400 block mb-1 font-semibold">GA4 Measurement ID</label>
                    <input
                      type="text"
                      value={ga4Config.measurementId}
                      onChange={(e) => setGA4Config((prev) => ({ ...prev, measurementId: e.target.value }))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="text-slate-400 block mb-1 font-semibold">Google Tag Manager (GTM) Container ID</label>
                    <input
                      type="text"
                      value={ga4Config.gtmContainerId || 'GTM-WISEIND9'}
                      onChange={(e) => setGA4Config((prev) => ({ ...prev, gtmContainerId: e.target.value }))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {/* Enhanced E-commerce Feature Toggles */}
                <div className="pt-3 border-t border-slate-800 space-y-2">
                  <h5 className="font-semibold text-slate-300">Enhanced E-Commerce Features Active:</h5>
                  <div className="grid grid-cols-2 gap-2 text-slate-300">
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span>Item impression tracking (view_item_list)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span>Funnel checkout step telemetry (begin_checkout)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span>Revenue & Currency conversion tracking</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span>Promotion & Coupon discount tracking</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
