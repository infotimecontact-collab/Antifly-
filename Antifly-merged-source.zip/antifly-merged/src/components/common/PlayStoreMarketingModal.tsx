import React, { useState } from 'react';
import {
  Sparkles,
  Download,
  Share2,
  Copy,
  Check,
  Smartphone,
  Tablet,
  Award,
  ShieldCheck,
  TrendingUp,
  X,
  FileText,
  Printer,
  ShoppingBag,
  Bike,
  Store,
  IndianRupee,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const PlayStoreMarketingModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({
  isOpen,
  onClose,
}) => {
  const { settings, showToast } = useApp();
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [activeAssetTab, setActiveAssetTab] = useState<'playstore' | 'captions' | 'flyer'>('playstore');

  if (!isOpen) return null;

  const marketingPunchlines = [
    {
      title: 'Main Play Store Short Description (80 chars)',
      text: 'Antifly — Vocal for Local! Shop directly from verified nearby stores with 0% markup.',
      tag: 'ASO High Conversion',
    },
    {
      title: 'Play Store Full Description Hook',
      text: `🇮🇳 Antifly (Voice of India) — India's Premier Hyperlocal Marketplace & Driver Network!\n\n✨ Why Antifly?\n• 🏪 100% Verified Local Neighborhood Stores\n• ⚡ Direct UPI QR Payment to Merchants\n• 🔄 Mandatory 7-Day Guaranteed Returns & Exchange\n• 🛵 Superfast Hyperlocal Delivery with Driver Incentives\n• 📞 24/7 Dedicated Support: ${settings.contactPhone || '+91 98765 43210'}`,
      tag: 'Play Store Listing',
    },
    {
      title: 'WhatsApp & Social Media Broadcast Caption',
      text: '🛍️ Indore & India! Why pay extra on big corporate apps? Shop directly from your trusted neighborhood merchants on Antifly! Enjoy direct UPI payments, 7-day hassle-free exchange & lightning fast local delivery! Download now: https://antifly.app',
      tag: 'Social Growth',
    },
    {
      title: 'Driver Partner Recruitment Punchline',
      text: '🛵 Become a Antifly Delivery Partner! Drive your own bike/EV scooter, get 20 free welcome credits on login, and earn up to ₹300 daily milestone bonuses (1 Credit = ₹1 Real Cash). Instant UPI daily payout!',
      tag: 'Driver Hiring',
    },
  ];

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    showToast('Copied to clipboard!');
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handlePrintPdf = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-white/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-4xl w-full shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-red-600 via-orange-600 to-amber-600 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-amber-200" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-tight">
                Antifly — Play Store Launch & Growth Marketing Kit
              </h2>
              <p className="text-xs text-white/90 font-medium">
                High-converting ASO assets, verified captions, promotional flyers & Play Store export
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 transition cursor-pointer text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-slate-200 bg-slate-50 px-5 gap-3 pt-3">
          <button
            onClick={() => setActiveAssetTab('playstore')}
            className={`pb-3 px-3 text-xs font-black transition cursor-pointer border-b-2 ${
              activeAssetTab === 'playstore'
                ? 'border-red-600 text-red-600'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            📱 Play Store Mockup Screenshots
          </button>
          <button
            onClick={() => setActiveAssetTab('captions')}
            className={`pb-3 px-3 text-xs font-black transition cursor-pointer border-b-2 ${
              activeAssetTab === 'captions'
                ? 'border-red-600 text-red-600'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            ✍️ Viral Indian Marketing Captions
          </button>
          <button
            onClick={() => setActiveAssetTab('flyer')}
            className={`pb-3 px-3 text-xs font-black transition cursor-pointer border-b-2 ${
              activeAssetTab === 'flyer'
                ? 'border-red-600 text-red-600'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            🖨️ Printable Promotion Flyer (PDF Ready)
          </button>
        </div>

        {/* Modal Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: PLAY STORE SCREENSHOTS READY */}
          {activeAssetTab === 'playstore' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    Official Google Play Store Promotional Graphics
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">
                    Pre-designed high resolution app mockups tailored for Google Play Store review.
                  </p>
                </div>
                <button
                  onClick={handlePrintPdf}
                  className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer shadow-xs"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print / Save as PDF</span>
                </button>
              </div>

              {/* 3 Play Store Screenshot Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Screenshot 1 */}
                <div className="bg-gradient-to-b from-red-600 to-red-700 text-white p-5 rounded-3xl flex flex-col justify-between shadow-lg text-center aspect-[9/16] max-h-[420px]">
                  <div>
                    <span className="px-3 py-1 bg-white/20 rounded-full text-[10px] font-black uppercase tracking-wider">
                      Screenshot 1
                    </span>
                    <h4 className="text-base font-black mt-2 leading-tight">
                      Apna Shahar, Apni Dukan!
                    </h4>
                    <p className="text-[11px] text-white/90 font-semibold mt-1">
                      Shop directly from 100+ verified neighborhood stores in your city.
                    </p>
                  </div>

                  <div className="bg-white text-slate-900 p-4 rounded-2xl shadow-xl text-left space-y-2 mt-auto">
                    <div className="flex items-center gap-2">
                      <Store className="w-5 h-5 text-red-600" />
                      <div>
                        <div className="text-xs font-black">Shree Ganesh Sweets</div>
                        <div className="text-[10px] text-slate-500 font-bold">Palasia, Indore • 0.8 km</div>
                      </div>
                    </div>
                    <div className="bg-emerald-50 text-emerald-800 p-2 rounded-xl text-[10px] font-extrabold text-center border border-emerald-200">
                      ⚡ Direct UPI QR Scan & Pay
                    </div>
                  </div>
                </div>

                {/* Screenshot 2 */}
                <div className="bg-gradient-to-b from-blue-600 to-indigo-700 text-white p-5 rounded-3xl flex flex-col justify-between shadow-lg text-center aspect-[9/16] max-h-[420px]">
                  <div>
                    <span className="px-3 py-1 bg-white/20 rounded-full text-[10px] font-black uppercase tracking-wider">
                      Screenshot 2
                    </span>
                    <h4 className="text-base font-black mt-2 leading-tight">
                      7-Day Guaranteed Return & Exchange
                    </h4>
                    <p className="text-[11px] text-white/90 font-semibold mt-1">
                      100% buyer protection with mandatory seller exchange policy.
                    </p>
                  </div>

                  <div className="bg-white text-slate-900 p-4 rounded-2xl shadow-xl text-left space-y-2 mt-auto">
                    <div className="flex items-center gap-2 text-emerald-700 font-extrabold text-xs">
                      <ShieldCheck className="w-5 h-5 text-emerald-600" />
                      <span>Zero Hassle Returns</span>
                    </div>
                    <p className="text-[10px] text-slate-600 font-medium">
                      If any seller denies, automatic full refund penalty to customer.
                    </p>
                  </div>
                </div>

                {/* Screenshot 3 */}
                <div className="bg-gradient-to-b from-emerald-600 to-teal-700 text-white p-5 rounded-3xl flex flex-col justify-between shadow-lg text-center aspect-[9/16] max-h-[420px]">
                  <div>
                    <span className="px-3 py-1 bg-white/20 rounded-full text-[10px] font-black uppercase tracking-wider">
                      Screenshot 3
                    </span>
                    <h4 className="text-base font-black mt-2 leading-tight">
                      Drive Your Own Vehicle & Earn Daily
                    </h4>
                    <p className="text-[11px] text-white/90 font-semibold mt-1">
                      20 Login Bonus Credits + up to ₹300 Daily Milestone Incentives.
                    </p>
                  </div>

                  <div className="bg-white text-slate-900 p-4 rounded-2xl shadow-xl text-left space-y-2 mt-auto">
                    <div className="flex items-center justify-between text-xs font-black">
                      <span>Daily Bonus</span>
                      <span className="text-emerald-600 font-extrabold">+₹300 Cash</span>
                    </div>
                    <div className="text-[10px] text-slate-500 font-semibold">
                      1 Credit = ₹1 Rupee • Instant Bank UPI
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: MARKETING CAPTIONS */}
          {activeAssetTab === 'captions' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black text-slate-900">
                  Ready-to-Use High Impact Marketing Copy
                </h3>
                <span className="text-xs font-bold text-slate-500">
                  Click copy and paste in Play Store or Social Ads
                </span>
              </div>

              <div className="space-y-3">
                {marketingPunchlines.map((item, idx) => (
                  <div key={idx} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-slate-900">{item.title}</span>
                      <span className="px-2.5 py-0.5 rounded-full bg-red-100 text-red-800 text-[10px] font-black">
                        {item.tag}
                      </span>
                    </div>

                    <pre className="text-xs text-slate-700 font-sans whitespace-pre-wrap bg-white p-3 rounded-xl border border-slate-200">
                      {item.text}
                    </pre>

                    <div className="flex justify-end">
                      <button
                        onClick={() => handleCopy(item.text, idx)}
                        className="flex items-center gap-1.5 bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer shadow-xs"
                      >
                        {copiedIndex === idx ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedIndex === idx ? 'Copied!' : 'Copy Caption'}</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: PROMOTIONAL FLYER PRINT */}
          {activeAssetTab === 'flyer' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black text-slate-900">
                  Printable A4 / Pamphlet Banner for Offline Store Promotion
                </h3>
                <button
                  onClick={handlePrintPdf}
                  className="flex items-center gap-1.5 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer shadow-xs"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Download / Print Flyer</span>
                </button>
              </div>

              <div className="p-8 rounded-3xl bg-gradient-to-b from-white via-orange-50/30 to-red-50/30 border-2 border-red-200 space-y-6 text-center max-w-2xl mx-auto shadow-sm">
                <div className="inline-block px-4 py-1.5 rounded-full bg-red-600 text-white text-xs font-black uppercase tracking-widest">
                  🇮🇳 Apni Dukan, Apna Shahar — Antifly
                </div>

                <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight leading-tight">
                  Shop Local. Save Big. Direct UPI QR Payment to Merchants!
                </h1>

                <p className="text-xs sm:text-sm text-slate-600 font-medium">
                  Support local Indore and Indian shops with 0% extra commissions, 7-day guaranteed returns, and express 30-minute doorstep delivery.
                </p>

                <div className="grid grid-cols-3 gap-3 text-left">
                  <div className="p-3 bg-white rounded-2xl border border-slate-200 shadow-xs">
                    <span className="text-[10px] font-black text-red-600 uppercase">Feature 1</span>
                    <h5 className="font-extrabold text-xs text-slate-900 mt-0.5">Nearby Stores</h5>
                    <p className="text-[10px] text-slate-500 mt-0.5">Find top shops within 2-5 km</p>
                  </div>
                  <div className="p-3 bg-white rounded-2xl border border-slate-200 shadow-xs">
                    <span className="text-[10px] font-black text-emerald-600 uppercase">Feature 2</span>
                    <h5 className="font-extrabold text-xs text-slate-900 mt-0.5">Direct UPI QR</h5>
                    <p className="text-[10px] text-slate-500 mt-0.5">Pay via PhonePe / GPay</p>
                  </div>
                  <div className="p-3 bg-white rounded-2xl border border-slate-200 shadow-xs">
                    <span className="text-[10px] font-black text-blue-600 uppercase">Feature 3</span>
                    <h5 className="font-extrabold text-xs text-slate-900 mt-0.5">7-Day Return</h5>
                    <p className="text-[10px] text-slate-500 mt-0.5">Guaranteed exchange policy</p>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-200 text-xs font-bold text-slate-700 flex items-center justify-between">
                  <span>Customer Care: {settings.contactPhone || '+91 98765 43210'}</span>
                  <span>Email: {settings.contactEmail || 'support@antifly.in'}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
