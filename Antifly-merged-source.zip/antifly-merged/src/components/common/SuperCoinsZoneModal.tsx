import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Coins,
  X,
  Sparkles,
  Gift,
  Crown,
  TrendingUp,
  Flame,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldCheck,
  ChevronRight,
  Award,
  Zap,
  Gem,
  ArrowRightLeft,
  Calendar,
} from 'lucide-react';

export const SuperCoinsZoneModal: React.FC = () => {
  const {
    isSuperCoinsModalOpen,
    setIsSuperCoinsModalOpen,
    superCoinsBalance,
    diamondsBalance,
    superCoinRewards,
    superCoinTransactions,
    diamondTransactions,
    redeemSuperCoinReward,
    convertDiamondsToCoins,
    addDiamonds,
    isPlusMember,
    adminGamificationConfig,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'rewards' | 'diamonds' | 'tiers' | 'history'>('rewards');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [diamondsToConvert, setDiamondsToConvert] = useState<number>(10);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [spinResult, setSpinResult] = useState<number | null>(null);

  if (!isSuperCoinsModalOpen) return null;

  const cfg = adminGamificationConfig;

  const filteredRewards = superCoinRewards.filter((r) => {
    if (selectedCategory === 'all') return true;
    return r.category === selectedCategory;
  });

  const handleConvertDiamonds = (e: React.FormEvent) => {
    e.preventDefault();
    if (diamondsToConvert <= 0 || diamondsToConvert > diamondsBalance) return;
    convertDiamondsToCoins(diamondsToConvert);
  };

  const handleSpinWheel = () => {
    if (isSpinning) return;
    setIsSpinning(true);
    setSpinResult(null);

    setTimeout(() => {
      const min = cfg.spinWheelMinDiamonds || 5;
      const max = cfg.spinWheelMaxDiamonds || 50;
      const wonDiamonds = Math.floor(Math.random() * (max - min + 1)) + min;
      addDiamonds(wonDiamonds, `🎡 Daily Lucky Spin Reward (+${wonDiamonds} 💎)`);
      setSpinResult(wonDiamonds);
      setIsSpinning(false);
    }, 1200);
  };

  return (
    <div
      id="supercoins-zone-modal"
      className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 lg:p-6 animate-fade-in"
    >
      <div className="bg-white dark:bg-slate-900 w-full max-w-4xl rounded-3xl shadow-2xl border border-amber-200 dark:border-amber-900/30 overflow-hidden flex flex-col my-auto max-h-[92vh]">
        {/* WiseCoins Signature Header */}
        <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-500 p-6 text-slate-800 relative overflow-hidden flex-shrink-0">
          <div className="absolute right-0 top-0 translate-x-8 -translate-y-8 opacity-20 pointer-events-none">
            <Coins className="w-56 h-56 text-slate-800" />
          </div>

          <div className="flex items-start justify-between relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center border border-slate-200/10 shadow-inner">
                <Coins className="w-8 h-8 text-slate-800 fill-amber-300" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-black uppercase tracking-wider bg-white text-amber-400 px-2 py-0.5 rounded-full">
                    ⚡ {cfg.seasonCampaignName || 'WisePlus VIP Loyalty Hub'}
                  </span>
                  {cfg.activeSeasonMultiplier > 1 && (
                    <span className="text-[11px] font-black bg-gradient-to-r from-orange-600 to-amber-700 text-white px-2 py-0.5 rounded-full shadow-xs">
                      🔥 {cfg.activeSeasonMultiplier}X MULTIPLIER ACTIVE
                    </span>
                  )}
                </div>
                <h2 className="text-2xl font-black tracking-tight text-slate-800 mt-1">
                  Dynamic Coins & Diamonds Hub
                </h2>
                <p className="text-xs text-slate-900 font-semibold opacity-95">
                  Earn {cfg.coinsEarnedPer100Spent} SuperCoins per ₹100 spent • 1 💎 = {cfg.diamondsToCoinsConversionRate} 🪙 • Redemptions up to {cfg.maxCoinsRedemptionPercentagePerOrder}%
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsSuperCoinsModalOpen(false)}
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-slate-800 transition"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* SuperCoins Balance Banner */}
          <div className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-white/20 backdrop-blur-md rounded-2xl p-3.5 border border-slate-200/10 flex items-center justify-between">
              <div>
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-900">Your Coin Balance</p>
                <div className="flex items-baseline gap-1.5 mt-0.5">
                  <Coins className="w-5 h-5 fill-amber-300 text-slate-800" />
                  <span className="text-2xl font-black text-slate-800">{superCoinsBalance}</span>
                  <span className="text-xs font-semibold text-slate-900">Coins (≈ ₹{superCoinsBalance * (cfg.coinsToInrRedemptionRatio || 1)})</span>
                </div>
              </div>
            </div>

            <div className="bg-white/20 backdrop-blur-md rounded-2xl p-3.5 border border-slate-200/10 flex items-center justify-between">
              <div>
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-900">Diamonds Vault</p>
                <div className="flex items-baseline gap-1.5 mt-0.5">
                  <Gem className="w-5 h-5 text-slate-800 fill-cyan-300" />
                  <span className="text-2xl font-black text-slate-800">{diamondsBalance}</span>
                  <span className="text-xs font-semibold text-slate-900">Diamonds (≈ ₹{diamondsBalance * (cfg.diamondToInrRatio || 10)})</span>
                </div>
              </div>
            </div>

            <div className="bg-white/20 backdrop-blur-md rounded-2xl p-3.5 border border-slate-200/10 flex items-center justify-between">
              <div>
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-900">Daily Coin Streak</p>
                <div className="flex items-center gap-1.5 mt-1">
                  <Flame className="w-4 h-4 text-orange-700 fill-orange-500 animate-pulse" />
                  <span className="text-sm font-black text-slate-800">Active (+{cfg.dailyCheckInBonus || 25} Coins)</span>
                </div>
              </div>
              <span className="px-2 py-1 bg-white text-amber-300 text-[10px] font-bold rounded-lg">Claimed</span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center justify-between px-6 border-b border-stone-200 dark:border-slate-800 bg-stone-50 dark:bg-white">
          <div className="flex gap-4">
            <button
              onClick={() => setActiveTab('rewards')}
              className={`py-3.5 text-xs font-bold border-b-2 flex items-center gap-1.5 transition ${
                activeTab === 'rewards'
                  ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Gift className="w-4 h-4" />
              Claim Vouchers ({superCoinRewards.length})
            </button>
            <button
              onClick={() => setActiveTab('diamonds')}
              className={`py-3.5 text-xs font-bold border-b-2 flex items-center gap-1.5 transition ${
                activeTab === 'diamonds'
                  ? 'border-cyan-500 text-cyan-600 dark:text-cyan-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Gem className="w-4 h-4" />
              💎 Diamonds Exchange & Spin
            </button>
            <button
              onClick={() => setActiveTab('tiers')}
              className={`py-3.5 text-xs font-bold border-b-2 flex items-center gap-1.5 transition ${
                activeTab === 'tiers'
                  ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Crown className="w-4 h-4" />
              VIP Membership Tiers ({cfg.membershipTiers?.length || 4})
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`py-3.5 text-xs font-bold border-b-2 flex items-center gap-1.5 transition ${
                activeTab === 'history'
                  ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Clock className="w-4 h-4" />
              Passbook History
            </button>
          </div>

          <div className="text-[11px] font-semibold text-stone-500 hidden sm:flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            Admin Managed Dynamic Multipliers
          </div>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {activeTab === 'rewards' && (
            <div className="space-y-4">
              {/* Category Filter Pills */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {['all', 'Discount', 'OTT', 'Travel', 'Dining'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition ${
                      selectedCategory === cat
                        ? 'bg-amber-500 text-slate-800 shadow-sm'
                        : 'bg-stone-100 dark:bg-slate-800 text-stone-600 dark:text-slate-300 hover:bg-stone-200'
                    }`}
                  >
                    {cat === 'all' ? 'All Rewards' : `${cat} Vouchers`}
                  </button>
                ))}
              </div>

              {/* Rewards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredRewards.map((reward) => {
                  const canAfford = superCoinsBalance >= reward.coinsCost;
                  return (
                    <div
                      key={reward.id}
                      className="border border-stone-200 dark:border-slate-800 rounded-2xl p-4 flex gap-4 bg-stone-50/50 dark:bg-slate-800/50 hover:border-amber-400/50 transition group"
                    >
                      <img
                        src={reward.imageUrl}
                        alt={reward.title}
                        className="w-24 h-24 rounded-xl object-cover flex-shrink-0 shadow-sm"
                      />
                      <div className="flex-1 flex flex-col justify-between">
                        <div>
                          <div className="flex items-center justify-between gap-1">
                            <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300">
                              {reward.badge}
                            </span>
                            <span className="text-[10px] text-stone-400 font-medium">
                              Expires in {reward.expiresInDays}d
                            </span>
                          </div>
                          <h4 className="font-bold text-stone-900 dark:text-white text-xs mt-1.5 group-hover:text-amber-600 dark:group-hover:text-amber-400 transition">
                            {reward.title}
                          </h4>
                          <p className="text-[11px] text-stone-500 dark:text-slate-400 line-clamp-2 mt-0.5">
                            {reward.description}
                          </p>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-stone-200 dark:border-slate-700/60 mt-2">
                          <div className="flex items-center gap-1 font-bold text-stone-900 dark:text-white text-xs">
                            <Coins className="w-4 h-4 text-amber-500 fill-amber-400" />
                            <span>{reward.coinsCost} Coins</span>
                            <span className="text-[10px] text-stone-400 line-through">₹{reward.monetaryValue}</span>
                          </div>

                          <button
                            onClick={() => redeemSuperCoinReward(reward.id)}
                            disabled={!canAfford}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition ${
                              canAfford
                                ? 'bg-amber-500 hover:bg-amber-400 text-slate-800 shadow-sm active:scale-95'
                                : 'bg-stone-200 dark:bg-slate-700 text-stone-400 cursor-not-allowed'
                            }`}
                          >
                            {canAfford ? 'Redeem Now' : `Need ${reward.coinsCost - superCoinsBalance} More`}
                            {canAfford && <ArrowRight className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {activeTab === 'diamonds' && (
            <div className="space-y-6">
              {/* Convert Card */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-5 bg-gradient-to-br from-cyan-950/60 to-slate-900 border border-cyan-500/30 rounded-2xl text-white space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                      <ArrowRightLeft className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-sm text-white">Instant Diamond-to-Coin Converter</h4>
                      <p className="text-xs text-cyan-300">
                        1 💎 Diamond = {cfg.diamondsToCoinsConversionRate || 10} SuperCoins
                      </p>
                    </div>
                  </div>

                  <form onSubmit={handleConvertDiamonds} className="space-y-3">
                    <div>
                      <label className="block text-xs text-slate-300 mb-1 font-bold">
                        Diamonds to Convert (Available: {diamondsBalance} 💎)
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          min="1"
                          max={diamondsBalance || 1}
                          value={diamondsToConvert}
                          onChange={(e) => setDiamondsToConvert(Number(e.target.value))}
                          className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white"
                        />
                        <button
                          type="button"
                          onClick={() => setDiamondsToConvert(diamondsBalance)}
                          className="px-2.5 py-2 bg-slate-700 hover:bg-slate-600 text-xs font-bold rounded-xl text-cyan-300 whitespace-nowrap"
                        >
                          MAX
                        </button>
                      </div>
                    </div>

                    <div className="p-3 bg-slate-800/80 rounded-xl text-xs text-slate-300 flex justify-between">
                      <span>You will receive:</span>
                      <strong className="text-amber-400 font-extrabold">
                        +{diamondsToConvert * (cfg.diamondsToCoinsConversionRate || 10)} SuperCoins 🪙
                      </strong>
                    </div>

                    <button
                      type="submit"
                      disabled={diamondsBalance < 1 || diamondsToConvert > diamondsBalance}
                      className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-extrabold rounded-xl transition shadow-xs disabled:opacity-50"
                    >
                      Convert {diamondsToConvert} Diamonds Now
                    </button>
                  </form>
                </div>

                {/* Spin the Wheel Card */}
                <div className="p-5 bg-gradient-to-br from-purple-950/60 to-slate-900 border border-purple-500/30 rounded-2xl text-white space-y-4 text-center flex flex-col justify-between">
                  <div>
                    <div className="w-12 h-12 rounded-2xl bg-purple-500/20 text-purple-400 flex items-center justify-center mx-auto mb-2">
                      <Sparkles className="w-6 h-6" />
                    </div>
                    <h4 className="font-extrabold text-sm text-white">Daily Diamond Lucky Spin</h4>
                    <p className="text-xs text-slate-400 mt-1">
                      Spin daily to win between {cfg.spinWheelMinDiamonds || 5} to {cfg.spinWheelMaxDiamonds || 50} free Diamonds!
                    </p>
                  </div>

                  {spinResult !== null && (
                    <div className="p-3 bg-emerald-950/80 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 font-bold animate-bounce">
                      🎉 Congratulations! You won +{spinResult} Diamonds!
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={handleSpinWheel}
                    disabled={isSpinning}
                    className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-black rounded-xl transition shadow-md disabled:opacity-50 uppercase tracking-wider"
                  >
                    {isSpinning ? '🎡 Spinning Lucky Wheel...' : '🎡 Spin the Wheel Now'}
                  </button>
                </div>
              </div>

              {/* Diamond Passbook */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500 dark:text-slate-400">
                  Recent Diamond Activity
                </h4>
                <div className="divide-y divide-stone-200 dark:divide-slate-800 border border-stone-200 dark:border-slate-800 rounded-2xl overflow-hidden bg-white dark:bg-slate-900">
                  {diamondTransactions?.map((tx) => (
                    <div key={tx.id} className="p-4 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold ${
                            tx.type === 'Earned'
                              ? 'bg-cyan-100 dark:bg-cyan-950/60 text-cyan-600'
                              : 'bg-rose-100 dark:bg-rose-950/60 text-rose-600'
                          }`}
                        >
                          {tx.type === 'Earned' ? '+' : '-'}
                        </div>
                        <div>
                          <p className="font-bold text-stone-900 dark:text-white">{tx.description}</p>
                          <p className="text-[11px] text-stone-400">{tx.date}</p>
                        </div>
                      </div>
                      <div
                        className={`font-black text-sm flex items-center gap-1 ${
                          tx.type === 'Earned' ? 'text-cyan-600' : 'text-rose-600'
                        }`}
                      >
                        <span>
                          {tx.type === 'Earned' ? '+' : '-'}
                          {tx.amount}
                        </span>
                        <Gem className="w-4 h-4 text-cyan-500 fill-cyan-400" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'tiers' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {cfg.membershipTiers?.map((tier) => (
                  <div
                    key={tier.id}
                    className="p-5 rounded-2xl bg-slate-900 text-white border border-slate-800 flex flex-col justify-between relative overflow-hidden"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl">{tier.badgeIcon}</span>
                        <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-500 text-slate-800">
                          {tier.coinsMultiplier}X Coins
                        </span>
                      </div>
                      <h4 className="font-extrabold text-sm text-white mt-3">{tier.name}</h4>
                      <p className="text-xs text-amber-400 font-bold mt-0.5">
                        {tier.annualFee > 0 ? `₹${tier.annualFee}/year` : 'Spend Unlock'}
                      </p>

                      <ul className="mt-3 space-y-1.5 text-[11px] text-slate-300">
                        {tier.perks.map((p, idx) => (
                          <li key={idx} className="flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                            <span>{p}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-800 text-[10px] text-slate-400">
                      <span>Threshold: ₹{tier.minPointsOrSpend.toLocaleString()} spend</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500 dark:text-slate-400">
                Recent SuperCoin Activity
              </h4>
              <div className="divide-y divide-stone-200 dark:divide-slate-800 border border-stone-200 dark:border-slate-800 rounded-2xl overflow-hidden bg-white dark:bg-slate-900">
                {superCoinTransactions.map((tx) => (
                  <div key={tx.id} className="p-4 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold ${
                          tx.type === 'Earned'
                            ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600'
                            : 'bg-rose-100 dark:bg-rose-950/60 text-rose-600'
                        }`}
                      >
                        {tx.type === 'Earned' ? '+' : '-'}
                      </div>
                      <div>
                        <p className="font-bold text-stone-900 dark:text-white">{tx.description}</p>
                        <p className="text-[11px] text-stone-400">{tx.date}</p>
                      </div>
                    </div>
                    <div
                      className={`font-black text-sm flex items-center gap-1 ${
                        tx.type === 'Earned' ? 'text-emerald-600' : 'text-rose-600'
                      }`}
                    >
                      <span>
                        {tx.type === 'Earned' ? '+' : '-'}
                        {tx.amount}
                      </span>
                      <Coins className="w-4 h-4 text-amber-500 fill-amber-400" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

