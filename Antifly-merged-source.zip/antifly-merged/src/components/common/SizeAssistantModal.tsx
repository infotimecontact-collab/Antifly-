import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Ruler,
  X,
  Sparkles,
  CheckCircle2,
  Users,
  ShieldCheck,
  TrendingUp,
  RotateCcw,
} from 'lucide-react';

export const SizeAssistantModal: React.FC = () => {
  const {
    isSizeAssistantOpen,
    setIsSizeAssistantOpen,
    sizeProfile,
    calculateRecommendedSize,
    showToast,
  } = useApp();

  const [height, setHeight] = useState(sizeProfile.heightCm || 175);
  const [weight, setWeight] = useState(sizeProfile.weightKg || 70);
  const [bodyType, setBodyType] = useState<string>(sizeProfile.bodyType || 'Average');
  const [fitPref, setFitPref] = useState<string>(sizeProfile.fitPreference || 'Regular');
  const [calculatedSize, setCalculatedSize] = useState<string>(sizeProfile.recommendedSize || 'L');

  if (!isSizeAssistantOpen) return null;

  const handleCalculate = (e: React.FormEvent) => {
    e.preventDefault();
    const size = calculateRecommendedSize(height, weight, bodyType, fitPref);
    setCalculatedSize(size);
    showToast(`🎯 Recommended Size: ${size} calculated!`);
  };

  return (
    <div
      id="size-assistant-modal"
      className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fade-in"
    >
      <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-3xl shadow-2xl border border-stone-200 dark:border-slate-800 overflow-hidden flex flex-col my-auto max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-stone-900 via-stone-800 to-stone-900 p-6 text-white relative flex-shrink-0">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400">
                <Ruler className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider bg-amber-400 text-slate-800 px-2 py-0.5 rounded-full">
                  WiseFit™ AI
                </span>
                <h3 className="text-xl font-black text-white mt-1">Smart Size & Fit Predictor</h3>
                <p className="text-xs text-stone-300 font-medium">98% Fit Accuracy Based on Real Shopper Returns</p>
              </div>
            </div>

            <button
              onClick={() => setIsSizeAssistantOpen(false)}
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleCalculate} className="p-6 overflow-y-auto flex-1 space-y-5">
          {/* Height & Weight Sliders */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-bold uppercase tracking-wider text-stone-600 dark:text-slate-400">
                  Height
                </label>
                <span className="text-xs font-black text-stone-900 dark:text-white">{height} cm</span>
              </div>
              <input
                type="range"
                min="140"
                max="210"
                value={height}
                onChange={(e) => setHeight(Number(e.target.value))}
                className="w-full accent-stone-900 dark:accent-amber-400"
              />
              <div className="flex justify-between text-[10px] text-stone-400 mt-1">
                <span>140cm (4'7")</span>
                <span>210cm (6'11")</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-bold uppercase tracking-wider text-stone-600 dark:text-slate-400">
                  Weight
                </label>
                <span className="text-xs font-black text-stone-900 dark:text-white">{weight} kg</span>
              </div>
              <input
                type="range"
                min="40"
                max="130"
                value={weight}
                onChange={(e) => setWeight(Number(e.target.value))}
                className="w-full accent-stone-900 dark:accent-amber-400"
              />
              <div className="flex justify-between text-[10px] text-stone-400 mt-1">
                <span>40 kg</span>
                <span>130 kg</span>
              </div>
            </div>
          </div>

          {/* Body Shape Selector */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 dark:text-slate-400 mb-2">
              Body Shape
            </label>
            <div className="grid grid-cols-4 gap-2">
              {['Slim', 'Average', 'Athletic', 'Broad'].map((shape) => (
                <button
                  type="button"
                  key={shape}
                  onClick={() => setBodyType(shape)}
                  className={`py-2 text-xs font-bold rounded-xl border transition ${
                    bodyType === shape
                      ? 'border-stone-900 dark:border-amber-400 bg-stone-900 dark:bg-amber-400 text-white dark:text-slate-800 shadow-sm'
                      : 'border-stone-200 dark:border-slate-800 text-stone-600 dark:text-slate-400 hover:bg-stone-100'
                  }`}
                >
                  {shape}
                </button>
              ))}
            </div>
          </div>

          {/* Fit Preference */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 dark:text-slate-400 mb-2">
              How do you like your fit?
            </label>
            <div className="grid grid-cols-3 gap-2">
              {['Fitted / Slim', 'Regular / Standard', 'Relaxed / Oversized'].map((fit) => (
                <button
                  type="button"
                  key={fit}
                  onClick={() => setFitPref(fit)}
                  className={`py-2 text-xs font-bold rounded-xl border transition ${
                    fitPref === fit
                      ? 'border-stone-900 dark:border-amber-400 bg-stone-900 dark:bg-amber-400 text-white dark:text-slate-800 shadow-sm'
                      : 'border-stone-200 dark:border-slate-800 text-stone-600 dark:text-slate-400 hover:bg-stone-100'
                  }`}
                >
                  {fit}
                </button>
              ))}
            </div>
          </div>

          {/* Predict CTA */}
          <button
            type="submit"
            className="w-full py-3 bg-stone-900 dark:bg-white text-white dark:text-slate-900 font-extrabold text-sm rounded-2xl shadow-md hover:bg-stone-800 transition flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            Recalculate Best Fit
          </button>

          {/* Result Card */}
          <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 flex items-center justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-[11px] font-black uppercase text-amber-900 dark:text-amber-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Recommended Size
              </div>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-3xl font-black text-stone-900 dark:text-white">Size {calculatedSize}</span>
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                  ({sizeProfile.confidenceScore}% Fit Match)
                </span>
              </div>
              <p className="text-[11px] text-stone-600 dark:text-slate-300 mt-0.5">
                Matched with <strong>{sizeProfile.matchedShoppersCount.toLocaleString()}</strong> shoppers with identical build.
              </p>
            </div>

            <div className="w-14 h-14 rounded-2xl bg-amber-400 text-slate-800 flex items-center justify-center font-black text-2xl shadow-inner">
              {calculatedSize}
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
