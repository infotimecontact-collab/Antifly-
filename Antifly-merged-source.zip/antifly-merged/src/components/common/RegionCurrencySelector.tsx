import React, { useState } from 'react';
import { Globe, Check, ChevronDown } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CountryCode, RegionConfig } from '../../types';

interface RegionCurrencySelectorProps {
  compact?: boolean;
  variant?: 'light' | 'header';
}

export const RegionCurrencySelector: React.FC<RegionCurrencySelectorProps> = ({ compact = false }) => {
  const { selectedCountry, setSelectedCountry, allRegions, currentRegion } = useApp();
  const [isOpen, setIsOpen] = useState(false);

  const regionList: RegionConfig[] = Object.values(allRegions) as RegionConfig[];

  const handleSelect = (code: CountryCode) => {
    setSelectedCountry(code);
    setIsOpen(false);
  };

  return (
    <div className="relative inline-block text-left" id="worldwide-region-currency-selector">
      <button
        type="button"
        id="region-selector-trigger-btn"
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all ${
          compact
            ? 'bg-amber-50/80 border-amber-200 text-stone-800 hover:bg-amber-100/70'
            : 'bg-stone-50 border-stone-200 text-stone-800 hover:bg-stone-100'
        }`}
        title="Change Country & Currency"
      >
        <span className="text-base leading-none">{currentRegion.flag}</span>
        <span className="font-semibold text-stone-900">{currentRegion.code}</span>
        <span className="text-stone-400">|</span>
        <span className="text-amber-700 font-semibold">{currentRegion.currency} ({currentRegion.symbol})</span>
        <ChevronDown className="w-3.5 h-3.5 text-stone-500 ml-0.5" />
      </button>

      {isOpen && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />
          <div
            id="region-selector-dropdown-menu"
            className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-stone-200 py-2 z-50 animate-in fade-in zoom-in-95 duration-150"
          >
            <div className="px-3.5 py-2 border-b border-stone-100">
              <div className="flex items-center gap-2 text-stone-700 font-semibold text-xs uppercase tracking-wider">
                <Globe className="w-3.5 h-3.5 text-amber-600" />
                <span>Select Worldwide Region</span>
              </div>
              <p className="text-[11px] text-stone-500 mt-0.5">
                Local prices, taxes ({currentRegion.taxName}), and regional couriers apply.
              </p>
            </div>

            <div className="max-h-64 overflow-y-auto py-1">
              {regionList.map((region) => {
                const isSelected = region.code === selectedCountry;
                return (
                  <button
                    key={region.code}
                    id={`region-select-opt-${region.code.toLowerCase()}`}
                    onClick={() => handleSelect(region.code)}
                    className={`w-full text-left px-3.5 py-2.5 flex items-center justify-between text-xs transition-colors ${
                      isSelected
                        ? 'bg-amber-50 text-amber-900 font-semibold'
                        : 'text-stone-700 hover:bg-stone-50'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="text-xl">{region.flag}</span>
                      <div>
                        <div className="font-medium text-stone-900 flex items-center gap-1.5">
                          {region.name}
                          <span className="text-[10px] px-1.5 py-0.2 bg-stone-100 text-stone-600 rounded">
                            {region.code}
                          </span>
                        </div>
                        <div className="text-[11px] text-stone-500 flex items-center gap-2 mt-0.5">
                          <span>{region.currency} ({region.symbol})</span>
                          <span>•</span>
                          <span>{region.defaultCourier}</span>
                        </div>
                      </div>
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-amber-600 shrink-0" />}
                  </button>
                );
              })}
            </div>

            <div className="px-3.5 py-2 border-t border-stone-100 bg-stone-50/70 rounded-b-xl flex items-center justify-between text-[11px] text-stone-500">
              <span>Automatic SLA: 5-Day Refund Guarantee</span>
              <span className="text-emerald-700 font-medium font-mono text-[10px]">Active</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
