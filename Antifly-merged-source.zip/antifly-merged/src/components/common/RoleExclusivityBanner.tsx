import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ShieldAlert,
  Smartphone,
  CheckCircle2,
  Trash2,
  Lock,
  Unlock,
  Store,
  Bike,
  User,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ArrowRight,
  RefreshCw,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';

export const RoleExclusivityBanner: React.FC = () => {
  const {
    registeredAccounts,
    activeAuthUser,
    openAuthModalFor,
    deleteDriverAccountPermanently,
    deleteSellerAccountPermanently,
    deleteCustomerAccountPermanently,
    setDeviceMode,
  } = useApp();

  const [isExpanded, setIsExpanded] = useState<boolean>(false);

  const roleBadge = (role: UserRole) => {
    switch (role) {
      case 'seller':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
            <Store className="w-3 h-3" /> Seller Store
          </span>
        );
      case 'driver':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
            <Bike className="w-3 h-3" /> Delivery Driver
          </span>
        );
      case 'customer':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/30">
            <User className="w-3 h-3" /> Customer
          </span>
        );
    }
  };

  return (
    <div
      id="role-exclusivity-policy-strip"
      className="bg-slate-900 border-b border-slate-800 text-slate-200 text-xs shadow-md relative z-30"
    >
      <div className="max-w-7xl mx-auto px-4 py-2 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 font-semibold text-[11px]">
            <ShieldAlert className="w-3.5 h-3.5 text-indigo-400" />
            <span>Mobile Role Exclusivity Active</span>
          </div>
          <span className="text-slate-400 hidden sm:inline text-xs">
            1 Mobile Number = 1 Active Role (Seller, Driver, or Customer). Cannot cross-login without account deletion.
          </span>
        </div>

        <div className="flex items-center gap-2">
          {activeAuthUser ? (
            <div className="flex items-center gap-2 bg-slate-800/80 px-2.5 py-1 rounded-lg border border-slate-700">
              <span className="text-[11px] text-slate-400">Active User:</span>
              <span className="font-semibold text-white text-xs">{activeAuthUser.name}</span>
              {roleBadge(activeAuthUser.role)}
            </div>
          ) : (
            <button
              id="btn-open-auth-modal-topbar"
              onClick={() => openAuthModalFor('customer')}
              className="px-2.5 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs transition-colors"
            >
              Sign In / Register
            </button>
          )}

          <button
            id="btn-toggle-exclusivity-registry-inspector"
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center gap-1 px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700 text-[11px]"
          >
            <span>Live Phone Registry ({registeredAccounts.length})</span>
            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Expandable Live Registry Inspector & Test Bench */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t border-slate-800 bg-white/95 p-4"
          >
            <div className="max-w-7xl mx-auto space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pb-2">
                <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
                  <div className="flex items-center gap-2 text-amber-400 font-semibold text-xs">
                    <Bike className="w-4 h-4" />
                    <span>Rule 1: Driver Cannot Be Customer</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    If a phone is registered to a Driver, they cannot log in to a Customer account. They must first delete their driver account to release the number.
                  </p>
                </div>

                <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
                  <div className="flex items-center gap-2 text-emerald-400 font-semibold text-xs">
                    <Store className="w-4 h-4" />
                    <span>Rule 2: Seller Cannot Be Driver/Customer</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    If a phone is registered to a Seller Store, they cannot log in as a Driver or Customer with the same number until the Seller account is deleted.
                  </p>
                </div>

                <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
                  <div className="flex items-center gap-2 text-blue-400 font-semibold text-xs">
                    <RefreshCw className="w-4 h-4" />
                    <span>Rule 3: Instant Number Release on Deletion</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Deleting a Seller or Driver account immediately frees up the mobile number, allowing immediate registration/login as a Customer.
                  </p>
                </div>
              </div>

              {/* Table of Registered Accounts */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-indigo-400" />
                    <span>Active Mobile Numbers in System Database</span>
                  </h4>
                  <button
                    id="btn-open-auth-modal-tester"
                    onClick={() => openAuthModalFor('customer')}
                    className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1"
                  >
                    <span>Test Login / Registration Flow</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {registeredAccounts.map((acc) => (
                    <div
                      key={acc.id}
                      className="p-3 bg-slate-900/90 border border-slate-800 rounded-xl flex flex-col justify-between gap-2 hover:border-slate-700 transition-colors"
                    >
                      <div>
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className="font-mono text-xs font-bold text-white">{acc.phone}</span>
                          {roleBadge(acc.role)}
                        </div>
                        <div className="text-xs font-semibold text-slate-200">{acc.name}</div>
                        {acc.storeName && (
                          <div className="text-[11px] text-emerald-400 truncate">
                            🏪 {acc.storeName}
                          </div>
                        )}
                        {acc.vehicleNumber && (
                          <div className="text-[11px] text-amber-400">
                            🛵 {acc.vehicleType} • {acc.vehicleNumber}
                          </div>
                        )}
                      </div>

                      <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
                        <button
                          id={`btn-login-with-${acc.id}`}
                          onClick={() => openAuthModalFor(acc.role)}
                          className="text-[11px] text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1"
                        >
                          <span>Log In as {acc.role}</span>
                        </button>

                        <button
                          id={`btn-delete-reg-${acc.id}`}
                          onClick={async () => {
                            if (acc.role === 'driver') {
                              await deleteDriverAccountPermanently(acc.phone);
                            } else if (acc.role === 'seller') {
                              await deleteSellerAccountPermanently(acc.phone);
                            } else {
                              await deleteCustomerAccountPermanently(acc.phone);
                            }
                          }}
                          className="flex items-center gap-1 px-2 py-1 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 hover:text-rose-300 border border-rose-500/30 text-[10px] font-medium transition-colors"
                          title="Delete account to release mobile number"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete ({acc.role})</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
