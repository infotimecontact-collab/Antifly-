import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Radio,
  Eye,
  Heart,
  Send,
  Sparkles,
  ShoppingBag,
  Gift,
  Coins,
  Gem,
  Volume2,
  VolumeX,
  Share2,
  Flame,
  CheckCircle2,
  ArrowRight,
  TrendingUp,
  MessageCircle,
  HelpCircle,
} from 'lucide-react';
import { DEFAULT_LIVE_STREAM_SHOWS } from '../../data/ecosystemData';
import { LiveStreamShow, LiveStreamChatMessage } from '../../types';

export const LiveStreamShoppingModal: React.FC = () => {
  const {
    isLiveShoppingOpen,
    setIsLiveShoppingOpen,
    products,
    addToCart,
    showToast,
    formatPrice,
    superCoinWallet,
    awardSuperCoins,
    redeemDiamonds,
  } = useApp();

  const [activeShowId, setActiveShowId] = useState<string>(DEFAULT_LIVE_STREAM_SHOWS?.[0]?.id || '');
  const [isMuted, setIsMuted] = useState(true);
  const [likesCount, setLikesCount] = useState(39420);
  const [floatingHearts, setFloatingHearts] = useState<{ id: number; x: number }[]>([]);
  const [chatMessages, setChatMessages] = useState<LiveStreamChatMessage[]>([
    {
      id: 'm-1',
      userName: 'Aarohi S.',
      userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100',
      userBadge: 'VIP Platinum',
      message: 'Can you show the pallu border in daylight angle please? 😍',
      timestamp: 'Just now',
    },
    {
      id: 'm-2',
      userName: 'Vikram Joshi',
      userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100',
      userBadge: 'Top Buyer',
      message: 'Booked 2 sarees! That 45% flash discount is unbelievable 🔥',
      timestamp: 'Just now',
      isGift: true,
      giftType: 'diamond',
      giftAmount: 10,
    },
    {
      id: 'm-3',
      userName: 'Ritu Khurana',
      userAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100',
      message: 'Is express 30-min Indore doorstep delivery active tonight?',
      timestamp: '1m ago',
    },
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [selectedPollOption, setSelectedPollOption] = useState<string | null>(null);
  const [flashStock, setFlashStock] = useState(18);

  const activeShow =
    (DEFAULT_LIVE_STREAM_SHOWS || []).find((s) => s.id === activeShowId) ||
    DEFAULT_LIVE_STREAM_SHOWS?.[0] ||
    null;
  const pinnedProduct = (products && products.length > 0)
    ? (products.find((p) => p.id === activeShow?.pinnedProductId) || products?.[0] || null)
    : null;

  // Auto increment likes and simulate incoming chat
  useEffect(() => {
    if (!isLiveShoppingOpen) return;

    const interval = setInterval(() => {
      setLikesCount((prev) => prev + Math.floor(Math.random() * 5) + 1);

      if (Math.random() > 0.6) {
        const names = ['Kavita Rao', 'Mohit Sharma', 'Ananya Mehta', 'Rohan Gupta', 'Sneha Patel'];
        const comments = [
          'The quality is so pure! 💖',
          'Just claimed 50 SuperCoins on live stream drop!',
          'Ordering the emerald one now!',
          'Are there matching jewelry pieces available?',
          'Indore handloom is the best!',
        ];
        const randomName = names[Math.floor(Math.random() * names.length)];
        const randomComment = comments[Math.floor(Math.random() * comments.length)];

        setChatMessages((prev) => [
          ...prev.slice(-15),
          {
            id: `auto-${Date.now()}`,
            userName: randomName,
            message: randomComment,
            timestamp: 'Just now',
          },
        ]);
      }
    }, 3500);

    return () => clearInterval(interval);
  }, [isLiveShoppingOpen]);

  if (!isLiveShoppingOpen) return null;

  const handleSendHeart = () => {
    setLikesCount((prev) => prev + 1);
    const newHeart = { id: Date.now() + Math.random(), x: Math.random() * 60 + 20 };
    setFloatingHearts((prev) => [...prev, newHeart]);
    setTimeout(() => {
      setFloatingHearts((prev) => prev.filter((h) => h.id !== newHeart.id));
    }, 2000);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const newMsg: LiveStreamChatMessage = {
      id: `user-${Date.now()}`,
      userName: 'You (Aarav Sharma)',
      userBadge: 'VIP Gold',
      message: inputMessage.trim(),
      timestamp: 'Just now',
    };

    setChatMessages((prev) => [...prev, newMsg]);
    setInputMessage('');
    awardSuperCoins(5, 'Live Stream Chat Participation');
  };

  const handleSendDiamondGift = (amount: number) => {
    if (superCoinWallet.diamondBalance < amount) {
      showToast(`⚠️ You need ${amount} Diamonds. Current balance: ${superCoinWallet.diamondBalance}`);
      return;
    }

    redeemDiamonds(amount);
    showToast(`💎 Gifted ${amount} Diamonds to Host ${activeShow.hostName}! Host rewarded.`);

    setChatMessages((prev) => [
      ...prev,
      {
        id: `gift-${Date.now()}`,
        userName: 'You (Aarav Sharma)',
        userBadge: 'VIP Diamond Supporter',
        message: `Sent ${amount} 💎 Diamonds to support the live show!`,
        timestamp: 'Just now',
        isGift: true,
        giftType: 'diamond',
        giftAmount: amount,
      },
    ]);

    handleSendHeart();
  };

  const handleBuyFlashProduct = () => {
    if (pinnedProduct) {
      addToCart(pinnedProduct, pinnedProduct.variants?.[0]?.id || 'live-flash-deal');
      if (flashStock > 1) {
        setFlashStock((prev) => prev - 1);
      }
      showToast(`🔥 Live Flash Deal added to cart! Saved ${activeShow.flashDiscountPercent}% extra!`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-white/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-5xl h-[92vh] max-h-[860px] flex flex-col md:flex-row overflow-hidden shadow-2xl relative text-slate-100">
        
        {/* Close Button */}
        <button
          onClick={() => setIsLiveShoppingOpen(false)}
          className="absolute top-4 right-4 z-40 p-2.5 bg-white/80 hover:bg-slate-800 text-white rounded-full transition border border-white/20 shadow-lg cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left / Main Video Stage */}
        <div className="flex-1 relative bg-slate-100 flex flex-col justify-between overflow-hidden">
          {/* Simulated Video Feed */}
          <div className="absolute inset-0 z-0">
            <img
              src={activeShow.thumbnailUrl}
              alt={activeShow.title}
              className="w-full h-full object-cover brightness-90 filter"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-100/90 via-slate-100/30 to-slate-100/60 pointer-events-none" />
          </div>

          {/* Floating Hearts Animation */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden z-20">
            {floatingHearts.map((h) => (
              <div
                key={h.id}
                style={{ left: `${h.x}%` }}
                className="absolute bottom-16 text-rose-500 animate-bounce duration-1000 transform -translate-y-24 opacity-80"
              >
                <Heart className="w-8 h-8 fill-rose-500 text-rose-400" />
              </div>
            ))}
          </div>

          {/* Top Live Overlay Bar */}
          <div className="relative z-10 p-4 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 bg-red-600/90 text-white px-3 py-1 rounded-full text-xs font-black tracking-wider uppercase shadow-lg shadow-red-600/30 animate-pulse">
                <Radio className="w-3.5 h-3.5" />
                <span>LIVE SHOPPING</span>
              </div>
              <div className="flex items-center gap-1.5 bg-slate-100/60 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-slate-200 border border-white/10">
                <Eye className="w-3.5 h-3.5 text-emerald-400" />
                <span>{activeShow.viewerCount.toLocaleString()} watching</span>
              </div>
            </div>

            {/* Live Show Selector Dropdown */}
            <div className="flex items-center gap-2 pr-12 md:pr-0">
              <select
                value={activeShowId}
                onChange={(e) => {
                  setActiveShowId(e.target.value);
                  setFlashStock(18);
                  showToast('Switched Live Stream Showroom');
                }}
                className="bg-slate-100/75 backdrop-blur-md border border-white/20 text-xs font-bold text-white px-3 py-1.5 rounded-xl focus:outline-none"
              >
                {DEFAULT_LIVE_STREAM_SHOWS.map((s) => (
                  <option key={s.id} value={s.id} className="bg-slate-900 text-white">
                    {s.category}: {s.hostName}
                  </option>
                ))}
              </select>
              <button
                onClick={() => setIsMuted(!isMuted)}
                className="p-1.5 bg-slate-100/60 backdrop-blur-md rounded-xl text-slate-300 hover:text-white border border-white/10"
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
              </button>
            </div>
          </div>

          {/* Host Info & Title Card */}
          <div className="relative z-10 p-4 space-y-2">
            <div className="flex items-center gap-3 bg-slate-100/60 backdrop-blur-md p-2 rounded-2xl border border-white/10 max-w-max">
              <img
                src={activeShow.hostAvatar}
                alt={activeShow.hostName}
                className="w-10 h-10 rounded-full object-cover ring-2 ring-amber-400"
              />
              <div>
                <div className="text-xs font-black text-white flex items-center gap-1">
                  <span>{activeShow.hostName}</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
                </div>
                <div className="text-[10px] text-amber-300 font-mono">{activeShow.hostHandle}</div>
              </div>
              <button
                onClick={() => showToast(`⭐ Followed ${activeShow.hostName}! You'll receive live stream notifications.`)}
                className="ml-2 bg-gradient-to-r from-red-600 to-rose-600 text-white text-[11px] font-black px-3 py-1 rounded-xl hover:brightness-110 shadow-sm"
              >
                Follow
              </button>
            </div>

            <h2 className="text-sm sm:text-base font-black text-white drop-shadow-md max-w-xl">
              {activeShow.title}
            </h2>

            {/* Interactive Live Viewer Poll */}
            {activeShow.pollQuestion && (
              <div className="bg-white/85 backdrop-blur-md border border-purple-500/40 rounded-2xl p-3 max-w-md space-y-2">
                <div className="flex items-center gap-1.5 text-purple-300 text-xs font-black">
                  <HelpCircle className="w-3.5 h-3.5 text-purple-400" />
                  <span>Live Audience Poll: {activeShow.pollQuestion}</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  {activeShow.pollOptions?.map((opt) => (
                    <button
                      key={opt.id}
                      onClick={() => {
                        setSelectedPollOption(opt.id);
                        showToast(`🗳️ Vote recorded for "${opt.text}"!`);
                      }}
                      className={`text-left p-2 rounded-xl text-[11px] font-bold transition flex items-center justify-between border ${
                        selectedPollOption === opt.id
                          ? 'bg-purple-600/40 border-purple-400 text-white shadow-xs'
                          : 'bg-slate-900/80 border-slate-700 text-slate-300 hover:border-purple-400'
                      }`}
                    >
                      <span className="truncate">{opt.text}</span>
                      <span className="font-mono text-purple-300 text-[10px]">{opt.votes + (selectedPollOption === opt.id ? 1 : 0)}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Bottom Video Controls: Pinned Live Deal Bar */}
          <div className="relative z-10 p-4">
            {pinnedProduct && (
              <div className="bg-white/95 backdrop-blur-xl border-2 border-amber-500/80 rounded-2xl p-3 shadow-2xl flex items-center justify-between gap-3 animate-in slide-in-from-bottom-2">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative">
                    <img
                      src={pinnedProduct.images?.[0] || pinnedProduct.image}
                      alt={pinnedProduct.name}
                      className="w-14 h-14 rounded-xl object-cover border border-amber-400/50"
                    />
                    <span className="absolute -top-2 -left-2 bg-gradient-to-r from-red-600 to-amber-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded-md uppercase tracking-wider shadow-md">
                      {activeShow.flashDiscountPercent}% OFF
                    </span>
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] font-black uppercase tracking-wider text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded-sm">
                        PINNED LIVE DEAL
                      </span>
                      <span className="text-[10px] font-bold text-rose-400 flex items-center gap-0.5">
                        <Flame className="w-3 h-3" />
                        Only {flashStock} left!
                      </span>
                    </div>
                    <div className="text-xs sm:text-sm font-black text-white truncate max-w-[200px] sm:max-w-[280px]">
                      {pinnedProduct.name}
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-sm sm:text-base font-black text-emerald-400">
                        {formatPrice(Math.round(pinnedProduct.price * (1 - activeShow.flashDiscountPercent / 100)))}
                      </span>
                      <span className="text-xs text-slate-400 line-through">
                        {formatPrice(pinnedProduct.mrp || pinnedProduct.price)}
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleBuyFlashProduct}
                  className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 font-black px-4 py-2.5 rounded-xl text-xs sm:text-sm shadow-xl flex items-center gap-2 whitespace-nowrap cursor-pointer transition hover:scale-105"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Buy Live Deal</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right Live Stream Sidebar: Chat & Gifting Arena */}
        <div className="w-full md:w-80 lg:w-96 bg-slate-900 border-t md:border-t-0 md:border-l border-slate-800 flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-3.5 border-b border-slate-800 flex items-center justify-between bg-white/50">
            <div className="flex items-center gap-2">
              <MessageCircle className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-black uppercase tracking-wider text-slate-200">Live Chat & Reactions</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-rose-400 font-bold">
              <Heart className="w-3.5 h-3.5 fill-rose-500" />
              <span>{likesCount.toLocaleString()}</span>
            </div>
          </div>

          {/* Chat Messages Stream */}
          <div className="flex-1 p-3 space-y-2.5 overflow-y-auto max-h-[320px] md:max-h-none text-xs">
            {chatMessages.map((msg) => (
              <div
                key={msg.id}
                className={`p-2 rounded-xl transition ${
                  msg.isGift
                    ? 'bg-amber-500/10 border border-amber-500/40 text-amber-200'
                    : 'bg-slate-800/60 border border-slate-700/50 text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between gap-1 mb-1">
                  <div className="flex items-center gap-1.5">
                    {msg.userAvatar && (
                      <img src={msg.userAvatar} alt={msg.userName} className="w-4 h-4 rounded-full object-cover" />
                    )}
                    <span className="font-bold text-white text-[11px]">{msg.userName}</span>
                    {msg.userBadge && (
                      <span className="bg-amber-500/20 text-amber-300 text-[9px] font-black px-1.5 py-0.2 rounded-sm">
                        {msg.userBadge}
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">{msg.timestamp}</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">{msg.message}</p>
              </div>
            ))}
          </div>

          {/* Quick Gifting Triggers */}
          <div className="p-2.5 bg-white/70 border-t border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold uppercase tracking-wider px-1">
              <span>Send Live Creator Gift</span>
              <span className="text-amber-400 flex items-center gap-1 font-mono">
                <Gem className="w-3 h-3 text-cyan-400" /> {superCoinWallet.diamondBalance} Diamonds
              </span>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              <button
                onClick={() => handleSendDiamondGift(5)}
                className="p-1.5 bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-500/40 rounded-xl text-cyan-300 font-bold text-[10px] flex items-center justify-center gap-1 transition"
              >
                <Gem className="w-3 h-3 text-cyan-400" />
                <span>5 💎 Tip</span>
              </button>
              <button
                onClick={() => handleSendDiamondGift(20)}
                className="p-1.5 bg-amber-950/40 hover:bg-amber-900/60 border border-amber-500/40 rounded-xl text-amber-300 font-bold text-[10px] flex items-center justify-center gap-1 transition"
              >
                <Sparkles className="w-3 h-3 text-amber-400" />
                <span>20 💎 Crown</span>
              </button>
              <button
                onClick={handleSendHeart}
                className="p-1.5 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-500/40 rounded-xl text-rose-300 font-bold text-[10px] flex items-center justify-center gap-1 transition"
              >
                <Heart className="w-3 h-3 fill-rose-500" />
                <span>Like +1</span>
              </button>
            </div>

            {/* Chat Input */}
            <form onSubmit={handleSendMessage} className="flex items-center gap-1.5 pt-1">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Ask host a question..."
                className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />
              <button
                type="submit"
                className="bg-amber-500 hover:bg-amber-600 text-slate-800 p-2 rounded-xl font-bold transition cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>

        </div>

      </div>
    </div>
  );
};
