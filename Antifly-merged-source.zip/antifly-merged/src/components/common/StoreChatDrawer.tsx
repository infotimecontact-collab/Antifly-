import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { ChatInbox } from '../chat/ChatInbox';
import { ChatConversation } from '../chat/ChatConversation';
import { ActiveCallOverlay } from '../chat/ActiveCallOverlay';
import {
  X,
  Maximize2,
  Minimize2,
  MessageSquare,
  Sparkles,
} from 'lucide-react';
import { StoreChatSession } from '../../types';

export const StoreChatDrawer: React.FC = () => {
  const {
    isStoreChatOpen,
    setIsStoreChatOpen,
    storeChatSessions,
    activeChatSessionId,
    setActiveChatSessionId,
  } = useApp();

  const [isFullScreen, setIsFullScreen] = useState(false);
  const [mobileView, setMobileView] = useState<'inbox' | 'conversation'>('inbox');

  // Sync active session
  const activeSession =
    (storeChatSessions || []).find((s) => s.id === activeChatSessionId) ||
    storeChatSessions?.[0] || null;

  useEffect(() => {
    if (activeChatSessionId) {
      setMobileView('conversation');
    }
  }, [activeChatSessionId]);

  if (!isStoreChatOpen) {
    return <ActiveCallOverlay />;
  }

  const handleSelectChat = (session: StoreChatSession) => {
    setActiveChatSessionId(session.id);
    setMobileView('conversation');
  };

  const handleBackToInbox = () => {
    setMobileView('inbox');
  };

  return (
    <>
      <div
        id="store-chat-drawer-backdrop"
        className="fixed inset-0 z-50 overflow-hidden bg-white/60 backdrop-blur-xs flex justify-end animate-fade-in"
      >
        <div
          id="direct-messaging-hub-container"
          className={`bg-white h-full shadow-2xl flex flex-col border-l border-slate-200 transition-all duration-300 ${
            isFullScreen
              ? 'w-full max-w-6xl mx-auto rounded-none lg:my-6 lg:rounded-3xl lg:border overflow-hidden'
              : 'w-full max-w-xl md:max-w-2xl lg:max-w-4xl'
          }`}
        >
          {/* Global Top Mini Bar for Drawer Controls */}
          <div className="bg-slate-900 text-white px-4 py-2 flex items-center justify-between border-b border-slate-800 shrink-0">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-black tracking-wider uppercase text-slate-200">
                Direct 1-to-1 Messaging
              </span>
              <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full hidden sm:inline">
                End-to-End Encrypted
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setIsFullScreen(!isFullScreen)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
                title={isFullScreen ? 'Exit Full Screen' : 'Full Screen View'}
              >
                {isFullScreen ? (
                  <Minimize2 className="w-4 h-4" />
                ) : (
                  <Maximize2 className="w-4 h-4" />
                )}
              </button>

              <button
                onClick={() => setIsStoreChatOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition cursor-pointer"
                title="Close Chat"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Main Layout: Split view on Desktop, Tabbed on Mobile */}
          <div className="flex-1 flex overflow-hidden relative">
            {/* Left Inbox Column */}
            <div
              className={`w-full md:w-72 lg:w-80 shrink-0 h-full border-r border-slate-200 ${
                mobileView === 'conversation' ? 'hidden md:flex flex-col' : 'flex flex-col'
              }`}
            >
              <ChatInbox
                onSelectChat={handleSelectChat}
                selectedChatId={activeSession?.id || null}
              />
            </div>

            {/* Right Active Conversation Column */}
            <div
              className={`flex-1 h-full flex-col bg-slate-50 ${
                mobileView === 'inbox' ? 'hidden md:flex' : 'flex'
              }`}
            >
              {activeSession ? (
                <ChatConversation
                  session={activeSession}
                  onBack={handleBackToInbox}
                />
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-400">
                  <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 mb-3">
                    <MessageSquare className="w-8 h-8" />
                  </div>
                  <h3 className="text-base font-extrabold text-slate-800 mb-1">
                    Select a Conversation
                  </h3>
                  <p className="text-xs text-slate-500 max-w-xs">
                    Choose an existing chat from the left or click + to start a new 1-to-1 conversation with any customer or verified seller.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Global Active Call Overlay */}
      <ActiveCallOverlay />
    </>
  );
};
