import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Smartphone,
  ShieldCheck,
  AlertTriangle,
  Lock,
  ArrowRight,
  User,
  Store,
  Bike,
  CheckCircle2,
  Trash2,
  Sparkles,
  Info,
  KeyRound,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    setIsAuthModalOpen,
    authModalTargetRole,
    setAuthModalTargetRole,
    registeredAccounts,
    activeAuthUser,
    checkPhoneConflict,
    loginWithPhone,
    registerRoleAccount,
    deleteDriverAccountPermanently,
    deleteSellerAccountPermanently,
    deleteCustomerAccountPermanently,
    logoutAuthUser,
    setDeviceMode,
  } = useApp();

  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [phone, setPhone] = useState<string>('');
  const [name, setName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [storeName, setStoreName] = useState<string>('');
  const [storeCategory, setStoreCategory] = useState<string>('electrical');
  const [vehicleType, setVehicleType] = useState<string>('Electric Bike');
  const [vehicleNumber, setVehicleNumber] = useState<string>('MP-09-EV-2024');
  const [otpStep, setOtpStep] = useState<boolean>(false);
  const [generatedOtp, setGeneratedOtp] = useState<string>('');
  const [enteredOtp, setEnteredOtp] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [successMessage, setSuccessMessage] = useState<string>('');

  // Reset inputs when modal opens or target role changes
  useEffect(() => {
    if (isAuthModalOpen) {
      setErrorMessage('');
      setSuccessMessage('');
      setOtpStep(false);
      setEnteredOtp('');
      if (!phone) {
        if (authModalTargetRole === 'customer') setPhone('9826099881');
        else if (authModalTargetRole === 'seller') setPhone('9826077881');
        else if (authModalTargetRole === 'driver') setPhone('9827033441');
      }
    }
  }, [isAuthModalOpen, authModalTargetRole]);

  if (!isAuthModalOpen) return null;

  const conflictCheck = checkPhoneConflict(phone, authModalTargetRole);

  const handleSendOtp = () => {
    setErrorMessage('');
    if (!phone || phone.replace(/\D/g, '').length < 10) {
      setErrorMessage('Please enter a valid 10-digit mobile number.');
      return;
    }

    if (conflictCheck.hasConflict) {
      setErrorMessage(conflictCheck.conflictMessage || 'Role exclusivity conflict.');
      return;
    }

    if (authMode === 'register' && !name.trim()) {
      setErrorMessage('Please provide your Full Name to complete registration.');
      return;
    }

    // Generate 4-digit OTP
    const mockOtp = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(mockOtp);
    setOtpStep(true);
    setSuccessMessage(`OTP sent to +91 ${phone.slice(-10)} (Security Code: ${mockOtp})`);
  };

  const handleVerifyAndSubmit = async () => {
    setErrorMessage('');
    if (enteredOtp !== generatedOtp && enteredOtp !== '1234') {
      setErrorMessage(`Invalid OTP code! Please enter ${generatedOtp}`);
      return;
    }

    if (authMode === 'login') {
      const res = await loginWithPhone(phone, authModalTargetRole);
      if (res.success) {
        setSuccessMessage(res.message);
        setTimeout(() => setIsAuthModalOpen(false), 900);
      } else {
        setErrorMessage(res.message);
      }
    } else {
      const res = await registerRoleAccount({
        phone: `+91 ${phone.replace(/\D/g, '').slice(-10)}`,
        role: authModalTargetRole,
        name: name.trim() || 'Valued Partner',
        email: email.trim() || `${authModalTargetRole}@antifly.com`,
        storeName: storeName.trim() || name,
        category: storeCategory,
        vehicleType,
        vehicleNumber,
        city: 'Indore',
      });

      if (res.success) {
        setSuccessMessage(res.message);
        setTimeout(() => setIsAuthModalOpen(false), 900);
      } else {
        setErrorMessage(res.message);
      }
    }
  };

  const handleQuickFill = (testPhone: string, testRole: UserRole, testName: string) => {
    setPhone(testPhone.replace(/\D/g, '').slice(-10));
    setAuthModalTargetRole(testRole);
    setName(testName);
    setOtpStep(false);
    setErrorMessage('');
    setSuccessMessage('');
  };

  return (
    <div
      id="auth-exclusivity-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-100/75 backdrop-blur-sm"
      onClick={() => setIsAuthModalOpen(false)}
    >
      <motion.div
        id="auth-modal-content-card"
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.2 }}
        className="w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-slate-100 flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 p-5 border-b border-slate-700/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Unified Mobile Authentication
                <span className="text-xs px-2 py-0.5 rounded-full font-mono bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  1 Phone = 1 Role
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Strict Mobile Number Role-Exclusivity Security Engine
              </p>
            </div>
          </div>
          <button
            id="btn-close-auth-modal"
            onClick={() => setIsAuthModalOpen(false)}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1 custom-scrollbar">
          {/* Target Role Selector Tabs */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Select Portal / Application Role
            </label>
            <div className="grid grid-cols-3 gap-2 p-1 bg-white/70 border border-slate-800 rounded-xl">
              <button
                id="btn-tab-role-customer"
                onClick={() => {
                  setAuthModalTargetRole('customer');
                  setOtpStep(false);
                  setErrorMessage('');
                }}
                className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg font-medium text-xs transition-all ${
                  authModalTargetRole === 'customer'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <User className="w-4 h-4" />
                <span>Customer</span>
              </button>

              <button
                id="btn-tab-role-seller"
                onClick={() => {
                  setAuthModalTargetRole('seller');
                  setOtpStep(false);
                  setErrorMessage('');
                }}
                className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg font-medium text-xs transition-all ${
                  authModalTargetRole === 'seller'
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Store className="w-4 h-4" />
                <span>Venture</span>
              </button>

              <button
                id="btn-tab-role-driver"
                onClick={() => {
                  setAuthModalTargetRole('driver');
                  setOtpStep(false);
                  setErrorMessage('');
                }}
                className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg font-medium text-xs transition-all ${
                  authModalTargetRole === 'driver'
                    ? 'bg-amber-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Bike className="w-4 h-4" />
                <span>Buddy</span>
              </button>
            </div>
          </div>

          {/* Login vs Register Switch */}
          <div className="flex border-b border-slate-800 text-sm">
            <button
              id="btn-auth-mode-login"
              onClick={() => {
                setAuthMode('login');
                setOtpStep(false);
                setErrorMessage('');
              }}
              className={`pb-2.5 px-4 font-semibold transition-colors border-b-2 ${
                authMode === 'login'
                  ? 'border-indigo-500 text-indigo-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Sign In with Mobile
            </button>
            <button
              id="btn-auth-mode-register"
              onClick={() => {
                setAuthMode('register');
                setOtpStep(false);
                setErrorMessage('');
              }}
              className={`pb-2.5 px-4 font-semibold transition-colors border-b-2 ${
                authMode === 'register'
                  ? 'border-indigo-500 text-indigo-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Register New {authModalTargetRole.toUpperCase()}
            </button>
          </div>

          {/* Active User Status (if logged in) */}
          {activeAuthUser && (
            <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-xl flex items-center justify-between text-xs">
              <div className="flex items-center gap-2.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                <div>
                  <div className="font-semibold text-slate-200">
                    Currently Logged In: <span className="text-white">{activeAuthUser.name}</span> (
                    <span className="capitalize text-indigo-300">{activeAuthUser.role}</span>)
                  </div>
                  <div className="text-slate-400">{activeAuthUser.phone}</div>
                </div>
              </div>
              <button
                id="btn-auth-logout"
                onClick={logoutAuthUser}
                className="px-2.5 py-1 rounded-md bg-rose-500/20 text-rose-300 border border-rose-500/30 hover:bg-rose-500/30 transition-colors"
              >
                Logout
              </button>
            </div>
          )}

          {/* Live Role-Conflict Warning Banner */}
          {conflictCheck.hasConflict && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 bg-amber-950/40 border border-amber-600/50 rounded-xl text-amber-200 text-xs space-y-2.5"
            >
              <div className="flex items-start gap-2.5 font-semibold text-amber-300">
                <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
                <span>ROLE EXCLUSIVITY RESTRICTION ACTIVE</span>
              </div>
              <p className="leading-relaxed text-slate-300">
                {conflictCheck.conflictMessage}
              </p>

              {/* Action buttons to resolve conflict by deleting conflicting account */}
              <div className="pt-2 border-t border-amber-800/40 flex flex-wrap items-center gap-2">
                <span className="text-[11px] text-amber-400 font-medium">Resolution Options:</span>
                {conflictCheck.activeRole === 'driver' && (
                  <button
                    id="btn-resolve-delete-driver"
                    onClick={async () => {
                      await deleteDriverAccountPermanently(phone);
                      setErrorMessage('');
                      setSuccessMessage('Buddy account deleted. Phone number is now free!');
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-medium transition-colors shadow-sm"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Delete Buddy Account to Free Number
                  </button>
                )}

                {conflictCheck.activeRole === 'seller' && (
                  <button
                    id="btn-resolve-delete-seller"
                    onClick={async () => {
                      await deleteSellerAccountPermanently(phone);
                      setErrorMessage('');
                      setSuccessMessage('Venture profile deleted. Phone number is now free!');
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-medium transition-colors shadow-sm"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Delete Venture to Free Number
                  </button>
                )}

                {conflictCheck.activeRole === 'customer' && (
                  <button
                    id="btn-resolve-delete-customer"
                    onClick={async () => {
                      await deleteCustomerAccountPermanently(phone);
                      setErrorMessage('');
                      setSuccessMessage('Customer account deleted. Phone number is now free!');
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-medium transition-colors shadow-sm"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Delete Customer Account to Free Number
                  </button>
                )}
              </div>
            </motion.div>
          )}

          {/* Form Inputs */}
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                Mobile Number (India)
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-3 flex items-center gap-1.5 text-slate-400 font-mono text-sm border-r border-slate-700 pr-2">
                  <span>🇮🇳</span>
                  <span>+91</span>
                </div>
                <input
                  id="input-auth-phone"
                  type="tel"
                  maxLength={10}
                  placeholder="98260 00000"
                  value={phone}
                  onChange={(e) => {
                    setPhone(e.target.value.replace(/\D/g, ''));
                    setErrorMessage('');
                    setSuccessMessage('');
                  }}
                  className={`w-full bg-white/80 border pl-20 pr-4 py-2.5 rounded-xl font-mono text-sm text-white placeholder-slate-600 focus:outline-none transition-colors ${
                    conflictCheck.hasConflict
                      ? 'border-amber-500/80 focus:border-amber-400'
                      : 'border-slate-700 focus:border-indigo-500'
                  }`}
                />
              </div>
              <div className="mt-1 flex items-center justify-between text-[11px] text-slate-400">
                <span>Must be unique across Customer, Venture, and Buddy roles</span>
                {conflictCheck.isRegisteredForTargetRole && (
                  <span className="text-emerald-400 flex items-center gap-1 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Verified {authModalTargetRole === 'seller' ? 'Venture' : authModalTargetRole === 'driver' ? 'Buddy' : 'Customer'}
                  </span>
                )}
              </div>
            </div>

            {/* Registration Extra Fields */}
            {authMode === 'register' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="space-y-3.5 pt-1"
              >
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">
                    {authModalTargetRole === 'seller' ? 'Venture Proprietor / Contact Name' : 'Full Name'}
                  </label>
                  <input
                    id="input-auth-name"
                    type="text"
                    placeholder="e.g. Rajesh Kumar"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-white/80 border border-slate-700 px-3.5 py-2.5 rounded-xl text-sm text-white placeholder-slate-600 focus:border-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">
                    Email Address
                  </label>
                  <input
                    id="input-auth-email"
                    type="email"
                    placeholder="e.g. partner@antifly.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-white/80 border border-slate-700 px-3.5 py-2.5 rounded-xl text-sm text-white placeholder-slate-600 focus:border-indigo-500 focus:outline-none"
                  />
                </div>

                {authModalTargetRole === 'seller' && (
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-400 mb-1">
                        Venture / Brand Name
                      </label>
                      <input
                        id="input-auth-store-name"
                        type="text"
                        placeholder="e.g. Malwa Electric Mart"
                        value={storeName}
                        onChange={(e) => setStoreName(e.target.value)}
                        className="w-full bg-white/80 border border-slate-700 px-3 py-2 rounded-xl text-xs text-white placeholder-slate-600 focus:border-emerald-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-400 mb-1">
                        Primary Category
                      </label>
                      <select
                        id="select-auth-store-category"
                        value={storeCategory}
                        onChange={(e) => setStoreCategory(e.target.value)}
                        className="w-full bg-white/80 border border-slate-700 px-3 py-2 rounded-xl text-xs text-white focus:border-emerald-500 focus:outline-none"
                      >
                        <option value="electrical">⚡ Electrical & Electrician</option>
                        <option value="cosmetics">💄 Cosmetics & Beauty</option>
                        <option value="ethnic-wear">👗 Cloth & Handloom</option>
                        <option value="furniture">🪑 Furniture & Living</option>
                        <option value="commercial-hardware">🛠️ Commercial Hardware</option>
                        <option value="electronics">📱 Electronics & Audio</option>
                      </select>
                    </div>
                  </div>
                )}

                {authModalTargetRole === 'driver' && (
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-400 mb-1">
                        Vehicle Type
                      </label>
                      <select
                        id="select-auth-vehicle-type"
                        value={vehicleType}
                        onChange={(e) => setVehicleType(e.target.value)}
                        className="w-full bg-white/80 border border-slate-700 px-3 py-2 rounded-xl text-xs text-white focus:border-amber-500 focus:outline-none"
                      >
                        <option value="Electric Bike">⚡ Electric Bike (EV)</option>
                        <option value="EV Scooter">🛵 EV Scooter</option>
                        <option value="Motorcycle">🏍️ Petrol Motorcycle</option>
                        <option value="Delivery Van">🚐 Mini Delivery Van</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-400 mb-1">
                        Vehicle Number
                      </label>
                      <input
                        id="input-auth-vehicle-num"
                        type="text"
                        placeholder="MP-09-EV-8899"
                        value={vehicleNumber}
                        onChange={(e) => setVehicleNumber(e.target.value)}
                        className="w-full bg-white/80 border border-slate-700 px-3 py-2 rounded-xl text-xs text-white placeholder-slate-600 focus:border-amber-500 focus:outline-none uppercase font-mono"
                      />
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {/* OTP Verification Step */}
            {otpStep && (
              <motion.div
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-4 bg-indigo-950/40 border border-indigo-500/40 rounded-xl space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-indigo-300 flex items-center gap-1.5">
                    <KeyRound className="w-4 h-4" /> Enter 4-Digit Security OTP
                  </span>
                  <button
                    id="btn-autofill-otp"
                    onClick={() => setEnteredOtp(generatedOtp)}
                    className="text-[11px] px-2 py-0.5 rounded bg-indigo-500/30 text-indigo-200 hover:bg-indigo-500/50 transition-colors"
                  >
                    Auto-Fill ({generatedOtp})
                  </button>
                </div>
                <input
                  id="input-auth-otp"
                  type="text"
                  maxLength={4}
                  placeholder="• • • •"
                  value={enteredOtp}
                  onChange={(e) => setEnteredOtp(e.target.value)}
                  className="w-full bg-white border border-indigo-500/60 py-2.5 text-center font-mono text-2xl tracking-[0.5em] text-white rounded-xl focus:outline-none"
                />
              </motion.div>
            )}

            {/* Feedback Messages */}
            {errorMessage && (
              <div className="p-3 bg-rose-950/50 border border-rose-600/50 text-rose-200 text-xs rounded-xl flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}

            {successMessage && (
              <div className="p-3 bg-emerald-950/50 border border-emerald-600/50 text-emerald-200 text-xs rounded-xl flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
                <span>{successMessage}</span>
              </div>
            )}

            {/* Primary Action Button */}
            {!otpStep ? (
              <button
                id="btn-send-auth-otp"
                disabled={conflictCheck.hasConflict}
                onClick={handleSendOtp}
                className={`w-full py-3 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all shadow-lg ${
                  conflictCheck.hasConflict
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                    : authModalTargetRole === 'customer'
                    ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-900/30'
                    : authModalTargetRole === 'seller'
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/30'
                    : 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-900/30'
                }`}
              >
                <span>Continue & Get OTP</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                id="btn-verify-auth-otp"
                onClick={handleVerifyAndSubmit}
                className={`w-full py-3 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all shadow-lg ${
                  authModalTargetRole === 'customer'
                    ? 'bg-blue-600 hover:bg-blue-500 text-white'
                    : authModalTargetRole === 'seller'
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    : 'bg-amber-600 hover:bg-amber-500 text-white'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {authMode === 'login'
                    ? `Log In as ${authModalTargetRole === 'seller' ? 'VENTURE' : authModalTargetRole === 'driver' ? 'BUDDY' : 'CUSTOMER'}`
                    : `Create ${authModalTargetRole === 'seller' ? 'VENTURE' : authModalTargetRole === 'driver' ? 'BUDDY' : 'CUSTOMER'} Account`}
                </span>
              </button>
            )}
          </div>

          {/* Preset Test Numbers for Quick Testing */}
          <div className="pt-4 border-t border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-semibold text-slate-300">Quick Test Exclusivity Numbers</span>
              <span>Tap to auto-fill</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                id="btn-test-num-driver-aman"
                onClick={() => handleQuickFill('9827033441', 'customer', 'Aman Soni')}
                className="p-2.5 rounded-xl bg-white border border-slate-800 hover:border-amber-500/50 text-left transition-colors group"
              >
                <div className="flex items-center justify-between text-amber-400 font-semibold text-[11px]">
                  <span>🛵 Buddy: Aman Soni</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300">Buddy</span>
                </div>
                <div className="font-mono text-slate-300 text-[11px] mt-0.5">+91 98270 33441</div>
                <div className="text-[10px] text-slate-500 mt-1">Try in Customer mode to test conflict</div>
              </button>

              <button
                id="btn-test-num-seller-indore"
                onClick={() => handleQuickFill('9826077881', 'customer', 'Indore Electric')}
                className="p-2.5 rounded-xl bg-white border border-slate-800 hover:border-emerald-500/50 text-left transition-colors group"
              >
                <div className="flex items-center justify-between text-emerald-400 font-semibold text-[11px]">
                  <span>⚡ Venture: Indore Electric</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300">Venture</span>
                </div>
                <div className="font-mono text-slate-300 text-[11px] mt-0.5">+91 98260 77881</div>
                <div className="text-[10px] text-slate-500 mt-1">Try in Customer mode to test conflict</div>
              </button>

              <button
                id="btn-test-num-customer-priya"
                onClick={() => handleQuickFill('9826099881', 'driver', 'Priya Sharma')}
                className="p-2.5 rounded-xl bg-white border border-slate-800 hover:border-blue-500/50 text-left transition-colors group"
              >
                <div className="flex items-center justify-between text-blue-400 font-semibold text-[11px]">
                  <span>🛍️ Customer: Priya Sharma</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300">Customer</span>
                </div>
                <div className="font-mono text-slate-300 text-[11px] mt-0.5">+91 98260 99881</div>
                <div className="text-[10px] text-slate-500 mt-1">Try in Buddy mode to test conflict</div>
              </button>

              <button
                id="btn-test-num-fresh"
                onClick={() => handleQuickFill('9900012345', 'customer', 'New User')}
                className="p-2.5 rounded-xl bg-white border border-slate-800 hover:border-indigo-500/50 text-left transition-colors group"
              >
                <div className="flex items-center justify-between text-indigo-400 font-semibold text-[11px]">
                  <span>🆕 Fresh Clean Number</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300">Available</span>
                </div>
                <div className="font-mono text-slate-300 text-[11px] mt-0.5">+91 99000 12345</div>
                <div className="text-[10px] text-slate-500 mt-1">Unregistered, valid for any role</div>
              </button>
            </div>
          </div>
        </div>

        {/* Footer Rules Note */}
        <div className="p-3.5 bg-white/80 border-t border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
          <Info className="w-4 h-4 shrink-0 text-slate-500" />
          <span>
            Strict Platform Policy: A phone number can only belong to <strong>one active role</strong> (Customer, Venture, or Buddy). To switch roles, delete the active account first.
          </span>
        </div>
      </motion.div>
    </div>
  );
};
