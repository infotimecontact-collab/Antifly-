import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  QrCode,
  CheckCircle2,
  Copy,
  ExternalLink,
  ShieldCheck,
  Smartphone,
  IndianRupee,
  Store,
  Sparkles,
  MessageSquare,
  BadgePercent,
  Check,
} from 'lucide-react';
import { SellerProfile } from '../../types';

interface DirectSellerPaymentModalProps {
  seller: SellerProfile | null;
  isOpen: boolean;
  onClose: () => void;
  defaultAmount?: number;
  productName?: string;
}

export const DirectSellerPaymentModal: React.FC<DirectSellerPaymentModalProps> = ({
  seller,
  isOpen,
  onClose,
  defaultAmount,
  productName,
}) => {
  const { openStoreChat, showToast } = useApp();
  const [customAmount, setCustomAmount] = useState<string>(
    defaultAmount ? defaultAmount.toString() : '500'
  );
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [isPaidConfirmed, setIsPaidConfirmed] = useState(false);

  if (!isOpen || !seller) return null;

  const upiId =
    seller.storeUpiId ||
    `${seller.storeName.toLowerCase().replace(/[^a-z0-9]/g, '')}@okaxis`;

  const amountNum = parseFloat(customAmount) || 0;
  const upiLink = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(
    seller.storeName
  )}&am=${amountNum}&cu=INR&tn=${encodeURIComponent(
    productName ? `Payment for ${productName}` : `Antifly direct payment to ${seller.storeName}`
  )}`;

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(upiId);
    setCopiedUpi(true);
    showToast(`Copied UPI ID: ${upiId}`);
    setTimeout(() => setCopiedUpi(false), 2500);
  };

  const handleConfirmPaid = () => {
    setIsPaidConfirmed(true);
    showToast(`Payment of ₹${amountNum} recorded! Venture notified via direct chat.`);
    setTimeout(() => {
      onClose();
      setIsPaidConfirmed(false);
      openStoreChat(seller.id);
    }, 1200);
  };

  return (
    <div
      id="direct-seller-payment-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/70 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-red-600 to-rose-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-extrabold text-base tracking-tight text-white">
                  Direct Venture UPI Payment
                </h3>
                <span className="text-[10px] bg-amber-400 text-slate-800 font-black px-1.5 py-0.2 rounded-full uppercase">
                  0% Fee
                </span>
              </div>
              <p className="text-xs text-rose-100 font-medium">
                Pay directly to {seller.storeName}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-rose-100 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          {/* Venture Info Banner */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-red-100 text-red-600 flex items-center justify-center font-black text-base border border-red-200 flex-shrink-0">
                {seller.storeName.charAt(0)}
              </div>
              <div>
                <div className="flex items-center gap-1">
                  <h4 className="font-black text-sm text-slate-900">{seller.storeName}</h4>
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 fill-blue-50" />
                </div>
                <p className="text-xs text-slate-500 font-semibold">
                  📍 {seller.city || 'Indore'} &bull; 7-Day Guaranteed Exchange
                </p>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                Direct Venture
              </span>
            </div>
          </div>

          {/* Product note if provided */}
          {productName && (
            <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 font-semibold flex items-center justify-between">
              <span>Item: <strong>{productName}</strong></span>
              <span>7-Day Return/Exchange Guaranteed</span>
            </div>
          )}

          {/* Amount input */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">Enter Payment Amount (₹ INR):</label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-extrabold text-sm">
                ₹
              </span>
              <input
                type="number"
                value={customAmount}
                onChange={(e) => setCustomAmount(e.target.value)}
                min="1"
                placeholder="Enter amount"
                className="w-full pl-8 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-extrabold text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
              />
            </div>
          </div>

          {/* High-Res QR Code Card */}
          <div className="bg-white border-2 border-dashed border-red-300 rounded-3xl p-5 flex flex-col items-center justify-center space-y-3 shadow-inner">
            <div className="relative p-3 bg-white border border-slate-200 rounded-2xl shadow-sm">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(
                  upiLink
                )}`}
                alt="Venture Payment QR"
                className="w-44 h-44 object-contain rounded-lg"
              />
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
                <IndianRupee className="w-12 h-12 text-slate-900" />
              </div>
            </div>

            <div className="text-center space-y-1">
              <div className="flex items-center justify-center gap-2">
                <span className="text-xs font-bold text-slate-600">Venture UPI ID:</span>
                <code className="text-xs font-black text-red-600 bg-red-50 px-2 py-0.5 rounded-lg border border-red-200">
                  {upiId}
                </code>
                <button
                  onClick={handleCopyUpi}
                  className="p-1 rounded-md text-slate-500 hover:text-red-600 hover:bg-slate-100 transition cursor-pointer"
                  title="Copy UPI ID"
                >
                  {copiedUpi ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              <p className="text-[11px] text-slate-500 font-medium">
                Scan with Google Pay, PhonePe, Paytm, BHIM, or any UPI App
              </p>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="grid grid-cols-2 gap-2.5">
            <a
              href={upiLink}
              target="_blank"
              rel="noopener noreferrer"
              className="py-2.5 px-3 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white rounded-2xl text-xs font-black flex items-center justify-center gap-1.5 shadow-sm transition"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Open UPI App</span>
            </a>

            <button
              onClick={handleConfirmPaid}
              className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl text-xs font-black flex items-center justify-center gap-1.5 shadow-sm transition cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{isPaidConfirmed ? 'Verified!' : 'I Have Paid'}</span>
            </button>
          </div>

          {/* Freedom & Friendly Communication Note */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl text-[11px] text-slate-600 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-slate-800">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>100% Direct & Transparent Shopping</span>
            </div>
            <p>
              Direct payment connects you straight to the venture without middleman deductions. You also enjoy the <strong>Mandatory 7-Day Return / 1-Click Exchange Guarantee</strong>!
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs">
          <button
            onClick={() => {
              onClose();
              openStoreChat(seller.id);
            }}
            className="text-red-600 hover:text-red-700 font-extrabold flex items-center gap-1 cursor-pointer"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Chat & Bargain with Venture</span>
          </button>

          <button
            onClick={onClose}
            className="text-slate-600 hover:text-slate-900 font-bold cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
