import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  X,
  Heart,
  Eye,
  ShoppingBag,
  Share2,
  CheckCircle2,
  Tag,
  ArrowRight,
  TrendingUp,
  Flame,
  Layers,
} from 'lucide-react';

export const MyntraStudioModal: React.FC = () => {
  const {
    isStyleCastModalOpen,
    setIsStyleCastModalOpen,
    styleCastLooks,
    activeStyleLook,
    setActiveStyleLook,
    products,
    addToCart,
    lookBundles,
    addBundleToCart,
    showToast,
    formatPrice,
  } = useApp();

  const [selectedOccasion, setSelectedOccasion] = useState<string>('all');
  const [likedLooks, setLikedLooks] = useState<string[]>(['look-01']);

  if (!isStyleCastModalOpen) return null;

  const currentLook = activeStyleLook || (styleCastLooks && styleCastLooks.length > 0 ? styleCastLooks?.[0] : null);

  if (!currentLook) return null;

  const filteredLooks = styleCastLooks.filter((l) => {
    if (selectedOccasion === 'all') return true;
    return l.occasion === selectedOccasion;
  });

  const taggedProducts = products.filter((p) => currentLook.taggedProductIds?.includes(p.id));
  const isLiked = likedLooks.includes(currentLook.id);

  const toggleLike = () => {
    if (isLiked) {
      setLikedLooks(likedLooks.filter((id) => id !== currentLook.id));
    } else {
      setLikedLooks([...likedLooks, currentLook.id]);
      showToast('❤️ Added look to your StyleCast moodboard');
    }
  };

  const matchingBundle = (lookBundles || []).find(
    (b) => currentLook?.taggedProductIds?.[0] && b.mainProductId === currentLook?.taggedProductIds?.[0]
  );

  return (
    <div
      id="myntra-studio-modal"
      className="fixed inset-0 z-50 bg-white/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 lg:p-6 animate-fade-in"
    >
      <div className="bg-white dark:bg-slate-900 w-full max-w-5xl rounded-3xl shadow-2xl border border-stone-200 dark:border-slate-800 overflow-hidden flex flex-col my-auto max-h-[92vh]">
        {/* WiseStyle Studio Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-pink-500 via-red-500 to-yellow-500 flex items-center justify-center text-white font-black text-sm shadow-md">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-pink-100 dark:bg-pink-950 text-pink-700 dark:text-pink-300 px-2 py-0.5 rounded-md">
                  WiseStyle Studio
                </span>
                <span className="text-[11px] font-bold text-stone-500 dark:text-slate-400">
                  Curated Creator Runway & Lookbooks
                </span>
              </div>
              <h3 className="font-extrabold text-stone-900 dark:text-white text-base">
                Shop The Full Outfit & Trend Reels
              </h3>
            </div>
          </div>

          <button
            onClick={() => setIsStyleCastModalOpen(false)}
            className="p-2 rounded-full hover:bg-stone-100 dark:hover:bg-slate-800 text-stone-500 transition"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Occasion Filter Pills */}
        <div className="flex items-center gap-2 px-6 py-2.5 bg-stone-50 dark:bg-white border-b border-stone-200 dark:border-slate-800 overflow-x-auto flex-shrink-0">
          {['all', 'Festive Glam', 'Streetwear Casual', 'Old Money', 'Workplace Chic'].map((occ) => (
            <button
              key={occ}
              onClick={() => setSelectedOccasion(occ)}
              className={`px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap transition ${
                selectedOccasion === occ
                  ? 'bg-stone-900 dark:bg-white text-white dark:text-slate-900 shadow-sm'
                  : 'bg-stone-200/70 dark:bg-slate-800 text-stone-600 dark:text-slate-300 hover:bg-stone-300/70'
              }`}
            >
              {occ === 'all' ? 'All Occasions' : occ}
            </button>
          ))}
        </div>

        {/* Studio Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 overflow-y-auto flex-1">
          {/* Left Column: Creator Visual Stage */}
          <div className="lg:col-span-5 bg-stone-950 flex flex-col justify-between p-6 relative overflow-hidden text-white min-h-[380px]">
            <img
              src={currentLook.coverImage}
              alt={currentLook.title}
              className="absolute inset-0 w-full h-full object-cover opacity-80"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

            {/* Top tags */}
            <div className="relative z-10 flex justify-between items-start">
              <span className="px-3 py-1 rounded-full bg-slate-100/60 backdrop-blur-md text-[11px] font-bold text-pink-300 border border-pink-500/30">
                ✨ {currentLook.occasion}
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={toggleLike}
                  className="p-2.5 rounded-full bg-slate-100/60 backdrop-blur-md hover:bg-pink-600 transition"
                  title="Like"
                >
                  <Heart className={`w-4 h-4 ${isLiked ? 'text-pink-500 fill-pink-500' : 'text-white'}`} />
                </button>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(window.location.href);
                    showToast('🔗 Lookbook link copied to share!');
                  }}
                  className="p-2.5 rounded-full bg-slate-100/60 backdrop-blur-md hover:bg-white/20 transition"
                  title="Share"
                >
                  <Share2 className="w-4 h-4 text-white" />
                </button>
              </div>
            </div>

            {/* Bottom creator info */}
            <div className="relative z-10 space-y-3">
              <div className="flex items-center gap-3">
                <img
                  src={currentLook.influencerAvatar}
                  alt={currentLook.influencerName}
                  className="w-10 h-10 rounded-full border-2 border-pink-500 object-cover shadow-lg"
                />
                <div>
                  <h4 className="font-bold text-sm text-white">{currentLook.influencerName}</h4>
                  <p className="text-xs text-pink-300 font-medium">{currentLook.influencerHandle}</p>
                </div>
                <div className="ml-auto flex items-center gap-3 text-xs text-stone-300">
                  <span className="flex items-center gap-1">
                    <Eye className="w-3.5 h-3.5" /> {currentLook.viewsCount}
                  </span>
                  <span className="flex items-center gap-1">
                    <Heart className="w-3.5 h-3.5 text-pink-400 fill-pink-400" /> {currentLook.likesCount.toLocaleString()}
                  </span>
                </div>
              </div>

              <h3 className="font-black text-lg text-white leading-snug">{currentLook.title}</h3>
            </div>
          </div>

          {/* Right Column: Tagged Items & Complete Look Checkout */}
          <div className="lg:col-span-7 p-6 space-y-6 bg-white dark:bg-slate-900 flex flex-col justify-between">
            <div className="space-y-6">
              {/* Creator Styling Notes */}
              <div className="bg-stone-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-stone-200 dark:border-slate-800">
                <h4 className="font-bold text-xs uppercase tracking-wider text-stone-600 dark:text-slate-400 mb-2 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  Styling Notes by {currentLook.influencerName}
                </h4>
                <ul className="space-y-1.5 text-xs text-stone-700 dark:text-slate-300">
                  {currentLook.stylingTips.map((tip, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-pink-500 font-bold">•</span>
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Tagged Outfits List */}
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <h4 className="font-bold text-xs uppercase tracking-wider text-stone-600 dark:text-slate-400">
                    Tagged Items In This Look ({taggedProducts.length})
                  </h4>
                  <span className="text-[11px] font-bold text-pink-600 dark:text-pink-400">
                    Bundle Discount: {currentLook.bundleDiscountPercentage}% OFF
                  </span>
                </div>

                <div className="space-y-2.5">
                  {taggedProducts.map((p) => (
                    <div
                      key={p.id}
                      className="p-3 rounded-2xl border border-stone-200 dark:border-slate-800 flex items-center justify-between gap-3 bg-stone-50/50 dark:bg-slate-800/40 hover:border-pink-300 transition"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <img src={p.images?.[0] || p.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200'} alt={p.name} className="w-14 h-14 rounded-xl object-cover" />
                        <div className="min-w-0">
                          <p className="font-bold text-stone-900 dark:text-white text-xs truncate">{p.name}</p>
                          <p className="text-[11px] text-stone-400">{p.brand}</p>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="font-black text-xs text-stone-900 dark:text-white">{formatPrice(p.price)}</span>
                            <span className="text-[10px] text-stone-400 line-through">{formatPrice(p.mrp)}</span>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() =>
                          addToCart({
                            productId: p.id,
                            variantId: p.variants?.[0]?.id || 'v1',
                            productName: p.name,
                            brand: p.brand,
                            color: p.colors?.[0]?.name || 'Standard',
                            size: p.sizes?.[0] || 'M',
                            price: p.price,
                            mrp: p.mrp,
                            image: p.images?.[0] || p.image || '',
                            quantity: 1,
                            stock: 20,
                          })
                        }
                        className="px-3 py-1.5 rounded-xl bg-stone-900 dark:bg-white text-white dark:text-slate-900 hover:bg-pink-600 dark:hover:bg-pink-400 dark:hover:text-white text-xs font-bold transition flex items-center gap-1 whitespace-nowrap"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                        Add Item
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Complete The Look Action CTA */}
            {matchingBundle && (
              <div className="p-4 rounded-2xl bg-gradient-to-r from-pink-50 via-rose-50 to-amber-50 dark:from-pink-950/40 dark:to-amber-950/30 border border-pink-200 dark:border-pink-900/50 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-1.5 text-[11px] font-black text-pink-700 dark:text-pink-300 uppercase">
                    <Flame className="w-4 h-4 text-pink-600 fill-pink-500" />
                    Complete Set Special Offer
                  </div>
                  <h5 className="font-extrabold text-sm text-stone-900 dark:text-white">
                    Buy Complete {matchingBundle.title} & Save {matchingBundle.bundleDiscountPercent}%
                  </h5>
                </div>

                <button
                  onClick={() => addBundleToCart(matchingBundle.id)}
                  className="w-full sm:w-auto px-5 py-2.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white font-bold text-xs rounded-xl shadow-md shadow-pink-600/20 active:scale-95 transition flex items-center justify-center gap-2 whitespace-nowrap"
                >
                  <ShoppingBag className="w-4 h-4" />
                  Shop Complete Look
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Bottom Carousel of Other Creator Looks */}
        <div className="p-4 border-t border-stone-200 dark:border-slate-800 bg-stone-50 dark:bg-white flex items-center gap-3 overflow-x-auto flex-shrink-0">
          <span className="text-[11px] font-bold uppercase text-stone-400 whitespace-nowrap">More Styles:</span>
          {filteredLooks.map((look) => (
            <button
              key={look.id}
              onClick={() => setActiveStyleLook(look)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-bold transition whitespace-nowrap ${
                currentLook.id === look.id
                  ? 'border-pink-500 bg-pink-100/50 dark:bg-pink-950/40 text-pink-700 dark:text-pink-300 shadow-sm'
                  : 'border-stone-200 dark:border-slate-800 text-stone-600 dark:text-slate-400 hover:bg-stone-200/50'
              }`}
            >
              <img src={look.coverImage} alt={look.title} className="w-6 h-6 rounded-lg object-cover" />
              <span>{look.influencerName}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
