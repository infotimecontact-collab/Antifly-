import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  Check,
  Sparkles,
  Store,
  User,
  Zap,
  Award,
  Crown,
  Lock,
} from 'lucide-react';

export const VerifiedBadgeModal: React.FC = () => {
  const {
    isVerifiedBadgeModalOpen,
    setIsVerifiedBadgeModalOpen,
    userPersonaProfile,
    purchaseSellerVerifiedTick,
    purchaseCustomerVerifiedTick,
    sellerDailySalesCount,
  } = useApp();

  if (!isVerifiedBadgeModalOpen) return null;

  const hasSellerMilestone = sellerDailySalesCount >= 10;

  return (
    <div
      id="verified-badge-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-blue-500/30 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shadow-inner">
              <CheckCircle2 className="w-7 h-7 fill-blue-400 text-slate-800" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black tracking-tight">
                  Verified Tick Mark Upgrade
                </h2>
                <span className="bg-amber-400 text-slate-800 text-[10px] font-black uppercase px-2 py-0.5 rounded-full shadow-xs">
                  Official Verification
                </span>
              </div>
              <p className="text-xs text-blue-100 mt-0.5">
                Official Blue/Golden Tick Badges for Trusted Merchants & VIP Buyers
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsVerifiedBadgeModalOpen(false)}
            className="p-2 rounded-xl text-blue-100 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* Seller Verified Badge Box */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-500/10 via-slate-50 to-amber-500/5 dark:from-amber-950/20 dark:via-slate-800/50 dark:to-slate-800 border-2 border-amber-500/40 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                  <Store className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <span>Seller Verified Merchant Badge</span>
                    <CheckCircle2 className="w-4 h-4 text-blue-500 fill-blue-500" />
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Displayed next to your store name, products, and community posts
                  </p>
                </div>
              </div>

              <div className="text-right">
                <span className="text-lg font-black text-amber-600 dark:text-amber-400">$10</span>
                <span className="text-xs text-slate-500 ml-1">/ month (₹850)</span>
              </div>
            </div>

            <div className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-500" />
                <span>Builds 10x higher buyer trust and conversion rates</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-500" />
                <span>Priority placement in Hyperlocal search and nearby vendor feeds</span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-500" />
                <span>
                  <strong>Free Auto-Unlock:</strong> Sell 10–20 orders/day to earn verified tick automatically!
                </span>
              </div>
            </div>

            {hasSellerMilestone && (
              <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-800 dark:text-emerald-300 font-bold flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-500" />
                <span>Congratulations! Your daily sales ({sellerDailySalesCount} orders) qualify you for automatic merchant verification!</span>
              </div>
            )}

            <button
              onClick={() => {
                purchaseSellerVerifiedTick();
                setIsVerifiedBadgeModalOpen(false);
              }}
              className={`w-full py-2.5 px-4 rounded-xl font-black text-xs flex items-center justify-center gap-2 transition ${
                userPersonaProfile.hasSellerTick
                  ? 'bg-emerald-600 text-white'
                  : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 shadow-md'
              }`}
            >
              {userPersonaProfile.hasSellerTick ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Seller Badge Active ({userPersonaProfile.sellerTickExpiresAt ? `Renews: ${userPersonaProfile.sellerTickExpiresAt.slice(0, 10)}` : 'Active'})</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  <span>{hasSellerMilestone ? 'Claim Free Verified Merchant Badge' : 'Purchase Seller Verified Badge ($10 / Month)'}</span>
                </>
              )}
            </button>
          </div>

          {/* Customer Verified VIP Badge Box */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-blue-500/10 via-slate-50 to-blue-500/5 dark:from-blue-950/20 dark:via-slate-800/50 dark:to-slate-800 border-2 border-blue-500/40 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                  <Crown className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <span>Customer VIP Verified Badge</span>
                    <CheckCircle2 className="w-4 h-4 text-blue-500 fill-blue-500" />
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Shows verified buyer status on product reviews and direct vendor chats
                  </p>
                </div>
              </div>

              <div className="text-right">
                <span className="text-lg font-black text-blue-600 dark:text-blue-400">$2</span>
                <span className="text-xs text-slate-500 ml-1">/ 1 Year (₹170)</span>
              </div>
            </div>

            <div className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-500" />
                <span>Verified Buyer Tick on all published product reviews & fit feedback</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-500" />
                <span>VIP Priority response tag during store bargaining and direct chats</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-500" />
                <span>Exclusive invitation to private local merchant clearance drops</span>
              </div>
            </div>

            <button
              onClick={() => {
                purchaseCustomerVerifiedTick();
                setIsVerifiedBadgeModalOpen(false);
              }}
              className={`w-full py-2.5 px-4 rounded-xl font-black text-xs flex items-center justify-center gap-2 transition ${
                userPersonaProfile.hasCustomerTick
                  ? 'bg-emerald-600 text-white'
                  : 'bg-blue-600 hover:bg-blue-700 text-white shadow-md'
              }`}
            >
              {userPersonaProfile.hasCustomerTick ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>VIP Customer Badge Active (Valid for 1 Year)</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  <span>Get Customer Verified Badge ($2 / Year)</span>
                </>
              )}
            </button>
          </div>

          {/* Driver Verification Policy Note */}
          <div className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex items-start gap-2.5 text-xs text-slate-600 dark:text-slate-400">
            <Lock className="w-4 h-4 text-slate-500 flex-shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-800 dark:text-slate-200">Driver Partner Verification:</strong> Driver verification is strictly government-proof based (Driving License + Vehicle RC validation) and cannot be purchased with money to ensure rider safety.
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-white border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
          <span>🔒 Verified Badges are synced in real-time across the super-app</span>
          <button
            onClick={() => setIsVerifiedBadgeModalOpen(false)}
            className="font-bold text-slate-700 dark:text-slate-300 hover:underline"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
