import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Star,
  ShieldCheck,
  CheckCircle2,
  ThumbsUp,
  MessageSquare,
  Sparkles,
} from 'lucide-react';

export const SellerRatingModal: React.FC = () => {
  const {
    isSellerRatingModalOpen,
    setIsSellerRatingModalOpen,
    targetRatingSeller,
    submitSellerRating,
  } = useApp();

  const [selectedRating10, setSelectedRating10] = useState<number>(10);
  const [feedbackText, setFeedbackText] = useState<string>('');

  if (!isSellerRatingModalOpen || !targetRatingSeller) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitSellerRating(targetRatingSeller.id, selectedRating10, feedbackText || 'Great experience with fast local delivery!');
  };

  const getRatingLabel = (score: number) => {
    if (score === 10) return '🏆 10/10 Perfect & Outstanding!';
    if (score >= 8) return '⭐ Great quality & fast service';
    if (score >= 6) return '👍 Good experience';
    if (score >= 4) return '😐 Average';
    return '👎 Needs improvement';
  };

  return (
    <div
      id="seller-rating-modal"
      className="fixed inset-0 z-50 bg-slate-100/60 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 relative animate-in fade-in zoom-in-95 duration-150">
        {/* Close */}
        <button
          onClick={() => setIsSellerRatingModalOpen(false)}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Store Header */}
        <div className="text-center space-y-2 pb-4 border-b border-slate-100">
          <div className="w-16 h-16 rounded-2xl overflow-hidden border border-slate-200 mx-auto shadow-sm">
            <img
              src={targetRatingSeller.logoImage || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=150&auto=format&fit=crop&q=80'}
              alt={targetRatingSeller.storeName}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="flex items-center justify-center gap-1.5">
            <h2 className="text-lg font-black text-slate-900">
              {targetRatingSeller.storeName}
            </h2>
            <CheckCircle2 className="w-4 h-4 text-blue-600 fill-blue-50" />
          </div>

          <p className="text-xs text-slate-500 font-medium">
            How was your shopping and delivery experience with this venture?
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          {/* 1 to 10 Scale Selector */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-700">
              <span>Select Score (1 to 10 Scale):</span>
              <span className="text-red-600 font-extrabold">{getRatingLabel(selectedRating10)}</span>
            </div>

            <div className="grid grid-cols-5 gap-1.5">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => {
                const isSelected = selectedRating10 === num;
                return (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setSelectedRating10(num)}
                    className={`py-2 rounded-xl text-xs font-black transition cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
                      isSelected
                        ? 'bg-red-600 text-white shadow-md shadow-red-600/20 scale-105'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    <span>{num}</span>
                    <Star className={`w-2.5 h-2.5 ${isSelected ? 'fill-white text-white' : 'text-amber-500 fill-amber-400'}`} />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Feedback Text Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">
              Your Review & Comments:
            </label>
            <textarea
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
              placeholder="e.g. Fresh quality, polite buddy, packaged very well! Delivered in 20 minutes."
              rows={3}
              className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-3 text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 resize-none"
            />
          </div>

          {/* Quick tags */}
          <div className="flex flex-wrap gap-1.5">
            {['⚡ Fast 20m delivery', '📦 Fresh packaging', '💰 Best local price', '🤝 Polite venture partner'].map((tag) => (
              <button
                key={tag}
                type="button"
                onClick={() => setFeedbackText((prev) => (prev ? `${prev} • ${tag}` : tag))}
                className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold transition cursor-pointer"
              >
                {tag}
              </button>
            ))}
          </div>

          {/* Submit CTA */}
          <button
            type="submit"
            className="w-full py-3 rounded-2xl bg-red-600 hover:bg-red-700 text-white text-xs font-black shadow-md shadow-red-600/20 transition cursor-pointer flex items-center justify-center gap-1.5"
          >
            <Star className="w-4 h-4 fill-white" />
            <span>Submit {selectedRating10}/10 Rating</span>
          </button>
        </form>
      </div>
    </div>
  );
};
