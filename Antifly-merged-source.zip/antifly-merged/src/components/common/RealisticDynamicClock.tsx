import React, { useState, useEffect } from 'react';
import { Clock, Sparkles, Calendar, Globe, Zap, Info } from 'lucide-react';

interface RealisticDynamicClockProps {
  size?: 'xs' | 'sm' | 'md' | 'lg';
  showDigitalTime?: boolean;
  showSeconds?: boolean;
  variant?: 'customer' | 'seller' | 'driver' | 'dark' | 'light' | 'luxury';
  className?: string;
  badgeLabel?: string;
}

export const RealisticDynamicClock: React.FC<RealisticDynamicClockProps> = ({
  size = 'sm',
  showDigitalTime = true,
  showSeconds = true,
  variant = 'customer',
  className = '',
  badgeLabel,
}) => {
  const [time, setTime] = useState(() => new Date());
  const [showTooltip, setShowTooltip] = useState(false);

  useEffect(() => {
    // High-resolution clock tick
    const update = () => setTime(new Date());
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  const hours = time.getHours();
  const minutes = time.getMinutes();
  const seconds = time.getSeconds();
  const ms = time.getMilliseconds();

  // Precise rotational angles in degrees
  const secondAngle = seconds * 6; // 360 / 60 = 6 deg per sec
  const minuteAngle = minutes * 6 + (seconds / 60) * 6; // smooth progress
  const hourAngle = ((hours % 12) + minutes / 60 + seconds / 3600) * 30; // 360 / 12 = 30 deg per hr

  const formattedHours12 = hours % 12 || 12;
  const period = hours >= 12 ? 'PM' : 'AM';
  const pad = (n: number) => String(n).padStart(2, '0');
  const digitalTimeStr = `${formattedHours12}:${pad(minutes)}${showSeconds ? `:${pad(seconds)}` : ''} ${period}`;
  const dateStr = time.toLocaleDateString('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  // Size pixel map for the clock face
  const sizeConfig = {
    xs: { dial: 22, stroke: 1.5, text: 'text-[9px]' },
    sm: { dial: 28, stroke: 1.8, text: 'text-[10px]' },
    md: { dial: 34, stroke: 2, text: 'text-xs' },
    lg: { dial: 44, stroke: 2.5, text: 'text-sm' },
  }[size];

  // Theme styling based on variant (Customer: Amber/Gold, Seller: Orange/Warm, Driver: Emerald/Teal)
  const getThemeColors = () => {
    switch (variant) {
      case 'seller':
        return {
          bezel: 'from-amber-400 via-orange-500 to-amber-700',
          secondHand: '#f97316', // Orange
          hourHand: '#ffffff',
          minuteHand: '#fed7aa',
          dialBg: '#1e1b18',
          pillBg: 'bg-orange-500/15 border-orange-500/30 text-orange-600 dark:text-orange-300',
          pulseDot: 'bg-orange-500',
        };
      case 'driver':
        return {
          bezel: 'from-emerald-400 via-teal-500 to-emerald-800',
          secondHand: '#10b981', // Emerald
          hourHand: '#ffffff',
          minuteHand: '#a7f3d0',
          dialBg: '#0f1f1a',
          pillBg: 'bg-emerald-500/15 border-emerald-500/30 text-emerald-600 dark:text-emerald-300',
          pulseDot: 'bg-emerald-500',
        };
      case 'luxury':
        return {
          bezel: 'from-amber-300 via-yellow-500 to-amber-600',
          secondHand: '#ef4444', // Red
          hourHand: '#fbbf24',
          minuteHand: '#fef08a',
          dialBg: '#18181b',
          pillBg: 'bg-amber-500/15 border-amber-500/30 text-amber-600 dark:text-amber-300',
          pulseDot: 'bg-amber-500',
        };
      case 'dark':
        return {
          bezel: 'from-slate-400 via-slate-600 to-slate-800',
          secondHand: '#f43f5e',
          hourHand: '#ffffff',
          minuteHand: '#cbd5e1',
          dialBg: '#090d16',
          pillBg: 'bg-slate-800/80 border-slate-700 text-slate-200',
          pulseDot: 'bg-rose-500',
        };
      case 'customer':
      default:
        return {
          bezel: 'from-amber-400 via-amber-500 to-orange-600',
          secondHand: '#ef4444', // Crimson Red
          hourHand: '#ffffff',
          minuteHand: '#fde68a',
          dialBg: '#111827',
          pillBg: 'bg-amber-500/15 border-amber-500/30 text-amber-700 dark:text-amber-300',
          pulseDot: 'bg-amber-500',
        };
    }
  };

  const colors = getThemeColors();
  const d = sizeConfig.dial;
  const center = d / 2;
  const radius = center - 2;

  return (
    <div
      id="realistic-dynamic-clock-badge"
      className={`relative inline-flex items-center gap-1.5 cursor-pointer select-none group ${className}`}
      onClick={() => setShowTooltip((prev) => !prev)}
      onMouseEnter={() => setShowTooltip(true)}
      onMouseLeave={() => setShowTooltip(false)}
      title="Real-Time Clock (Live Synced)"
    >
      {/* Container Pill */}
      <div
        className={`flex items-center gap-1.5 px-2 py-1 rounded-full border backdrop-blur-md shadow-xs transition-all duration-200 group-hover:scale-105 group-hover:shadow-md ${colors.pillBg}`}
      >
        {/* ============================================================ */}
        {/* REALISTIC SVG WATCH FACE / CLOCK DIAL                        */}
        {/* ============================================================ */}
        <div className="relative flex-shrink-0" style={{ width: d, height: d }}>
          <svg
            width={d}
            height={d}
            viewBox={`0 0 ${d} ${d}`}
            className="overflow-visible drop-shadow-sm"
          >
            <defs>
              {/* Metallic Bezel Gradient */}
              <radialGradient
                id={`bezel-grad-${variant}-${size}`}
                cx="35%"
                cy="35%"
                r="65%"
              >
                <stop offset="0%" stopColor="#ffffff" stopOpacity="0.9" />
                <stop offset="45%" stopColor="#94a3b8" stopOpacity="0.8" />
                <stop offset="85%" stopColor="#334155" stopOpacity="1" />
                <stop offset="100%" stopColor="#0f172a" stopOpacity="1" />
              </radialGradient>

              {/* Dial Face Texture */}
              <radialGradient
                id={`dial-grad-${variant}-${size}`}
                cx="50%"
                cy="50%"
                r="50%"
              >
                <stop offset="0%" stopColor="#1e293b" />
                <stop offset="70%" stopColor={colors.dialBg} />
                <stop offset="100%" stopColor="#020617" />
              </radialGradient>

              {/* Glass Glare Overlay */}
              <linearGradient
                id={`glass-glare-${variant}-${size}`}
                x1="0"
                y1="0"
                x2="1"
                y2="1"
              >
                <stop offset="0%" stopColor="#ffffff" stopOpacity="0.4" />
                <stop offset="40%" stopColor="#ffffff" stopOpacity="0.05" />
                <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
              </linearGradient>
            </defs>

            {/* Outer Metallic Bezel Ring */}
            <circle
              cx={center}
              cy={center}
              r={radius + 1.2}
              fill={`url(#bezel-grad-${variant}-${size})`}
              stroke="#0f172a"
              strokeWidth="0.6"
            />

            {/* Inner Dial Circle */}
            <circle
              cx={center}
              cy={center}
              r={radius - 1.2}
              fill={`url(#dial-grad-${variant}-${size})`}
              stroke="rgba(255,255,255,0.15)"
              strokeWidth="0.4"
            />

            {/* 12 Hour Index Markers */}
            {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map(
              (deg, i) => {
                const isMajor = i % 3 === 0; // 12, 3, 6, 9
                const tickLength = isMajor ? radius * 0.28 : radius * 0.16;
                const innerR = radius - 1.8 - tickLength;
                const outerR = radius - 1.8;
                const rad = (deg - 90) * (Math.PI / 180);
                const x1 = center + innerR * Math.cos(rad);
                const y1 = center + innerR * Math.sin(rad);
                const x2 = center + outerR * Math.cos(rad);
                const y2 = center + outerR * Math.sin(rad);

                return (
                  <line
                    key={deg}
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke={isMajor ? '#f8fafc' : 'rgba(255,255,255,0.4)'}
                    strokeWidth={isMajor ? 0.9 : 0.5}
                    strokeLinecap="round"
                  />
                );
              }
            )}

            {/* HOUR HAND (Realistic Baton Shape) */}
            <g
              transform={`rotate(${hourAngle}, ${center}, ${center})`}
              className="transition-transform duration-200"
            >
              <line
                x1={center}
                y1={center + radius * 0.15}
                x2={center}
                y2={center - radius * 0.52}
                stroke={colors.hourHand}
                strokeWidth={size === 'xs' ? 1.2 : 1.8}
                strokeLinecap="round"
              />
              {/* Luminous Inset Line */}
              <line
                x1={center}
                y1={center - radius * 0.15}
                x2={center}
                y2={center - radius * 0.46}
                stroke="rgba(255,255,255,0.9)"
                strokeWidth="0.8"
                strokeLinecap="round"
              />
            </g>

            {/* MINUTE HAND (Slender Tapered Hand) */}
            <g
              transform={`rotate(${minuteAngle}, ${center}, ${center})`}
              className="transition-transform duration-200"
            >
              <line
                x1={center}
                y1={center + radius * 0.2}
                x2={center}
                y2={center - radius * 0.76}
                stroke={colors.minuteHand}
                strokeWidth={size === 'xs' ? 1.0 : 1.3}
                strokeLinecap="round"
              />
            </g>

            {/* SECOND HAND (Realistic Colored Needle with Tail) */}
            <g
              transform={`rotate(${secondAngle}, ${center}, ${center})`}
              style={{
                transition: 'transform 0.15s cubic-bezier(0.4, 2.08, 0.55, 0.44)',
              }}
            >
              {/* Needle Body */}
              <line
                x1={center}
                y1={center + radius * 0.25}
                x2={center}
                y2={center - radius * 0.85}
                stroke={colors.secondHand}
                strokeWidth={0.75}
                strokeLinecap="round"
              />
              {/* Counter-balance circle */}
              <circle
                cx={center}
                cy={center + radius * 0.16}
                r={radius * 0.09}
                fill={colors.secondHand}
              />
            </g>

            {/* Center Cap Pin */}
            <circle
              cx={center}
              cy={center}
              r={radius * 0.14}
              fill="#ffffff"
              stroke="#0f172a"
              strokeWidth="0.5"
            />

            {/* Subtle Glass Curved Highlight */}
            <path
              d={`M ${center - radius + 2} ${center} A ${radius - 2} ${
                radius - 2
              } 0 0 1 ${center + radius - 2} ${center} Z`}
              fill={`url(#glass-glare-${variant}-${size})`}
              pointerEvents="none"
            />
          </svg>

          {/* Live Pulsing Real-time indicator dot */}
          <span
            className={`absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full ${colors.pulseDot} animate-ping`}
          />
        </div>

        {/* Digital Real-Time Label */}
        {showDigitalTime && (
          <div className="flex flex-col items-start leading-none pr-0.5">
            <span
              className={`font-mono font-black tracking-tight ${sizeConfig.text}`}
            >
              {digitalTimeStr}
            </span>
            {badgeLabel ? (
              <span className="text-[8px] font-bold opacity-75 uppercase tracking-wider">
                {badgeLabel}
              </span>
            ) : null}
          </div>
        )}
      </div>

      {/* ============================================================ */}
      {/* REALISTIC LUXURY TIMEPIECE EXPANDED TOOLTIP / STATUS POPUP   */}
      {/* ============================================================ */}
      {showTooltip && (
        <div
          id="real-time-clock-tooltip"
          className="absolute top-full mt-2 left-1/2 -translate-x-1/2 z-50 w-56 p-3 bg-slate-900/95 text-white rounded-2xl border border-slate-700 shadow-2xl backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150 text-left"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
            <div className="flex items-center gap-1.5">
              <span
                className={`w-2 h-2 rounded-full ${colors.pulseDot} animate-pulse`}
              />
              <span className="text-[11px] font-bold text-slate-200">
                Live Precision Clock
              </span>
            </div>
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono font-bold">
              REAL-TIME
            </span>
          </div>

          <div className="space-y-1.5 text-[11px]">
            <div className="flex items-center justify-between text-slate-300">
              <span className="flex items-center gap-1 text-slate-400">
                <Clock className="w-3 h-3" /> Exact Time:
              </span>
              <span className="font-mono font-bold text-amber-300">
                {digitalTimeStr}
              </span>
            </div>

            <div className="flex items-center justify-between text-slate-300">
              <span className="flex items-center gap-1 text-slate-400">
                <Calendar className="w-3 h-3" /> Today:
              </span>
              <span className="font-medium text-slate-200">{dateStr}</span>
            </div>

            <div className="flex items-center justify-between text-slate-300">
              <span className="flex items-center gap-1 text-slate-400">
                <Globe className="w-3 h-3" /> Timezone:
              </span>
              <span className="text-slate-300 font-mono text-[10px]">
                {Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Kolkata'}
              </span>
            </div>
          </div>

          <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[9px] text-slate-400">
            <span className="flex items-center gap-1">
              <Zap className="w-2.5 h-2.5 text-amber-400" />
              Dynamic Clock Icon
            </span>
            <span className="text-emerald-400 font-semibold">100% Sync</span>
          </div>
        </div>
      )}
    </div>
  );
};
