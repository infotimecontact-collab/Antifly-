import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  User,
  Store,
  Truck,
  ShieldCheck,
  Check,
  ArrowRightLeft,
  Sparkles,
  MapPin,
  Clock,
  Award,
  CheckCircle2,
  FileCheck,
  ChevronRight,
  Sun,
  Moon,
  Bike,
} from 'lucide-react';
import { UnifiedPersonaMode } from '../../types';

export const UnifiedRoleSwitcherModal: React.FC = () => {
  const {
    isRoleSwitcherOpen,
    setIsRoleSwitcherOpen,
    userPersonaProfile,
    switchActivePersona,
    driverMilestoneProgress,
    setDriverRadiusFilterKm,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'switch' | 'proofs'>('switch');

  if (!isRoleSwitcherOpen) return null;

  const personas: {
    mode: UnifiedPersonaMode;
    title: string;
    subtitle: string;
    icon: React.ReactNode;
    color: string;
    activeBorder: string;
    description: string;
    dailyScheduleTip: string;
  }[] = [
    {
      mode: 'customer',
      title: 'Customer (Buyer & Explorer)',
      subtitle: 'Browse Local Ventures, Chat & Bargain',
      icon: <User className="w-5 h-5" />,
      color: 'text-amber-500 bg-amber-500/10 border-amber-500/30',
      activeBorder: 'border-amber-500 ring-2 ring-amber-500/20 bg-amber-50/30 dark:bg-amber-950/20',
      description: 'Discover nearby ventures (Agarwal Venture, Dairy, Art Galleries), follow venture feeds, propose bargains, and place orders.',
      dailyScheduleTip: 'Shop groceries, fashion, electronics, and food anytime with doorstep express delivery.',
    },
    {
      mode: 'seller',
      title: 'Venture (Merchant Partner)',
      subtitle: 'Morning Venture & Catalog Manager',
      icon: <Store className="w-5 h-5" />,
      color: 'text-orange-500 bg-orange-500/10 border-orange-500/30',
      activeBorder: 'border-orange-500 ring-2 ring-orange-500/20 bg-orange-50/30 dark:bg-orange-950/20',
      description: 'Run your venture catalog, receive buyer bargaining proposals, publish reels, and manage bulk CSV inventory.',
      dailyScheduleTip: 'Morning & Daytime: Manage your physical venture orders, inventory, and customer chats.',
    },
    {
      mode: 'driver',
      title: 'Buddy / Delivery Partner (Rider)',
      subtitle: 'Evening Shifts (2km - 10km Radius)',
      icon: <Truck className="w-5 h-5" />,
      color: 'text-emerald-500 bg-emerald-500/10 border-emerald-500/30',
      activeBorder: 'border-emerald-500 ring-2 ring-emerald-500/20 bg-emerald-50/30 dark:bg-emerald-950/20',
      description: 'Deliver orders from nearby ventures to customers with OTP validation and earn ₹50–₹300 daily milestone bonuses.',
      dailyScheduleTip: 'Evening / Night (1-2 Hours): Earn handsome payouts & buddy credits delivering within your local neighborhood.',
    },
  ];

  return (
    <div
      id="unified-role-switcher-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-red-500/30 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header with Red Accent */}
        <div className="p-6 bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shadow-inner">
              <ArrowRightLeft className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black tracking-tight">
                  One Unified Account &bull; Vice-Versa Persona
                </h2>
                <span className="bg-amber-400 text-slate-800 text-[10px] font-black uppercase px-2 py-0.5 rounded-full shadow-xs">
                  All-in-One SuperApp
                </span>
              </div>
              <p className="text-xs text-rose-100 mt-0.5">
                Run your venture in the morning, shop anytime, deliver orders as a buddy in the evening!
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsRoleSwitcherOpen(false)}
            className="p-2 rounded-xl text-rose-100 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Unified Profile Summary Strip */}
        <div className="p-4 bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-red-600 to-amber-500 text-white font-black flex items-center justify-center text-sm shadow-md">
              {userPersonaProfile.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-1.5 font-extrabold text-slate-900 dark:text-white">
                <span>{userPersonaProfile.name}</span>
                {userPersonaProfile.hasCustomerTick && (
                  <span title="VIP Customer Tick">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 fill-blue-500" />
                  </span>
                )}
                {userPersonaProfile.hasSellerTick && (
                  <span title="Verified Venture Tick">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-500">
                📱 {userPersonaProfile.phone} &bull; 📍 {userPersonaProfile.city}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-xl bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 font-bold border border-emerald-500/30 text-[11px] flex items-center gap-1">
              <FileCheck className="w-3.5 h-3.5" />
              KYC Verified
            </span>
            <span className="px-2.5 py-1 rounded-xl bg-red-500/10 text-red-700 dark:text-red-300 font-bold border border-red-500/30 text-[11px]">
              Active: {userPersonaProfile.activePersona === 'seller' ? 'VENTURE' : userPersonaProfile.activePersona === 'driver' ? 'BUDDY' : userPersonaProfile.activePersona.toUpperCase()}
            </span>
          </div>
        </div>

        {/* Scrollable Personas */}
        <div className="p-6 overflow-y-auto space-y-4">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Switch Your Active Persona (Vice-Versa Capability)
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {personas.map((p) => {
              const isCurrent = userPersonaProfile.activePersona === p.mode;
              return (
                <div
                  key={p.mode}
                  onClick={() => {
                    switchActivePersona(p.mode);
                    setIsRoleSwitcherOpen(false);
                    showToast(`Switched active mode to ${p.title}!`);
                  }}
                  className={`relative p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between group ${
                    isCurrent
                      ? p.activeBorder
                      : 'border-slate-200 dark:border-slate-800 hover:border-red-400 bg-white dark:bg-slate-800/40'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center border ${p.color}`}>
                          {p.icon}
                        </div>
                        <h4 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white">
                          {p.title}
                        </h4>
                      </div>
                      {isCurrent && (
                        <span className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center text-[10px] font-black shadow-xs">
                          ✓
                        </span>
                      )}
                    </div>

                    <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                      {p.description}
                    </p>

                    <div className="mt-2.5 p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-[10px] text-slate-500 flex items-start gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-amber-500 flex-shrink-0 mt-0.2" />
                      <span>{p.dailyScheduleTip}</span>
                    </div>
                  </div>

                  <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-800/60 flex items-center justify-between text-xs font-bold text-red-600 dark:text-red-400 group-hover:translate-x-0.5 transition-transform">
                    <span>{isCurrent ? 'Currently Active Mode' : 'Switch to this Mode'}</span>
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Evening Buddy Geofencing Control (2km - 10km) */}
          <div className="mt-4 p-4 rounded-2xl bg-gradient-to-r from-emerald-500/10 via-slate-50 to-teal-500/10 dark:from-emerald-950/20 dark:via-slate-800 dark:to-slate-800 border border-emerald-500/30 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bike className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                <div>
                  <h4 className="text-xs font-extrabold text-slate-900 dark:text-white">
                    Buddy Evening Shift & Nearby Geofencing
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Accept delivery runs near your home/venture location
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                {[2, 5, 10].map((km) => (
                  <button
                    key={km}
                    onClick={() => {
                      setDriverRadiusFilterKm(km);
                      showToast(`🛵 Buddy delivery radius set to ${km} km!`);
                    }}
                    className={`px-2.5 py-1 rounded-xl text-xs font-bold transition ${
                      driverMilestoneProgress.nearbyRadiusKm === km
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-emerald-400'
                    }`}
                  >
                    {km} km
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300 pt-1">
              <span>
                Today's Deliveries: <strong>{driverMilestoneProgress.deliveriesToday}</strong>
              </span>
              <span className="font-bold text-emerald-600 dark:text-emerald-400">
                Milestone Bonus Earned: +${driverMilestoneProgress.bonusEarnedTodayUSD} (₹{driverMilestoneProgress.bonusEarnedTodayINR})
              </span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-white border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
          <span>🔄 All registered proofs, ventures, and ratings stay synced in your central account</span>
          <button
            onClick={() => setIsRoleSwitcherOpen(false)}
            className="font-bold text-slate-700 dark:text-slate-300 hover:underline"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
