import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Camera,
  Upload,
  Rotate3d,
  Sun,
  Sparkles,
  ShoppingBag,
  Heart,
  ZoomIn,
  ZoomOut,
  Layers,
  CheckCircle2,
  RefreshCw,
  Video,
  VideoOff,
  User,
  SlidersHorizontal,
  Eye,
  Truck,
  ShieldCheck,
  Clock,
  Trash2,
  Download,
  Split,
  ChevronRight,
  PackageCheck,
  Calendar,
  MapPin,
  Phone,
  Sparkle,
  BadgeCheck,
  Check,
} from 'lucide-react';
import { DEFAULT_VIRTUAL_TRYON_ITEMS } from '../../data/ecosystemData';
import {
  TRY_ON_PERSON_MODELS,
  SAMPLE_TRYON_PRESETS,
  CATEGORY_FIT_GUIDELINES,
} from '../../data/virtualTryOnData';
import {
  CustomUploadedProduct,
  TryOnPersonModel,
  ProductTryOnCategory,
  FreeTrialBooking,
} from '../../types';

export const VirtualTryOnModal: React.FC = () => {
  const {
    isVirtualTryOnOpen,
    setIsVirtualTryOnOpen,
    activeTryOnProductId,
    products,
    addToCart,
    showToast,
    formatPrice,
    toggleSaveItem,
    isItemSaved,
    customUploadedProducts,
    activeCustomUploadId,
    setActiveCustomUploadId,
    addCustomUploadedProduct,
    removeCustomUploadedProduct,
    freeTrialBookings,
    bookFreeTrial,
    cancelFreeTrialBooking,
    userUploadedSelfieModel,
    setUserUploadedSelfieModel,
    currentCustomer,
  } = useApp();

  // Active Main View Tab
  const [activeTab, setActiveTab] = useState<'upload_tryon' | 'store_catalog' | 'active_trials'>(
    activeCustomUploadId ? 'upload_tryon' : 'upload_tryon'
  );

  // Selected Product (Store Item vs Custom Uploaded Item)
  const [selectedStoreItemId, setSelectedStoreItemId] = useState<string>(
    DEFAULT_VIRTUAL_TRYON_ITEMS?.[0]?.id || ''
  );
  const [selectedCustomId, setSelectedCustomId] = useState<string>(
    customUploadedProducts?.[0]?.id || ''
  );

  // Selected Target Person / Model
  const [targetPersonMode, setTargetPersonMode] = useState<'model' | 'selfie' | 'camera'>('model');
  const [selectedModelId, setSelectedModelId] = useState<string>(
    TRY_ON_PERSON_MODELS?.[0]?.id || 'model-male-casual'
  );

  // Garment Position, Scale, Rotation & Drape Parameters
  const [garmentPos, setGarmentPos] = useState({ x: 0, y: 15 }); // offsets in %
  const [garmentScale, setGarmentScale] = useState(1.0);
  const [garmentRotation, setGarmentRotation] = useState(0);
  const [garmentOpacity, setGarmentOpacity] = useState(0.95);
  const [blendMode, setBlendMode] = useState<'normal' | 'multiply' | 'soft-light'>('normal');

  // Lighting & View Controls
  const [lightingPreset, setLightingPreset] = useState<'studio' | 'sunset' | 'daylight' | 'neon'>('studio');
  const [zoomLevel, setZoomLevel] = useState(1);
  const [isSplitCompareActive, setIsSplitCompareActive] = useState(false);
  const [splitPosition, setSplitPosition] = useState(50); // 0 to 100%
  const [isCapturing, setIsCapturing] = useState(false);
  const [isAutoFitting, setIsAutoFitting] = useState(false);

  // Free Trial Booking Drawer Form State
  const [isBookingDrawerOpen, setIsBookingDrawerOpen] = useState(false);
  const [trialSize, setTrialSize] = useState('L (40-42")');
  const [trialColor, setTrialColor] = useState('Standard Match');
  const [trialDuration, setTrialDuration] = useState(3);
  const [bookingForm, setBookingForm] = useState({
    name: currentCustomer?.name || 'Aarav Sharma',
    phone: currentCustomer?.phone || '+91 98260 11223',
    address: currentCustomer?.addresses?.[0]?.street || 'Flat 402, Lotus Court, AB Road, Indore, MP - 452001',
  });

  // Refs
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const productFileInputRef = useRef<HTMLInputElement | null>(null);
  const selfieFileInputRef = useRef<HTMLInputElement | null>(null);
  const stageRef = useRef<HTMLDivElement | null>(null);
  const isDraggingRef = useRef(false);
  const dragStartRef = useRef({ x: 0, y: 0, initPosX: 0, initPosY: 0 });

  // Sync when activeTryOnProductId changes
  useEffect(() => {
    if (activeTryOnProductId) {
      const match = (DEFAULT_VIRTUAL_TRYON_ITEMS || []).find((item) => item.productId === activeTryOnProductId);
      if (match) {
        setSelectedStoreItemId(match.id);
        setActiveTab('store_catalog');
      }
    }
  }, [activeTryOnProductId]);

  // Sync when activeCustomUploadId changes
  useEffect(() => {
    if (activeCustomUploadId) {
      setSelectedCustomId(activeCustomUploadId);
      setActiveTab('upload_tryon');
    }
  }, [activeCustomUploadId]);

  // Clean up camera stream on close
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  // WebCam Handler
  const startCamera = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }
        setTargetPersonMode('camera');
        showToast('📸 Live AR Mirror Camera Active! Align yourself with the frame.');
      } else {
        showToast('⚠️ Camera access not supported in this browser. Using AI Virtual Model.');
      }
    } catch (err) {
      showToast('⚠️ Camera permission not available. Switched to AI Virtual Model.');
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setTargetPersonMode('model');
  };

  // Determine current active item (Store Item vs Custom Uploaded Product)
  const currentCustomItem =
    customUploadedProducts.find((p) => p.id === selectedCustomId) ||
    customUploadedProducts?.[0] ||
    null;

  const currentStoreItem =
    (DEFAULT_VIRTUAL_TRYON_ITEMS || []).find((it) => it.id === selectedStoreItemId) ||
    DEFAULT_VIRTUAL_TRYON_ITEMS?.[0] ||
    null;

  const isCustomMode = activeTab === 'upload_tryon';
  const activeProductName = isCustomMode
    ? currentCustomItem?.name || 'Custom Uploaded Shirt'
    : currentStoreItem?.name || 'Store CAD Garment';

  const activeProductImage = isCustomMode
    ? currentCustomItem?.imageUrl || ''
    : currentStoreItem?.image || '';

  const activeCategory: ProductTryOnCategory = isCustomMode
    ? currentCustomItem?.category || 'tops_shirts'
    : (currentStoreItem?.category as ProductTryOnCategory) || 'tops_shirts';

  const activeFitInfo = CATEGORY_FIT_GUIDELINES[activeCategory] || CATEGORY_FIT_GUIDELINES.tops_shirts;

  // Selected Target Model
  const currentModel =
    targetPersonMode === 'selfie' && userUploadedSelfieModel
      ? userUploadedSelfieModel
      : TRY_ON_PERSON_MODELS.find((m) => m.id === selectedModelId) || TRY_ON_PERSON_MODELS[0];

  // Auto-Match Suitable Model when product category changes
  const autoMatchSuitableModel = (category: ProductTryOnCategory) => {
    const suitable = TRY_ON_PERSON_MODELS.find((m) => m.suitableCategories.includes(category));
    if (suitable) {
      setSelectedModelId(suitable.id);
      showToast(`✨ Auto-selected ${suitable.name} — most suitable for ${activeFitInfo.label}`);
    }
  };

  // One-Click AI Auto-Fit & Drape Computation
  const handleAutoFitDrape = () => {
    setIsAutoFitting(true);
    setTimeout(() => {
      setGarmentPos({ x: 0, y: activeFitInfo.defaultOffsetY });
      setGarmentScale(activeFitInfo.defaultScale);
      setGarmentRotation(0);
      setBlendMode('normal');
      setGarmentOpacity(0.95);
      setIsAutoFitting(false);
      showToast(`✨ AI Fitted "${activeProductName}" perfectly onto ${currentModel.name}!`);
    }, 600);
  };

  // Upload Custom Product Photo Handler
  const handleProductFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const imageUrl = reader.result as string;
        const newProduct: CustomUploadedProduct = {
          id: `custom-prod-${Date.now()}`,
          name: file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ') || 'My Uploaded Shirt',
          category: 'tops_shirts',
          imageUrl: imageUrl,
          detectedItemType: 'Uploaded Shirt / Garment',
          fabricType: 'Standard Weave Cotton / Blend',
          aiFitRecommendation: 'Auto-detected upper-body silhouette. Aligns smoothly over model shoulders.',
          colorPalette: ['#1e293b', '#f8fafc', '#3b82f6'],
          uploadedAt: 'Just now',
        };
        addCustomUploadedProduct(newProduct);
        setSelectedCustomId(newProduct.id);
        setActiveTab('upload_tryon');
        autoMatchSuitableModel('tops_shirts');
        handleAutoFitDrape();
        showToast('🎉 Photo uploaded! Garment extracted and ready for instant free trial fitting.');
      };
      reader.readAsDataURL(file);
    }
  };

  // Upload Custom User Selfie / Person Photo Handler
  const handleSelfieFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const imageUrl = reader.result as string;
        const newSelfieModel: TryOnPersonModel = {
          id: `selfie-${Date.now()}`,
          name: 'My Personal Photo / Selfie',
          gender: 'unisex',
          bodyType: 'regular',
          suitableCategories: [
            'tops_shirts',
            'dresses_gowns',
            'ethnic_sarees',
            'jackets_coats',
            'eyewear',
            'jewelry',
            'general',
          ],
          poseDescription: 'User Uploaded Photo',
          imageUrl: imageUrl,
          heightTag: 'Custom User Height',
          fitTag: 'Personal Proportions',
          isCustomUpload: true,
        };
        setUserUploadedSelfieModel(newSelfieModel);
        setTargetPersonMode('selfie');
        handleAutoFitDrape();
        showToast('🌟 Your photo uploaded! The product is now being tried on your person.');
      };
      reader.readAsDataURL(file);
    }
  };

  // Dragging interaction handlers for garment alignment on canvas
  const handleMouseDown = (e: React.MouseEvent) => {
    if (isSplitCompareActive) return;
    isDraggingRef.current = true;
    dragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      initPosX: garmentPos.x,
      initPosY: garmentPos.y,
    };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || !stageRef.current) return;
    const rect = stageRef.current.getBoundingClientRect();
    const deltaX = ((e.clientX - dragStartRef.current.x) / rect.width) * 100;
    const deltaY = ((e.clientY - dragStartRef.current.y) / rect.height) * 100;
    setGarmentPos({
      x: dragStartRef.current.initPosX + deltaX,
      y: dragStartRef.current.initPosY + deltaY,
    });
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  // Snapshot & Save to Moodboard
  const handleCaptureSnapshot = () => {
    setIsCapturing(true);
    setTimeout(() => {
      setIsCapturing(false);
      showToast('✨ High-Resolution Virtual Try-On Snapshot saved to your Style Moodboard!');
      toggleSaveItem({
        targetId: isCustomMode ? selectedCustomId : selectedStoreItemId,
        itemType: 'product',
        title: activeProductName,
        subtitle: `Virtual Try-On on ${currentModel.name}`,
        imageUrl: activeProductImage,
        price: isCustomMode ? 1499 : currentStoreItem?.price || 1999,
        tags: ['Try-On Snapshot', activeCategory],
      });
    }, 700);
  };

  // Confirm Free 3-Day Doorstep Trial Booking
  const handleConfirmFreeTrial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingForm.name || !bookingForm.phone || !bookingForm.address) {
      showToast('Please provide your complete name, phone, and delivery address.');
      return;
    }

    const booking = bookFreeTrial({
      productName: activeProductName,
      productImage: activeProductImage,
      productCategory: activeCategory,
      productId: isCustomMode ? undefined : currentStoreItem?.productId,
      customerName: bookingForm.name,
      customerPhone: bookingForm.phone,
      deliveryAddress: bookingForm.address,
      selectedSize: trialSize,
      selectedColor: trialColor,
      trialDurationDays: trialDuration,
      securityDeposit: 0,
    });

    setIsBookingDrawerOpen(false);
    setActiveTab('active_trials');
  };

  if (!isVirtualTryOnOpen) return null;

  return (
    <div
      id="virtual-try-on-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-white/85 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-6xl h-[94vh] max-h-[900px] flex flex-col overflow-hidden shadow-2xl relative text-slate-100">
        
        {/* Hidden File Inputs */}
        <input
          ref={productFileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleProductFileUpload}
        />
        <input
          ref={selfieFileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleSelfieFileUpload}
        />

        {/* Modal Top Header Bar */}
        <div className="p-3.5 sm:px-6 bg-white/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 relative z-30">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-amber-500 to-rose-500 text-slate-800 flex items-center justify-center font-black shadow-md">
              <Sparkles className="w-5 h-5 text-slate-800" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-black text-white tracking-tight">
                  Free Product Trial &amp; AI Dressing Room
                </h2>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                  ₹0 Free 3-Day Trial
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Upload any shirt or item photo &bull; AI automatically fits it to the most suitable person
              </p>
            </div>
          </div>

          {/* Navigation Mode Tabs */}
          <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-2xl border border-slate-800">
            <button
              id="tryon-tab-upload"
              onClick={() => setActiveTab('upload_tryon')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'upload_tryon'
                  ? 'bg-amber-500 text-slate-800 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload &amp; Try Any Item</span>
            </button>

            <button
              id="tryon-tab-store"
              onClick={() => setActiveTab('store_catalog')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'store_catalog'
                  ? 'bg-amber-500 text-slate-800 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Rotate3d className="w-3.5 h-3.5" />
              <span>Store 3D Items</span>
            </button>

            <button
              id="tryon-tab-trials"
              onClick={() => setActiveTab('active_trials')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'active_trials'
                  ? 'bg-amber-500 text-slate-800 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Truck className="w-3.5 h-3.5" />
              <span>My Free Trials ({freeTrialBookings.length})</span>
            </button>
          </div>

          {/* Close Modal Button */}
          <button
            id="tryon-close-btn"
            onClick={() => {
              stopCamera();
              setIsVirtualTryOnOpen(false);
            }}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-full transition border border-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Main Body (Split into Left Stage and Right Control Panel) */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden relative">
          
          {/* ============================================================== */}
          {/* TAB 3: ACTIVE FREE TRIALS DASHBOARD VIEW */}
          {/* ============================================================== */}
          {activeTab === 'active_trials' ? (
            <div className="flex-1 p-6 overflow-y-auto bg-white space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <h3 className="text-lg font-black text-white flex items-center gap-2">
                    <PackageCheck className="w-5 h-5 text-amber-400" />
                    <span>Your Active 3-Day Free Home Doorstep Trials</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Try products at home for 3 days at zero cost. If you love it, pay in 1-click or return with free doorstep pickup!
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('upload_tryon')}
                  className="bg-amber-500 hover:bg-amber-400 text-slate-800 font-black px-4 py-2 rounded-xl text-xs flex items-center gap-2 shadow-md transition"
                >
                  <Upload className="w-4 h-4" />
                  <span>Try Another Product Free</span>
                </button>
              </div>

              {freeTrialBookings.length === 0 ? (
                <div className="p-12 text-center bg-slate-900/50 rounded-3xl border border-slate-800 space-y-3">
                  <div className="w-14 h-14 rounded-full bg-slate-800 flex items-center justify-center mx-auto text-slate-400">
                    <Truck className="w-7 h-7 text-amber-400" />
                  </div>
                  <h4 className="text-base font-bold text-white">No active free trials right now</h4>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    Upload a photo of your shirt or pick any product from the catalog to book a 3-day doorstep free trial at ₹0 cost!
                  </p>
                  <button
                    onClick={() => setActiveTab('upload_tryon')}
                    className="mt-2 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-800 font-bold px-4 py-2 rounded-xl text-xs"
                  >
                    Start Free Trial Now
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {freeTrialBookings.map((trial) => (
                    <div
                      key={trial.id}
                      className="bg-slate-900 border border-slate-800 hover:border-amber-500/50 rounded-2xl p-4 space-y-3 transition shadow-lg relative overflow-hidden"
                    >
                      <div className="flex gap-3">
                        <img
                          src={trial.productImage}
                          alt={trial.productName}
                          className="w-20 h-20 rounded-xl object-cover border border-slate-800 bg-white flex-shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1 text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded w-fit mb-1">
                            <BadgeCheck className="w-3 h-3" />
                            <span>{trial.status}</span>
                          </div>
                          <h4 className="text-xs font-bold text-white truncate">{trial.productName}</h4>
                          <p className="text-[11px] text-slate-400 mt-0.5">
                            Size: <span className="text-amber-400 font-bold">{trial.selectedSize}</span> &bull; {trial.trialDurationDays} Days Trial
                          </p>
                          <p className="text-[10px] text-slate-500 font-mono mt-0.5">
                            Track: {trial.trackingCode}
                          </p>
                        </div>
                      </div>

                      <div className="bg-white/70 p-2.5 rounded-xl border border-slate-800 text-[11px] text-slate-300 space-y-1">
                        <div className="flex items-center justify-between text-slate-400 text-[10px]">
                          <span>Booked: {trial.bookedAt}</span>
                          <span className="text-amber-400 font-bold">Ends: {trial.expiresAt}</span>
                        </div>
                        <div className="truncate text-slate-400 text-[10px] flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-amber-500" />
                          <span>{trial.deliveryAddress}</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <button
                          onClick={() => {
                            addToCart({
                              productId: trial.productId || 'custom-trial-prod',
                              variantId: 'trial-purchase',
                              productName: trial.productName,
                              brand: 'Antifly Certified',
                              color: trial.selectedColor || 'Standard',
                              size: trial.selectedSize,
                              price: 1499,
                              mrp: 2499,
                              image: trial.productImage,
                              quantity: 1,
                              stock: 50,
                            });
                            showToast(`🛒 Purchased "${trial.productName}" from Free Trial!`);
                          }}
                          className="py-2 px-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1 transition"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>Keep &amp; Buy</span>
                        </button>

                        <button
                          onClick={() => cancelFreeTrialBooking(trial.id)}
                          className="py-2 px-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl flex items-center justify-center gap-1 transition border border-slate-700"
                        >
                          <Truck className="w-3.5 h-3.5 text-amber-400" />
                          <span>Return Pickup</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <>
              {/* ============================================================== */}
              {/* LEFT: THE INTERACTIVE TRY-ON CANVAS / FITTING STAGE */}
              {/* ============================================================== */}
              <div
                ref={stageRef}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                className="flex-1 relative flex flex-col justify-between overflow-hidden bg-white select-none cursor-default"
              >
                {/* Ambient Lighting Gradient */}
                <div
                  className={`absolute inset-0 pointer-events-none transition-all duration-700 ${
                    lightingPreset === 'sunset'
                      ? 'bg-gradient-to-tr from-amber-950/60 via-rose-950/30 to-slate-950'
                      : lightingPreset === 'daylight'
                      ? 'bg-gradient-to-tr from-sky-950/50 via-slate-900/60 to-slate-950'
                      : lightingPreset === 'neon'
                      ? 'bg-gradient-to-tr from-purple-950/70 via-cyan-950/40 to-slate-950'
                      : 'bg-gradient-to-b from-slate-900 to-slate-950'
                  }`}
                />

                {/* Live WebCam Feed (if in camera mode) */}
                {targetPersonMode === 'camera' && (
                  <div className="absolute inset-0 z-0">
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover transform -scale-x-100"
                    />
                    <div className="absolute inset-0 bg-white/20 backdrop-blur-[0.5px]" />
                  </div>
                )}

                {/* Flash Effect on Snapshot */}
                {isCapturing && (
                  <div className="absolute inset-0 z-50 bg-white animate-out fade-out duration-500 pointer-events-none" />
                )}

                {/* Top Control Bar on Stage */}
                <div className="relative z-20 p-3 sm:p-4 flex flex-wrap items-center justify-between gap-2 bg-gradient-to-b from-slate-950/90 to-transparent">
                  <div className="flex items-center gap-2">
                    <span className="bg-gradient-to-r from-amber-500 to-orange-500 text-slate-800 px-3 py-1 rounded-full text-xs font-black tracking-wider uppercase shadow-md flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{isCustomMode ? 'Custom Product Try-On' : '3D CAD Showcase'}</span>
                    </span>
                    <span className="bg-slate-900/80 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-slate-300 border border-slate-700 flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-amber-400" />
                      <span>Model: {currentModel.name}</span>
                    </span>
                  </div>

                  {/* Camera, Split View & Reset Quick Actions */}
                  <div className="flex items-center gap-1.5">
                    {/* One-Click AI Auto Fit */}
                    <button
                      onClick={handleAutoFitDrape}
                      disabled={isAutoFitting}
                      className="px-3 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:brightness-110 text-white rounded-xl text-xs font-black shadow-md flex items-center gap-1.5 transition"
                      title="AI Auto Fit to Body"
                    >
                      <Sparkle className={`w-3.5 h-3.5 ${isAutoFitting ? 'animate-spin' : ''}`} />
                      <span>{isAutoFitting ? 'Fitting...' : '✨ AI Auto-Fit'}</span>
                    </button>

                    {/* Split Before/After Toggle */}
                    <button
                      onClick={() => setIsSplitCompareActive(!isSplitCompareActive)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border ${
                        isSplitCompareActive
                          ? 'bg-amber-500 text-slate-800 border-amber-400'
                          : 'bg-slate-800/90 text-slate-300 border-slate-700 hover:bg-slate-700'
                      }`}
                      title="Split Before / After Comparison"
                    >
                      <Split className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Split View</span>
                    </button>

                    {/* Camera AR Toggle */}
                    <button
                      onClick={() => {
                        if (targetPersonMode === 'camera') stopCamera();
                        else startCamera();
                      }}
                      className={`p-2 rounded-xl text-xs font-bold transition border ${
                        targetPersonMode === 'camera'
                          ? 'bg-rose-600 text-white border-rose-400 animate-pulse'
                          : 'bg-slate-800/90 text-slate-300 border-slate-700 hover:bg-slate-700'
                      }`}
                      title={targetPersonMode === 'camera' ? 'Disable WebCam' : 'Enable WebCam AR Mirror'}
                    >
                      {targetPersonMode === 'camera' ? <VideoOff className="w-4 h-4" /> : <Video className="w-4 h-4" />}
                    </button>

                    {/* Reset Button */}
                    <button
                      onClick={() => {
                        setGarmentPos({ x: 0, y: activeFitInfo.defaultOffsetY });
                        setGarmentScale(activeFitInfo.defaultScale);
                        setGarmentRotation(0);
                        setZoomLevel(1);
                      }}
                      className="p-2 bg-slate-800/90 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700"
                      title="Reset Position & Scale"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Center Main Stage Display */}
                <div className="relative z-10 flex-1 flex items-center justify-center p-2 sm:p-4 overflow-hidden">
                  
                  {/* Container with Zoom Scaling */}
                  <div
                    style={{ transform: `scale(${zoomLevel})`, transition: 'transform 0.15s ease-out' }}
                    className="relative w-full max-w-[420px] aspect-[3/4] max-h-[520px] rounded-3xl overflow-hidden shadow-2xl border border-slate-700/60 bg-slate-900 flex items-center justify-center group"
                  >
                    {/* Layer 1: Target Person / Model Photo (Base Layer) */}
                    {targetPersonMode !== 'camera' && (
                      <img
                        src={currentModel.imageUrl}
                        alt={currentModel.name}
                        className="absolute inset-0 w-full h-full object-cover object-center filter brightness-95"
                      />
                    )}

                    {/* Layer 2: The Try-On Product Overlay (Draggable / Scalable) */}
                    {activeProductImage && (
                      <div
                        style={{
                          transform: `translate(${garmentPos.x}%, ${garmentPos.y}%) scale(${garmentScale}) rotate(${garmentRotation}deg)`,
                          mixBlendMode: blendMode,
                          opacity: garmentOpacity,
                          cursor: isSplitCompareActive ? 'default' : 'grab',
                        }}
                        className="absolute z-20 transition-all duration-75 select-none"
                      >
                        <div className="relative group/garment">
                          <img
                            src={activeProductImage}
                            alt={activeProductName}
                            className="w-48 sm:w-60 max-h-72 object-contain pointer-events-none drop-shadow-[0_15px_30px_rgba(71,85,105,0.35)]"
                          />
                          {/* Fine-Tuning Bounding Mesh on Hover */}
                          <div className="absolute -inset-2 border border-dashed border-amber-400/40 rounded-2xl pointer-events-none group-hover/garment:border-amber-400/80 transition" />
                        </div>
                      </div>
                    )}

                    {/* Split-View Before / After Slider Overlay */}
                    {isSplitCompareActive && (
                      <div
                        className="absolute inset-0 z-30 pointer-events-none overflow-hidden"
                        style={{ clipPath: `inset(0 ${100 - splitPosition}% 0 0)` }}
                      >
                        {/* Before (Original Person Model Without Garment) */}
                        <div className="absolute inset-0 bg-white">
                          <img
                            src={currentModel.imageUrl}
                            alt="Original Model"
                            className="w-full h-full object-cover object-center"
                          />
                          <div className="absolute top-4 left-4 bg-slate-100/70 backdrop-blur-md px-2.5 py-1 rounded-lg text-[10px] font-bold text-white uppercase tracking-wider">
                            Before Try-On
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Split View Divider Bar & Slider Handle */}
                    {isSplitCompareActive && (
                      <div
                        style={{ left: `${splitPosition}%` }}
                        className="absolute top-0 bottom-0 z-40 w-0.5 bg-amber-400 cursor-ew-resize pointer-events-auto flex items-center justify-center"
                      >
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={splitPosition}
                          onChange={(e) => setSplitPosition(Number(e.target.value))}
                          className="absolute inset-0 opacity-0 cursor-ew-resize w-full h-full"
                        />
                        <div className="w-7 h-7 rounded-full bg-amber-400 text-slate-800 flex items-center justify-center shadow-lg font-black text-[10px]">
                          ⇄
                        </div>
                      </div>
                    )}

                    {/* Stage Drag & Gesture Helper Hint */}
                    <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between pointer-events-none text-[10px] text-slate-300/80 bg-white/70 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-800">
                      <span className="flex items-center gap-1 font-mono">
                        <SlidersHorizontal className="w-3 h-3 text-amber-400" />
                        <span>Drag garment to position &bull; Use sliders to fine-tune</span>
                      </span>
                      <span className="text-amber-400 font-bold">
                        Fit: {activeFitInfo.suitableBody}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Bottom Interactive Toolbar (Zoom, Lighting, Opacity, Snapshot) */}
                <div className="relative z-20 p-3 sm:p-4 bg-white/90 backdrop-blur-xl border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  
                  {/* Zoom Controls */}
                  <div className="flex items-center gap-1.5 bg-slate-900 px-2 py-1 rounded-xl border border-slate-800">
                    <button
                      onClick={() => setZoomLevel((z) => Math.max(0.7, z - 0.1))}
                      className="p-1 text-slate-300 hover:text-white"
                      title="Zoom Out"
                    >
                      <ZoomOut className="w-4 h-4" />
                    </button>
                    <span className="text-xs font-mono font-bold text-slate-300 w-10 text-center">
                      {Math.round(zoomLevel * 100)}%
                    </span>
                    <button
                      onClick={() => setZoomLevel((z) => Math.min(1.5, z + 0.1))}
                      className="p-1 text-slate-300 hover:text-white"
                      title="Zoom In"
                    >
                      <ZoomIn className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Garment Scale & Drape Sliders */}
                  <div className="hidden lg:flex items-center gap-4 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800 text-xs">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold text-slate-400 uppercase">Scale:</span>
                      <input
                        type="range"
                        min="0.4"
                        max="2.0"
                        step="0.05"
                        value={garmentScale}
                        onChange={(e) => setGarmentScale(Number(e.target.value))}
                        className="w-20 accent-amber-500 cursor-pointer"
                      />
                      <span className="text-[10px] font-mono text-amber-400">{garmentScale.toFixed(2)}x</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold text-slate-400 uppercase">Rotate:</span>
                      <input
                        type="range"
                        min="-45"
                        max="45"
                        step="1"
                        value={garmentRotation}
                        onChange={(e) => setGarmentRotation(Number(e.target.value))}
                        className="w-16 accent-amber-500 cursor-pointer"
                      />
                      <span className="text-[10px] font-mono text-amber-400">{garmentRotation}°</span>
                    </div>
                  </div>

                  {/* Studio Lighting Switcher */}
                  <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
                    <span className="text-[10px] font-bold text-slate-400 uppercase px-1.5 hidden sm:inline">Lighting:</span>
                    {(['studio', 'sunset', 'daylight', 'neon'] as const).map((preset) => (
                      <button
                        key={preset}
                        onClick={() => setLightingPreset(preset)}
                        className={`px-2 py-0.5 rounded-lg text-[10px] font-bold capitalize transition ${
                          lightingPreset === preset
                            ? 'bg-amber-500 text-slate-800'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        {preset}
                      </button>
                    ))}
                  </div>

                  {/* Snapshot & Moodboard Save */}
                  <button
                    onClick={handleCaptureSnapshot}
                    className="bg-gradient-to-r from-rose-600 to-red-600 hover:brightness-110 text-white px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 shadow-md transition cursor-pointer"
                  >
                    <Camera className="w-4 h-4" />
                    <span>Snapshot Try-On</span>
                  </button>
                </div>
              </div>

              {/* ============================================================== */}
              {/* RIGHT: CONTROL PANEL & SUITABLE PERSON SELECTOR */}
              {/* ============================================================== */}
              <div className="w-full md:w-84 lg:w-96 bg-slate-900 border-t md:border-t-0 md:border-l border-slate-800 flex flex-col justify-between p-4 sm:p-5 space-y-4 overflow-y-auto max-h-[45vh] md:max-h-none">
                
                <div className="space-y-4">
                  
                  {/* SECTION 1: PRODUCT SELECTION & UPLOAD QUICK ACTIONS */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-[11px] font-black uppercase tracking-wider text-slate-400">
                        {isCustomMode ? 'Uploaded Products & Samples:' : 'Store CAD Catalog:'}
                      </label>
                      <button
                        onClick={() => productFileInputRef.current?.click()}
                        className="text-[11px] font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 hover:underline cursor-pointer"
                      >
                        <Upload className="w-3 h-3" />
                        <span>Upload Your Photo</span>
                      </button>
                    </div>

                    {isCustomMode ? (
                      <div className="space-y-2">
                        {/* Upload Button Box */}
                        <div
                          onClick={() => productFileInputRef.current?.click()}
                          className="p-3 border-2 border-dashed border-slate-700 hover:border-amber-500 rounded-2xl bg-white/40 text-center cursor-pointer transition group"
                        >
                          <div className="flex items-center justify-center gap-2 text-xs font-bold text-slate-200 group-hover:text-amber-400">
                            <Upload className="w-4 h-4 text-amber-500" />
                            <span>Click to Upload Photo of Your Shirt / Product</span>
                          </div>
                          <p className="text-[10px] text-slate-400 mt-0.5">
                            Auto AI drape extraction &bull; Works with any photo or selfie
                          </p>
                        </div>

                        {/* Preset Uploaded Garments Carousel */}
                        <div className="grid grid-cols-3 gap-1.5 max-h-28 overflow-y-auto p-1 bg-white/50 rounded-xl border border-slate-800">
                          {customUploadedProducts.map((prod) => (
                            <button
                              key={prod.id}
                              onClick={() => {
                                setSelectedCustomId(prod.id);
                                autoMatchSuitableModel(prod.category);
                                handleAutoFitDrape();
                              }}
                              className={`p-1 rounded-xl border text-left transition flex flex-col items-center gap-1 ${
                                selectedCustomId === prod.id
                                  ? 'border-amber-500 bg-amber-500/10 ring-1 ring-amber-500'
                                  : 'border-slate-800 hover:border-slate-700 bg-slate-900'
                              }`}
                            >
                              <img
                                src={prod.imageUrl}
                                alt={prod.name}
                                className="w-10 h-10 object-cover rounded-lg bg-white"
                              />
                              <span className="text-[9px] font-bold text-slate-300 truncate w-full text-center">
                                {prod.name}
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    ) : (
                      /* Store CAD Item Dropdown */
                      <select
                        value={selectedStoreItemId}
                        onChange={(e) => {
                          setSelectedStoreItemId(e.target.value);
                          handleAutoFitDrape();
                        }}
                        className="w-full bg-slate-800 border border-slate-700 text-xs font-bold text-white px-3 py-2.5 rounded-xl focus:outline-none focus:border-amber-500"
                      >
                        {DEFAULT_VIRTUAL_TRYON_ITEMS.map((item) => (
                          <option key={item.id} value={item.id} className="bg-slate-900">
                            {item.name} ({formatPrice(item.price)})
                          </option>
                        ))}
                      </select>
                    )}
                  </div>

                  {/* SECTION 2: SUITABLE PERSON / MODEL SELECTION */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-black uppercase tracking-wider text-slate-400">
                        Applicable Person / Model:
                      </label>
                      <button
                        onClick={() => selfieFileInputRef.current?.click()}
                        className="text-[11px] font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 hover:underline cursor-pointer"
                      >
                        <User className="w-3 h-3" />
                        <span>Upload My Photo / Selfie</span>
                      </button>
                    </div>

                    {/* Person Mode Switcher (AI Models vs Uploaded Selfie vs Live WebCam) */}
                    <div className="grid grid-cols-3 gap-1 bg-white p-1 rounded-xl border border-slate-800 text-[11px]">
                      <button
                        onClick={() => {
                          setTargetPersonMode('model');
                          stopCamera();
                        }}
                        className={`py-1.5 rounded-lg font-bold transition flex items-center justify-center gap-1 ${
                          targetPersonMode === 'model'
                            ? 'bg-amber-500 text-slate-800 shadow-xs'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        <User className="w-3 h-3" />
                        <span>AI Models</span>
                      </button>

                      <button
                        onClick={() => {
                          if (userUploadedSelfieModel) {
                            setTargetPersonMode('selfie');
                            stopCamera();
                          } else {
                            selfieFileInputRef.current?.click();
                          }
                        }}
                        className={`py-1.5 rounded-lg font-bold transition flex items-center justify-center gap-1 ${
                          targetPersonMode === 'selfie'
                            ? 'bg-amber-500 text-slate-800 shadow-xs'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        <Upload className="w-3 h-3" />
                        <span>My Selfie</span>
                      </button>

                      <button
                        onClick={() => startCamera()}
                        className={`py-1.5 rounded-lg font-bold transition flex items-center justify-center gap-1 ${
                          targetPersonMode === 'camera'
                            ? 'bg-rose-600 text-white shadow-xs'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        <Video className="w-3 h-3" />
                        <span>Live AR</span>
                      </button>
                    </div>

                    {/* AI Models Library Grid */}
                    {targetPersonMode === 'model' && (
                      <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto p-1 bg-white/60 rounded-xl border border-slate-800">
                        {TRY_ON_PERSON_MODELS.map((model) => {
                          const isSuitable = model.suitableCategories.includes(activeCategory);
                          return (
                            <button
                              key={model.id}
                              onClick={() => {
                                setSelectedModelId(model.id);
                                handleAutoFitDrape();
                              }}
                              className={`p-2 rounded-xl border text-left transition flex items-center gap-2 relative ${
                                selectedModelId === model.id
                                  ? 'border-amber-500 bg-amber-500/10 ring-1 ring-amber-500'
                                  : 'border-slate-800 hover:border-slate-700 bg-slate-900'
                              }`}
                            >
                              <img
                                src={model.imageUrl}
                                alt={model.name}
                                className="w-9 h-9 rounded-lg object-cover bg-white flex-shrink-0"
                              />
                              <div className="min-w-0">
                                <div className="text-[10px] font-bold text-white truncate leading-tight">
                                  {model.name}
                                </div>
                                <div className="text-[9px] text-slate-400 truncate">
                                  {model.fitTag || model.gender}
                                </div>
                              </div>
                              {isSuitable && (
                                <span
                                  className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-400"
                                  title="Best Fit for this garment"
                                />
                              )}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  {/* SECTION 3: AI FIT & ANTHROPOMETRIC SPECS CARD */}
                  <div className="bg-white/80 p-3.5 rounded-2xl border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1.5 font-bold text-amber-400">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>AI Anthropometric Drape Analysis</span>
                      </div>
                      <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded">
                        100% Fit Match
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      {isCustomMode
                        ? currentCustomItem?.aiFitRecommendation || 'Calibrated to human torso proportions with zero fabric distortion.'
                        : 'Calibrated to standard Indian anthropometric measurements with high-precision drape simulations.'}
                    </p>
                    <div className="flex items-center gap-2 pt-1 text-[10px] text-slate-400 font-mono">
                      <span>Height: {currentModel.heightTag || '5 ft 10 in'}</span>
                      <span>&bull;</span>
                      <span>Target: {activeFitInfo.suitableBody}</span>
                    </div>
                  </div>

                </div>

                {/* SECTION 4: FREE TRIAL & CART ACTION BUTTONS */}
                <div className="space-y-2 pt-2 border-t border-slate-800">
                  {/* Primary CTA: Book 3-Day Free Home Doorstep Trial */}
                  <button
                    id="book-free-trial-btn"
                    onClick={() => setIsBookingDrawerOpen(true)}
                    className="w-full bg-gradient-to-r from-amber-500 via-orange-500 to-amber-500 hover:brightness-110 text-slate-800 font-black py-3 rounded-2xl text-xs sm:text-sm shadow-xl flex items-center justify-center gap-2 cursor-pointer transition hover:scale-[1.02]"
                  >
                    <Truck className="w-4 h-4 text-slate-800" />
                    <span>🎉 Book 3-Day Free Home Doorstep Trial</span>
                  </button>

                  {/* Secondary CTA: Add to Bag */}
                  <button
                    id="tryon-add-to-cart-btn"
                    onClick={() => {
                      addToCart({
                        productId: isCustomMode ? selectedCustomId : currentStoreItem?.productId || 'tryon-item',
                        variantId: 'configured-tryon-variant',
                        productName: activeProductName,
                        brand: 'Antifly Certified',
                        color: 'Standard Match',
                        size: 'L (40-42")',
                        price: isCustomMode ? 1499 : currentStoreItem?.price || 1999,
                        mrp: isCustomMode ? 2499 : (currentStoreItem?.price || 1999) + 800,
                        image: activeProductImage,
                        quantity: 1,
                        stock: 50,
                      });
                      showToast(`🛒 Added "${activeProductName}" to Cart!`);
                    }}
                    className="w-full bg-slate-800 hover:bg-slate-700 text-white font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 transition border border-slate-700 cursor-pointer"
                  >
                    <ShoppingBag className="w-3.5 h-3.5 text-amber-400" />
                    <span>Add to Bag ({isCustomMode ? '₹1,499' : formatPrice(currentStoreItem?.price || 1999)})</span>
                  </button>
                </div>

              </div>
            </>
          )}

        </div>

        {/* ============================================================== */}
        {/* MODAL / DRAWER: 3-DAY FREE TRIAL BOOKING CONFIRMATION */}
        {/* ============================================================== */}
        {isBookingDrawerOpen && (
          <div className="absolute inset-0 z-50 bg-white/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
            <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-lg p-6 space-y-4 shadow-2xl relative">
              <button
                onClick={() => setIsBookingDrawerOpen(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-300 flex items-center justify-center font-black">
                  <Truck className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Book 3-Day Free Home Trial</h3>
                  <p className="text-xs text-slate-400">Zero advance fee &bull; Try for 3 days &bull; Free doorstep return</p>
                </div>
              </div>

              <div className="bg-white p-3 rounded-2xl border border-slate-800 flex items-center gap-3">
                <img
                  src={activeProductImage}
                  alt={activeProductName}
                  className="w-14 h-14 rounded-xl object-cover border border-slate-800 bg-slate-900"
                />
                <div className="min-w-0">
                  <h4 className="text-xs font-bold text-white truncate">{activeProductName}</h4>
                  <div className="flex items-center gap-2 mt-1 text-[11px]">
                    <span className="text-emerald-400 font-bold">Trial Fee: ₹0 (100% Free)</span>
                    <span className="text-slate-400">&bull;</span>
                    <span className="text-amber-400">Security Deposit: ₹0</span>
                  </div>
                </div>
              </div>

              <form onSubmit={handleConfirmFreeTrial} className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">Select Size:</label>
                    <select
                      value={trialSize}
                      onChange={(e) => setTrialSize(e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 text-xs text-white p-2.5 rounded-xl font-bold"
                    >
                      <option value="S (36-38&quot;)">S (36-38")</option>
                      <option value="M (38-40&quot;)">M (38-40")</option>
                      <option value="L (40-42&quot;)">L (40-42")</option>
                      <option value="XL (42-44&quot;)">XL (42-44")</option>
                      <option value="XXL (46&quot;)">XXL (46")</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">Trial Period:</label>
                    <select
                      value={trialDuration}
                      onChange={(e) => setTrialDuration(Number(e.target.value))}
                      className="w-full bg-slate-800 border border-slate-700 text-xs text-white p-2.5 rounded-xl font-bold"
                    >
                      <option value={3}>3 Days Home Trial (Free)</option>
                      <option value={5}>5 Days Extended Trial (Free)</option>
                      <option value={7}>7 Days Premium Trial (Free)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">Your Full Name:</label>
                  <input
                    type="text"
                    value={bookingForm.name}
                    onChange={(e) => setBookingForm({ ...bookingForm, name: e.target.value })}
                    required
                    className="w-full bg-slate-800 border border-slate-700 text-xs text-white p-2.5 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">Phone Number for Delivery Updates:</label>
                  <input
                    type="tel"
                    value={bookingForm.phone}
                    onChange={(e) => setBookingForm({ ...bookingForm, phone: e.target.value })}
                    required
                    className="w-full bg-slate-800 border border-slate-700 text-xs text-white p-2.5 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">Doorstep Delivery Address:</label>
                  <textarea
                    rows={2}
                    value={bookingForm.address}
                    onChange={(e) => setBookingForm({ ...bookingForm, address: e.target.value })}
                    required
                    className="w-full bg-slate-800 border border-slate-700 text-xs text-white p-2.5 rounded-xl"
                  />
                </div>

                <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-2xl flex items-center gap-2 text-xs text-emerald-300">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>100% Free Doorstep Delivery &bull; Zero penalty &bull; 1-click return pickup</span>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-800 font-black rounded-xl text-sm shadow-xl hover:brightness-110 transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <PackageCheck className="w-4 h-4" />
                  <span>Confirm Free 3-Day Home Doorstep Trial</span>
                </button>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
