import React, { useState } from 'react';
import {
  QrCode,
  Barcode,
  Printer,
  Copy,
  Check,
  Download,
  Share2,
  Scan,
  X,
  ExternalLink,
  ShieldCheck,
  Store,
  Sparkles,
  ShoppingBag,
} from 'lucide-react';
import { Product, ProductVariant } from '../../types';
import { useApp } from '../../context/AppContext';

interface ProductInventoryQRModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product | null;
  variant?: ProductVariant | null;
}

export const ProductInventoryQRModal: React.FC<ProductInventoryQRModalProps> = ({
  isOpen,
  onClose,
  product,
  variant,
}) => {
  const { showToast, addToCart, setIsCartOpen } = useApp();
  const [copied, setCopied] = useState(false);
  const [isScanningSimulated, setIsScanningSimulated] = useState(false);
  const [qrSize, setQrSize] = useState<'standard' | 'shelf' | 'poster'>('standard');

  if (!isOpen || !product) return null;

  const skuCode = variant?.sku || `SKU-${product.id.toUpperCase()}-DEF`;
  const colorName = variant?.color || 'Standard';
  const sizeName = variant?.size || 'Standard';
  const activePrice = variant?.price || product.price;
  const activeMrp = variant?.mrp || product.mrp;
  const stockCount = variant?.stock ?? product.totalStock ?? product.stock ?? 25;

  const scanUrl = `https://antifly.com/scan/p/${product.id}?sku=${encodeURIComponent(skuCode)}&source=in_store_qr`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(scanUrl);
    setCopied(true);
    showToast('In-store checkout & inventory scan link copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSimulateScan = () => {
    setIsScanningSimulated(true);
    setTimeout(() => {
      setIsScanningSimulated(false);
      showToast(`⚡ POS Scanned: ${product.name} (${skuCode}) added to cart!`);
      addToCart({
        productId: product.id,
        variantId: variant?.id || product.variants?.[0]?.id || 'var-1',
        quantity: 1,
      });
      setIsCartOpen(true);
      onClose();
    }, 1200);
  };

  const handlePrintLabel = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-white/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                Inventory & POS QR Code
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Instant Checkout
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                In-store scanning, warehouse shelf labels & instant customer checkout
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Product Summary Banner */}
          <div className="flex items-center gap-4 p-4 rounded-2xl bg-white/60 border border-slate-800/80">
            <img
              src={product.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200'}
              alt={product.name}
              className="w-16 h-16 rounded-xl object-cover border border-slate-700 shrink-0"
            />
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-bold text-white truncate">{product.name}</h4>
              <p className="text-xs text-slate-400 mt-0.5">
                {product.brand} • {product.category}
              </p>
              <div className="flex flex-wrap items-center gap-2 mt-2">
                <span className="font-mono text-[11px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                  {skuCode}
                </span>
                <span className="text-xs font-black text-white">
                  ₹{activePrice.toLocaleString('en-IN')}{' '}
                  <span className="text-slate-500 line-through text-[10px]">₹{activeMrp.toLocaleString('en-IN')}</span>
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                  stockCount > 15 ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'
                }`}>
                  Stock: {stockCount} units
                </span>
              </div>
            </div>
          </div>

          {/* QR Code Presentation Box */}
          <div className="flex flex-col items-center justify-center p-6 rounded-2xl bg-white text-slate-800 shadow-inner space-y-4">
            <div className="text-center space-y-1">
              <div className="font-bold text-xs uppercase tracking-widest text-slate-500">
                Antifly Social Commerce
              </div>
              <div className="font-black text-sm text-slate-900 truncate max-w-xs">{product.name}</div>
            </div>

            {/* Generated Vector QR Code Graphic */}
            <div className="p-3 bg-white border-4 border-slate-900 rounded-2xl shadow-md relative group">
              <svg
                viewBox="0 0 100 100"
                className="w-44 h-44 fill-slate-900"
                xmlns="http://www.w3.org/2000/svg"
              >
                {/* QR Positioning Markers */}
                <rect x="5" y="5" width="26" height="26" fill="#0f172a" rx="4" />
                <rect x="9" y="9" width="18" height="18" fill="#ffffff" rx="2" />
                <rect x="13" y="13" width="10" height="10" fill="#0f172a" rx="1" />

                <rect x="69" y="5" width="26" height="26" fill="#0f172a" rx="4" />
                <rect x="73" y="9" width="18" height="18" fill="#ffffff" rx="2" />
                <rect x="77" y="13" width="10" height="10" fill="#0f172a" rx="1" />

                <rect x="5" y="69" width="26" height="26" fill="#0f172a" rx="4" />
                <rect x="9" y="73" width="18" height="18" fill="#ffffff" rx="2" />
                <rect x="13" y="77" width="10" height="10" fill="#0f172a" rx="1" />

                {/* QR Data Pattern */}
                <rect x="36" y="8" width="6" height="6" />
                <rect x="46" y="8" width="6" height="6" />
                <rect x="56" y="8" width="6" height="6" />
                <rect x="36" y="18" width="6" height="6" />
                <rect x="50" y="18" width="6" height="6" />
                <rect x="8" y="36" width="6" height="6" />
                <rect x="18" y="36" width="6" height="6" />
                <rect x="28" y="36" width="6" height="6" />
                <rect x="38" y="36" width="6" height="6" />
                <rect x="48" y="36" width="6" height="6" />
                <rect x="58" y="36" width="6" height="6" />
                <rect x="68" y="36" width="6" height="6" />
                <rect x="78" y="36" width="6" height="6" />
                <rect x="88" y="36" width="6" height="6" />

                <rect x="14" y="46" width="6" height="6" />
                <rect x="24" y="46" width="6" height="6" />
                <rect x="44" y="46" width="12" height="12" fill="#ef4444" rx="2" />
                <rect x="64" y="46" width="6" height="6" />
                <rect x="84" y="46" width="6" height="6" />

                <rect x="8" y="56" width="6" height="6" />
                <rect x="28" y="56" width="6" height="6" />
                <rect x="68" y="56" width="6" height="6" />
                <rect x="88" y="56" width="6" height="6" />

                <rect x="36" y="68" width="6" height="6" />
                <rect x="46" y="68" width="6" height="6" />
                <rect x="56" y="68" width="6" height="6" />
                <rect x="66" y="68" width="6" height="6" />
                <rect x="76" y="68" width="6" height="6" />
                <rect x="86" y="68" width="6" height="6" />

                <rect x="36" y="78" width="6" height="6" />
                <rect x="50" y="78" width="6" height="6" />
                <rect x="60" y="78" width="6" height="6" />
                <rect x="74" y="78" width="6" height="6" />
                <rect x="88" y="78" width="6" height="6" />

                <rect x="36" y="88" width="6" height="6" />
                <rect x="46" y="88" width="6" height="6" />
                <rect x="56" y="88" width="6" height="6" />
                <rect x="66" y="88" width="6" height="6" />
                <rect x="76" y="88" width="6" height="6" />
                <rect x="86" y="88" width="6" height="6" />
              </svg>

              {/* Central Logo Overlay */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-8 h-8 rounded-lg bg-white text-amber-400 flex items-center justify-center font-black text-xs shadow-lg border-2 border-white">
                  W
                </div>
              </div>
            </div>

            {/* Barcode line representation */}
            <div className="w-full max-w-xs flex flex-col items-center pt-2 border-t border-slate-200">
              <div className="flex items-center justify-center gap-1 h-8 w-full">
                {[4, 2, 6, 2, 3, 5, 2, 4, 3, 2, 5, 2, 6, 3, 2, 4, 5, 2, 3, 4].map((width, i) => (
                  <span
                    key={i}
                    className="bg-slate-900 h-full inline-block rounded-[1px]"
                    style={{ width: `${width}px` }}
                  />
                ))}
              </div>
              <div className="font-mono text-[11px] tracking-widest text-slate-700 mt-1 font-bold">
                *{skuCode}*
              </div>
            </div>

            <div className="text-center">
              <p className="text-[11px] text-slate-600 font-medium">
                Scan with phone camera or Wise App to buy instantly at ₹{activePrice}
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              onClick={handleSimulateScan}
              disabled={isScanningSimulated}
              className="px-4 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold text-xs flex items-center justify-center gap-2 transition shadow-lg shadow-amber-500/20 disabled:opacity-50"
            >
              {isScanningSimulated ? (
                <>
                  <span className="w-4 h-4 border-2 border-slate-200 border-t-transparent rounded-full animate-spin" />
                  Simulating POS Scan...
                </>
              ) : (
                <>
                  <Scan className="w-4 h-4" />
                  Simulate POS / Camera Scan
                </>
              )}
            </button>

            <button
              onClick={handleCopyLink}
              className="px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center justify-center gap-2 transition border border-slate-700"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-slate-400" />}
              {copied ? 'Link Copied!' : 'Copy In-Store Scan Link'}
            </button>

            <button
              onClick={handlePrintLabel}
              className="px-4 py-2.5 rounded-2xl bg-white hover:bg-slate-800 text-slate-300 font-semibold text-xs flex items-center justify-center gap-2 transition border border-slate-800"
            >
              <Printer className="w-4 h-4 text-slate-400" />
              Print Shelf Tag / Sticker
            </button>

            <button
              onClick={() => {
                showToast('QR Code sticker template downloaded (PNG/SVG ready for label printer)');
              }}
              className="px-4 py-2.5 rounded-2xl bg-white hover:bg-slate-800 text-slate-300 font-semibold text-xs flex items-center justify-center gap-2 transition border border-slate-800"
            >
              <Download className="w-4 h-4 text-slate-400" />
              Export Sticker (300 DPI)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
