import React from 'react';
import { X, Printer, Download, CheckCircle2, ShieldCheck, QrCode } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const InvoiceModal: React.FC = () => {
  const { activeInvoiceData, setActiveInvoiceData, formatPrice } = useApp();

  if (!activeInvoiceData) return null;

  const inv = activeInvoiceData;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div
      id="invoice-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-sm overflow-y-auto"
    >
      <div
        id="invoice-modal-container"
        className="bg-white border border-stone-200 rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Top Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-stone-50 print:hidden">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-100 flex items-center justify-center text-amber-800">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-stone-900">Official Tax Invoice</h2>
              <p className="text-xs text-stone-500 font-mono">Invoice #{inv.invoiceNumber}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              id="invoice-print-btn"
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-lg transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>Print Invoice</span>
            </button>
            <button
              id="invoice-download-btn"
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Save PDF</span>
            </button>
            <button
              id="invoice-close-btn"
              type="button"
              onClick={() => setActiveInvoiceData(null)}
              className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Document Body */}
        <div className="p-8 overflow-y-auto space-y-6 text-stone-800 text-xs font-sans bg-white print:p-0">
          {/* Header Row */}
          <div className="flex justify-between items-start border-b border-stone-200 pb-6">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 rounded bg-amber-600 inline-block"></span>
                <span className="text-lg font-black tracking-tight text-stone-900">ANTIFLY</span>
                <span className="text-[10px] px-1.5 py-0.5 bg-amber-50 text-amber-800 border border-amber-200 rounded font-semibold uppercase">
                  Global Commerce
                </span>
              </div>
              <p className="text-xs font-semibold text-stone-700 mt-1">{inv.sellerDetails.name}</p>
              <p className="text-stone-500 mt-0.5 max-w-sm">{inv.sellerDetails.address}</p>
              <div className="mt-2 space-y-0.5 text-[11px] text-stone-600">
                <p><span className="font-semibold text-stone-700">Tax/GST/VAT ID:</span> {inv.sellerDetails.gstinOrVat}</p>
                <p><span className="font-semibold text-stone-700">Support:</span> {inv.sellerDetails.email} | {inv.sellerDetails.phone}</p>
              </div>
            </div>

            <div className="text-right">
              <div className="inline-block bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold px-2.5 py-1 rounded-md text-xs mb-2">
                {inv.paymentStatus.toUpperCase()} • 5-DAY SLA GUARANTEE
              </div>
              <h3 className="text-base font-bold text-stone-900">TAX INVOICE</h3>
              <p className="text-[11px] text-stone-500 mt-0.5"><span className="font-semibold text-stone-700">Invoice No:</span> {inv.invoiceNumber}</p>
              <p className="text-[11px] text-stone-500"><span className="font-semibold text-stone-700">Invoice Date:</span> {inv.invoiceDate}</p>
              <p className="text-[11px] text-stone-500"><span className="font-semibold text-stone-700">Order ID:</span> #{inv.orderNumber}</p>
              <p className="text-[11px] text-stone-500"><span className="font-semibold text-stone-700">Payment:</span> {inv.paymentMethod}</p>
            </div>
          </div>

          {/* Buyer & Billing Details */}
          <div className="grid grid-cols-2 gap-6 bg-stone-50/80 p-4 rounded-xl border border-stone-200">
            <div>
              <h4 className="font-bold text-stone-900 text-xs uppercase tracking-wider text-amber-800">Billed & Shipped To:</h4>
              <p className="text-sm font-bold text-stone-900 mt-1">{inv.buyerDetails.name}</p>
              <p className="text-stone-600 mt-0.5">{inv.buyerDetails.address}</p>
              <p className="text-stone-600">{inv.buyerDetails.city}, {inv.buyerDetails.state} - {inv.buyerDetails.pincode}</p>
              <p className="text-stone-600 font-semibold">{inv.buyerDetails.country}</p>
            </div>
            <div>
              <h4 className="font-bold text-stone-900 text-xs uppercase tracking-wider text-amber-800">Customer Contact & Compliance:</h4>
              <div className="mt-1 space-y-0.5 text-stone-600">
                <p><span className="font-semibold text-stone-700">Phone:</span> {inv.buyerDetails.phone}</p>
                <p><span className="font-semibold text-stone-700">Email:</span> {inv.buyerDetails.email}</p>
                <p><span className="font-semibold text-stone-700">E-Way Bill / IRN:</span> <span className="font-mono text-[10px] text-stone-500">{inv.irnNumber}</span></p>
                <p><span className="font-semibold text-stone-700">Refund SLA:</span> 5 Working Days via automated reversal</p>
              </div>
            </div>
          </div>

          {/* Line Items Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse" id="invoice-items-table">
              <thead>
                <tr className="border-b-2 border-stone-200 bg-stone-100/70 text-stone-700 text-[11px] uppercase tracking-wider">
                  <th className="py-2.5 px-3 font-bold">Item & Description</th>
                  <th className="py-2.5 px-2 font-bold">HSN/SKU</th>
                  <th className="py-2.5 px-2 font-bold text-center">Qty</th>
                  <th className="py-2.5 px-3 font-bold text-right">Unit Price</th>
                  <th className="py-2.5 px-2 font-bold text-right">{inv.taxLabel}</th>
                  <th className="py-2.5 px-3 font-bold text-right">Total Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {inv.items.map((item, idx) => (
                  <tr key={idx} className="hover:bg-stone-50/50">
                    <td className="py-3 px-3">
                      <p className="font-bold text-stone-900">{item.name}</p>
                      <p className="text-[11px] text-stone-500">100% Guaranteed Authentic • Sealed Dispatch</p>
                    </td>
                    <td className="py-3 px-2 font-mono text-stone-600 text-[11px]">{item.sku}</td>
                    <td className="py-3 px-2 text-center font-semibold text-stone-800">{item.quantity}</td>
                    <td className="py-3 px-3 text-right text-stone-700">{formatPrice(item.unitPrice)}</td>
                    <td className="py-3 px-2 text-right text-stone-600">{formatPrice(item.taxAmount)} ({item.taxRate}%)</td>
                    <td className="py-3 px-3 text-right font-bold text-stone-900">{formatPrice(item.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Subtotal & Calculations */}
          <div className="flex justify-between items-start border-t border-stone-200 pt-4">
            <div className="flex items-center gap-4 max-w-sm">
              <div className="w-20 h-20 bg-stone-100 border border-stone-200 rounded-lg p-1.5 flex items-center justify-center shrink-0">
                <img
                  src={inv.qrCodeUrl}
                  alt="Invoice QR"
                  className="w-full h-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="text-[11px] text-stone-500 space-y-1">
                <div className="flex items-center gap-1 text-emerald-700 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Digitally Signed & Validated</span>
                </div>
                <p>Scan QR code to verify invoice authenticity on the government tax portal.</p>
              </div>
            </div>

            <div className="w-64 space-y-2 text-xs">
              <div className="flex justify-between text-stone-600">
                <span>Items Subtotal:</span>
                <span className="font-medium">{formatPrice(inv.subtotal)}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Applicable {inv.taxLabel}:</span>
                <span className="font-medium">{formatPrice(inv.taxTotal)}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Worldwide Shipping Fee:</span>
                <span className="font-medium">{inv.shippingFee === 0 ? 'FREE' : formatPrice(inv.shippingFee)}</span>
              </div>
              {inv.discount > 0 && (
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>Promotional Discount:</span>
                  <span>-{formatPrice(inv.discount)}</span>
                </div>
              )}
              <div className="flex justify-between text-stone-900 font-extrabold text-sm pt-2 border-t-2 border-stone-800">
                <span>Grand Total:</span>
                <span className="text-amber-800">{formatPrice(inv.grandTotal)}</span>
              </div>
            </div>
          </div>

          {/* Footer Terms */}
          <div className="border-t border-stone-100 pt-4 text-[10px] text-stone-400 space-y-1">
            <p><strong>Terms & Conditions:</strong> This is a computer generated invoice and requires no physical signature. In case of cancellation or return, refunds are credited back to the source account within exactly 5 working days per the Antifly Global Guarantee.</p>
            <p>Registered office: Commerce Tower 9, Bengaluru 560001 • Worldwide Dispatch Hubs: New York, London, Frankfurt, Dubai, Singapore.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
