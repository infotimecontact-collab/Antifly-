import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Share2,
  X,
  Globe,
  Code,
  Check,
  Copy,
  Layers,
  Sparkles,
  Eye,
  FileText,
  Search,
  CheckCircle,
} from 'lucide-react';

export const SEOManagerModal: React.FC = () => {
  const {
    isSEOModalOpen,
    setIsSEOModalOpen,
    products,
    categories,
    settings,
    showToast,
  } = useApp();

  const [metaTitle, setMetaTitle] = useState('Antifly - The Global Handcrafted & Omnichannel E-Commerce SuperApp');
  const [metaDescription, setMetaDescription] = useState('Explore authentic Indian handlooms, silk sarees, designer apparel, electronics, and fast grocery delivery worldwide with live order tracking and best prices.');
  const [canonicalUrl, setCanonicalUrl] = useState('https://antifly.com');
  const [keywords, setKeywords] = useState('handcrafted sarees, kanjeevaram silk, indian artisan crafts, global ecommerce, fast delivery');
  const [ogImage, setOgImage] = useState('https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=1200&auto=format&fit=crop&q=80');
  const [activeTab, setActiveTab] = useState<'preview' | 'schema' | 'sitemap'>('preview');
  const [hasCopiedSchema, setHasCopiedSchema] = useState(false);

  if (!isSEOModalOpen) return null;

  // Generate structured JSON-LD Schema for E-commerce & Products
  const jsonLdSchema = {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'WebSite',
        '@id': `${canonicalUrl}/#website`,
        'url': canonicalUrl,
        'name': 'Antifly Global Marketplace',
        'description': metaDescription,
        'potentialAction': {
          '@type': 'SearchAction',
          'target': `${canonicalUrl}/search?q={search_term_string}`,
          'query-input': 'required name=search_term_string',
        },
      },
      {
        '@type': 'Organization',
        '@id': `${canonicalUrl}/#organization`,
        'name': 'Antifly Omnichannel Retail Private Limited',
        'url': canonicalUrl,
        'logo': 'https://antifly.com/logo.png',
        'contactPoint': {
          '@type': 'ContactPoint',
          'telephone': '+91-9000099551',
          'contactType': 'customer support',
          'availableLanguage': ['English', 'Hindi', 'Tamil', 'Telugu', 'Bengali'],
        },
      },
      {
        '@type': 'ItemList',
        'itemListElement': products.slice(0, 5).map((p, idx) => ({
          '@type': 'ListItem',
          'position': idx + 1,
          'item': {
            '@type': 'Product',
            'name': p.name,
            'image': p.image,
            'description': p.description,
            'sku': p.id,
            'offers': {
              '@type': 'Offer',
              'priceCurrency': 'INR',
              'price': p.price,
              'availability': 'https://schema.org/InStock',
            },
            'aggregateRating': {
              '@type': 'AggregateRating',
              'ratingValue': p.rating,
              'reviewCount': p.reviewsCount,
            },
          },
        })),
      },
    ],
  };

  const schemaString = JSON.stringify(jsonLdSchema, null, 2);

  const handleCopySchema = () => {
    navigator.clipboard.writeText(schemaString);
    setHasCopiedSchema(true);
    showToast('JSON-LD Schema script copied to clipboard');
    setTimeout(() => setHasCopiedSchema(false), 2000);
  };

  return (
    <div id="seo-manager-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl text-slate-100 overflow-hidden">
        {/* Modal Header */}
        <div className="bg-white px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white shadow-md">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">
                SEO & OpenGraph Meta Optimizer
              </h2>
              <p className="text-xs text-slate-400">
                Live Google SERP preview, Social sharing cards & JSON-LD Rich Snippets Schema.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsSEOModalOpen(false)}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 px-6 pt-4 border-b border-slate-800 bg-slate-900">
          <button
            onClick={() => setActiveTab('preview')}
            className={`flex items-center gap-2 px-4 py-2 rounded-t-xl text-xs sm:text-sm font-semibold border-b-2 transition-all ${
              activeTab === 'preview'
                ? 'border-emerald-500 text-emerald-400 bg-slate-850'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Eye className="w-4 h-4" />
            <span>SERP & Social Card Previews</span>
          </button>

          <button
            onClick={() => setActiveTab('schema')}
            className={`flex items-center gap-2 px-4 py-2 rounded-t-xl text-xs sm:text-sm font-semibold border-b-2 transition-all ${
              activeTab === 'schema'
                ? 'border-emerald-500 text-emerald-400 bg-slate-850'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code className="w-4 h-4" />
            <span>JSON-LD Schema Markup</span>
          </button>

          <button
            onClick={() => setActiveTab('sitemap')}
            className={`flex items-center gap-2 px-4 py-2 rounded-t-xl text-xs sm:text-sm font-semibold border-b-2 transition-all ${
              activeTab === 'sitemap'
                ? 'border-emerald-500 text-emerald-400 bg-slate-850'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Sitemap.xml & Robots.txt</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6 text-xs">
          {/* TAB 1: PREVIEWS & META EDITORS */}
          {activeTab === 'preview' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left: Meta inputs */}
              <div className="space-y-3 bg-white p-4 rounded-2xl border border-slate-800">
                <h3 className="font-bold text-white text-sm">Meta Tag Configurations</h3>

                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">Page Title (H1 / OG Title)</label>
                  <input
                    type="text"
                    value={metaTitle}
                    onChange={(e) => setMetaTitle(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <span className="text-[10px] text-slate-500 mt-0.5 block">{metaTitle.length}/60 characters</span>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">Meta Description</label>
                  <textarea
                    rows={3}
                    value={metaDescription}
                    onChange={(e) => setMetaDescription(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <span className="text-[10px] text-slate-500 mt-0.5 block">{metaDescription.length}/160 characters</span>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">Canonical URL</label>
                  <input
                    type="url"
                    value={canonicalUrl}
                    onChange={(e) => setCanonicalUrl(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">OpenGraph Banner Image URL</label>
                  <input
                    type="url"
                    value={ogImage}
                    onChange={(e) => setOgImage(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Right: Real-time Previews */}
              <div className="space-y-4">
                {/* Google SERP Preview Card */}
                <div className="bg-white text-slate-900 p-4 rounded-2xl shadow-md border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block mb-2">
                    Google Search Result Simulation
                  </span>
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-xs text-slate-600">
                      <Globe className="w-3.5 h-3.5 text-slate-400" />
                      <span>{canonicalUrl}</span>
                    </div>
                    <h4 className="text-sm font-semibold text-blue-800 hover:underline cursor-pointer">
                      {metaTitle}
                    </h4>
                    <p className="text-xs text-slate-600 line-clamp-2">
                      {metaDescription}
                    </p>
                    <div className="text-[11px] text-amber-700 font-semibold pt-1">
                      ⭐ 4.8 &bull; 1,420 reviews &bull; Price: ₹1,999 to ₹24,999 &bull; In stock
                    </div>
                  </div>
                </div>

                {/* Social Card Preview (WhatsApp / Facebook / LinkedIn) */}
                <div className="bg-white border border-slate-800 rounded-2xl overflow-hidden shadow-md">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block px-4 pt-3">
                    Social Share Card (Facebook / WhatsApp / Twitter)
                  </span>
                  <div className="p-3">
                    <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-900">
                      <img src={ogImage} alt="OG Banner" className="w-full h-36 object-cover" />
                      <div className="p-3 space-y-1">
                        <span className="text-[10px] uppercase text-slate-400 font-mono">antifly.com</span>
                        <p className="font-bold text-white text-xs line-clamp-1">{metaTitle}</p>
                        <p className="text-slate-400 text-[11px] line-clamp-2">{metaDescription}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: SCHEMA MARKUP */}
          {activeTab === 'schema' && (
            <div className="space-y-3">
              <div className="flex justify-between items-center bg-white p-3 rounded-xl border border-slate-800">
                <span className="text-slate-400 text-xs font-semibold">
                  Valid Schema.org WebSite, Organization & Product Rich Snippets
                </span>
                <button
                  onClick={handleCopySchema}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-slate-800 font-bold rounded-lg transition-all"
                >
                  {hasCopiedSchema ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{hasCopiedSchema ? 'Copied' : 'Copy JSON-LD'}</span>
                </button>
              </div>

              <div className="bg-white border border-slate-800 rounded-2xl p-4 font-mono text-xs text-emerald-300 max-h-96 overflow-y-auto shadow-inner leading-relaxed">
                <pre>{schemaString}</pre>
              </div>
            </div>
          )}

          {/* TAB 3: SITEMAP.XML & ROBOTS.TXT */}
          {activeTab === 'sitemap' && (
            <div className="space-y-4">
              <div className="bg-white p-4 rounded-2xl border border-slate-800">
                <h4 className="font-bold text-white mb-2">Automated Dynamic XML Sitemap</h4>
                <div className="bg-slate-900 p-3 rounded-xl font-mono text-[11px] text-slate-300 max-h-48 overflow-y-auto">
                  {`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://antifly.com/</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  ${categories.map((c) => `  <url>\n    <loc>https://antifly.com/category/${c.slug}</loc>\n    <priority>0.8</priority>\n  </url>`).join('\n')}
  ${products.slice(0, 10).map((p) => `  <url>\n    <loc>https://antifly.com/product/${p.slug}</loc>\n    <priority>0.7</priority>\n  </url>`).join('\n')}
</urlset>`}
                </div>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-800">
                <h4 className="font-bold text-white mb-2">Robots.txt</h4>
                <div className="bg-slate-900 p-3 rounded-xl font-mono text-[11px] text-slate-300">
                  {`User-agent: *
Allow: /
Disallow: /admin
Disallow: /api/private/
Sitemap: https://antifly.com/sitemap.xml`}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
