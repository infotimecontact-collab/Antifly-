import React, { useState } from 'react';
import { Product } from '../../types';
import { useApp } from '../../context/AppContext';
import { Heart, Star, ShoppingBag, Sparkles, Scale, Eye, Check, ShieldCheck, Building2, Package, MessageSquare, Tag, Bookmark, Glasses } from 'lucide-react';
import { UniversalSaveButton } from '../favorites/UniversalSaveButton';

interface ProductCardProps {
  product: Product;
  badge?: string;
  isCompact?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, badge, isCompact = false }) => {
  const {
    wishlist,
    toggleWishlist,
    addToCart,
    setActivePdpId,
    addToComparison,
    comparisonList,
    openStoreChat,
    openStoreCommunity,
    openVirtualTryOn,
  } = useApp();

  const isWishlisted = (wishlist || []).includes(product?.id);
  const isCompared = (comparisonList || []).some((p) => p.id === product?.id);
  const [selectedVariant, setSelectedVariant] = useState(product?.variants?.[0] || null);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);

  const initialQty = product?.isWholesale ? (product.minOrderQuantity || 1) : 1;
  const primaryImage = product?.images?.[0] || product?.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600';

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart({
      productId: product.id,
      variantId: selectedVariant?.id || product.variants?.[0]?.id || 'default',
      productName: product.name,
      brand: product.brand,
      color: selectedVariant?.color || product.colors?.[0]?.name || 'Standard',
      size: selectedVariant?.size || product.sizes?.[0] || 'Standard',
      price: product.price,
      mrp: product.mrp,
      image: primaryImage,
      quantity: initialQty,
      stock: product.totalStock,
    });
  };

  const handleWishlistClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id);
  };

  const handleCompareClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToComparison(product);
  };

  return (
    <div
      id={`product-card-${product.id}`}
      onClick={() => setActivePdpId(product.id)}
      onMouseEnter={() => {
        setIsHovered(true);
        if (product?.images && (product.images.length || 0) > 1) setActiveImageIndex(1);
      }}
      onMouseLeave={() => {
        setIsHovered(false);
        setActiveImageIndex(0);
      }}
      className="group relative bg-white dark:bg-slate-900 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 hover:border-amber-400/60 dark:hover:border-amber-500/40 hover:shadow-xl transition-all duration-300 flex flex-col cursor-pointer"
    >
      {/* Image container */}
      <div className="relative aspect-[4/5] w-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
        <img
          src={product.images?.[activeImageIndex] || primaryImage}
          alt={product.name}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5 z-10">
          {product.isWholesale && (
            <span className="bg-gradient-to-r from-blue-700 to-indigo-800 text-white text-[10px] font-black tracking-wide uppercase px-2 py-0.5 rounded shadow-md flex items-center gap-1">
              <Package className="w-3 h-3 text-amber-300" />
              Wholesale MOQ: {product.minOrderQuantity || 12}
            </span>
          )}
          {product.isDealershipProduct && (
            <span className="bg-amber-600/90 backdrop-blur-md text-slate-800 text-[9px] font-black tracking-wider uppercase px-2 py-0.5 rounded shadow-sm flex items-center gap-1">
              <ShieldCheck className="w-2.5 h-2.5" />
              Dealership Vendor
            </span>
          )}
          {badge && !product.isWholesale && (
            <span className="bg-white/80 backdrop-blur-md text-amber-300 text-[10px] font-semibold tracking-wider uppercase px-2 py-0.5 rounded shadow-sm">
              {badge}
            </span>
          )}
          {product.discountPercentage > 0 && (
            <span className="bg-orange-600 text-white text-[11px] font-bold px-2 py-0.5 rounded shadow-sm">
              {product.discountPercentage}% OFF
            </span>
          )}
          {product.isNewArrival && !product.isWholesale && (
            <span className="bg-emerald-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-sm">
              NEW
            </span>
          )}
        </div>

        {/* Floating Quick Action Icons */}
        <div className="absolute top-2.5 right-2.5 flex flex-col gap-1.5 z-10">
          {/* Consistent Heart-Shaped Save / Favorite Button with Micro-Animation */}
          <div id={`save-favorite-wrapper-${product.id}`}>
            <UniversalSaveButton
              targetId={product.id}
              itemType="product"
              title={product.name}
              subtitle={product.brand}
              imageUrl={primaryImage}
              price={product.price}
              originalPrice={product.mrp}
              badge={product.discountPercentage > 0 ? `${product.discountPercentage}% OFF` : undefined}
              tags={[product.category, product.brand]}
              iconType="heart"
              size="sm"
              className="shadow-md"
            />
          </div>

          {/* Compare Button */}
          <button
            id={`compare-btn-${product.id}`}
            onClick={handleCompareClick}
            className={`p-2 rounded-full backdrop-blur-md transition-all shadow-sm ${
              isCompared
                ? 'bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-300'
                : 'bg-white/80 dark:bg-slate-900/80 text-slate-700 dark:text-slate-200 hover:text-amber-500 hover:scale-110'
            }`}
            title="Compare with another product"
          >
            <Scale className="w-4 h-4" />
          </button>
        </div>

        {/* Hover Quick View / Visual Search Overlay */}
        <div className="absolute bottom-2.5 inset-x-2.5 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex gap-1.5 z-10">
          <button
            onClick={handleQuickAdd}
            className="flex-1 bg-white/90 hover:bg-orange-600 text-white text-xs font-semibold py-2 px-2.5 rounded-lg backdrop-blur-md transition-all flex items-center justify-center gap-1 shadow-md"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span className="truncate">{product.isWholesale ? `Add Lot (${product.minOrderQuantity || 12})` : 'Quick Add'}</span>
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              openVirtualTryOn(product.id);
            }}
            className="p-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg backdrop-blur-md shadow-md transition-all"
            title="3D AR Virtual Try-On"
          >
            <Glasses className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              openStoreChat(product.sellerId || 'seller-indore-toys', product);
            }}
            className="p-2 bg-amber-500 hover:bg-amber-600 text-slate-800 font-bold rounded-lg backdrop-blur-md shadow-md transition-all"
            title="Bargain Custom Price with Store"
          >
            <Tag className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setActivePdpId(product.id);
            }}
            className="p-2 bg-white/90 dark:bg-slate-800/90 text-slate-800 dark:text-slate-200 hover:text-amber-500 rounded-lg backdrop-blur-md shadow-md"
            title="View Details"
          >
            <Eye className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Details Container */}
      <div className="p-3.5 flex-1 flex flex-col justify-between">
        <div>
          {/* Brand & Category */}
          <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 mb-1">
            <span className="font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-300 truncate max-w-[140px]">
              {product.brand}
            </span>
            <div className="flex items-center gap-1 bg-amber-50 dark:bg-amber-950/60 px-1.5 py-0.5 rounded text-amber-700 dark:text-amber-300 text-[10px] font-bold flex-shrink-0">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
              <span>{product.rating}</span>
              <span className="text-slate-400">({product.reviewCount})</span>
            </div>
          </div>

          {/* Product Name */}
          <h3
            className={`font-semibold text-slate-800 dark:text-slate-100 line-clamp-1 group-hover:text-orange-600 dark:group-hover:text-amber-400 transition-colors ${
              isCompact ? 'text-xs' : 'text-sm'
            }`}
          >
            {product.name}
          </h3>

          {/* Wholesale unit badge */}
          {product.isWholesale && (
            <div className="mt-1.5 flex items-center gap-1.5 text-[11px] font-bold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/50 px-2 py-0.5 rounded-md border border-indigo-200 dark:border-indigo-800/50">
              <span>₹{product.wholesalePricePerUnit || Math.round(product.price / (product.minOrderQuantity || 1))} / unit</span>
              <span className="text-slate-400 font-normal">• MOQ: {product.minOrderQuantity || 12}</span>
            </div>
          )}

          {/* Color variant dots */}
          {product?.colors && product.colors.length > 0 && !product.isWholesale && (
            <div className="flex items-center gap-1.5 mt-2">
              {product.colors.slice(0, 4).map((c, i) => (
                <span
                  key={i}
                  className="w-2.5 h-2.5 rounded-full border border-slate-300 dark:border-slate-700 ring-1 ring-transparent hover:ring-slate-400 dark:hover:ring-slate-500 transition-all"
                  style={{ backgroundColor: c.hex }}
                  title={c.name}
                />
              ))}
              {(product?.colors?.length || 0) > 4 && (
                <span className="text-[10px] text-slate-400 font-medium">
                  +{(product?.colors?.length || 4) - 4}
                </span>
              )}
            </div>
          )}
        </div>

        {/* Pricing & Stock Footer */}
        <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
          <div className="flex items-baseline gap-1.5">
            <span className="text-base font-bold text-slate-900 dark:text-white">
              ₹{product.price.toLocaleString('en-IN')}
            </span>
            {product.mrp > product.price && (
              <span className="text-xs text-slate-400 line-through">
                ₹{product.mrp.toLocaleString('en-IN')}
              </span>
            )}
            {product.isWholesale && (
              <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400">
                / {product.minOrderQuantity || 12} qty
              </span>
            )}
          </div>

          {/* Stock hint */}
          {product.totalStock <= 20 ? (
            <span className="text-[10px] font-medium text-orange-600 dark:text-orange-400">
              Only {product.totalStock} left
            </span>
          ) : (
            <span className="text-[10px] font-medium text-emerald-600 dark:text-emerald-400 flex items-center gap-0.5">
              <Check className="w-2.5 h-2.5" /> In Stock
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
