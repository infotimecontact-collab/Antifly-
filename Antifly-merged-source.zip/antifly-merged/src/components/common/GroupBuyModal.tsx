import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  X,
  Flame,
  Clock,
  CheckCircle2,
  Share2,
  ArrowRight,
  ShieldCheck,
  Zap,
  TrendingDown,
} from 'lucide-react';

export const GroupBuyModal: React.FC = () => {
  const {
    isGroupBuyModalOpen,
    setIsGroupBuyModalOpen,
    groupBuyDeals,
    joinGroupBuy,
    formatPrice,
    showToast,
  } = useApp();

  const [activeDealId, setActiveDealId] = useState<string>(groupBuyDeals?.[0]?.id || '');

  if (!isGroupBuyModalOpen) return null;

  return (
    <div
      id="group-buy-modal"
      className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 lg:p-6 animate-fade-in"
    >
      <div className="bg-white dark:bg-slate-900 w-full max-w-3xl rounded-3xl shadow-2xl border border-rose-200 dark:border-rose-950/40 overflow-hidden flex flex-col my-auto max-h-[92vh]">
        {/* WiseSquad Community Group Buy Header */}
        <div className="bg-gradient-to-r from-rose-600 via-pink-600 to-amber-500 p-6 text-white relative flex-shrink-0">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 shadow-inner">
                <Users className="w-8 h-8 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase tracking-wider bg-white text-rose-700 px-2 py-0.5 rounded-full">
                    👥 WiseSquad Group Buy Deals
                  </span>
                  <span className="text-[10px] font-bold text-rose-100 bg-slate-100/20 px-2 py-0.5 rounded-full">
                    Pool with 1 More Shopper • Save up to 40%
                  </span>
                </div>
                <h2 className="text-2xl font-black tracking-tight text-white mt-1">
                  Community Team Purchase Hub
                </h2>
                <p className="text-xs text-rose-100 font-medium opacity-90">
                  Join an open team or start your own. When 2 people join, both get the supplier wholesale group price!
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsGroupBuyModalOpen(false)}
              className="p-2 rounded-full bg-white/20 hover:bg-white/30 text-white transition"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Deals List */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          <div className="flex justify-between items-center">
            <h4 className="text-xs font-black uppercase tracking-wider text-stone-500">
              Live Active Buying Teams ({groupBuyDeals.length})
            </h4>
            <span className="text-xs text-emerald-600 font-bold flex items-center gap-1">
              <Zap className="w-3.5 h-3.5" /> Instant Team Confirmation
            </span>
          </div>

          <div className="space-y-4">
            {groupBuyDeals.map((deal) => {
              const spotsLeft = deal.requiredMembers - deal.currentMembers;
              return (
                <div
                  key={deal.id}
                  className="border border-stone-200 dark:border-slate-800 rounded-3xl p-5 bg-stone-50/50 dark:bg-slate-800/40 flex flex-col sm:flex-row items-center gap-5 hover:border-rose-300 transition"
                >
                  <img
                    src={deal.productImage}
                    alt={deal.productName}
                    className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover shadow-sm flex-shrink-0"
                  />

                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-black uppercase bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 px-2 py-0.5 rounded-md">
                        {deal.groupCode}
                      </span>
                      <span className="text-[11px] text-stone-400 font-medium flex items-center gap-1">
                        <Clock className="w-3 h-3" /> Ends in 3h 45m
                      </span>
                    </div>

                    <h4 className="font-extrabold text-stone-900 dark:text-white text-sm">
                      {deal.productName}
                    </h4>

                    {/* Team Leader Avatar */}
                    <div className="flex items-center gap-2 text-xs text-stone-600 dark:text-slate-300">
                      <img
                        src={deal.leaderAvatar}
                        alt={deal.leaderName}
                        className="w-6 h-6 rounded-full border border-pink-400 object-cover"
                      />
                      <span>
                        Started by <strong>{deal.leaderName}</strong> ({deal.currentMembers}/{deal.requiredMembers} joined)
                      </span>
                    </div>

                    <div className="flex items-center gap-3 pt-1">
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-lg font-black text-rose-600 dark:text-rose-400">
                          {formatPrice(deal.groupPrice)}
                        </span>
                        <span className="text-xs text-stone-400 line-through">
                          {formatPrice(deal.originalPrice)}
                        </span>
                      </div>
                      <span className="text-xs font-black text-emerald-600 bg-emerald-100 dark:bg-emerald-950/60 px-2 py-0.5 rounded-lg flex items-center gap-0.5">
                        <TrendingDown className="w-3.5 h-3.5" /> Save {formatPrice(deal.savings)}
                      </span>
                    </div>
                  </div>

                  <div className="flex-shrink-0 flex flex-col sm:items-end w-full sm:w-auto gap-2">
                    <button
                      onClick={() => joinGroupBuy(deal.id)}
                      className="w-full sm:w-auto px-5 py-2.5 bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white font-bold text-xs rounded-2xl shadow-md shadow-rose-600/20 active:scale-95 transition flex items-center justify-center gap-2"
                    >
                      <Users className="w-4 h-4" />
                      Join Team & Save {formatPrice(deal.savings)}
                    </button>
                    <span className="text-[10px] text-stone-400 text-center sm:text-right">
                      {spotsLeft === 1 ? '🔥 Only 1 spot left to complete deal' : `${spotsLeft} spots remaining`}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
