import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Sparkles,
  MessageSquare,
  ShieldCheck,
  Check,
  Clock,
  Zap,
  Users,
  Store,
  Crown,
  ChevronRight,
  Flame,
} from 'lucide-react';
import { VendorConnectTier } from '../../types';

export const VendorConnectMembershipModal: React.FC = () => {
  const {
    isConnectMembershipModalOpen,
    setIsConnectMembershipModalOpen,
    customerConnectState,
    purchaseConnectTier,
    sellers,
    formatPrice,
  } = useApp();

  if (!isConnectMembershipModalOpen) return null;

  const plans = [
    {
      id: 'tier_10_sellers' as VendorConnectTier,
      title: 'Starter Pack',
      priceUSD: 1,
      priceINR: 85,
      sellerQuota: 10,
      description: 'Connect with any 10 local or nationwide ventures for direct chat & bargaining.',
      tag: 'Best for Light Shoppers',
    },
    {
      id: 'tier_100_sellers' as VendorConnectTier,
      title: 'Active Shopper',
      priceUSD: 2,
      priceINR: 170,
      sellerQuota: 100,
      description: 'Connect with 100 ventures, join venture VIP communities & get instant price offers.',
      isPopular: true,
      tag: 'Most Popular',
    },
    {
      id: 'tier_500_sellers' as VendorConnectTier,
      title: 'Power Buyer & Trader',
      priceUSD: 5,
      priceINR: 425,
      sellerQuota: 500,
      description: 'Direct 1-on-1 access to 500 ventures with priority broadcast messages.',
      tag: 'High Volume',
    },
    {
      id: 'tier_1000_sellers' as VendorConnectTier,
      title: 'Enterprise Venture VIP',
      priceUSD: 10,
      priceINR: 850,
      sellerQuota: 1000,
      description: 'Unlimited ecosystem connect with 1,000 top wholesalers and ventures.',
      tag: 'Max Access',
    },
  ];

  return (
    <div
      id="vendor-connect-membership-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-rose-500/30 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header with Red Accent Branding */}
        <div className="relative p-6 bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shadow-inner">
              <MessageSquare className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black tracking-tight">
                  Venture Connect Membership
                </h2>
                <span className="bg-amber-400 text-slate-800 text-[10px] font-black uppercase px-2 py-0.5 rounded-full shadow-xs">
                  $1 Connect Engine
                </span>
              </div>
              <p className="text-xs text-rose-100 mt-0.5">
                Direct 1-on-1 Chats, Custom Price Bargaining & Venture Communities
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsConnectMembershipModalOpen(false)}
            className="p-2 rounded-xl text-rose-100 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* Active Free Trial Notification Banner */}
          {customerConnectState.isFreeTrialActive ? (
            <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-500/15 via-teal-500/10 to-emerald-500/15 border border-emerald-500/30 flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-emerald-500 text-white flex items-center justify-center flex-shrink-0 mt-0.5 shadow-sm">
                <Sparkles className="w-4 h-4" />
              </div>
              <div className="flex-1 text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-emerald-900 dark:text-emerald-300 text-sm">
                    🎉 3-Month 100% Free Trial Active!
                  </span>
                  <span className="bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-300 dark:border-emerald-800">
                    {customerConnectState.freeTrialDaysLeft} Days Remaining
                  </span>
                </div>
                <p className="text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  As part of our nationwide rollout, all customer accounts enjoy <strong>unlimited free venture connections for the first 3 months</strong>. After your trial, connect packages start at just $1 (₹85) for 10 ventures!
                </p>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/50 flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-rose-900 dark:text-rose-200">
                  Venture Connections Used: {customerConnectState?.contactedSellerIds?.length || 0} / {customerConnectState?.sellerQuota || 3}
                </span>
                <p className="text-slate-500 mt-0.5">
                  Upgrade your tier to chat with more ventures across your city.
                </p>
              </div>
              <span className="text-xs font-black text-rose-600 dark:text-rose-400 bg-white dark:bg-slate-800 px-3 py-1.5 rounded-xl border border-rose-300">
                Tier: {customerConnectState.currentTier.replace('tier_', '').replace('_', ' ').toUpperCase()}
              </span>
            </div>
          )}

          {/* Value Highlights */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex items-start gap-2.5">
              <Store className="w-4 h-4 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">Direct Venture Chat</h4>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Chat directly with any nearby grocery, milk, art, or apparel venture.
                </p>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex items-start gap-2.5">
              <Flame className="w-4 h-4 text-orange-500 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">Custom Bargaining</h4>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Propose custom target prices (e.g. ₹20 for ₹50 item) with counter-offers.
                </p>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex items-start gap-2.5">
              <Users className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">Venture VIP Community</h4>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Follow venture feeds, watch exclusive reels, and access flash-sale coupon codes.
                </p>
              </div>
            </div>
          </div>

          {/* Pricing Tiers Grid */}
          <div>
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
              Select Venture Connect Quota Tier
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {plans.map((plan) => {
                const isCurrent = customerConnectState.currentTier === plan.id;
                return (
                  <div
                    key={plan.id}
                    className={`relative p-4 rounded-2xl border-2 transition-all flex flex-col justify-between ${
                      plan.isPopular
                        ? 'border-red-500 bg-red-50/20 dark:bg-red-950/20 shadow-md'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-400 bg-white dark:bg-slate-800/50'
                    }`}
                  >
                    {plan.tag && (
                      <span className={`absolute -top-2.5 right-4 text-[10px] font-black uppercase px-2 py-0.5 rounded-full shadow-xs ${
                        plan.isPopular ? 'bg-red-600 text-white' : 'bg-slate-800 text-white'
                      }`}>
                        {plan.tag}
                      </span>
                    )}

                    <div>
                      <div className="flex items-baseline justify-between">
                        <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">
                          {plan.title}
                        </h4>
                        <div className="text-right">
                          <span className="text-lg font-black text-red-600 dark:text-red-400">
                            ${plan.priceUSD}
                          </span>
                          <span className="text-xs text-slate-500 font-semibold ml-1">
                            (₹{plan.priceINR})
                          </span>
                        </div>
                      </div>

                      <div className="mt-2 flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200">
                        <Check className="w-3.5 h-3.5 text-emerald-500" />
                        <span>Chat & Bargain with {plan.sellerQuota} Ventures</span>
                      </div>

                      <p className="text-[11px] text-slate-500 mt-1.5 leading-relaxed">
                        {plan.description}
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        purchaseConnectTier(plan.id);
                        setIsConnectMembershipModalOpen(false);
                      }}
                      className={`mt-4 w-full py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition ${
                        isCurrent
                          ? 'bg-emerald-600 text-white'
                          : plan.isPopular
                          ? 'bg-red-600 hover:bg-red-700 text-white shadow-md'
                          : 'bg-slate-900 hover:bg-slate-800 dark:bg-slate-700 text-white'
                      }`}
                    >
                      {isCurrent ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Current Active Tier</span>
                        </>
                      ) : (
                        <>
                          <Zap className="w-3.5 h-3.5" />
                          <span>Activate for ${plan.priceUSD} (₹{plan.priceINR})</span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-white border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
          <span>🔒 100% Secure Checkout via UPI, Cards, Net Banking & Wallets</span>
          <button
            onClick={() => setIsConnectMembershipModalOpen(false)}
            className="font-bold text-slate-700 dark:text-slate-300 hover:underline"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
