import React from 'react';
import { useApp } from '../../context/AppContext';
import { X, BookOpen, Calendar, ShieldCheck } from 'lucide-react';

export const CMSModal: React.FC = () => {
  const { activeCMSPage, setActiveCMSPage } = useApp();

  if (!activeCMSPage) return null;

  return (
    <div
      id="cms-modal-overlay"
      className="fixed inset-0 z-50 bg-white/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fade-in overflow-y-auto"
    >
      <div
        id="cms-modal-card"
        className="bg-white dark:bg-slate-900 w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[85vh]"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base">{activeCMSPage.title}</h3>
              <p className="text-[11px] text-slate-400">
                Official Antifly Policies & Information &bull; v{activeCMSPage.version}
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveCMSPage(null)}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-500 pb-3 border-b border-slate-200 dark:border-slate-800">
            <span className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              Last Revised: {activeCMSPage.lastUpdated}
            </span>
            <span className="flex items-center gap-1.5 text-emerald-600 font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" />
              Legally Compliant
            </span>
          </div>

          <div className="prose dark:prose-invert max-w-none text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed space-y-4 whitespace-pre-line">
            {activeCMSPage.content}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            onClick={() => setActiveCMSPage(null)}
            className="bg-slate-900 dark:bg-slate-700 hover:bg-slate-800 text-white font-bold px-5 py-2 rounded-xl text-xs"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
