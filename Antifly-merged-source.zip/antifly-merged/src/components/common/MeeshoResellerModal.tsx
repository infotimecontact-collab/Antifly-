import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Share2,
  X,
  Store,
  DollarSign,
  TrendingUp,
  Percent,
  CheckCircle2,
  Sparkles,
  Smartphone,
  Wallet,
  ArrowRight,
  ShieldAlert,
  Copy,
  Users,
} from 'lucide-react';

export const MeeshoResellerModal: React.FC = () => {
  const {
    isResellerModalOpen,
    setIsResellerModalOpen,
    resellerConfig,
    setResellerConfig,
    products,
    showToast,
    meeshoReturnChoice,
    setMeeshoReturnChoice,
  } = useApp();

  const [shopName, setShopName] = useState(resellerConfig.resellerShopName);
  const [marginPct, setMarginPct] = useState(resellerConfig.resellerMarginPercentage);
  const [selectedSampleProduct, setSelectedSampleProduct] = useState(products?.[0] || null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'share' | 'returns'>('dashboard');

  if (!isResellerModalOpen) return null;

  const sampleWholesalePrice = selectedSampleProduct?.price || 1499;
  const calculatedMargin = Math.round(sampleWholesalePrice * (marginPct / 100));
  const finalCustomerPrice = sampleWholesalePrice + calculatedMargin;

  const handleSaveConfig = () => {
    setResellerConfig((prev) => ({
      ...prev,
      resellerShopName: shopName,
      resellerMarginPercentage: marginPct,
      isReselling: true,
    }));
    showToast('🎉 Reseller Profile & Margin updated successfully!');
  };

  const handleCopyWhatsAppText = () => {
    const text = `🛍️ *${shopName} Special Festive Drop* 🛍️\n\n✨ *${selectedSampleProduct.name}*\n🏷️ Exclusive Price: ₹${finalCustomerPrice} (MRP: ₹${selectedSampleProduct.mrp})\n✅ 100% Premium Quality Verified\n🚚 Cash on Delivery & Free Home Delivery Available\n\n💬 Reply here to book your size right now!`;
    navigator.clipboard.writeText(text);
    showToast('📋 WhatsApp Catalog Message Copied to Clipboard!');
  };

  return (
    <div
      id="meesho-reseller-modal"
      className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 lg:p-6 animate-fade-in"
    >
      <div className="bg-white dark:bg-slate-900 w-full max-w-4xl rounded-3xl shadow-2xl border border-pink-200 dark:border-pink-950/40 overflow-hidden flex flex-col my-auto max-h-[92vh]">
        {/* WiseReseller Signature Pink Header */}
        <div className="bg-gradient-to-r from-pink-600 via-rose-500 to-pink-500 p-6 text-white relative overflow-hidden flex-shrink-0">
          <div className="flex items-start justify-between relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 shadow-inner">
                <Store className="w-8 h-8 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-black uppercase tracking-wider bg-white text-pink-700 px-2 py-0.5 rounded-full">
                    💼 WiseReseller Boutique Studio
                  </span>
                  <span className="text-[11px] font-bold text-pink-100 bg-slate-100/20 px-2 py-0.5 rounded-full">
                    Zero Investment • 100% Work From Home
                  </span>
                </div>
                <h2 className="text-2xl font-black tracking-tight text-white mt-1">
                  Start Your Own Online Business
                </h2>
                <p className="text-xs text-pink-100 font-medium opacity-90">
                  Add your margin, share on WhatsApp & Instagram, we deliver directly to your customer under your shop name!
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsResellerModalOpen(false)}
              className="p-2 rounded-full bg-white/20 hover:bg-white/30 text-white transition"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Reseller Earnings Cards */}
          <div className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-slate-100/20 backdrop-blur-md rounded-2xl p-3.5 border border-white/10">
              <p className="text-[11px] font-bold uppercase tracking-wider text-pink-200">Total Profit Earned</p>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-2xl font-black text-white">₹{resellerConfig.totalEarnings.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <div className="bg-slate-100/20 backdrop-blur-md rounded-2xl p-3.5 border border-white/10">
              <p className="text-[11px] font-bold uppercase tracking-wider text-pink-200">Ready to Withdraw</p>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-2xl font-black text-emerald-300">₹{resellerConfig.pendingEarnings.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <div className="bg-slate-100/20 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 flex items-center justify-between">
              <div>
                <p className="text-[11px] font-bold uppercase tracking-wider text-pink-200">Active Margin</p>
                <span className="text-2xl font-black text-amber-300">+{resellerConfig.resellerMarginPercentage}%</span>
              </div>
              <button
                onClick={() => showToast('💸 Payout request submitted to your registered UPI ID!')}
                className="px-3 py-1.5 bg-white text-pink-600 hover:bg-pink-50 font-black text-xs rounded-xl shadow-sm transition"
              >
                Withdraw UPI
              </button>
            </div>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center justify-between px-6 border-b border-stone-200 dark:border-slate-800 bg-stone-50 dark:bg-white">
          <div className="flex gap-4">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`py-3.5 text-xs font-bold border-b-2 flex items-center gap-1.5 transition ${
                activeTab === 'dashboard'
                  ? 'border-pink-600 text-pink-600 dark:text-pink-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Store className="w-4 h-4" />
              Shop & Margin Settings
            </button>
            <button
              onClick={() => setActiveTab('share')}
              className={`py-3.5 text-xs font-bold border-b-2 flex items-center gap-1.5 transition ${
                activeTab === 'share'
                  ? 'border-pink-600 text-pink-600 dark:text-pink-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Share2 className="w-4 h-4" />
              1-Click WhatsApp Share Studio
            </button>
            <button
              onClick={() => setActiveTab('returns')}
              className={`py-3.5 text-xs font-bold border-b-2 flex items-center gap-1.5 transition ${
                activeTab === 'returns'
                  ? 'border-pink-600 text-pink-600 dark:text-pink-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <ShieldAlert className="w-4 h-4" />
              SmartSaver Dual-Return Policy Options
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {activeTab === 'dashboard' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Form setup */}
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 dark:text-slate-400 mb-1.5">
                    Your Brand / WhatsApp Boutique Name
                  </label>
                  <div className="flex items-center gap-2">
                    <Store className="w-5 h-5 text-pink-500" />
                    <input
                      type="text"
                      value={shopName}
                      onChange={(e) => setShopName(e.target.value)}
                      placeholder="e.g. Royal Grace Fashions"
                      className="w-full px-3.5 py-2 rounded-xl border border-stone-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-semibold focus:outline-none focus:border-pink-500"
                    />
                  </div>
                  <p className="text-[11px] text-stone-400 mt-1">
                    * This name will appear on the shipping invoice delivered to your customer.
                  </p>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 dark:text-slate-400">
                      Target Profit Margin
                    </label>
                    <span className="text-sm font-black text-pink-600 dark:text-pink-400">{marginPct}% Profit</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="50"
                    step="1"
                    value={marginPct}
                    onChange={(e) => setMarginPct(Number(e.target.value))}
                    className="w-full accent-pink-600 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] font-bold text-stone-400 mt-1">
                    <span>5% (Budget)</span>
                    <span>25% (Recommended)</span>
                    <span>50% (High Margin)</span>
                  </div>
                </div>

                <button
                  onClick={handleSaveConfig}
                  className="w-full py-3 bg-pink-600 hover:bg-pink-700 active:scale-[0.99] text-white font-bold text-sm rounded-2xl shadow-lg shadow-pink-600/20 transition flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Save Reseller Profile
                </button>
              </div>

              {/* Live Margin Calculation Preview */}
              <div className="bg-stone-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-stone-200 dark:border-slate-700/80">
                <h4 className="font-black text-xs uppercase tracking-wider text-stone-700 dark:text-slate-300 mb-3 flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4 text-emerald-500" />
                  Live Order Profit Breakdown (Example)
                </h4>

                <div className="space-y-2.5 text-xs">
                  <div className="flex justify-between text-stone-600 dark:text-slate-400">
                    <span>Product Supplier Cost (Base):</span>
                    <span className="font-semibold text-stone-900 dark:text-white">₹{sampleWholesalePrice}</span>
                  </div>
                  <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-bold">
                    <span>Your Added Margin ({marginPct}%):</span>
                    <span>+₹{calculatedMargin}</span>
                  </div>
                  <div className="flex justify-between text-stone-600 dark:text-slate-400">
                    <span>Shipping & Delivery to Customer:</span>
                    <span className="text-emerald-600 font-bold">FREE (₹0)</span>
                  </div>
                  <div className="pt-2 border-t border-stone-200 dark:border-slate-700 flex justify-between font-black text-sm text-stone-900 dark:text-white">
                    <span>Final Customer Invoice Price:</span>
                    <span className="text-pink-600 dark:text-pink-400">₹{finalCustomerPrice}</span>
                  </div>
                </div>

                <div className="mt-4 p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 dark:border-emerald-900/50 text-[11px] text-emerald-800 dark:text-emerald-300">
                  💰 When your customer pays ₹{finalCustomerPrice} upon delivery, your bank account automatically receives{' '}
                  <strong>₹{calculatedMargin}</strong> within 48 hours!
                </div>
              </div>
            </div>
          )}

          {activeTab === 'share' && (
            <div className="space-y-4">
              <p className="text-xs text-stone-500 dark:text-slate-400">
                Select any product below to instantly generate a branded social catalog message with your custom pricing:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {products.slice(0, 4).map((p) => {
                  const custPrice = Math.round(p.price * (1 + marginPct / 100));
                  return (
                    <div
                      key={p.id}
                      onClick={() => setSelectedSampleProduct(p)}
                      className={`p-3 rounded-2xl border flex gap-3 cursor-pointer transition ${
                        selectedSampleProduct?.id === p.id
                          ? 'border-pink-500 bg-pink-50/50 dark:bg-pink-950/20 shadow-sm'
                          : 'border-stone-200 dark:border-slate-800 hover:border-pink-300'
                      }`}
                    >
                      <img src={p.images?.[0] || p.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200'} alt={p.name} className="w-16 h-16 rounded-xl object-cover" />
                      <div className="flex-1 min-w-0 text-xs">
                        <p className="font-bold text-stone-900 dark:text-white truncate">{p.name}</p>
                        <p className="text-stone-400 text-[11px]">Supplier Cost: ₹{p.price}</p>
                        <p className="font-black text-pink-600 dark:text-pink-400 mt-1">Your Price: ₹{custPrice}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {selectedSampleProduct && (
                <div className="mt-4 p-4 rounded-2xl bg-stone-900 text-stone-100 font-mono text-xs space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] uppercase font-bold text-emerald-400">📱 WhatsApp Ready Preview</span>
                    <button
                      onClick={handleCopyWhatsAppText}
                      className="px-3 py-1 bg-pink-600 hover:bg-pink-500 text-white font-sans text-xs font-bold rounded-lg flex items-center gap-1.5 transition"
                    >
                      <Copy className="w-3.5 h-3.5" /> Copy Message
                    </button>
                  </div>
                  <pre className="whitespace-pre-wrap font-sans text-xs leading-relaxed text-stone-200 bg-stone-950/70 p-3 rounded-xl border border-stone-800">
                    {`🛍️ *${shopName} Exclusive Collection* 🛍️\n\n✨ *${selectedSampleProduct.name}*\n🏷️ Special Offer: ₹${finalCustomerPrice} (MRP: ₹${selectedSampleProduct.mrp})\n✅ Quality Inspected & Assured\n🚚 Free COD & Home Delivery\n\n💬 Send me your size to order!`}
                  </pre>
                </div>
              )}
            </div>
          )}

          {activeTab === 'returns' && (
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500">
                SmartSaver Dual-Pricing & Return Policy
              </h4>
              <p className="text-xs text-stone-600 dark:text-slate-400">
                Choose the return flexibility you want to offer your customers during checkout:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div
                  onClick={() => {
                    setMeeshoReturnChoice('easy_return');
                    showToast('Selected All Returns allowed');
                  }}
                  className={`p-4 rounded-2xl border cursor-pointer transition ${
                    meeshoReturnChoice === 'easy_return'
                      ? 'border-pink-500 bg-pink-50/50 dark:bg-pink-950/20 ring-2 ring-pink-500/20'
                      : 'border-stone-200 dark:border-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-stone-900 dark:text-white">Easy Returns Allowed</span>
                    <span className="text-xs font-bold text-stone-500">Standard Price</span>
                  </div>
                  <p className="text-xs text-stone-500 dark:text-slate-400 mt-2">
                    Customer can return for any reason (sizing, change of mind, fit) within 7 days.
                  </p>
                </div>

                <div
                  onClick={() => {
                    setMeeshoReturnChoice('wrong_defective_only');
                    showToast('Selected Wrong/Defective returns only (Extra ₹50 saved)');
                  }}
                  className={`p-4 rounded-2xl border cursor-pointer transition ${
                    meeshoReturnChoice === 'wrong_defective_only'
                      ? 'border-pink-500 bg-pink-50/50 dark:bg-pink-950/20 ring-2 ring-pink-500/20'
                      : 'border-stone-200 dark:border-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-stone-900 dark:text-white">Wrong/Defective Only</span>
                    <span className="text-xs font-black text-emerald-600 bg-emerald-100 dark:bg-emerald-950 px-2 py-0.5 rounded">
                      SAVE EXTRA ₹50
                    </span>
                  </div>
                  <p className="text-xs text-stone-500 dark:text-slate-400 mt-2">
                    Returns accepted only if wrong item or physical defect delivered. Saves supplier logistics cost!
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
