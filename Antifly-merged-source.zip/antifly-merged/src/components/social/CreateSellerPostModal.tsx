import React, { useState } from 'react';
import {
  X,
  Store,
  Sparkles,
  UploadCloud,
  Tag,
  Pin,
  Image as ImageIcon,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface CreateSellerPostModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreateSellerPostModal: React.FC<CreateSellerPostModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { currentSeller, createSellerFeedPost } = useApp();

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [mediaUrl, setMediaUrl] = useState('');
  const [customFilePreview, setCustomFilePreview] = useState<string | null>(null);
  const [badge, setBadge] = useState('🔥 NEW ARRIVAL');
  const [pinned, setPinned] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const BADGE_PRESETS = [
    '🔥 NEW ARRIVAL',
    '⚡ FLAT 40% OFF',
    '🌟 DIRECT WEAVER PRICE',
    '👑 BIS HALLMARKED',
    '🥑 100% ORGANIC BATCH',
    '🎁 FESTIVE VIP OFFER',
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setCustomFilePreview(reader.result as string);
        setMediaUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) {
      alert('Please fill out the post title and details');
      return;
    }

    setIsSubmitting(true);
    try {
      await createSellerFeedPost({
        sellerId: currentSeller.id,
        sellerName: currentSeller.storeName,
        sellerPhone: currentSeller.phone,
        sellerAvatar: currentSeller.logoImage,
        sellerCity: currentSeller.city,
        title: title.trim(),
        content: content.trim(),
        mediaUrl: customFilePreview || mediaUrl || currentSeller.bannerImage,
        badge,
        pinned,
      });
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="create-seller-post-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-white/70 backdrop-blur-sm p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="create-seller-post-modal"
        className="w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl text-white my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-900/90">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
              <Store className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold">Publish Seller Store Post</h3>
              <p className="text-xs text-neutral-400">
                Shared to all followers, contacts & discover feeds
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Title */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Post Headline / Product Title
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. 🏮 Festive Banarasi Silk Sarees Collection is LIVE!"
              className="w-full bg-neutral-800 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500 font-semibold"
            />
          </div>

          {/* Badge Selection */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Promotion Badge / Tag
            </label>
            <div className="flex flex-wrap gap-1.5">
              {BADGE_PRESETS.map((b) => (
                <button
                  key={b}
                  type="button"
                  onClick={() => setBadge(b)}
                  className={`px-2.5 py-1 rounded-full text-xs font-bold transition-all ${
                    badge === b
                      ? 'bg-amber-500 text-neutral-950 shadow-md scale-105'
                      : 'bg-neutral-800 text-neutral-400 hover:bg-neutral-700 hover:text-neutral-200'
                  }`}
                >
                  {b}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Post Content & Story Details
            </label>
            <textarea
              required
              rows={4}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Describe your newly arrived products, batch freshness, special customer discount codes, or workshop highlights..."
              className="w-full bg-neutral-800 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500 resize-none leading-relaxed"
            />
          </div>

          {/* Media Upload */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Product Photo / Banner Image
            </label>
            <div className="relative border-2 border-dashed border-neutral-700 hover:border-amber-500 rounded-2xl p-4 bg-neutral-800/40 text-center transition-colors">
              {customFilePreview ? (
                <div className="relative">
                  <img
                    src={customFilePreview}
                    alt="Preview"
                    className="w-full h-36 object-cover rounded-xl"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setCustomFilePreview(null);
                      setMediaUrl('');
                    }}
                    className="absolute top-2 right-2 p-1 bg-slate-900/80 rounded-full hover:bg-slate-900 text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div>
                  <UploadCloud className="w-7 h-7 mx-auto text-neutral-400 mb-1" />
                  <p className="text-xs font-semibold text-neutral-200">
                    Upload product / store image
                  </p>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Pin toggle */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-neutral-800/50 border border-neutral-700/50">
            <div className="flex items-center gap-2 text-xs font-semibold text-neutral-300">
              <Pin className="w-4 h-4 text-amber-400" />
              <span>Pin to top of your store social feed</span>
            </div>
            <input
              type="checkbox"
              checked={pinned}
              onChange={(e) => setPinned(e.target.checked)}
              className="w-4 h-4 rounded text-amber-500 focus:ring-amber-500"
            />
          </div>

          {/* Submit */}
          <div className="pt-2 flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="w-1/3 py-3 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold text-xs transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 py-3 rounded-2xl bg-amber-500 hover:bg-amber-600 text-neutral-950 font-bold text-xs shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isSubmitting ? 'Publishing...' : 'Publish Store Post'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
