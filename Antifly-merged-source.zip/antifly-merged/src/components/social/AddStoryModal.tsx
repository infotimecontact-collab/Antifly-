import React, { useState } from 'react';
import {
  X,
  Camera,
  Type,
  Tag,
  Sparkles,
  Bike,
  Store,
  User,
  Image as ImageIcon,
  Check,
  Lock,
  Globe,
  UploadCloud,
  Palette,
  Phone,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { StoryMediaType } from '../../types';

interface AddStoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const GRADIENT_PRESETS = [
  { id: 'grad-1', name: 'Sunset Crimson', class: 'from-amber-600 via-rose-600 to-indigo-800' },
  { id: 'grad-2', name: 'Emerald Fresh', class: 'from-emerald-600 via-teal-700 to-cyan-900' },
  { id: 'grad-3', name: 'Deep Midnight', class: 'from-indigo-900 via-purple-900 to-neutral-900' },
  { id: 'grad-4', name: 'Golden Festive', class: 'from-amber-500 via-orange-600 to-rose-700' },
  { id: 'grad-5', name: 'Cyber Neon', class: 'from-fuchsia-600 via-pink-600 to-blue-700' },
  { id: 'grad-6', name: 'Monsoon Blue', class: 'from-blue-600 via-sky-700 to-indigo-950' },
];

const PRESET_PHOTO_TEMPLATES = [
  {
    category: 'driver',
    title: '🛵 On-Time Delivery Route',
    url: 'https://images.unsplash.com/photo-1617347454431-f49d7ff5c3b1?w=800&auto=format&fit=crop&q=80',
    defaultCaption: '⚡ On-road delivering 10-minute parcels with safety and care! Available across town 🛵💨',
  },
  {
    category: 'seller',
    title: '🏮 Saree Handloom Collection',
    url: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&auto=format&fit=crop&q=80',
    defaultCaption: '🔥 Fresh festive handloom saree stock just arrived! DM us for direct weaver discounts ✨',
  },
  {
    category: 'seller',
    title: '🥑 Farm Fresh Harvest',
    url: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=800&auto=format&fit=crop&q=80',
    defaultCaption: '🌿 100% Organic fruits & fresh vegetables ready for instant delivery! 🥭🥗',
  },
  {
    category: 'customer',
    title: '📦 Unboxing My Order',
    url: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800&auto=format&fit=crop&q=80',
    defaultCaption: '✨ Received my package in 12 mins from Antifly! Superb packaging & genuine quality 👌',
  },
];

export const AddStoryModal: React.FC<AddStoryModalProps> = ({ isOpen, onClose }) => {
  const { userPersonaProfile, addStory, currentDriver, currentSeller } = useApp();

  const [activeTab, setActiveTab] = useState<StoryMediaType>('image');
  const [selectedRole, setSelectedRole] = useState<'customer' | 'driver' | 'seller'>(
    userPersonaProfile.activePersona || 'customer'
  );
  const [selectedGradient, setSelectedGradient] = useState(
    GRADIENT_PRESETS?.[0] || { name: 'Sunset Amber', class: 'from-amber-500 via-orange-500 to-red-500' }
  );
  const [textStoryContent, setTextStoryContent] = useState('');
  const [caption, setCaption] = useState('');
  const [mediaUrl, setMediaUrl] = useState('');
  const [customFilePreview, setCustomFilePreview] = useState<string | null>(null);
  const [privacy, setPrivacy] = useState<'contacts_and_followers' | 'public'>('contacts_and_followers');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setCustomFilePreview(reader.result as string);
        setMediaUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      if (activeTab === 'text') {
        if (!textStoryContent.trim()) {
          alert('Please enter your status update text');
          setIsSubmitting(false);
          return;
        }
        await addStory({
          authorRole: selectedRole,
          mediaType: 'text',
          text: textStoryContent.trim(),
          backgroundColor: selectedGradient?.class || 'from-amber-500 via-orange-500 to-red-500',
          caption: caption.trim() || undefined,
          privacy,
        });
      } else {
        const finalUrl =
          customFilePreview ||
          mediaUrl ||
          (selectedRole === 'driver'
            ? (PRESET_PHOTO_TEMPLATES?.[0]?.url || 'https://images.unsplash.com/photo-1580674684081-7617fbf3d745?w=800')
            : selectedRole === 'seller'
            ? (PRESET_PHOTO_TEMPLATES?.[1]?.url || 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800')
            : (PRESET_PHOTO_TEMPLATES?.[3]?.url || 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800'));

        await addStory({
          authorRole: selectedRole,
          mediaType: activeTab,
          mediaUrl: finalUrl,
          caption: caption.trim() || undefined,
          privacy,
        });
      }

      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="add-story-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-white/75 backdrop-blur-sm p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="add-story-modal"
        className="w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl text-white my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-900/90">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold">Add Status & Story</h3>
              <p className="text-xs text-neutral-400">
                Disappears in 24 hours • WhatsApp-style sync
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Post As Persona Selector */}
          <div>
            <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">
              Post Status As
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setSelectedRole('customer')}
                className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-semibold border transition-all ${
                  selectedRole === 'customer'
                    ? 'bg-blue-600 border-blue-500 text-white shadow-md'
                    : 'bg-neutral-800/80 border-neutral-700 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                <User className="w-4 h-4" />
                <span>Customer</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedRole('driver')}
                className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-semibold border transition-all ${
                  selectedRole === 'driver'
                    ? 'bg-emerald-600 border-emerald-500 text-white shadow-md'
                    : 'bg-neutral-800/80 border-neutral-700 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                <Bike className="w-4 h-4" />
                <span>Driver Buddy</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedRole('seller')}
                className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-semibold border transition-all ${
                  selectedRole === 'seller'
                    ? 'bg-amber-600 border-amber-500 text-white shadow-md'
                    : 'bg-neutral-800/80 border-neutral-700 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                <Store className="w-4 h-4" />
                <span>Store / Seller</span>
              </button>
            </div>
          </div>

          {/* Story Format Tabs */}
          <div className="flex bg-neutral-800/90 p-1 rounded-2xl border border-neutral-700/60">
            <button
              type="button"
              onClick={() => setActiveTab('image')}
              className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'image'
                  ? 'bg-neutral-700 text-white shadow'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <ImageIcon className="w-4 h-4" /> Photo Story
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('text')}
              className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'text'
                  ? 'bg-neutral-700 text-white shadow'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Type className="w-4 h-4" /> Text Status
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('deal')}
              className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'deal'
                  ? 'bg-amber-500 text-neutral-950 shadow'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Tag className="w-4 h-4" /> Flash Deal
            </button>
          </div>

          {/* Tab 1: Text Story Builder */}
          {activeTab === 'text' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                  Choose Canvas Gradient
                </label>
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {GRADIENT_PRESETS.map((grad) => (
                    <button
                      key={grad.id}
                      type="button"
                      onClick={() => setSelectedGradient(grad)}
                      className={`w-9 h-9 rounded-full bg-gradient-to-br ${
                        grad.class
                      } flex-shrink-0 flex items-center justify-center ring-2 transition-all ${
                        selectedGradient.id === grad.id
                          ? 'ring-white scale-110'
                          : 'ring-transparent opacity-70 hover:opacity-100'
                      }`}
                      title={grad.name}
                    >
                      {selectedGradient.id === grad.id && (
                        <Check className="w-4 h-4 text-white" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Text Preview Canvas */}
              <div
                className={`w-full h-44 rounded-2xl bg-gradient-to-br ${selectedGradient.class} p-5 flex flex-col justify-center items-center text-center shadow-inner border border-white/10`}
              >
                <textarea
                  value={textStoryContent}
                  onChange={(e) => setTextStoryContent(e.target.value)}
                  placeholder="Type what's on your mind... (e.g. 🛵 Delivering in Indiranagar now! or 🏮 New Banarasi silk saree stock in store!)"
                  rows={3}
                  maxLength={180}
                  className="w-full bg-transparent text-white font-bold text-base text-center placeholder-white/60 resize-none focus:outline-none drop-shadow"
                />
                <span className="text-[10px] text-white/70 mt-2">
                  {180 - textStoryContent.length} chars left
                </span>
              </div>
            </div>
          )}

          {/* Tab 2 & 3: Photo or Deal Story */}
          {(activeTab === 'image' || activeTab === 'deal') && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                  Select Photo or Upload
                </label>

                {/* Upload or Preview Box */}
                <div className="relative border-2 border-dashed border-neutral-700 hover:border-emerald-500 rounded-2xl p-4 bg-neutral-800/40 text-center transition-colors">
                  {customFilePreview ? (
                    <div className="relative">
                      <img
                        src={customFilePreview}
                        alt="Preview"
                        className="w-full h-40 object-cover rounded-xl"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          setCustomFilePreview(null);
                          setMediaUrl('');
                        }}
                        className="absolute top-2 right-2 p-1 bg-slate-900/80 rounded-full hover:bg-slate-900 text-white"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div>
                      <UploadCloud className="w-8 h-8 mx-auto text-neutral-400 mb-1" />
                      <p className="text-xs font-semibold text-neutral-200">
                        Upload photo from device
                      </p>
                      <p className="text-[10px] text-neutral-400 mt-0.5">
                        JPG, PNG up to 10MB
                      </p>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        className="absolute inset-0 opacity-0 cursor-pointer"
                      />
                    </div>
                  )}
                </div>

                {/* Presets Gallery */}
                <div className="mt-3">
                  <p className="text-xs text-neutral-400 mb-2 font-medium">
                    Or pick a template:
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    {PRESET_PHOTO_TEMPLATES.map((tmpl, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          setMediaUrl(tmpl.url);
                          setCustomFilePreview(tmpl.url);
                          if (!caption) setCaption(tmpl.defaultCaption);
                        }}
                        className="flex items-center gap-2 p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-700/80 border border-neutral-700 text-left transition-all text-xs"
                      >
                        <img
                          src={tmpl.url}
                          alt={tmpl.title}
                          className="w-10 h-10 rounded-lg object-cover flex-shrink-0"
                        />
                        <span className="font-semibold text-neutral-200 line-clamp-1">
                          {tmpl.title}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Caption Input */}
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                  Caption / Details
                </label>
                <input
                  type="text"
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  placeholder="Add a short caption to your status..."
                  className="w-full bg-neutral-800 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          )}

          {/* Privacy & Audience Rules (WhatsApp style matching) */}
          <div className="p-3.5 rounded-2xl bg-neutral-800/60 border border-neutral-700/50 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
                Who can see this status?
              </label>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setPrivacy('contacts_and_followers')}
                className={`py-2 px-2.5 rounded-xl text-left text-xs border transition-all ${
                  privacy === 'contacts_and_followers'
                    ? 'bg-emerald-950/70 border-emerald-500 text-emerald-200'
                    : 'bg-neutral-800 border-neutral-700 text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <p className="font-bold flex items-center gap-1">
                  <Phone className="w-3 h-3 text-emerald-400" /> My Contacts & Follows
                </p>
                <p className="text-[10px] text-neutral-400 mt-0.5">
                  Visible to mutual phonebook numbers & followers
                </p>
              </button>

              <button
                type="button"
                onClick={() => setPrivacy('public')}
                className={`py-2 px-2.5 rounded-xl text-left text-xs border transition-all ${
                  privacy === 'public'
                    ? 'bg-emerald-950/70 border-emerald-500 text-emerald-200'
                    : 'bg-neutral-800 border-neutral-700 text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <p className="font-bold flex items-center gap-1">
                  <Globe className="w-3 h-3 text-blue-400" /> Public Community
                </p>
                <p className="text-[10px] text-neutral-400 mt-0.5">
                  Visible across Antifly status feeds
                </p>
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-2 flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="w-1/3 py-3 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold text-xs transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-neutral-950 font-bold text-xs shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isSubmitting ? 'Posting Status...' : 'Share 24-Hour Status'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
