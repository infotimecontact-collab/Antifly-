import React, { useState } from 'react';
import {
  Plus,
  Camera,
  Search,
  Phone,
  UserCheck,
  UserPlus,
  Bike,
  Store,
  User,
  Heart,
  MessageCircle,
  Share2,
  Sparkles,
  ShieldCheck,
  Tag,
  Clock,
  Pin,
  Filter,
  CheckCircle2,
  Trash2,
  Eye,
  Info,
  ChevronRight,
  RefreshCw,
  ShoppingBag,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { UserStory, UserPhoneContact, SellerFeedPost } from '../../types';
import { UniversalSaveButton } from '../favorites/UniversalSaveButton';

export const WhatsAppStatusHub: React.FC = () => {
  const {
    stories,
    phoneContacts,
    sellerFeedPosts,
    userPersonaProfile,
    currentDriver,
    currentSeller,
    openStoryViewer,
    setIsAddStoryModalOpen,
    setIsCreateSellerPostModalOpen,
    addPhoneContact,
    toggleFollowPhoneContact,
    deletePhoneContact,
    likeSellerFeedPost,
    addSellerFeedComment,
    canCurrentUserViewStory,
    getVisibleStoriesForCurrentUser,
    openStoreChat,
    sellers,
    showToast,
  } = useApp();

  // Internal Tabs: 'stories' | 'seller_feed' | 'contacts'
  const [activeSection, setActiveSection] = useState<'stories' | 'seller_feed' | 'contacts'>('stories');
  const [roleFilter, setRoleFilter] = useState<'all' | 'driver' | 'seller' | 'customer'>('all');
  const [searchContactQuery, setSearchContactQuery] = useState('');
  const [isAddContactModalOpen, setIsAddContactModalOpen] = useState(false);

  // New Contact Form State
  const [newContactName, setNewContactName] = useState('');
  const [newContactPhone, setNewContactPhone] = useState('');
  const [newContactRole, setNewContactRole] = useState<'customer' | 'driver' | 'seller'>('customer');

  // Comment input per post
  const [commentInputs, setCommentInputs] = useState<{ [postId: string]: string }>({});

  const visibleStories = getVisibleStoriesForCurrentUser();
  const currentUserId = userPersonaProfile.id || 'usr-master-101';
  const currentUserPhone = userPersonaProfile.phone || '+91 98260 12345';

  const myStories = stories.filter(
    (s) => s.authorId === currentUserId || s.authorPhone === currentUserPhone
  );

  const otherStories = visibleStories.filter(
    (s) => s.authorId !== currentUserId && s.authorPhone !== currentUserPhone
  );

  const filteredOtherStories = otherStories.filter((s) => {
    if (roleFilter === 'all') return true;
    return s.authorRole === roleFilter;
  });

  const filteredContacts = phoneContacts.filter((c) => {
    const q = searchContactQuery.toLowerCase();
    return c.name.toLowerCase().includes(q) || c.phone.includes(q);
  });

  const handleAddContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContactName.trim() || !newContactPhone.trim()) {
      alert('Please provide contact name and mobile number');
      return;
    }

    addPhoneContact({
      name: newContactName.trim(),
      phone: newContactPhone.trim(),
      role: newContactRole,
      isFollowed: true,
      isRegistered: true,
    });

    setNewContactName('');
    setNewContactPhone('');
    setIsAddContactModalOpen(false);
  };

  const handleCommentSubmit = (postId: string, e: React.FormEvent) => {
    e.preventDefault();
    const text = commentInputs[postId];
    if (!text || !text.trim()) return;
    addSellerFeedComment(postId, text);
    setCommentInputs((prev) => ({ ...prev, [postId]: '' }));
  };

  const formatTimeAgo = (dateStr: string) => {
    const diffMs = Date.now() - new Date(dateStr).getTime();
    const diffMins = Math.floor(diffMs / 60000);
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHrs = Math.floor(diffMins / 60);
    if (diffHrs < 24) return `${diffHrs}h ago`;
    return '1d ago';
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'driver':
        return <Bike className="w-3 h-3 text-white" />;
      case 'seller':
        return <Store className="w-3 h-3 text-white" />;
      default:
        return <User className="w-3 h-3 text-white" />;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'driver':
        return 'bg-emerald-600';
      case 'seller':
        return 'bg-amber-600';
      default:
        return 'bg-blue-600';
    }
  };

  return (
    <div id="whatsapp-status-hub" className="w-full max-w-5xl mx-auto px-3 sm:px-6 py-4 space-y-6">
      {/* Top Banner / Hero */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-900 via-teal-900 to-neutral-900 text-white p-5 sm:p-7 shadow-xl border border-emerald-700/40">
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>WhatsApp-Style Status & Community Hub</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
              Status & Stories Hub
            </h1>
            <p className="text-xs sm:text-sm text-neutral-300 max-w-xl leading-relaxed">
              Share real-time 24-hour status updates with people in your phone contacts and followers.
              Drivers share live delivery shifts, sellers post flash deals, and customers share reviews!
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              id="add-status-header-btn"
              onClick={() => setIsAddStoryModalOpen(true)}
              className="bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-black px-4 py-2.5 rounded-2xl text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/25 transition-all transform active:scale-95"
            >
              <Camera className="w-4 h-4" />
              <span>Post 24h Status</span>
            </button>

            {userPersonaProfile.activePersona === 'seller' || currentSeller ? (
              <button
                id="create-seller-post-btn"
                onClick={() => setIsCreateSellerPostModalOpen(true)}
                className="bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold px-3.5 py-2.5 rounded-2xl text-xs flex items-center gap-1.5 shadow-md transition-all"
              >
                <Store className="w-4 h-4" />
                <span>Store Post</span>
              </button>
            ) : null}
          </div>
        </div>

        {/* Subtle Background Glow */}
        <div className="absolute -top-12 -right-12 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Main Navigation Sub-Tabs */}
      <div className="flex items-center justify-between border-b border-neutral-200 dark:border-neutral-800 pb-2">
        <div className="flex items-center gap-2 bg-neutral-100 dark:bg-neutral-800/80 p-1.5 rounded-2xl">
          <button
            id="tab-status-updates"
            onClick={() => setActiveSection('stories')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeSection === 'stories'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <Camera className="w-4 h-4" />
            <span>24h Stories ({visibleStories.length})</span>
          </button>

          <button
            id="tab-seller-feed"
            onClick={() => setActiveSection('seller_feed')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeSection === 'seller_feed'
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <Store className="w-4 h-4" />
            <span>Seller Stream ({sellerFeedPosts.length})</span>
          </button>

          <button
            id="tab-phone-contacts"
            onClick={() => setActiveSection('contacts')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeSection === 'contacts'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <Phone className="w-4 h-4" />
            <span>My Phone Contacts ({phoneContacts.length})</span>
          </button>
        </div>

        {/* Sync Info Pill */}
        <div className="hidden md:flex items-center gap-1.5 text-xs text-neutral-500 dark:text-neutral-400 font-medium">
          <Info className="w-3.5 h-3.5 text-emerald-500" />
          <span>Synced with your mobile contacts & follows</span>
        </div>
      </div>

      {/* ========================================================= */}
      {/* SECTION 1: 24-HOUR STATUS & STORIES                       */}
      {/* ========================================================= */}
      {activeSection === 'stories' && (
        <div className="space-y-6">
          {/* Horizontal Circular Stories Ribbon (WhatsApp & Instagram style) */}
          <div className="p-4 bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200 dark:border-neutral-800 shadow-sm">
            <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-3 px-1">
              Active Updates (24h Status)
            </h3>
            <div className="flex items-center gap-4 overflow-x-auto pb-2 scrollbar-thin">
              {/* My Status Bubble */}
              <div className="flex flex-col items-center flex-shrink-0 cursor-pointer group">
                <div
                  className="relative"
                  onClick={() => {
                    const firstStory = myStories?.[0];
                    if (firstStory) {
                      openStoryViewer(firstStory, myStories || []);
                    } else {
                      setIsAddStoryModalOpen(true);
                    }
                  }}
                >
                  <div
                    className={`w-16 h-16 rounded-full p-0.5 flex items-center justify-center transition-transform group-hover:scale-105 ${
                      (myStories?.length || 0) > 0
                        ? 'bg-gradient-to-tr from-emerald-500 via-teal-400 to-green-500 ring-2 ring-emerald-400 ring-offset-2 dark:ring-offset-neutral-900'
                        : 'border-2 border-dashed border-neutral-300 dark:border-neutral-700'
                    }`}
                  >
                    <img
                      src={
                        userPersonaProfile?.avatar ||
                        'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'
                      }
                      alt="My Profile"
                      className="w-full h-full rounded-full object-cover bg-neutral-800"
                    />
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsAddStoryModalOpen(true);
                    }}
                    className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-emerald-500 hover:bg-emerald-600 text-neutral-950 font-black flex items-center justify-center shadow-md border-2 border-white dark:border-neutral-900 transition-transform active:scale-90"
                    title="Add new status"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
                <span className="text-xs font-bold text-neutral-900 dark:text-neutral-100 mt-2 text-center truncate max-w-[72px]">
                  My Status
                </span>
                <span className="text-[10px] text-neutral-500 dark:text-neutral-400">
                  {myStories.length > 0 ? `${myStories.length} active` : 'Tap to add'}
                </span>
              </div>

              {/* Other Active Stories Bubbles */}
              {visibleStories
                .filter((s) => s.authorId !== currentUserId && s.authorPhone !== currentUserPhone)
                .map((st) => (
                  <div
                    key={st.id}
                    className="flex flex-col items-center flex-shrink-0 cursor-pointer group"
                    onClick={() => openStoryViewer(st, visibleStories)}
                  >
                    <div className="relative">
                      <div
                        className={`w-16 h-16 rounded-full p-0.5 flex items-center justify-center transition-transform group-hover:scale-105 ${
                          st.isViewedByCurrentUser
                            ? 'bg-neutral-300 dark:bg-neutral-700'
                            : 'bg-gradient-to-tr from-emerald-500 via-amber-400 to-rose-500 ring-2 ring-emerald-400 ring-offset-2 dark:ring-offset-neutral-900'
                        }`}
                      >
                        <img
                          src={st.authorAvatar}
                          alt={st.authorName}
                          className="w-full h-full rounded-full object-cover bg-neutral-800"
                        />
                      </div>
                      <span
                        className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full ${getRoleColor(
                          st.authorRole
                        )} flex items-center justify-center border-2 border-white dark:border-neutral-900 shadow-sm`}
                      >
                        {getRoleIcon(st.authorRole)}
                      </span>
                    </div>
                    <span className="text-xs font-bold text-neutral-900 dark:text-neutral-100 mt-2 text-center truncate max-w-[76px]">
                      {st.authorName?.split(' ')?.[0] || st.authorName || 'User'}
                    </span>
                    <span className="text-[10px] text-neutral-500 dark:text-neutral-400">
                      {formatTimeAgo(st.createdAt)}
                    </span>
                  </div>
                ))}
            </div>
          </div>

          {/* Role Filters */}
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setRoleFilter('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  roleFilter === 'all'
                    ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 shadow-sm'
                    : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400'
                }`}
              >
                All Updates ({otherStories.length})
              </button>
              <button
                onClick={() => setRoleFilter('driver')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                  roleFilter === 'driver'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400'
                }`}
              >
                <Bike className="w-3.5 h-3.5" /> Delivery Buddies
              </button>
              <button
                onClick={() => setRoleFilter('seller')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                  roleFilter === 'seller'
                    ? 'bg-amber-600 text-white shadow-sm'
                    : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400'
                }`}
              >
                <Store className="w-3.5 h-3.5" /> Verified Stores
              </button>
              <button
                onClick={() => setRoleFilter('customer')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                  roleFilter === 'customer'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400'
                }`}
              >
                <User className="w-3.5 h-3.5" /> Contacts & Friends
              </button>
            </div>
          </div>

          {/* Stories Grid Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {/* If user has their own active status */}
            {myStories.map((mySt) => (
              <div
                key={mySt.id}
                onClick={() => openStoryViewer(mySt, myStories)}
                className="group relative h-72 rounded-3xl overflow-hidden cursor-pointer shadow-md hover:shadow-xl transition-all duration-300 border-2 border-emerald-500 bg-neutral-900 flex flex-col justify-between p-4"
              >
                {mySt.mediaType === 'image' || mySt.mediaType === 'deal' ? (
                  <>
                    <img
                      src={mySt.mediaUrl}
                      alt="My story"
                      className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-slate-900/40" />
                  </>
                ) : (
                  <div
                    className={`absolute inset-0 bg-gradient-to-br ${
                      mySt.backgroundColor || 'from-amber-600 via-rose-600 to-indigo-800'
                    } flex items-center justify-center p-6 text-center`}
                  >
                    <p className="text-sm font-bold text-white line-clamp-4">
                      {mySt.text}
                    </p>
                  </div>
                )}

                {/* Top Info */}
                <div className="relative z-10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <img
                      src={userPersonaProfile.avatar}
                      alt="My status"
                      className="w-8 h-8 rounded-full object-cover ring-2 ring-emerald-400"
                    />
                    <div>
                      <p className="text-xs font-bold text-white drop-shadow">Your Status</p>
                      <p className="text-[10px] text-emerald-300 font-medium">
                        {formatTimeAgo(mySt.createdAt)}
                      </p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500 text-neutral-950 shadow">
                    Active
                  </span>
                </div>

                {/* Bottom View Counter */}
                <div className="relative z-10 flex items-center justify-between text-white text-xs font-bold pt-2 border-t border-white/20">
                  <span className="flex items-center gap-1">
                    <Eye className="w-4 h-4 text-emerald-400" />
                    {mySt?.views?.length || 0} Views
                  </span>
                  <span className="flex items-center gap-1 text-rose-300">
                    <Heart className="w-4 h-4 fill-rose-400" />
                    {mySt?.likes?.length || 0}
                  </span>
                </div>
              </div>
            ))}

            {/* Other visible stories */}
            {filteredOtherStories.map((st) => (
              <div
                key={st.id}
                onClick={() => openStoryViewer(st, visibleStories)}
                className="group relative h-72 rounded-3xl overflow-hidden cursor-pointer shadow-md hover:shadow-xl transition-all duration-300 border border-neutral-200 dark:border-neutral-800 bg-neutral-900 flex flex-col justify-between p-4"
              >
                {st.mediaType === 'image' || st.mediaType === 'deal' ? (
                  <>
                    <img
                      src={st.mediaUrl}
                      alt={st.caption || 'Story'}
                      className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900/85 via-slate-900/20 to-slate-900/40" />
                  </>
                ) : (
                  <div
                    className={`absolute inset-0 bg-gradient-to-br ${
                      st.backgroundColor || 'from-amber-600 via-rose-600 to-indigo-800'
                    } flex items-center justify-center p-6 text-center`}
                  >
                    <p className="text-sm font-bold text-white line-clamp-4 leading-relaxed">
                      {st.text}
                    </p>
                  </div>
                )}

                {/* Top User Info */}
                <div className="relative z-10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <img
                      src={st.authorAvatar}
                      alt={st.authorName}
                      className="w-9 h-9 rounded-full object-cover ring-2 ring-emerald-400 shadow-md"
                    />
                    <div>
                      <p className="text-xs font-bold text-white drop-shadow truncate max-w-[130px]">
                        {st.authorName}
                      </p>
                      <p className="text-[10px] text-neutral-300">
                        {formatTimeAgo(st.createdAt)}
                      </p>
                    </div>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold text-white shadow flex items-center gap-1 ${getRoleColor(
                      st.authorRole
                    )}`}
                  >
                    {getRoleIcon(st.authorRole)}
                    <span className="capitalize">{st.authorRole}</span>
                  </span>
                </div>

                {/* Bottom Caption & Interactions */}
                <div className="relative z-10 space-y-2">
                  {st.caption && (
                    <p className="text-xs font-medium text-white line-clamp-2 drop-shadow bg-slate-900/50 backdrop-blur-sm p-2 rounded-xl border border-white/10">
                      {st.caption}
                    </p>
                  )}
                  <div className="flex items-center justify-between text-white text-xs">
                    <span className="text-[10px] text-emerald-300 font-medium">
                      📱 {st.authorPhone}
                    </span>
                    <span className="flex items-center gap-1 text-rose-300 font-bold">
                      <Heart className="w-3.5 h-3.5 fill-rose-400" />
                      {st?.likes?.length || 0}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredOtherStories.length === 0 && myStories.length === 0 && (
            <div className="text-center py-12 bg-white dark:bg-neutral-900 rounded-3xl border border-dashed border-neutral-300 dark:border-neutral-800 p-6">
              <Camera className="w-12 h-12 text-neutral-400 mx-auto mb-3 opacity-40" />
              <h4 className="text-sm font-bold text-neutral-700 dark:text-neutral-300">
                No active status updates found
              </h4>
              <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
                Be the first to post a 24-hour update or add contacts from your phonebook to sync their status!
              </p>
              <button
                onClick={() => setIsAddStoryModalOpen(true)}
                className="mt-4 bg-emerald-500 hover:bg-emerald-600 text-neutral-950 font-bold px-4 py-2 rounded-xl text-xs shadow-md"
              >
                Post Your Status
              </button>
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* SECTION 2: SELLER SOCIAL POSTS STREAM                     */}
      {/* ========================================================= */}
      {activeSection === 'seller_feed' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
                Verified Seller & Store Feeds
              </h3>
              <p className="text-xs text-neutral-500">
                Exclusive store releases, artisan weaver highlights, and wholesale batch drops
              </p>
            </div>

            {userPersonaProfile.activePersona === 'seller' && (
              <button
                onClick={() => setIsCreateSellerPostModalOpen(true)}
                className="bg-amber-500 hover:bg-amber-600 text-neutral-950 font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow-md"
              >
                <Plus className="w-4 h-4" />
                <span>Create Store Post</span>
              </button>
            )}
          </div>

          <div className="space-y-5">
            {sellerFeedPosts.map((post) => (
              <div
                key={post.id}
                className="bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200 dark:border-neutral-800 shadow-sm overflow-hidden"
              >
                {/* Post Header */}
                <div className="p-4 sm:p-5 flex items-center justify-between border-b border-neutral-100 dark:border-neutral-800/80">
                  <div className="flex items-center gap-3">
                    <img
                      src={post.sellerAvatar}
                      alt={post.sellerName}
                      className="w-11 h-11 rounded-full object-cover ring-2 ring-amber-500/50"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-neutral-900 dark:text-white">
                          {post.sellerName}
                        </h4>
                        <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-600 dark:text-amber-400">
                          <ShieldCheck className="w-3 h-3" /> Verified Store
                        </span>
                      </div>
                      <p className="text-xs text-neutral-500 flex items-center gap-1 mt-0.5">
                        <span>📍 {post.sellerCity || 'India'}</span>
                        <span>•</span>
                        <span>{formatTimeAgo(post.createdAt)}</span>
                        <span>•</span>
                        <span>📱 {post.sellerPhone}</span>
                      </p>
                    </div>
                  </div>

                  {post.badge && (
                    <span className="px-2.5 py-1 rounded-full text-xs font-black bg-amber-500 text-neutral-950 shadow-sm">
                      {post.badge}
                    </span>
                  )}
                </div>

                {/* Post Content */}
                <div className="p-4 sm:p-5 space-y-3">
                  <h3 className="text-base font-bold text-neutral-900 dark:text-white leading-snug">
                    {post.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed whitespace-pre-wrap">
                    {post.content}
                  </p>
                </div>

                {/* Media Image */}
                {post.mediaUrl && (
                  <div className="relative w-full max-h-96 overflow-hidden bg-neutral-950">
                    <img
                      src={post.mediaUrl}
                      alt={post.title}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                )}

                {/* Interaction & Action Bar */}
                <div className="p-4 bg-neutral-50 dark:bg-neutral-800/40 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => likeSellerFeedPost(post.id)}
                      className={`flex items-center gap-1.5 text-xs font-bold transition-all ${
                        post.likedByUserIds.includes(currentUserId)
                          ? 'text-rose-500'
                          : 'text-neutral-600 dark:text-neutral-400 hover:text-rose-500'
                      }`}
                    >
                      <Heart
                        className={`w-4 h-4 ${
                          post.likedByUserIds.includes(currentUserId) ? 'fill-rose-500' : ''
                        }`}
                      />
                      <span>{post.likesCount} Likes</span>
                    </button>

                    <span className="flex items-center gap-1.5 text-xs font-bold text-neutral-600 dark:text-neutral-400">
                      <MessageCircle className="w-4 h-4" />
                      <span>{post.commentsCount} Comments</span>
                    </span>

                    <button
                      onClick={() => {
                        if (navigator.clipboard) {
                          navigator.clipboard.writeText(
                            `${window.location.origin}/store/${post.sellerId}`
                          );
                          showToast('🔗 Store link copied to share on WhatsApp!');
                        }
                      }}
                      className="flex items-center gap-1.5 text-xs font-bold text-neutral-600 dark:text-neutral-400 hover:text-emerald-500"
                    >
                      <Share2 className="w-4 h-4" />
                      <span>Share</span>
                    </button>

                    {/* Universal Save Post Button */}
                    <UniversalSaveButton
                      targetId={post.id}
                      itemType="post"
                      title={post.title}
                      subtitle={`by ${post.sellerName}`}
                      imageUrl={post.mediaUrl}
                      tags={[post.sellerName, 'Post']}
                      size="sm"
                    />
                  </div>

                  <button
                    onClick={() => {
                      const matched = sellers.find(
                        (s) => s.phone === post.sellerPhone || s.id === post.sellerId
                      );
                      if (matched) {
                        openStoreChat(matched.id);
                      } else {
                        showToast(`Connecting to ${post.sellerName} chat...`);
                      }
                    }}
                    className="bg-amber-500 hover:bg-amber-600 text-neutral-950 font-bold px-3.5 py-1.5 rounded-xl text-xs flex items-center gap-1.5 shadow-sm"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Bargain & Chat</span>
                  </button>
                </div>

                {/* Comments Section */}
                <div className="p-4 bg-white dark:bg-neutral-900 border-t border-neutral-100 dark:border-neutral-800 space-y-3">
                  {(post?.comments?.length || 0) > 0 && (
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                      {post.comments.map((c) => (
                        <div
                          key={c.id}
                          className="flex items-start gap-2.5 p-2 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 text-xs"
                        >
                          <img
                            src={
                              c.userAvatar ||
                              'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80'
                            }
                            alt={c.userName}
                            className="w-7 h-7 rounded-full object-cover mt-0.5"
                          />
                          <div className="flex-1">
                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-neutral-900 dark:text-white">
                                {c.userName}
                              </span>
                              <span className="text-[10px] text-neutral-400">
                                {formatTimeAgo(c.createdAt)}
                              </span>
                            </div>
                            <p className="text-neutral-700 dark:text-neutral-300 mt-0.5">
                              {c.text}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Add Comment Input Form */}
                  <form
                    onSubmit={(e) => handleCommentSubmit(post.id, e)}
                    className="flex items-center gap-2 pt-1"
                  >
                    <input
                      type="text"
                      placeholder="Write a comment or ask about wholesale discount..."
                      value={commentInputs[post.id] || ''}
                      onChange={(e) =>
                        setCommentInputs((prev) => ({ ...prev, [post.id]: e.target.value }))
                      }
                      className="flex-1 bg-neutral-100 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl px-3.5 py-2 text-xs text-neutral-900 dark:text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500"
                    />
                    <button
                      type="submit"
                      disabled={!commentInputs[post.id]?.trim()}
                      className="bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 font-bold px-3 py-2 rounded-xl text-xs disabled:opacity-30 hover:opacity-90"
                    >
                      Post
                    </button>
                  </form>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SECTION 3: MY PHONE CONTACTS & FOLLOWS (WHATSAPP SYNC)    */}
      {/* ========================================================= */}
      {activeSection === 'contacts' && (
        <div className="space-y-5">
          {/* Explanation Box */}
          <div className="p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/50 flex items-start gap-3">
            <Phone className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="text-xs font-bold text-blue-900 dark:text-blue-200">
                WhatsApp-Style Address Book & Follow Matching
              </h4>
              <p className="text-xs text-blue-800 dark:text-blue-300 leading-relaxed">
                Stories and 24-hour status updates from drivers, sellers, and customers are visible to anyone saved in your phonebook and people you follow.
                Add local delivery boys, frequent store phone numbers, or friends to see their instant status updates!
              </p>
            </div>
          </div>

          {/* Search & Add Contact Header */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400" />
              <input
                type="text"
                placeholder="Search contact by name or phone..."
                value={searchContactQuery}
                onChange={(e) => setSearchContactQuery(e.target.value)}
                className="w-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-sm"
              />
            </div>

            <button
              onClick={() => setIsAddContactModalOpen(true)}
              className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-600 text-neutral-950 font-bold px-4 py-2.5 rounded-2xl text-xs flex items-center justify-center gap-2 shadow-md transition-all"
            >
              <UserPlus className="w-4 h-4" />
              <span>Add Phone Contact</span>
            </button>
          </div>

          {/* Contact List */}
          <div className="bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200 dark:border-neutral-800 shadow-sm divide-y divide-neutral-100 dark:divide-neutral-800 overflow-hidden">
            {filteredContacts.map((contact) => (
              <div
                key={contact.id}
                className="p-4 flex items-center justify-between hover:bg-neutral-50 dark:hover:bg-neutral-800/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <img
                      src={
                        contact.avatar ||
                        'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80'
                      }
                      alt={contact.name}
                      className="w-11 h-11 rounded-full object-cover"
                    />
                    {contact.hasActiveStory && (
                      <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 rounded-full ring-2 ring-white dark:ring-neutral-900 animate-pulse" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-neutral-900 dark:text-white">
                        {contact.name}
                      </h4>
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold text-white ${getRoleColor(
                          contact.role
                        )}`}
                      >
                        {contact.role}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-500 flex items-center gap-2 mt-0.5">
                      <span className="font-mono">{contact.phone}</span>
                      {contact.isRegistered ? (
                        <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-0.5">
                          <CheckCircle2 className="w-3 h-3" /> on Antifly
                        </span>
                      ) : (
                        <span className="text-neutral-400">Invite</span>
                      )}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => toggleFollowPhoneContact(contact.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                      contact.isFollowed
                        ? 'bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700'
                        : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200'
                    }`}
                  >
                    <UserCheck className="w-3.5 h-3.5" />
                    <span>{contact.isFollowed ? 'Following' : 'Follow'}</span>
                  </button>

                  <button
                    onClick={() => deletePhoneContact(contact.id)}
                    className="p-2 text-neutral-400 hover:text-rose-500 rounded-xl hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                    title="Remove Contact"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}

            {filteredContacts.length === 0 && (
              <div className="p-8 text-center text-neutral-400">
                <Phone className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <p className="text-xs font-semibold">No contacts found</p>
                <p className="text-[10px] text-neutral-500">
                  Add contacts above to see their real-time stories and numbers.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Add New Contact Modal */}
      {isAddContactModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-white/70 backdrop-blur-sm p-4"
          onClick={() => setIsAddContactModalOpen(false)}
        >
          <div
            className="w-full max-w-md bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-3xl p-6 shadow-2xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-neutral-100 dark:border-neutral-800 pb-3">
              <h3 className="text-base font-bold text-neutral-900 dark:text-white">
                Add Phone Contact to Sync
              </h3>
              <button
                onClick={() => setIsAddContactModalOpen(false)}
                className="text-neutral-400 hover:text-neutral-600"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddContact} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                  Full Name / Store Name
                </label>
                <input
                  type="text"
                  required
                  value={newContactName}
                  onChange={(e) => setNewContactName(e.target.value)}
                  placeholder="e.g. Ramesh Delivery Partner or Indiranagar Groceries"
                  className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl px-3.5 py-2 text-xs text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                  Mobile Number (With Country Code)
                </label>
                <input
                  type="text"
                  required
                  value={newContactPhone}
                  onChange={(e) => setNewContactPhone(e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl px-3.5 py-2 text-xs text-neutral-900 dark:text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                  Contact Category
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setNewContactRole('customer')}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                      newContactRole === 'customer'
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 border-transparent'
                    }`}
                  >
                    Customer
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewContactRole('driver')}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                      newContactRole === 'driver'
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 border-transparent'
                    }`}
                  >
                    Driver Buddy
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewContactRole('seller')}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                      newContactRole === 'seller'
                        ? 'bg-amber-600 text-white border-amber-600'
                        : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 border-transparent'
                    }`}
                  >
                    Store / Seller
                  </button>
                </div>
              </div>

              <div className="pt-2 flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddContactModalOpen(false)}
                  className="w-1/3 py-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 font-semibold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-neutral-950 font-bold text-xs shadow-md"
                >
                  Save & Sync Status
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
