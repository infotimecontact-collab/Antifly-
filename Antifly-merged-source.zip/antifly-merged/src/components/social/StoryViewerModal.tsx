import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Heart,
  Send,
  Eye,
  Trash2,
  Share2,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Bike,
  Store,
  User,
  ShoppingBag,
  Sparkles,
  Lock,
  Globe,
  Tag,
  Clock,
  Phone,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { UserStory } from '../../types';

interface StoryViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialStory: UserStory | null;
  storiesList: UserStory[];
}

export const StoryViewerModal: React.FC<StoryViewerModalProps> = ({
  isOpen,
  onClose,
  initialStory,
  storiesList,
}) => {
  const {
    userPersonaProfile,
    deleteStory,
    likeStory,
    replyToStory,
    viewStory,
    openStoreChat,
    sellers,
    setIsCartOpen,
  } = useApp();

  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [progress, setProgress] = useState<number>(0);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [replyText, setReplyText] = useState<string>('');
  const [showViewsList, setShowViewsList] = useState<boolean>(false);
  const [hasLikedLocal, setHasLikedLocal] = useState<boolean>(false);
  const [likeCountLocal, setLikeCountLocal] = useState<number>(0);

  const activeStory = (storiesList || [])[currentIndex] || storiesList?.[0] || initialStory || null;
  const currentUserId = userPersonaProfile.id || 'usr-master-101';
  const isOwnStory =
    activeStory &&
    (activeStory.authorId === currentUserId ||
      activeStory.authorPhone === userPersonaProfile.phone);

  // Sync index when initialStory changes
  useEffect(() => {
    if (initialStory && storiesList.length > 0) {
      const idx = storiesList.findIndex((s) => s.id === initialStory.id);
      if (idx !== -1) {
        setCurrentIndex(idx);
      }
    }
    setProgress(0);
  }, [initialStory, storiesList]);

  // Track view & likes for the current active story
  useEffect(() => {
    if (!activeStory || !isOpen) return;
    viewStory(activeStory.id);
    const likesArr = activeStory.likes || [];
    const liked = likesArr.includes(currentUserId);
    setHasLikedLocal(liked);
    setLikeCountLocal(likesArr.length);
    setProgress(0);
  }, [currentIndex, activeStory?.id, isOpen]);

  // Story progress timer (5 seconds per story)
  useEffect(() => {
    if (!isOpen || isPaused || showViewsList) return;

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          handleNext();
          return 0;
        }
        return prev + 2; // ~5 seconds total
      });
    }, 100);

    return () => clearInterval(interval);
  }, [isOpen, isPaused, showViewsList, currentIndex, storiesList?.length]);

  if (!isOpen || !activeStory) return null;

  const handleNext = () => {
    if (currentIndex < storiesList.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setProgress(0);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
      setProgress(0);
    }
  };

  const handleLike = () => {
    likeStory(activeStory.id);
    setHasLikedLocal(!hasLikedLocal);
    setLikeCountLocal((prev) => (hasLikedLocal ? prev - 1 : prev + 1));
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim()) return;
    replyToStory(activeStory.id, replyText);
    setReplyText('');
  };

  const handleDelete = () => {
    if (window.confirm('Delete this status update?')) {
      deleteStory(activeStory.id);
      if (storiesList.length <= 1) {
        onClose();
      } else {
        handleNext();
      }
    }
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'driver':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/90 text-white shadow-sm">
            <Bike className="w-3 h-3" /> Delivery Buddy
          </span>
        );
      case 'seller':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-500/90 text-white shadow-sm">
            <Store className="w-3 h-3" /> Verified Seller
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-blue-500/90 text-white shadow-sm">
            <User className="w-3 h-3" /> Customer
          </span>
        );
    }
  };

  const formatTimeAgo = (dateStr: string) => {
    const diffMs = Date.now() - new Date(dateStr).getTime();
    const diffMins = Math.floor(diffMs / 60000);
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHrs = Math.floor(diffMins / 60);
    if (diffHrs < 24) return `${diffHrs}h ago`;
    return '1d ago';
  };

  return (
    <div
      id="story-viewer-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-white/90 backdrop-blur-md select-none transition-all duration-200"
      onClick={() => onClose()}
    >
      {/* Story Container Container Frame */}
      <div
        id="story-viewer-modal"
        className="relative w-full max-w-md h-[92vh] max-h-[820px] bg-neutral-900 rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between border border-neutral-800"
        onClick={(e) => e.stopPropagation()}
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
        onTouchStart={() => setIsPaused(true)}
        onTouchEnd={() => setIsPaused(false)}
      >
        {/* Top Progress Bars */}
        <div className="absolute top-0 inset-x-0 z-20 p-3 pt-4 flex gap-1.5 bg-gradient-to-b from-slate-900/80 via-slate-900/40 to-transparent">
          {storiesList.map((st, idx) => (
            <div
              key={st.id}
              className="flex-1 h-1 bg-white/25 rounded-full overflow-hidden"
            >
              <div
                className="h-full bg-white transition-all duration-100 ease-linear rounded-full"
                style={{
                  width:
                    idx < currentIndex
                      ? '100%'
                      : idx === currentIndex
                      ? `${progress}%`
                      : '0%',
                }}
              />
            </div>
          ))}
        </div>

        {/* Top Bar / Author Info */}
        <div className="absolute top-7 inset-x-0 z-20 px-4 py-2 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src={activeStory.authorAvatar}
                alt={activeStory.authorName}
                className="w-11 h-11 rounded-full object-cover ring-2 ring-emerald-400 p-0.5 bg-neutral-800"
              />
              <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-neutral-900 rounded-full flex items-center justify-center">
                <ShieldCheck className="w-2.5 h-2.5 text-white" />
              </span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <p className="text-sm font-bold text-white tracking-tight drop-shadow">
                  {activeStory.authorName}
                </p>
                {getRoleBadge(activeStory.authorRole)}
              </div>
              <div className="flex items-center gap-2 text-xs text-neutral-300">
                <span className="flex items-center gap-1 font-medium">
                  <Clock className="w-3 h-3 text-neutral-400" />
                  {formatTimeAgo(activeStory.createdAt)}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1 text-emerald-300">
                  {activeStory.privacy === 'public' ? (
                    <>
                      <Globe className="w-3 h-3" /> Public
                    </>
                  ) : (
                    <>
                      <Lock className="w-3 h-3" /> Contacts & Follows
                    </>
                  )}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1 text-white">
            {isOwnStory && (
              <button
                id="story-delete-btn"
                onClick={handleDelete}
                className="p-2 hover:bg-white/20 rounded-full transition-colors text-rose-400"
                title="Delete your story"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            )}
            <button
              id="story-close-btn"
              onClick={onClose}
              className="p-2 hover:bg-white/20 rounded-full transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Story Content Canvas Area */}
        <div className="relative flex-1 w-full h-full flex items-center justify-center overflow-hidden bg-neutral-950">
          {activeStory.mediaType === 'image' || activeStory.mediaType === 'deal' ? (
            <div className="relative w-full h-full flex items-center justify-center">
              <img
                src={activeStory.mediaUrl}
                alt={activeStory.caption || 'Story media'}
                className="w-full h-full object-cover select-none"
              />
              {/* Dark subtle overlay for text readability */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-transparent to-slate-950/30 pointer-events-none" />

              {/* Deal Banner Overlay if present */}
              {activeStory.mediaType === 'deal' && (
                <div className="absolute top-24 left-4 right-4 z-10 bg-amber-500/95 text-neutral-950 p-3 rounded-2xl shadow-xl backdrop-blur-md flex items-center justify-between border border-amber-300/40 animate-pulse">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-neutral-950 font-bold" />
                    <div>
                      <p className="text-xs font-black uppercase tracking-wider">
                        ⚡ Limited 24-Hour Status Deal
                      </p>
                      <p className="text-xs font-medium">
                        Direct discount for connected contacts & followers
                      </p>
                    </div>
                  </div>
                  <Tag className="w-5 h-5 text-neutral-950" />
                </div>
              )}
            </div>
          ) : (
            /* Text Story Canvas */
            <div
              className={`w-full h-full flex flex-col items-center justify-center p-8 text-center bg-gradient-to-br ${
                activeStory.backgroundColor || 'from-amber-600 via-rose-600 to-indigo-800'
              }`}
            >
              <div className="max-w-xs space-y-4">
                <span className="inline-block p-3 rounded-2xl bg-white/20 backdrop-blur-md shadow-lg">
                  {activeStory.authorRole === 'driver' ? (
                     <Bike className="w-8 h-8 text-white" />
                  ) : activeStory.authorRole === 'seller' ? (
                    <Store className="w-8 h-8 text-white" />
                  ) : (
                    <Sparkles className="w-8 h-8 text-white" />
                  )}
                </span>
                <p className="text-2xl font-bold text-white leading-relaxed drop-shadow-md whitespace-pre-wrap font-sans">
                  {activeStory.text}
                </p>
                <div className="pt-2">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-900/40 text-white/90 backdrop-blur-sm">
                    <Phone className="w-3 h-3 text-emerald-400" />
                    {activeStory.authorPhone}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Left/Right Navigation Tap Zones */}
          <div
            id="story-nav-prev-zone"
            className="absolute left-0 top-16 bottom-24 w-1/3 z-10 cursor-pointer"
            onClick={handlePrev}
          />
          <div
            id="story-nav-next-zone"
            className="absolute right-0 top-16 bottom-24 w-1/3 z-10 cursor-pointer"
            onClick={handleNext}
          />

          {/* Caption / Description Box */}
          {activeStory.caption && (
            <div className="absolute bottom-20 inset-x-0 z-20 px-4 py-3 pointer-events-none">
              <div className="bg-slate-900/70 backdrop-blur-md p-3.5 rounded-2xl border border-white/10 text-white shadow-lg pointer-events-auto">
                <p className="text-sm font-medium leading-snug">
                  {activeStory.caption}
                </p>
                {activeStory.authorCity && (
                  <p className="text-xs text-neutral-300 mt-1 flex items-center gap-1">
                    📍 {activeStory.authorCity}
                  </p>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Bottom Actions & Reply Bar */}
        <div className="relative z-20 p-3.5 bg-slate-900/95 backdrop-blur-lg border-t border-neutral-800/80">
          {isOwnStory ? (
            /* Story Owner Insights */
            <div className="flex items-center justify-between text-white px-2 py-1">
              <button
                id="story-viewers-toggle-btn"
                onClick={() => setShowViewsList(!showViewsList)}
                className="flex items-center gap-2 text-sm font-medium hover:text-emerald-400 transition-colors"
              >
                <Eye className="w-4 h-4 text-emerald-400" />
                <span>{activeStory?.views?.length || 0} Views</span>
                <span className="text-xs text-neutral-400">
                  (Tap to see contacts)
                </span>
              </button>

              <div className="flex items-center gap-4 text-sm font-medium">
                <span className="flex items-center gap-1 text-rose-400">
                  <Heart className="w-4 h-4 fill-rose-500" />
                  {likeCountLocal}
                </span>
                <span className="flex items-center gap-1 text-blue-400">
                  <Send className="w-4 h-4" />
                  {activeStory?.replies?.length || 0}
                </span>
              </div>
            </div>
          ) : (
            /* Viewer Reply & Interactive Bar */
            <div className="flex items-center gap-2">
              <form
                onSubmit={handleSendReply}
                className="flex-1 flex items-center bg-neutral-800/90 border border-neutral-700 rounded-full px-4 py-1.5 focus-within:ring-2 focus-within:ring-emerald-500"
              >
                <input
                  type="text"
                  placeholder={`Reply to ${activeStory?.authorName?.split(' ')?.[0] || activeStory?.authorName || 'Author'}...`}
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  className="w-full bg-transparent text-sm text-white placeholder-neutral-400 focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={!replyText.trim()}
                  className="text-emerald-400 hover:text-emerald-300 disabled:opacity-30 p-1"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>

              <button
                id="story-like-btn"
                onClick={handleLike}
                className={`p-2.5 rounded-full transition-all duration-200 ${
                  hasLikedLocal
                    ? 'bg-rose-500 text-white scale-110'
                    : 'bg-neutral-800 text-white hover:bg-neutral-700'
                }`}
                title="Like story"
              >
                <Heart
                  className={`w-5 h-5 ${hasLikedLocal ? 'fill-white' : ''}`}
                />
              </button>

              {/* Direct Quick Action */}
              {activeStory.authorRole === 'seller' && (
                <button
                  id="story-shop-btn"
                  onClick={() => {
                    const matched = sellers.find(
                      (s) =>
                        s.phone === activeStory.authorPhone ||
                        s.id === activeStory.authorId
                    );
                    if (matched) {
                      openStoreChat(matched.id);
                      onClose();
                    }
                  }}
                  className="bg-amber-500 hover:bg-amber-600 text-neutral-950 font-bold px-3 py-2 rounded-full text-xs flex items-center gap-1.5 shadow-md"
                  title="Direct Store Chat & Bargain"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>Shop Deal</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Viewers Bottom Sheet Drawer (For Story Author) */}
        {showViewsList && isOwnStory && (
          <div
            id="story-viewers-sheet"
            className="absolute inset-x-0 bottom-0 top-28 bg-neutral-900/98 backdrop-blur-xl z-30 rounded-t-3xl p-5 overflow-y-auto border-t border-neutral-700 shadow-2xl animate-in slide-in-from-bottom duration-200"
          >
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2 text-white font-bold">
                <Eye className="w-5 h-5 text-emerald-400" />
                <span>Seen by {activeStory?.views?.length || 0} contacts</span>
              </div>
              <button
                onClick={() => setShowViewsList(false)}
                className="text-neutral-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3">
              {(activeStory?.views?.length || 0) === 0 ? (
                <div className="py-8 text-center text-neutral-400">
                  <Eye className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p className="text-sm font-medium">No views yet</p>
                  <p className="text-xs text-neutral-500">
                    Contacts & followers will appear here once they view your status.
                  </p>
                </div>
              ) : (
                (activeStory?.views || []).map((vw, i) => (
                  <div
                    key={`${vw.userId}-${i}`}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-neutral-800/60 border border-neutral-700/50"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={
                          vw.userAvatar ||
                          'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80'
                        }
                        alt={vw.userName}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                      <div>
                        <p className="text-sm font-semibold text-white">
                          {vw.userName}
                        </p>
                        <p className="text-xs text-neutral-400">
                          {vw.userPhone || 'Phone Contact'} • {getRoleBadge(vw.userRole)}
                        </p>
                      </div>
                    </div>
                    <span className="text-xs text-neutral-400">
                      {formatTimeAgo(vw.viewedAt)}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      {/* Desktop External Navigation Arrows */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          handlePrev();
        }}
        disabled={currentIndex === 0}
        className="hidden md:flex absolute left-8 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md items-center justify-center text-white disabled:opacity-20 transition-all"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>
      <button
        onClick={(e) => {
          e.stopPropagation();
          handleNext();
        }}
        disabled={currentIndex === storiesList.length - 1}
        className="hidden md:flex absolute right-8 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md items-center justify-center text-white disabled:opacity-20 transition-all"
      >
        <ChevronRight className="w-6 h-6" />
      </button>
    </div>
  );
};
