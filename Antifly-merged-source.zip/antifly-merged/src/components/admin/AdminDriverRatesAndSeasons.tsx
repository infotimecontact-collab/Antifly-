import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { DeliverySeasonType } from '../../types';
import {
  Sun,
  CloudRain,
  Snowflake,
  CloudSun,
  IndianRupee,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  Zap,
  TrendingUp,
  MapPin,
  Clock,
  ShieldCheck,
  Sparkles,
  PhoneCall,
  Save,
  RotateCcw,
} from 'lucide-react';

export const AdminDriverRatesAndSeasons: React.FC = () => {
  const {
    adminDriverRateConfig,
    updateDriverRateConfig,
    calculateDynamicDriverPayout,
    drivers,
    initiateVentureBuddyBroadcast,
    showToast,
  } = useApp();

  // Local form state cloned from context
  const [formData, setFormData] = useState(adminDriverRateConfig);
  const [simulationDistance, setSimulationDistance] = useState<number>(3.0);
  const [isSimNight, setIsSimNight] = useState<boolean>(false);
  const [isSimPriority, setIsSimPriority] = useState<boolean>(false);
  const [isTestingCall, setIsTestingCall] = useState<boolean>(false);

  // Synchronize if context changes externally
  React.useEffect(() => {
    setFormData(adminDriverRateConfig);
  }, [adminDriverRateConfig]);

  const handleSeasonChange = (season: DeliverySeasonType) => {
    const updated = { ...formData, currentSeason: season };
    setFormData(updated);
  };

  const handleBaseFareChange = (val: number) => {
    // Strictly minimum 30 rupees floor
    const valid = Math.max(30, val);
    setFormData((prev) => ({ ...prev, baseFare: valid }));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.baseFare < 30) {
      showToast('⚠️ Driver Base Fare cannot be less than ₹30.');
      return;
    }
    await updateDriverRateConfig(formData);
  };

  const handleResetToDefaults = () => {
    setFormData({
      ...adminDriverRateConfig,
      baseFare: 30,
      ratePerKm: 15,
      currentSeason: 'RAINY',
      rainyMonsoonAllowance: 25,
      rainyMultiplier: 1.4,
      summerHeatAllowance: 15,
      summerMultiplier: 1.25,
      winterColdAllowance: 10,
      winterMultiplier: 1.15,
      nightShiftAllowance: 20,
      expressPriorityBonus: 30,
      minGuaranteedPayoutFloor: 30,
    });
    showToast('Reset form to recommended seasonal defaults.');
  };

  // Calculated live preview with current form values
  const simulatedPayout = calculateDynamicDriverPayout(simulationDistance, {
    isNight: isSimNight,
    isPriority: isSimPriority,
    customSeason: formData.currentSeason,
  });

  const handleTestBroadcast = async () => {
    setIsTestingCall(true);
    try {
      await initiateVentureBuddyBroadcast({
        deliveryDistanceKm: simulationDistance,
        parcelDescription: `[ADMIN SIMULATION] Test Delivery (${simulationDistance} km) - Season: ${formData.currentSeason}`,
        ratePerKm: formData.ratePerKm,
        baseFee: formData.baseFare,
      });
    } finally {
      setIsTestingCall(false);
    }
  };

  const activeDriversOnline = drivers.filter((d) => d.isOnline).length;

  return (
    <div id="admin-driver-rates-and-seasons" className="space-y-6 max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white rounded-2xl p-6 shadow-md border border-slate-700 relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-10 -translate-y-10 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-full text-xs font-black uppercase tracking-wider flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                Live Dynamic Dispatch
              </span>
              <span className="text-xs text-slate-400">
                Guaranteed Minimum Base: <strong className="text-emerald-400">₹30 or More</strong>
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white mt-2 tracking-tight">
              Driver Rates & Seasonal Pricing Engine
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl mt-1">
              Dynamically control driver base fees, distance rates (₹/KM), and instant seasonal hazard allowances for Summer Heatwaves, Monsoon Rains, and Winter conditions across the 50 KM city radius.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-800/80 border border-slate-700 p-3 rounded-xl">
            <div className="text-right">
              <p className="text-[11px] text-slate-400 font-bold uppercase">Online Buddy Fleet</p>
              <p className="text-lg font-black text-emerald-400">{activeDriversOnline} Drivers Active</p>
            </div>
            <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse ml-2" />
          </div>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Section 1: Active Season Selection Switcher */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <CloudSun className="w-5 h-5 text-amber-600" />
                1. Select Active City Season & Weather Condition
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Switching active season automatically applies the corresponding hazard allowance to all Venture bookings and Driver calls in real-time.
              </p>
            </div>
            <span className="text-xs font-bold px-2.5 py-1 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-lg">
              Active: {formData.currentSeason}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
            {/* Rainy Season */}
            <button
              type="button"
              onClick={() => handleSeasonChange('RAINY')}
              className={`p-4 rounded-xl border text-left transition-all relative overflow-hidden ${
                formData.currentSeason === 'RAINY'
                  ? 'border-blue-600 bg-blue-50/80 ring-2 ring-blue-500/20 shadow-xs'
                  : 'border-slate-200 hover:border-slate-300 bg-slate-50/50'
              }`}
            >
              {formData.currentSeason === 'RAINY' && (
                <div className="absolute top-2 right-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-600" />
                </div>
              )}
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center mb-3 shadow-xs">
                <CloudRain className="w-5 h-5" />
              </div>
              <p className="font-extrabold text-sm text-slate-900">🌧️ Monsoon / Rainy</p>
              <p className="text-xs text-slate-600 mt-1">
                Wet roads, waterlogging, rainwear wear-and-tear allowance.
              </p>
              <div className="mt-3 pt-2 border-t border-blue-200/60 flex items-center justify-between text-xs font-bold text-blue-900">
                <span>Rain Allowance:</span>
                <span className="text-blue-700">+₹{formData.rainyMonsoonAllowance} / trip</span>
              </div>
            </button>

            {/* Summer Season */}
            <button
              type="button"
              onClick={() => handleSeasonChange('SUMMER')}
              className={`p-4 rounded-xl border text-left transition-all relative overflow-hidden ${
                formData.currentSeason === 'SUMMER'
                  ? 'border-amber-600 bg-amber-50/80 ring-2 ring-amber-500/20 shadow-xs'
                  : 'border-slate-200 hover:border-slate-300 bg-slate-50/50'
              }`}
            >
              {formData.currentSeason === 'SUMMER' && (
                <div className="absolute top-2 right-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-600" />
                </div>
              )}
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center mb-3 shadow-xs">
                <Sun className="w-5 h-5" />
              </div>
              <p className="font-extrabold text-sm text-slate-900">☀️ Summer / Heatwave</p>
              <p className="text-xs text-slate-600 mt-1">
                High temperature, afternoon peak heat hydration allowance.
              </p>
              <div className="mt-3 pt-2 border-t border-amber-200/60 flex items-center justify-between text-xs font-bold text-amber-900">
                <span>Heat Allowance:</span>
                <span className="text-amber-700">+₹{formData.summerHeatAllowance} / trip</span>
              </div>
            </button>

            {/* Winter Season */}
            <button
              type="button"
              onClick={() => handleSeasonChange('WINTER')}
              className={`p-4 rounded-xl border text-left transition-all relative overflow-hidden ${
                formData.currentSeason === 'WINTER'
                  ? 'border-cyan-600 bg-cyan-50/80 ring-2 ring-cyan-500/20 shadow-xs'
                  : 'border-slate-200 hover:border-slate-300 bg-slate-50/50'
              }`}
            >
              {formData.currentSeason === 'WINTER' && (
                <div className="absolute top-2 right-2">
                  <CheckCircle2 className="w-4 h-4 text-cyan-600" />
                </div>
              )}
              <div className="w-10 h-10 rounded-xl bg-cyan-100 text-cyan-700 flex items-center justify-center mb-3 shadow-xs">
                <Snowflake className="w-5 h-5" />
              </div>
              <p className="font-extrabold text-sm text-slate-900">❄️ Winter / Morning Fog</p>
              <p className="text-xs text-slate-600 mt-1">
                Dense fog visibility, cold morning early rider allowance.
              </p>
              <div className="mt-3 pt-2 border-t border-cyan-200/60 flex items-center justify-between text-xs font-bold text-cyan-900">
                <span>Cold Allowance:</span>
                <span className="text-cyan-700">+₹{formData.winterColdAllowance} / trip</span>
              </div>
            </button>

            {/* Normal Season */}
            <button
              type="button"
              onClick={() => handleSeasonChange('NORMAL')}
              className={`p-4 rounded-xl border text-left transition-all relative overflow-hidden ${
                formData.currentSeason === 'NORMAL'
                  ? 'border-emerald-600 bg-emerald-50/80 ring-2 ring-emerald-500/20 shadow-xs'
                  : 'border-slate-200 hover:border-slate-300 bg-slate-50/50'
              }`}
            >
              {formData.currentSeason === 'NORMAL' && (
                <div className="absolute top-2 right-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                </div>
              )}
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-3 shadow-xs">
                <CloudSun className="w-5 h-5" />
              </div>
              <p className="font-extrabold text-sm text-slate-900">🌤️ Standard Season</p>
              <p className="text-xs text-slate-600 mt-1">
                Pleasant weather, standard base fee and distance-only calculation.
              </p>
              <div className="mt-3 pt-2 border-t border-emerald-200/60 flex items-center justify-between text-xs font-bold text-emerald-900">
                <span>Extra Allowance:</span>
                <span className="text-emerald-700">₹0 (Base + KM)</span>
              </div>
            </button>
          </div>
        </div>

        {/* Section 2: Core Base Fare (>= ₹30) and Per-KM Distance Rate */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Base Fare Controller */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div>
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <IndianRupee className="w-4 h-4 text-emerald-600" />
                  Guaranteed Driver Base Fare (₹30 or More)
                </h3>
                <span className="text-xs font-extrabold px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-md">
                  Min Floor: ₹30
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Every booking guarantees the driver this starting amount regardless of trip distance.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">
                  ₹
                </span>
                <input
                  type="number"
                  min="30"
                  max="200"
                  step="1"
                  value={formData.baseFare}
                  onChange={(e) => handleBaseFareChange(Number(e.target.value))}
                  className="w-full pl-8 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-base font-extrabold text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white"
                />
              </div>

              {/* Quick Preset Buttons */}
              <div className="flex items-center gap-1.5">
                {[30, 35, 40, 50].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => handleBaseFareChange(preset)}
                    className={`px-3 py-2 rounded-lg text-xs font-bold transition-all ${
                      formData.baseFare === preset
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    ₹{preset}
                  </button>
                ))}
              </div>
            </div>

            {formData.baseFare < 30 && (
              <p className="text-xs text-rose-600 font-bold flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                Base fare must be ₹30 or more than ₹30.
              </p>
            )}

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1">
              <div className="flex justify-between">
                <span>Venture Payment Requirement:</span>
                <strong className="text-slate-900">Seller pays full dynamic amount</strong>
              </div>
              <div className="flex justify-between">
                <span>Driver Settlement:</span>
                <strong className="text-emerald-700">Instant to Driver Wallet / UPI</strong>
              </div>
            </div>
          </div>

          {/* Rate Per KM Controller */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div>
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-amber-600" />
                  Distance Rate Per Kilometer (₹/KM)
                </h3>
                <span className="text-xs font-extrabold px-2 py-0.5 bg-amber-100 text-amber-800 rounded-md">
                  Active: ₹{formData.ratePerKm}/km
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Multiplied by the Google Maps / GPS delivery distance between Venture and Customer.
              </p>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                <span>₹10 / km (Budget)</span>
                <span className="text-base text-amber-600 font-extrabold">₹{formData.ratePerKm} / km</span>
                <span>₹50 / km (High Surge)</span>
              </div>
              <input
                type="range"
                min="10"
                max="50"
                step="1"
                value={formData.ratePerKm}
                onChange={(e) => setFormData({ ...formData, ratePerKm: Number(e.target.value) })}
                className="w-full accent-amber-500 h-2 bg-slate-200 rounded-lg cursor-pointer"
              />
              <div className="flex items-center gap-2 pt-1">
                {[12, 15, 18, 20, 25].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setFormData({ ...formData, ratePerKm: preset })}
                    className={`flex-1 py-1 rounded-md text-xs font-bold transition-all ${
                      formData.ratePerKm === preset
                        ? 'bg-amber-500 text-slate-800 font-extrabold'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    ₹{preset}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Section 3: Seasonal Allowances & Surcharges Detailed Config */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-indigo-600" />
            Seasonal Hazard Allowances & Time Surges
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Rainy Allowance */}
            <div className="p-4 bg-blue-50/50 rounded-xl border border-blue-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-blue-900 flex items-center gap-1.5">
                  <CloudRain className="w-4 h-4 text-blue-600" />
                  Rainy Season Bonus
                </span>
              </div>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">₹</span>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={formData.rainyMonsoonAllowance}
                  onChange={(e) => setFormData({ ...formData, rainyMonsoonAllowance: Number(e.target.value) })}
                  className="w-full pl-7 pr-3 py-2 bg-white border border-blue-300 rounded-lg text-xs font-bold text-slate-900"
                />
              </div>
              <p className="text-[11px] text-blue-800">Added to driver earnings during rainy days.</p>
            </div>

            {/* Summer Allowance */}
            <div className="p-4 bg-amber-50/50 rounded-xl border border-amber-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                  <Sun className="w-4 h-4 text-amber-600" />
                  Summer Heat Bonus
                </span>
              </div>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">₹</span>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={formData.summerHeatAllowance}
                  onChange={(e) => setFormData({ ...formData, summerHeatAllowance: Number(e.target.value) })}
                  className="w-full pl-7 pr-3 py-2 bg-white border border-amber-300 rounded-lg text-xs font-bold text-slate-900"
                />
              </div>
              <p className="text-[11px] text-amber-800">Peak heat hydration and fatigue allowance.</p>
            </div>

            {/* Night Shift Allowance */}
            <div className="p-4 bg-purple-50/50 rounded-xl border border-purple-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-purple-900 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-purple-600" />
                  Night Shift (10PM-6AM)
                </span>
              </div>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">₹</span>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={formData.nightShiftAllowance}
                  onChange={(e) => setFormData({ ...formData, nightShiftAllowance: Number(e.target.value) })}
                  className="w-full pl-7 pr-3 py-2 bg-white border border-purple-300 rounded-lg text-xs font-bold text-slate-900"
                />
              </div>
              <p className="text-[11px] text-purple-800">Incentivizes drivers for late-night food/parcel drops.</p>
            </div>

            {/* Express Priority Bonus */}
            <div className="p-4 bg-emerald-50/50 rounded-xl border border-emerald-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-900 flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-emerald-600" />
                  Express 15-Min Rush
                </span>
              </div>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">₹</span>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={formData.expressPriorityBonus}
                  onChange={(e) => setFormData({ ...formData, expressPriorityBonus: Number(e.target.value) })}
                  className="w-full pl-7 pr-3 py-2 bg-white border border-emerald-300 rounded-lg text-xs font-bold text-slate-900"
                />
              </div>
              <p className="text-[11px] text-emerald-800">Priority speed surcharge paid to fast dispatchers.</p>
            </div>
          </div>
        </div>

        {/* Section 4: Live Interactive Simulation Matrix (1km, 2km, 3km, 4km, etc.) */}
        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 rounded-2xl p-6 text-white border border-slate-700 shadow-md space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <h3 className="text-base font-extrabold text-white">
                  Live Venture-to-Driver Fare Simulation Matrix
                </h3>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Calculates the exact amount the Venture will be billed and the Driver will receive with active season and rates.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsSimNight(!isSimNight)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                  isSimNight
                    ? 'bg-purple-600 text-white border-purple-500'
                    : 'bg-slate-800 text-slate-300 border-slate-600 hover:bg-slate-700'
                }`}
              >
                🌙 Night Surge ({isSimNight ? 'ON' : 'OFF'})
              </button>
              <button
                type="button"
                onClick={() => setIsSimPriority(!isSimPriority)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                  isSimPriority
                    ? 'bg-emerald-600 text-white border-emerald-500'
                    : 'bg-slate-800 text-slate-300 border-slate-600 hover:bg-slate-700'
                }`}
              >
                ⚡ Priority Rush ({isSimPriority ? 'ON' : 'OFF'})
              </button>
            </div>
          </div>

          {/* Standard Distance Reference Table */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[1, 2, 3, 4].map((km) => {
              const calc = calculateDynamicDriverPayout(km, {
                isNight: isSimNight,
                isPriority: isSimPriority,
                customSeason: formData.currentSeason,
              });
              return (
                <div
                  key={km}
                  onClick={() => setSimulationDistance(km)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                    simulationDistance === km
                      ? 'bg-amber-500 text-slate-800 border-amber-400 font-extrabold shadow-sm ring-2 ring-amber-400/40'
                      : 'bg-slate-800/80 text-white border-slate-700 hover:border-slate-500'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs uppercase tracking-wider">{km} Kilometer</span>
                    <MapPin className="w-3.5 h-3.5 opacity-70" />
                  </div>
                  <p className="text-xl font-black mt-1">₹{calc.totalPayout}</p>
                  <p className={`text-[10px] mt-1 ${simulationDistance === km ? 'text-slate-900' : 'text-slate-400'}`}>
                    Base ₹{calc.baseFare} + {km}km @ ₹{calc.ratePerKm}/km
                    {calc.seasonalSurge > 0 ? ` + Season ₹${calc.seasonalSurge}` : ''}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Custom Distance Slider & Dynamic Result */}
          <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-700 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-300 font-bold">
                Custom Test Distance: <strong className="text-amber-400 text-sm">{simulationDistance} KM</strong>
              </span>
              <span className="text-xs text-emerald-400 font-mono font-bold">
                {simulatedPayout.breakdown}
              </span>
            </div>

            <input
              type="range"
              min="0.5"
              max="20"
              step="0.5"
              value={simulationDistance}
              onChange={(e) => setSimulationDistance(Number(e.target.value))}
              className="w-full accent-amber-400 h-2 bg-slate-700 rounded-lg cursor-pointer"
            />

            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-amber-500 text-slate-800 flex items-center justify-center font-black text-xl shadow-xs">
                  ₹{simulatedPayout.totalPayout}
                </div>
                <div>
                  <p className="text-sm font-extrabold text-white">
                    Venture Bills ₹{simulatedPayout.totalPayout} → Driver Earns ₹{simulatedPayout.totalPayout}
                  </p>
                  <p className="text-xs text-slate-400">
                    Includes ₹{simulatedPayout.baseFare} minimum floor + ₹{simulatedPayout.distanceFare} distance ({simulationDistance}km @ ₹{simulatedPayout.ratePerKm}/km) + ₹{simulatedPayout.seasonalSurge} {simulatedPayout.seasonApplied} allowance.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={handleTestBroadcast}
                disabled={isTestingCall}
                className="w-full sm:w-auto px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 shadow-xs transition-all disabled:opacity-50"
              >
                <PhoneCall className="w-4 h-4" />
                {isTestingCall ? 'Broadcasting...' : 'Simulate Live Buddy Broadcast Call'}
              </button>
            </div>
          </div>
        </div>

        {/* Action Bar (Save / Reset) */}
        <div className="flex items-center justify-between p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <button
            type="button"
            onClick={handleResetToDefaults}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl flex items-center gap-2 transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            Reset to Recommended Defaults
          </button>

          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-500 hidden sm:inline">
              Changes take effect immediately across all connected Venture & Buddy apps.
            </span>
            <button
              type="submit"
              className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-800 text-xs font-extrabold rounded-xl flex items-center gap-2 shadow-xs transition-all"
            >
              <Save className="w-4 h-4" />
              Save Dynamic Rates & Seasons
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
