import React, { useState, useMemo } from 'react';
import {
  X,
  Search,
  Coins,
  IndianRupee,
  Calendar,
  CheckCircle2,
  Download,
  Filter,
  User,
  Bike,
  ArrowRight,
  TrendingUp,
  CreditCard,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export interface DriverIncentiveLedgerEntry {
  id: string;
  driverId: string;
  driverName: string;
  driverPhone: string;
  vehicleNumber: string;
  vehicleType: string;
  orderId?: string;
  milestoneTitle: string;
  creditsConverted: number;
  rupeesAmount: number;
  conversionRate: string; // e.g. "1 Credit = ₹1"
  payoutUpiId: string;
  transactionRef: string;
  status: 'Completed' | 'Processing' | 'Failed';
  timestamp: string;
}

export const AdminDriverIncentiveLedgerModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
}> = ({ isOpen, onClose }) => {
  const { drivers, showToast } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDriverFilter, setSelectedDriverFilter] = useState('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  // Mock initial ledger entries with realistic driver milestone & order conversion history
  const [ledgerEntries] = useState<DriverIncentiveLedgerEntry[]>([
    {
      id: 'LEDGER-9901',
      driverId: 'drv-1',
      driverName: 'Rahul Sharma',
      driverPhone: '+91 98260 11223',
      vehicleNumber: 'MP-09-EV-8842',
      vehicleType: 'Electric Bike',
      orderId: 'ORD-98421',
      milestoneTitle: '20 Orders Daily Super Bonus',
      creditsConverted: 300,
      rupeesAmount: 300,
      conversionRate: '1 Credit = ₹1',
      payoutUpiId: 'rahulsharma@okhdfcbank',
      transactionRef: 'UPI-IND-883921092',
      status: 'Completed',
      timestamp: '2026-08-19 19:45',
    },
    {
      id: 'LEDGER-9902',
      driverId: 'drv-1',
      driverName: 'Rahul Sharma',
      driverPhone: '+91 98260 11223',
      vehicleNumber: 'MP-09-EV-8842',
      vehicleType: 'Electric Bike',
      orderId: 'ORD-98319',
      milestoneTitle: '10 Orders Milestone Incentive',
      creditsConverted: 120,
      rupeesAmount: 120,
      conversionRate: '1 Credit = ₹1',
      payoutUpiId: 'rahulsharma@okhdfcbank',
      transactionRef: 'UPI-IND-883920041',
      status: 'Completed',
      timestamp: '2026-08-19 14:15',
    },
    {
      id: 'LEDGER-9903',
      driverId: 'drv-2',
      driverName: 'Vikram Singh',
      driverPhone: '+91 98765 44321',
      vehicleNumber: 'MP-09-AB-4321',
      vehicleType: 'Motorcycle / Bike',
      orderId: 'REG-WELCOME',
      milestoneTitle: 'Vehicle Login Welcome Bonus',
      creditsConverted: 20,
      rupeesAmount: 20,
      conversionRate: '1 Credit = ₹1',
      payoutUpiId: 'vikram.singh@paytm',
      transactionRef: 'UPI-IND-883918822',
      status: 'Completed',
      timestamp: '2026-08-19 11:30',
    },
    {
      id: 'LEDGER-9904',
      driverId: 'drv-2',
      driverName: 'Vikram Singh',
      driverPhone: '+91 98765 44321',
      vehicleNumber: 'MP-09-AB-4321',
      vehicleType: 'Motorcycle / Bike',
      orderId: 'ORD-97812',
      milestoneTitle: '5 Orders Milestone Reward',
      creditsConverted: 50,
      rupeesAmount: 50,
      conversionRate: '1 Credit = ₹1',
      payoutUpiId: 'vikram.singh@paytm',
      transactionRef: 'UPI-IND-883916723',
      status: 'Completed',
      timestamp: '2026-08-19 16:50',
    },
    {
      id: 'LEDGER-9905',
      driverId: 'drv-3',
      driverName: 'Amit Patel',
      driverPhone: '+91 98930 55443',
      vehicleNumber: 'MP-09-EV-3312',
      vehicleType: 'EV Scooter',
      orderId: 'ORD-97645',
      milestoneTitle: '10 Orders Milestone Incentive',
      creditsConverted: 120,
      rupeesAmount: 120,
      conversionRate: '1 Credit = ₹1',
      payoutUpiId: 'amitpatel@okaxis',
      transactionRef: 'UPI-IND-883914501',
      status: 'Completed',
      timestamp: '2026-08-18 20:10',
    },
    {
      id: 'LEDGER-9906',
      driverId: 'drv-3',
      driverName: 'Amit Patel',
      driverPhone: '+91 98930 55443',
      vehicleNumber: 'MP-09-EV-3312',
      vehicleType: 'EV Scooter',
      orderId: 'ORD-97510',
      milestoneTitle: '20 Orders Daily Super Bonus',
      creditsConverted: 300,
      rupeesAmount: 300,
      conversionRate: '1 Credit = ₹1',
      payoutUpiId: 'amitpatel@okaxis',
      transactionRef: 'UPI-IND-883912199',
      status: 'Completed',
      timestamp: '2026-08-18 22:45',
    },
    {
      id: 'LEDGER-9907',
      driverId: 'drv-4',
      driverName: 'Deepak Verma',
      driverPhone: '+91 98111 88776',
      vehicleNumber: 'MP-09-CZ-9901',
      vehicleType: 'Cargo Delivery Van',
      orderId: 'REG-WELCOME',
      milestoneTitle: 'Vehicle Login Welcome Bonus',
      creditsConverted: 20,
      rupeesAmount: 20,
      conversionRate: '1 Credit = ₹1',
      payoutUpiId: 'deepak.verma@ybl',
      transactionRef: 'UPI-IND-883910087',
      status: 'Completed',
      timestamp: '2026-08-18 10:15',
    },
    {
      id: 'LEDGER-9908',
      driverId: 'drv-1',
      driverName: 'Rahul Sharma',
      driverPhone: '+91 98260 11223',
      vehicleNumber: 'MP-09-EV-8842',
      vehicleType: 'Electric Bike',
      orderId: 'ORD-97420',
      milestoneTitle: '5 Orders Milestone Reward',
      creditsConverted: 50,
      rupeesAmount: 50,
      conversionRate: '1 Credit = ₹1',
      payoutUpiId: 'rahulsharma@okhdfcbank',
      transactionRef: 'UPI-IND-883908819',
      status: 'Completed',
      timestamp: '2026-08-18 15:30',
    },
  ]);

  const filteredEntries = useMemo(() => {
    return ledgerEntries.filter((item) => {
      const matchSearch =
        item.driverName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.vehicleNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.orderId && item.orderId.toLowerCase().includes(searchQuery.toLowerCase())) ||
        item.transactionRef.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.payoutUpiId.toLowerCase().includes(searchQuery.toLowerCase());

      const matchDriver = selectedDriverFilter === 'ALL' || item.driverId === selectedDriverFilter;

      return matchSearch && matchDriver;
    });
  }, [ledgerEntries, searchQuery, selectedDriverFilter]);

  const totalPages = Math.ceil(filteredEntries.length / itemsPerPage) || 1;
  const paginatedEntries = filteredEntries.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const totalCreditsConverted = useMemo(() => {
    return filteredEntries.reduce((acc, curr) => acc + curr.creditsConverted, 0);
  }, [filteredEntries]);

  const totalRupeesPaid = useMemo(() => {
    return filteredEntries.reduce((acc, curr) => acc + curr.rupeesAmount, 0);
  }, [filteredEntries]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-white/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-5xl w-full shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center">
              <Coins className="w-6 h-6 text-amber-200" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-tight">
                Driver Incentive & Credit Conversion Ledger
              </h2>
              <p className="text-xs text-white/90 font-medium">
                Real-time audit log of all driver milestone credits, vehicle login bonuses, and instant UPI payouts
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 transition cursor-pointer text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Summary Metric Strip */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-5 bg-slate-50 border-b border-slate-200">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider">
              Total Credits Redeemed
            </span>
            <div className="text-xl font-black text-amber-600 mt-1 flex items-center gap-1.5">
              <Coins className="w-5 h-5 text-amber-500 fill-amber-300" />
              <span>{totalCreditsConverted.toLocaleString('en-IN')} Credits</span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider">
              Total Real Cash Disbursed
            </span>
            <div className="text-xl font-black text-emerald-600 mt-1 flex items-center gap-1.5">
              <IndianRupee className="w-5 h-5 text-emerald-600" />
              <span>₹{totalRupeesPaid.toLocaleString('en-IN')}.00</span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider">
              Conversion Standard
            </span>
            <div className="text-sm font-black text-slate-800 mt-1 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-blue-600" />
              <span>1 Incentive Credit = ₹1.00 INR (0% Deduction)</span>
            </div>
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="p-5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 bg-white">
          <div className="flex items-center gap-2 flex-1 min-w-[240px]">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="Search by driver name, vehicle number, order ID, or UPI ref..."
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <select
              value={selectedDriverFilter}
              onChange={(e) => {
                setSelectedDriverFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none"
            >
              <option value="ALL">All Drivers</option>
              {drivers.map((drv) => (
                <option key={drv.id} value={drv.id}>
                  {drv.name} ({drv.vehicleNumber})
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => {
              showToast('Exported Driver Incentive Ledger CSV successfully!');
            }}
            className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white px-3.5 py-2 rounded-xl text-xs font-black transition cursor-pointer shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>

        {/* Ledger Table */}
        <div className="p-5 overflow-x-auto flex-1">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-extrabold uppercase text-[10px]">
                <th className="py-3 px-3">Date & Time</th>
                <th className="py-3 px-3">Driver Partner</th>
                <th className="py-3 px-3">Vehicle Details</th>
                <th className="py-3 px-3">Milestone / Trigger</th>
                <th className="py-3 px-3">Credits</th>
                <th className="py-3 px-3">Real ₹ Payout</th>
                <th className="py-3 px-3">UPI Ref & Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedEntries.length > 0 ? (
                paginatedEntries.map((entry) => (
                  <tr key={entry.id} className="hover:bg-slate-50/70 transition">
                    <td className="py-3 px-3 font-semibold text-slate-600 whitespace-nowrap">
                      {entry.timestamp}
                    </td>

                    <td className="py-3 px-3">
                      <div className="font-extrabold text-slate-900">{entry.driverName}</div>
                      <div className="text-[10px] text-slate-500 font-medium">{entry.driverPhone}</div>
                    </td>

                    <td className="py-3 px-3">
                      <span className="font-bold text-slate-800">{entry.vehicleNumber}</span>
                      <div className="text-[10px] text-slate-500 font-medium">{entry.vehicleType}</div>
                    </td>

                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 font-black text-[10px] border border-blue-200">
                        {entry.milestoneTitle}
                      </span>
                      {entry.orderId && (
                        <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                          Ref: {entry.orderId}
                        </div>
                      )}
                    </td>

                    <td className="py-3 px-3 font-black text-amber-700 whitespace-nowrap">
                      +{entry.creditsConverted} pts
                    </td>

                    <td className="py-3 px-3 font-black text-emerald-700 whitespace-nowrap">
                      ₹{entry.rupeesAmount}.00
                    </td>

                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1 text-emerald-700 font-bold text-[11px]">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                        <span className="font-mono">{entry.transactionRef}</span>
                      </div>
                      <div className="text-[10px] text-slate-500 truncate max-w-[140px]">
                        {entry.payoutUpiId}
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-slate-400 font-bold">
                    No incentive records found matching your filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
          <div className="text-slate-600 font-medium">
            Showing {(currentPage - 1) * itemsPerPage + 1} to{' '}
            {Math.min(currentPage * itemsPerPage, filteredEntries.length)} of {filteredEntries.length} conversion records
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-40 cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4 text-slate-700" />
            </button>
            <span className="font-extrabold text-slate-900 px-2">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-40 cursor-pointer"
            >
              <ChevronRight className="w-4 h-4 text-slate-700" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
