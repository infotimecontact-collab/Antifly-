import React, { useState } from 'react';
import {
  Key,
  CreditCard,
  MessageSquare,
  Mail,
  ShieldCheck,
  Save,
  CheckCircle,
  Eye,
  EyeOff,
  Server,
  Zap,
  Globe,
  Lock,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AdminGateways: React.FC = () => {
  const { gatewayKeys, updateGatewayKeys, showToast } = useApp();
  const [formData, setFormData] = useState(gatewayKeys);
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});
  const [activeTab, setActiveTab] = useState<'payments' | 'sms' | 'email' | 'apis'>('payments');

  const toggleKeyVisibility = (field: string) => {
    setShowKeys((prev) => ({ ...prev, [field]: !prev[field] }));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateGatewayKeys(formData);
    showToast('Payment & SMS gateway credentials updated safely.');
  };

  return (
    <div className="space-y-6" id="admin-gateways-manager">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center text-amber-800">
            <Key className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-stone-900">Payment & Communication Gateways</h1>
            <p className="text-xs text-stone-500">
              Manage live production keys for Stripe, Razorpay, PayPal, Twilio SMS, Sendgrid, Maps & Gemini AI.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => {
              setFormData((prev) => ({
                ...prev,
                environmentMode: prev.environmentMode === 'production' ? 'sandbox' : 'production',
              }));
              showToast(
                `Gateway environment switched to ${formData.environmentMode === 'production' ? 'Sandbox' : 'Production'}`
              );
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors flex items-center gap-1.5 ${
              formData.environmentMode === 'production'
                ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                : 'bg-amber-50 border-amber-300 text-amber-800'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Mode: {formData.environmentMode.toUpperCase()}</span>
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="flex items-center gap-2 px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold rounded-xl shadow transition-colors"
          >
            <Save className="w-4 h-4 text-amber-400" />
            <span>Save All Gateway Keys</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-stone-200 bg-white px-6 pt-3 rounded-t-2xl">
        <button
          type="button"
          onClick={() => setActiveTab('payments')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'payments'
              ? 'border-amber-600 text-amber-900'
              : 'border-transparent text-stone-500 hover:text-stone-800'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>Payment Gateways (Stripe, Razorpay, PayPal)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('sms')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'sms'
              ? 'border-amber-600 text-amber-900'
              : 'border-transparent text-stone-500 hover:text-stone-800'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>SMS Gateways (Twilio, MSG91)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('email')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'email'
              ? 'border-amber-600 text-amber-900'
              : 'border-transparent text-stone-500 hover:text-stone-800'
          }`}
        >
          <Mail className="w-4 h-4" />
          <span>Transactional Email (Sendgrid / AWS SES)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('apis')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'apis'
              ? 'border-amber-600 text-amber-900'
              : 'border-transparent text-stone-500 hover:text-stone-800'
          }`}
        >
          <Globe className="w-4 h-4" />
          <span>Logistics Maps & AI APIs</span>
        </button>
      </div>

      {/* Tab Panels */}
      <form onSubmit={handleSave} className="bg-white p-6 rounded-b-2xl border border-t-0 border-stone-200 space-y-6">
        {activeTab === 'payments' && (
          <div className="space-y-6">
            {/* Stripe Gateway Card */}
            <div className="p-5 bg-stone-50/70 border border-stone-200 rounded-xl space-y-4">
              <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                <div className="flex items-center gap-2.5">
                  <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                  <h3 className="text-sm font-bold text-stone-900">Stripe Global (USA, UK, EU, Global Cards)</h3>
                </div>
                <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                  Active & 3DS2 Ready
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Stripe Publishable Key</label>
                  <input
                    type="text"
                    value={formData.stripePublishableKey}
                    onChange={(e) => setFormData({ ...formData, stripePublishableKey: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    placeholder="pk_live_..."
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Stripe Secret Key</label>
                  <div className="relative">
                    <input
                      type={showKeys['stripeSecret'] ? 'text' : 'password'}
                      value={formData.stripeSecretKey}
                      onChange={(e) => setFormData({ ...formData, stripeSecretKey: e.target.value })}
                      className="w-full px-3 py-2 pr-10 border border-stone-300 rounded-lg text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                      placeholder="sk_live_..."
                    />
                    <button
                      type="button"
                      onClick={() => toggleKeyVisibility('stripeSecret')}
                      className="absolute right-2.5 top-2.5 text-stone-400 hover:text-stone-700"
                    >
                      {showKeys['stripeSecret'] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Razorpay Gateway Card */}
            <div className="p-5 bg-stone-50/70 border border-stone-200 rounded-xl space-y-4">
              <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                <div className="flex items-center gap-2.5">
                  <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                  <h3 className="text-sm font-bold text-stone-900">Razorpay India (UPI, Netbanking, Rupay Cards)</h3>
                </div>
                <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                  UPI Auto-Refund Enabled
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Razorpay Key ID</label>
                  <input
                    type="text"
                    value={formData.razorpayKeyId}
                    onChange={(e) => setFormData({ ...formData, razorpayKeyId: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    placeholder="rzp_live_..."
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Razorpay Key Secret</label>
                  <div className="relative">
                    <input
                      type={showKeys['razorpaySecret'] ? 'text' : 'password'}
                      value={formData.razorpayKeySecret}
                      onChange={(e) => setFormData({ ...formData, razorpayKeySecret: e.target.value })}
                      className="w-full px-3 py-2 pr-10 border border-stone-300 rounded-lg text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                      placeholder="rzp_secret_..."
                    />
                    <button
                      type="button"
                      onClick={() => toggleKeyVisibility('razorpaySecret')}
                      className="absolute right-2.5 top-2.5 text-stone-400 hover:text-stone-700"
                    >
                      {showKeys['razorpaySecret'] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* PayPal Gateway Card */}
            <div className="p-5 bg-stone-50/70 border border-stone-200 rounded-xl space-y-4">
              <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                <div className="flex items-center gap-2.5">
                  <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                  <h3 className="text-sm font-bold text-stone-900">PayPal Worldwide (Express Checkout & Venmo)</h3>
                </div>
                <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                  Active
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">PayPal Client ID</label>
                  <input
                    type="text"
                    value={formData.paypalClientId}
                    onChange={(e) => setFormData({ ...formData, paypalClientId: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    placeholder="PAYPAL_CLIENT_ID..."
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Webhook Secret for Instant Refunds</label>
                  <input
                    type="text"
                    value={formData.webhookSecret}
                    onChange={(e) => setFormData({ ...formData, webhookSecret: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    placeholder="whsec_..."
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'sms' && (
          <div className="space-y-6">
            <div className="p-5 bg-stone-50/70 border border-stone-200 rounded-xl space-y-4">
              <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                <div className="flex items-center gap-2.5">
                  <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                  <h3 className="text-sm font-bold text-stone-900">Twilio Global SMS & WhatsApp Dispatch</h3>
                </div>
                <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                  DLT / 10DLC Registered
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Twilio Account SID</label>
                  <input
                    type="text"
                    value={formData.twilioAccountSid}
                    onChange={(e) => setFormData({ ...formData, twilioAccountSid: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    placeholder="AC..."
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Twilio Auth Token</label>
                  <div className="relative">
                    <input
                      type={showKeys['twilioAuth'] ? 'text' : 'password'}
                      value={formData.twilioAuthToken}
                      onChange={(e) => setFormData({ ...formData, twilioAuthToken: e.target.value })}
                      className="w-full px-3 py-2 pr-10 border border-stone-300 rounded-lg text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                      placeholder="Auth token..."
                    />
                    <button
                      type="button"
                      onClick={() => toggleKeyVisibility('twilioAuth')}
                      className="absolute right-2.5 top-2.5 text-stone-400 hover:text-stone-700"
                    >
                      {showKeys['twilioAuth'] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Sender Phone / Alphanumeric Sender ID</label>
                  <input
                    type="text"
                    value={formData.twilioSenderNumber}
                    onChange={(e) => setFormData({ ...formData, twilioSenderNumber: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    placeholder="+14155550199 or WISEIN"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'email' && (
          <div className="space-y-6">
            <div className="p-5 bg-stone-50/70 border border-stone-200 rounded-xl space-y-4">
              <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                <div className="flex items-center gap-2.5">
                  <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                  <h3 className="text-sm font-bold text-stone-900">SendGrid / AWS SES Transactional Email</h3>
                </div>
                <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                  DKIM & SPF Verified
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">SendGrid API Key</label>
                  <div className="relative">
                    <input
                      type={showKeys['sendgridKey'] ? 'text' : 'password'}
                      value={formData.sendgridApiKey}
                      onChange={(e) => setFormData({ ...formData, sendgridApiKey: e.target.value })}
                      className="w-full px-3 py-2 pr-10 border border-stone-300 rounded-lg text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                      placeholder="SG...."
                    />
                    <button
                      type="button"
                      onClick={() => toggleKeyVisibility('sendgridKey')}
                      className="absolute right-2.5 top-2.5 text-stone-400 hover:text-stone-700"
                    >
                      {showKeys['sendgridKey'] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Verified Sender Email</label>
                  <input
                    type="email"
                    value={formData.sendgridSenderEmail}
                    onChange={(e) => setFormData({ ...formData, sendgridSenderEmail: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    placeholder="orders@antifly.com"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'apis' && (
          <div className="space-y-6">
            <div className="p-5 bg-stone-50/70 border border-stone-200 rounded-xl space-y-4">
              <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                <div className="flex items-center gap-2.5">
                  <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                  <h3 className="text-sm font-bold text-stone-900">Google Maps Platform & Gemini AI API</h3>
                </div>
                <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                  GPS Route Simulation Active
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Google Maps API Key (Routes & Geocoding)</label>
                  <input
                    type="text"
                    value={formData.googleMapsApiKey}
                    onChange={(e) => setFormData({ ...formData, googleMapsApiKey: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    placeholder="AIzaSy..."
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Gemini AI Assistant Key</label>
                  <div className="relative">
                    <input
                      type={showKeys['geminiKey'] ? 'text' : 'password'}
                      value={formData.geminiApiKey}
                      onChange={(e) => setFormData({ ...formData, geminiApiKey: e.target.value })}
                      className="w-full px-3 py-2 pr-10 border border-stone-300 rounded-lg text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                      placeholder="AIzaSy..."
                    />
                    <button
                      type="button"
                      onClick={() => toggleKeyVisibility('geminiKey')}
                      className="absolute right-2.5 top-2.5 text-stone-400 hover:text-stone-700"
                    >
                      {showKeys['geminiKey'] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="flex justify-end pt-4 border-t border-stone-200">
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow transition-colors"
          >
            <CheckCircle className="w-4 h-4" />
            <span>Save & Apply Gateway Configuration</span>
          </button>
        </div>
      </form>
    </div>
  );
};
