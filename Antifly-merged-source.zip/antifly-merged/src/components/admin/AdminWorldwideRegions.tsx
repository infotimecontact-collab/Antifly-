import React, { useState } from 'react';
import {
  Globe,
  DollarSign,
  Truck,
  Percent,
  CheckCircle,
  Clock,
  ArrowRight,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CountryCode } from '../../types';

export const AdminWorldwideRegions: React.FC = () => {
  const { allRegions, selectedCountry, setSelectedCountry, showToast, formatPrice } = useApp();
  const [regionsList, setRegionsList] = useState(Object.values(allRegions));

  const handleActiveToggle = (code: CountryCode) => {
    setSelectedCountry(code);
    showToast(`Switched active administrative region to ${code}`);
  };

  return (
    <div className="space-y-6" id="admin-worldwide-regions-manager">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center text-amber-800">
            <Globe className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-stone-900">Worldwide Localization & Multi-Country Engine</h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300">
                8 Global Hubs Active
              </span>
            </div>
            <p className="text-xs text-stone-500">
              Configure currencies, regional couriers, tax regimes (GST, VAT, Sales Tax), and exchange rates for seamless global sales.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-stone-500 font-medium">Active Store Region:</span>
          <span className="font-bold text-stone-900 px-3 py-1.5 bg-stone-100 border border-stone-300 rounded-lg">
            {allRegions[selectedCountry]?.name} ({allRegions[selectedCountry]?.currency})
          </span>
        </div>
      </div>

      {/* Grid of Regions */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {regionsList.map((region) => {
          const isSelected = selectedCountry === region.countryCode;
          return (
            <div
              key={region.countryCode}
              className={`p-5 rounded-2xl border transition-all shadow-sm flex flex-col justify-between space-y-4 ${
                isSelected
                  ? 'bg-amber-50/60 border-amber-400 ring-2 ring-amber-400/20'
                  : 'bg-white border-stone-200 hover:border-stone-300'
              }`}
            >
              <div className="space-y-3">
                {/* Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="text-3xl leading-none">{region.flag}</span>
                    <div>
                      <h3 className="text-sm font-bold text-stone-900">{region.name}</h3>
                      <p className="text-[11px] text-stone-500 font-mono">
                        {region.countryCode} • {region.currency} ({region.symbol})
                      </p>
                    </div>
                  </div>
                  {isSelected && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-200 text-amber-900">
                      ACTIVE
                    </span>
                  )}
                </div>

                {/* Details Breakdown */}
                <div className="space-y-2 text-xs pt-2 border-t border-stone-200/80">
                  <div className="flex justify-between text-stone-600">
                    <span className="flex items-center gap-1">
                      <Percent className="w-3.5 h-3.5 text-stone-400" />
                      Tax Regime:
                    </span>
                    <span className="font-bold text-stone-800">
                      {region.taxName} ({(region.taxRate * 100).toFixed(0)}%)
                    </span>
                  </div>

                  <div className="flex justify-between text-stone-600">
                    <span className="flex items-center gap-1">
                      <Truck className="w-3.5 h-3.5 text-stone-400" />
                      Courier Partner:
                    </span>
                    <span className="font-semibold text-stone-800 truncate max-w-[120px]">
                      {region.defaultCourier}
                    </span>
                  </div>

                  <div className="flex justify-between text-stone-600">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-stone-400" />
                      Refund SLA:
                    </span>
                    <span className="font-bold text-emerald-700">5 Working Days</span>
                  </div>

                  <div className="flex justify-between text-stone-600">
                    <span className="flex items-center gap-1">
                      <DollarSign className="w-3.5 h-3.5 text-stone-400" />
                      Conversion Index:
                    </span>
                    <span className="font-mono text-stone-700">1 INR = {region.rateFromINR} {region.currency}</span>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <button
                type="button"
                onClick={() => handleActiveToggle(region.countryCode)}
                className={`w-full py-2 px-3 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 ${
                  isSelected
                    ? 'bg-amber-600 text-white shadow-sm'
                    : 'bg-stone-100 hover:bg-stone-200 text-stone-800'
                }`}
              >
                {isSelected ? (
                  <>
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>Currently Managing</span>
                  </>
                ) : (
                  <>
                    <span>Switch Context to {region.name}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
