import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CMSPage, HomepageSection } from '../../types';
import {
  Layers,
  FileText,
  Save,
  Eye,
  CheckCircle,
  ArrowUp,
  ArrowDown,
  ToggleLeft,
  ToggleRight,
  Sparkles,
  Edit3,
  Globe,
  Sliders,
} from 'lucide-react';

export const AdminCMS: React.FC = () => {
  const {
    cmsPages,
    homepageSections,
    updateCMSPage,
    updateHomepageSections,
    setActiveCMSPage,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'pages' | 'homepage-builder'>('pages');
  const [selectedPage, setSelectedPage] = useState<CMSPage>(cmsPages?.[0] || {
    slug: 'about-us',
    title: 'About Antifly',
    metaDescription: 'Antifly brand story',
    content: 'Antifly crafts exceptional sustainable fashion...',
    lastUpdated: '2026-08-15',
    version: '1.2',
  });
  const [pageTitle, setPageTitle] = useState(selectedPage.title);
  const [pageContent, setPageContent] = useState(selectedPage.content);
  const [isSaving, setIsSaving] = useState(false);

  // Sections builder local state
  const [sections, setSections] = useState<HomepageSection[]>(homepageSections);

  const handleSelectPage = (page: CMSPage) => {
    setSelectedPage(page);
    setPageTitle(page.title);
    setPageContent(page.content);
  };

  const handleSavePage = async () => {
    setIsSaving(true);
    await updateCMSPage(selectedPage.slug, pageContent, pageTitle);
    setIsSaving(false);
  };

  const handleToggleSection = (id: string) => {
    const updated = sections.map((s) => (s.id === id ? { ...s, isVisible: !s.isVisible } : s));
    setSections(updated);
  };

  const handleMoveSection = (index: number, direction: 'up' | 'down') => {
    const newSections = [...sections];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newSections.length) return;

    const temp = newSections[index];
    newSections[index] = newSections[targetIndex];
    newSections[targetIndex] = temp;

    // re-assign order numbers
    newSections.forEach((s, idx) => {
      s.order = idx + 1;
    });

    setSections(newSections);
  };

  const handleSaveHomepageLayout = async () => {
    await updateHomepageSections(sections);
  };

  return (
    <div id="admin-cms-view" className="space-y-6">
      {/* Header & Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Layers className="w-5 h-5 text-amber-400" />
            CMS & Homepage Layout Builder
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Maintain legal policies, brand editorial pages, and dynamically orchestrate the storefront homepage modules.
          </p>
        </div>

        <div className="flex gap-1.5 bg-white p-1.5 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('pages')}
            className={`px-4 py-2 rounded-lg font-bold transition flex items-center gap-2 ${
              activeTab === 'pages'
                ? 'bg-amber-500 text-slate-800 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4" />
            Content & Policy Pages
          </button>
          <button
            onClick={() => setActiveTab('homepage-builder')}
            className={`px-4 py-2 rounded-lg font-bold transition flex items-center gap-2 ${
              activeTab === 'homepage-builder'
                ? 'bg-amber-500 text-slate-800 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sliders className="w-4 h-4" />
            Homepage Section Builder
          </button>
        </div>
      </div>

      {activeTab === 'pages' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Sidebar: Pages List */}
          <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider px-2 py-1 mb-2">
              Published CMS Pages ({cmsPages.length})
            </div>
            {cmsPages.map((page) => (
              <button
                key={page.slug}
                onClick={() => handleSelectPage(page)}
                className={`w-full text-left p-3 rounded-xl transition flex items-center justify-between group ${
                  selectedPage.slug === page.slug
                    ? 'bg-amber-500/20 border border-amber-500/40 text-amber-300'
                    : 'bg-white/60 border border-slate-800 text-slate-300 hover:bg-slate-800/60 hover:text-white'
                }`}
              >
                <div>
                  <div className="text-xs font-bold">{page.title}</div>
                  <div className="text-[10px] text-slate-500 font-mono mt-0.5">/{page.slug}</div>
                </div>
                <span className="text-[10px] font-mono text-slate-500">v{page.version}</span>
              </button>
            ))}
          </div>

          {/* Right Editor: Content Editing */}
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <span className="text-[10px] uppercase font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                  Editing: /{selectedPage.slug}
                </span>
                <h3 className="text-base font-bold text-white mt-1.5">{pageTitle}</h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveCMSPage(selectedPage)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5" />
                  Preview Modal
                </button>
                <button
                  onClick={handleSavePage}
                  disabled={isSaving}
                  className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-800 text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-md"
                >
                  <Save className="w-3.5 h-3.5" />
                  {isSaving ? 'Saving...' : 'Save & Publish'}
                </button>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Page Title</label>
                <input
                  type="text"
                  value={pageTitle}
                  onChange={(e) => setPageTitle(e.target.value)}
                  className="w-full bg-white border border-slate-800 rounded-xl px-3.5 py-2 text-white font-medium focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">SEO Meta Description</label>
                <input
                  type="text"
                  value={selectedPage.metaDescription}
                  readOnly
                  className="w-full bg-white/60 border border-slate-800/80 rounded-xl px-3.5 py-2 text-slate-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">
                  Page Content & Legal Terms (HTML / Markdown Formatted)
                </label>
                <textarea
                  rows={14}
                  value={pageContent}
                  onChange={(e) => setPageContent(e.target.value)}
                  className="w-full bg-white border border-slate-800 rounded-xl p-4 text-slate-200 font-sans text-xs leading-relaxed focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-800">
                <span>Last updated: {selectedPage.lastUpdated}</span>
                <span>Security verified & compliant with consumer protection norms</span>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Homepage Builder */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <Sliders className="w-4 h-4 text-amber-400" />
                Storefront Layout Orchestrator
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Drag or re-order sections, toggle visibility, and control the flow of the customer website and mobile home feeds.
              </p>
            </div>

            <button
              onClick={handleSaveHomepageLayout}
              className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-800 text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-md"
            >
              <Save className="w-3.5 h-3.5" />
              Publish Live Layout
            </button>
          </div>

          <div className="space-y-3">
            {sections.map((section, idx) => (
              <div
                key={section.id}
                className={`p-4 rounded-xl border flex items-center justify-between transition ${
                  section.isVisible
                    ? 'bg-white border-slate-800'
                    : 'bg-white/40 border-slate-800/50 opacity-60'
                }`}
              >
                <div className="flex items-center gap-4">
                  <span className="w-7 h-7 rounded-lg bg-slate-800 text-slate-300 font-mono font-bold text-xs flex items-center justify-center">
                    #{section.order}
                  </span>
                  <div>
                    <div className="text-xs font-bold text-white flex items-center gap-2">
                      {section.title}
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-amber-400 border border-slate-700">
                        {section.type}
                      </span>
                    </div>
                    {section.subtitle && (
                      <div className="text-[11px] text-slate-400 mt-0.5">{section.subtitle}</div>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  {/* Toggle Visibility */}
                  <button
                    onClick={() => handleToggleSection(section.id)}
                    className={`text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
                      section.isVisible
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'bg-slate-800 text-slate-500 border border-slate-700'
                    }`}
                  >
                    {section.isVisible ? (
                      <>
                        <CheckCircle className="w-3.5 h-3.5" /> Visible
                      </>
                    ) : (
                      'Hidden'
                    )}
                  </button>

                  {/* Move Up / Down */}
                  <div className="flex items-center bg-slate-800 border border-slate-700 rounded-lg p-0.5">
                    <button
                      disabled={idx === 0}
                      onClick={() => handleMoveSection(idx, 'up')}
                      className="p-1.5 hover:text-white text-slate-400 disabled:opacity-30 rounded"
                      title="Move section up"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      disabled={idx === sections.length - 1}
                      onClick={() => handleMoveSection(idx, 'down')}
                      className="p-1.5 hover:text-white text-slate-400 disabled:opacity-30 rounded"
                      title="Move section down"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
