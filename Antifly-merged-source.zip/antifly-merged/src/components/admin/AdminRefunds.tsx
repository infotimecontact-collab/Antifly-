import React, { useState } from 'react';
import {
  RotateCcw,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Search,
  Building2,
  ArrowRight,
  Sparkles,
  ExternalLink,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { RefundRecord } from '../../types';

export const AdminRefunds: React.FC = () => {
  const { refunds, advanceRefundStep, formatPrice, showToast } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRefund, setSelectedRefund] = useState<RefundRecord | null>(refunds?.[0] || null);

  const filteredRefunds = refunds.filter(
    (r) =>
      r.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.bankReferenceNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalRefundedVolume = refunds.reduce((acc, r) => acc + r.amount, 0);
  const activeSLACount = refunds.filter((r) => r.status !== 'Credited').length;

  return (
    <div className="space-y-6" id="admin-refunds-pipeline-manager">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center text-amber-800">
            <RotateCcw className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-stone-900">5-Day SLA Automated Refund Management</h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300">
                5 Working Days Guaranteed
              </span>
            </div>
            <p className="text-xs text-stone-500">
              Systematic banking pipeline ensuring seamless, uncollapsible reversals directly into customer source accounts.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-3.5 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs">
            <span className="text-stone-500">Active SLA Pipelines: </span>
            <span className="font-bold text-stone-900">{activeSLACount} Orders</span>
          </div>
          <div className="px-3.5 py-1.5 bg-amber-50 border border-amber-200 rounded-xl text-xs">
            <span className="text-amber-700">Total Managed Reversals: </span>
            <span className="font-bold text-amber-900">{formatPrice(totalRefundedVolume)}</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Left List / Right 5-Day SLA Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Refunds List */}
        <div className="lg:col-span-5 space-y-4">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by Order #, Customer, or ARN..."
              className="w-full pl-9 pr-4 py-2.5 bg-white border border-stone-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-500 shadow-sm"
            />
          </div>

          {/* Refund Cards */}
          <div className="space-y-3">
            {filteredRefunds.map((refund) => {
              const isSelected = selectedRefund?.id === refund.id;
              return (
                <button
                  key={refund.id}
                  type="button"
                  onClick={() => setSelectedRefund(refund)}
                  className={`w-full text-left p-4 rounded-xl border transition-all shadow-sm ${
                    isSelected
                      ? 'bg-amber-50/70 border-amber-400 ring-2 ring-amber-400/20'
                      : 'bg-white border-stone-200 hover:border-stone-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold text-stone-900">Order #{refund.orderNumber}</span>
                    <span className="text-xs font-extrabold text-amber-800">{formatPrice(refund.amount)}</span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-stone-500 mb-2">
                    <span>{refund.customerName}</span>
                    <span className="font-mono text-[10px] text-stone-400">{refund.bankReferenceNumber}</span>
                  </div>

                  {/* 5-Day SLA Progress Mini Bar */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[10px] font-semibold">
                      <span className="text-stone-700">
                        {refund.status === 'Credited'
                          ? 'Completed (Day 5/5)'
                          : `SLA Day ${refund.currentDay} of 5`}
                      </span>
                      <span
                        className={`px-1.5 py-0.2 rounded font-bold ${
                          refund.status === 'Credited'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {refund.status.replace('_', ' ')}
                      </span>
                    </div>

                    <div className="w-full bg-stone-100 h-1.5 rounded-full overflow-hidden flex gap-0.5">
                      {[1, 2, 3, 4, 5].map((d) => (
                        <div
                          key={d}
                          className={`flex-1 h-full rounded-full transition-all ${
                            d <= refund.currentDay
                              ? refund.status === 'Credited'
                                ? 'bg-emerald-500'
                                : 'bg-amber-500'
                              : 'bg-stone-200'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: 5-Day SLA Timeline Inspector */}
        <div className="lg:col-span-7">
          {selectedRefund ? (
            <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-sm space-y-6">
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-200 pb-5">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-stone-900">
                      Reversal for Order #{selectedRefund.orderNumber}
                    </h3>
                    <span
                      className={`text-xs px-2.5 py-0.5 rounded-full font-bold ${
                        selectedRefund.status === 'Credited'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {selectedRefund.status.replace('_', ' ')}
                    </span>
                  </div>
                  <p className="text-xs text-stone-500 mt-0.5">
                    Customer: <span className="font-semibold text-stone-800">{selectedRefund.customerName}</span> ({selectedRefund.customerEmail})
                  </p>
                </div>

                <div className="text-right">
                  <p className="text-xs text-stone-400 font-medium">Refund Amount</p>
                  <p className="text-xl font-black text-amber-800">{formatPrice(selectedRefund.amount)}</p>
                </div>
              </div>

              {/* Bank Reference & SLA SLA SLA details */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-stone-50 p-4 rounded-xl border border-stone-200 text-xs">
                <div>
                  <p className="text-[11px] text-stone-400 font-medium">Payment Route</p>
                  <p className="font-bold text-stone-800 mt-0.5">{selectedRefund.paymentMethod}</p>
                </div>
                <div>
                  <p className="text-[11px] text-stone-400 font-medium">Bank ARN Number</p>
                  <p className="font-mono text-[11px] font-bold text-stone-800 mt-0.5">{selectedRefund.bankReferenceNumber}</p>
                </div>
                <div>
                  <p className="text-[11px] text-stone-400 font-medium">Initiated On</p>
                  <p className="font-semibold text-stone-800 mt-0.5">{selectedRefund.initiatedAt}</p>
                </div>
                <div>
                  <p className="text-[11px] text-stone-400 font-medium">Expected Credit Date</p>
                  <p className="font-bold text-emerald-700 mt-0.5">{selectedRefund.expectedCreditDate}</p>
                </div>
              </div>

              {/* 5-Day SLA Pipeline Visualization */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-800 flex items-center gap-1.5">
                    <Clock className="w-4 h-4" />
                    <span>5-Working-Day Banking Reversal Log</span>
                  </h4>
                  {selectedRefund.status !== 'Credited' && (
                    <button
                      type="button"
                      id="advance-sla-day-btn"
                      onClick={() => advanceRefundStep(selectedRefund.id)}
                      className="flex items-center gap-1 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-lg shadow-sm transition-colors"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Simulate Next Bank Day</span>
                    </button>
                  )}
                </div>

                <div className="space-y-3 relative before:absolute before:left-4 before:top-2 before:bottom-2 before:w-0.5 before:bg-stone-200">
                  {selectedRefund.dayLog.map((log) => {
                    const isPassed = log.day <= selectedRefund.currentDay;
                    const isCurrent = log.day === selectedRefund.currentDay && selectedRefund.status !== 'Credited';
                    return (
                      <div key={log.day} className="relative flex items-start gap-4 pl-1">
                        <div
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold z-10 shrink-0 ${
                            log.isComplete || log.day < selectedRefund.currentDay
                              ? 'bg-amber-600 text-white'
                              : isCurrent
                              ? 'bg-emerald-600 text-white ring-4 ring-emerald-100 animate-pulse'
                              : 'bg-stone-100 text-stone-400 border border-stone-300'
                          }`}
                        >
                          {log.isComplete || log.day < selectedRefund.currentDay ? (
                            <CheckCircle2 className="w-4 h-4" />
                          ) : (
                            log.day
                          )}
                        </div>

                        <div className="flex-1 bg-stone-50 border border-stone-200 rounded-xl p-3">
                          <div className="flex items-center justify-between">
                            <p className="text-xs font-bold text-stone-900">{log.title}</p>
                            <span className="text-[11px] font-mono text-stone-500">{log.date}</span>
                          </div>
                          <p className="text-[11px] text-stone-600 mt-1">{log.desc}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Cancellation Reason note */}
              <div className="p-4 bg-stone-50 border border-stone-200 rounded-xl text-xs">
                <p className="font-bold text-stone-700">Cancellation Reason from Customer:</p>
                <p className="text-stone-600 mt-0.5 italic">"{selectedRefund.refundReason}"</p>
              </div>
            </div>
          ) : (
            <div className="bg-white border border-stone-200 rounded-2xl p-12 text-center text-stone-400">
              <p>Select a refund record to inspect the 5-Day banking SLA pipeline.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
