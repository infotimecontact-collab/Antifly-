import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { RotateCcw, CheckCircle, XCircle, Clock, Search, AlertCircle } from 'lucide-react';

export const AdminReturns: React.FC = () => {
  const { returns, handleReturnAction, showToast } = useApp();
  const [filter, setFilter] = useState('All');

  const filteredReturns = returns.filter((r) => {
    if (filter !== 'All' && r.status !== filter) return false;
    return true;
  });

  const onAction = async (id: string, action: 'Approve' | 'Reject') => {
    await handleReturnAction(id, action);
    showToast(`Return request ${action === 'Approve' ? 'Approved' : 'Rejected'}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white">
            Returns & Exchange Management
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Process doorstep pickups, exchange dispatch, and instant refunds
          </p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 text-xs">
        {['All', 'Pending', 'Approved', 'Rejected', 'Completed'].map((tab) => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
              filter === tab
                ? 'bg-amber-500 text-slate-800 shadow-md'
                : 'text-slate-400 hover:bg-slate-800'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Returns List */}
      <div className="space-y-3">
        {filteredReturns.length === 0 ? (
          <div className="p-12 text-center bg-slate-900 rounded-2xl border border-slate-800 text-slate-400">
            <RotateCcw className="w-10 h-10 mx-auto stroke-1 text-slate-600 mb-2" />
            <h3 className="font-bold text-sm text-white">No return requests found</h3>
            <p className="text-xs text-slate-500">All customer returns are currently processed.</p>
          </div>
        ) : (
          filteredReturns.map((item) => (
            <div
              key={item.id}
              className="p-5 bg-slate-900 rounded-2xl border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-white text-sm">
                    #{item.orderNumber}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold text-[10px] uppercase">
                    {item.type}
                  </span>
                  <span className="text-slate-400">
                    Requested on {new Date(item.createdAt).toLocaleDateString('en-IN')}
                  </span>
                </div>
                <p className="text-slate-300">
                  Customer: <strong>{item.customerName}</strong> ({item.customerEmail})
                </p>
                <p className="text-slate-400">
                  Reason: <strong>{item.reason}</strong> &bull; Subscribed for: {item.preferredAction}
                </p>
                {item.comments && (
                  <p className="text-[11px] text-slate-500 italic">"{item.comments}"</p>
                )}
              </div>

              {/* Status & Actions */}
              <div className="flex items-center gap-3">
                <span
                  className={`px-3 py-1 rounded-full text-xs font-bold ${
                    item.status === 'Approved'
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : item.status === 'Rejected'
                      ? 'bg-rose-500/20 text-rose-300'
                      : 'bg-amber-500/20 text-amber-300'
                  }`}
                >
                  ● {item.status}
                </span>

                {item.status === 'Pending' && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onAction(item.id, 'Approve')}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1 shadow"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Approve</span>
                    </button>
                    <button
                      onClick={() => onAction(item.id, 'Reject')}
                      className="bg-rose-600/80 hover:bg-rose-600 text-white font-bold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1 shadow"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Reject</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
