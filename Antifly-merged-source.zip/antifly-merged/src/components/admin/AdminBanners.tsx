import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Banner } from '../../types';
import {
  Image as ImageIcon,
  Plus,
  Trash2,
  Edit2,
  CheckCircle,
  XCircle,
  Clock,
  ArrowUp,
  ArrowDown,
  Smartphone,
  Monitor,
  Flame,
  Sparkles,
  RefreshCw,
  Eye,
  Check,
} from 'lucide-react';

const CURATED_REAL_BANNER_PRESETS = [
  {
    name: 'Modern Indian Luxury Apparel',
    category: 'Fashion',
    desktop: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=1920&auto=format&fit=crop&q=85',
    mobile: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=900&auto=format&fit=crop&q=85',
    defaultTag: '⚡ LIVE NOW',
    defaultBadge: 'Festive Drop • Up to 50% Off',
  },
  {
    name: 'Pro Acoustic Studio Audio & Wearables',
    category: 'Electronics',
    desktop: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=1920&auto=format&fit=crop&q=85',
    mobile: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=900&auto=format&fit=crop&q=85',
    defaultTag: '🔥 SELLING FAST',
    defaultBadge: 'Flat 45% Off • Limited Stock',
  },
  {
    name: 'Minimalist Chronograph Watches & Accessories',
    category: 'Accessories',
    desktop: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=1920&auto=format&fit=crop&q=85',
    mobile: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=900&auto=format&fit=crop&q=85',
    defaultTag: '✨ LUXURY LAUNCH',
    defaultBadge: 'Collector Edition • 2-Yr Warranty',
  },
  {
    name: 'Botanical Skincare & 24K Saffron Elixirs',
    category: 'Beauty',
    desktop: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=1920&auto=format&fit=crop&q=85',
    mobile: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=900&auto=format&fit=crop&q=85',
    defaultTag: '🌿 100% ORGANIC',
    defaultBadge: 'Buy 1 Get 1 Mini Free',
  },
  {
    name: 'Midnight Flash Lightning Sale Drop',
    category: 'Flash Sale',
    desktop: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1920&auto=format&fit=crop&q=85',
    mobile: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=900&auto=format&fit=crop&q=85',
    defaultTag: '⏳ ENDS SOON',
    defaultBadge: 'Lightning Deal • 48% Off',
  },
  {
    name: 'Handcrafted Heritage Leather Footwear & Mojaris',
    category: 'Footwear',
    desktop: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=1920&auto=format&fit=crop&q=85',
    mobile: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=900&auto=format&fit=crop&q=85',
    defaultTag: '👞 HERITAGE CRAFT',
    defaultBadge: 'Handcrafted Perfection',
  },
];

export const AdminBanners: React.FC = () => {
  const { banners, saveBanner, deleteBanner, showToast } = useApp();
  const [selectedType, setSelectedType] = useState<string>('all');
  const [editingBanner, setEditingBanner] = useState<Partial<Banner> | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'mobile'>('desktop');

  const filteredBanners = banners.filter((b) => {
    if (selectedType === 'all') return true;
    return b.type.toLowerCase() === selectedType.toLowerCase();
  });

  const handleToggleActive = async (banner: Banner) => {
    await saveBanner({ ...banner, isActive: !banner.isActive });
    showToast(`Banner ${banner.isActive ? 'paused' : 'activated'}`, 'info');
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBanner?.title) return;
    await saveBanner(editingBanner);
    setIsModalOpen(false);
    setEditingBanner(null);
    showToast('Banner creative saved successfully!', 'success');
  };

  const handleMovePriority = async (banner: Banner, direction: 'up' | 'down') => {
    const newPriority = direction === 'up' ? banner.priority - 1 : banner.priority + 1;
    await saveBanner({ ...banner, priority: Math.max(1, newPriority) });
  };

  const handleApplyPreset = (preset: typeof CURATED_REAL_BANNER_PRESETS[0]) => {
    if (!editingBanner) return;
    setEditingBanner({
      ...editingBanner,
      desktopImage: preset.desktop,
      mobileImage: preset.mobile,
      liveTag: preset.defaultTag,
      discountBadge: preset.defaultBadge,
      title: editingBanner.title || preset.name,
    });
    showToast(`Applied preset: ${preset.name}`, 'info');
  };

  return (
    <div id="admin-banners-view" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <ImageIcon className="w-5 h-5 text-amber-400" />
            Hero Banners & Real-Time Timing Creatives
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage high-resolution real photography hero banners, live countdown clocks, and automated carousel timing.
          </p>
        </div>
        <button
          id="btn-add-hero-banner"
          onClick={() => {
            setEditingBanner({
              title: '',
              subtitle: '',
              type: 'Hero',
              desktopImage: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=1920&auto=format&fit=crop&q=85',
              mobileImage: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=900&auto=format&fit=crop&q=85',
              ctaText: 'Explore Collection',
              destinationUrl: '/catalog',
              discountBadge: 'Festive Edition • Flat 40% Off',
              priority: banners.length + 1,
              isActive: true,
              timingSeconds: 14400,
              liveTag: '⚡ LIVE NOW',
            });
            setIsModalOpen(true);
          }}
          className="bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-2 transition shadow-lg shadow-amber-500/10"
        >
          <Plus className="w-4 h-4" />
          Add Real Timing Banner
        </button>
      </div>

      {/* Banner Type Tabs */}
      <div className="flex gap-2 bg-slate-900 p-1.5 rounded-xl border border-slate-800 text-xs w-full sm:w-auto overflow-x-auto">
        {['all', 'hero', 'promotional', 'category', 'offer', 'app'].map((type) => (
          <button
            key={type}
            onClick={() => setSelectedType(type)}
            className={`px-3.5 py-1.5 rounded-lg capitalize font-medium transition ${
              selectedType === type
                ? 'bg-amber-500 text-slate-800 font-bold'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            {type === 'all' ? 'All Creatives' : `${type} Banners`}
          </button>
        ))}
      </div>

      {/* Grid of Banners */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredBanners.map((banner) => (
          <div
            key={banner.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl flex flex-col group hover:border-slate-700 transition"
          >
            {/* Banner Preview Image */}
            <div className="relative aspect-[16/8] bg-white overflow-hidden">
              <img
                src={banner.desktopImage}
                alt={banner.title}
                className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent p-4 flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-full bg-slate-900/80 backdrop-blur-md text-amber-300 border border-amber-500/30 text-[10px] font-bold uppercase tracking-wider">
                      {banner.type} • Priority #{banner.priority}
                    </span>
                    {banner.liveTag && (
                      <span className="px-2 py-0.5 bg-rose-600/90 text-white font-black text-[10px] rounded-md shadow-md animate-pulse">
                        {banner.liveTag}
                      </span>
                    )}
                  </div>
                  {banner.discountBadge && (
                    <span className="px-2 py-0.5 bg-amber-500 text-slate-800 font-black text-[10px] rounded-md shadow-md">
                      {banner.discountBadge}
                    </span>
                  )}
                </div>

                <div>
                  <h3 className="text-base font-black text-white leading-tight drop-shadow-md">
                    {banner.title}
                  </h3>
                  <p className="text-xs text-slate-200 mt-0.5 drop-shadow line-clamp-1">
                    {banner.subtitle}
                  </p>
                </div>
              </div>
            </div>

            {/* Banner Meta & Actions */}
            <div className="p-4 flex-1 flex flex-col justify-between gap-4">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <span className="flex items-center gap-1 text-slate-300">
                    <Monitor className="w-3.5 h-3.5 text-blue-400" /> Real HD 1920x1080
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1 text-amber-400 font-mono font-semibold">
                    <Clock className="w-3.5 h-3.5" /> {Math.round((banner.timingSeconds || 14400) / 3600)}h Timing
                  </span>
                </div>
                <div className="text-[11px] font-mono text-slate-400">
                  Target: {banner.destinationUrl}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleToggleActive(banner)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold inline-flex items-center gap-1 transition ${
                      banner.isActive
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {banner.isActive ? <CheckCircle className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                    {banner.isActive ? 'Active Live' : 'Paused'}
                  </button>

                  {/* Priority adjustments */}
                  <div className="flex items-center bg-slate-800 border border-slate-700 rounded-lg p-0.5">
                    <button
                      onClick={() => handleMovePriority(banner, 'up')}
                      className="p-1 hover:text-white text-slate-400 rounded"
                      title="Move Up"
                    >
                      <ArrowUp className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => handleMovePriority(banner, 'down')}
                      className="p-1 hover:text-white text-slate-400 rounded"
                      title="Move Down"
                    >
                      <ArrowDown className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      setEditingBanner(banner);
                      setIsModalOpen(true);
                    }}
                    className="p-2 hover:bg-slate-800 text-slate-300 hover:text-white rounded-lg transition"
                    title="Edit Banner"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => deleteBanner(banner.id)}
                    className="p-2 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 rounded-lg transition"
                    title="Delete Banner"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Banner Modal with Curated Presets & Real Timing Controls */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-100/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl">
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-white">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-amber-400" />
                {editingBanner?.id ? 'Edit Banner Creative & Timing' : 'Add New Real Timing Banner'}
              </h3>
              <button
                onClick={() => {
                  setIsModalOpen(false);
                  setEditingBanner(null);
                }}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4 text-xs max-h-[82vh] overflow-y-auto">
              {/* Preset Gallery Quick-Picker */}
              <div className="bg-white p-3.5 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-300 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    Quick Pick Real Photography Preset (Unsplash HD)
                  </span>
                  <span className="text-[10px] text-slate-500">1-click populate</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {CURATED_REAL_BANNER_PRESETS.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleApplyPreset(preset)}
                      className="group p-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/50 rounded-xl text-left transition flex items-center gap-2"
                    >
                      <img
                        src={preset.desktop}
                        alt={preset.name}
                        className="w-10 h-10 rounded-lg object-cover flex-shrink-0"
                      />
                      <div className="min-w-0">
                        <p className="font-bold text-white text-[11px] truncate group-hover:text-amber-400">
                          {preset.category}
                        </p>
                        <p className="text-[10px] text-slate-400 truncate">{preset.defaultTag}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Title & Placement */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Banner Title *</label>
                  <input
                    type="text"
                    required
                    value={editingBanner?.title || ''}
                    onChange={(e) => setEditingBanner({ ...editingBanner, title: e.target.value })}
                    placeholder="e.g. The Modern Indian Aesthetic"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-medium focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Banner Placement</label>
                  <select
                    value={editingBanner?.type || 'Hero'}
                    onChange={(e) =>
                      setEditingBanner({ ...editingBanner, type: e.target.value as Banner['type'] })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="Hero">Hero Carousel (Top)</option>
                    <option value="Promotional">Promotional Grid</option>
                    <option value="Category">Category Spotlight</option>
                    <option value="Offer">Deal Ribbon / Flash</option>
                    <option value="App">Mobile App Exclusive</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Subtitle / Marketing Tagline</label>
                <input
                  type="text"
                  value={editingBanner?.subtitle || ''}
                  onChange={(e) => setEditingBanner({ ...editingBanner, subtitle: e.target.value })}
                  placeholder="e.g. Conscious handloom fabrics, tailored festive silhouettes & timeless essentials."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Image URLs */}
              <div className="space-y-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Desktop Real Image URL (1920x1080) *</label>
                  <input
                    type="url"
                    required
                    value={editingBanner?.desktopImage || ''}
                    onChange={(e) => setEditingBanner({ ...editingBanner, desktopImage: e.target.value })}
                    placeholder="https://images.unsplash.com/..."
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Mobile Optimized Image URL (900x900)</label>
                  <input
                    type="url"
                    value={editingBanner?.mobileImage || ''}
                    onChange={(e) => setEditingBanner({ ...editingBanner, mobileImage: e.target.value })}
                    placeholder="https://images.unsplash.com/..."
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Real-time Timing, Tag & Badge */}
              <div className="grid grid-cols-3 gap-3 bg-white/60 p-3 rounded-xl border border-slate-800">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Live Status Tag</label>
                  <input
                    type="text"
                    value={editingBanner?.liveTag || ''}
                    onChange={(e) => setEditingBanner({ ...editingBanner, liveTag: e.target.value })}
                    placeholder="e.g. ⚡ LIVE NOW"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Timing Countdown (Sec)</label>
                  <input
                    type="number"
                    min="60"
                    step="300"
                    value={editingBanner?.timingSeconds || 14400}
                    onChange={(e) =>
                      setEditingBanner({ ...editingBanner, timingSeconds: Number(e.target.value) })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Discount Badge</label>
                  <input
                    type="text"
                    value={editingBanner?.discountBadge || ''}
                    onChange={(e) => setEditingBanner({ ...editingBanner, discountBadge: e.target.value })}
                    placeholder="e.g. Flat 45% Off"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* CTA, Priority, Destination */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Button CTA Text</label>
                  <input
                    type="text"
                    value={editingBanner?.ctaText || ''}
                    onChange={(e) => setEditingBanner({ ...editingBanner, ctaText: e.target.value })}
                    placeholder="e.g. Explore Collection"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Priority Order</label>
                  <input
                    type="number"
                    min="1"
                    value={editingBanner?.priority || 1}
                    onChange={(e) =>
                      setEditingBanner({ ...editingBanner, priority: Number(e.target.value) })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Destination Route</label>
                  <input
                    type="text"
                    value={editingBanner?.destinationUrl || ''}
                    onChange={(e) => setEditingBanner({ ...editingBanner, destinationUrl: e.target.value })}
                    placeholder="/catalog or /category/men"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Real-time Preview */}
              {editingBanner?.desktopImage && (
                <div className="space-y-1.5 pt-2">
                  <div className="flex items-center justify-between text-slate-400 font-semibold">
                    <span className="flex items-center gap-1.5">
                      <Eye className="w-3.5 h-3.5 text-amber-400" />
                      Live Creative Simulation Preview
                    </span>
                    <div className="flex items-center gap-1 bg-slate-800 p-0.5 rounded-lg text-[10px]">
                      <button
                        type="button"
                        onClick={() => setPreviewDevice('desktop')}
                        className={`px-2 py-0.5 rounded ${previewDevice === 'desktop' ? 'bg-amber-500 text-slate-800 font-bold' : 'text-slate-400'}`}
                      >
                        Desktop
                      </button>
                      <button
                        type="button"
                        onClick={() => setPreviewDevice('mobile')}
                        className={`px-2 py-0.5 rounded ${previewDevice === 'mobile' ? 'bg-amber-500 text-slate-800 font-bold' : 'text-slate-400'}`}
                      >
                        Mobile
                      </button>
                    </div>
                  </div>
                  <div
                    className={`relative rounded-xl overflow-hidden bg-white border border-slate-800 ${
                      previewDevice === 'desktop' ? 'aspect-[16/7]' : 'aspect-[9/10] max-w-xs mx-auto'
                    }`}
                  >
                    <img
                      src={previewDevice === 'desktop' ? editingBanner.desktopImage : (editingBanner.mobileImage || editingBanner.desktopImage)}
                      alt="preview"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-slate-950/90 via-slate-950/50 to-transparent p-4 flex flex-col justify-between">
                      <div className="flex items-center gap-2">
                        {editingBanner.liveTag && (
                          <span className="px-2 py-0.5 bg-rose-600 text-white font-black text-[9px] rounded uppercase">
                            {editingBanner.liveTag}
                          </span>
                        )}
                        {editingBanner.discountBadge && (
                          <span className="px-2 py-0.5 bg-amber-500 text-slate-800 font-bold text-[9px] rounded">
                            {editingBanner.discountBadge}
                          </span>
                        )}
                      </div>
                      <div>
                        <h4 className="font-black text-white text-sm leading-tight drop-shadow">
                          {editingBanner.title || 'Banner Title'}
                        </h4>
                        <p className="text-[10px] text-slate-300 line-clamp-1 mt-0.5">
                          {editingBanner.subtitle || 'Marketing subtitle description...'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="pt-4 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setEditingBanner(null);
                  }}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold rounded-xl shadow-md flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  {editingBanner?.id ? 'Update Banner' : 'Publish Banner'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

