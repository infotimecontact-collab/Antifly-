import React, { useState } from 'react';
import {
  ShieldAlert,
  Lock,
  FileText,
  UserX,
  Download,
  Save,
  CheckCircle2,
  AlertTriangle,
  Globe,
  Sliders,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AdminDataPrivacy: React.FC = () => {
  const { dataPrivacy, updateDataPrivacy, showToast } = useApp();
  const [privacyForm, setPrivacyForm] = useState(dataPrivacy);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateDataPrivacy(privacyForm);
    showToast('Global Privacy, GDPR & DPDP policies updated');
  };

  return (
    <div className="space-y-6" id="admin-data-privacy-manager">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center text-amber-800">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-stone-900">Data Privacy & Compliance Governance</h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                GDPR • DPDP • CCPA Active
              </span>
            </div>
            <p className="text-xs text-stone-500">
              Manage international data retention, user consent, Right to be Forgotten requests, and cryptographic compliance ledgers.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleSave}
          className="flex items-center gap-2 px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold rounded-xl shadow transition-colors"
        >
          <Save className="w-4 h-4 text-amber-400" />
          <span>Save Privacy Policies</span>
        </button>
      </div>

      <form onSubmit={handleSave} className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Worldwide Regulatory Frameworks */}
        <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b border-stone-200 pb-3">
            <Globe className="w-5 h-5 text-amber-600" />
            <h2 className="text-sm font-bold text-stone-900">Worldwide Framework Toggles</h2>
          </div>

          <div className="space-y-3 text-xs">
            <label className="flex items-center justify-between p-3.5 bg-stone-50 border border-stone-200 rounded-xl cursor-pointer hover:bg-amber-50/50 transition-colors">
              <div>
                <p className="font-bold text-stone-900">India DPDP Act 2023 Compliance</p>
                <p className="text-[11px] text-stone-500">Consent manager, bilingual notices & localized storage nodes</p>
              </div>
              <input
                type="checkbox"
                checked={privacyForm.dpdpComplianceIndia}
                onChange={(e) => setPrivacyForm({ ...privacyForm, dpdpComplianceIndia: e.target.checked })}
                className="w-4 h-4 text-amber-600 rounded focus:ring-amber-500"
              />
            </label>

            <label className="flex items-center justify-between p-3.5 bg-stone-50 border border-stone-200 rounded-xl cursor-pointer hover:bg-amber-50/50 transition-colors">
              <div>
                <p className="font-bold text-stone-900">European Union GDPR Compliance</p>
                <p className="text-[11px] text-stone-500">Right to erasure, explicit cookie banners & data portability</p>
              </div>
              <input
                type="checkbox"
                checked={privacyForm.gdprComplianceEU}
                onChange={(e) => setPrivacyForm({ ...privacyForm, gdprComplianceEU: e.target.checked })}
                className="w-4 h-4 text-amber-600 rounded focus:ring-amber-500"
              />
            </label>

            <label className="flex items-center justify-between p-3.5 bg-stone-50 border border-stone-200 rounded-xl cursor-pointer hover:bg-amber-50/50 transition-colors">
              <div>
                <p className="font-bold text-stone-900">USA California CCPA / CPRA Governance</p>
                <p className="text-[11px] text-stone-500">"Do Not Sell My Info" disclosure & granular marketing opt-out</p>
              </div>
              <input
                type="checkbox"
                checked={privacyForm.ccpaComplianceUS}
                onChange={(e) => setPrivacyForm({ ...privacyForm, ccpaComplianceUS: e.target.checked })}
                className="w-4 h-4 text-amber-600 rounded focus:ring-amber-500"
              />
            </label>

            <label className="flex items-center justify-between p-3.5 bg-stone-50 border border-stone-200 rounded-xl cursor-pointer hover:bg-amber-50/50 transition-colors">
              <div>
                <p className="font-bold text-stone-900">Cookie Consent Banner on Storefront</p>
                <p className="text-[11px] text-stone-500">Display persistent consent modal for all new website visitors</p>
              </div>
              <input
                type="checkbox"
                checked={privacyForm.cookieBannerEnabled}
                onChange={(e) => setPrivacyForm({ ...privacyForm, cookieBannerEnabled: e.target.checked })}
                className="w-4 h-4 text-amber-600 rounded focus:ring-amber-500"
              />
            </label>
          </div>
        </div>

        {/* Data Protection Officer & Retention Controls */}
        <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b border-stone-200 pb-3">
            <Lock className="w-5 h-5 text-amber-600" />
            <h2 className="text-sm font-bold text-stone-900">Data Governance & Officer Contacts</h2>
          </div>

          <div className="space-y-3.5 text-xs">
            <div>
              <label className="block font-bold text-stone-700 mb-1">Designated Data Protection Officer (DPO) Email</label>
              <input
                type="email"
                value={privacyForm.dpoEmail}
                onChange={(e) => setPrivacyForm({ ...privacyForm, dpoEmail: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-medium focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="dpo@antifly.com"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-1">Audit Log Retention Policy (Days)</label>
              <input
                type="number"
                value={privacyForm.dataRetentionDays}
                onChange={(e) => setPrivacyForm({ ...privacyForm, dataRetentionDays: parseInt(e.target.value) || 365 })}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-medium focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-1">Public Privacy Policy Canonical URL</label>
              <input
                type="text"
                value={privacyForm.privacyPolicyUrl}
                onChange={(e) => setPrivacyForm({ ...privacyForm, privacyPolicyUrl: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-medium focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-1">Terms of Service Canonical URL</label>
              <input
                type="text"
                value={privacyForm.termsUrl}
                onChange={(e) => setPrivacyForm({ ...privacyForm, termsUrl: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-medium focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>
        </div>

        {/* Right to Erasure & Portability Ledger */}
        <div className="md:col-span-2 bg-white border border-stone-200 rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-stone-200 pb-3">
            <div className="flex items-center gap-2">
              <UserX className="w-5 h-5 text-amber-600" />
              <h2 className="text-sm font-bold text-stone-900">Right to Erasure & Data Export Requests</h2>
            </div>
            <span className="text-xs font-mono text-stone-500">2 Requests Pending Verification</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-stone-200 bg-stone-50 text-stone-700 font-bold">
                  <th className="py-2.5 px-3">Request ID</th>
                  <th className="py-2.5 px-3">Customer</th>
                  <th className="py-2.5 px-3">Type</th>
                  <th className="py-2.5 px-3">Regulation</th>
                  <th className="py-2.5 px-3">Submitted</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                <tr className="hover:bg-stone-50">
                  <td className="py-3 px-3 font-mono text-stone-600">DSR-2026-091</td>
                  <td className="py-3 px-3">
                    <p className="font-bold text-stone-900">Pooja Sharma</p>
                    <p className="text-[11px] text-stone-500">pooja.sharma@example.com</p>
                  </td>
                  <td className="py-3 px-3 font-semibold text-amber-800">Export All My Data (JSON/CSV)</td>
                  <td className="py-3 px-3">DPDP Act (India)</td>
                  <td className="py-3 px-3 text-stone-500">Yesterday, 14:20</td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                      Processing
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right">
                    <button
                      type="button"
                      onClick={() => showToast('Generated encrypted data export archive for Pooja Sharma.')}
                      className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded font-semibold transition-colors"
                    >
                      Export Data
                    </button>
                  </td>
                </tr>

                <tr className="hover:bg-stone-50">
                  <td className="py-3 px-3 font-mono text-stone-600">DSR-2026-088</td>
                  <td className="py-3 px-3">
                    <p className="font-bold text-stone-900">Vikram Malhotra</p>
                    <p className="text-[11px] text-stone-500">vikram.m@example.com</p>
                  </td>
                  <td className="py-3 px-3 font-semibold text-rose-700">Account Erasure (Right to be Forgotten)</td>
                  <td className="py-3 px-3">GDPR Article 17</td>
                  <td className="py-3 px-3 text-stone-500">2 Days ago</td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                      Pending Approval
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right">
                    <button
                      type="button"
                      onClick={() => showToast('Customer Vikram Malhotra personal records anonymized and purged.')}
                      className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 rounded font-semibold transition-colors"
                    >
                      Approve Erasure
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </form>
    </div>
  );
};
