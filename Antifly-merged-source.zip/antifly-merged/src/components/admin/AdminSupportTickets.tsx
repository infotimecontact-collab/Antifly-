import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SupportTicket } from '../../types';
import {
  LifeBuoy,
  ShieldAlert,
  Search,
  Filter,
  CheckCircle,
  Clock,
  AlertTriangle,
  Send,
  User,
  Store,
  Truck,
  MessageSquare,
  FileText,
  BadgeAlert,
  Lock,
  RefreshCw,
  Plus,
} from 'lucide-react';

export const AdminSupportTickets: React.FC = () => {
  const {
    supportTickets,
    setSupportTickets,
    showToast,
    orders,
    customers,
    sellers,
    drivers,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'tickets' | 'fraud'>('tickets');
  const [selectedTicketId, setSelectedTicketId] = useState<string>(
    supportTickets?.[0]?.id || ''
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [replyText, setReplyText] = useState('');
  const [internalNoteText, setInternalNoteText] = useState('');

  // Selected Ticket
  const currentTicket = supportTickets.find((t) => t.id === selectedTicketId);

  // Filtered Tickets
  const filteredTickets = supportTickets.filter((t) => {
    const matchesSearch =
      t.ticketNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.creatorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.creatorPhone.includes(searchQuery);

    if (!matchesSearch) return false;
    if (statusFilter !== 'all' && t.status !== statusFilter) return false;
    if (categoryFilter !== 'all' && t.category !== categoryFilter) return false;
    return true;
  });

  // Ticket status update
  const handleUpdateStatus = (status: SupportTicket['status']) => {
    if (!currentTicket) return;
    setSupportTickets((prev) =>
      prev.map((t) =>
        t.id === currentTicket.id
          ? { ...t, status, updatedAt: new Date().toISOString() }
          : t
      )
    );
    showToast(`Ticket ${currentTicket.ticketNumber} marked as ${status}`);
  };

  // Ticket reply message
  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !currentTicket) return;

    const newMessage = {
      id: `msg-${Date.now()}`,
      senderRole: 'support',
      senderName: 'Admin Operations Desk',
      text: replyText.trim(),
      timestamp: new Date().toISOString(),
      isStaff: true,
    };

    setSupportTickets((prev) =>
      prev.map((t) =>
        t.id === currentTicket.id
          ? {
              ...t,
              status: t.status === 'OPEN' ? 'IN_PROGRESS' : t.status,
              updatedAt: new Date().toISOString(),
              messages: [...t.messages, newMessage],
            }
          : t
      )
    );

    setReplyText('');
    showToast('Reply dispatched to ticket thread');
  };

  // Add internal note
  const handleSaveInternalNote = () => {
    if (!internalNoteText.trim() || !currentTicket) return;
    setSupportTickets((prev) =>
      prev.map((t) =>
        t.id === currentTicket.id
          ? {
              ...t,
              internalNotes: t.internalNotes
                ? `${t.internalNotes}\n[${new Date().toLocaleTimeString()}]: ${internalNoteText.trim()}`
                : `[${new Date().toLocaleTimeString()}]: ${internalNoteText.trim()}`,
            }
          : t
      )
    );
    setInternalNoteText('');
    showToast('Internal investigation note saved');
  };

  // Fraud detection telemetry indicators
  const fraudMetrics = [
    {
      title: 'Suspicious Duplicate Devices',
      count: '0 Flagged',
      desc: 'No duplicate hardware fingerprint anomalies detected across current sessions.',
      status: 'safe',
    },
    {
      title: 'OTP Delivery Tamper Check',
      count: '100% Cryptographic Match',
      desc: 'All recent doorstep deliveries authenticated with dynamic 4-digit buyer OTP codes.',
      status: 'safe',
    },
    {
      title: 'Excessive Cancellation Monitor',
      count: '2 Accounts Under Watch',
      desc: 'Users with >3 sequential COD cancellations flagged for pre-dispatch verification.',
      status: 'warning',
    },
    {
      title: 'Merchant Payout Escrow Lock',
      count: '₹0 Disputed Balances',
      desc: 'All merchant wallet disbursements backed by confirmed customer delivery timestamps.',
      status: 'safe',
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in text-slate-900">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 flex items-center gap-2">
            <LifeBuoy className="w-6 h-6 text-blue-500" />
            Support Desk & Dispute Resolution
          </h1>
          <p className="text-xs text-slate-500 mt-0.5 font-medium">
            Manage multi-party customer, seller, and driver tickets, resolve complaints, and monitor fraud telemetry
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('tickets')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              activeTab === 'tickets'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            Active Tickets ({supportTickets.length})
          </button>
          <button
            onClick={() => setActiveTab('fraud')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activeTab === 'fraud'
                ? 'bg-rose-600 text-white shadow-sm'
                : 'bg-white text-rose-700 border border-rose-200 hover:bg-rose-50'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            Fraud Prevention
          </button>
        </div>
      </div>

      {activeTab === 'tickets' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Tickets Master List */}
          <div className="lg:col-span-5 space-y-4">
            {/* Search & Filters */}
            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs space-y-2.5">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by ticket #, subject, or name..."
                  className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-700 font-bold focus:outline-none"
                >
                  <option value="all">All Statuses</option>
                  <option value="OPEN">Open</option>
                  <option value="IN_PROGRESS">In Progress</option>
                  <option value="RESOLVED">Resolved</option>
                  <option value="CLOSED">Closed</option>
                </select>

                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-700 font-bold focus:outline-none"
                >
                  <option value="all">All Categories</option>
                  <option value="Delivery Delay">Delivery Delay</option>
                  <option value="Payment/Payout">Payment/Payout</option>
                  <option value="Order Issue">Order Issue</option>
                  <option value="Product Dispute">Product Dispute</option>
                </select>
              </div>
            </div>

            {/* Tickets Scroll List */}
            <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
              {filteredTickets.map((t) => {
                const isSelected = t.id === selectedTicketId;
                const roleIcon =
                  t.creatorRole === 'customer' ? (
                    <User className="w-3.5 h-3.5 text-blue-500" />
                  ) : t.creatorRole === 'seller' ? (
                    <Store className="w-3.5 h-3.5 text-orange-500" />
                  ) : (
                    <Truck className="w-3.5 h-3.5 text-emerald-500" />
                  );

                return (
                  <div
                    key={t.id}
                    onClick={() => setSelectedTicketId(t.id)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer shadow-xs ${
                      isSelected
                        ? 'bg-blue-50/80 border-blue-500 ring-2 ring-blue-500/20'
                        : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/60'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        <span className="p-1 rounded-lg bg-slate-100">{roleIcon}</span>
                        <span className="text-[11px] font-mono font-bold text-slate-700">
                          {t.ticketNumber}
                        </span>
                      </div>

                      <span
                        className={`text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                          t.status === 'OPEN'
                            ? 'bg-rose-100 text-rose-700'
                            : t.status === 'IN_PROGRESS'
                            ? 'bg-amber-100 text-amber-700'
                            : t.status === 'RESOLVED'
                            ? 'bg-emerald-100 text-emerald-700'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {t.status}
                      </span>
                    </div>

                    <h4 className="text-xs font-bold text-slate-900 mt-2 line-clamp-1">
                      {t.subject}
                    </h4>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2">
                      <span className="font-semibold">{t.creatorName}</span>
                      <span className="text-[10px] text-slate-400">{new Date(t.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Ticket Conversation & Resolution */}
          <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
            {currentTicket ? (
              <>
                {/* Detail Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-black text-blue-600">
                        {currentTicket.ticketNumber}
                      </span>
                      <span className="text-xs font-bold text-slate-400">&bull;</span>
                      <span className="text-xs font-semibold text-slate-600">
                        Category: {currentTicket.category}
                      </span>
                    </div>
                    <h3 className="text-base font-extrabold text-slate-900 mt-1">
                      {currentTicket.subject}
                    </h3>
                  </div>

                  {/* Status Dropdown */}
                  <div className="flex items-center gap-2">
                    <select
                      value={currentTicket.status}
                      onChange={(e) => handleUpdateStatus(e.target.value as any)}
                      className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-800 focus:outline-none focus:border-blue-500"
                    >
                      <option value="OPEN">OPEN</option>
                      <option value="IN_PROGRESS">IN_PROGRESS</option>
                      <option value="WAITING">WAITING</option>
                      <option value="RESOLVED">RESOLVED</option>
                      <option value="CLOSED">CLOSED</option>
                    </select>
                  </div>
                </div>

                {/* Creator Details Bar */}
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div>
                    <span className="text-slate-500">Initiator:</span>{' '}
                    <strong className="text-slate-800 uppercase">{currentTicket.creatorRole}</strong> (
                    {currentTicket.creatorName})
                  </div>
                  <div>
                    <span className="text-slate-500">Phone:</span>{' '}
                    <strong className="text-slate-800 font-mono">{currentTicket.creatorPhone}</strong>
                  </div>
                  {currentTicket.assignedTo && (
                    <div>
                      <span className="text-slate-500">Assigned:</span>{' '}
                      <strong className="text-blue-700 font-semibold">{currentTicket.assignedTo}</strong>
                    </div>
                  )}
                </div>

                {/* Messages Thread */}
                <div className="space-y-3 max-h-[300px] overflow-y-auto p-2">
                  {currentTicket.messages.map((m) => (
                    <div
                      key={m.id}
                      className={`flex flex-col ${
                        m.isStaff ? 'items-end' : 'items-start'
                      }`}
                    >
                      <div
                        className={`max-w-[85%] rounded-2xl p-3 text-xs shadow-xs ${
                          m.isStaff
                            ? 'bg-blue-600 text-white rounded-br-none'
                            : 'bg-slate-100 text-slate-900 border border-slate-200 rounded-bl-none'
                        }`}
                      >
                        <div
                          className={`text-[10px] font-bold mb-1 flex items-center justify-between gap-4 ${
                            m.isStaff ? 'text-blue-100' : 'text-slate-500'
                          }`}
                        >
                          <span>{m.senderName}</span>
                          <span>{new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                        <p className="leading-relaxed">{m.text}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Reply Form */}
                <form onSubmit={handleSendReply} className="flex gap-2 pt-2 border-t border-slate-100">
                  <input
                    type="text"
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    placeholder="Type official response to customer/seller/driver..."
                    className="flex-1 px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-blue-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send</span>
                  </button>
                </form>

                {/* Internal Notes Accordion */}
                <div className="bg-amber-50/60 border border-amber-200 rounded-xl p-3.5 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-900 flex items-center gap-1">
                      <FileText className="w-3.5 h-3.5 text-amber-600" />
                      Staff Internal Investigation Notes (Confidential)
                    </span>
                  </div>

                  {currentTicket.internalNotes ? (
                    <p className="text-[11px] text-amber-800 font-mono bg-white p-2 rounded-lg border border-amber-200 whitespace-pre-line">
                      {currentTicket.internalNotes}
                    </p>
                  ) : (
                    <p className="text-[11px] text-slate-500 italic">No internal notes added yet.</p>
                  )}

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={internalNoteText}
                      onChange={(e) => setInternalNoteText(e.target.value)}
                      placeholder="Add investigation detail (visible to admin staff only)..."
                      className="flex-1 px-3 py-1.5 bg-white border border-amber-300 rounded-lg text-xs"
                    />
                    <button
                      type="button"
                      onClick={handleSaveInternalNote}
                      className="px-3 py-1.5 bg-amber-700 hover:bg-amber-800 text-white rounded-lg text-xs font-bold"
                    >
                      Save Note
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <div className="text-center py-16 text-slate-400">
                <LifeBuoy className="w-12 h-12 mx-auto text-slate-300 mb-2" />
                <p className="text-xs font-medium">Select a ticket from the left panel to inspect</p>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Fraud Telemetry & Prevention Section */
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {fraudMetrics.map((m, idx) => (
              <div
                key={idx}
                className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                    {m.title}
                  </span>
                  {m.status === 'safe' ? (
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-amber-500" />
                  )}
                </div>
                <h3 className="text-base font-extrabold text-slate-900">{m.count}</h3>
                <p className="text-xs text-slate-500">{m.desc}</p>
              </div>
            ))}
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-500" />
              Automated Fraud Detection Rules & Restrictions
            </h3>

            <div className="divide-y divide-slate-100 text-xs">
              <div className="py-3 flex items-center justify-between gap-4">
                <div>
                  <h4 className="font-bold text-slate-900">1 Mobile Number = 1 Active Role Rule</h4>
                  <p className="text-slate-500">Exclusivity registry blocks cross-role collision (Driver / Seller / Customer cannot overlap on same phone).</p>
                </div>
                <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full font-bold text-[10px]">
                  ENFORCED
                </span>
              </div>

              <div className="py-3 flex items-center justify-between gap-4">
                <div>
                  <h4 className="font-bold text-slate-900">Doorstep Handover OTP Security</h4>
                  <p className="text-slate-500">Drivers cannot mark order as DELIVERED without customer 4-digit cryptographic OTP.</p>
                </div>
                <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full font-bold text-[10px]">
                  ENFORCED
                </span>
              </div>

              <div className="py-3 flex items-center justify-between gap-4">
                <div>
                  <h4 className="font-bold text-slate-900">Wholesale MOQ Threshold Enforcement</h4>
                  <p className="text-slate-500">Wholesale lot discounts (e.g. 12-unit toys, 45-unit t-shirts) cannot be bypassed with sub-MOQ orders.</p>
                </div>
                <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full font-bold text-[10px]">
                  ENFORCED
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
