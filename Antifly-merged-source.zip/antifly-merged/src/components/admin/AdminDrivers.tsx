import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { DriverProfile, DriverKycDocuments } from '../../types';
import {
  Truck,
  ShieldCheck,
  CheckCircle,
  XCircle,
  Clock,
  Search,
  Filter,
  MapPin,
  Smartphone,
  Award,
  DollarSign,
  AlertCircle,
  Navigation,
  FileText,
  Eye,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  UserCheck,
  Bike,
  CreditCard,
  Camera,
  ExternalLink,
  Trash2,
  Power,
} from 'lucide-react';

export const AdminDrivers: React.FC = () => {
  const {
    drivers,
    setDrivers,
    driverTasks,
    showToast,
    approveDriverKyc,
    rejectDriverKyc,
    deactivateDriverAccount,
    deleteDriverAccountAndConvertToCustomer,
    accountLifecycleConfig,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'online' | 'offline' | 'verified' | 'pending' | 'rejected'>('all');
  
  // KYC Inspection Modal State
  const [selectedDriverForKyc, setSelectedDriverForKyc] = useState<DriverProfile | null>(null);
  const [rejectionReasonInput, setRejectionReasonInput] = useState('');
  const [isRejecting, setIsRejecting] = useState(false);

  const filteredDrivers = drivers.filter((driver) => {
    const matchesSearch =
      driver.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      driver.phone.includes(searchQuery) ||
      driver.vehicleNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      driver.city.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;
    if (filterStatus === 'online') return driver.isOnline;
    if (filterStatus === 'offline') return !driver.isOnline;
    if (filterStatus === 'verified') return driver.kycStatus === 'APPROVED' || driver.isVerified;
    if (filterStatus === 'pending') return driver.kycStatus === 'PENDING_ADMIN_VERIFICATION' || (!driver.isVerified && driver.kycStatus !== 'REJECTED');
    if (filterStatus === 'rejected') return driver.kycStatus === 'REJECTED';
    return true;
  });

  const handleApprove = async (driverId: string) => {
    await approveDriverKyc(driverId);
    setSelectedDriverForKyc(null);
  };

  const handleReject = async (driverId: string) => {
    if (!rejectionReasonInput.trim()) {
      showToast('Please specify a rejection reason for the driver');
      return;
    }
    await rejectDriverKyc(driverId, rejectionReasonInput);
    setIsRejecting(false);
    setRejectionReasonInput('');
    setSelectedDriverForKyc(null);
  };

  const handleDeactivate = async (driver: DriverProfile) => {
    if (confirm(`Deactivate driver account for "${driver.name}" with a dynamic ${accountLifecycleConfig.driverGraceDays}-day grace period?`)) {
      await deactivateDriverAccount(driver.id, 'Deactivated by Admin Operations');
    }
  };

  const handleConvertToCustomer = async (driver: DriverProfile) => {
    if (confirm(`Convert driver "${driver.name}" (${driver.phone}) into a Normal Customer account? Their driver fleet privileges will be revoked and they can immediately shop as a consumer.`)) {
      await deleteDriverAccountAndConvertToCustomer(driver.id, 'Admin manual role conversion');
    }
  };

  const handleToggleOnline = (driverId: string) => {
    setDrivers((prev) =>
      prev.map((d) => (d.id === driverId ? { ...d, isOnline: !d.isOnline } : d))
    );
    showToast('Driver dispatch availability toggled');
  };

  const pendingCount = drivers.filter(
    (d) => d.kycStatus === 'PENDING_ADMIN_VERIFICATION' || (!d.isVerified && d.kycStatus !== 'REJECTED')
  ).length;

  return (
    <div className="space-y-6 animate-fade-in text-slate-900">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 flex items-center gap-2">
            <Truck className="w-6 h-6 text-emerald-600" />
            Driver & Fleet Partner Verification (24-Hour SLA)
          </h1>
          <p className="text-xs text-slate-500 mt-1 font-medium">
            Verify original Bike documents, Driving License, Aadhaar card & Voter ID. Features enabled within 24h of verification.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {pendingCount > 0 && (
            <span className="px-3 py-1.5 rounded-xl bg-amber-500 text-slate-800 text-xs font-black flex items-center gap-1.5 animate-pulse shadow-xs">
              <Clock className="w-3.5 h-3.5" />
              {pendingCount} PENDING 24H SLA REVIEW
            </span>
          )}
          <span className="px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold font-mono">
            {drivers.filter((d) => d.isOnline).length} / {drivers.length} DRIVERS ONLINE
          </span>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-col md:flex-row items-center justify-between gap-3 shadow-xs">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search drivers by name, phone, vehicle plate, or city..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-emerald-500 font-medium"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as any)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 font-bold focus:outline-none focus:border-emerald-500"
          >
            <option value="all">All Fleet Partners ({drivers.length})</option>
            <option value="pending">Pending KYC Review ({pendingCount})</option>
            <option value="verified">KYC Approved & Active ({drivers.filter((d) => d.kycStatus === 'APPROVED' || d.isVerified).length})</option>
            <option value="rejected">Rejected / Incomplete ({drivers.filter((d) => d.kycStatus === 'REJECTED').length})</option>
            <option value="online">Online & Available ({drivers.filter((d) => d.isOnline).length})</option>
            <option value="offline">Offline</option>
          </select>
        </div>
      </div>

      {/* Drivers List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredDrivers.map((driver) => {
          const activeTask = driverTasks.find(
            (t) => t.assignedDriverId === driver.id && t.status !== 'Delivered'
          );

          const isPending = driver.kycStatus === 'PENDING_ADMIN_VERIFICATION' || (!driver.isVerified && driver.kycStatus !== 'REJECTED');
          const isApproved = driver.kycStatus === 'APPROVED' || driver.isVerified;
          const isRejected = driver.kycStatus === 'REJECTED';

          return (
            <div
              key={driver.id}
              className={`bg-white rounded-3xl border ${
                isPending ? 'border-amber-400 ring-2 ring-amber-300/30' : 'border-slate-200'
              } p-5 space-y-4 hover:shadow-lg transition-all shadow-xs flex flex-col justify-between`}
            >
              <div className="space-y-3">
                {/* Header Profile & KYC Status */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <img
                      src={driver.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                      alt={driver.name}
                      className="w-12 h-12 rounded-2xl object-cover border border-slate-200 bg-slate-100 flex-shrink-0"
                    />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h3 className="font-black text-sm text-slate-900">{driver.name}</h3>
                        {isApproved && (
                          <ShieldCheck className="w-4 h-4 text-blue-600" title="Verified Driver" />
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 font-medium font-mono">
                        {driver.phone} &bull; {driver.city}
                      </p>
                    </div>
                  </div>

                  <span
                    className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                      driver.isOnline
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1'
                        : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    {driver.isOnline && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />}
                    {driver.isOnline ? 'Online' : 'Offline'}
                  </span>
                </div>

                {/* KYC Badge Status Strip */}
                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-100 text-xs">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">KYC Status</span>
                  {isPending && (
                    <span className="px-2 py-0.5 rounded-lg bg-amber-100 text-amber-900 font-black text-[10px] flex items-center gap-1 border border-amber-300 animate-pulse">
                      <Clock className="w-3 h-3" />
                      Pending 24h SLA
                    </span>
                  )}
                  {isApproved && (
                    <span className="px-2 py-0.5 rounded-lg bg-emerald-100 text-emerald-800 font-black text-[10px] flex items-center gap-1 border border-emerald-300">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      Verified & Enabled
                    </span>
                  )}
                  {isRejected && (
                    <span className="px-2 py-0.5 rounded-lg bg-rose-100 text-rose-800 font-black text-[10px] flex items-center gap-1 border border-rose-300">
                      <XCircle className="w-3 h-3 text-rose-600" />
                      Rejected
                    </span>
                  )}
                </div>

                {/* Vehicle & Specs */}
                <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Vehicle Type:</span>
                    <strong className="text-slate-800 uppercase flex items-center gap-1">
                      <Bike className="w-3.5 h-3.5 text-slate-600" />
                      {driver.vehicleType}
                    </strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Bike Plate (RC):</span>
                    <strong className="text-slate-900 font-mono font-bold">{driver.vehicleNumber}</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Driving License:</span>
                    <strong className="text-blue-700 font-mono">{driver.drivingLicense || 'DL-MP09-2024-9988'}</strong>
                  </div>
                </div>

                {/* Performance & Wallet Telemetry */}
                <div className="grid grid-cols-3 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-center">
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold block">Trips</span>
                    <span className="text-xs font-black text-slate-800">{driver.completedDeliveries || 0}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold block">Rating</span>
                    <span className="text-xs font-black text-amber-500">{driver.rating} ★</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold block">Wallet Balance</span>
                    <span className="text-xs font-black text-emerald-600">₹{driver.walletBalance || 0}</span>
                  </div>
                </div>

                {/* Live Task Indicator */}
                {activeTask && (
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-2.5 text-xs text-amber-900 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <Navigation className="w-3.5 h-3.5 text-amber-600 animate-spin" />
                      <span>Active: {activeTask.status}</span>
                    </div>
                    <span className="font-mono font-bold text-[10px]">{activeTask.orderId}</span>
                  </div>
                )}

                {driver.isDeactivated && (
                  <div className="bg-rose-50 border border-rose-200 rounded-xl p-2 text-xs text-rose-800">
                    <span className="font-bold">Account Deactivated</span>: Scheduled deletion on {driver.deactivationScheduledDeletionDate || 'in 7 days'}
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="pt-3 border-t border-slate-100 space-y-2">
                <button
                  onClick={() => setSelectedDriverForKyc(driver)}
                  className="w-full py-2 rounded-xl bg-slate-900 hover:bg-slate-100 text-white text-xs font-black flex items-center justify-center gap-1.5 transition cursor-pointer shadow-xs"
                >
                  <FileText className="w-3.5 h-3.5 text-amber-400" />
                  <span>Inspect KYC Proofs (Bike, DL, Aadhaar, Voter)</span>
                </button>

                <div className="flex items-center justify-between gap-2">
                  <button
                    onClick={() => handleToggleOnline(driver.id)}
                    className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                      driver.isOnline
                        ? 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        : 'bg-emerald-600 text-white hover:bg-emerald-700'
                    }`}
                  >
                    {driver.isOnline ? 'Set Offline' : 'Set Available'}
                  </button>

                  <button
                    onClick={() => handleConvertToCustomer(driver)}
                    title="Delete Driver role and convert directly to Normal Customer"
                    className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold transition cursor-pointer flex items-center gap-1"
                  >
                    <UserCheck className="w-3.5 h-3.5" />
                    <span>Convert to Customer</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* KYC Proofs Inspection Modal */}
      {selectedDriverForKyc && (
        <div className="fixed inset-0 z-50 bg-white/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 max-w-2xl w-full shadow-2xl space-y-5 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="font-black text-lg text-slate-900 flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  <span>Driver KYC Document Verification</span>
                </h3>
                <p className="text-xs text-slate-500 font-medium mt-0.5">
                  Applicant: <strong>{selectedDriverForKyc.name}</strong> ({selectedDriverForKyc.phone}) &bull; City: {selectedDriverForKyc.city}
                </p>
              </div>

              <button
                onClick={() => {
                  setSelectedDriverForKyc(null);
                  setIsRejecting(false);
                }}
                className="p-1 rounded-xl text-slate-400 hover:bg-slate-100 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            {/* SLA Alert banner */}
            <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 flex items-center gap-3 text-xs text-amber-950">
              <Clock className="w-5 h-5 text-amber-600 flex-shrink-0" />
              <div>
                <strong className="block font-black">24-Hour Admin SLA Commitment</strong>
                <span>Admin verifies original vehicle documents and identity proofs within 24 hours. Upon approval, driver can log in and start receiving orders within 24 hours.</span>
              </div>
            </div>

            {/* KYC Document Proofs Grid */}
            <div className="space-y-4 max-h-[55vh] overflow-y-auto pr-1 text-xs">
              {/* Section 1: Bike & Vehicle Details */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <h4 className="font-black text-slate-900 flex items-center gap-2 uppercase tracking-wider text-[11px]">
                  <Bike className="w-4 h-4 text-blue-600" />
                  1. Bike & Vehicle Registration Proofs
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <span className="text-[10px] text-slate-500 font-bold block">Bike Registration Number (RC)</span>
                    <strong className="text-slate-900 text-sm font-mono">{selectedDriverForKyc.vehicleNumber}</strong>
                    <div className="mt-2 rounded-xl overflow-hidden border border-slate-200 bg-white">
                      <img
                        src={selectedDriverForKyc.kycDocs?.bikeRcDocumentUrl || 'https://images.unsplash.com/photo-1617788138017-80ad40651399?w=600&auto=format&fit=crop&q=80'}
                        alt="Bike RC Proof"
                        className="w-full h-32 object-cover"
                      />
                      <div className="p-2 text-[10px] text-slate-600 font-bold bg-slate-100 text-center">
                        Original Vehicle RC Document Proof
                      </div>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-500 font-bold block">Vehicle Type & Insurance</span>
                    <strong className="text-slate-900 text-sm">{selectedDriverForKyc.vehicleType}</strong>
                    <div className="mt-2 rounded-xl overflow-hidden border border-slate-200 bg-white">
                      <img
                        src={selectedDriverForKyc.kycDocs?.bikeInsuranceDocUrl || 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80'}
                        alt="Bike Insurance"
                        className="w-full h-32 object-cover"
                      />
                      <div className="p-2 text-[10px] text-slate-600 font-bold bg-slate-100 text-center">
                        Original Vehicle Insurance Proof
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 2: Driving License */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <h4 className="font-black text-slate-900 flex items-center gap-2 uppercase tracking-wider text-[11px]">
                  <CreditCard className="w-4 h-4 text-emerald-600" />
                  2. Driving License Proof (DL)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <span className="text-[10px] text-slate-500 font-bold block">DL Number</span>
                    <strong className="text-slate-900 text-sm font-mono">{selectedDriverForKyc.drivingLicense || 'DL-MP09-2024-9988'}</strong>
                    <div className="mt-2 rounded-xl overflow-hidden border border-slate-200 bg-white">
                      <img
                        src={selectedDriverForKyc.kycDocs?.drivingLicenseFrontUrl || 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80'}
                        alt="Driving License Front"
                        className="w-full h-32 object-cover"
                      />
                      <div className="p-2 text-[10px] text-slate-600 font-bold bg-slate-100 text-center">
                        Driving License Proof
                      </div>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-500 font-bold block">Live Rider Selfie</span>
                    <div className="mt-2 rounded-xl overflow-hidden border border-slate-200 bg-white">
                      <img
                        src={selectedDriverForKyc.kycDocs?.selfieUrl || selectedDriverForKyc.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80'}
                        alt="Rider Selfie"
                        className="w-full h-32 object-cover"
                      />
                      <div className="p-2 text-[10px] text-slate-600 font-bold bg-slate-100 text-center">
                        Live Identity Verification Selfie
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 3: Aadhaar Card & Voter ID */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <h4 className="font-black text-slate-900 flex items-center gap-2 uppercase tracking-wider text-[11px]">
                  <ShieldCheck className="w-4 h-4 text-purple-600" />
                  3. Aadhaar Card & Voter ID Original Proofs
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <span className="text-[10px] text-slate-500 font-bold block">Aadhaar Card Number</span>
                    <strong className="text-slate-900 text-sm font-mono">{selectedDriverForKyc.kycDocs?.aadhaarNumber || '7829 4410 9921'}</strong>
                    <div className="mt-2 rounded-xl overflow-hidden border border-slate-200 bg-white">
                      <img
                        src={selectedDriverForKyc.kycDocs?.aadhaarFrontUrl || 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=600&auto=format&fit=crop&q=80'}
                        alt="Aadhaar Proof"
                        className="w-full h-32 object-cover"
                      />
                      <div className="p-2 text-[10px] text-slate-600 font-bold bg-slate-100 text-center">
                        Original Aadhaar Card Proof
                      </div>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-500 font-bold block">Voter ID Card Number</span>
                    <strong className="text-slate-900 text-sm font-mono">{selectedDriverForKyc.kycDocs?.voterIdNumber || 'MP/24/098/120938'}</strong>
                    <div className="mt-2 rounded-xl overflow-hidden border border-slate-200 bg-white">
                      <img
                        src={selectedDriverForKyc.kycDocs?.voterIdDocUrl || 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=600&auto=format&fit=crop&q=80'}
                        alt="Voter ID Proof"
                        className="w-full h-32 object-cover"
                      />
                      <div className="p-2 text-[10px] text-slate-600 font-bold bg-slate-100 text-center">
                        Original Voter ID Card Proof
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Rejection input box */}
            {isRejecting && (
              <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 space-y-2">
                <label className="block text-xs font-bold text-rose-900">
                  Reason for Rejection / Missing Documents:
                </label>
                <input
                  type="text"
                  value={rejectionReasonInput}
                  onChange={(e) => setRejectionReasonInput(e.target.value)}
                  placeholder="e.g. Bike RC image is blurry, please re-upload clear photo of original RC"
                  className="w-full px-3 py-2 bg-white border border-rose-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
              {isRejecting ? (
                <>
                  <button
                    onClick={() => setIsRejecting(false)}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => handleReject(selectedDriverForKyc.id)}
                    className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black transition cursor-pointer shadow-xs"
                  >
                    Confirm Rejection & Send Feedback
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => setIsRejecting(true)}
                    className="px-4 py-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold transition cursor-pointer"
                  >
                    Reject KYC Proofs
                  </button>

                  <button
                    onClick={() => handleApprove(selectedDriverForKyc.id)}
                    className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black transition cursor-pointer shadow-md flex items-center gap-1.5"
                  >
                    <CheckCircle className="w-4 h-4" />
                    <span>Approve KYC & Enable 24h Login Features</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

