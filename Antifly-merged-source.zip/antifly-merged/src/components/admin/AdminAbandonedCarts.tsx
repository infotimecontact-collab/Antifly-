import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AbandonedCart } from '../../types';
import {
  ShoppingCart,
  Send,
  Sparkles,
  Smartphone,
  Globe,
  Clock,
  CheckCircle,
  Mail,
  MessageSquare,
  AlertCircle,
  DollarSign,
  Search,
} from 'lucide-react';

export const AdminAbandonedCarts: React.FC = () => {
  const { abandonedCarts, sendAbandonedCartReminder, showToast } = useApp();
  const [search, setSearch] = useState('');
  const [sendingId, setSendingId] = useState<string | null>(null);

  const filteredCarts = abandonedCarts.filter(
    (c) =>
      c.customerName.toLowerCase().includes(search.toLowerCase()) ||
      c.customerEmail.toLowerCase().includes(search.toLowerCase()) ||
      c.customerPhone.includes(search)
  );

  const totalValue = abandonedCarts.reduce((acc, c) => acc + c.cartValue, 0);
  const totalReminded = abandonedCarts.filter((c) => c.reminderSent).length;

  const handleSendReminder = async (id: string) => {
    setSendingId(id);
    await sendAbandonedCartReminder(id);
    setSendingId(null);
  };

  const handleBulkRemindAll = async () => {
    for (const cart of abandonedCarts) {
      if (!cart.reminderSent) {
        await sendAbandonedCartReminder(cart.id);
      }
    }
    showToast('Batch automated recovery reminders sent to all pending shoppers');
  };

  return (
    <div id="admin-abandoned-carts-view" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-amber-400" />
            Abandoned Cart Recovery Engine
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Identify high-intent shoppers who dropped off at checkout and recover revenue with automated omnichannel incentives.
          </p>
        </div>

        <button
          id="btn-bulk-remind-abandoned"
          onClick={handleBulkRemindAll}
          className="bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-2 transition shadow-lg shadow-amber-500/10"
        >
          <Send className="w-4 h-4" />
          Dispatch Batch AI Reminders
        </button>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="text-slate-400 text-xs font-medium">At-Risk Pipeline Value</div>
          <div className="text-2xl font-black text-rose-400 mt-1">₹{totalValue.toLocaleString('en-IN')}</div>
          <div className="text-[11px] text-slate-400 mt-1">{abandonedCarts.length} shopping carts pending</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="text-slate-400 text-xs font-medium">Reminders Dispatched</div>
          <div className="text-2xl font-black text-amber-400 mt-1">{totalReminded} <span className="text-xs font-normal text-slate-400">/ {abandonedCarts.length}</span></div>
          <div className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1">
            <CheckCircle className="w-3 h-3" /> WhatsApp, SMS & In-App Push
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="text-slate-400 text-xs font-medium">Estimated Recovery Win Rate</div>
          <div className="text-2xl font-black text-emerald-400 mt-1">28.4%</div>
          <div className="text-[11px] text-slate-400 mt-1">Boosted by personalized 10% coupon triggers</div>
        </div>
      </div>

      {/* Search Filter */}
      <div className="relative w-full sm:w-80">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          placeholder="Search customer, email or phone..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
        />
      </div>

      {/* Cart Cards List */}
      <div className="space-y-4">
        {filteredCarts.map((cart) => (
          <div
            key={cart.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl hover:border-slate-700 transition space-y-4"
          >
            {/* Top row: Customer + Cart Value + Source */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-sm text-amber-400">
                  {cart.customerName.charAt(0)}
                </div>
                <div>
                  <div className="text-sm font-bold text-white flex items-center gap-2">
                    {cart.customerName}
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700 flex items-center gap-1">
                      {cart.source.includes('App') ? (
                        <Smartphone className="w-3 h-3 text-purple-400" />
                      ) : (
                        <Globe className="w-3 h-3 text-blue-400" />
                      )}
                      {cart.source}
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                    <span>{cart.customerEmail}</span>
                    <span>•</span>
                    <span>{cart.customerPhone}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="text-xs text-slate-400 font-medium">Cart Value</div>
                  <div className="text-lg font-black text-amber-400">₹{cart.cartValue.toLocaleString('en-IN')}</div>
                </div>

                <button
                  id={`btn-remind-cart-${cart.id}`}
                  disabled={sendingId === cart.id}
                  onClick={() => handleSendReminder(cart.id)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition shadow-md ${
                    cart.reminderSent
                      ? 'bg-slate-800 text-emerald-400 hover:bg-slate-700 border border-slate-700'
                      : 'bg-amber-500 hover:bg-amber-400 text-slate-800'
                  }`}
                >
                  <Send className="w-3.5 h-3.5" />
                  {sendingId === cart.id
                    ? 'Dispatching...'
                    : cart.reminderSent
                    ? `Re-send Reminder (${cart.reminderCount})`
                    : 'Send Recovery Push & SMS'}
                </button>
              </div>
            </div>

            {/* Bottom row: Cart Items breakdown */}
            <div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Unpurchased Items ({cart?.items?.length || 0})
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {(cart?.items || []).map((item, i) => (
                  <div
                    key={i}
                    className="bg-white border border-slate-800/80 rounded-xl p-2.5 flex items-center gap-3"
                  >
                    <img
                      src={item.image}
                      alt={item.productName}
                      className="w-12 h-12 rounded-lg object-cover bg-slate-900 flex-shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-semibold text-white truncate">{item.productName}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        Size: {item.size} • Qty: {item.quantity}
                      </div>
                      <div className="text-xs font-bold text-amber-400 mt-0.5">
                        ₹{item.price * item.quantity}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-800/50">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3 text-slate-400" /> Abandoned at {cart.abandonedAt}
              </span>
              {cart.reminderSent ? (
                <span className="text-emerald-400 font-medium">✓ Automated discount coupon attached</span>
              ) : (
                <span className="text-amber-400/80">Pending merchant outreach</span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
