import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Product } from '../../types';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  X,
  Sparkles,
  Image as ImageIcon,
  Tag,
  CheckCircle,
  AlertTriangle,
  ArrowUpDown,
  Upload,
  Download,
  FileSpreadsheet,
} from 'lucide-react';
import { BulkProductUploadModal } from './BulkProductUploadModal';

export const AdminProducts: React.FC = () => {
  const { products, categories, saveProduct, deleteProduct, showToast } = useApp();

  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isBulkUploadOpen, setIsBulkUploadOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);

  const filteredProducts = products.filter((p) => {
    if (selectedCat !== 'all' && p.category.toLowerCase() !== selectedCat.toLowerCase()) {
      return false;
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      return p.name.toLowerCase().includes(q) || p.brand.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q);
    }
    return true;
  });

  const handleOpenAdd = () => {
    setEditingProduct({
      name: '',
      brand: 'Antifly Studio',
      category: 'Men',
      subcategory: 'Linen Shirts',
      price: 1999,
      mrp: 2999,
      totalStock: 50,
      rating: 4.8,
      reviewCount: 12,
      shortDescription: 'Handcrafted premium breathable fabric.',
      description: 'Expertly woven with 100% natural fibers for exceptional comfort and breathability.',
      images: [
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=600&auto=format&fit=crop&q=80',
      ],
      colors: [
        { name: 'Beige', hex: '#D2B48C' },
        { name: 'White', hex: '#FFFFFF' },
      ],
      sizes: ['M', 'L', 'XL'],
      specifications: [
        { label: 'Fabric', value: '100% Pure Organic Linen' },
        { label: 'Fit', value: 'Relaxed Tailored' },
      ],
      tags: ['Linen', 'Summer', 'Handcrafted'],
      searchKeywords: ['linen', 'shirt', 'men'],
      seoTitle: 'Artisan Linen Shirt | Antifly',
      seoDescription: 'Buy pure handcrafted linen shirts online.',
      seoKeywords: ['linen', 'fashion'],
      shippingInfo: 'Ships within 24 hours. Free Delivery on ₹999+',
      returnPolicy: '7-Day Hassle-Free Returns & Size Exchanges',
      exchangePolicy: 'Instant Doorstep Exchange Available',
      isPublished: true,
      isFeatured: true,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (prod: Product) => {
    setEditingProduct({ ...prod });
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct || !editingProduct.name) return;

    await saveProduct(editingProduct);
    setIsModalOpen(false);
    setEditingProduct(null);
    showToast(`Product "${editingProduct.name}" saved successfully!`);
  };

  const handleDelete = async (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete ${name}?`)) {
      await deleteProduct(id);
      showToast(`Product "${name}" deleted.`);
    }
  };

  const handleExportCSV = () => {
    if (products.length === 0) {
      showToast('No products in catalog to export.');
      return;
    }

    const headers = ['name', 'brand', 'category', 'subcategory', 'price', 'mrp', 'totalStock', 'sku', 'sizes', 'colors', 'imageUrl', 'description'];
    const rows = products.map((p) => [
      `"${p.name.replace(/"/g, '""')}"`,
      `"${p.brand.replace(/"/g, '""')}"`,
      `"${p.category}"`,
      `"${p.subcategory}"`,
      p.price,
      p.mrp,
      p.totalStock,
      `"${p.sku || ''}"`,
      `"${p.sizes?.join(';') || ''}"`,
      `"${p.colors?.map((c) => c.name).join(';') || ''}"`,
      `"${p.images?.[0] || p.image || ''}"`,
      `"${(p.description || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `antifly_catalog_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast(`📦 Exported ${products.length} products to CSV!`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white">
            Product Catalog Management
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage SKUs, variants, prices, inventory, bulk CSV ingestion, and omnichannel sync
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold rounded-xl text-xs flex items-center gap-2 transition"
            title="Export Entire Live Catalog to CSV"
          >
            <Download className="w-4 h-4 text-slate-400" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => setIsBulkUploadOpen(true)}
            className="px-4 py-2.5 bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white font-extrabold rounded-xl text-xs flex items-center gap-2 shadow-lg shadow-sky-600/20 transition"
            title="Bulk Upload CSV / File Catalog Ingestion"
          >
            <Upload className="w-4 h-4" />
            <span>Bulk Upload (CSV / File)</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-800 font-extrabold px-4 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-lg shadow-amber-500/20 transition"
          >
            <Plus className="w-4 h-4" />
            <span>Add Single Product</span>
          </button>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-900 p-3 rounded-2xl border border-slate-800">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by product name, brand, SKU..."
            className="w-full pl-10 pr-4 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={selectedCat}
            onChange={(e) => setSelectedCat(e.target.value)}
            className="p-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:outline-none cursor-pointer"
          >
            <option value="all">All Departments</option>
            {categories.map((c) => (
              <option key={c.id} value={c.name}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase tracking-wider text-[10px] border-b border-slate-700">
              <tr>
                <th className="p-3.5">Product</th>
                <th className="p-3.5">SKU / Dept</th>
                <th className="p-3.5">Price / MRP</th>
                <th className="p-3.5">Stock</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredProducts.map((p) => {
                const isLowStock = p.totalStock < 40;

                return (
                  <tr key={p.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="p-3.5">
                      <div className="flex items-center gap-3">
                        <img
                          src={p.images?.[0] || p.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200'}
                          alt={p.name}
                          className="w-12 h-14 object-cover rounded-lg border border-slate-700 flex-shrink-0"
                        />
                        <div>
                          <span className="text-[10px] uppercase font-bold text-amber-400">
                            {p.brand}
                          </span>
                          <h4 className="font-bold text-white text-xs line-clamp-1">{p.name}</h4>
                          <p className="text-[11px] text-slate-400">Rating: ⭐ {p.rating} ({p.reviewCount})</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-3.5">
                      <p className="font-mono text-slate-200">{p.sku}</p>
                      <p className="text-[11px] text-slate-400">{p.category} &bull; {p.subcategory}</p>
                    </td>
                    <td className="p-3.5">
                      <p className="font-bold text-white font-mono">₹{p.price.toLocaleString('en-IN')}</p>
                      <p className="text-[10px] text-slate-400 line-through">₹{p.mrp.toLocaleString('en-IN')}</p>
                    </td>
                    <td className="p-3.5">
                      <span
                        className={`font-bold font-mono px-2 py-0.5 rounded text-[11px] ${
                          isLowStock
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        }`}
                      >
                        {p.totalStock} units
                      </span>
                    </td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400">
                        {p.isPublished ? 'Published' : 'Draft'}
                      </span>
                    </td>
                    <td className="p-3.5 text-right space-x-2">
                      <button
                        onClick={() => handleOpenEdit(p)}
                        className="p-1.5 bg-slate-800 hover:bg-slate-700 text-amber-400 rounded-lg transition-colors"
                        title="Edit Product"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(p.id, p.name)}
                        className="p-1.5 bg-slate-800 hover:bg-rose-900/50 text-rose-400 rounded-lg transition-colors"
                        title="Delete Product"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Product Modal */}
      {isModalOpen && editingProduct && (
        <div className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-2xl shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-base text-white">
                {editingProduct.id ? 'Edit Product' : 'Add New Product'}
              </h3>
              <button onClick={() => setIsModalOpen(false)}>
                <X className="w-5 h-5 text-slate-400 hover:text-white" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2">
                  <label className="block text-slate-400 mb-1">Product Title</label>
                  <input
                    type="text"
                    required
                    value={editingProduct.name || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                    className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Brand</label>
                  <input
                    type="text"
                    value={editingProduct.brand || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, brand: e.target.value })}
                    className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Department</label>
                  <select
                    value={editingProduct.category || 'Men'}
                    onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                    className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Selling Price (₹)</label>
                  <input
                    type="number"
                    value={editingProduct.price || 0}
                    onChange={(e) => setEditingProduct({ ...editingProduct, price: Number(e.target.value) })}
                    className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">MRP Price (₹)</label>
                  <input
                    type="number"
                    value={editingProduct.mrp || 0}
                    onChange={(e) => setEditingProduct({ ...editingProduct, mrp: Number(e.target.value) })}
                    className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Total Stock Count</label>
                  <input
                    type="number"
                    value={editingProduct.totalStock || 0}
                    onChange={(e) => setEditingProduct({ ...editingProduct, totalStock: Number(e.target.value) })}
                    className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Primary Image URL</label>
                  <input
                    type="text"
                    value={editingProduct?.images?.[0] || editingProduct?.image || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, images: [e.target.value] })}
                    className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono text-[11px]"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-slate-400 mb-1">Description</label>
                  <textarea
                    rows={3}
                    value={editingProduct.description || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                    className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2 border-t border-slate-800">
                <button
                  type="submit"
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold py-2.5 rounded-xl shadow"
                >
                  Save Product
                </button>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 bg-slate-800 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Bulk Product Upload (CSV/JSON) Modal */}
      <BulkProductUploadModal
        isOpen={isBulkUploadOpen}
        onClose={() => setIsBulkUploadOpen(false)}
      />
    </div>
  );
};
