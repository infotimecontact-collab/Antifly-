import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SellerProfile } from '../../types';
import {
  Store,
  CheckCircle,
  XCircle,
  Clock,
  ShieldCheck,
  Search,
  Filter,
  Eye,
  Edit,
  Trash2,
  DollarSign,
  TrendingUp,
  MapPin,
  FileText,
  Building2,
  BadgeCheck,
  Package,
} from 'lucide-react';

export const AdminSellers: React.FC = () => {
  const { sellers, setSellers, showToast, activeSellerId, setActiveSellerId } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'wholesale' | 'dealership' | 'retail'>('all');
  const [selectedSeller, setSelectedSeller] = useState<SellerProfile | null>(null);
  const [editingCommissionSellerId, setEditingCommissionSellerId] = useState<string | null>(null);
  const [newCommissionRate, setNewCommissionRate] = useState<number>(5);

  const filteredSellers = sellers.filter((seller) => {
    const matchesSearch =
      seller.storeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      seller.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      seller.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (seller.gstNumber && seller.gstNumber.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesSearch) return false;
    if (selectedFilter === 'wholesale') return seller.isWholesaler;
    if (selectedFilter === 'dealership') return seller.isDealershipVendor;
    if (selectedFilter === 'retail') return !seller.isWholesaler && !seller.isDealershipVendor;
    return true;
  });

  const handleToggleStatus = (sellerId: string) => {
    setSellers((prev) =>
      prev.map((s) => (s.id === sellerId ? { ...s, isActive: !s.isActive } : s))
    );
    showToast('Seller status updated successfully');
  };

  const handleSaveCommission = (sellerId: string) => {
    setSellers((prev) =>
      prev.map((s) => (s.id === sellerId ? { ...s, commissionRate: newCommissionRate / 100 } : s))
    );
    setEditingCommissionSellerId(null);
    showToast(`Updated platform commission to ${newCommissionRate}%`);
  };

  return (
    <div className="space-y-6 animate-fade-in text-slate-900">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 flex items-center gap-2">
            <Store className="w-6 h-6 text-orange-500" />
            Seller & Wholesaler Management
          </h1>
          <p className="text-xs text-slate-500 mt-0.5 font-medium">
            100% Free Platform — 0% Commission & Instant Direct Payouts for all stores, wholesalers, and ventures.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold font-mono">
            0% COMMISSIONS • 100% FREE FOR ALL
          </span>
          <span className="px-3 py-1.5 rounded-xl bg-orange-50 text-orange-800 border border-orange-200 text-xs font-bold font-mono">
            {sellers.length} REGISTERED MERCHANTS
          </span>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-col md:flex-row items-center justify-between gap-3 shadow-xs">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search sellers by store name, city, GST number, or category..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-amber-500 font-medium"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={selectedFilter}
            onChange={(e) => setSelectedFilter(e.target.value as any)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 font-bold focus:outline-none focus:border-amber-500"
          >
            <option value="all">All Sellers ({sellers.length})</option>
            <option value="wholesale">Wholesalers ({sellers.filter((s) => s.isWholesaler).length})</option>
            <option value="dealership">Authorized Dealerships ({sellers.filter((s) => s.isDealershipVendor).length})</option>
            <option value="retail">Local Retailers</option>
          </select>
        </div>
      </div>

      {/* Sellers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSellers.map((seller) => (
          <div
            key={seller.id}
            className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 hover:shadow-lg transition-all shadow-xs flex flex-col justify-between"
          >
            <div className="space-y-3">
              {/* Header Info */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-3">
                  <img
                    src={seller.logoImage || 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=150&auto=format&fit=crop&q=80'}
                    alt={seller.storeName}
                    className="w-12 h-12 rounded-xl object-cover border border-slate-200 bg-slate-100 flex-shrink-0"
                  />
                  <div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <h3 className="font-extrabold text-sm text-slate-900">{seller.storeName}</h3>
                      {seller.isActive ? (
                        <span className="w-2 h-2 rounded-full bg-emerald-500" title="Active" />
                      ) : (
                        <span className="w-2 h-2 rounded-full bg-rose-500" title="Suspended" />
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500 font-medium">
                      {seller.category} &bull; {seller.city}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => handleToggleStatus(seller.id)}
                  className={`px-2 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider transition ${
                    seller.isActive
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-200'
                      : 'bg-rose-50 text-rose-800 border border-rose-200 hover:bg-emerald-50 hover:text-emerald-700'
                  }`}
                >
                  {seller.isActive ? 'Active' : 'Suspended'}
                </button>
              </div>

              {/* Badges & Role Types */}
              <div className="flex flex-wrap gap-1.5">
                {seller.isWholesaler && (
                  <span className="bg-purple-100 text-purple-800 text-[10px] font-extrabold px-2 py-0.5 rounded-md flex items-center gap-1">
                    <Package className="w-3 h-3" />
                    Wholesaler (MOQ: {seller.wholesaleMOQDefault || 12})
                  </span>
                )}
                {seller.isDealershipVendor && (
                  <span className="bg-blue-100 text-blue-800 text-[10px] font-extrabold px-2 py-0.5 rounded-md flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    Authorized Dealership
                  </span>
                )}
                <span className="bg-slate-100 text-slate-700 text-[10px] font-bold px-2 py-0.5 rounded-md">
                  Radius: {seller.deliveryRadiusKm} KM
                </span>
              </div>

              {/* Description */}
              <p className="text-xs text-slate-600 line-clamp-2">{seller.description}</p>

              {/* Financial & Revenue Telemetry */}
              <div className="grid grid-cols-3 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-center">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold block">Orders</span>
                  <span className="text-xs font-black text-slate-800">{seller.totalOrders.toLocaleString('en-IN')}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-bold block">Revenue</span>
                  <span className="text-xs font-black text-emerald-600">₹{(seller.totalRevenue / 1000).toFixed(0)}k</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-bold block">Commission</span>
                  <span className="text-xs font-black text-amber-600">{((seller.commissionRate || 0.05) * 100).toFixed(0)}%</span>
                </div>
              </div>

              {/* GST & License */}
              <div className="text-[11px] text-slate-500 space-y-0.5 font-mono">
                <p>GST: <strong className="text-slate-800">{seller.gstNumber || '23AABCT9912T1Z8'}</strong></p>
                <p>PAN: <strong className="text-slate-800">{seller.panNumber || 'AABCT9912T'}</strong></p>
                {seller.dealershipLicenseNo && (
                  <p>License: <strong className="text-blue-700">{seller.dealershipLicenseNo}</strong></p>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
              {editingCommissionSellerId === seller.id ? (
                <div className="flex items-center gap-1.5 flex-1">
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={newCommissionRate}
                    onChange={(e) => setNewCommissionRate(Number(e.target.value))}
                    className="w-16 px-2 py-1 bg-slate-100 border border-slate-300 rounded text-xs font-bold"
                  />
                  <span className="text-xs font-bold">%</span>
                  <button
                    onClick={() => handleSaveCommission(seller.id)}
                    className="px-2 py-1 bg-emerald-600 text-white rounded text-[11px] font-bold"
                  >
                    Save
                  </button>
                  <button
                    onClick={() => setEditingCommissionSellerId(null)}
                    className="px-2 py-1 bg-slate-200 text-slate-700 rounded text-[11px]"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => {
                    setEditingCommissionSellerId(seller.id);
                    setNewCommissionRate(Math.round((seller.commissionRate || 0.05) * 100));
                  }}
                  className="text-xs font-bold text-slate-600 hover:text-amber-600 flex items-center gap-1"
                >
                  <Edit className="w-3 h-3" />
                  <span>Edit Commission</span>
                </button>
              )}

              <button
                onClick={() => {
                  setActiveSellerId(seller.id);
                  showToast(`Switched active portal seller to ${seller.storeName}`);
                }}
                className="px-3 py-1.5 bg-slate-900 hover:bg-orange-600 text-white text-xs font-bold rounded-xl transition shadow-xs"
              >
                Manage Store
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
