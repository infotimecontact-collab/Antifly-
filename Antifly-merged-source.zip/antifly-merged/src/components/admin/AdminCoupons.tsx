import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Coupon } from '../../types';
import {
  Tag,
  Plus,
  Search,
  CheckCircle,
  XCircle,
  Copy,
  Trash2,
  Edit2,
  Smartphone,
  Globe,
  Sparkles,
  Percent,
  Calendar,
  Layers,
} from 'lucide-react';

export const AdminCoupons: React.FC = () => {
  const { coupons, showToast } = useApp();
  const [couponList, setCouponList] = useState<Coupon[]>(coupons);
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'active' | 'appOnly' | 'websiteOnly'>('all');
  const [editingCoupon, setEditingCoupon] = useState<Partial<Coupon> | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const filteredCoupons = couponList.filter((c) => {
    const matchesSearch =
      c.code.toLowerCase().includes(search.toLowerCase()) ||
      c.description.toLowerCase().includes(search.toLowerCase());
    if (!matchesSearch) return false;
    if (filterType === 'active') return c.isActive;
    if (filterType === 'appOnly') return c.appOnly;
    if (filterType === 'websiteOnly') return c.websiteOnly;
    return true;
  });

  const handleToggleStatus = (id: string) => {
    setCouponList((prev) =>
      prev.map((c) => (c.id === id ? { ...c, isActive: !c.isActive } : c))
    );
    showToast('Coupon status updated');
  };

  const handleDelete = (id: string) => {
    setCouponList((prev) => prev.filter((c) => c.id !== id));
    showToast('Coupon deleted');
  };

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    showToast(`Copied ${code} to clipboard`);
  };

  const handleSaveCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCoupon?.code) return;

    if (editingCoupon.id) {
      setCouponList((prev) =>
        prev.map((c) => (c.id === editingCoupon.id ? (editingCoupon as Coupon) : c))
      );
      showToast(`Coupon ${editingCoupon.code} updated`);
    } else {
      const newCoupon: Coupon = {
        id: `cp-${Date.now()}`,
        code: editingCoupon.code.toUpperCase().trim(),
        description: editingCoupon.description || 'Promotional coupon',
        discountType: editingCoupon.discountType || 'percentage',
        discountValue: Number(editingCoupon.discountValue) || 10,
        minCartValue: Number(editingCoupon.minCartValue) || 999,
        maxDiscount: editingCoupon.maxDiscount ? Number(editingCoupon.maxDiscount) : undefined,
        startDate: editingCoupon.startDate || new Date().toISOString().split('T')[0],
        endDate: editingCoupon.endDate || '2026-12-31',
        usageLimit: Number(editingCoupon.usageLimit) || 1000,
        usedCount: 0,
        isActive: true,
        appOnly: editingCoupon.appOnly || false,
        websiteOnly: editingCoupon.websiteOnly || false,
        categoryRestriction: editingCoupon.categoryRestriction || undefined,
      };
      setCouponList([newCoupon, ...couponList]);
      showToast(`New coupon ${newCoupon.code} created`);
    }
    setIsModalOpen(false);
    setEditingCoupon(null);
  };

  // Summary Metrics
  const totalRedemptions = couponList.reduce((acc, c) => acc + c.usedCount, 0);
  const activeCouponsCount = couponList.filter((c) => c.isActive).length;

  return (
    <div id="admin-coupons-view" className="space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Tag className="w-5 h-5 text-amber-400" />
            Promotional Coupons & Vouchers
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage omnichannel discounts, app-exclusive coupon codes, and cart threshold campaigns.
          </p>
        </div>
        <button
          id="btn-create-new-coupon"
          onClick={() => {
            setEditingCoupon({
              code: '',
              description: '',
              discountType: 'percentage',
              discountValue: 15,
              minCartValue: 1499,
              startDate: new Date().toISOString().split('T')[0],
              endDate: '2026-12-31',
              usageLimit: 500,
              isActive: true,
              appOnly: false,
              websiteOnly: false,
            });
            setIsModalOpen(true);
          }}
          className="bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-2 transition shadow-lg shadow-amber-500/10"
        >
          <Plus className="w-4 h-4" />
          Create New Coupon
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="text-slate-400 text-xs font-medium">Active Campaigns</div>
          <div className="text-2xl font-black text-white mt-1">{activeCouponsCount} <span className="text-xs font-normal text-slate-400">/ {couponList.length}</span></div>
          <div className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1">
            <CheckCircle className="w-3 h-3" /> Omnichannel active
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="text-slate-400 text-xs font-medium">Total Redemptions</div>
          <div className="text-2xl font-black text-amber-400 mt-1">{totalRedemptions.toLocaleString('en-IN')}</div>
          <div className="text-[11px] text-slate-400 mt-1">Across Website & Mobile Apps</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="text-slate-400 text-xs font-medium">App-Exclusive Codes</div>
          <div className="text-2xl font-black text-purple-400 mt-1">
            {couponList.filter((c) => c.appOnly).length}
          </div>
          <div className="text-[11px] text-purple-300 mt-1 flex items-center gap-1">
            <Smartphone className="w-3 h-3" /> Driving mobile downloads
          </div>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search coupon code or description..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs w-full sm:w-auto overflow-x-auto">
          {(['all', 'active', 'appOnly', 'websiteOnly'] as const).map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition ${
                filterType === type
                  ? 'bg-amber-500 text-slate-800 font-bold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {type === 'all' && 'All Coupons'}
              {type === 'active' && 'Active Only'}
              {type === 'appOnly' && 'App Only'}
              {type === 'websiteOnly' && 'Website Only'}
            </button>
          ))}
        </div>
      </div>

      {/* Coupons Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-white/70 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="py-3.5 px-4">Coupon Code</th>
                <th className="py-3.5 px-4">Discount</th>
                <th className="py-3.5 px-4">Min Spend / Cap</th>
                <th className="py-3.5 px-4">Platform Channel</th>
                <th className="py-3.5 px-4">Validity</th>
                <th className="py-3.5 px-4">Usage Stats</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredCoupons.map((coupon) => (
                <tr key={coupon.id} className="hover:bg-slate-800/30 transition">
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-1 rounded text-xs">
                        {coupon.code}
                      </span>
                      <button
                        onClick={() => handleCopy(coupon.code)}
                        className="text-slate-500 hover:text-slate-300 p-1"
                        title="Copy code"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-1 max-w-xs truncate">
                      {coupon.description}
                    </div>
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-white">
                    {coupon.discountType === 'percentage' ? (
                      <span className="text-emerald-400 font-bold">{coupon.discountValue}% OFF</span>
                    ) : (
                      <span className="text-emerald-400 font-bold">₹{coupon.discountValue} FLAT OFF</span>
                    )}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="text-slate-300 font-medium">Min: ₹{coupon.minCartValue}</div>
                    {coupon.maxDiscount && (
                      <div className="text-[11px] text-slate-400">Max discount: ₹{coupon.maxDiscount}</div>
                    )}
                  </td>
                  <td className="py-3.5 px-4">
                    {coupon.appOnly ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 text-[10px] font-semibold">
                        <Smartphone className="w-3 h-3" /> App Only
                      </span>
                    ) : coupon.websiteOnly ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 text-[10px] font-semibold">
                        <Globe className="w-3 h-3" /> Web Only
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700 text-[10px] font-semibold">
                        <Layers className="w-3 h-3" /> All Channels
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-slate-400 text-[11px]">
                    <div>Start: {coupon.startDate}</div>
                    <div>End: {coupon.endDate}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div
                          className="bg-amber-500 h-full rounded-full"
                          style={{
                            width: `${Math.min(100, (coupon.usedCount / coupon.usageLimit) * 100)}%`,
                          }}
                        />
                      </div>
                      <span className="text-slate-300 font-medium">
                        {coupon.usedCount} / {coupon.usageLimit}
                      </span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <button
                      onClick={() => handleToggleStatus(coupon.id)}
                      className={`px-2.5 py-1 rounded-full text-[10px] font-bold inline-flex items-center gap-1 transition ${
                        coupon.isActive
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}
                    >
                      {coupon.isActive ? (
                        <>
                          <CheckCircle className="w-3 h-3" /> Active
                        </>
                      ) : (
                        <>
                          <XCircle className="w-3 h-3" /> Paused
                        </>
                      )}
                    </button>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => {
                          setEditingCoupon(coupon);
                          setIsModalOpen(true);
                        }}
                        className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition"
                        title="Edit"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(coupon.id)}
                        className="p-1.5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 rounded-lg transition"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-100/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl">
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-white">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <Tag className="w-4 h-4 text-amber-400" />
                {editingCoupon?.id ? 'Edit Promotional Coupon' : 'Create New Coupon'}
              </h3>
              <button
                onClick={() => {
                  setIsModalOpen(false);
                  setEditingCoupon(null);
                }}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveCoupon} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Coupon Code *</label>
                  <input
                    type="text"
                    required
                    value={editingCoupon?.code || ''}
                    onChange={(e) =>
                      setEditingCoupon({ ...editingCoupon, code: e.target.value.toUpperCase() })
                    }
                    placeholder="e.g. WISEFEST20"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono uppercase font-bold focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Discount Type</label>
                  <select
                    value={editingCoupon?.discountType || 'percentage'}
                    onChange={(e) =>
                      setEditingCoupon({
                        ...editingCoupon,
                        discountType: e.target.value as 'percentage' | 'fixed',
                      })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="percentage">Percentage Discount (%)</option>
                    <option value="fixed">Flat Amount (₹)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Description</label>
                <input
                  type="text"
                  value={editingCoupon?.description || ''}
                  onChange={(e) => setEditingCoupon({ ...editingCoupon, description: e.target.value })}
                  placeholder="e.g. 20% off on your festive order above ₹1499"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">
                    {editingCoupon?.discountType === 'percentage' ? 'Value (%)' : 'Amount (₹)'}
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={editingCoupon?.discountValue || ''}
                    onChange={(e) =>
                      setEditingCoupon({ ...editingCoupon, discountValue: Number(e.target.value) })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Min Cart (₹)</label>
                  <input
                    type="number"
                    min="0"
                    value={editingCoupon?.minCartValue || ''}
                    onChange={(e) =>
                      setEditingCoupon({ ...editingCoupon, minCartValue: Number(e.target.value) })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Max Cap (₹)</label>
                  <input
                    type="number"
                    min="0"
                    value={editingCoupon?.maxDiscount || ''}
                    onChange={(e) =>
                      setEditingCoupon({ ...editingCoupon, maxDiscount: Number(e.target.value) })
                    }
                    placeholder="Optional"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Start Date</label>
                  <input
                    type="date"
                    value={editingCoupon?.startDate || ''}
                    onChange={(e) => setEditingCoupon({ ...editingCoupon, startDate: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">End Date</label>
                  <input
                    type="date"
                    value={editingCoupon?.endDate || ''}
                    onChange={(e) => setEditingCoupon({ ...editingCoupon, endDate: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Platform Channel</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingCoupon({ ...editingCoupon, appOnly: false, websiteOnly: false })}
                    className={`py-2 px-3 rounded-xl border text-center font-medium transition ${
                      !editingCoupon?.appOnly && !editingCoupon?.websiteOnly
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                        : 'bg-slate-800 border-slate-700 text-slate-400'
                    }`}
                  >
                    All Channels
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingCoupon({ ...editingCoupon, appOnly: true, websiteOnly: false })}
                    className={`py-2 px-3 rounded-xl border text-center font-medium transition ${
                      editingCoupon?.appOnly
                        ? 'bg-purple-500/20 border-purple-500 text-purple-300'
                        : 'bg-slate-800 border-slate-700 text-slate-400'
                    }`}
                  >
                    App Only
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingCoupon({ ...editingCoupon, appOnly: false, websiteOnly: true })}
                    className={`py-2 px-3 rounded-xl border text-center font-medium transition ${
                      editingCoupon?.websiteOnly
                        ? 'bg-blue-500/20 border-blue-500 text-blue-300'
                        : 'bg-slate-800 border-slate-700 text-slate-400'
                    }`}
                  >
                    Website Only
                  </button>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setEditingCoupon(null);
                  }}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold rounded-xl shadow-md"
                >
                  {editingCoupon?.id ? 'Update Coupon' : 'Publish Coupon'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
