import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SubAdmin, AdminDepartment } from '../../types';
import {
  ShieldCheck,
  UserPlus,
  Users,
  Search,
  CheckCircle2,
  XCircle,
  Edit2,
  Trash2,
  Lock,
  KeyRound,
  Phone,
  Mail,
  Briefcase,
  Layers,
  Sparkles,
  AlertTriangle,
  ChevronRight,
  Plus,
  RefreshCw,
  Eye,
  Check,
} from 'lucide-react';

const ALL_PERMISSIONS = [
  { id: 'orders', label: 'Orders & Dispatches', desc: 'Process orders, track couriers, manage return requests' },
  { id: 'sellers', label: 'Sellers & Diamond Roles', desc: 'Approve new shops, verify KYC, assign Diamond Badges' },
  { id: 'drivers', label: 'Drivers & Logistics', desc: 'Approve driver partners, verify licenses, set geofence radius' },
  { id: 'broadcasts', label: 'Driver Broadcast Pool', desc: 'Dispatch instant hyperlocal orders to nearby drivers' },
  { id: 'inventory', label: 'Catalog & Inventory', desc: 'Manage products, stock levels, categories, and pricing' },
  { id: 'cms', label: 'CMS, Banners & Reels', desc: 'Update hero banners, content pages, and curated reels' },
  { id: 'finance', label: 'Finance & Payouts', desc: 'Release seller settlements, driver milestone bonuses, refunds' },
  { id: 'support', label: '24/7 Support Desk', desc: 'Answer user queries, resolve dispute tickets, chat live' },
];

const DEPARTMENTS: AdminDepartment[] = [
  'Operations',
  'Catalog & Products',
  'Logistics & Drivers',
  'Finance & Payouts',
  'Customer Support',
  'Merchant Verifications',
];

export const AdminSubAdmins: React.FC = () => {
  const { subAdmins, createSubAdmin, updateSubAdminPermissions, toggleSubAdminStatus, deleteSubAdmin, showToast } =
    useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('ALL');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingSubAdmin, setEditingSubAdmin] = useState<SubAdmin | null>(null);

  // Form State
  const [formName, setFormName] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formDept, setFormDept] = useState<AdminDepartment>('Operations');
  const [formRoleTitle, setFormRoleTitle] = useState('');
  const [formPermissions, setFormPermissions] = useState<string[]>(['orders', 'sellers']);

  const filteredSubAdmins = subAdmins.filter((sa) => {
    const matchesSearch =
      sa.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sa.phone.includes(searchQuery) ||
      sa.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sa.roleTitle.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDept = selectedDept === 'ALL' || sa.department === selectedDept;
    return matchesSearch && matchesDept;
  });

  const handleOpenCreateModal = () => {
    setEditingSubAdmin(null);
    setFormName('');
    setFormPhone('');
    setFormEmail('');
    setFormDept('Operations');
    setFormRoleTitle('Operations Executive');
    setFormPermissions(['orders', 'sellers', 'support']);
    setIsCreateModalOpen(true);
  };

  const handleOpenEditModal = (sa: SubAdmin) => {
    setEditingSubAdmin(sa);
    setFormName(sa.name);
    setFormPhone(sa.phone);
    setFormEmail(sa.email);
    setFormDept(sa.department);
    setFormRoleTitle(sa.roleTitle);
    setFormPermissions(sa.permissions);
    setIsCreateModalOpen(true);
  };

  const togglePermission = (permId: string) => {
    if (formPermissions.includes(permId)) {
      if (formPermissions.length === 1) {
        showToast('⚠️ Sub-Admin must have at least one permission assigned.');
        return;
      }
      setFormPermissions(formPermissions.filter((p) => p !== permId));
    } else {
      setFormPermissions([...formPermissions, permId]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formPhone.trim() || !formEmail.trim()) {
      showToast('⚠️ Please fill in all required fields (Name, Mandatory Mobile, Email)');
      return;
    }

    if (editingSubAdmin) {
      updateSubAdminPermissions(editingSubAdmin.id, formPermissions, formDept, formRoleTitle);
    } else {
      createSubAdmin({
        name: formName.trim(),
        phone: formPhone.trim(),
        email: formEmail.trim(),
        department: formDept,
        roleTitle: formRoleTitle.trim() || `${formDept} Specialist`,
        permissions: formPermissions,
        createdBy: 'Super Admin',
      });
    }

    setIsCreateModalOpen(false);
  };

  const activeCount = subAdmins.filter((s) => s.status === 'ACTIVE').length;

  return (
    <div id="admin-subadmins-management" className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner with Stats */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-2xl bg-purple-50 text-purple-600 border border-purple-200">
              <ShieldCheck className="w-6 h-6" />
            </span>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900">
                Sub-Admin & Access Delegation
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 font-medium">
                Create sub-admins, assign role permissions, and delegate operational controls securely.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleOpenCreateModal}
            className="px-5 py-3 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-md transition cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>+ Create Sub-Admin</span>
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <p className="text-xs font-bold text-slate-500">Total Sub-Admins</p>
          <p className="text-2xl font-black text-slate-900 mt-1">{subAdmins.length}</p>
          <span className="text-[10px] text-purple-600 font-semibold">Configured accounts</span>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <p className="text-xs font-bold text-slate-500">Active Staff</p>
          <p className="text-2xl font-black text-emerald-600 mt-1">{activeCount}</p>
          <span className="text-[10px] text-emerald-600 font-semibold">With live access</span>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <p className="text-xs font-bold text-slate-500">Departments</p>
          <p className="text-2xl font-black text-slate-900 mt-1">{DEPARTMENTS.length}</p>
          <span className="text-[10px] text-slate-500 font-semibold">Segregated domains</span>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <p className="text-xs font-bold text-slate-500">Security Model</p>
          <p className="text-base font-black text-indigo-600 mt-1">RBAC Multi-Tenant</p>
          <span className="text-[10px] text-indigo-600 font-semibold">Granular permission keys</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-3xl p-4 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search sub-admin name, phone, email..."
            className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-900 focus:outline-none focus:border-purple-500 font-medium"
          />
        </div>

        {/* Department Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          <button
            onClick={() => setSelectedDept('ALL')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
              selectedDept === 'ALL'
                ? 'bg-purple-600 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            All ({subAdmins.length})
          </button>
          {DEPARTMENTS.map((dept) => {
            const count = subAdmins.filter((s) => s.department === dept).length;
            return (
              <button
                key={dept}
                onClick={() => setSelectedDept(dept)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                  selectedDept === dept
                    ? 'bg-purple-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {dept} ({count})
              </button>
            );
          })}
        </div>
      </div>

      {/* Sub-Admins Directory */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredSubAdmins.length === 0 ? (
          <div className="col-span-full py-16 text-center bg-white border border-slate-200 rounded-3xl p-6">
            <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-800">No Sub-Admins Found</h3>
            <p className="text-xs text-slate-500 mt-1">Try refining your search query or department filter.</p>
            <button
              onClick={handleOpenCreateModal}
              className="mt-4 px-4 py-2 rounded-xl bg-purple-600 text-white text-xs font-bold cursor-pointer"
            >
              + Create First Sub-Admin
            </button>
          </div>
        ) : (
          filteredSubAdmins.map((admin) => {
            const isActive = admin.status === 'ACTIVE';
            return (
              <div
                key={admin.id}
                className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-xs hover:border-purple-200 transition space-y-4"
              >
                {/* Header info */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-purple-50 border border-purple-200 text-purple-700 flex items-center justify-center font-black text-lg flex-shrink-0">
                      {admin.name.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-sm sm:text-base font-black text-slate-900">{admin.name}</h3>
                        <span
                          className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                            isActive
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-rose-50 text-rose-700 border border-rose-200'
                          }`}
                        >
                          {isActive ? 'Active' : 'Suspended'}
                        </span>
                      </div>
                      <p className="text-xs text-purple-700 font-bold">{admin.roleTitle}</p>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleOpenEditModal(admin)}
                      className="p-2 rounded-xl bg-slate-100 hover:bg-purple-50 text-slate-600 hover:text-purple-700 transition cursor-pointer"
                      title="Edit Sub-Admin Permissions"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => toggleSubAdminStatus(admin.id)}
                      className={`p-2 rounded-xl transition cursor-pointer ${
                        isActive
                          ? 'bg-rose-50 hover:bg-rose-100 text-rose-700'
                          : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700'
                      }`}
                      title={isActive ? 'Suspend Access' : 'Activate Access'}
                    >
                      {isActive ? <XCircle className="w-3.5 h-3.5" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      onClick={() => deleteSubAdmin(admin.id)}
                      className="p-2 rounded-xl bg-slate-100 hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition cursor-pointer"
                      title="Delete Sub-Admin"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Contact metadata */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs bg-slate-50 p-3 rounded-2xl border border-slate-100">
                  <div className="flex items-center gap-2 text-slate-700 font-semibold">
                    <Phone className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{admin.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-700 font-semibold truncate">
                    <Mail className="w-3.5 h-3.5 text-indigo-600" />
                    <span className="truncate">{admin.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-500 text-[11px]">
                    <Briefcase className="w-3.5 h-3.5 text-slate-400" />
                    <span>Dept: {admin.department}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-500 text-[11px]">
                    <Lock className="w-3.5 h-3.5 text-slate-400" />
                    <span>Last active: {admin.lastActive || 'Today'}</span>
                  </div>
                </div>

                {/* Permissions Badges */}
                <div className="space-y-1.5">
                  <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Assigned Delegations ({admin.permissions.length}):
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {admin.permissions.map((pId) => {
                      const match = ALL_PERMISSIONS.find((p) => p.id === pId);
                      return (
                        <span
                          key={pId}
                          className="px-2.5 py-1 rounded-xl bg-slate-100 text-slate-800 text-[11px] font-bold border border-slate-200 flex items-center gap-1"
                        >
                          <Check className="w-3 h-3 text-purple-600" />
                          <span>{match?.label || pId}</span>
                        </span>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Create / Edit Sub-Admin Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-100/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border border-slate-200 max-w-xl w-full p-6 sm:p-8 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-purple-50 text-purple-700">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-slate-900">
                    {editingSubAdmin ? 'Edit Sub-Admin Delegations' : 'Create New Sub-Admin'}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">
                    {editingSubAdmin
                      ? `Updating permissions for ${editingSubAdmin.name}`
                      : 'Set up administrative access for operations, catalog, logistics, or support.'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Name & Mobile */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="e.g. Ramesh Kumar"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-semibold focus:outline-none focus:border-purple-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">
                    Mandatory Mobile Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    placeholder="+91 98260 XXXXX"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-semibold focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              {/* Email & Role Title */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">Official Email *</label>
                  <input
                    type="email"
                    required
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    placeholder="staff@antifly.com"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-semibold focus:outline-none focus:border-purple-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">Role / Designation</label>
                  <input
                    type="text"
                    value={formRoleTitle}
                    onChange={(e) => setFormRoleTitle(e.target.value)}
                    placeholder="e.g. Logistics Dispatcher"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-semibold focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              {/* Department */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Assigned Department</label>
                <select
                  value={formDept}
                  onChange={(e) => setFormDept(e.target.value as AdminDepartment)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-semibold focus:outline-none focus:border-purple-500 cursor-pointer"
                >
                  {DEPARTMENTS.map((dept) => (
                    <option key={dept} value={dept}>
                      {dept}
                    </option>
                  ))}
                </select>
              </div>

              {/* Granular Permissions Checkboxes */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-black text-slate-900 uppercase tracking-wider">
                    Delegated Operational Permissions
                  </label>
                  <span className="text-[11px] font-bold text-purple-600">
                    {formPermissions.length} / {ALL_PERMISSIONS.length} selected
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {ALL_PERMISSIONS.map((perm) => {
                    const isChecked = formPermissions.includes(perm.id);
                    return (
                      <div
                        key={perm.id}
                        onClick={() => togglePermission(perm.id)}
                        className={`p-3 rounded-2xl border transition cursor-pointer flex items-start gap-2.5 ${
                          isChecked
                            ? 'bg-purple-50/60 border-purple-300 text-purple-950'
                            : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}}
                          className="mt-0.5 rounded text-purple-600 focus:ring-purple-500 cursor-pointer"
                        />
                        <div className="space-y-0.5 text-left">
                          <p className="text-xs font-bold">{perm.label}</p>
                          <p className="text-[10px] text-slate-500 leading-tight">{perm.desc}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold cursor-pointer shadow-md transition"
                >
                  {editingSubAdmin ? 'Save Permissions' : 'Create Sub-Admin'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
