import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Customer } from '../../types';
import {
  Users,
  Search,
  Mail,
  Phone,
  MapPin,
  ShoppingBag,
  IndianRupee,
  Smartphone,
  Globe,
  Tag,
  Shield,
  Eye,
  CheckCircle,
  XCircle,
  Plus,
  UserCheck,
} from 'lucide-react';

export const AdminCustomers: React.FC = () => {
  const { customers, orders, showToast } = useApp();
  const [customerList, setCustomerList] = useState<Customer[]>(customers);
  const [search, setSearch] = useState('');
  const [filterTag, setFilterTag] = useState<string>('all');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  const filteredCustomers = customerList.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.email.toLowerCase().includes(search.toLowerCase()) ||
      c.phone.includes(search);
    if (!matchesSearch) return false;
    if (filterTag === 'all') return true;
    return c.tags.includes(filterTag);
  });

  const handleToggleStatus = (id: string) => {
    setCustomerList((prev) =>
      prev.map((c) =>
        c.id === id ? { ...c, status: c.status === 'Active' ? 'Blocked' : 'Active' } : c
      )
    );
    showToast('Customer account status modified');
  };

  const totalSpentAll = customerList.reduce((acc, c) => acc + c.totalSpent, 0);
  const avgOrderValue = Math.round(
    totalSpentAll / Math.max(1, customerList.reduce((acc, c) => acc + c.totalOrders, 0))
  );

  return (
    <div id="admin-customers-view" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-400" />
            Customer Relationship Management (CRM)
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Omnichannel profiles, lifetime spend, order history, and VIP customer segment intelligence.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="bg-white px-3.5 py-2 rounded-xl border border-slate-800 text-xs">
            <span className="text-slate-400">Total Registered: </span>
            <span className="font-bold text-white">{customerList.length}</span>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="text-slate-400 text-xs font-medium">Customer Lifetime Value (LTV)</div>
          <div className="text-2xl font-black text-amber-400 mt-1">₹{totalSpentAll.toLocaleString('en-IN')}</div>
          <div className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1">
            <CheckCircle className="w-3 h-3" /> Average AOV: ₹{avgOrderValue.toLocaleString('en-IN')}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="text-slate-400 text-xs font-medium">VIP / High-Frequency Buyers</div>
          <div className="text-2xl font-black text-purple-400 mt-1">
            {customerList.filter((c) => c.tags.includes('VIP') || c.totalOrders > 2).length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Responsible for 64% of recurring GMV</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="text-slate-400 text-xs font-medium">App-First Shoppers</div>
          <div className="text-2xl font-black text-blue-400 mt-1">
            {customerList.filter((c) => c.preferredSource.includes('App')).length}
          </div>
          <div className="text-[11px] text-blue-300 mt-1 flex items-center gap-1">
            <Smartphone className="w-3 h-3" /> Android & iOS native users
          </div>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search customer by name, email, phone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs w-full sm:w-auto overflow-x-auto">
          {['all', 'VIP', 'Frequent Buyer', 'Festive Shopper'].map((tag) => (
            <button
              key={tag}
              onClick={() => setFilterTag(tag)}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition ${
                filterTag === tag
                  ? 'bg-amber-500 text-slate-800 font-bold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {tag === 'all' ? 'All Segments' : tag}
            </button>
          ))}
        </div>
      </div>

      {/* Customer CRM Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-white/70 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="py-3.5 px-4">Customer Profile</th>
                <th className="py-3.5 px-4">Contact Info</th>
                <th className="py-3.5 px-4">Preferred Channel</th>
                <th className="py-3.5 px-4">Orders Placed</th>
                <th className="py-3.5 px-4">Lifetime Spend</th>
                <th className="py-3.5 px-4">Tags & Segment</th>
                <th className="py-3.5 px-4">Account Status</th>
                <th className="py-3.5 px-4 text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredCustomers.map((cust) => (
                <tr key={cust.id} className="hover:bg-slate-800/30 transition">
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500/20 to-orange-500/20 border border-amber-500/30 text-amber-300 font-bold text-xs flex items-center justify-center">
                        {cust.name.charAt(0)}
                      </div>
                      <div>
                        <div className="font-bold text-white text-xs">{cust.name}</div>
                        <div className="text-[10px] text-slate-400">Joined {cust.registeredAt}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="text-slate-300 flex items-center gap-1.5">
                      <Mail className="w-3 h-3 text-slate-500" /> {cust.email}
                    </div>
                    <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                      <Phone className="w-3 h-3 text-slate-500" /> {cust.phone}
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700 text-[10px] font-medium">
                      {cust.preferredSource.includes('App') ? (
                        <Smartphone className="w-3 h-3 text-purple-400" />
                      ) : (
                        <Globe className="w-3 h-3 text-blue-400" />
                      )}
                      {cust.preferredSource}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-bold text-white">
                    {cust.totalOrders} Orders
                  </td>
                  <td className="py-3.5 px-4 font-extrabold text-amber-400">
                    ₹{cust.totalSpent.toLocaleString('en-IN')}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="flex flex-wrap gap-1">
                      {cust.tags.map((tag) => (
                        <span
                          key={tag}
                          className="px-2 py-0.5 bg-amber-500/10 text-amber-300 border border-amber-500/20 rounded text-[10px] font-semibold"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <button
                      onClick={() => handleToggleStatus(cust.id)}
                      className={`px-2.5 py-1 rounded-full text-[10px] font-bold inline-flex items-center gap-1 transition ${
                        cust.status === 'Active'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                      }`}
                    >
                      {cust.status === 'Active' ? (
                        <>
                          <CheckCircle className="w-3 h-3" /> Active
                        </>
                      ) : (
                        <>
                          <XCircle className="w-3 h-3" /> Blocked
                        </>
                      )}
                    </button>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => setSelectedCustomer(cust)}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition inline-flex items-center gap-1"
                    >
                      <Eye className="w-3.5 h-3.5" /> View Profile
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Customer Profile Modal */}
      {selectedCustomer && (
        <div className="fixed inset-0 bg-slate-100/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl">
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 font-black text-base flex items-center justify-center">
                  {selectedCustomer.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">{selectedCustomer.name}</h3>
                  <p className="text-xs text-slate-400">Customer ID: {selectedCustomer.id}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedCustomer(null)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-5 text-xs max-h-[75vh] overflow-y-auto">
              {/* Quick Metrics */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-white p-3 rounded-xl border border-slate-800">
                  <div className="text-slate-400 text-[11px]">Total Lifetime Orders</div>
                  <div className="text-lg font-bold text-white mt-0.5">{selectedCustomer.totalOrders} Orders</div>
                </div>
                <div className="bg-white p-3 rounded-xl border border-slate-800">
                  <div className="text-slate-400 text-[11px]">Lifetime Spend (LTV)</div>
                  <div className="text-lg font-black text-amber-400 mt-0.5">₹{selectedCustomer.totalSpent.toLocaleString('en-IN')}</div>
                </div>
                <div className="bg-white p-3 rounded-xl border border-slate-800">
                  <div className="text-slate-400 text-[11px]">Preferred Channel</div>
                  <div className="text-sm font-bold text-slate-200 mt-1">{selectedCustomer.preferredSource}</div>
                </div>
              </div>

              {/* Contact & Addresses */}
              <div className="bg-white p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Contact & Saved Addresses
                </div>
                <div className="grid grid-cols-2 gap-2 text-slate-300">
                  <div>Email: <span className="text-white font-medium">{selectedCustomer.email}</span></div>
                  <div>Phone: <span className="text-white font-medium">{selectedCustomer.phone}</span></div>
                </div>

                <div className="pt-2 border-t border-slate-800/80">
                  <div className="text-[11px] text-slate-400 mb-1">Primary Shipping Address:</div>
                  {selectedCustomer.addresses.map((addr) => (
                    <div key={addr.id} className="text-slate-300 text-xs bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                      <div className="font-semibold text-white">{addr.fullName} ({addr.type})</div>
                      <div>{addr.street}, {addr.apartment && `${addr.apartment}, `}{addr.city}, {addr.state} - {addr.pincode}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">Phone: {addr.phone}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Order History */}
              <div className="space-y-2">
                <div className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Recent Orders Placed by {selectedCustomer.name}
                </div>
                {orders
                  .filter((o) => o.customerId === selectedCustomer.id)
                  .map((order) => (
                    <div
                      key={order.id}
                      className="bg-white p-3 rounded-xl border border-slate-800 flex items-center justify-between"
                    >
                      <div>
                        <div className="font-bold text-white text-xs">{order.orderNumber}</div>
                        <div className="text-[11px] text-slate-400">
                          {order.createdAt} • {order?.items?.length || 0} item(s) • {order.paymentMethod}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs font-bold text-amber-400">₹{order.totalAmount}</div>
                        <span className="text-[10px] font-semibold text-emerald-400">{order.status}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
