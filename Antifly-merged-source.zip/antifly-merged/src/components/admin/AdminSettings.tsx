import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StoreSettings, AdminDriverRateConfig, AccountLifecycleConfig } from '../../types';
import {
  Settings,
  Save,
  CheckCircle,
  Phone,
  Mail,
  MapPin,
  Truck,
  IndianRupee,
  CreditCard,
  Sparkles,
  ShieldCheck,
  Smartphone,
  Globe,
  RotateCcw,
  Headphones,
  AlertTriangle,
  BadgePercent,
  Coins,
  Gem,
  Sun,
  CloudRain,
  Snowflake,
  Clock,
  UserCheck,
  Sliders,
} from 'lucide-react';

export const AdminSettings: React.FC = () => {
  const {
    settings,
    updateSettings,
    showToast,
    adminDriverRateConfig,
    updateDriverRateConfig,
    accountLifecycleConfig,
    updateAccountLifecycleConfig,
    autonomousConfig,
    updateAutonomousConfig,
    setIsAutonomousZeroAdminOpen,
  } = useApp();

  const [formData, setFormData] = useState<StoreSettings>(settings);
  const [driverRateForm, setDriverRateForm] = useState<AdminDriverRateConfig>(adminDriverRateConfig);
  const [lifecycleForm, setLifecycleForm] = useState<AccountLifecycleConfig>(accountLifecycleConfig);
  const [autonomousForm, setAutonomousForm] = useState(autonomousConfig);
  const [isSaving, setIsSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    await updateSettings(formData);
    await updateDriverRateConfig(driverRateForm);
    await updateAccountLifecycleConfig(lifecycleForm);
    updateAutonomousConfig(autonomousForm);
    setIsSaving(false);
    showToast('✅ Dynamic settings (Zero-Admin Autonomous Engine, Driver rates, Season surge & SLA) saved!');
  };

  return (
    <div id="admin-settings-view" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-slate-200 p-6 rounded-3xl shadow-xs">
        <div>
          <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <Settings className="w-5 h-5 text-red-600" />
            Dynamic System Control Center
          </h2>
          <p className="text-xs text-slate-500 font-medium mt-1">
            Dynamic driver amount (₹30+), summer/rainy season surge, 7-day deactivation lifecycle, 24h SLA, & membership coins/diamonds.
          </p>
        </div>

        <button
          form="store-settings-form"
          type="submit"
          disabled={isSaving}
          className="bg-red-600 hover:bg-red-700 text-white font-extrabold px-6 py-3 rounded-2xl text-xs flex items-center gap-2 transition shadow-sm cursor-pointer"
        >
          <Save className="w-4 h-4" />
          {isSaving ? 'Saving Changes...' : 'Save All Dynamic Configuration'}
        </button>
      </div>

      <form id="store-settings-form" onSubmit={handleSubmit} className="space-y-6">
        {/* ZERO-ADMIN AUTONOMOUS ENGINE & SELF-GOVERNANCE SWITCHBOARD */}
        <div className="bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-950 border border-emerald-500/40 rounded-3xl p-6 space-y-4 shadow-md text-white">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-800 flex items-center justify-center font-black">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                  Zero-Admin Autonomous Governance Engine
                </h3>
                <p className="text-xs text-slate-400 font-medium mt-0.5">
                  Eliminate admin dependency: Instant AI seller KYC, product auto-approvals, 24x7 UPI payouts &amp; AI dispute arbitration.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsAutonomousZeroAdminOpen(true)}
                className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs border border-amber-500/40 transition cursor-pointer"
              >
                Open Full 0-Touch Hub
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 pt-1">
            {[
              {
                key: 'zeroTouchModeEnabled',
                label: 'Zero-Touch Mode (Global)',
                desc: 'All approvals execute 100% via smart rules with 0 human touch.',
              },
              {
                key: 'autoApproveSellers',
                label: 'Instant AI Seller KYC',
                desc: 'Auto-verify GSTIN & PAN OCR under 30s.',
              },
              {
                key: 'autoApproveProducts',
                label: 'Instant Product Auto-Publish',
                desc: 'Live marketplace listings without approval queue.',
              },
              {
                key: 'instantEscrowPayouts',
                label: '24x7 Instant Escrow UPI',
                desc: 'Sellers withdraw completed funds instantly.',
              },
              {
                key: 'aiDisputeArbitration',
                label: 'AI Dispute Vision Arbitrator',
                desc: 'Auto-refunds for verified photo defects in 3s.',
              },
              {
                key: 'directPeerPaymentsEnabled',
                label: 'Direct Peer-to-Peer UPI',
                desc: 'Direct seller-buyer QR settlement support.',
              },
            ].map((rule) => {
              const isChecked = (autonomousForm as any)[rule.key];
              return (
                <div
                  key={rule.key}
                  onClick={() =>
                    setAutonomousForm({
                      ...autonomousForm,
                      [rule.key]: !isChecked,
                    })
                  }
                  className={`p-3 rounded-2xl border transition cursor-pointer flex items-start justify-between gap-3 ${
                    isChecked
                      ? 'bg-emerald-950/40 border-emerald-500/40'
                      : 'bg-slate-900/60 border-slate-800 opacity-60'
                  }`}
                >
                  <div>
                    <span className="text-xs font-black text-white block">{rule.label}</span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">{rule.desc}</span>
                  </div>
                  <div
                    className={`w-7 h-4 rounded-full p-0.5 transition-colors flex-shrink-0 ${
                      isChecked ? 'bg-emerald-400' : 'bg-slate-700'
                    }`}
                  >
                    <div
                      className={`w-3 h-3 rounded-full bg-white transition-transform ${
                        isChecked ? 'translate-x-3' : 'translate-x-0'
                      }`}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* DYNAMIC DRIVER FARE & SUMMER/RAINY SEASONAL ENGINE */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <Truck className="w-4 h-4 text-emerald-600" />
                Dynamic Driver Amount & Seasonal Rate Engine
              </h3>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                Admin controls base driver payout (₹30 or higher) and summer/rainy season dynamic surcharges.
              </p>
            </div>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase">
              Dynamic Rates
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Base Minimum Driver Fare (₹) <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                min="30"
                step="1"
                required
                value={driverRateForm.baseMinimumDriverFare}
                onChange={(e) =>
                  setDriverRateForm({
                    ...driverRateForm,
                    baseMinimumDriverFare: Math.max(30, Number(e.target.value)),
                  })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 font-black text-sm focus:outline-none focus:border-emerald-500"
              />
              <span className="text-[10px] text-emerald-700 font-bold mt-1 block">
                Guaranteed minimum: ₹30 or more
              </span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Per-KM Driver Distance Rate (₹/KM)
              </label>
              <input
                type="number"
                min="5"
                step="0.5"
                required
                value={driverRateForm.perKmRate}
                onChange={(e) =>
                  setDriverRateForm({
                    ...driverRateForm,
                    perKmRate: Number(e.target.value),
                  })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 font-bold text-sm focus:outline-none focus:border-emerald-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Paid per km travelled</span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Active Operational Season
              </label>
              <select
                value={driverRateForm.activeSeason}
                onChange={(e) =>
                  setDriverRateForm({
                    ...driverRateForm,
                    activeSeason: e.target.value as any,
                  })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 font-bold text-xs focus:outline-none focus:border-emerald-500 cursor-pointer"
              >
                <option value="NORMAL">Normal Season (Standard)</option>
                <option value="SUMMER">☀️ Summer Season (Heat Surge)</option>
                <option value="RAINY">🌧️ Rainy Season (Monsoon Surge)</option>
                <option value="WINTER">❄️ Winter Season (Fog Surge)</option>
              </select>
              <span className="text-[10px] text-amber-600 font-bold mt-1 block">
                Current: {driverRateForm.activeSeason} Season
              </span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Summer Season Surge (₹)
              </label>
              <input
                type="number"
                min="0"
                value={driverRateForm.summerSurgeExtraRupees}
                onChange={(e) =>
                  setDriverRateForm({
                    ...driverRateForm,
                    summerSurgeExtraRupees: Number(e.target.value),
                  })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-amber-700 font-bold text-sm focus:outline-none focus:border-emerald-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Added during summer months</span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Rainy Season Surge (₹)
              </label>
              <input
                type="number"
                min="0"
                value={driverRateForm.rainySurgeExtraRupees}
                onChange={(e) =>
                  setDriverRateForm({
                    ...driverRateForm,
                    rainySurgeExtraRupees: Number(e.target.value),
                  })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-blue-700 font-bold text-sm focus:outline-none focus:border-emerald-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Added during rainfall / monsoon</span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Night Shift Surge (10 PM–6 AM) (₹)
              </label>
              <input
                type="number"
                min="0"
                value={driverRateForm.nightSurgeExtraRupees}
                onChange={(e) =>
                  setDriverRateForm({
                    ...driverRateForm,
                    nightSurgeExtraRupees: Number(e.target.value),
                  })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-purple-700 font-bold text-sm focus:outline-none focus:border-emerald-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Late night rider incentive</span>
            </div>

            <div className="sm:col-span-2 flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200 rounded-2xl">
              <div>
                <strong className="text-xs font-bold text-slate-900 block">
                  Enable Dynamic Seasonal Surge
                </strong>
                <span className="text-[11px] text-slate-500">
                  Automatically add summer / rainy surge to driver orders
                </span>
              </div>
              <button
                type="button"
                onClick={() =>
                  setDriverRateForm({
                    ...driverRateForm,
                    isSeasonalSurgeActive: !driverRateForm.isSeasonalSurgeActive,
                  })
                }
                className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition cursor-pointer ${
                  driverRateForm.isSeasonalSurgeActive
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-200 text-slate-600'
                }`}
              >
                {driverRateForm.isSeasonalSurgeActive ? 'Surge ACTIVE' : 'Surge Disabled'}
              </button>
            </div>
          </div>
        </div>

        {/* DYNAMIC ACCOUNT LIFECYCLE & 24H SLA CONFIGURATION */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-purple-600" />
                Dynamic Account Lifecycle, 24-Hour SLA & 7-Day Conversion
              </h3>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                Dynamic 7-day deactivation freeze, 24h admin KYC verification SLA, and automatic conversion to normal customer.
              </p>
            </div>
            <span className="px-2.5 py-0.5 rounded-full bg-purple-100 text-purple-800 text-[10px] font-black uppercase">
              Lifecycle Policy
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Driver Deactivation Grace Period (Days)
              </label>
              <select
                value={lifecycleForm.driverGraceDays}
                onChange={(e) =>
                  setLifecycleForm({
                    ...lifecycleForm,
                    driverGraceDays: Number(e.target.value),
                  })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 font-black text-sm focus:outline-none focus:border-purple-500 cursor-pointer"
              >
                <option value={7}>7 Days (Default Dynamic Option)</option>
                <option value={14}>14 Days</option>
                <option value={30}>30 Days</option>
              </select>
              <span className="text-[10px] text-purple-700 font-bold mt-1 block">
                Dynamic {lifecycleForm.driverGraceDays}-day option for drivers
              </span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Admin KYC Review SLA (Hours)
              </label>
              <input
                type="number"
                min="1"
                max="72"
                value={lifecycleForm.driverVerificationSlaHours}
                onChange={(e) =>
                  setLifecycleForm({
                    ...lifecycleForm,
                    driverVerificationSlaHours: Number(e.target.value),
                  })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 font-black text-sm focus:outline-none focus:border-purple-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                Admin verifies documents within 24 hours
              </span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Driver First Login SLA (Hours)
              </label>
              <input
                type="number"
                min="1"
                max="72"
                value={lifecycleForm.driverLoginSlaHours}
                onChange={(e) =>
                  setLifecycleForm({
                    ...lifecycleForm,
                    driverLoginSlaHours: Number(e.target.value),
                  })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 font-black text-sm focus:outline-none focus:border-purple-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                Driver logs in within 24 hours after approval
              </span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Seller Registration Review
              </label>
              <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-900 flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>Direct Auto-Approval</span>
              </div>
              <span className="text-[10px] text-slate-400 mt-1 block">
                Sellers approved directly without admin verification
              </span>
            </div>

            <div className="sm:col-span-4 p-4 bg-purple-50 border border-purple-200 rounded-2xl text-xs text-purple-950 flex items-center justify-between gap-4">
              <div>
                <strong className="block font-black">
                  Auto-Convert Deleted Drivers / Sellers to Normal Customers
                </strong>
                <span className="text-[11px] text-purple-800">
                  When a driver completes the {lifecycleForm.driverGraceDays}-day deactivation or directly deletes their account, their mobile number is preserved and immediately converted to a Normal Customer account.
                </span>
              </div>
              <span className="px-3 py-1 rounded-xl bg-purple-600 text-white font-black text-xs shrink-0">
                Active & Enforced
              </span>
            </div>
          </div>
        </div>

        {/* DYNAMIC MEMBERSHIP COINS & DIAMONDS CONFIGURATION */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <Coins className="w-4 h-4 text-amber-500" />
                Dynamic Membership Coins & Diamonds Reward Engine
              </h3>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                Manage coin rewards, diamond multipliers, and VIP cashback dynamically.
              </p>
            </div>
            <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-black uppercase flex items-center gap-1">
              <Gem className="w-3 h-3 text-cyan-600" />
              Dynamic Currency
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div>
              <label className="block text-slate-700 font-bold mb-1">
                SuperCoins per ₹100 Spent
              </label>
              <input
                type="number"
                min="1"
                value={formData.coinsPer100Rupees ?? 5}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    coinsPer100Rupees: Number(e.target.value),
                  })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-amber-700 font-black text-sm focus:outline-none focus:border-amber-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Credited on every completed order</span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">
                1 Diamond Value in SuperCoins
              </label>
              <input
                type="number"
                min="10"
                value={formData.coinsPerDiamond ?? 100}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    coinsPerDiamond: Number(e.target.value),
                  })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-cyan-700 font-black text-sm focus:outline-none focus:border-amber-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Exchange rate: 100 Coins = 1 Diamond (= ₹10)</span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">
                VIP Diamond Member Discount (%)
              </label>
              <input
                type="number"
                min="0"
                max="50"
                value={formData.vipDiamondDiscountPercent ?? 15}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    vipDiamondDiscountPercent: Number(e.target.value),
                  })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-purple-700 font-black text-sm focus:outline-none focus:border-amber-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Extra discount for diamond tier users</span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Welcome Bonus SuperCoins
              </label>
              <input
                type="number"
                min="0"
                value={formData.welcomeBonusCoins ?? 50}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    welcomeBonusCoins: Number(e.target.value),
                  })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-emerald-700 font-black text-sm focus:outline-none focus:border-amber-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Given to new / converted accounts</span>
            </div>
          </div>
        </div>

        {/* Dynamic 24/7 Customer Support Configuration */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <Headphones className="w-4 h-4 text-red-600" />
              Dynamic 24/7 Customer Support Desk
            </h3>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase">
              Always Live (24/7)
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block text-slate-700 font-bold mb-1">
                24/7 Customer Support Email <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Mail className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={formData.contactEmail}
                  onChange={(e) => setFormData({ ...formData, contactEmail: e.target.value })}
                  placeholder="support@antifly.com"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3.5 py-2.5 text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
                />
              </div>
              <span className="text-[10px] text-slate-400 mt-1 block">Displayed on customer app profile & header</span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">
                24/7 Customer Helpline Phone <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Phone className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={formData.contactPhone}
                  onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                  placeholder="+91 98765 43210"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3.5 py-2.5 text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
                />
              </div>
              <span className="text-[10px] text-slate-400 mt-1 block">Toll-free / Direct call & WhatsApp helpline</span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">Brand Name / Store Title</label>
              <input
                type="text"
                required
                value={formData.storeName}
                onChange={(e) => setFormData({ ...formData, storeName: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Antifly Hyperlocal Marketplace</span>
            </div>
          </div>
        </div>

        {/* 7-Day Exchange Guarantee & Zero Denial Rules */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-emerald-600" />
              7-Day Return / Exchange Policy Enforcement
            </h3>
            <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-black uppercase">
              Consumer Protection Act
            </span>
          </div>

          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-950 space-y-1.5 font-medium">
            <div className="flex items-center gap-2 font-bold text-emerald-900">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Mandatory 7-Day Exchange & 100% Cancellation Right</span>
            </div>
            <p>
              Under Antifly rules, if a customer purchases a product from any seller, the seller <strong>CANNOT deny exchanging the product</strong> within 7 days.
            </p>
            <p className="text-[11px] text-emerald-800">
              ⚠️ If any seller denies exchange or return, the seller will be debited the compensation fee + full refund directly to the customer wallet.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block text-slate-700 font-bold mb-1">Return Window (Days)</label>
              <input
                type="number"
                min="7"
                max="30"
                value={7}
                readOnly
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 font-black focus:outline-none cursor-not-allowed"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Guaranteed 7 Days Policy</span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">Seller Denial Penalty to Buyer (₹)</label>
              <input
                type="number"
                min="50"
                value={100}
                readOnly
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 font-black focus:outline-none cursor-not-allowed"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Paid to customer if seller denies exchange</span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">Instant Cancellation Allowed</label>
              <div className="p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-emerald-700 flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>Any Time Before Handover</span>
              </div>
            </div>
          </div>
        </div>

        {/* Business Profile Details */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 space-y-4 shadow-xs">
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-3">
            <Globe className="w-4 h-4 text-red-600" />
            Registered Headquarters Address
          </h3>

          <div className="text-xs">
            <label className="block text-slate-700 font-bold mb-1">Registered Business Address</label>
            <div className="relative">
              <MapPin className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
              <textarea
                rows={2}
                value={formData.businessAddress}
                onChange={(e) => setFormData({ ...formData, businessAddress: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3.5 py-2 text-slate-900 font-medium focus:outline-none focus:border-red-500 text-xs"
              />
            </div>
          </div>
        </div>

        {/* Shipping & Geolocation Distance Logistics */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 space-y-4 shadow-xs">
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-3">
            <Truck className="w-4 h-4 text-red-600" />
            Hyperlocal Geolocation & 50 KM Discovery Engine
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div>
              <label className="block text-slate-700 font-bold mb-1">Default Store Discovery Radius</label>
              <select
                value={formData.defaultStoreSearchRadiusKm || 50}
                onChange={(e) =>
                  setFormData({ ...formData, defaultStoreSearchRadiusKm: Number(e.target.value) })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 font-bold focus:outline-none focus:border-red-500 cursor-pointer"
              >
                <option value={1}>1 KM (Ultra Local Neighborhood)</option>
                <option value={5}>5 KM (Local Area)</option>
                <option value={10}>10 KM (Sub-District)</option>
                <option value={25}>25 KM (Metro Zone)</option>
                <option value={50}>50 KM (Default Pan-District Radius)</option>
                <option value={100}>100 KM (Extended Regional)</option>
              </select>
              <span className="text-[10px] text-red-600 font-semibold mt-1 block">Default: 50 KM radius search</span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">Base Delivery Fee (₹)</label>
              <input
                type="number"
                min="0"
                value={formData.baseDeliveryFee ?? 30}
                onChange={(e) =>
                  setFormData({ ...formData, baseDeliveryFee: Number(e.target.value) })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 font-medium focus:outline-none focus:border-red-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Base fee for 0–3 KM delivery</span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">Additional Per-KM Rate (₹/KM)</label>
              <input
                type="number"
                min="0"
                value={formData.deliveryFeePerKm ?? 10}
                onChange={(e) =>
                  setFormData({ ...formData, deliveryFeePerKm: Number(e.target.value) })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 font-medium focus:outline-none focus:border-red-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Charged beyond base 3 KM</span>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">Platform Commission (%)</label>
              <input
                type="number"
                min="0"
                max="100"
                value={formData.platformCommissionPercentage ?? 10}
                onChange={(e) =>
                  setFormData({ ...formData, platformCommissionPercentage: Number(e.target.value) })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-emerald-600 font-black focus:outline-none focus:border-red-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Default commission per vendor order</span>
            </div>
          </div>
        </div>

        {/* Payment Gateways Switchboard */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 space-y-4 shadow-xs">
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-3">
            <CreditCard className="w-4 h-4 text-red-600" />
            Omnichannel Payment Gateway Switchboard
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-slate-900">UPI Instant & QR</div>
                <div className="text-[10px] text-slate-500 font-medium">GPay, PhonePe, Paytm</div>
              </div>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, upiEnabled: !formData.upiEnabled })}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition cursor-pointer ${
                  formData.upiEnabled
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-slate-200 text-slate-500'
                }`}
              >
                {formData.upiEnabled ? 'Enabled' : 'Disabled'}
              </button>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-slate-900">Cards & EMI</div>
                <div className="text-[10px] text-slate-500 font-medium">Visa, Mastercard, RuPay</div>
              </div>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, cardsEnabled: !formData.cardsEnabled })}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition cursor-pointer ${
                  formData.cardsEnabled
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-slate-200 text-slate-500'
                }`}
              >
                {formData.cardsEnabled ? 'Enabled' : 'Disabled'}
              </button>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-slate-900">Net Banking</div>
                <div className="text-[10px] text-slate-500 font-medium">50+ Major Indian Banks</div>
              </div>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, netBankingEnabled: !formData.netBankingEnabled })}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition cursor-pointer ${
                  formData.netBankingEnabled
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-slate-200 text-slate-500'
                }`}
              >
                {formData.netBankingEnabled ? 'Enabled' : 'Disabled'}
              </button>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-slate-900">Cash on Delivery</div>
                <div className="text-[10px] text-slate-500 font-medium">Pay at Doorstep</div>
              </div>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, codEnabled: !formData.codEnabled })}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition cursor-pointer ${
                  formData.codEnabled
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-slate-200 text-slate-500'
                }`}
              >
                {formData.codEnabled ? 'Enabled' : 'Disabled'}
              </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};

