import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { DynamicMembershipTier } from '../../types';
import {
  Coins,
  Gem,
  Crown,
  Sparkles,
  Save,
  Plus,
  Trash2,
  CheckCircle2,
  TrendingUp,
  Percent,
  Calendar,
  Gift,
  ArrowRightLeft,
  RotateCcw,
  Zap,
} from 'lucide-react';

export const AdminGamificationMemberships: React.FC = () => {
  const {
    adminGamificationConfig,
    updateGamificationConfig,
    superCoinsBalance,
    diamondsBalance,
    convertDiamondsToCoins,
    addDiamonds,
    showToast,
  } = useApp();

  const [formData, setFormData] = useState(adminGamificationConfig);
  const [selectedTierIndex, setSelectedTierIndex] = useState<number>(0);
  const [testGrantDiamonds, setTestGrantDiamonds] = useState<number>(50);
  const [testConvertDiamonds, setTestConvertDiamonds] = useState<number>(10);

  React.useEffect(() => {
    setFormData(adminGamificationConfig);
  }, [adminGamificationConfig]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateGamificationConfig(formData);
  };

  const handleTierUpdate = (index: number, updates: Partial<DynamicMembershipTier>) => {
    const updatedTiers = [...formData.membershipTiers];
    updatedTiers[index] = { ...updatedTiers[index], ...updates };
    setFormData({ ...formData, membershipTiers: updatedTiers });
  };

  const handleAddTier = () => {
    const newTier: DynamicMembershipTier = {
      id: `tier-${Date.now()}`,
      name: 'Platinum Prestige',
      badgeIcon: '🏆',
      minPointsOrSpend: 20000,
      coinsMultiplier: 4,
      diamondCashbackPercent: 12,
      freeExpressDelivery: true,
      priorityDispatch: true,
      earlyAccessHours: 36,
      annualFee: 1199,
      colorGradient: 'from-blue-600 via-indigo-600 to-purple-700',
      perks: [
        '4X SuperCoins on every purchase',
        '12% Diamond Cashback',
        'Unlimited Free Express Delivery',
        '36h Early VIP Access to Sales',
      ],
    };
    setFormData({
      ...formData,
      membershipTiers: [...formData.membershipTiers, newTier],
    });
    setSelectedTierIndex(formData.membershipTiers.length);
    showToast('New Dynamic Membership Tier created. Configure perks below and Save.');
  };

  const handleDeleteTier = (index: number) => {
    if (formData.membershipTiers.length <= 1) {
      showToast('⚠️ At least one membership tier must exist.');
      return;
    }
    const updated = formData.membershipTiers.filter((_, i) => i !== index);
    setFormData({ ...formData, membershipTiers: updated });
    setSelectedTierIndex(Math.max(0, index - 1));
    showToast('Membership tier deleted.');
  };

  const handleResetDefaults = () => {
    updateGamificationConfig(adminGamificationConfig);
    showToast('Reset gamification parameters.');
  };

  return (
    <div id="admin-gamification-memberships" className="space-y-6 max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-900 via-slate-900 to-purple-950 text-white rounded-2xl p-6 shadow-md border border-amber-500/20 relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-10 -translate-y-10 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-full text-xs font-black uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Dynamic Loyalty & Currency Hub
              </span>
              <span className="text-xs text-amber-200 font-bold">
                Live Dynamic Economy: Coins, Diamonds & Memberships
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white mt-2 tracking-tight">
              Dynamic Coins, Diamonds & VIP Memberships
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl mt-1">
              Configure dynamic earning rates, seasonal multipliers (2X/3X in Summer & Monsoon), diamond-to-coin exchange rates, and multi-tier membership privileges.
            </p>
          </div>

          {/* Current Global Live Stats */}
          <div className="flex items-center gap-3 bg-slate-800/80 border border-slate-700 p-3 rounded-xl">
            <div className="text-right">
              <p className="text-[10px] text-slate-400 font-bold uppercase">Customer Vault</p>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-xs font-bold text-amber-400 flex items-center gap-1">
                  🪙 {superCoinsBalance} Coins
                </span>
                <span className="text-xs font-bold text-cyan-400 flex items-center gap-1">
                  💎 {diamondsBalance} Diamonds
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Section 1: Dynamic Currency Engine (Coins & Diamonds) */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* SuperCoins Rules */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Coins className="w-5 h-5 text-amber-500" />
                SuperCoins Earning & Checkout Rules
              </h2>
              <span className="text-xs font-bold px-2 py-0.5 bg-amber-50 text-amber-800 border border-amber-200 rounded-md">
                1 Coin = ₹{formData.coinsToInrRedemptionRatio}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Coins Earned per ₹100 Spent
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={formData.coinsEarnedPer100Spent}
                    onChange={(e) =>
                      setFormData({ ...formData, coinsEarnedPer100Spent: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[11px] text-slate-400">coins</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Welcome Bonus Coins
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    max="5000"
                    step="50"
                    value={formData.welcomeBonusCoins}
                    onChange={(e) =>
                      setFormData({ ...formData, welcomeBonusCoins: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[11px] text-slate-400">coins</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Daily Check-in Streak Bonus
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    max="200"
                    value={formData.dailyCheckInBonus}
                    onChange={(e) =>
                      setFormData({ ...formData, dailyCheckInBonus: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[11px] text-slate-400">coins/day</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Max Coin Redemption Cap per Order
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="5"
                    max="100"
                    value={formData.maxCoinsRedemptionPercentagePerOrder}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        maxCoinsRedemptionPercentagePerOrder: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[11px] text-slate-400">% total</span>
                </div>
              </div>
            </div>

            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex items-center justify-between">
              <span>Customer Conversion:</span>
              <strong className="font-bold">100 SuperCoins = ₹{100 * formData.coinsToInrRedemptionRatio} Off at Checkout</strong>
            </div>
          </div>

          {/* Diamonds Currency Rules */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Gem className="w-5 h-5 text-cyan-500" />
                Diamonds Currency & Exchange Rules
              </h2>
              <span className="text-xs font-bold px-2 py-0.5 bg-cyan-50 text-cyan-800 border border-cyan-200 rounded-md">
                1 💎 = ₹{formData.diamondToInrRatio}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Diamonds Earned per Order
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={formData.diamondsEarnedPerOrder}
                    onChange={(e) =>
                      setFormData({ ...formData, diamondsEarnedPerOrder: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[11px] text-slate-400">💎 / order</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Diamond to SuperCoin Ratio
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={formData.diamondsToCoinsConversionRate}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        diamondsToCoinsConversionRate: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[11px] text-slate-400">Coins / 💎</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Referral Reward Diamonds
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="5"
                    max="200"
                    value={formData.referralRewardDiamonds}
                    onChange={(e) =>
                      setFormData({ ...formData, referralRewardDiamonds: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[11px] text-slate-400">💎 / friend</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Spin the Wheel Range
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={formData.spinWheelMinDiamonds}
                    onChange={(e) =>
                      setFormData({ ...formData, spinWheelMinDiamonds: Number(e.target.value) })
                    }
                    className="w-1/2 px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                  />
                  <span className="text-xs text-slate-400 font-bold">to</span>
                  <input
                    type="number"
                    min="10"
                    max="100"
                    value={formData.spinWheelMaxDiamonds}
                    onChange={(e) =>
                      setFormData({ ...formData, spinWheelMaxDiamonds: Number(e.target.value) })
                    }
                    className="w-1/2 px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                  />
                </div>
              </div>
            </div>

            <div className="p-3 bg-cyan-50 rounded-xl border border-cyan-200 text-xs text-cyan-900 flex items-center justify-between">
              <span>Exchange Value:</span>
              <strong className="font-bold">
                1 💎 Diamond = 🪙 {formData.diamondsToCoinsConversionRate} SuperCoins (Worth ₹{formData.diamondToInrRatio})
              </strong>
            </div>
          </div>
        </div>

        {/* Section 2: Seasonal Gamification Boost Campaign */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-indigo-600" />
              Seasonal Gamification Campaign & Multiplier
            </h2>
            <span className="text-xs font-extrabold px-3 py-1 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-800 rounded-full shadow-xs">
              {formData.activeSeasonMultiplier}X MULTIPLIER ACTIVE
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Campaign Banner Headline
              </label>
              <input
                type="text"
                value={formData.seasonCampaignName}
                onChange={(e) => setFormData({ ...formData, seasonCampaignName: e.target.value })}
                placeholder="e.g. Monsoon Mega Rewards & 2X Diamonds Carnival"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Active Season Point Multiplier
              </label>
              <select
                value={formData.activeSeasonMultiplier}
                onChange={(e) =>
                  setFormData({ ...formData, activeSeasonMultiplier: Number(e.target.value) })
                }
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:bg-white"
              >
                <option value={1}>1X (Standard Points)</option>
                <option value={1.5}>1.5X (Festival Weekend Boost)</option>
                <option value={2}>2X (Monsoon / Summer Double Rewards)</option>
                <option value={3}>3X (Mega Festive Triple Bonanza)</option>
                <option value={5}>5X (Super Bharat Big Days)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Section 3: Dynamic Membership Tiers (Silver, Gold, Diamond VIP, WiseOne) */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-5">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Crown className="w-5 h-5 text-amber-500" />
                Dynamic Membership Tiers & VIP Benefits
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Manage tier upgrade criteria, coin multipliers (1x–5x), diamond cashback percentages, and express delivery privileges.
              </p>
            </div>

            <button
              type="button"
              onClick={handleAddTier}
              className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-800 text-xs font-extrabold rounded-xl flex items-center gap-1.5 shadow-xs transition-all"
            >
              <Plus className="w-4 h-4" />
              Add New Tier
            </button>
          </div>

          {/* Tier Selector Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
            {formData.membershipTiers.map((tier, idx) => (
              <button
                key={tier.id || idx}
                type="button"
                onClick={() => setSelectedTierIndex(idx)}
                className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-2 ${
                  selectedTierIndex === idx
                    ? 'bg-slate-900 text-white shadow-xs ring-2 ring-amber-400'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <span>{tier.badgeIcon}</span>
                <span>{tier.name}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-700 text-amber-300">
                  {tier.coinsMultiplier}X
                </span>
              </button>
            ))}
          </div>

          {/* Selected Tier Editor Form */}
          {formData.membershipTiers[selectedTierIndex] && (
            <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xl">
                    {formData.membershipTiers[selectedTierIndex].badgeIcon}
                  </span>
                  <h3 className="text-sm font-extrabold text-slate-900">
                    Editing: {formData.membershipTiers[selectedTierIndex].name}
                  </h3>
                </div>

                <button
                  type="button"
                  onClick={() => handleDeleteTier(selectedTierIndex)}
                  className="text-xs text-rose-600 hover:text-rose-700 font-bold flex items-center gap-1 px-2.5 py-1 bg-rose-50 rounded-lg border border-rose-200"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Delete Tier
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Tier Name
                  </label>
                  <input
                    type="text"
                    value={formData.membershipTiers[selectedTierIndex].name}
                    onChange={(e) =>
                      handleTierUpdate(selectedTierIndex, { name: e.target.value })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Badge Emoji Icon
                  </label>
                  <input
                    type="text"
                    value={formData.membershipTiers[selectedTierIndex].badgeIcon}
                    onChange={(e) =>
                      handleTierUpdate(selectedTierIndex, { badgeIcon: e.target.value })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900 text-center"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Coins Multiplier
                  </label>
                  <select
                    value={formData.membershipTiers[selectedTierIndex].coinsMultiplier}
                    onChange={(e) =>
                      handleTierUpdate(selectedTierIndex, {
                        coinsMultiplier: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                  >
                    <option value={1}>1X Multiplier</option>
                    <option value={1.5}>1.5X Multiplier</option>
                    <option value={2}>2X Multiplier</option>
                    <option value={3}>3X Multiplier</option>
                    <option value={4}>4X Multiplier</option>
                    <option value={5}>5X Multiplier</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Diamond Cashback %
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min="0"
                      max="30"
                      value={formData.membershipTiers[selectedTierIndex].diamondCashbackPercent}
                      onChange={(e) =>
                        handleTierUpdate(selectedTierIndex, {
                          diamondCashbackPercent: Number(e.target.value),
                        })
                      }
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">%</span>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Spend Threshold to Unlock (₹)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="500"
                    value={formData.membershipTiers[selectedTierIndex].minPointsOrSpend}
                    onChange={(e) =>
                      handleTierUpdate(selectedTierIndex, {
                        minPointsOrSpend: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Annual Fee (₹ or 0 for Free)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="100"
                    value={formData.membershipTiers[selectedTierIndex].annualFee}
                    onChange={(e) =>
                      handleTierUpdate(selectedTierIndex, {
                        annualFee: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Early Access to Sales (Hours)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="72"
                    value={formData.membershipTiers[selectedTierIndex].earlyAccessHours}
                    onChange={(e) =>
                      handleTierUpdate(selectedTierIndex, {
                        earlyAccessHours: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                  />
                </div>

                <div className="flex items-center gap-4 pt-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.membershipTiers[selectedTierIndex].freeExpressDelivery}
                      onChange={(e) =>
                        handleTierUpdate(selectedTierIndex, {
                          freeExpressDelivery: e.target.checked,
                        })
                      }
                      className="rounded-md text-amber-500 focus:ring-amber-400"
                    />
                    <span className="text-xs font-bold text-slate-800">Free Express Delivery</span>
                  </label>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Section 4: Live Interactive Currency Testing & Simulator */}
        <div className="bg-slate-900 rounded-2xl p-6 text-white border border-slate-800 space-y-4">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-extrabold text-white">
              Live Currency Converter & Test Utility
            </h3>
          </div>
          <p className="text-xs text-slate-400">
            Simulate instant conversion of customer diamonds to coins or grant rewards to test live UI reflection.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Convert Diamonds */}
            <div className="p-4 bg-slate-800 rounded-xl border border-slate-700 space-y-3">
              <span className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
                <ArrowRightLeft className="w-4 h-4" />
                Convert Diamonds to SuperCoins
              </span>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="1"
                  max={diamondsBalance || 100}
                  value={testConvertDiamonds}
                  onChange={(e) => setTestConvertDiamonds(Number(e.target.value))}
                  className="w-1/2 px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-xs font-bold text-white"
                />
                <button
                  type="button"
                  onClick={() => convertDiamondsToCoins(testConvertDiamonds)}
                  className="w-1/2 px-3 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold transition-all"
                >
                  Convert (Gain {testConvertDiamonds * (formData.diamondsToCoinsConversionRate || 10)} 🪙)
                </button>
              </div>
            </div>

            {/* Grant Test Diamonds */}
            <div className="p-4 bg-slate-800 rounded-xl border border-slate-700 space-y-3">
              <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                <Gift className="w-4 h-4" />
                Grant Test Diamonds to Customer Vault
              </span>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="5"
                  max="500"
                  step="10"
                  value={testGrantDiamonds}
                  onChange={(e) => setTestGrantDiamonds(Number(e.target.value))}
                  className="w-1/2 px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-xs font-bold text-white"
                />
                <button
                  type="button"
                  onClick={() => addDiamonds(testGrantDiamonds, 'Admin Simulation Test Grant')}
                  className="w-1/2 px-3 py-2 bg-amber-500 hover:bg-amber-400 text-slate-800 font-extrabold rounded-lg text-xs transition-all"
                >
                  Grant +{testGrantDiamonds} 💎
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Action Save Bar */}
        <div className="flex items-center justify-between p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl flex items-center gap-2 transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            Reset Parameters
          </button>

          <button
            type="submit"
            className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-800 text-xs font-extrabold rounded-xl flex items-center gap-2 shadow-xs transition-all"
          >
            <Save className="w-4 h-4" />
            Save Dynamic Gamification & Membership Settings
          </button>
        </div>
      </form>
    </div>
  );
};
