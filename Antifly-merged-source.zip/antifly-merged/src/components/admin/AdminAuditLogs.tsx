import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AuditLog } from '../../types';
import {
  ShieldCheck,
  Search,
  Filter,
  Lock,
  UserCheck,
  Clock,
  Layers,
  FileCheck,
  Download,
} from 'lucide-react';

export const AdminAuditLogs: React.FC = () => {
  const { auditLogs } = useApp();
  const [search, setSearch] = useState('');
  const [selectedModule, setSelectedModule] = useState<string>('all');

  const filteredLogs = auditLogs.filter((log) => {
    const matchesSearch =
      log.userName.toLowerCase().includes(search.toLowerCase()) ||
      log.action.toLowerCase().includes(search.toLowerCase()) ||
      log.details.toLowerCase().includes(search.toLowerCase()) ||
      log.userRole.toLowerCase().includes(search.toLowerCase());
    if (!matchesSearch) return false;
    if (selectedModule === 'all') return true;
    return log.module === selectedModule;
  });

  return (
    <div id="admin-audit-logs-view" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            Security & Operational Audit Trail
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Immutable, timestamped enterprise activity log tracking all merchant mutations, role changes, and inventory actions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5" /> SOC2 & GDPR Compliant Logging
          </span>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search action, user, module or details..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs w-full sm:w-auto overflow-x-auto">
          {['all', 'Products', 'Orders', 'Coupons', 'Inventory', 'Banners', 'Settings'].map(
            (mod) => (
              <button
                key={mod}
                onClick={() => setSelectedModule(mod)}
                className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition ${
                  selectedModule === mod
                    ? 'bg-amber-500 text-slate-800 font-bold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {mod === 'all' ? 'All Modules' : mod}
              </button>
            )
          )}
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-white/70 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="py-3.5 px-4">Timestamp</th>
                <th className="py-3.5 px-4">Operator / User</th>
                <th className="py-3.5 px-4">Module</th>
                <th className="py-3.5 px-4">Action Performed</th>
                <th className="py-3.5 px-4">Details & Payload</th>
                <th className="py-3.5 px-4 text-right">IP Address</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/30 transition">
                  <td className="py-3.5 px-4 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3 h-3 text-slate-500" />
                      {log.timestamp}
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="font-bold text-white text-xs">{log.userName}</div>
                    <div className="text-[10px] text-amber-400 font-mono mt-0.5">{log.userRole}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700 text-[10px] font-semibold">
                      {log.module}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-white">
                    {log.action}
                  </td>
                  <td className="py-3.5 px-4 text-slate-300 max-w-md text-xs leading-relaxed">
                    {log.details}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono text-slate-500 text-[11px]">
                    {log.ipAddress || '192.168.1.104'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
