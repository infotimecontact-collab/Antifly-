import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Target,
  Users,
  TrendingUp,
  Handshake,
  Clock,
  Sparkles,
  MapPin,
  ShieldCheck,
  Share2,
  User,
  Zap,
  Globe,
  Compass,
  Award,
  ChevronRight,
  Sliders,
} from 'lucide-react';

import { NavaActionFeedTab } from './NavaActionFeedTab';
import { NavaMissionsTab } from './NavaMissionsTab';
import { NavaCirclesTab } from './NavaCirclesTab';
import { NavaProofTimelineTab } from './NavaProofTimelineTab';
import { NavaHelpExchangeTab } from './NavaHelpExchangeTab';
import { NavaTimeWalletTab } from './NavaTimeWalletTab';
import { NavaAICoachTab } from './NavaAICoachTab';
import { NavaRealWorldTab } from './NavaRealWorldTab';
import { NavaTrustPassportTab } from './NavaTrustPassportTab';
import { NavaGoalGraphTab } from './NavaGoalGraphTab';
import { NavaFutureSelfProfileTab } from './NavaFutureSelfProfileTab';

export const NavaSocialHubModal: React.FC = () => {
  const {
    isNavaModalOpen,
    setIsNavaModalOpen,
    navaActiveTab,
    setNavaActiveTab,
    navaTimeWallet,
    navaTrustPassport,
    navaIdentityMode,
  } = useApp();

  if (!isNavaModalOpen) return null;

  const navTabs: Array<{
    key: typeof navaActiveTab;
    label: string;
    icon: any;
    badge?: string;
    color: string;
  }> = [
    { key: 'feed', label: 'Action Feed', icon: Zap, color: 'text-amber-400' },
    { key: 'missions', label: 'Missions', icon: Target, badge: 'Active', color: 'text-indigo-400' },
    { key: 'circles', label: 'Circles & Voice', icon: Users, badge: 'Live', color: 'text-emerald-400' },
    { key: 'proofs', label: 'Proof of Progress', icon: TrendingUp, color: 'text-cyan-400' } as any,
    { key: 'help', label: 'Help Exchange', icon: Handshake, color: 'text-violet-400' },
    { key: 'timewallet', label: 'Time Wallet', icon: Clock, badge: `${navaTimeWallet.availableCredits}h`, color: 'text-amber-300' },
    { key: 'aicoach', label: 'AI Mission Coach', icon: Sparkles, color: 'text-indigo-300' },
    { key: 'realworld', label: 'Real-World (Indore)', icon: MapPin, color: 'text-teal-400' },
    { key: 'trust', label: 'Trust & Impact', icon: ShieldCheck, badge: `${navaTrustPassport.overallScore}`, color: 'text-emerald-400' },
    { key: 'graph', label: 'Goal Graph', icon: Share2, color: 'text-blue-400' },
    { key: 'profile', label: 'Future-Self', icon: User, color: 'text-purple-400' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-white/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-7xl h-[94vh] rounded-3xl bg-white border border-indigo-500/30 flex flex-col overflow-hidden shadow-2xl">
        {/* NAVA TOP BRAND & METRICS BAR */}
        <div className="px-5 py-3.5 bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950 border-b border-slate-800 flex items-center justify-between gap-3 shrink-0">
          {/* Logo & Philosophy Tagline */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/30 text-white font-black text-lg">
              N
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-black tracking-tight text-white flex items-center gap-1.5">
                  NAVA
                  <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    NEXT-GEN SOCIAL
                  </span>
                </h1>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Don’t Just Share Your Life. <span className="text-indigo-300 font-semibold">Build It Together.</span>
              </p>
            </div>
          </div>

          {/* Quick Metrics & Identity Pills */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Time Wallet Balance Pill */}
            <button
              onClick={() => setNavaActiveTab('timewallet')}
              className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-amber-500/30 text-amber-300 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
            >
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>{navaTimeWallet.availableCredits} Time Credits</span>
            </button>

            {/* Trust Passport Pill */}
            <button
              onClick={() => setNavaActiveTab('trust')}
              className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-emerald-500/30 text-emerald-300 text-xs font-bold transition hidden sm:flex items-center gap-1.5 cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>{navaTrustPassport.overallScore} Trust</span>
            </button>

            {/* Progressive Identity Badge */}
            <button
              onClick={() => setNavaActiveTab('profile')}
              className="px-3 py-1.5 rounded-xl bg-indigo-950/80 hover:bg-indigo-900 border border-indigo-500/40 text-indigo-200 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer capitalize"
            >
              <span className="text-xs">
                {navaIdentityMode === 'anonymous' ? '🕶️' : navaIdentityMode === 'pseudonym' ? '🎭' : '🛡️'}
              </span>
              <span className="hidden md:inline">{navaIdentityMode}</span>
            </button>

            {/* Close Modal Button */}
            <button
              onClick={() => setIsNavaModalOpen(false)}
              className="w-9 h-9 rounded-xl bg-slate-900 hover:bg-rose-950/80 text-slate-400 hover:text-rose-300 border border-slate-800 hover:border-rose-500/40 flex items-center justify-center transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* HORIZONTAL TAB NAVIGATION BAR */}
        <div className="px-4 py-2 bg-slate-900/90 border-b border-slate-800/80 flex items-center gap-1.5 overflow-x-auto shrink-0 scrollbar-none">
          {navTabs.map((tab) => {
            const Icon = tab.icon;
            // Handle proofs vs proof
            const isTabActive =
              navaActiveTab === tab.key || (tab.key === ('proofs' as any) && navaActiveTab === ('proofs' as any));

            return (
              <button
                key={tab.key}
                onClick={() => setNavaActiveTab(tab.key as any)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition flex items-center gap-1.5 cursor-pointer border ${
                  isTabActive
                    ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/30'
                    : 'bg-white hover:bg-slate-800 text-slate-400 border-slate-800'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isTabActive ? 'text-white' : tab.color}`} />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[9px] font-black ${
                      isTabActive
                        ? 'bg-white/20 text-white'
                        : 'bg-indigo-500/20 text-indigo-300'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* MAIN TAB CONTENT CONTAINER */}
        <div className="flex-1 p-4 md:p-6 overflow-y-auto bg-white space-y-6">
          {navaActiveTab === 'feed' && <NavaActionFeedTab />}
          {navaActiveTab === 'missions' && <NavaMissionsTab />}
          {navaActiveTab === 'circles' && <NavaCirclesTab />}
          {(navaActiveTab as string) === 'proofs' && <NavaProofTimelineTab />}
          {navaActiveTab === 'help' && <NavaHelpExchangeTab />}
          {navaActiveTab === 'timewallet' && <NavaTimeWalletTab />}
          {navaActiveTab === 'aicoach' && <NavaAICoachTab />}
          {navaActiveTab === 'realworld' && <NavaRealWorldTab />}
          {navaActiveTab === 'trust' && <NavaTrustPassportTab />}
          {navaActiveTab === 'graph' && <NavaGoalGraphTab />}
          {navaActiveTab === 'profile' && <NavaFutureSelfProfileTab />}
        </div>
      </div>
    </div>
  );
};
