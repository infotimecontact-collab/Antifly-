import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShieldCheck,
  Award,
  Users,
  Clock,
  Code2,
  Heart,
  TrendingUp,
  CheckCircle2,
  FileCheck,
  Sparkles,
} from 'lucide-react';

export const NavaTrustPassportTab: React.FC = () => {
  const { navaTrustPassport, navaImpactLedger } = useApp();

  return (
    <div className="space-y-6">
      {/* Top Trust Passport Card */}
      <div className="rounded-2xl bg-gradient-to-br from-slate-900 via-emerald-950/40 to-slate-900 border border-emerald-500/30 p-6 md:p-8 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="px-3 py-0.5 rounded-full text-xs font-bold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                NAVA Verifiable Trust Passport
              </span>
              <span className="text-xs text-slate-400">Non-Monetary Reputation Protocol</span>
            </div>

            <div className="flex items-baseline gap-3 pt-1">
              <h1 className="text-4xl md:text-5xl font-black text-white">{navaTrustPassport.overallScore}</h1>
              <span className="text-sm font-bold text-emerald-400">/ 100 Overall Community Trust</span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Traditional social media counts arbitrary likes and fake followers. NAVA replaces vanity with a
              cryptographically verifiable Trust Passport composed of 4 objective pillars: Reliability,
              Helpfulness, Peer-Reviewed Skill Evidence, and Community Conduct.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-white/80 border border-emerald-500/30 text-right space-y-2 shrink-0">
            <span className="text-[10px] font-bold text-slate-400 uppercase">Trust Tier</span>
            <p className="text-base font-black text-emerald-300">Level 4: Master Contributor</p>
            <p className="text-xs text-slate-400">
              {navaTrustPassport.peerConfirmationsCount} Peer Validations Recorded
            </p>
          </div>
        </div>

        {/* 4 Trust Pillars Progress Bars */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-800/80">
          <div className="p-4 rounded-xl bg-white/60 border border-slate-800 space-y-2">
            <div className="flex justify-between text-xs font-bold">
              <span className="text-slate-300">1. Reliability</span>
              <span className="text-emerald-400">{navaTrustPassport.reliability}%</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-emerald-500 rounded-full"
                style={{ width: `${navaTrustPassport.reliability}%` }}
              />
            </div>
            <p className="text-[10px] text-slate-400">Commitment to scheduled sprint tasks</p>
          </div>

          <div className="p-4 rounded-xl bg-white/60 border border-slate-800 space-y-2">
            <div className="flex justify-between text-xs font-bold">
              <span className="text-slate-300">2. Helpfulness</span>
              <span className="text-violet-400">{navaTrustPassport.helpfulness}%</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-violet-500 rounded-full"
                style={{ width: `${navaTrustPassport.helpfulness}%` }}
              />
            </div>
            <p className="text-[10px] text-slate-400">Active hours solving teammate blockers</p>
          </div>

          <div className="p-4 rounded-xl bg-white/60 border border-slate-800 space-y-2">
            <div className="flex justify-between text-xs font-bold">
              <span className="text-slate-300">3. Skill Evidence</span>
              <span className="text-cyan-400">{navaTrustPassport.skillEvidence}%</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-cyan-500 rounded-full"
                style={{ width: `${navaTrustPassport.skillEvidence}%` }}
              />
            </div>
            <p className="text-[10px] text-slate-400">Shipped code repos & verified artifacts</p>
          </div>

          <div className="p-4 rounded-xl bg-white/60 border border-slate-800 space-y-2">
            <div className="flex justify-between text-xs font-bold">
              <span className="text-slate-300">4. Community Conduct</span>
              <span className="text-amber-400">{navaTrustPassport.communityConduct}%</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-amber-500 rounded-full"
                style={{ width: `${navaTrustPassport.communityConduct}%` }}
              />
            </div>
            <p className="text-[10px] text-slate-400">Constructive feedback & zero toxicity</p>
          </div>
        </div>
      </div>

      {/* Feature 12: Social Impact Ledger */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" />
              Verifiable Social Impact Ledger
            </h3>
            <p className="text-xs text-slate-400">
              Immutable ledger of real contributions made to individuals and offline society.
            </p>
          </div>
        </div>

        {/* Big Counters Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center mb-2">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <h4 className="text-3xl font-black text-white">{navaImpactLedger.missionsCompleted}</h4>
            <p className="text-xs font-semibold text-slate-300">Missions Completed</p>
            <p className="text-[10px] text-slate-500">Across 3 goal domains</p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
            <div className="w-9 h-9 rounded-xl bg-violet-500/15 text-violet-400 flex items-center justify-center mb-2">
              <Users className="w-5 h-5" />
            </div>
            <h4 className="text-3xl font-black text-white">{navaImpactLedger.peopleHelped}</h4>
            <p className="text-xs font-semibold text-slate-300">People Helped 1-on-1</p>
            <p className="text-[10px] text-slate-500">Via Help Exchange</p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
            <div className="w-9 h-9 rounded-xl bg-teal-500/15 text-teal-400 flex items-center justify-center mb-2">
              <Clock className="w-5 h-5" />
            </div>
            <h4 className="text-3xl font-black text-white">{navaImpactLedger.hoursVolunteered}</h4>
            <p className="text-xs font-semibold text-slate-300">Hours Volunteered</p>
            <p className="text-[10px] text-slate-500">Offline & peer mentoring</p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/15 text-cyan-400 flex items-center justify-center mb-2">
              <Code2 className="w-5 h-5" />
            </div>
            <h4 className="text-3xl font-black text-white">{navaImpactLedger.openSourceContributions}</h4>
            <p className="text-xs font-semibold text-slate-300">Open-Source PRs</p>
            <p className="text-[10px] text-slate-500">Verified on GitHub</p>
          </div>
        </div>
      </div>
    </div>
  );
};
