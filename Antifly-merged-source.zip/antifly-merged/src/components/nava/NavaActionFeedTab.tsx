import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  NavaActionFeedItem,
  NavaFeedActionType,
  NavaCircle,
  NavaMission,
  NavaHelpListing,
} from '../../types';
import {
  CheckCircle2,
  Handshake,
  MapPin,
  Radio,
  Rocket,
  Search,
  MessageSquare,
  Sparkles,
  HelpCircle,
  Clock,
  ArrowRight,
  ShieldCheck,
  Zap,
  Info,
  Filter,
  Users,
  Target,
  ListTodo,
  Award,
  Flame,
  Check,
  ExternalLink,
  ChevronRight,
  Coins,
  AlertCircle,
  Share2,
  Lock,
  Unlock,
} from 'lucide-react';

export const NavaActionFeedTab: React.FC = () => {
  const {
    navaActionFeed,
    navaActiveTab,
    setNavaActiveTab,
    joinNavaMission,
    navaMissions,
    navaCircles,
    navaHelpListings,
    showToast,
    openNavaSocialHub,
    awardSuperCoins,
  } = useApp();

  const [selectedActionFilter, setSelectedActionFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeExplainId, setActiveExplainId] = useState<string | null>(null);
  const [completedTaskIds, setCompletedTaskIds] = useState<Record<string, boolean>>({});
  const [verifiedMilestoneIds, setVerifiedMilestoneIds] = useState<Record<string, boolean>>({});
  const [acceptedHelpIds, setAcceptedHelpIds] = useState<Record<string, boolean>>({});

  // 1. Sourced User-Joined Mission Circles
  const joinedCircles = useMemo(() => {
    return (navaCircles || []).filter((c) => {
      if (!c) return false;
      const linkedMission = (navaMissions || []).find((m) => m?.id === c.missionId);
      return linkedMission?.hasJoined || (c.members || []).some((m) => m?.id === 'user-jatin' || m?.name === 'Jatin Agrawal');
    });
  }, [navaCircles, navaMissions]);

  // 2. Derive dynamically sourced items from joined Mission Circles
  const sourcedCircleActions = useMemo(() => {
    const list: Array<{
      id: string;
      sourceCircleId: string;
      circleName: string;
      circleIcon?: string;
      type: 'TASK' | 'MILESTONE' | 'HELP' | 'VOICE_SPRINT';
      title: string;
      subtitle: string;
      description: string;
      priority?: 'high' | 'medium' | 'low';
      assignedTo?: string;
      timestamp: string;
      trustReward: number;
      coinReward: number;
      explainableReason: string;
      ctaLabel: string;
      isLive?: boolean;
    }> = [];

    (joinedCircles || []).forEach((circle) => {
      if (!circle) return;

      // Extract tasks from Circle Task Board
      (circle.tasksBoard || []).forEach((task) => {
        if (!task) return;
        list.push({
          id: `circle-task-${task.id}`,
          sourceCircleId: circle.id,
          circleName: circle.name,
          type: 'TASK',
          title: task.title,
          subtitle: `Circle Task Board • Assigned: ${task.assignedToName || 'Unassigned'}`,
          description: `Actionable task in ${circle.name}. Priority: ${(task.priority || 'medium').toUpperCase()}. Complete or peer review this deliverable to unblock circle progression.`,
          priority: task.priority || 'medium',
          assignedTo: task.assignedToName,
          timestamp: 'Live Circle Board',
          trustReward: task.priority === 'high' ? 8 : 5,
          coinReward: task.priority === 'high' ? 25 : 15,
          explainableReason: `Sourced from your joined circle "${circle.name}". High priority task blocking team deployment.`,
          ctaLabel: task.status === 'done' ? 'Review & Sign-Off' : 'Claim & Execute Task',
        });
      });

      // Extract Help Requests from Circle Chat
      (circle.recentMessages || [])
        .filter((m) => m?.isHelpRequest)
        .forEach((helpMsg) => {
          if (!helpMsg) return;
          list.push({
            id: `circle-help-${helpMsg.id}`,
            sourceCircleId: circle.id,
            circleName: circle.name,
            type: 'HELP',
            title: `Help Request: ${helpMsg.senderName || 'Teammate'}`,
            subtitle: `Urgent Peer Blocker in ${circle.name}`,
            description: `"${helpMsg.text || 'Need help with blocker'}"`,
            priority: 'high',
            assignedTo: helpMsg.senderName,
            timestamp: helpMsg.timestamp || 'Just now',
            trustReward: 10,
            coinReward: 30,
            explainableReason: `Teammate ${helpMsg.senderName || 'in your circle'} is blocked and requested assistance.`,
            ctaLabel: 'Offer Instant Help / Code Review',
          });
        });

      // Voice Sprint if active
      if (circle.isVoiceRoomLive) {
        list.push({
          id: `circle-voice-${circle.id}`,
          sourceCircleId: circle.id,
          circleName: circle.name,
          type: 'VOICE_SPRINT',
          title: `Live Voice Accountability Sprint 🎙️`,
          subtitle: `${circle.activeVoiceListeners || 5} members building together right now`,
          description: `Active co-working voice room in ${circle.name}. Goal: "${circle.activeGoal || 'Focus Sprint'}". Jump in to sprint together.`,
          priority: 'high',
          timestamp: 'Streaming Now',
          trustReward: 5,
          coinReward: 20,
          explainableReason: `Live focus room with active peers in your primary Mission Circle.`,
          ctaLabel: 'Join Live Voice Room',
          isLive: true,
        });
      }
    });

    // Milestones from joined missions
    (navaMissions || [])
      .filter((m) => m?.hasJoined)
      .forEach((mission) => {
        if (!mission) return;
        (mission.milestones || []).forEach((ms) => {
          if (ms && !ms.isCompleted) {
            list.push({
              id: `mission-ms-${ms.id}`,
              sourceCircleId: mission.circleId,
              circleName: mission.title,
              type: 'MILESTONE',
              title: `Milestone: ${ms.title}`,
              subtitle: `Target: ${ms.targetDurationWeeks || 2} Weeks • Mission Progress: ${mission.progressPct || 0}%`,
              description: ms.description || '',
              priority: 'high',
              timestamp: 'Mission Milestone',
              trustReward: 15,
              coinReward: 50,
              explainableReason: `Key milestone for your enrolled mission "${mission.title}".`,
              ctaLabel: 'Submit Proof / Verify Progress',
            });
          }
        });
      });

    return list;
  }, [joinedCircles, navaMissions]);

  // Handle Interactive Task Claim / Execution
  const handleExecuteTask = (taskId: string, title: string, coinReward: number, trustReward: number) => {
    setCompletedTaskIds((prev) => ({ ...prev, [taskId]: true }));
    awardSuperCoins(coinReward);
    showToast(`🎯 Action Completed! +${trustReward} Trust Score & +${coinReward} SuperCoins earned!`);
  };

  const handleVerifyMilestone = (msId: string, title: string) => {
    setVerifiedMilestoneIds((prev) => ({ ...prev, [msId]: true }));
    awardSuperCoins(35);
    showToast(`✅ Milestone Verified & Signed-off on Nava Ledger! +10 Trust`);
  };

  const handleAcceptHelp = (helpId: string) => {
    setAcceptedHelpIds((prev) => ({ ...prev, [helpId]: true }));
    awardSuperCoins(20);
    showToast(`🤝 Connected! 1:1 Help Session initialized with teammate.`);
  };

  // Action Filter Configuration
  const filterTabs = [
    { key: 'ALL', label: 'All Actionable', icon: Zap, count: (sourcedCircleActions || []).length + (navaActionFeed || []).length },
    { key: 'TASK', label: 'Circle Tasks', icon: ListTodo, count: (sourcedCircleActions || []).filter((s) => s.type === 'TASK').length },
    { key: 'MILESTONE', label: 'Milestones', icon: Target, count: (sourcedCircleActions || []).filter((s) => s.type === 'MILESTONE').length },
    { key: 'HELP', label: 'Help Requests', icon: Handshake, count: (sourcedCircleActions || []).filter((s) => s.type === 'HELP').length },
    { key: 'VOICE_SPRINT', label: 'Voice Sprints', icon: Radio, count: (sourcedCircleActions || []).filter((s) => s.type === 'VOICE_SPRINT').length },
  ];

  const filteredCircleActions = sourcedCircleActions.filter((item) => {
    if (selectedActionFilter !== 'ALL' && item.type !== selectedActionFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        item.title.toLowerCase().includes(q) ||
        item.subtitle.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.circleName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* High Level Action-First Social Feed Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/90 to-slate-900 p-6 border border-indigo-500/30 text-white shadow-2xl">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded-full text-xs font-black tracking-wider uppercase bg-gradient-to-r from-indigo-500 to-violet-600 text-white shadow-md shadow-indigo-500/30">
                Action-Based Social Feed
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <Users className="w-3 h-3" />
                {joinedCircles.length} Joined Mission Circles Sourced
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Action Over Scrolling. Purpose Over Vanity.
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Unlike traditional algorithms that optimize for passive watch-time, NAVA's Action Feed dynamically sources
              <span className="text-amber-300 font-bold"> active tasks</span>,
              <span className="text-cyan-300 font-bold"> mission milestones</span>, and
              <span className="text-violet-300 font-bold"> urgent peer help requests </span>
              directly from your joined Mission Circles.
            </p>
          </div>

          {/* Quick Metrics Badge Group */}
          <div className="flex flex-wrap lg:flex-col gap-2 shrink-0">
            <div className="bg-white/70 border border-slate-800 rounded-2xl p-3 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold text-base">
                <Flame className="w-5 h-5 text-amber-400" />
              </div>
              <div>
                <div className="text-[11px] text-slate-400 font-medium">Daily Action Streak</div>
                <div className="text-sm font-black text-white">12 Days Active • 94 Trust</div>
              </div>
            </div>

            <button
              onClick={() => setNavaActiveTab('circles')}
              className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 font-bold text-xs text-white shadow-lg shadow-indigo-600/30 transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <Users className="w-4 h-4 text-indigo-200" />
              <span>Manage Joined Circles</span>
            </button>
          </div>
        </div>
      </div>

      {/* Sourced Mission Circles Ribbon */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Active Feed Sources (Your Mission Circles)</span>
          </div>
          <span className="text-[11px] text-slate-400">Auto-synced with Circle Taskboards</span>
        </div>

        <div className="flex flex-wrap gap-2">
          {joinedCircles.map((circle) => (
            <div
              key={circle.id}
              onClick={() => setNavaActiveTab('circles')}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white border border-indigo-500/30 text-xs font-semibold text-white hover:border-indigo-400 transition cursor-pointer"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{circle.name}</span>
              <span className="px-1.5 py-0.2 rounded text-[10px] bg-slate-800 text-indigo-300 font-mono">
                {circle?.tasksBoard?.length || 0} tasks
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Action Filters & Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="flex flex-wrap gap-1.5 w-full sm:w-auto">
          {filterTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = selectedActionFilter === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => setSelectedActionFilter(tab.key)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer border ${
                  isActive
                    ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/30'
                    : 'bg-slate-900 hover:bg-slate-800 text-slate-400 border-slate-800'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                  isActive ? 'bg-indigo-800 text-white' : 'bg-slate-800 text-slate-400'
                }`}>
                  {tab.count}
                </span>
              </button>
            );
          })}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search actionable tasks, missions, help..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* SOURCED CIRCLE ACTION CARDS */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-slate-400 px-1">
          <span>Priority Action Queue ({filteredCircleActions.length} Actionable Items)</span>
          <span className="text-indigo-400">Click any card action to execute & earn trust</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredCircleActions.map((action) => {
            const isTaskDone = completedTaskIds[action.id];
            const isMsVerified = verifiedMilestoneIds[action.id];
            const isHelpAccepted = acceptedHelpIds[action.id];
            const isExplaining = activeExplainId === action.id;

            return (
              <div
                key={action.id}
                className={`relative rounded-2xl border p-5 transition-all duration-200 flex flex-col justify-between shadow-xl ${
                  isTaskDone || isMsVerified || isHelpAccepted
                    ? 'bg-white/70 border-emerald-500/40 text-slate-400'
                    : action.type === 'HELP'
                    ? 'bg-slate-900/90 border-violet-500/30 hover:border-violet-400'
                    : action.type === 'VOICE_SPRINT'
                    ? 'bg-slate-900/90 border-cyan-500/30 hover:border-cyan-400'
                    : 'bg-slate-900/90 border-slate-800 hover:border-indigo-500/40'
                }`}
              >
                <div className="space-y-3">
                  {/* Top Metadata Header */}
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-black tracking-wider uppercase border flex items-center gap-1 ${
                          action.type === 'TASK'
                            ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                            : action.type === 'MILESTONE'
                            ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                            : action.type === 'HELP'
                            ? 'bg-violet-500/10 text-violet-300 border-violet-500/30'
                            : 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30'
                        }`}
                      >
                        {action.type === 'TASK' && <ListTodo className="w-3 h-3" />}
                        {action.type === 'MILESTONE' && <Target className="w-3 h-3" />}
                        {action.type === 'HELP' && <Handshake className="w-3 h-3" />}
                        {action.type === 'VOICE_SPRINT' && <Radio className="w-3 h-3" />}
                        <span>{action.type}</span>
                      </span>

                      <span className="text-[11px] font-bold text-indigo-300 bg-indigo-950/80 px-2 py-0.5 rounded border border-indigo-500/30 truncate">
                        {action.circleName}
                      </span>
                    </div>

                    {/* Why this recommendation button */}
                    <button
                      onClick={() => setActiveExplainId(isExplaining ? null : action.id)}
                      className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-indigo-950 text-indigo-300 border border-slate-700 text-[10px] font-bold flex items-center gap-1 transition cursor-pointer shrink-0"
                      title="Explainable Recommendation Details"
                    >
                      <Info className="w-3 h-3 text-indigo-400" />
                      <span>Why this?</span>
                    </button>
                  </div>

                  {/* Explainability Popover */}
                  {isExplaining && (
                    <div className="p-3 rounded-xl bg-indigo-950 border border-indigo-500/50 text-xs text-indigo-200 flex items-start gap-2.5 animate-fadeIn shadow-lg">
                      <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <div className="space-y-0.5">
                        <p className="font-bold text-white">Why This Action Is In Your Feed:</p>
                        <p className="text-slate-300 text-[11px] leading-relaxed">{action.explainableReason}</p>
                      </div>
                    </div>
                  )}

                  {/* Content */}
                  <div className="space-y-1">
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      {action.title}
                      {action.isLive && (
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30 animate-pulse">
                          LIVE
                        </span>
                      )}
                    </h3>
                    <p className="text-xs font-semibold text-slate-400">{action.subtitle}</p>
                    <p className="text-xs text-slate-300 leading-relaxed pt-1">{action.description}</p>
                  </div>

                  {/* Rewards Row */}
                  <div className="flex items-center gap-3 pt-2">
                    <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>+{action.trustReward} Trust</span>
                    </div>
                    <div className="flex items-center gap-1 text-[11px] font-bold text-amber-400">
                      <Coins className="w-3.5 h-3.5" />
                      <span>+{action.coinReward} SuperCoins</span>
                    </div>
                  </div>
                </div>

                {/* Footer Action Trigger */}
                <div className="pt-4 mt-4 border-t border-slate-800 flex items-center justify-between gap-3">
                  <div className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-500" />
                    <span>{action.timestamp}</span>
                  </div>

                  {action.type === 'TASK' ? (
                    <button
                      onClick={() => handleExecuteTask(action.id, action.title, action.coinReward, action.trustReward)}
                      disabled={isTaskDone}
                      className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition cursor-pointer shadow-md ${
                        isTaskDone
                          ? 'bg-emerald-600 text-white cursor-default'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
                      }`}
                    >
                      {isTaskDone ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Task Completed & Verified</span>
                        </>
                      ) : (
                        <>
                          <span>{action.ctaLabel}</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </>
                      )}
                    </button>
                  ) : action.type === 'MILESTONE' ? (
                    <button
                      onClick={() => handleVerifyMilestone(action.id, action.title)}
                      disabled={isMsVerified}
                      className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition cursor-pointer shadow-md ${
                        isMsVerified
                          ? 'bg-amber-600 text-white cursor-default'
                          : 'bg-amber-500 hover:bg-amber-400 text-slate-800 shadow-amber-500/30'
                      }`}
                    >
                      {isMsVerified ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Milestone Verified</span>
                        </>
                      ) : (
                        <>
                          <span>{action.ctaLabel}</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </>
                      )}
                    </button>
                  ) : action.type === 'HELP' ? (
                    <button
                      onClick={() => handleAcceptHelp(action.id)}
                      disabled={isHelpAccepted}
                      className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition cursor-pointer shadow-md ${
                        isHelpAccepted
                          ? 'bg-violet-600 text-white cursor-default'
                          : 'bg-violet-600 hover:bg-violet-500 text-white shadow-violet-600/30'
                      }`}
                    >
                      {isHelpAccepted ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Help Session Opened</span>
                        </>
                      ) : (
                        <>
                          <span>{action.ctaLabel}</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </>
                      )}
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        setNavaActiveTab('circles');
                        showToast(`Entering Live Voice Room in ${action.circleName}...`);
                      }}
                      className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-2 transition shadow-md shadow-cyan-600/30 cursor-pointer"
                    >
                      <span>{action.ctaLabel}</span>
                      <Radio className="w-3.5 h-3.5 animate-pulse" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
