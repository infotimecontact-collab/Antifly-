import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  MapPin,
  Users,
  Calendar,
  Clock,
  ShieldCheck,
  CheckCircle2,
  QrCode,
  Sparkles,
  ExternalLink,
  Award,
} from 'lucide-react';

export const NavaRealWorldTab: React.FC = () => {
  const { navaMissions, showToast, setNavaActiveTab } = useApp();
  const [activeCheckInModal, setActiveCheckInModal] = useState<string | null>(null);
  const [checkInSuccess, setCheckInSuccess] = useState(false);

  const realWorldMissions = navaMissions.filter((m) => m.location?.isRealWorld);

  const handleSimulateQRCheckIn = (missionTitle: string) => {
    setCheckInSuccess(true);
    setTimeout(() => {
      showToast(`📍 Verified Attendance at "${missionTitle}"! Earned +2 Hours to Impact Ledger.`);
      setActiveCheckInModal(null);
      setCheckInSuccess(false);
    }, 1200);
  };

  return (
    <div className="space-y-6">
      {/* Real-World Hero Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-teal-950 via-slate-900 to-slate-900 border border-teal-500/30 p-6 md:p-8 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-2 max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="px-3 py-0.5 rounded-full text-xs font-bold uppercase bg-teal-500/20 text-teal-300 border border-teal-500/40 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-teal-400" />
              Real-World Physical Missions
            </span>
            <span className="text-xs text-slate-400">Offline Impact • Verified Geolocation</span>
          </div>
          <h2 className="text-xl md:text-2xl font-black text-white">
            Digital Networks Should Fix Physical Communities.
          </h2>
          <p className="text-xs text-slate-300 leading-relaxed">
            Social media shouldn't keep you glued to glass. NAVA connects you with offline drives in Indore
            and beyond — tree plantations, lake restorations, food rescue, and community tutoring.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-white/80 border border-teal-500/30 text-right space-y-1 shrink-0">
          <span className="text-[10px] font-bold text-slate-400 uppercase">Hyperlocal Hub</span>
          <p className="text-base font-black text-teal-300 flex items-center gap-1 justify-end">
            <MapPin className="w-4 h-4 text-teal-400" />
            Indore, Madhya Pradesh
          </p>
          <span className="text-[11px] text-slate-400 block">Cleanest City Community Hub</span>
        </div>
      </div>

      {/* Real-World Missions Listing */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {realWorldMissions.map((mission) => {
          const loc = mission.location;
          return (
            <div
              key={mission.id}
              className="rounded-2xl bg-slate-900 border border-slate-800 p-6 flex flex-col justify-between space-y-5 hover:border-teal-500/40 transition shadow-xl"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider bg-teal-500/15 text-teal-300 border border-teal-500/30 flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    {loc?.venue || loc?.city}
                  </span>

                  <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Verified Organizer
                  </span>
                </div>

                <div className="space-y-1">
                  <h3 className="text-base font-bold text-white">{mission.title}</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">{mission.description}</p>
                </div>

                {/* Target Outcome */}
                <div className="p-3 rounded-xl bg-white border border-slate-800/80 text-xs text-slate-300 flex items-start gap-2">
                  <Award className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-white">Deliverable Goal: </span>
                    <span className="text-slate-400">{mission.targetOutcome}</span>
                  </div>
                </div>

                {/* Logistics */}
                <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400 pt-1">
                  <span className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-teal-400" />
                    {loc?.meetingDate || 'Sundays 7:00 AM'}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-teal-400" />
                    {mission.currentParticipantsCount} / {mission.maxParticipants} Volunteers
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-slate-800 flex items-center justify-between gap-3">
                <button
                  onClick={() => setActiveCheckInModal(mission.id)}
                  className="px-3.5 py-2 rounded-xl bg-white hover:bg-slate-800 text-teal-300 border border-teal-500/30 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                >
                  <QrCode className="w-4 h-4" />
                  <span>On-Site QR Check-In</span>
                </button>

                <button
                  onClick={() => {
                    showToast(`🎯 Registered for ${mission.title}! Coordinates sent.`);
                  }}
                  className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold shadow-md shadow-teal-600/30 transition cursor-pointer"
                >
                  RSVP & Join Drive
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* QR Check-In Modal Simulation */}
      {activeCheckInModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-100/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-sm rounded-2xl bg-slate-900 border border-teal-500/40 p-6 text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-teal-500/20 border border-teal-500/40 flex items-center justify-center text-teal-300 mx-auto">
              <QrCode className="w-6 h-6" />
            </div>

            <div className="space-y-1">
              <h4 className="text-base font-black text-white">On-Site Geolocation Check-In</h4>
              <p className="text-xs text-slate-400">
                Scan the drive leader's badge or verify your GPS coordinates to credit your Social Impact Ledger.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-800 flex flex-col items-center justify-center space-y-2">
              <div className="w-32 h-32 bg-white rounded-lg p-2 flex items-center justify-center">
                <div className="w-full h-full border-4 border-slate-200 border-dashed rounded flex items-center justify-center font-mono text-[10px] text-slate-800 font-bold">
                  NAVA:INDR-049
                </div>
              </div>
              <span className="text-[10px] text-emerald-400 font-mono">GPS Verified: 22.7196° N, 75.8577° E</span>
            </div>

            <div className="flex gap-2 justify-center pt-2">
              <button
                onClick={() => setActiveCheckInModal(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-xs font-bold text-slate-300 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => handleSimulateQRCheckIn('Bilawali Lake Conservation')}
                disabled={checkInSuccess}
                className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-xs font-bold text-white shadow-md shadow-teal-600/30 transition cursor-pointer flex items-center gap-1.5"
              >
                {checkInSuccess ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-white" />
                    <span>Verifying...</span>
                  </>
                ) : (
                  <span>Verify Check-In</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
