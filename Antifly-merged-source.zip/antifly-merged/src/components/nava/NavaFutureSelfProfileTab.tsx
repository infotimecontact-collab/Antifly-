import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { NavaIdentityMode, NavaGoal } from '../../types';
import {
  User,
  Shield,
  Eye,
  EyeOff,
  Sparkles,
  Target,
  CheckCircle2,
  Lock,
  Globe,
  Sliders,
  Clock,
  Zap,
} from 'lucide-react';

export const NavaFutureSelfProfileTab: React.FC = () => {
  const {
    navaIdentityMode,
    setNavaIdentityMode,
    navaSelectedGoals,
    setNavaSelectedGoals,
    navaTrustPassport,
    showToast,
  } = useApp();

  const [futureVision, setFutureVision] = useState(
    'In 12 months, I will be a Senior AI Infrastructure Engineer leading open-source distributed systems and mentoring 50+ engineers.'
  );
  const [dailyActionCapMinutes, setDailyActionCapMinutes] = useState(45);
  const [isIncognitoFeed, setIsIncognitoFeed] = useState(false);

  const identityLevels: Array<{
    mode: NavaIdentityMode;
    label: string;
    icon: string;
    description: string;
  }> = [
    {
      mode: 'anonymous',
      label: 'Anonymous 🕶️',
      icon: '🕶️',
      description: 'Zero personal data exposed. Only your raw deliverables and code proofs speak for you.',
    },
    {
      mode: 'pseudonym',
      label: 'Pseudonym 🎭',
      icon: '🎭',
      description: 'Consistent alter-ego with accumulated trust scores without revealing real name.',
    },
    {
      mode: 'username',
      label: 'Username 👤',
      icon: '👤',
      description: 'Standard community handle (@jatin_builds).',
    },
    {
      mode: 'verified',
      label: 'Verified Builder 🛡️',
      icon: '🛡️',
      description: 'ID-verified with cryptographic Trust Passport credentials.',
    },
    {
      mode: 'professional',
      label: 'Professional 🎓',
      icon: '🎓',
      description: 'Full portfolio linked with institutional and GitHub credentials.',
    },
  ];

  const availableGoals: Array<{ key: NavaGoal; label: string; icon: string }> = [
    { key: 'developer', label: 'Full Stack & AI Developer', icon: '💻' },
    { key: 'entrepreneur', label: 'Tech Founder & Bootstrapper', icon: '🚀' },
    { key: 'designer', label: 'Product & System Designer', icon: '🎨' },
    { key: 'creator', label: 'Technical Writer & Creator', icon: '🎬' },
    { key: 'community_leader', label: 'Local Impact & Civic Leader', icon: '🌍' },
    { key: 'athlete', label: 'Fitness & Endurance Athlete', icon: '🏃' },
    { key: 'student', label: 'Curious Lifelong Learner', icon: '📚' },
  ];

  const toggleGoal = (goal: NavaGoal) => {
    if (navaSelectedGoals.includes(goal)) {
      if (navaSelectedGoals.length <= 1) {
        showToast('You must keep at least 1 future goal active.');
        return;
      }
      setNavaSelectedGoals(navaSelectedGoals.filter((g) => g !== goal));
    } else {
      setNavaSelectedGoals([...navaSelectedGoals, goal]);
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    showToast('✨ Future-Self Vision & Progressive Identity updated successfully!');
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/70 to-slate-900 border border-indigo-500/30 p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1.5 max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Future-Self Profile & Privacy
            </span>
            <span className="text-xs text-slate-400">Transform Feed to Who You Want to Become</span>
          </div>
          <h2 className="text-xl md:text-2xl font-black text-white">
            Your Profile is Your Future, Not Your Past.
          </h2>
          <p className="text-xs text-slate-300">
            Configure your goal trajectory, choose your progressive identity level, and set intentional
            boundaries against endless passive scrolling.
          </p>
        </div>

        <div className="p-3.5 rounded-xl bg-white/80 border border-indigo-500/30 text-right space-y-1 shrink-0">
          <span className="text-[10px] font-bold text-slate-400 uppercase">Active Identity</span>
          <p className="text-sm font-black text-indigo-300 capitalize">{navaIdentityMode} Mode</p>
          <span className="text-[10px] text-emerald-400">🛡️ {navaTrustPassport.overallScore} Trust Score</span>
        </div>
      </div>

      <form onSubmit={handleSaveProfile} className="space-y-6">
        {/* Section 1: Progressive Identity Selector */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-indigo-400" />
              1. Progressive Identity Engine (5 Granular Levels)
            </h3>
            <p className="text-xs text-slate-400">
              Switch privacy modes anytime. Your trust score attaches to your verified cryptographic hash.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {identityLevels.map((lvl) => {
              const isSelected = navaIdentityMode === lvl.mode;
              return (
                <div
                  key={lvl.mode}
                  onClick={() => {
                    setNavaIdentityMode(lvl.mode);
                    showToast(`Identity switched to ${lvl.label}`);
                  }}
                  className={`p-4 rounded-xl border cursor-pointer transition-all duration-200 space-y-2 flex flex-col justify-between ${
                    isSelected
                      ? 'bg-indigo-950/60 border-indigo-500 ring-2 ring-indigo-500/40 shadow-lg'
                      : 'bg-white/60 hover:bg-white border-slate-800'
                  }`}
                >
                  <div className="space-y-1">
                    <span className="text-2xl block">{lvl.icon}</span>
                    <h4 className="text-xs font-bold text-white">{lvl.label}</h4>
                    <p className="text-[11px] text-slate-400 leading-relaxed">{lvl.description}</p>
                  </div>

                  {isSelected && (
                    <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      Active Mode
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Section 2: Future-Self Vision & Selected Goals */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Target className="w-4 h-4 text-indigo-400" />
              2. Who Do You Want To Become? (Future Goals)
            </h3>
            <p className="text-xs text-slate-400">
              Select the identities and skill areas you want the NAVA feed and AI Coach to optimize for.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            {availableGoals.map((g) => {
              const isSelected = navaSelectedGoals.includes(g.key);
              return (
                <button
                  type="button"
                  key={g.key}
                  onClick={() => toggleGoal(g.key)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer border ${
                    isSelected
                      ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/30'
                      : 'bg-white text-slate-400 hover:text-slate-200 border-slate-800'
                  }`}
                >
                  <span>{g.icon}</span>
                  <span>{g.label}</span>
                  {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-200" />}
                </button>
              );
            })}
          </div>

          <div className="pt-2">
            <label className="block text-xs font-bold text-slate-300 mb-1">
              Your 12-Month Future Self Declaration *
            </label>
            <textarea
              rows={3}
              value={futureVision}
              onChange={(e) => setFutureVision(e.target.value)}
              placeholder="State your clear aspiration in 1-2 sentences..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Section 3: Anti-Dopamine & Mindful Social Controls */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-indigo-400" />
              3. Anti-Doomscrolling & Healthy Focus Boundaries
            </h3>
            <p className="text-xs text-slate-400">
              NAVA is designed to send you back into the real world to build, not keep you hooked.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-white border border-slate-800 space-y-2">
              <div className="flex justify-between text-xs font-bold text-white">
                <span>Daily Action Time Limit:</span>
                <span className="text-indigo-400">{dailyActionCapMinutes} Minutes</span>
              </div>
              <input
                type="range"
                min={15}
                max={120}
                step={15}
                value={dailyActionCapMinutes}
                onChange={(e) => setDailyActionCapMinutes(Number(e.target.value))}
                className="w-full accent-indigo-500"
              />
              <p className="text-[10px] text-slate-400">
                After {dailyActionCapMinutes} mins of active coordination, NAVA prompts you to log off and build.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-800 flex items-center justify-between gap-3">
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-white block">Incognito Goal Discovery</span>
                <p className="text-[10px] text-slate-400">
                  Hide your current search and explore activities from your Circle activity logs.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsIncognitoFeed(!isIncognitoFeed)}
                className={`p-2 rounded-xl border cursor-pointer ${
                  isIncognitoFeed
                    ? 'bg-indigo-600 text-white border-indigo-500'
                    : 'bg-slate-900 text-slate-400 border-slate-800'
                }`}
              >
                {isIncognitoFeed ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition cursor-pointer"
          >
            Save Future-Self Configuration
          </button>
        </div>
      </form>
    </div>
  );
};
