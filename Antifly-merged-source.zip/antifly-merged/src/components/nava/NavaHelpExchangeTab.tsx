import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { NavaHelpListing } from '../../types';
import {
  Handshake,
  Plus,
  Clock,
  Sparkles,
  Search,
  CheckCircle2,
  HelpCircle,
  MapPin,
  ShieldCheck,
  Zap,
  Filter,
  ArrowRight,
} from 'lucide-react';

export const NavaHelpExchangeTab: React.FC = () => {
  const {
    navaHelpListings,
    addNavaHelpListing,
    requestNavaHelpSession,
    navaTimeWallet,
    showToast,
  } = useApp();

  const [activeFilter, setActiveFilter] = useState<'ALL' | 'can_help' | 'need_help'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [isPostModalOpen, setIsPostModalOpen] = useState(false);

  // Form State
  const [postType, setPostType] = useState<'can_help' | 'need_help'>('can_help');
  const [postTitle, setPostTitle] = useState('');
  const [postDesc, setPostDesc] = useState('');
  const [postCategory, setPostCategory] = useState('Technology & Engineering');
  const [postLocation, setPostLocation] = useState('Indore / Remote');
  const [postAvailability, setPostAvailability] = useState('2 hrs / week');
  const [postCredits, setPostCredits] = useState<number>(1);

  const filteredListings = navaHelpListings.filter((item) => {
    if (activeFilter !== 'ALL' && item.type !== activeFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        item.title.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.skillCategory.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!postTitle.trim() || !postDesc.trim()) {
      showToast('Please provide a title and details for your listing.');
      return;
    }

    addNavaHelpListing({
      type: postType,
      title: postTitle.trim(),
      description: postDesc.trim(),
      skillCategory: postCategory,
      locationName: postLocation.trim(),
      availability: postAvailability.trim(),
      timeCreditsPerHour: Number(postCredits),
    });

    setIsPostModalOpen(false);
    setPostTitle('');
    setPostDesc('');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner with Time Wallet balance snippet */}
      <div className="rounded-2xl bg-gradient-to-r from-violet-950 via-slate-900 to-slate-900 border border-violet-500/30 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div className="space-y-1 max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase bg-violet-500/20 text-violet-300 border border-violet-500/30">
              Help Exchange & Time Bank
            </span>
            <span className="text-xs text-slate-400">1 Hour Given = 1 Time Credit Earned</span>
          </div>
          <h2 className="text-xl md:text-2xl font-black text-white">
            Everyone Knows Something. Everyone Needs Something.
          </h2>
          <p className="text-xs text-slate-300">
            Offer your specialized skills or get unstuck with verified community teammates. All sessions
            are balanced via fair, non-monetary Time Credits.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <div className="p-3 rounded-xl bg-white/80 border border-violet-500/40 text-right">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Your Time Wallet</span>
            <span className="text-lg font-black text-violet-300 flex items-center gap-1">
              <Clock className="w-4 h-4 text-amber-400" />
              {navaTimeWallet.availableCredits} Credits
            </span>
          </div>
          <button
            onClick={() => setIsPostModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs shadow-lg shadow-violet-600/30 transition flex items-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Create Listing
          </button>
        </div>
      </div>

      {/* Filter Tabs & Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => setActiveFilter('ALL')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer border ${
              activeFilter === 'ALL'
                ? 'bg-slate-800 text-white border-slate-700'
                : 'bg-slate-900 text-slate-400 border-slate-800'
            }`}
          >
            All Exchange ({navaHelpListings.length})
          </button>
          <button
            onClick={() => setActiveFilter('can_help')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
              activeFilter === 'can_help'
                ? 'bg-emerald-600 text-white border-emerald-500 shadow-sm'
                : 'bg-slate-900 text-emerald-400 border-slate-800'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            I CAN HELP ({navaHelpListings.filter((h) => h.type === 'can_help').length})
          </button>
          <button
            onClick={() => setActiveFilter('need_help')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
              activeFilter === 'need_help'
                ? 'bg-amber-600 text-white border-amber-500 shadow-sm'
                : 'bg-slate-900 text-amber-400 border-slate-800'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            I NEED HELP ({navaHelpListings.filter((h) => h.type === 'need_help').length})
          </button>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search skills, domains, questions..."
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500"
          />
        </div>
      </div>

      {/* Help Exchange Listings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredListings.map((item) => {
          const isOfferingHelp = item.type === 'can_help';
          return (
            <div
              key={item.id}
              className={`rounded-2xl border p-5 flex flex-col justify-between space-y-4 transition-all duration-200 shadow-lg ${
                isOfferingHelp
                  ? 'bg-slate-900/80 border-emerald-500/30 hover:border-emerald-500/60'
                  : 'bg-slate-900/80 border-amber-500/30 hover:border-amber-500/60'
              }`}
            >
              <div className="space-y-3">
                {/* Header Badge */}
                <div className="flex items-center justify-between gap-2">
                  <span
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-black uppercase tracking-wider border flex items-center gap-1.5 ${
                      isOfferingHelp
                        ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                        : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                    }`}
                  >
                    {isOfferingHelp ? <Zap className="w-3 h-3" /> : <HelpCircle className="w-3 h-3" />}
                    {isOfferingHelp ? 'I CAN HELP' : 'I NEED HELP'}
                  </span>

                  <span className="text-[11px] font-bold text-violet-300 flex items-center gap-1 bg-violet-950/60 px-2.5 py-0.5 rounded-full border border-violet-500/30">
                    <Sparkles className="w-3 h-3 text-amber-400" />
                    {item.matchScorePct}% Match Score
                  </span>
                </div>

                {/* User & Skill Category */}
                <div className="flex items-center gap-3">
                  <img
                    src={item.userAvatar}
                    alt={item.userName}
                    className="w-10 h-10 rounded-full object-cover border border-slate-700 shrink-0"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-bold text-white">{item.userName}</h4>
                      <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        {item.trustScore} Trust
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">{item.skillCategory}</p>
                  </div>
                </div>

                {/* Title & Description */}
                <div className="space-y-1">
                  <h3 className="text-sm font-bold text-white">{item.title}</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">{item.description}</p>
                </div>
              </div>

              {/* Meta & CTA Bar */}
              <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3 text-[11px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-500" />
                    {item.locationName}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-500" />
                    {item.timeCreditsPerHour} Credit/hr
                  </span>
                </div>

                <button
                  onClick={() => requestNavaHelpSession(item.id)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-md ${
                    isOfferingHelp
                      ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/20'
                      : 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-600/20'
                  }`}
                >
                  <span>{isOfferingHelp ? 'Book 1-on-1 Help' : 'Volunteer to Help'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Post Listing Modal */}
      {isPostModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-100/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-lg rounded-2xl bg-slate-900 border border-violet-500/40 p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-lg font-black text-white flex items-center gap-2">
                <Handshake className="w-5 h-5 text-violet-400" />
                Create Help Exchange Listing
              </h3>
              <button
                onClick={() => setIsPostModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handlePostSubmit} className="space-y-4">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setPostType('can_help')}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-bold border transition cursor-pointer flex items-center justify-center gap-1.5 ${
                    postType === 'can_help'
                      ? 'bg-emerald-600 text-white border-emerald-500'
                      : 'bg-white text-slate-400 border-slate-800'
                  }`}
                >
                  <Zap className="w-4 h-4" />
                  I Can Help (Offer Skill)
                </button>
                <button
                  type="button"
                  onClick={() => setPostType('need_help')}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-bold border transition cursor-pointer flex items-center justify-center gap-1.5 ${
                    postType === 'need_help'
                      ? 'bg-amber-600 text-white border-amber-500'
                      : 'bg-white text-slate-400 border-slate-800'
                  }`}
                >
                  <HelpCircle className="w-4 h-4" />
                  I Need Help (Request Skill)
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Skill Topic / Title *</label>
                <input
                  type="text"
                  required
                  placeholder={
                    postType === 'can_help'
                      ? 'e.g. FastAPI Async Architecture & DB Optimization'
                      : 'e.g. Need feedback on System Design for Social Graph'
                  }
                  value={postTitle}
                  onChange={(e) => setPostTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-violet-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Details & Context *</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Explain what specific challenges will be discussed or how you can assist teammates..."
                  value={postDesc}
                  onChange={(e) => setPostDesc(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-violet-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Skill Category</label>
                  <select
                    value={postCategory}
                    onChange={(e) => setPostCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-violet-500"
                  >
                    <option value="Technology & Engineering">Technology & Engineering</option>
                    <option value="Product & Design">Product & Design</option>
                    <option value="Growth & Marketing">Growth & Marketing</option>
                    <option value="Career & Mentorship">Career & Mentorship</option>
                    <option value="Community Impact">Community Impact</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Time Credits / Hr</label>
                  <input
                    type="number"
                    min={1}
                    max={5}
                    value={postCredits}
                    onChange={(e) => setPostCredits(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-violet-500"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsPostModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-xs font-bold text-slate-300 hover:bg-slate-700 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-xs font-bold text-white shadow-lg shadow-violet-600/30 transition cursor-pointer"
                >
                  Publish Listing
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
