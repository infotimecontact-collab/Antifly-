import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { NavaProofOfProgress } from '../../types';
import {
  TrendingUp,
  Plus,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  Handshake,
  Users,
  Sparkles,
  Award,
  Heart,
  MessageCircle,
  HelpCircle,
  BookOpen,
  AlertTriangle,
  ArrowRight,
  Shield,
  Info,
} from 'lucide-react';

export const NavaProofTimelineTab: React.FC = () => {
  const {
    navaProofs,
    postNavaProof,
    reactToNavaProof,
    navaMissions,
    navaIdentityMode,
    showToast,
  } = useApp();

  const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);
  const [selectedMissionId, setSelectedMissionId] = useState<string>(navaMissions?.[0]?.id || '');
  const [milestoneTitle, setMilestoneTitle] = useState('');
  const [accomplished, setAccomplished] = useState('');
  const [learned, setLearned] = useState('');
  const [difficult, setDifficult] = useState('');
  const [nextStep, setNextStep] = useState('');
  const [proofUrl, setProofUrl] = useState('');
  const [proofType, setProofType] = useState<
    'project_repo' | 'certificate' | 'live_demo' | 'screenshot' | 'document' | 'video'
  >('project_repo');

  const handlePublishSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accomplished.trim() || !learned.trim()) {
      showToast('Please answer what you accomplished and what you learned.');
      return;
    }

    const mission = navaMissions.find((m) => m.id === selectedMissionId);

    postNavaProof({
      missionId: selectedMissionId,
      missionTitle: mission ? mission.title : 'Active Community Mission',
      milestoneTitle: milestoneTitle || 'Sprint Milestone',
      accomplished: accomplished.trim(),
      learned: learned.trim(),
      difficult: difficult.trim() || 'Balancing technical complexity with performance targets.',
      nextStep: nextStep.trim() || 'Deploy next iteration and gather peer feedback.',
      proofUrl: proofUrl.trim() || 'https://github.com/nava-missions/proof',
      proofType,
    });

    setIsPublishModalOpen(false);
    setMilestoneTitle('');
    setAccomplished('');
    setLearned('');
    setDifficult('');
    setNextStep('');
    setProofUrl('');
  };

  return (
    <div className="space-y-6">
      {/* Header & Publishing CTA */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Proof of Progress
            </span>
            <span className="text-xs text-slate-400">No Vanity Likes • Real Accomplishments</span>
          </div>
          <h2 className="text-xl font-black text-white">Don’t Tell People. Prove Your Progress.</h2>
          <p className="text-xs text-slate-300 max-w-2xl">
            Every update is structured around real deliverables, reflection, and peer validation.
            Reactions signify real collaboration, not dopamine clicks.
          </p>
        </div>

        <button
          onClick={() => setIsPublishModalOpen(true)}
          className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/30 transition flex items-center gap-2 cursor-pointer self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          Publish Proof of Progress
        </button>
      </div>

      {/* Proof Feed Timeline */}
      <div className="space-y-6">
        {navaProofs.map((proof) => {
          return (
            <div
              key={proof.id}
              className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-5 shadow-xl hover:border-slate-700 transition"
            >
              {/* Top User & Mission Meta */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <img
                    src={proof.userAvatar}
                    alt={proof.userName}
                    className="w-11 h-11 rounded-full object-cover border border-slate-700 shrink-0"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-white">{proof.userName}</h4>
                      <span className="px-2 py-0.2 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3 text-emerald-400" />
                        {proof.userTrustScore} Trust
                      </span>
                    </div>
                    <p className="text-xs text-indigo-400 font-medium">{proof.missionTitle}</p>
                    <p className="text-[11px] text-slate-500">{proof.timestamp}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-auto">
                  <span className="px-3 py-1 rounded-xl bg-white border border-slate-800 text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5 text-amber-400" />
                    {proof.milestoneTitle}
                  </span>
                </div>
              </div>

              {/* Structured 4-Question Accomplishment Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                <div className="p-4 rounded-xl bg-white border border-slate-800/80 space-y-1">
                  <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    1. What was accomplished?
                  </span>
                  <p className="text-xs text-slate-200 leading-relaxed">{proof.accomplished}</p>
                </div>

                <div className="p-4 rounded-xl bg-white border border-slate-800/80 space-y-1">
                  <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5" />
                    2. What did you learn?
                  </span>
                  <p className="text-xs text-slate-200 leading-relaxed">{proof.learned}</p>
                </div>

                <div className="p-4 rounded-xl bg-white border border-slate-800/80 space-y-1">
                  <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    3. What was difficult / blocker?
                  </span>
                  <p className="text-xs text-slate-200 leading-relaxed">{proof.difficult}</p>
                </div>

                <div className="p-4 rounded-xl bg-white border border-slate-800/80 space-y-1">
                  <span className="text-[11px] font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                    <ArrowRight className="w-3.5 h-3.5" />
                    4. What is the immediate next step?
                  </span>
                  <p className="text-xs text-slate-200 leading-relaxed">{proof.nextStep}</p>
                </div>
              </div>

              {/* Verifiable Link / Attachment */}
              {proof.proofUrl && (
                <div className="p-3 rounded-xl bg-indigo-950/30 border border-indigo-500/30 flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2 text-indigo-200 truncate">
                    <ExternalLink className="w-4 h-4 text-indigo-400 shrink-0" />
                    <span className="font-semibold text-white">Verifiable Artifact:</span>
                    <span className="text-indigo-300 truncate">{proof.proofUrl}</span>
                  </div>
                  <a
                    href={proof.proofUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 font-bold text-white text-xs shrink-0 flex items-center gap-1"
                  >
                    <span>Inspect Code / Proof</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}

              {/* Peer Verifications Signoff */}
              <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                <span className="flex items-center gap-1.5 text-[11px]">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  Peer Verified by: <strong className="text-slate-300">{proof.verifiedByPeers.join(', ')}</strong>
                </span>
                <span className="text-[11px] text-slate-500">
                  {proof.peerVerificationsCount} peer confirmations
                </span>
              </div>

              {/* NO-LIKE PURPOSEFUL ACTIONS BAR */}
              <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center gap-2">
                {/* 1. Helped Me */}
                <button
                  onClick={() => reactToNavaProof(proof.id, 'helpedMe')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                    proof.userReactions?.helpedMe
                      ? 'bg-violet-500/20 text-violet-300 border-violet-500/40 shadow-sm'
                      : 'bg-white hover:bg-slate-800 text-slate-400 border-slate-800'
                  }`}
                >
                  <Handshake className="w-3.5 h-3.5 text-violet-400" />
                  <span>Helped Me ({proof.meaningfulReactions.helpedMe})</span>
                </button>

                {/* 2. Verify Progress */}
                <button
                  onClick={() => reactToNavaProof(proof.id, 'verifyProgress')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                    proof.userReactions?.verifyProgress
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-sm'
                      : 'bg-white hover:bg-slate-800 text-slate-400 border-slate-800'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Verify Progress ({proof.meaningfulReactions.verifyProgress})</span>
                </button>

                {/* 3. Collaborate */}
                <button
                  onClick={() => reactToNavaProof(proof.id, 'collaborate')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                    proof.userReactions?.collaborate
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shadow-sm'
                      : 'bg-white hover:bg-slate-800 text-slate-400 border-slate-800'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Collaborate ({proof.meaningfulReactions.collaborate})</span>
                </button>

                {/* 4. Join Mission */}
                <button
                  onClick={() => reactToNavaProof(proof.id, 'joinMission')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                    proof.userReactions?.joinMission
                      ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40 shadow-sm'
                      : 'bg-white hover:bg-slate-800 text-slate-400 border-slate-800'
                  }`}
                >
                  <Users className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Join Mission ({proof.meaningfulReactions.joinMission})</span>
                </button>

                {/* 5. Support */}
                <button
                  onClick={() => reactToNavaProof(proof.id, 'support')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                    proof.userReactions?.support
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 shadow-sm'
                      : 'bg-white hover:bg-slate-800 text-slate-400 border-slate-800'
                  }`}
                >
                  <Heart className="w-3.5 h-3.5 text-rose-400" />
                  <span>Support ({proof.meaningfulReactions.support})</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Publish Proof Modal */}
      {isPublishModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-100/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-2xl rounded-2xl bg-slate-900 border border-emerald-500/40 p-6 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="space-y-0.5">
                <h3 className="text-lg font-black text-white flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-emerald-400" />
                  Publish Proof of Progress Update
                </h3>
                <p className="text-xs text-slate-400">
                  Reflect on your milestone, share learnings, and attach verifiable evidence.
                </p>
              </div>
              <button
                onClick={() => setIsPublishModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handlePublishSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Select Mission</label>
                  <select
                    value={selectedMissionId}
                    onChange={(e) => setSelectedMissionId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-emerald-500"
                  >
                    {navaMissions.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.title}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Milestone Title *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Milestone 2: FastAPI + Docker Container"
                    value={milestoneTitle}
                    onChange={(e) => setMilestoneTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-emerald-400 mb-1">
                  1. What did you accomplish? *
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="Concrete deliverable shipped, PR merged, trees planted, prototype demoed..."
                  value={accomplished}
                  onChange={(e) => setAccomplished(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-cyan-400 mb-1">
                  2. What did you learn? *
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="New insight, architectural pattern, or lesson discovered during the sprint..."
                  value={learned}
                  onChange={(e) => setLearned(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-amber-400 mb-1">
                    3. What was difficult / blocker?
                  </label>
                  <textarea
                    rows={2}
                    placeholder="What took the most debugging time or friction?"
                    value={difficult}
                    onChange={(e) => setDifficult(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-indigo-400 mb-1">
                    4. What is your next step?
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Immediate task scheduled for the upcoming sprint?"
                    value={nextStep}
                    onChange={(e) => setNextStep(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Artifact / Repo URL
                  </label>
                  <input
                    type="url"
                    placeholder="https://github.com/... or live demo link"
                    value={proofUrl}
                    onChange={(e) => setProofUrl(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Artifact Type</label>
                  <select
                    value={proofType}
                    onChange={(e) => setProofType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="project_repo">Project Code Repo</option>
                    <option value="live_demo">Live Demo</option>
                    <option value="certificate">Verified Certificate</option>
                    <option value="document">Report / Doc</option>
                    <option value="screenshot">Screenshot / Graphic</option>
                  </select>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsPublishModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-xs font-bold text-slate-300 hover:bg-slate-700 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white shadow-lg shadow-emerald-600/30 transition cursor-pointer"
                >
                  Publish Proof to Network
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
