import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Share2,
  Users,
  Target,
  Code2,
  Sparkles,
  ArrowRight,
  Shield,
  Layers,
  Search,
} from 'lucide-react';

export const NavaGoalGraphTab: React.FC = () => {
  const { setNavaActiveTab, showToast } = useApp();
  const [selectedNode, setSelectedNode] = useState<string>('goal-1');
  const [filterType, setFilterType] = useState<string>('ALL');

  const nodes = [
    {
      id: 'you',
      label: 'You (Jatin)',
      type: 'user',
      category: 'Me',
      color: 'bg-indigo-600 text-white border-indigo-400',
      x: 50,
      y: 50,
      details: 'Full Stack & AI Engineer pursuing 3 active missions.',
    },
    {
      id: 'goal-1',
      label: 'Generative AI Developer',
      type: 'goal',
      category: 'Goal',
      color: 'bg-cyan-600 text-white border-cyan-400',
      x: 25,
      y: 25,
      details: 'Targeting production mastery in LLMs, RAG, and FastAPI microservices.',
    },
    {
      id: 'goal-2',
      label: 'SaaS Bootstrapper',
      type: 'goal',
      category: 'Goal',
      color: 'bg-amber-600 text-white border-amber-400',
      x: 75,
      y: 25,
      details: 'Launching profitable micro-tools and community ecosystems.',
    },
    {
      id: 'skill-python',
      label: 'Python / AsyncIO',
      type: 'skill',
      category: 'Skill',
      color: 'bg-emerald-600 text-white border-emerald-400',
      x: 15,
      y: 55,
      details: 'High proficiency in asynchronous Python architectures and memory management.',
    },
    {
      id: 'skill-react',
      label: 'React & UI Architecture',
      type: 'skill',
      category: 'Skill',
      color: 'bg-blue-600 text-white border-blue-400',
      x: 85,
      y: 55,
      details: 'Component state modeling, motion transitions, and design systems.',
    },
    {
      id: 'mission-algo',
      label: 'Mission: Quant Trading Bot',
      type: 'mission',
      category: 'Mission',
      color: 'bg-rose-600 text-white border-rose-400',
      x: 30,
      y: 80,
      details: '60-Day sprint with 18 builders testing risk-adjusted backtests.',
    },
    {
      id: 'peer-rohit',
      label: 'Rohit Verma (98 Trust)',
      type: 'peer',
      category: 'Teammate',
      color: 'bg-violet-600 text-white border-violet-400',
      x: 70,
      y: 80,
      details: 'Matched on Python + VectorDB goals. Available on Help Exchange.',
    },
  ];

  const activeNode = nodes.find((n) => n.id === selectedNode) || nodes?.[0] || null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border border-indigo-500/30 p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1.5 max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              NAVA Goal Graph
            </span>
            <span className="text-xs text-slate-400">Semantic Relational Discovery</span>
          </div>
          <h2 className="text-xl md:text-2xl font-black text-white">
            Connect Goals, Skills, Teammates & Missions.
          </h2>
          <p className="text-xs text-slate-300">
            Instead of an arbitrary social graph of "who follows whom", NAVA constructs a living
            Goal Graph connecting what you aim to build with who has the missing puzzle pieces.
          </p>
        </div>

        <button
          onClick={() => {
            setNavaActiveTab('missions');
            showToast('Opening matched Missions from your Goal Graph...');
          }}
          className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition flex items-center gap-2 cursor-pointer shrink-0"
        >
          <Target className="w-4 h-4" />
          Explore Matched Missions
        </button>
      </div>

      {/* Interactive Graph Canvas Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Visual Graph Viewport */}
        <div className="lg:col-span-8 rounded-2xl bg-white border border-slate-800 p-6 relative min-h-[420px] flex flex-col justify-between overflow-hidden shadow-2xl">
          {/* Subtle Grid Background Pattern */}
          <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#6366f1_1px,transparent_1px)] [background-size:16px_16px]" />

          {/* Connected SVG lines connecting center node to peripheral nodes */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none stroke-indigo-500/30 stroke-2 stroke-dasharray-4">
            <line x1="50%" y1="50%" x2="25%" y2="25%" />
            <line x1="50%" y1="50%" x2="75%" y2="25%" />
            <line x1="50%" y1="50%" x2="15%" y2="55%" />
            <line x1="50%" y1="50%" x2="85%" y2="55%" />
            <line x1="50%" y1="50%" x2="30%" y2="80%" />
            <line x1="50%" y1="50%" x2="70%" y2="80%" />
          </svg>

          {/* Interactive Nodes */}
          <div className="relative z-10 w-full h-full min-h-[360px]">
            {nodes.map((node) => {
              const isSelected = selectedNode === node.id;
              return (
                <button
                  key={node.id}
                  onClick={() => setSelectedNode(node.id)}
                  style={{ left: `${node.x}%`, top: `${node.y}%` }}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 px-3.5 py-2 rounded-2xl text-xs font-bold transition-all duration-200 cursor-pointer shadow-lg border flex items-center gap-1.5 whitespace-nowrap ${
                    node.color
                  } ${
                    isSelected
                      ? 'scale-115 ring-4 ring-white/50 z-30 shadow-indigo-500/50'
                      : 'hover:scale-105 z-20 opacity-90 hover:opacity-100'
                  }`}
                >
                  {node.type === 'user' && <Users className="w-3.5 h-3.5" />}
                  {node.type === 'goal' && <Target className="w-3.5 h-3.5" />}
                  {node.type === 'skill' && <Code2 className="w-3.5 h-3.5" />}
                  {node.type === 'mission' && <Layers className="w-3.5 h-3.5" />}
                  {node.type === 'peer' && <Sparkles className="w-3.5 h-3.5" />}
                  <span>{node.label}</span>
                </button>
              );
            })}
          </div>

          <div className="relative z-10 flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-800">
            <span>Click any node to inspect semantic relationships</span>
            <span className="text-indigo-400 font-medium">Goal Graph Engine v2.4 Active</span>
          </div>
        </div>

        {/* Selected Node Details Card */}
        <div className="lg:col-span-4 rounded-2xl bg-slate-900 border border-slate-800 p-6 flex flex-col justify-between space-y-4 shadow-xl">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                {activeNode.category} Node
              </span>
              <span className="text-[11px] text-slate-500 font-mono">ID: {activeNode.id}</span>
            </div>

            <h3 className="text-lg font-black text-white">{activeNode.label}</h3>
            <p className="text-xs text-slate-300 leading-relaxed">{activeNode.details}</p>

            <div className="p-3.5 rounded-xl bg-white border border-slate-800 space-y-2">
              <h5 className="text-xs font-bold text-slate-300">Semantic Graph Connections:</h5>
              <ul className="text-[11px] text-slate-400 space-y-1">
                <li>• <strong>3 Active Teammates</strong> currently pursuing this node</li>
                <li>• <strong>2 Circle Rooms</strong> running live voice sprints</li>
                <li>• <strong>5 Help Exchange Listings</strong> offering guidance</li>
              </ul>
            </div>
          </div>

          <button
            onClick={() => {
              if (activeNode.type === 'peer') setNavaActiveTab('help');
              else if (activeNode.type === 'mission') setNavaActiveTab('missions');
              else setNavaActiveTab('circles');
            }}
            className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/30 transition flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span>Interact With {activeNode.category}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
