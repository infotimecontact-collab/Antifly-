import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  CheckCircle2,
  Calendar,
  Send,
  Bot,
  User,
  ArrowRight,
  BookOpen,
  Users,
  Clock,
  Target,
  Zap,
  RotateCcw,
} from 'lucide-react';

export const NavaAICoachTab: React.FC = () => {
  const {
    navaAICoachRoadmap,
    toggleNavaAICoachTask,
    setNavaActiveTab,
    showToast,
  } = useApp();

  const [coachPrompt, setCoachPrompt] = useState('');
  const [messages, setMessages] = useState<Array<{ sender: 'ai' | 'user'; text: string; time: string }>>([
    {
      sender: 'ai',
      text: `Hello Jatin! I'm your NAVA AI Mission Coach. I'm currently tracking your 90-day goal: "${navaAICoachRoadmap.userGoal}". You are 28% of the way through your roadmap. How can I assist your sprint today?`,
      time: '10:00 AM',
    },
  ]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!coachPrompt.trim()) return;

    const userText = coachPrompt.trim();
    const newMsg = {
      sender: 'user' as const,
      text: userText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, newMsg]);
    setCoachPrompt('');

    // Synthetic Coach Response based on NAVA AI logic
    setTimeout(() => {
      let aiReply = `Great progress! Based on your target "${navaAICoachRoadmap.userGoal}", I recommend focusing on Dockerizing your async FastAPI pipeline today. I've matched 2 teammates in your Indore circle who have solved similar Celery/Postgres bottlenecks.`;
      if (userText.toLowerCase().includes('help') || userText.toLowerCase().includes('stuck')) {
        aiReply = `I see you're facing a blocker! Let's break it down into 3 smaller micro-tasks: 1) Verify schema migrations, 2) Test query execution plan with EXPLAIN ANALYZE, 3) Open a 1-on-1 session on Help Exchange.`;
      } else if (userText.toLowerCase().includes('roadmap') || userText.toLowerCase().includes('plan')) {
        aiReply = `I've refreshed your 90-day sprint milestones. Week 3 focuses on Docker + Vector DB indexing. Completing these 3 tasks will add +2 to your Skill Evidence score!`;
      }

      setMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: aiReply,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    }, 600);
  };

  const weeklyRoadmap = navaAICoachRoadmap?.weeklyRoadmap || [];
  const recommendedTeammates = navaAICoachRoadmap?.recommendedTeammates || [];
  const userGoal = navaAICoachRoadmap?.userGoal || 'Become a Senior Full-Stack AI Engineer';
  const targetDurationDays = navaAICoachRoadmap?.targetDurationDays || 90;

  const totalTasks = weeklyRoadmap.reduce(
    (acc, wk) => acc + (wk.tasks?.length || 0),
    0
  );
  const completedTasks = weeklyRoadmap.reduce(
    (acc, wk) => acc + (wk.tasks?.filter((t) => t.isCompleted)?.length || 0),
    0
  );
  const progressPct = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* AI Coach Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-900 border border-indigo-500/30 p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1.5 max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              AI Mission Coach
            </span>
            <span className="text-xs text-slate-400">90-Day Adaptive Goal Architecture</span>
          </div>
          <h2 className="text-xl md:text-2xl font-black text-white">
            Turn Vague Dreams Into Daily Execution.
          </h2>
          <p className="text-xs text-slate-300">
            Current Focus: <strong className="text-indigo-300">{userGoal}</strong> ({targetDurationDays} Days Sprint).
          </p>
        </div>

        <div className="p-4 rounded-xl bg-white/80 border border-slate-800 space-y-1.5 shrink-0 min-w-44 text-right">
          <div className="flex justify-between text-xs font-bold text-slate-300">
            <span>Overall Sprints</span>
            <span className="text-emerald-400">{progressPct}%</span>
          </div>
          <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 rounded-full transition-all duration-300"
              style={{ width: `${progressPct}%` }}
            />
          </div>
          <p className="text-[10px] text-slate-400">
            {completedTasks} of {totalTasks} roadmap tasks verified
          </p>
        </div>
      </div>

      {/* Two Column Layout: Interactive AI Dialogue & 90-Day Sprints */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: AI Coach Conversation Terminal */}
        <div className="lg:col-span-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col h-[520px] shadow-xl overflow-hidden">
          <div className="p-4 border-b border-slate-800 bg-white flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-indigo-600 flex items-center justify-center text-white">
                <Bot className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">NAVA AI Coach Assistant</h4>
                <p className="text-[10px] text-emerald-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Active Goal Co-pilot
                </p>
              </div>
            </div>

            <button
              onClick={() => showToast('Roadmap synced with latest weekly progress.')}
              className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 text-xs cursor-pointer"
              title="Sync Roadmap"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Messages Container */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3.5">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`flex items-start gap-2.5 ${
                  m.sender === 'user' ? 'flex-row-reverse' : ''
                }`}
              >
                <div
                  className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs shrink-0 mt-0.5 ${
                    m.sender === 'user'
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-800 text-amber-300 border border-slate-700'
                  }`}
                >
                  {m.sender === 'user' ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
                </div>

                <div
                  className={`p-3 rounded-2xl max-w-[82%] text-xs space-y-1 ${
                    m.sender === 'user'
                      ? 'bg-indigo-600 text-white rounded-tr-none'
                      : 'bg-white text-slate-200 border border-slate-800 rounded-tl-none leading-relaxed'
                  }`}
                >
                  <p>{m.text}</p>
                  <span
                    className={`text-[9px] block text-right ${
                      m.sender === 'user' ? 'text-indigo-200' : 'text-slate-500'
                    }`}
                  >
                    {m.time}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Prompt Input Form */}
          <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-800 bg-white flex items-center gap-2">
            <input
              type="text"
              value={coachPrompt}
              onChange={(e) => setCoachPrompt(e.target.value)}
              placeholder="Ask your coach: 'How to build week 3 sprint?', 'Find teammates'..."
              className="flex-1 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
            <button
              type="submit"
              className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold transition cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>

        {/* Right Column: Weekly Breakdown & Check-off Tasks */}
        <div className="lg:col-span-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-indigo-400" />
              90-Day Weekly Roadmaps & Sprints
            </h3>
            <span className="text-xs text-slate-400">Click task to toggle proof</span>
          </div>

          <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1">
            {weeklyRoadmap.map((week) => (
              <div
                key={week.weekNumber}
                className={`rounded-2xl p-4 border transition ${
                  week.isCompleted
                    ? 'bg-emerald-950/20 border-emerald-500/30'
                    : 'bg-slate-900 border-slate-800'
                }`}
              >
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase ${
                        week.isCompleted
                          ? 'bg-emerald-500 text-slate-800'
                          : 'bg-indigo-500/20 text-indigo-300'
                      }`}
                    >
                      Week {week.weekNumber}
                    </span>
                    <h4 className="text-xs font-bold text-white">{week.title}</h4>
                  </div>
                  <span className="text-[11px] text-slate-400 font-medium">{week.weekRange}</span>
                </div>

                {/* Tasks List */}
                <div className="space-y-2 pt-3">
                  {(week.tasks || []).map((task) => (
                    <div
                      key={task.id}
                      onClick={() => toggleNavaAICoachTask(task.id)}
                      className="p-2.5 rounded-xl bg-white/80 hover:bg-white border border-slate-800/80 flex items-center justify-between gap-3 cursor-pointer transition"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <button
                          type="button"
                          className={`w-4 h-4 rounded-md flex items-center justify-center text-[10px] shrink-0 border transition ${
                            task.isCompleted
                              ? 'bg-emerald-500 text-slate-800 border-emerald-500'
                              : 'border-slate-700 bg-slate-900'
                          }`}
                        >
                          {task.isCompleted ? '✓' : ''}
                        </button>
                        <span
                          className={`text-xs truncate ${
                            task.isCompleted
                              ? 'text-slate-500 line-through'
                              : 'text-slate-200 font-medium'
                          }`}
                        >
                          {task.title}
                        </span>
                      </div>

                      <span className="text-[10px] text-indigo-400 shrink-0 font-medium">
                        Milestone
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Recommended Teammates Matched by Coach */}
          <div className="p-4 rounded-2xl bg-indigo-950/30 border border-indigo-500/30 space-y-3">
            <h4 className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
              <Users className="w-4 h-4 text-indigo-400" />
              Teammates Matched for Your Goal
            </h4>
            <div className="grid grid-cols-2 gap-2">
              {recommendedTeammates.map((mate) => (
                <div
                  key={mate.name}
                  className="p-2.5 rounded-xl bg-white border border-slate-800 flex items-center gap-2.5"
                >
                  <img
                    src={mate.avatar}
                    alt={mate.name}
                    className="w-7 h-7 rounded-full object-cover shrink-0"
                  />
                  <div className="min-w-0">
                    <p className="text-[11px] font-bold text-white truncate">{mate.name}</p>
                    <p className="text-[10px] text-indigo-400 truncate">{mate.role}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
