import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { NavaCircle } from '../../types';
import {
  Users,
  Radio,
  Send,
  CheckCircle2,
  Clock,
  Shield,
  HelpCircle,
  Sparkles,
  MessageSquare,
  Plus,
  Mic,
  MicOff,
  Volume2,
  AlertCircle,
  Kanban,
} from 'lucide-react';

export const NavaCirclesTab: React.FC = () => {
  const {
    navaCircles,
    sendNavaCircleMessage,
    navaIdentityMode,
    showToast,
  } = useApp();

  const [activeCircleId, setActiveCircleId] = useState<string>(navaCircles?.[0]?.id || '');
  const [chatInput, setChatInput] = useState('');
  const [isHelpRequestMode, setIsHelpRequestMode] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<'board' | 'chat' | 'members'>('board');
  const [isVoiceMuted, setIsVoiceMuted] = useState(false);
  const [isVoiceConnected, setIsVoiceConnected] = useState(false);

  const activeCircle = (navaCircles || []).find((c) => c.id === activeCircleId) || navaCircles?.[0];

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !activeCircle) return;
    sendNavaCircleMessage(activeCircle.id, chatInput.trim(), isHelpRequestMode);
    setChatInput('');
    if (isHelpRequestMode) {
      showToast('🤝 Help request broadcasted to Circle teammates!');
      setIsHelpRequestMode(false);
    }
  };

  const handleToggleVoice = () => {
    if (!isVoiceConnected) {
      setIsVoiceConnected(true);
      showToast('🎙️ Connected to Circle Live Voice Sprint Room!');
    } else {
      setIsVoiceConnected(false);
      showToast('Disconnected from Voice Sprint.');
    }
  };

  if (!activeCircle) {
    return (
      <div className="p-8 text-center text-slate-400 bg-slate-900 rounded-2xl border border-slate-800">
        No active mission circles found. Join a mission to unlock your circle!
      </div>
    );
  }

  const todoTasks = (activeCircle.tasksBoard || []).filter((t) => t.status === 'todo');
  const inProgressTasks = (activeCircle.tasksBoard || []).filter((t) => t.status === 'in_progress');
  const doneTasks = (activeCircle.tasksBoard || []).filter((t) => t.status === 'done');

  return (
    <div className="space-y-6">
      {/* Circle Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {(navaCircles || []).map((circle) => {
          const isSelected = circle.id === activeCircleId;
          return (
            <button
              key={circle.id}
              onClick={() => setActiveCircleId(circle.id)}
              className={`px-4 py-2.5 rounded-xl font-bold text-xs whitespace-nowrap transition flex items-center gap-2 cursor-pointer border ${
                isSelected
                  ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/30'
                  : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>{circle.name}</span>
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-white/60 text-indigo-300">
                {circle.memberCount || (circle.members || []).length} members
              </span>
              {circle.isVoiceRoomLive && (
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              )}
            </button>
          );
        })}
      </div>

      {/* Main Circle Canvas */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
        {/* Circle Header & Live Voice Room Widget */}
        <div className="p-5 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border-b border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-black text-white">{activeCircle.name}</h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                {activeCircle.privacy} Circle
              </span>
            </div>
            <p className="text-xs text-slate-300">{activeCircle.description}</p>
            <p className="text-[11px] text-amber-400 font-medium">
              🎯 Active Objective: {activeCircle.activeGoal}
            </p>
          </div>

          {/* Live Voice Sprint Controls */}
          <div className="flex items-center gap-2 p-2.5 rounded-xl bg-white border border-slate-800 shrink-0">
            <div className="flex items-center gap-2 px-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
              <div className="text-left">
                <p className="text-[11px] font-bold text-white leading-tight">Live Voice Room</p>
                <p className="text-[10px] text-slate-400">
                  {isVoiceConnected ? 'Connected (7 Teammates)' : '7 active in room'}
                </p>
              </div>
            </div>

            <button
              onClick={handleToggleVoice}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                isVoiceConnected
                  ? 'bg-rose-500 hover:bg-rose-600 text-white'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm'
              }`}
            >
              {isVoiceConnected ? (
                <>
                  <Radio className="w-3.5 h-3.5" />
                  Leave Room
                </>
              ) : (
                <>
                  <Radio className="w-3.5 h-3.5" />
                  Join Voice Sprint
                </>
              )}
            </button>

            {isVoiceConnected && (
              <button
                onClick={() => setIsVoiceMuted(!isVoiceMuted)}
                className={`p-1.5 rounded-lg border text-xs cursor-pointer ${
                  isVoiceMuted
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    : 'bg-slate-800 text-slate-300 border-slate-700'
                }`}
              >
                {isVoiceMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
              </button>
            )}
          </div>
        </div>

        {/* Sub-Navigation Switcher */}
        <div className="px-5 pt-3 border-b border-slate-800 flex items-center gap-4 text-xs font-bold">
          <button
            onClick={() => setActiveSubTab('board')}
            className={`pb-3 flex items-center gap-1.5 cursor-pointer border-b-2 transition ${
              activeSubTab === 'board'
                ? 'border-indigo-500 text-indigo-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Kanban className="w-4 h-4" />
            Sprint Tasks Board ({activeCircle?.tasksBoard?.length || 0})
          </button>
          <button
            onClick={() => setActiveSubTab('chat')}
            className={`pb-3 flex items-center gap-1.5 cursor-pointer border-b-2 transition ${
              activeSubTab === 'chat'
                ? 'border-indigo-500 text-indigo-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            Circle Discussions & Help ({activeCircle?.recentMessages?.length || 0})
          </button>
          <button
            onClick={() => setActiveSubTab('members')}
            className={`pb-3 flex items-center gap-1.5 cursor-pointer border-b-2 transition ${
              activeSubTab === 'members'
                ? 'border-indigo-500 text-indigo-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="w-4 h-4" />
            Member Roster ({activeCircle?.members?.length || 0})
          </button>
        </div>

        {/* TAB 1: Tasks Kanban Board */}
        {activeSubTab === 'board' && (
          <div className="p-5 grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Todo Column */}
            <div className="rounded-xl bg-white p-4 border border-slate-800/80 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-slate-500" />
                  To Do ({todoTasks.length})
                </span>
              </div>
              <div className="space-y-2.5">
                {todoTasks.map((t) => (
                  <div
                    key={t.id}
                    className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-2 hover:border-slate-700 transition"
                  >
                    <p className="text-xs font-semibold text-slate-200">{t.title}</p>
                    <div className="flex items-center justify-between text-[10px] text-slate-400">
                      <span className="font-medium text-indigo-400">@{t.assignedToName}</span>
                      <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                        {t.priority}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* In Progress Column */}
            <div className="rounded-xl bg-white p-4 border border-slate-800/80 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Radio className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
                  In Progress ({inProgressTasks.length})
                </span>
              </div>
              <div className="space-y-2.5">
                {inProgressTasks.map((t) => (
                  <div
                    key={t.id}
                    className="p-3 rounded-lg bg-slate-900 border border-indigo-500/30 space-y-2 hover:border-indigo-500/50 transition shadow-sm"
                  >
                    <p className="text-xs font-semibold text-white">{t.title}</p>
                    <div className="flex items-center justify-between text-[10px] text-slate-400">
                      <span className="font-medium text-indigo-300">@{t.assignedToName}</span>
                      <span className="px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold">
                        Active Sprint
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Done Column */}
            <div className="rounded-xl bg-white p-4 border border-slate-800/80 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  Completed ({doneTasks.length})
                </span>
              </div>
              <div className="space-y-2.5">
                {doneTasks.map((t) => (
                  <div
                    key={t.id}
                    className="p-3 rounded-lg bg-slate-900/60 border border-emerald-500/20 space-y-2"
                  >
                    <p className="text-xs font-semibold text-slate-300 line-through">{t.title}</p>
                    <div className="flex items-center justify-between text-[10px] text-emerald-400 font-medium">
                      <span>@{t.assignedToName}</span>
                      <span>Verified ✓</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: Circle Chat with Help Signal */}
        {activeSubTab === 'chat' && (
          <div className="p-5 space-y-4">
            <div className="space-y-3 max-h-80 overflow-y-auto pr-2">
              {activeCircle.recentMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`p-3.5 rounded-xl border flex items-start gap-3 ${
                    msg.isHelpRequest
                      ? 'bg-amber-950/30 border-amber-500/40 text-amber-200'
                      : 'bg-white border-slate-800 text-slate-200'
                  }`}
                >
                  <img
                    src={msg.senderAvatar}
                    alt={msg.senderName}
                    className="w-8 h-8 rounded-full object-cover border border-slate-700 shrink-0 mt-0.5"
                  />
                  <div className="space-y-1 flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{msg.senderName}</span>
                        {msg.isHelpRequest && (
                          <span className="px-2 py-0.2 rounded text-[10px] font-black uppercase bg-amber-500 text-slate-800">
                            Help Request 🚨
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-500">{msg.timestamp}</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{msg.text}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Message Input with "I Need Help" Flag Toggle */}
            <form onSubmit={handleSendMessage} className="space-y-2 pt-2 border-t border-slate-800">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsHelpRequestMode(!isHelpRequestMode)}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer border ${
                    isHelpRequestMode
                      ? 'bg-amber-500 text-slate-800 border-amber-400'
                      : 'bg-slate-800 text-slate-400 hover:text-white border-slate-700'
                  }`}
                >
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>Flag as Help Request</span>
                </button>
                <span className="text-[11px] text-slate-500">
                  {isHelpRequestMode ? 'Will notify matched teammates instantly' : 'Normal message'}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder={
                    isHelpRequestMode
                      ? 'Explain what you are stuck on (e.g. Postgres deadlock in async worker)...'
                      : 'Share an update, snippet, or coordinate with teammates...'
                  }
                  className="flex-1 px-4 py-2.5 rounded-xl bg-white border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="submit"
                  className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/30 transition flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* TAB 3: Member Roster & Trust Scores */}
        {activeSubTab === 'members' && (
          <div className="p-5 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {(activeCircle.members || []).map((member) => (
              <div
                key={member.id}
                className="p-3.5 rounded-xl bg-white border border-slate-800 flex items-center gap-3"
              >
                <img
                  src={member.avatar}
                  alt={member.name}
                  className="w-10 h-10 rounded-full object-cover border border-slate-700 shrink-0"
                />
                <div className="space-y-0.5 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <h5 className="text-xs font-bold text-white truncate">{member.name}</h5>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase bg-indigo-500/20 text-indigo-300">
                      {member.role}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 truncate">{member.speciality}</p>
                  <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1">
                    <Shield className="w-2.5 h-2.5" />
                    {member.trustScore} Trust Score
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
