import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Clock,
  ArrowDownLeft,
  ArrowUpRight,
  ShieldCheck,
  Zap,
  Handshake,
  Calendar,
  Info,
  Gift,
  Coins,
} from 'lucide-react';

export const NavaTimeWalletTab: React.FC = () => {
  const { navaTimeWallet, addNavaTimeCredits, showToast, setNavaActiveTab } = useApp();
  const [claimAmount, setClaimAmount] = useState(1);
  const [claimReason, setClaimReason] = useState('');

  const handleSimulateContribution = () => {
    addNavaTimeCredits(
      1,
      'Peer Mentorship Session: Code Review & System Architecture',
      'Priya Sharma'
    );
    showToast('⏳ Earned +1 Time Credit for conducting a 1-hour verified peer session!');
  };

  return (
    <div className="space-y-6">
      {/* Wallet Balance Hero Card */}
      <div className="rounded-2xl bg-gradient-to-br from-indigo-950 via-slate-900 to-violet-950 border border-indigo-500/30 p-6 md:p-8 shadow-2xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full text-xs font-black uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                NAVA Time Wallet Ledger
              </span>
              <span className="text-xs text-slate-400">1 Hour = 1 Credit • Non-Monetary Trust</span>
            </div>

            <div className="flex items-baseline gap-3 pt-2">
              <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight">
                {navaTimeWallet.availableCredits}
              </h1>
              <span className="text-lg font-bold text-indigo-300">Time Credits Available</span>
            </div>

            <p className="text-xs text-slate-300 max-w-xl leading-relaxed">
              Your time is the most valuable currency on Earth. In NAVA, an hour spent mentoring,
              building, or volunteering creates Time Credits you can exchange for anyone else's time.
            </p>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-2 gap-3 shrink-0">
            <div className="p-4 rounded-xl bg-white/70 border border-slate-800 space-y-1">
              <span className="text-[10px] font-bold text-emerald-400 uppercase flex items-center gap-1">
                <ArrowDownLeft className="w-3.5 h-3.5" />
                Lifetime Earned
              </span>
              <p className="text-xl font-black text-white">{navaTimeWallet.lifetimeEarned} hrs</p>
            </div>

            <div className="p-4 rounded-xl bg-white/70 border border-slate-800 space-y-1">
              <span className="text-[10px] font-bold text-violet-400 uppercase flex items-center gap-1">
                <ArrowUpRight className="w-3.5 h-3.5" />
                Lifetime Redeemed
              </span>
              <p className="text-xl font-black text-white">{navaTimeWallet.lifetimeSpent} hrs</p>
            </div>
          </div>
        </div>

        {/* Quick Actions Bar */}
        <div className="relative z-10 mt-6 pt-5 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setNavaActiveTab('help')}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/30 transition flex items-center gap-1.5 cursor-pointer"
            >
              <Handshake className="w-4 h-4" />
              Find Help Sessions
            </button>
            <button
              onClick={handleSimulateContribution}
              className="px-4 py-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 font-bold text-xs transition flex items-center gap-1.5 cursor-pointer"
            >
              <Zap className="w-4 h-4 text-amber-400" />
              Simulate 1-Hr Contribution
            </button>
          </div>

          <span className="text-xs text-slate-400 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            Decentralized Social Escrow Verified
          </span>
        </div>
      </div>

      {/* Philosophy Callout */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1.5">
          <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-indigo-400" />
            1. Universal Equality
          </h4>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            One hour of help from a senior developer or designer is balanced with one hour of tutoring or community organizing.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1.5">
          <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            2. Escrow Protection
          </h4>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Credits are reserved in escrow when booking and released automatically once both teammates confirm the session outcome.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1.5">
          <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
            <Coins className="w-4 h-4 text-amber-400" />
            3. Reputation Growth
          </h4>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Every settled transaction updates your NAVA Trust Passport and Social Impact Ledger with verifiable proof.
          </p>
        </div>
      </div>

      {/* Transaction History Table */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Clock className="w-4 h-4 text-indigo-400" />
            Time Credit Transaction History
          </h3>
          <span className="text-xs text-slate-400">{navaTimeWallet?.transactions?.length || 0} Transactions</span>
        </div>

        <div className="divide-y divide-slate-800">
          {(navaTimeWallet?.transactions || []).map((tx) => {
            const isEarned = tx.type === 'earned';
            return (
              <div key={tx.id} className="p-4 hover:bg-slate-800/40 transition flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 ${
                      isEarned
                        ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                        : 'bg-violet-500/15 text-violet-400 border border-violet-500/30'
                    }`}
                  >
                    {isEarned ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-white">{tx.description}</h5>
                    <p className="text-[11px] text-slate-400">
                      With <strong className="text-slate-300">{tx.counterpartyName}</strong> • {tx.date}
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span
                    className={`text-sm font-black ${
                      isEarned ? 'text-emerald-400' : 'text-violet-400'
                    }`}
                  >
                    {isEarned ? `+${tx.amount}` : `-${tx.amount}`} Credits
                  </span>
                  <span className="text-[10px] text-slate-500 block">
                    {tx.sessionDurationHours} hr session
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
