import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { NavaMission, NavaGoal } from '../../types';
import {
  Target,
  Plus,
  Users,
  Calendar,
  CheckCircle2,
  Sparkles,
  Search,
  Filter,
  Shield,
  Layers,
  Award,
  ChevronDown,
  ChevronUp,
  MapPin,
  Clock,
  ArrowUpRight,
  Info,
} from 'lucide-react';

export const NavaMissionsTab: React.FC = () => {
  const {
    navaMissions,
    joinNavaMission,
    createNavaMission,
    setNavaActiveTab,
    showToast,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGoalFilter, setSelectedGoalFilter] = useState<string>('ALL');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('ALL');
  const [expandedMissionId, setExpandedMissionId] = useState<string | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  // Form State for creating new mission
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newGoal, setNewGoal] = useState<NavaGoal>('developer');
  const [newOutcome, setNewOutcome] = useState('');
  const [newDuration, setNewDuration] = useState<number>(60);
  const [newDifficulty, setNewDifficulty] = useState<'beginner' | 'intermediate' | 'advanced'>('intermediate');
  const [newSkillsReq, setNewSkillsReq] = useState('');
  const [newSkillsGain, setNewSkillsGain] = useState('');
  const [newMaxMembers, setNewMaxMembers] = useState<number>(25);

  const goalCategories: Array<{ key: string; label: string }> = [
    { key: 'ALL', label: 'All Goals' },
    { key: 'developer', label: '💻 Developer' },
    { key: 'entrepreneur', label: '🚀 Entrepreneur' },
    { key: 'designer', label: '🎨 Designer' },
    { key: 'creator', label: '🎬 Creator' },
    { key: 'community_leader', label: '🌍 Community Leader' },
    { key: 'athlete', label: '🏃 Athlete' },
  ];

  const filteredMissions = navaMissions.filter((m) => {
    if (selectedGoalFilter !== 'ALL' && m.goalCategory !== selectedGoalFilter) return false;
    if (selectedDifficulty !== 'ALL' && m.difficulty !== selectedDifficulty) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        m.title.toLowerCase().includes(q) ||
        m.description.toLowerCase().includes(q) ||
        m.targetOutcome.toLowerCase().includes(q) ||
        m.tags.some((t) => t.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newOutcome.trim()) {
      showToast('Please provide a title and target outcome.');
      return;
    }

    createNavaMission({
      title: newTitle.trim(),
      description: newDesc.trim() || 'Collaborative mission designed for steady progress.',
      goalCategory: newGoal,
      targetOutcome: newOutcome.trim(),
      durationDays: Number(newDuration),
      difficulty: newDifficulty,
      requiredSkills: newSkillsReq ? newSkillsReq.split(',').map((s) => s.trim()) : ['Dedication'],
      gainedSkills: newSkillsGain ? newSkillsGain.split(',').map((s) => s.trim()) : ['Mastery', 'Teamwork'],
      maxParticipants: Number(newMaxMembers),
    });

    setIsCreateModalOpen(false);
    setNewTitle('');
    setNewDesc('');
    setNewOutcome('');
    setNewSkillsReq('');
    setNewSkillsGain('');
  };

  return (
    <div className="space-y-6">
      {/* Header with Search & "Create Mission" CTA */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <Target className="w-5 h-5 text-indigo-400" />
            Mission Marketplace & Systems
          </h2>
          <p className="text-xs text-slate-400">
            Join or launch goal-oriented missions. Every mission produces tangible proof, not empty content.
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition flex items-center gap-2 cursor-pointer self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          Launch New Mission
        </button>
      </div>

      {/* Filter Bar */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search missions by skills, goals, tech stack, or location..."
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-white border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <select
              value={selectedDifficulty}
              onChange={(e) => setSelectedDifficulty(e.target.value)}
              className="px-3 py-2 rounded-xl bg-white border border-slate-800 text-xs text-slate-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
            >
              <option value="ALL">All Difficulties</option>
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </select>
          </div>
        </div>

        {/* Goal Category Pills */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          {goalCategories.map((cat) => (
            <button
              key={cat.key}
              onClick={() => setSelectedGoalFilter(cat.key)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer border ${
                selectedGoalFilter === cat.key
                  ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm'
                  : 'bg-white text-slate-400 hover:text-slate-200 border-slate-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Missions Grid */}
      <div className="grid grid-cols-1 gap-4">
        {filteredMissions.map((mission) => {
          const isExpanded = expandedMissionId === mission.id;
          const completedMilestones = (mission.milestones || []).filter((m) => m.isCompleted).length;
          const totalMilestones = (mission.milestones || []).length;

          return (
            <div
              key={mission.id}
              className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                mission.hasJoined
                  ? 'bg-slate-900/90 border-indigo-500/50 shadow-lg shadow-indigo-950/20'
                  : 'bg-slate-900/60 hover:bg-slate-900 border-slate-800'
              }`}
            >
              <div className="p-5 space-y-4">
                {/* Mission Top Details */}
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="space-y-1.5 max-w-3xl">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-indigo-500/15 text-indigo-300 border border-indigo-500/30">
                        {mission.goalCategory}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          mission.difficulty === 'beginner'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : mission.difficulty === 'intermediate'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}
                      >
                        {mission.difficulty}
                      </span>
                      <span className="text-[11px] text-slate-400 flex items-center gap-1 font-medium">
                        <Clock className="w-3 h-3 text-slate-500" />
                        {mission.durationDays} Days Duration
                      </span>
                      {mission.location?.isRealWorld && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-500/15 text-teal-300 border border-teal-500/30 flex items-center gap-1">
                          <MapPin className="w-2.5 h-2.5" />
                          {mission.location.city}
                        </span>
                      )}
                    </div>

                    <h3 className="text-base md:text-lg font-bold text-white leading-snug">
                      {mission.title}
                    </h3>
                    <p className="text-xs text-slate-300 leading-relaxed">{mission.description}</p>
                  </div>

                  {/* Join / Active Status CTA */}
                  <div className="flex sm:flex-col items-center sm:items-end gap-2 shrink-0">
                    <button
                      onClick={() => joinNavaMission(mission.id)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                        mission.hasJoined
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-rose-500/20 hover:text-rose-300 hover:border-rose-500/40'
                          : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30'
                      }`}
                    >
                      {mission.hasJoined ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Joined (Active)</span>
                        </>
                      ) : (
                        <>
                          <Target className="w-3.5 h-3.5" />
                          <span>Join Mission</span>
                        </>
                      )}
                    </button>

                    {mission.hasJoined && (
                      <button
                        onClick={() => setNavaActiveTab('circles')}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-indigo-950 text-indigo-300 text-[11px] font-semibold transition flex items-center gap-1 cursor-pointer"
                      >
                        <Users className="w-3 h-3" />
                        <span>Open Circle</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Target Outcome Callout */}
                <div className="p-3 rounded-xl bg-white/70 border border-slate-800/80 flex items-start gap-2.5">
                  <Award className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div className="text-xs space-y-0.5">
                    <span className="font-bold text-slate-300">Target Outcome: </span>
                    <span className="text-slate-400">{mission.targetOutcome}</span>
                  </div>
                </div>

                {/* Skills Tags */}
                <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                      Skills Gained:
                    </span>
                    {mission.gainedSkills.map((sk) => (
                      <span
                        key={sk}
                        className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[11px] font-medium border border-slate-700/60"
                      >
                        {sk}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center gap-4 text-slate-400 text-xs shrink-0">
                    <span className="flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-indigo-400" />
                      <strong className="text-white">{mission.currentParticipantsCount}</strong> / {mission.maxParticipants} builders
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Shield className="w-3.5 h-3.5 text-emerald-400" />
                      Creator Trust: <strong className="text-emerald-400">{mission.creatorTrustScore}</strong>
                    </span>
                  </div>
                </div>

                {/* Progress Bar & Milestones Accordion Toggle */}
                <div className="pt-2 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-1.5 flex-1 max-w-md">
                    <div className="flex justify-between text-[11px] font-semibold text-slate-400">
                      <span>Milestones Progress</span>
                      <span className="text-indigo-400">{completedMilestones} of {totalMilestones} Completed ({mission.progressPct}%)</span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 rounded-full transition-all duration-300"
                        style={{ width: `${mission.progressPct}%` }}
                      />
                    </div>
                  </div>

                  <button
                    onClick={() => setExpandedMissionId(isExpanded ? null : mission.id)}
                    className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 self-start sm:self-auto cursor-pointer"
                  >
                    <span>{isExpanded ? 'Hide Milestones' : 'View Milestones & Roadmap'}</span>
                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Expanded Milestones Roadmap */}
              {isExpanded && (
                <div className="p-5 bg-white border-t border-slate-800 space-y-4">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                    <Layers className="w-4 h-4 text-indigo-400" />
                    Structured Milestone Roadmap
                  </h4>

                  <div className="space-y-3">
                    {(mission.milestones || []).map((ms, idx) => (
                      <div
                        key={ms.id}
                        className={`p-3.5 rounded-xl border transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                          ms.isCompleted
                            ? 'bg-emerald-950/20 border-emerald-500/30'
                            : 'bg-slate-900 border-slate-800'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div
                            className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${
                              ms.isCompleted
                                ? 'bg-emerald-500 text-slate-800'
                                : 'bg-slate-800 text-slate-400 border border-slate-700'
                            }`}
                          >
                            {ms.isCompleted ? '✓' : idx + 1}
                          </div>
                          <div className="space-y-0.5">
                            <h5 className="text-xs font-bold text-white">{ms.title}</h5>
                            <p className="text-[11px] text-slate-400">{ms.description}</p>
                            {ms.proofSummary && (
                              <p className="text-[10px] text-emerald-400 font-medium pt-1">
                                🛡️ Verified Proof: {ms.proofSummary}
                              </p>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          {ms.proofUrl && (
                            <a
                              href={ms.proofUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-indigo-300 text-[11px] font-semibold flex items-center gap-1"
                            >
                              <span>Proof URL</span>
                              <ArrowUpRight className="w-3 h-3" />
                            </a>
                          )}
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              ms.isCompleted
                                ? 'bg-emerald-500/20 text-emerald-300'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {ms.isCompleted ? 'Done' : 'Upcoming'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Create Mission Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-100/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-2xl rounded-2xl bg-slate-900 border border-indigo-500/40 p-6 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="space-y-0.5">
                <h3 className="text-lg font-black text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-amber-400" />
                  Launch a Next-Gen NAVA Mission
                </h3>
                <p className="text-xs text-slate-400">
                  Define your objective, target duration, and required milestones.
                </p>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Mission Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Master High-Frequency Algo Trading in Python"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Goal Domain</label>
                  <select
                    value={newGoal}
                    onChange={(e) => setNewGoal(e.target.value as NavaGoal)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="developer">Developer</option>
                    <option value="entrepreneur">Entrepreneur</option>
                    <option value="designer">Designer</option>
                    <option value="creator">Creator</option>
                    <option value="community_leader">Community Leader</option>
                    <option value="athlete">Athlete</option>
                    <option value="student">Student</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Difficulty</label>
                  <select
                    value={newDifficulty}
                    onChange={(e) => setNewDifficulty(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="beginner">Beginner</option>
                    <option value="intermediate">Intermediate</option>
                    <option value="advanced">Advanced</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Duration (Days)</label>
                  <input
                    type="number"
                    min={14}
                    max={180}
                    value={newDuration}
                    onChange={(e) => setNewDuration(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Target Outcome (Proof of Success) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Backtest 3 profitable trading models & publish live paper trading bot"
                  value={newOutcome}
                  onChange={(e) => setNewOutcome(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Description</label>
                <textarea
                  rows={3}
                  placeholder="Explain the mission vision, team cadence, and why builders should join..."
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Skills Required (comma separated)
                  </label>
                  <input
                    type="text"
                    placeholder="Python, Statistics, Git"
                    value={newSkillsReq}
                    onChange={(e) => setNewSkillsReq(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Skills Gained (comma separated)
                  </label>
                  <input
                    type="text"
                    placeholder="VectorDB, Quant Finance, Async IO"
                    value={newSkillsGain}
                    onChange={(e) => setNewSkillsGain(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-xs font-bold text-slate-300 hover:bg-slate-700 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 transition cursor-pointer"
                >
                  Launch Mission & Circle
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
