import React, { useState } from 'react';
import {
  X,
  Sliders,
  DollarSign,
  TrendingUp,
  MapPin,
  Users,
  Truck,
  ShieldAlert,
  Sparkles,
  Bot,
  RefreshCw,
  CheckCircle2,
  PieChart,
  Navigation,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface AdminCommandCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdminCommandCenterModal: React.FC<AdminCommandCenterModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { showToast } = useApp();

  const [activeTab, setActiveTab] = useState<'command' | 'pricing' | 'simulator' | 'copilot'>('command');

  // Dynamic Pricing Studio State
  const [baseRate, setBaseRate] = useState<number>(30);
  const [perKmRate, setPerKmRate] = useState<number>(8);
  const [slab0to5, setSlab0to5] = useState<number>(45);
  const [slab5to10, setSlab5to10] = useState<number>(75);
  const [slab10to20, setSlab10to20] = useState<number>(140);
  const [slab20to50, setSlab20to50] = useState<number>(290);
  const [peakMultiplier, setPeakMultiplier] = useState<number>(1.25);
  const [sellerContributionPct, setSellerContributionPct] = useState<number>(65);

  // Simulator State
  const [simDistance, setSimDistance] = useState<number>(14);
  const [simParcel, setSimParcel] = useState<'small' | 'medium' | 'large'>('medium');
  const [simDemand, setSimDemand] = useState<'normal' | 'high' | 'surge'>('high');

  // Copilot State
  const [copilotQuery, setCopilotQuery] = useState<string>('');
  const [copilotResponse, setCopilotResponse] = useState<string | null>(null);
  const [isCopilotThinking, setIsCopilotThinking] = useState<boolean>(false);

  if (!isOpen) return null;

  // Simulator Math
  const simBase = simDistance <= 5 ? slab0to5 : simDistance <= 10 ? slab5to10 : simDistance <= 20 ? slab10to20 : slab20to50;
  const simMultiplier = simDemand === 'surge' ? 1.5 : simDemand === 'high' ? peakMultiplier : 1.0;
  const partnerPayout = Math.round(simBase * simMultiplier);
  const customerFee = 0; // 100% FREE Community Delivery
  const sellerDeduction = Math.round((partnerPayout * sellerContributionPct) / 100);
  const platformSubsidizedFund = partnerPayout - sellerDeduction;

  const handleSavePricingRules = () => {
    showToast('✨ Dynamic Pricing Rules Updated! Live immediately for all network routes.');
  };

  const handleRunCopilot = (queryText?: string) => {
    const q = queryText || copilotQuery;
    if (!q) return;
    setIsCopilotThinking(true);
    setTimeout(() => {
      setIsCopilotThinking(false);
      if (q.toLowerCase().includes('cost') || q.toLowerCase().includes('increase')) {
        setCopilotResponse(
          '📊 Delivery costs increased by 8.4% today due to evening monsoon showers in Indore-Palasia sector. Dynamic peak surge (1.25x) was triggered between 5:30 PM–7:00 PM, retaining 94% partner fulfillment SLA.'
        );
      } else if (q.toLowerCase().includes('demand') || q.toLowerCase().includes('city')) {
        setCopilotResponse(
          '📍 Highest demand corridor: Indore Vijay Nagar ➔ Khandwa Route (+42% intercity parcel volume). Recommendation: Add ₹25 corridor booster to attract more regular commuters.'
        );
      } else {
        setCopilotResponse(
          `🤖 Analysis Complete: Platform network efficiency is at 98.2%. Average community delivery duration is 21.4 minutes with 0% customer delivery fees.`
        );
      }
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl w-full max-w-4xl shadow-2xl text-slate-100 flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 px-6 py-4 flex items-center justify-between text-white border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black flex items-center gap-2">
                <span>Executive Command Center</span>
                <span className="text-[9px] bg-emerald-950 text-emerald-300 border border-emerald-700 px-2 py-0.5 rounded-full font-bold">
                  LIVE
                </span>
              </h3>
              <p className="text-xs text-slate-400">Autonomous Commerce & Network Governance</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-800 bg-white px-6 pt-2">
          <button
            onClick={() => setActiveTab('command')}
            className={`py-3 px-4 text-xs font-black border-b-2 transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'command'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Command Center & Map</span>
          </button>

          <button
            onClick={() => setActiveTab('pricing')}
            className={`py-3 px-4 text-xs font-black border-b-2 transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'pricing'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Dynamic Pricing Studio</span>
          </button>

          <button
            onClick={() => setActiveTab('simulator')}
            className={`py-3 px-4 text-xs font-black border-b-2 transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'simulator'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <PieChart className="w-3.5 h-3.5" />
            <span>Pricing Simulator</span>
          </button>

          <button
            onClick={() => setActiveTab('copilot')}
            className={`py-3 px-4 text-xs font-black border-b-2 transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'copilot'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Admin Copilot</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: COMMAND CENTER & LIVE MAP */}
          {activeTab === 'command' && (
            <div className="space-y-6">
              {/* Metric Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-white p-3.5 rounded-2xl border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Total Platform GMV</span>
                  <p className="text-lg font-black text-white">₹14,82,450</p>
                  <span className="text-[10px] text-emerald-400 font-bold">+18.4% vs last week</span>
                </div>

                <div className="bg-white p-3.5 rounded-2xl border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">🟢 Available Partners</span>
                  <p className="text-lg font-black text-emerald-400">142</p>
                  <span className="text-[10px] text-slate-500">In 50km radius</span>
                </div>

                <div className="bg-white p-3.5 rounded-2xl border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">🔵 Active Deliveries</span>
                  <p className="text-lg font-black text-cyan-400">48</p>
                  <span className="text-[10px] text-slate-500">In transit</span>
                </div>

                <div className="bg-white p-3.5 rounded-2xl border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">🔴 Network Alerts</span>
                  <p className="text-lg font-black text-emerald-400">0</p>
                  <span className="text-[10px] text-emerald-500">All systems optimal</span>
                </div>
              </div>

              {/* Visual Simulated Map View */}
              <div className="bg-white p-4 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300 flex items-center gap-2">
                    <Navigation className="w-4 h-4 text-emerald-400" />
                    <span>Indore Live Community Corridor Grid</span>
                  </span>
                  <span className="text-[10px] text-slate-400">Auto-refreshing 5s</span>
                </div>

                <div className="h-44 bg-slate-900 rounded-xl border border-slate-800 relative flex items-center justify-center overflow-hidden">
                  <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:16px_16px] opacity-20" />
                  {/* Floating active markers */}
                  <div className="absolute top-8 left-16 flex items-center gap-1 bg-emerald-950 text-emerald-300 border border-emerald-700 px-2 py-0.5 rounded-full text-[10px] font-bold animate-pulse">
                    🟢 Partner #102 (Vijay Nagar)
                  </div>
                  <div className="absolute top-20 right-24 flex items-center gap-1 bg-cyan-950 text-cyan-300 border border-cyan-700 px-2 py-0.5 rounded-full text-[10px] font-bold">
                    🔵 Package #9921 ➔ Palasia (7m away)
                  </div>
                  <div className="absolute bottom-6 left-1/3 flex items-center gap-1 bg-teal-950 text-teal-300 border border-teal-700 px-2 py-0.5 rounded-full text-[10px] font-bold">
                    🟢 Commuter on Khandwa Corridor
                  </div>

                  <p className="text-xs text-slate-500 font-mono z-10">
                    Live Telemetry: 190 nodes active across Indore, Ujjain, Dewas, Khandwa
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: DYNAMIC PRICING STUDIO */}
          {activeTab === 'pricing' && (
            <div className="space-y-5">
              <div className="bg-white p-4 rounded-2xl border border-slate-800 space-y-1">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">
                  Admin Dynamic Pricing Configuration
                </span>
                <p className="text-xs text-slate-400">
                  Rules update instantly without requiring a platform release. 100% Free Community Delivery for customers is preserved via seller contribution + platform subsidy.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="bg-white p-4 rounded-2xl border border-slate-800 space-y-2">
                  <label className="font-bold text-slate-300 block">Distance Slab 0–5 km Base Payout (₹):</label>
                  <input
                    type="range"
                    min={30}
                    max={80}
                    value={slab0to5}
                    onChange={(e) => setSlab0to5(Number(e.target.value))}
                    className="w-full accent-emerald-400"
                  />
                  <span className="text-sm font-black text-emerald-400">₹{slab0to5}</span>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-800 space-y-2">
                  <label className="font-bold text-slate-300 block">Distance Slab 5–10 km Base Payout (₹):</label>
                  <input
                    type="range"
                    min={60}
                    max={120}
                    value={slab5to10}
                    onChange={(e) => setSlab5to10(Number(e.target.value))}
                    className="w-full accent-emerald-400"
                  />
                  <span className="text-sm font-black text-emerald-400">₹{slab5to10}</span>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-800 space-y-2">
                  <label className="font-bold text-slate-300 block">Distance Slab 10–20 km Base Payout (₹):</label>
                  <input
                    type="range"
                    min={100}
                    max={200}
                    value={slab10to20}
                    onChange={(e) => setSlab10to20(Number(e.target.value))}
                    className="w-full accent-emerald-400"
                  />
                  <span className="text-sm font-black text-emerald-400">₹{slab10to20}</span>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-800 space-y-2">
                  <label className="font-bold text-slate-300 block">Distance Slab 20–50 km Regional Payout (₹):</label>
                  <input
                    type="range"
                    min={200}
                    max={500}
                    value={slab20to50}
                    onChange={(e) => setSlab20to50(Number(e.target.value))}
                    className="w-full accent-emerald-400"
                  />
                  <span className="text-sm font-black text-emerald-400">₹{slab20to50}</span>
                </div>
              </div>

              <button
                onClick={handleSavePricingRules}
                className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-black text-xs rounded-xl shadow-lg transition cursor-pointer"
              >
                APPLY & SYNC REAL-TIME PRICING RULES
              </button>
            </div>
          )}

          {/* TAB 3: PRICING SIMULATOR */}
          {activeTab === 'simulator' && (
            <div className="space-y-5">
              <div className="bg-white p-4 rounded-2xl border border-slate-800 space-y-3">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider block">
                  Simulate Dynamic Route Economics
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="text-slate-400 block mb-1 font-bold">Distance (km):</label>
                    <input
                      type="number"
                      value={simDistance}
                      onChange={(e) => setSimDistance(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    />
                  </div>

                  <div>
                    <label className="text-slate-400 block mb-1 font-bold">Demand Level:</label>
                    <select
                      value={simDemand}
                      onChange={(e) => setSimDemand(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    >
                      <option value="normal">Normal (1.0x)</option>
                      <option value="high">Peak Demand ({peakMultiplier}x)</option>
                      <option value="surge">Surge Weather (1.5x)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-slate-400 block mb-1 font-bold">Parcel Size:</label>
                    <select
                      value={simParcel}
                      onChange={(e) => setSimParcel(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    >
                      <option value="small">Small (&lt; 1kg)</option>
                      <option value="medium">Medium (1-5kg)</option>
                      <option value="large">Large (5-15kg)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Simulation Results Breakdown */}
              <div className="bg-white p-5 rounded-2xl border border-slate-800 space-y-4">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  Calculated Financial Settlement:
                </h4>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                  <div className="bg-slate-900 p-3 rounded-xl border border-emerald-500/40">
                    <span className="text-[10px] text-slate-400 block">Customer Pays</span>
                    <span className="text-base font-black text-emerald-400">₹0 (FREE)</span>
                  </div>

                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Partner Reward</span>
                    <span className="text-base font-black text-white">₹{partnerPayout}</span>
                  </div>

                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Seller Contribution</span>
                    <span className="text-base font-black text-amber-400">₹{sellerDeduction}</span>
                  </div>

                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Platform Subsidy</span>
                    <span className="text-base font-black text-cyan-400">₹{platformSubsidizedFund}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: AI ADMIN COPILOT */}
          {activeTab === 'copilot' && (
            <div className="space-y-4">
              <div className="bg-white p-4 rounded-2xl border border-slate-800 space-y-3">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block">
                  Ask AI Admin Copilot:
                </span>

                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="e.g. Why did delivery costs increase today?"
                    value={copilotQuery}
                    onChange={(e) => setCopilotQuery(e.target.value)}
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-xs text-white"
                  />
                  <button
                    onClick={() => handleRunCopilot()}
                    disabled={isCopilotThinking}
                    className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-bold text-xs rounded-xl transition cursor-pointer flex items-center gap-1.5"
                  >
                    {isCopilotThinking ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                    <span>Ask</span>
                  </button>
                </div>

                {/* Quick query chips */}
                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    onClick={() => handleRunCopilot('Why did delivery costs increase today?')}
                    className="text-[11px] bg-slate-900 hover:bg-slate-800 text-slate-300 px-3 py-1 rounded-lg border border-slate-800"
                  >
                    💡 Why did delivery costs increase today?
                  </button>
                  <button
                    onClick={() => handleRunCopilot('Which city has the highest delivery demand?')}
                    className="text-[11px] bg-slate-900 hover:bg-slate-800 text-slate-300 px-3 py-1 rounded-lg border border-slate-800"
                  >
                    📍 Which city has the highest delivery demand?
                  </button>
                </div>
              </div>

              {copilotResponse && (
                <div className="bg-white p-4 rounded-2xl border border-emerald-500/40 text-xs text-slate-200 space-y-1">
                  <span className="font-bold text-emerald-400 block">Copilot Insight:</span>
                  <p>{copilotResponse}</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
