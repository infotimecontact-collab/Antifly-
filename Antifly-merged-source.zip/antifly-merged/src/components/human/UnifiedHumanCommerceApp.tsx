import React, { useState, useRef } from 'react';
import {
  Search,
  Mic,
  Camera,
  ShoppingBag,
  Store,
  Truck,
  DollarSign,
  Heart,
  Sparkles,
  MapPin,
  Clock,
  ArrowRight,
  ShieldCheck,
  Zap,
  Repeat,
  Gift,
  Play,
  Share2,
  CheckCircle2,
  Users,
  MessageSquare,
  SlidersHorizontal,
  Flame,
  Award,
  ChevronRight,
  TrendingUp,
  Tag,
  Navigation,
  Crosshair,
  Radio,
  Layers,
  Compass,
  AlertCircle,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../common/ProductCard';

interface UnifiedHumanCommerceAppProps {
  onSelectCategory?: (slug: string) => void;
  onViewCatalog?: () => void;
}

interface DeliveryOpportunity {
  id: string;
  orderNumber: string;
  storeName: string;
  storeAddress: string;
  customerName: string;
  customerAddress: string;
  pickupDistance: string;
  totalDistance: string;
  estTime: string;
  payoutINR: number;
  itemsSummary: string;
  routeMatchPct: number;
  parcelSize: 'Small' | 'Medium' | 'Bag';
  isDetourMatch?: boolean;
  coordinates: {
    pickupX: number; // Percentage for map
    pickupY: number;
    dropX: number;
    dropY: number;
  };
}

const DELIVERY_OPPORTUNITIES: DeliveryOpportunity[] = [
  {
    id: 'opp-1',
    orderNumber: '#IND-9941',
    storeName: 'Agarwal General Store',
    storeAddress: 'Rajwada Main Market, Chhatribagh',
    customerName: 'Ananya Verma',
    customerAddress: 'Shreem Heights, Vijaynagar',
    pickupDistance: '1.4 km',
    totalDistance: '3.8 km',
    estTime: '18 mins',
    payoutINR: 85,
    itemsSummary: 'Handloom Sarees & Groceries (2 Bags)',
    routeMatchPct: 96,
    parcelSize: 'Medium',
    isDetourMatch: true,
    coordinates: {
      pickupX: 35,
      pickupY: 60,
      dropX: 68,
      dropY: 32,
    },
  },
  {
    id: 'opp-2',
    orderNumber: '#IND-9942',
    storeName: 'Apna Sweets & Namkeen',
    storeAddress: 'Main AB Road, Vijaynagar Square',
    customerName: 'Rohit Khandelwal',
    customerAddress: 'Royal Palms, Scheme 54',
    pickupDistance: '0.6 km',
    totalDistance: '1.2 km',
    estTime: '11 mins',
    payoutINR: 60,
    itemsSummary: '1kg Ratlami Sev + 500g Kaju Katli',
    routeMatchPct: 99,
    parcelSize: 'Small',
    coordinates: {
      pickupX: 65,
      pickupY: 28,
      dropX: 78,
      dropY: 20,
    },
  },
  {
    id: 'opp-3',
    orderNumber: '#IND-9943',
    storeName: 'Sarafa Artisan Jewellers & Gifts',
    storeAddress: 'Sarafa Bazaar Night Street',
    customerName: 'Kavita Dave',
    customerAddress: 'Manorama Ganj, Palasia',
    pickupDistance: '2.1 km',
    totalDistance: '4.5 km',
    estTime: '24 mins',
    payoutINR: 130,
    itemsSummary: 'Silver Gift Box + Velvet Pouch',
    routeMatchPct: 88,
    parcelSize: 'Small',
    isDetourMatch: true,
    coordinates: {
      pickupX: 30,
      pickupY: 72,
      dropX: 52,
      dropY: 48,
    },
  },
];

export const UnifiedHumanCommerceApp: React.FC<UnifiedHumanCommerceAppProps> = ({
  onSelectCategory,
  onViewCatalog,
}) => {
  const {
    products,
    sellers,
    shortVideoReels,
    userLocation,
    setIsWiseAIOpen,
    setIsVoiceSearchOpen,
    setIsImageSearchOpen,
    setIsOneTapSellOpen,
    setIsUniversalIdentityOpen,
    setIsDestinationDetourOpen,
    setIsTimeToEarnOpen,
    setIsProductExchangeOpen,
    setIsAIConditionInspectorOpen,
    setIsAdminCommandCenterOpen,
    setIsCommunityNetworkOpen,
    setIsSmartDeliveryDecisionOpen,
    userUniversalCapabilities,
    toggleUserUniversalCapability,
    addToCart,
    openReelPlayer,
    openStoreCommunity,
    openStoreChat,
    showToast,
  } = useApp();

  const [naturalQuery, setNaturalQuery] = useState<string>('');
  const [activeEcosystemTab, setActiveEcosystemTab] = useState<'buy' | 'sell' | 'help' | 'earn' | 'connect'>('buy');
  const [geoScope, setGeoScope] = useState<'nearby' | 'india' | 'global'>('nearby');
  const [selectedQuickFilter, setSelectedQuickFilter] = useState<string>('all');

  // Delivery Opportunity Map Highlights State
  const [selectedOpportunityId, setSelectedOpportunityId] = useState<string>('opp-1');
  const [mapFilter, setMapFilter] = useState<'all' | 'route' | 'high_payout'>('all');
  const deliveryMapRef = useRef<HTMLDivElement | null>(null);

  // AI Shopping Assistant simulated response
  const [aiRecommendationQuery, setAiRecommendationQuery] = useState<string | null>(null);

  const isDeliveryModeActive = !!userUniversalCapabilities.delivery;

  const handleToggleDeliveryMode = () => {
    toggleUserUniversalCapability('delivery');
    if (!isDeliveryModeActive) {
      showToast('🚚 Delivery Mode ENABLED! Highlighting 3 nearby delivery opportunities on the map.');
      setTimeout(() => {
        deliveryMapRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 250);
    } else {
      showToast('⚪ Delivery Mode paused. Returned to standard shopper mode.');
    }
  };

  const handleNaturalSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!naturalQuery.trim()) return;

    if (naturalQuery.toLowerCase().includes('phone') || naturalQuery.toLowerCase().includes('20000')) {
      setAiRecommendationQuery('Under ₹20,000 Phones near Indore');
      showToast('🤖 AI Assistant parsed: Category=Phone, Budget=₹20,000, Location=Indore.');
    } else if (naturalQuery.toLowerCase().includes('gift') || naturalQuery.toLowerCase().includes('brother')) {
      setAiRecommendationQuery('Birthday Gifts for Brother under ₹2,000');
      showToast('🤖 AI Assistant curated top gift recommendations.');
    } else {
      setAiRecommendationQuery(`Results for "${naturalQuery}"`);
      showToast(`🔍 Showing matches for "${naturalQuery}"`);
    }
  };

  const handleOneTapBuyReelProduct = (reel: any) => {
    const matchedProduct = products.find((p) => p.name.toLowerCase().includes(reel.title.toLowerCase().split(' ')[0])) || products[0];
    if (matchedProduct) {
      addToCart({
        productId: matchedProduct.id,
        quantity: 1,
        selectedColor: 'Default',
        selectedSize: 'Standard',
      });
      showToast(`🛍 Added "${matchedProduct.name}" to cart with Free Community Delivery!`);
    }
  };

  const filteredOpportunities = DELIVERY_OPPORTUNITIES.filter((opp) => {
    if (mapFilter === 'route') return opp.isDetourMatch;
    if (mapFilter === 'high_payout') return opp.payoutINR >= 85;
    return true;
  });

  const activeSelectedOpp =
    DELIVERY_OPPORTUNITIES.find((o) => o.id === selectedOpportunityId) || DELIVERY_OPPORTUNITIES[0];

  return (
    <div className="w-full bg-slate-900 text-slate-100 min-h-screen pb-32 relative">
      {/* 1. TOP HUMAN-FIRST HERO BAR */}
      <div className="bg-gradient-to-b from-slate-950 via-slate-900 to-slate-900 border-b border-slate-800/80 px-4 sm:px-8 pt-6 pb-6">
        <div className="max-w-7xl mx-auto space-y-5">
          {/* Greeting & Universal Profile Quick Card */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black tracking-wider text-emerald-400 uppercase">
                  A COMMERCE NETWORK POWERED BY PEOPLE
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight mt-0.5">
                Buy from people. Sell to people. Deliver with people.
              </h1>
            </div>

            {/* Universal Identity Capsule */}
            <div className="flex items-center gap-2 bg-white/80 border border-slate-800 p-1.5 rounded-2xl">
              <button
                onClick={() => setIsUniversalIdentityOpen(true)}
                className="flex items-center gap-2.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition cursor-pointer border border-slate-700/50"
              >
                <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-[10px]">
                  AS
                </div>
                <span>Aarav (Indore)</span>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-700 px-1.5 py-0.2 rounded-full">
                  ★ 4.9
                </span>
              </button>

              <button
                onClick={() => setIsAdminCommandCenterOpen(true)}
                className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl transition cursor-pointer"
                title="Command Center"
              >
                <SlidersHorizontal className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* 2. THE 5 CORE HUMAN ACTIONS */}
          <div className="grid grid-cols-5 gap-2 sm:gap-3">
            {/* 1. BUY */}
            <button
              onClick={() => setActiveEcosystemTab('buy')}
              className={`py-3 sm:py-3.5 px-2 rounded-2xl font-black text-xs sm:text-sm flex flex-col sm:flex-row items-center justify-center gap-1.5 sm:gap-2 transition-all cursor-pointer ${
                activeEcosystemTab === 'buy'
                  ? 'bg-emerald-500 text-slate-800 shadow-xl shadow-emerald-500/30 ring-2 ring-emerald-400'
                  : 'bg-white/80 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
              }`}
            >
              <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5" />
              <span>BUY</span>
            </button>

            {/* 2. SELL */}
            <button
              onClick={() => {
                setActiveEcosystemTab('sell');
                setIsOneTapSellOpen(true);
              }}
              className={`py-3 sm:py-3.5 px-2 rounded-2xl font-black text-xs sm:text-sm flex flex-col sm:flex-row items-center justify-center gap-1.5 sm:gap-2 transition-all cursor-pointer ${
                activeEcosystemTab === 'sell'
                  ? 'bg-teal-500 text-slate-800 shadow-xl shadow-teal-500/30 ring-2 ring-teal-400'
                  : 'bg-white/80 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
              }`}
            >
              <Store className="w-4 h-4 sm:w-5 sm:h-5" />
              <span>SELL</span>
            </button>

            {/* 3. HELP (DELIVER) */}
            <button
              onClick={() => {
                setActiveEcosystemTab('help');
                if (!isDeliveryModeActive) {
                  toggleUserUniversalCapability('delivery');
                  showToast('🚚 Delivery Mode Activated! Showing nearby opportunities.');
                }
                setTimeout(() => {
                  deliveryMapRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }, 200);
              }}
              className={`py-3 sm:py-3.5 px-2 rounded-2xl font-black text-xs sm:text-sm flex flex-col sm:flex-row items-center justify-center gap-1.5 sm:gap-2 transition-all cursor-pointer ${
                activeEcosystemTab === 'help' || isDeliveryModeActive
                  ? 'bg-cyan-500 text-slate-800 shadow-xl shadow-cyan-500/30 ring-2 ring-cyan-400 font-black'
                  : 'bg-white/80 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
              }`}
            >
              <Truck className="w-4 h-4 sm:w-5 sm:h-5" />
              <span>HELP</span>
            </button>

            {/* 4. EARN */}
            <button
              onClick={() => {
                setActiveEcosystemTab('earn');
                setIsTimeToEarnOpen(true);
              }}
              className={`py-3 sm:py-3.5 px-2 rounded-2xl font-black text-xs sm:text-sm flex flex-col sm:flex-row items-center justify-center gap-1.5 sm:gap-2 transition-all cursor-pointer ${
                activeEcosystemTab === 'earn'
                  ? 'bg-blue-500 text-white shadow-xl shadow-blue-500/30 ring-2 ring-blue-400'
                  : 'bg-white/80 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
              }`}
            >
              <DollarSign className="w-4 h-4 sm:w-5 sm:h-5" />
              <span>EARN</span>
            </button>

            {/* 5. CONNECT */}
            <button
              onClick={() => setActiveEcosystemTab('connect')}
              className={`py-3 sm:py-3.5 px-2 rounded-2xl font-black text-xs sm:text-sm flex flex-col sm:flex-row items-center justify-center gap-1.5 sm:gap-2 transition-all cursor-pointer ${
                activeEcosystemTab === 'connect'
                  ? 'bg-pink-500 text-white shadow-xl shadow-pink-500/30 ring-2 ring-pink-400'
                  : 'bg-white/80 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
              }`}
            >
              <Heart className="w-4 h-4 sm:w-5 sm:h-5" />
              <span>CONNECT</span>
            </button>
          </div>

          {/* 3. INTELLIGENT AI SEARCH BAR */}
          <form
            onSubmit={handleNaturalSearch}
            className="bg-white border-2 border-emerald-500/40 focus-within:border-emerald-400 rounded-3xl p-2 sm:p-2.5 flex items-center gap-2 shadow-2xl transition"
          >
            <div className="pl-3 text-emerald-400">
              <Search className="w-5 h-5" />
            </div>

            <input
              type="text"
              placeholder="What are you looking for today? (e.g. Phone under ₹20k near me, Birthday gift under ₹2k)"
              value={naturalQuery}
              onChange={(e) => setNaturalQuery(e.target.value)}
              className="flex-1 bg-transparent text-white placeholder:text-slate-500 text-xs sm:text-sm font-medium focus:outline-hidden"
            />

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setIsVoiceSearchOpen(true)}
                className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-emerald-400 transition cursor-pointer"
                title="Voice Search"
              >
                <Mic className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => setIsImageSearchOpen(true)}
                className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-emerald-400 transition cursor-pointer"
                title="Photo Search"
              >
                <Camera className="w-4 h-4" />
              </button>

              <button
                type="submit"
                className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-black text-xs rounded-2xl shadow-lg transition cursor-pointer hidden sm:flex items-center gap-1"
              >
                <span>SEARCH</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </form>

          {/* Quick Natural Query Chips */}
          <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
            <span className="text-slate-500 font-bold text-[11px]">Popular:</span>
            <button
              onClick={() => {
                setNaturalQuery('Find phone under ₹20,000 near me');
                setAiRecommendationQuery('Under ₹20,000 Phones in Indore');
              }}
              className="bg-white border border-slate-800 hover:border-emerald-500/50 text-slate-300 hover:text-emerald-300 px-3 py-1 rounded-xl text-[11px] font-medium transition cursor-pointer"
            >
              📱 Phone under ₹20k near me
            </button>
            <button
              onClick={() => {
                setNaturalQuery('Birthday gift for brother under ₹2,000');
                setAiRecommendationQuery('Birthday Gifts for Brother under ₹2,000');
              }}
              className="bg-white border border-slate-800 hover:border-emerald-500/50 text-slate-300 hover:text-emerald-300 px-3 py-1 rounded-xl text-[11px] font-medium transition cursor-pointer"
            >
              🎁 Gift for brother under ₹2k
            </button>
            <button
              onClick={() => {
                if (!isDeliveryModeActive) toggleUserUniversalCapability('delivery');
                setIsDestinationDetourOpen(true);
              }}
              className="bg-emerald-950/60 border border-emerald-600/40 text-emerald-300 px-3 py-1 rounded-xl text-[11px] font-bold transition cursor-pointer"
            >
              🚗 Indore ➔ Khandwa Route Matches
            </button>
          </div>
        </div>
      </div>

      {/* 4. MAIN BODY CONTAINER */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8 space-y-10">
        {/* FREE COMMUNITY DELIVERY HERO BANNER */}
        <div className="bg-gradient-to-r from-emerald-900/60 via-slate-900 to-teal-900/60 border border-emerald-500/30 p-5 rounded-3xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/40 shrink-0">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-black text-white">🚚 FREE COMMUNITY DELIVERY ON ALL ORDERS</h3>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded-full font-bold border border-emerald-600/50">
                  ₹0 Delivery Fee
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Delivered by trusted neighborhood commuters and verified community partners. Estimated arrival: <strong className="text-emerald-400">Today • Arriving in ~18 mins</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (!isDeliveryModeActive) toggleUserUniversalCapability('delivery');
                setIsDestinationDetourOpen(true);
              }}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-black text-xs rounded-xl shadow-lg transition cursor-pointer"
            >
              CARRY & EARN (ON MY WAY)
            </button>
          </div>
        </div>

        {/* 4.1 HIGHLIGHTED DELIVERY OPPORTUNITIES MAP VIEW (ACTIVE WHEN DELIVERY MODE IS ON) */}
        <div
          ref={deliveryMapRef}
          className={`rounded-3xl border transition-all duration-500 overflow-hidden ${
            isDeliveryModeActive
              ? 'bg-white border-cyan-400/60 shadow-2xl shadow-cyan-500/10 p-5 sm:p-6 space-y-6 ring-2 ring-cyan-500/30'
              : 'bg-white/60 border-slate-800/80 p-5 rounded-3xl space-y-4'
          }`}
        >
          {/* Map Header & Controls */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div
                  className={`w-3 h-3 rounded-full ${
                    isDeliveryModeActive ? 'bg-cyan-400 animate-ping' : 'bg-slate-600'
                  }`}
                />
                <span className="text-xs font-black tracking-wider text-cyan-400 uppercase flex items-center gap-1.5">
                  <Navigation className="w-3.5 h-3.5" />
                  <span>
                    {isDeliveryModeActive
                      ? 'LIVE DELIVERY OPPORTUNITIES • RADAR ACTIVE'
                      : 'NEIGHBORHOOD DELIVERY RADAR (OFFLINE)'}
                  </span>
                </span>
                {isDeliveryModeActive && (
                  <span className="text-[10px] bg-cyan-950 text-cyan-300 border border-cyan-700 px-2 py-0.5 rounded-full font-bold">
                    3 Matches Found • Up to ₹275
                  </span>
                )}
              </div>
              <h3 className="text-base sm:text-lg font-black text-white">
                {isDeliveryModeActive
                  ? 'Delivery Opportunities Highlighted on Map'
                  : 'Enable Delivery Mode to View & Carry Live Neighborhood Orders'}
              </h3>
              <p className="text-xs text-slate-400">
                {isDeliveryModeActive
                  ? 'Tap any glowing pin or route on the map to accept and earn during your regular travel.'
                  : 'Turn on the floating Delivery Mode toggle below to start receiving real-time order broadcast alerts.'}
              </p>
            </div>

            {/* Top Action Toggle & Filters */}
            <div className="flex flex-wrap items-center gap-2">
              {isDeliveryModeActive && (
                <div className="flex items-center bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs font-bold">
                  <button
                    onClick={() => setMapFilter('all')}
                    className={`px-3 py-1 rounded-lg transition cursor-pointer ${
                      mapFilter === 'all' ? 'bg-cyan-500 text-slate-800 font-black' : 'text-slate-400'
                    }`}
                  >
                    All (3)
                  </button>
                  <button
                    onClick={() => setMapFilter('route')}
                    className={`px-3 py-1 rounded-lg transition cursor-pointer ${
                      mapFilter === 'route' ? 'bg-cyan-500 text-slate-800 font-black' : 'text-slate-400'
                    }`}
                  >
                    On Route
                  </button>
                  <button
                    onClick={() => setMapFilter('high_payout')}
                    className={`px-3 py-1 rounded-lg transition cursor-pointer ${
                      mapFilter === 'high_payout' ? 'bg-cyan-500 text-slate-800 font-black' : 'text-slate-400'
                    }`}
                  >
                    High Payout
                  </button>
                </div>
              )}

              <button
                onClick={handleToggleDeliveryMode}
                className={`px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-2 ${
                  isDeliveryModeActive
                    ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-800 shadow-lg shadow-cyan-500/30'
                    : 'bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/40'
                }`}
              >
                <Truck className="w-3.5 h-3.5" />
                <span>{isDeliveryModeActive ? 'DELIVERY MODE: ON' : 'TURN ON DELIVERY MODE'}</span>
              </button>
            </div>
          </div>

          {/* INTERACTIVE MAP VIEW */}
          <div className="relative w-full aspect-[16/9] sm:aspect-[21/9] bg-white rounded-3xl border border-slate-800 overflow-hidden shadow-inner flex items-center justify-center">
            {/* Background Map Grid & Roads Styling */}
            <div className="absolute inset-0 opacity-40 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px]" />

            {/* Stylized Highway & Street Vector Grid */}
            <svg className="absolute inset-0 w-full h-full stroke-slate-800/80 stroke-1 fill-none">
              <path d="M 0,120 Q 250,90 500,160 T 1000,140" strokeWidth="2" stroke="#334155" />
              <path d="M 150,0 Q 200,200 450,300 T 900,450" strokeWidth="2" stroke="#334155" />
              <path d="M 50,260 L 950,260" strokeDasharray="4 4" stroke="#1e293b" />
              <path d="M 600,0 L 600,500" strokeDasharray="4 4" stroke="#1e293b" />

              {/* Highlighted Active Route Polyline for Selected Opportunity */}
              {isDeliveryModeActive && (
                <path
                  d={`M ${activeSelectedOpp.coordinates.pickupX * 10},${
                    activeSelectedOpp.coordinates.pickupY * 4
                  } Q 500,180 ${activeSelectedOpp.coordinates.dropX * 10},${
                    activeSelectedOpp.coordinates.dropY * 4
                  }`}
                  stroke="#06b6d4"
                  strokeWidth="3"
                  strokeDasharray="6 4"
                  className="animate-pulse"
                />
              )}
            </svg>

            {/* Concentric Radar Range Rings */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-48 h-48 sm:w-72 sm:h-72 rounded-full border border-cyan-500/10" />
              <div className="w-80 h-80 sm:w-[32rem] sm:h-[32rem] rounded-full border border-cyan-500/5 absolute" />
              {isDeliveryModeActive && (
                <div className="w-24 h-24 rounded-full bg-cyan-500/10 border border-cyan-400/40 animate-ping absolute" />
              )}
            </div>

            {/* Current User Pin (Vijaynagar, Indore) */}
            <div
              className="absolute z-20 flex flex-col items-center transform -translate-x-1/2 -translate-y-1/2"
              style={{ left: '50%', top: '50%' }}
            >
              <div className="relative flex items-center justify-center">
                <div className="w-8 h-8 rounded-full bg-emerald-500 text-slate-800 font-black text-[10px] flex items-center justify-center shadow-xl shadow-emerald-500/50 border-2 border-white ring-4 ring-emerald-500/20">
                  YOU
                </div>
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 absolute -bottom-1 -right-1 ring-2 ring-slate-200" />
              </div>
              <span className="text-[10px] font-black text-emerald-300 bg-white/90 px-2 py-0.5 rounded-md border border-emerald-500/40 mt-1 shadow-md whitespace-nowrap">
                📍 Vijaynagar, Indore
              </span>
            </div>

            {/* Highlighted Delivery Opportunity Pins */}
            {isDeliveryModeActive &&
              filteredOpportunities.map((opp) => {
                const isSelected = selectedOpportunityId === opp.id;
                return (
                  <React.Fragment key={opp.id}>
                    {/* Pickup Pin */}
                    <button
                      onClick={() => setSelectedOpportunityId(opp.id)}
                      className={`absolute z-20 flex flex-col items-center transform -translate-x-1/2 -translate-y-1/2 transition-all cursor-pointer group ${
                        isSelected ? 'scale-110' : 'hover:scale-105 opacity-90'
                      }`}
                      style={{
                        left: `${opp.coordinates.pickupX}%`,
                        top: `${opp.coordinates.pickupY}%`,
                      }}
                    >
                      <div
                        className={`px-2.5 py-1 rounded-xl font-black text-[11px] flex items-center gap-1 shadow-2xl border ${
                          isSelected
                            ? 'bg-cyan-500 text-slate-800 border-white ring-4 ring-cyan-500/30'
                            : 'bg-slate-900/90 text-cyan-300 border-cyan-500/50'
                        }`}
                      >
                        <Store className="w-3 h-3" />
                        <span>₹{opp.payoutINR}</span>
                      </div>
                      <span className="text-[9px] font-bold text-slate-300 bg-slate-900/90 px-1.5 py-0.5 rounded border border-slate-700 mt-0.5 whitespace-nowrap">
                        {opp.storeName.split(' ')[0]} ({opp.pickupDistance})
                      </span>
                    </button>

                    {/* Drop Destination Pin */}
                    <div
                      className="absolute z-10 flex flex-col items-center transform -translate-x-1/2 -translate-y-1/2 pointer-events-none"
                      style={{
                        left: `${opp.coordinates.dropX}%`,
                        top: `${opp.coordinates.dropY}%`,
                      }}
                    >
                      <div className="w-6 h-6 rounded-lg bg-indigo-600/80 border border-indigo-400 text-white flex items-center justify-center shadow-lg">
                        <MapPin className="w-3.5 h-3.5" />
                      </div>
                      <span className="text-[9px] text-indigo-200 bg-white/80 px-1.5 py-0.2 rounded border border-indigo-800 mt-0.5 whitespace-nowrap">
                        Drop: {opp.customerAddress.split(',')[0]}
                      </span>
                    </div>
                  </React.Fragment>
                );
              })}

            {/* Offline Overlay Watermark if Delivery Mode is OFF */}
            {!isDeliveryModeActive && (
              <div className="absolute inset-0 bg-white/70 backdrop-blur-xs flex flex-col items-center justify-center text-center p-4 z-30">
                <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/30 mb-2">
                  <Crosshair className="w-6 h-6 animate-pulse" />
                </div>
                <h4 className="text-sm font-black text-white">Delivery Mode is Paused</h4>
                <p className="text-xs text-slate-400 max-w-sm mt-0.5">
                  Toggle on Delivery Mode to scan Indore city for active pickup orders that match your travel.
                </p>
                <button
                  onClick={handleToggleDeliveryMode}
                  className="mt-3 px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-800 font-black text-xs rounded-xl shadow-lg cursor-pointer"
                >
                  ACTIVATE RADAR & SHOW OPPORTUNITIES
                </button>
              </div>
            )}
          </div>

          {/* Interactive Selected Opportunity Action Card */}
          {isDeliveryModeActive && (
            <div className="bg-slate-900 border border-cyan-500/40 p-4 sm:p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/40 shrink-0 mt-0.5">
                  <Truck className="w-5 h-5" />
                </div>
                <div className="space-y-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-black text-white">{activeSelectedOpp.storeName}</span>
                    <span className="text-[10px] bg-cyan-950 text-cyan-300 px-2 py-0.5 rounded-full font-bold border border-cyan-700">
                      ⚡ {activeSelectedOpp.routeMatchPct}% Route Match
                    </span>
                    <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full font-bold">
                      📦 {activeSelectedOpp.parcelSize} Parcel
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">
                    Pickup: <strong className="text-white">{activeSelectedOpp.storeAddress}</strong> ➔ Drop:{' '}
                    <strong className="text-white">{activeSelectedOpp.customerAddress}</strong>
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Items: {activeSelectedOpp.itemsSummary} • Distance: {activeSelectedOpp.totalDistance} • Est.{' '}
                    {activeSelectedOpp.estTime}
                  </p>
                </div>
              </div>

              {/* Price & 1-Tap Accept Button */}
              <div className="flex items-center gap-3 shrink-0">
                <div className="text-right">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Instant Earning:</span>
                  <span className="text-lg font-black text-emerald-400">₹{activeSelectedOpp.payoutINR}</span>
                </div>

                <button
                  onClick={() => setIsSmartDeliveryDecisionOpen(true)}
                  className="px-5 py-3 bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-800 font-black text-xs rounded-xl shadow-lg shadow-cyan-500/30 transition cursor-pointer flex items-center gap-1.5"
                >
                  <span>ACCEPT & CARRY</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* AI QUERY RESULT (IF ACTIVE) */}
        {aiRecommendationQuery && (
          <div className="bg-white p-5 rounded-3xl border border-emerald-500/40 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>AI Recommendation: {aiRecommendationQuery}</span>
              </span>
              <button
                onClick={() => setAiRecommendationQuery(null)}
                className="text-xs text-slate-400 hover:text-white"
              >
                Clear
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {products.slice(0, 4).map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        )}

        {/* 5. "BUY WITHOUT LEAVING THE FEED" - SOCIAL REELS WITH INSTANT BUY */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <Play className="w-4 h-4 text-pink-400 fill-pink-400" />
                <span>Social Reels — Buy Without Leaving the Feed</span>
              </h3>
              <p className="text-xs text-slate-400">Discover trending looks and tap 1-Click Buy directly on the video</p>
            </div>

            <button
              onClick={() => setIsOneTapSellOpen(true)}
              className="text-xs font-bold text-pink-400 hover:text-pink-300 flex items-center gap-1"
            >
              <span>+ Create Reel</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {shortVideoReels.slice(0, 4).map((reel) => (
              <div
                key={reel.id}
                className="bg-white rounded-3xl border border-slate-800 overflow-hidden group hover:border-pink-500/50 transition-all flex flex-col justify-between"
              >
                <div className="relative aspect-[4/5] overflow-hidden bg-slate-900">
                  <img
                    src={reel.thumbnailUrl}
                    alt={reel.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80" />

                  {/* Creator info */}
                  <div className="absolute top-3 left-3 flex items-center gap-2 bg-white/70 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10">
                    <img src={reel.creatorAvatar} alt="" className="w-4 h-4 rounded-full" />
                    <span className="text-[10px] font-bold text-white">{reel.creatorName}</span>
                  </div>

                  {/* In-feed floating buy card */}
                  <div className="absolute bottom-3 inset-x-3 bg-slate-900/90 backdrop-blur-md p-3 rounded-2xl border border-white/20 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <div className="truncate pr-2">
                        <span className="font-black text-white block truncate">{reel.title}</span>
                        <span className="text-emerald-400 font-black">₹{reel.productPrice || '2,499'}</span>
                      </div>
                      <span className="text-[10px] text-slate-400">⭐ 4.8 • 1.8km</span>
                    </div>

                    <button
                      onClick={() => handleOneTapBuyReelProduct(reel)}
                      className="w-full py-2 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-400 hover:to-rose-400 text-white font-black text-xs rounded-xl shadow-lg transition cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>1-CLICK BUY NOW</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 6. NEARBY SELLERS & COMMUNITY BUSINESSES */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <Store className="w-4 h-4 text-emerald-400" />
                <span>People Selling Nearby (Indore Network)</span>
              </h3>
              <p className="text-xs text-slate-400">Verified local shops, home creators & artisan collectives</p>
            </div>

            <div className="flex items-center gap-1.5 bg-white p-1 rounded-xl border border-slate-800 text-xs font-bold">
              <button
                onClick={() => setGeoScope('nearby')}
                className={`px-3 py-1 rounded-lg transition ${
                  geoScope === 'nearby' ? 'bg-emerald-500 text-slate-800' : 'text-slate-400'
                }`}
              >
                Nearby (50km)
              </button>
              <button
                onClick={() => setGeoScope('india')}
                className={`px-3 py-1 rounded-lg transition ${
                  geoScope === 'india' ? 'bg-emerald-500 text-slate-800' : 'text-slate-400'
                }`}
              >
                India
              </button>
              <button
                onClick={() => setGeoScope('global')}
                className={`px-3 py-1 rounded-lg transition ${
                  geoScope === 'global' ? 'bg-emerald-500 text-slate-800' : 'text-slate-400'
                }`}
              >
                Global
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {sellers.slice(0, 3).map((seller) => (
              <div
                key={seller.id}
                className="bg-white border border-slate-800 hover:border-emerald-500/50 p-5 rounded-3xl space-y-4 transition"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={seller.logoUrl || seller.bannerUrl}
                      alt={seller.storeName}
                      className="w-12 h-12 rounded-2xl object-cover border border-slate-700"
                    />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h4 className="text-xs font-bold text-white">{seller.storeName}</h4>
                        {seller.isVerified && <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />}
                      </div>
                      <p className="text-[11px] text-slate-400">{seller.category} • {seller.city || 'Indore'}</p>
                    </div>
                  </div>

                  <span className="text-[10px] text-amber-400 font-black bg-amber-950/60 px-2 py-0.5 rounded-full border border-amber-800">
                    ★ {seller.rating}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                  <button
                    onClick={() => openStoreChat(seller.id)}
                    className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-xl font-bold flex items-center gap-1 border border-slate-800"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Ask Seller</span>
                  </button>

                  <button
                    onClick={() => openStoreCommunity(seller.id)}
                    className="px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-bold rounded-xl"
                  >
                    Visit Store
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 7. COMMUNITY FEED: GIVE FOR FREE & EXCHANGE / BARTER */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Give For Free Card */}
          <div className="bg-gradient-to-br from-cyan-950/60 via-slate-950 to-slate-950 p-6 rounded-3xl border border-cyan-500/40 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                <Gift className="w-4 h-4" />
                <span>GIVE FOR FREE — COMMUNITY GIFTING</span>
              </span>
              <span className="text-[10px] bg-cyan-950 text-cyan-300 px-2 py-0.5 rounded-full font-bold">
                100% Free
              </span>
            </div>

            <h4 className="text-sm font-extrabold text-white">
              Give away usable books, toys, furniture, or gadgets to neighbors
            </h4>
            <p className="text-xs text-slate-400">
              Nearby citizens can claim and community partners will deliver it for free.
            </p>

            <div className="pt-2">
              <button
                onClick={() => {
                  showToast('🎁 Free Community Giveaway opened! Post your item to neighbor feed.');
                  setIsProductExchangeOpen(true);
                }}
                className="px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-800 font-black text-xs rounded-xl shadow-lg transition cursor-pointer"
              >
                GIVE AN ITEM FOR FREE
              </button>
            </div>
          </div>

          {/* Peer Exchange & Barter Card */}
          <div className="bg-gradient-to-br from-purple-950/60 via-slate-950 to-slate-950 p-6 rounded-3xl border border-purple-500/40 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-purple-400 uppercase tracking-wider flex items-center gap-2">
                <Repeat className="w-4 h-4" />
                <span>PRODUCT EXCHANGE & SWAP</span>
              </span>
              <span className="text-[10px] bg-purple-950 text-purple-300 px-2 py-0.5 rounded-full font-bold">
                AI Fair-Value Match
              </span>
            </div>

            <h4 className="text-sm font-extrabold text-white">
              Exchange your phone, console, or accessories with cash difference
            </h4>
            <p className="text-xs text-slate-400">
              AI automatically checks condition grades and calculates fair cash adjustments.
            </p>

            <div className="pt-2">
              <button
                onClick={() => setIsProductExchangeOpen(true)}
                className="px-5 py-2.5 bg-purple-500 hover:bg-purple-400 text-white font-black text-xs rounded-xl shadow-lg transition cursor-pointer"
              >
                START A PRODUCT SWAP
              </button>
            </div>
          </div>
        </div>

        {/* 8. FOR YOU & TRENDING PRODUCTS GRID */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <Flame className="w-4 h-4 text-amber-400" />
                <span>Trending Near You (Free Community Delivery)</span>
              </h3>
              <p className="text-xs text-slate-400">Verified products backed by local neighbor delivery</p>
            </div>

            <button
              onClick={onViewCatalog}
              className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
            >
              <span>View All Catalog</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {products.slice(0, 8).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </div>

      {/* 5. FLOATING 'DELIVERY MODE' TOGGLE IN BOTTOM-RIGHT CORNER */}
      <div className="fixed bottom-20 right-4 sm:bottom-6 sm:right-6 z-40">
        <div
          className={`flex items-center gap-3 p-2 sm:p-2.5 rounded-full border backdrop-blur-xl transition-all duration-300 shadow-2xl ${
            isDeliveryModeActive
              ? 'bg-white/95 border-cyan-400 ring-4 ring-cyan-500/20 text-white shadow-cyan-500/20'
              : 'bg-slate-900/90 border-slate-700 text-slate-300 hover:border-cyan-500/50'
          }`}
        >
          {/* Quick Radar Icon / Status Indicator */}
          <div
            onClick={handleToggleDeliveryMode}
            className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center transition-all cursor-pointer ${
              isDeliveryModeActive
                ? 'bg-cyan-500 text-slate-800 shadow-lg shadow-cyan-500/50'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
            title="Toggle Delivery Mode"
          >
            <Truck className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>

          {/* Text & Earnings Label */}
          <div
            onClick={handleToggleDeliveryMode}
            className="cursor-pointer select-none pr-1 hidden xs:block"
          >
            <div className="flex items-center gap-1.5">
              <span
                className={`w-2 h-2 rounded-full ${
                  isDeliveryModeActive ? 'bg-cyan-400 animate-pulse' : 'bg-slate-500'
                }`}
              />
              <span className="text-xs font-black tracking-tight text-white">
                Delivery Mode: {isDeliveryModeActive ? 'ON' : 'OFF'}
              </span>
            </div>
            <span className="text-[10px] text-cyan-400 font-bold block">
              {isDeliveryModeActive ? '3 Nearby Matches (₹275)' : 'Earn ₹60–₹275 Nearby'}
            </span>
          </div>

          {/* Toggle Switch */}
          <button
            onClick={handleToggleDeliveryMode}
            aria-label="Toggle Delivery Mode"
            className={`w-12 h-6 sm:w-13 sm:h-7 rounded-full transition-colors relative cursor-pointer focus:outline-hidden p-0.5 ${
              isDeliveryModeActive ? 'bg-cyan-500' : 'bg-slate-800 border border-slate-700'
            }`}
          >
            <div
              className={`w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-white shadow-md transform transition-transform duration-200 flex items-center justify-center text-[10px] font-black text-slate-800 ${
                isDeliveryModeActive ? 'translate-x-6 sm:translate-x-6' : 'translate-x-0'
              }`}
            >
              {isDeliveryModeActive ? '✓' : ''}
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
