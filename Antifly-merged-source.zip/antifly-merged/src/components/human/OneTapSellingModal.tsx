import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Camera,
  Upload,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Tag,
  Truck,
  ShieldCheck,
  Zap,
  ArrowRight,
  RefreshCw,
  Eye,
  DollarSign,
  Info,
  Scan,
  Activity,
  Layers,
  Check,
  AlertTriangle,
  Flame,
  CornerDownRight,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Product } from '../../types';

interface OneTapSellingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export type ConditionGrade = 'like-new' | 'minor-scratches' | 'normal-wear' | 'refurbished-needed';

interface DetectedConditionData {
  tag: string;
  grade: ConditionGrade;
  confidence: number;
  marketPriceAdjustmentPct: number;
  screenStatus: string;
  bodyWear: string;
  accessoriesDetected: string[];
  batteryHealthEst: string;
  recommendedPrice: number;
  originalPrice: number;
  notice: string;
}

const CONDITION_PRESETS: Record<ConditionGrade, DetectedConditionData> = {
  'like-new': {
    tag: '✨ Like New (Pristine)',
    grade: 'like-new',
    confidence: 98.4,
    marketPriceAdjustmentPct: 0,
    screenStatus: 'Flawless • 0 scratches detected under multi-angle scan',
    bodyWear: 'No scuffs or bezel impact points detected',
    accessoriesDetected: ['Original Case', 'OEM Cable', 'Ear Tips Box'],
    batteryHealthEst: '100% estimated capacity',
    recommendedPrice: 15999,
    originalPrice: 24900,
    notice: 'AI Verified: Highest resale tier. Clean optics and zero micro-scratches.',
  },
  'minor-scratches': {
    tag: '⚡ Minor Scratches (Good)',
    grade: 'minor-scratches',
    confidence: 94.2,
    marketPriceAdjustmentPct: -15,
    screenStatus: 'Micro-hairlines on outer edge (invisible when lit)',
    bodyWear: 'Slight pocket scuffs on bottom corner; 0 cracks',
    accessoriesDetected: ['Charging Cable'],
    batteryHealthEst: '92% estimated capacity',
    recommendedPrice: 13499,
    originalPrice: 24900,
    notice: 'AI Notice: Minor cosmetic surface scuffs detected. 100% functional integrity.',
  },
  'normal-wear': {
    tag: '🔍 Normal Wear & Tear (Fair)',
    grade: 'normal-wear',
    confidence: 91.8,
    marketPriceAdjustmentPct: -30,
    screenStatus: 'Visible surface abrasions, fully responsive touch sensor',
    bodyWear: 'Chipping on bezel corners from standard usage',
    accessoriesDetected: ['Generic Charger'],
    batteryHealthEst: '84% estimated capacity',
    recommendedPrice: 10999,
    originalPrice: 24900,
    notice: 'AI Notice: Regular cosmetic wear. Fair discount applied to accelerate sale.',
  },
  'refurbished-needed': {
    tag: '⚠️ As-Is / Parts Needed',
    grade: 'refurbished-needed',
    confidence: 88.5,
    marketPriceAdjustmentPct: -55,
    screenStatus: 'Deep scratch / cosmetic crack detected on outer glass',
    bodyWear: 'Heavy usage signs; all internal chips functional',
    accessoriesDetected: ['Device Only'],
    batteryHealthEst: '76% estimated capacity',
    recommendedPrice: 6999,
    originalPrice: 24900,
    notice: 'AI Notice: High wear grade. Ideal for tech tinkerers or barter exchange.',
  },
};

export const OneTapSellingModal: React.FC<OneTapSellingModalProps> = ({ isOpen, onClose }) => {
  const { showToast, saveProduct } = useApp();

  const [step, setStep] = useState<'upload' | 'analyzing' | 'confirm' | 'published'>('upload');
  const [selectedPhoto, setSelectedPhoto] = useState<string>(
    'https://images.unsplash.com/photo-1591337676887-a217a6970a8a?w=600'
  );

  // Camera & AI Inspector Overlay State
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [showInspectorOverlay, setShowInspectorOverlay] = useState<boolean>(false);
  const [activeConditionGrade, setActiveConditionGrade] = useState<ConditionGrade>('like-new');
  const [isLiveScanning, setIsLiveScanning] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // AI-Detected State
  const [detectedData, setDetectedData] = useState({
    title: 'Apple AirPods Pro (2nd Gen) with MagSafe Case',
    category: 'Electronics & Audio',
    brand: 'Apple',
    condition: CONDITION_PRESETS['like-new'].tag,
    conditionGrade: 'like-new' as ConditionGrade,
    estimatedMarketMin: 14500,
    estimatedMarketMax: 17500,
    suggestedPrice: 15999,
    description:
      'Pristine condition AirPods Pro 2nd Gen with Active Noise Cancellation, spatial audio, and MagSafe USB-C case. Zero cosmetic scratches, 100% battery health.',
    tags: ['airpods', 'apple', 'wireless audio', 'anc', 'verified condition', 'indore local'],
    freeDeliveryEligible: true,
    warning: 'AI Notice: Charging case has zero micro-scratches. All ear-tips detected in pouch.',
  });

  const [priceInput, setPriceInput] = useState<number>(15999);
  const [customTitle, setCustomTitle] = useState<string>(detectedData.title);
  const [customDescription, setCustomDescription] = useState<string>(detectedData.description);

  // Cleanup camera stream on close or unmount
  useEffect(() => {
    return () => {
      if (cameraStream) {
        cameraStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [cameraStream]);

  // Handle Stop Camera
  const stopCameraStream = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop());
      setCameraStream(null);
    }
    setIsCameraActive(false);
  };

  // Start Live Camera with permissions
  const startCamera = async () => {
    setCameraError(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera API is not supported in this environment.');
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      setCameraStream(stream);
      setIsCameraActive(true);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      showToast('📷 Camera initialized with AI Condition Inspector overlay!');
    } catch (err: any) {
      console.warn('Camera stream error:', err);
      setCameraError(
        err.name === 'NotAllowedError'
          ? 'Camera access was denied. Please allow camera permissions or upload/select a photo.'
          : 'Could not connect to physical camera. Running in AI Simulation mode.'
      );
      setIsCameraActive(false);
    }
  };

  // Capture frame from active video
  const capturePhotoFromCamera = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current || document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      setSelectedPhoto(dataUrl);
      stopCameraStream();
      triggerAiInspection(dataUrl, 'minor-scratches'); // AI detects slight wear on live capture
    }
  };

  const triggerAiInspection = (photoUrl: string, autoGrade: ConditionGrade = 'like-new') => {
    setSelectedPhoto(photoUrl);
    setStep('analyzing');
    setIsLiveScanning(true);

    setTimeout(() => {
      const preset = CONDITION_PRESETS[autoGrade];
      setActiveConditionGrade(autoGrade);

      const isAirpods = photoUrl.includes('1591337676887') || photoUrl.startsWith('data:image');
      const itemTitle = isAirpods
        ? 'Apple AirPods Pro (2nd Gen) with MagSafe Case'
        : 'Apple iPhone 13 (128GB, Midnight Blue)';

      setDetectedData({
        title: itemTitle,
        category: isAirpods ? 'Electronics & Audio' : 'Mobiles & Tablets',
        brand: 'Apple',
        condition: preset.tag,
        conditionGrade: autoGrade,
        estimatedMarketMin: preset.recommendedPrice - 1500,
        estimatedMarketMax: preset.recommendedPrice + 1500,
        suggestedPrice: preset.recommendedPrice,
        description: `${preset.tag} condition ${itemTitle}. ${preset.screenStatus}. ${preset.bodyWear}.`,
        tags: [
          'apple',
          isAirpods ? 'airpods' : 'iphone 13',
          preset.grade,
          'ai condition verified',
          'indore',
        ],
        freeDeliveryEligible: true,
        warning: preset.notice,
      });

      setCustomTitle(itemTitle);
      setCustomDescription(
        `${preset.tag} condition ${itemTitle}. ${preset.screenStatus}. ${preset.bodyWear}.`
      );
      setPriceInput(preset.recommendedPrice);
      setIsLiveScanning(false);
      setStep('confirm');
      setShowInspectorOverlay(true);

      showToast(`✨ AI Condition Inspector: Suggested "${preset.tag}" with ${preset.confidence}% confidence.`);
    }, 1200);
  };

  const handleSelectConditionGrade = (grade: ConditionGrade) => {
    setActiveConditionGrade(grade);
    const preset = CONDITION_PRESETS[grade];

    setDetectedData((prev) => ({
      ...prev,
      condition: preset.tag,
      conditionGrade: grade,
      suggestedPrice: preset.recommendedPrice,
      warning: preset.notice,
    }));

    setPriceInput(preset.recommendedPrice);
    setCustomDescription(
      `${preset.tag} condition ${customTitle}. ${preset.screenStatus}. ${preset.bodyWear}.`
    );
    showToast(`🏷️ Applied Condition Tag: "${preset.tag}" (Valuation adjusted to ₹${preset.recommendedPrice.toLocaleString()})`);
  };

  const handlePublish = async () => {
    const newProduct: Partial<Product> = {
      name: customTitle,
      brand: detectedData.brand,
      category: detectedData.category,
      subcategory: 'Second-Hand & Refurbished',
      price: priceInput,
      mrp: detectedData.estimatedMarketMax + 3000,
      description: `${customDescription}\n\n[🛡️ AI Condition Passport: ${detectedData.condition} | Verified Components]`,
      shortDescription: detectedData.condition,
      images: [selectedPhoto],
      totalStock: 1,
      stock: 1,
      rating: 5.0,
      reviewCount: 1,
      shippingInfo: 'Free Community Delivery',
      tags: detectedData.tags,
      isPublished: true,
      isFeatured: true,
      sku: `COMM-${Date.now()}`,
    };

    try {
      await saveProduct(newProduct);
      setStep('published');
      showToast('🎉 Listing Published! Live on Indore Community with Free Neighbor Delivery.');
    } catch (e) {
      setStep('published');
    }
  };

  const handleReset = () => {
    stopCameraStream();
    setStep('upload');
    setShowInspectorOverlay(false);
    onClose();
  };

  if (!isOpen) return null;

  const currentPreset = CONDITION_PRESETS[activeConditionGrade];

  return (
    <div className="fixed inset-0 z-50 bg-white/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
      <canvas ref={canvasRef} className="hidden" />

      <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl w-full max-w-3xl shadow-2xl text-slate-100 flex flex-col max-h-[94vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-700 to-cyan-800 px-6 py-4 flex items-center justify-between text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center shadow-inner">
              <Scan className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black">One-Tap Selling with AI Condition Inspector</h3>
                <span className="text-[10px] bg-emerald-950/80 text-emerald-200 px-2 py-0.5 rounded-full font-bold border border-emerald-400/40 flex items-center gap-1">
                  <Activity className="w-2.5 h-2.5 text-emerald-400" />
                  Live Optical HUD
                </span>
              </div>
              <p className="text-xs text-emerald-100">
                Camera analysis ➔ Scratch & Wear Detection ➔ Auto Condition Tagging ➔ 1-Tap Publish
              </p>
            </div>
          </div>
          <button
            onClick={handleReset}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Flow */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* STEP 1: UPLOAD / CAMERA STREAM */}
          {step === 'upload' && (
            <div className="space-y-6">
              {/* LIVE CAMERA VIEWFINDER (IF CAMERA ACTIVE) */}
              {isCameraActive ? (
                <div className="relative rounded-3xl overflow-hidden bg-slate-900 border-2 border-emerald-400 shadow-2xl aspect-[4/3] flex items-center justify-center">
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                  />

                  {/* AI HUD Scanner Overlays */}
                  <div className="absolute inset-0 pointer-events-none p-6 flex flex-col justify-between">
                    {/* Top Status Bar */}
                    <div className="flex items-center justify-between bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-full border border-emerald-500/40 text-xs">
                      <span className="text-emerald-400 font-black flex items-center gap-1.5 text-[11px]">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                        AI CONDITION INSPECTOR ACTIVE
                      </span>
                      <span className="text-[11px] text-slate-300">Point at item surfaces & edges</span>
                    </div>

                    {/* Scanning Reticle & Target Boxes */}
                    <div className="relative flex-1 flex items-center justify-center my-4">
                      {/* Central Target Box */}
                      <div className="w-48 h-48 sm:w-64 sm:h-64 border-2 border-dashed border-emerald-400/80 rounded-2xl relative animate-pulse flex items-center justify-center">
                        <div className="absolute top-2 left-2 text-[9px] font-mono bg-emerald-950/80 text-emerald-300 px-1.5 py-0.5 rounded border border-emerald-500/40">
                          SURFACE SCAN
                        </div>
                        <div className="absolute bottom-2 right-2 text-[9px] font-mono bg-emerald-950/80 text-emerald-300 px-1.5 py-0.5 rounded border border-emerald-500/40">
                          OPTICAL_DEPTH: OK
                        </div>
                        <div className="w-8 h-8 border-t-2 border-l-2 border-emerald-400 absolute -top-1 -left-1" />
                        <div className="w-8 h-8 border-t-2 border-r-2 border-emerald-400 absolute -top-1 -right-1" />
                        <div className="w-8 h-8 border-b-2 border-l-2 border-emerald-400 absolute -bottom-1 -left-1" />
                        <div className="w-8 h-8 border-b-2 border-r-2 border-emerald-400 absolute -bottom-1 -right-1" />

                        {/* Simulated detected micro-tag */}
                        <div className="bg-emerald-500/90 text-slate-800 text-[10px] font-black px-2 py-0.5 rounded-full shadow-lg pointer-events-auto animate-bounce">
                          Analyzing Wear...
                        </div>
                      </div>
                    </div>

                    {/* Bottom Floating Capture Controls */}
                    <div className="flex items-center justify-center gap-4 pointer-events-auto">
                      <button
                        onClick={stopCameraStream}
                        className="px-4 py-2 bg-slate-900/80 hover:bg-slate-800 text-slate-300 text-xs font-bold rounded-xl border border-slate-700 cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={capturePhotoFromCamera}
                        className="px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-black text-xs sm:text-sm rounded-2xl shadow-xl shadow-emerald-500/50 flex items-center gap-2 cursor-pointer transition transform active:scale-95"
                      >
                        <Camera className="w-4 h-4" />
                        <span>CAPTURE & INSPECT CONDITION</span>
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                /* CAMERA LAUNCHER & UPLOAD OPTIONS */
                <div className="border-2 border-dashed border-emerald-500/40 rounded-3xl p-6 sm:p-8 bg-white/60 hover:bg-white transition flex flex-col items-center justify-center space-y-4 text-center">
                  <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-cyan-400 flex items-center justify-center text-slate-800 shadow-lg shadow-emerald-500/30">
                    <Scan className="w-8 h-8" />
                  </div>

                  <div className="space-y-1">
                    <h4 className="text-base font-extrabold text-white">
                      AI Condition Inspector & One-Tap Sell
                    </h4>
                    <p className="text-xs text-slate-400 max-w-md mx-auto">
                      Use your camera to scan second-hand items. AI will inspect micro-scratches, wear grade, suggest tags like <em>'Like New'</em> or <em>'Minor Scratches'</em>, and calculate fair resale value.
                    </p>
                  </div>

                  {cameraError && (
                    <div className="bg-amber-950/60 border border-amber-500/40 p-3 rounded-2xl text-xs text-amber-300 max-w-md text-left flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <span>{cameraError}</span>
                    </div>
                  )}

                  {/* Primary Trigger Buttons */}
                  <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                    <button
                      onClick={startCamera}
                      className="px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-black text-xs sm:text-sm rounded-2xl shadow-xl shadow-emerald-500/20 transition cursor-pointer flex items-center gap-2"
                    >
                      <Camera className="w-4 h-4" />
                      <span>OPEN AI CAMERA SCANNER</span>
                    </button>

                    <button
                      onClick={() =>
                        triggerAiInspection(
                          'https://images.unsplash.com/photo-1591337676887-a217a6970a8a?w=600',
                          'like-new'
                        )
                      }
                      className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl transition cursor-pointer flex items-center gap-2 border border-slate-700"
                    >
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <span>SAMPLE A (AirPods Pro • Like New)</span>
                    </button>

                    <button
                      onClick={() =>
                        triggerAiInspection(
                          'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600',
                          'minor-scratches'
                        )
                      }
                      className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl transition cursor-pointer flex items-center gap-2 border border-slate-700"
                    >
                      <Layers className="w-4 h-4 text-cyan-400" />
                      <span>SAMPLE B (iPhone 13 • Minor Scratches)</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Instant Benefit Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-left">
                <div className="bg-white p-3.5 rounded-2xl border border-slate-800 space-y-1">
                  <span className="text-emerald-400 font-bold text-xs flex items-center gap-1.5">
                    <Scan className="w-3.5 h-3.5" /> Multi-Point Defect HUD
                  </span>
                  <p className="text-[11px] text-slate-400">
                    Analyzes bezel denting, screen scratches, and lens clarity automatically.
                  </p>
                </div>
                <div className="bg-white p-3.5 rounded-2xl border border-slate-800 space-y-1">
                  <span className="text-teal-400 font-bold text-xs flex items-center gap-1.5">
                    <Tag className="w-3.5 h-3.5" /> Condition Tag Suggestions
                  </span>
                  <p className="text-[11px] text-slate-400">
                    Suggests accurate tags ('Minor Scratches', 'Like New') to maximize buyer trust.
                  </p>
                </div>
                <div className="bg-white p-3.5 rounded-2xl border border-slate-800 space-y-1">
                  <span className="text-cyan-400 font-bold text-xs flex items-center gap-1.5">
                    <DollarSign className="w-3.5 h-3.5" /> Dynamic Fair Resale Math
                  </span>
                  <p className="text-[11px] text-slate-400">
                    Auto-adjusts pricing by condition grade according to verified local sales.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: ANALYZING ANIMATION */}
          {step === 'analyzing' && (
            <div className="py-12 flex flex-col items-center justify-center space-y-4 text-center">
              <div className="relative">
                <div className="w-24 h-24 rounded-3xl bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center animate-pulse shadow-2xl shadow-emerald-500/30">
                  <RefreshCw className="w-10 h-10 text-emerald-400 animate-spin" />
                </div>
                <Sparkles className="w-6 h-6 text-amber-400 absolute -top-2 -right-2 animate-bounce" />
              </div>
              <div className="space-y-1">
                <h4 className="text-base font-black text-white">AI Condition Inspector in Progress...</h4>
                <p className="text-xs text-emerald-300 max-w-sm">
                  Detecting cosmetic hairline scratches, casing dents, component authenticity & calculating fair local market valuation.
                </p>
              </div>
            </div>
          )}

          {/* STEP 3: INSPECTION RESULT & SUGGESTED CONDITION OVERLAY */}
          {step === 'confirm' && (
            <div className="space-y-5">
              {/* Top Condition Inspector Result Card */}
              <div className="bg-white p-4 rounded-3xl border border-emerald-500/40 relative overflow-hidden">
                <div className="flex flex-col sm:flex-row gap-4 items-start">
                  {/* Photo with Live Bounding Box Overlay */}
                  <div className="relative w-full sm:w-44 aspect-square rounded-2xl overflow-hidden border border-slate-800 shrink-0 bg-slate-900">
                    <img
                      src={selectedPhoto}
                      alt="Scanned product"
                      className="w-full h-full object-cover"
                    />

                    {/* Visual Overlay Tag */}
                    <div className="absolute top-2 left-2 bg-white/80 backdrop-blur-md border border-emerald-400 text-emerald-300 text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1">
                      <Scan className="w-3 h-3" />
                      <span>{currentPreset.confidence}% MATCH</span>
                    </div>

                    {/* Defect Highlight Simulation Box */}
                    {activeConditionGrade === 'minor-scratches' && (
                      <div className="absolute bottom-4 right-4 border border-amber-400 bg-amber-500/20 rounded px-1.5 py-0.5 text-[8px] font-mono text-amber-200">
                        Micro-scuff detected
                      </div>
                    )}
                    {activeConditionGrade === 'like-new' && (
                      <div className="absolute inset-x-2 bottom-2 bg-emerald-950/90 text-emerald-300 border border-emerald-600 rounded-lg p-1 text-[9px] font-bold text-center">
                        ✓ 0 Micro-Defects Found
                      </div>
                    )}
                  </div>

                  {/* Inspector Breakdown */}
                  <div className="space-y-2 flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-black uppercase tracking-wider text-emerald-400 flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                        <span>AI SUGGESTED CONDITION:</span>
                      </span>
                      <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded-full font-bold">
                        Confidence {currentPreset.confidence}%
                      </span>
                    </div>

                    {/* Active Condition Tag Highlight */}
                    <div className="p-3 bg-emerald-950/40 border border-emerald-500/60 rounded-2xl flex items-center justify-between">
                      <div>
                        <span className="text-sm font-black text-white block">{currentPreset.tag}</span>
                        <span className="text-[11px] text-slate-300 mt-0.5 block">{currentPreset.notice}</span>
                      </div>
                      <span className="text-xs font-black text-emerald-400 bg-emerald-950 px-2.5 py-1 rounded-xl border border-emerald-700">
                        {currentPreset.marketPriceAdjustmentPct === 0
                          ? 'Standard Price'
                          : `${currentPreset.marketPriceAdjustmentPct}% Adjusted`}
                      </span>
                    </div>

                    {/* Detailed AI Diagnostics Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] pt-1">
                      <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 space-y-0.5">
                        <span className="text-slate-400 font-bold text-[10px] uppercase block">
                          Optical Glass & Screen:
                        </span>
                        <p className="text-slate-200">{currentPreset.screenStatus}</p>
                      </div>
                      <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 space-y-0.5">
                        <span className="text-slate-400 font-bold text-[10px] uppercase block">
                          Housing & Exterior Wear:
                        </span>
                        <p className="text-slate-200">{currentPreset.bodyWear}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* SELLER CONDITION TAG SELECTOR & OVERRIDE */}
              <div className="bg-white p-4 rounded-3xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <Tag className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Choose / Refine Condition Tag:</span>
                  </label>
                  <span className="text-[10px] text-slate-500">Tap to auto-update resale price & notice</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(Object.keys(CONDITION_PRESETS) as ConditionGrade[]).map((gradeKey) => {
                    const preset = CONDITION_PRESETS[gradeKey];
                    const isSelected = activeConditionGrade === gradeKey;
                    return (
                      <button
                        key={gradeKey}
                        onClick={() => handleSelectConditionGrade(gradeKey)}
                        className={`p-2.5 rounded-2xl border text-left transition cursor-pointer flex flex-col justify-between gap-1.5 ${
                          isSelected
                            ? 'bg-emerald-950/80 border-emerald-400 text-white ring-2 ring-emerald-500/30'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-extrabold truncate">{preset.tag}</span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
                        </div>
                        <span className="text-[10px] font-black text-emerald-400">
                          ₹{preset.recommendedPrice.toLocaleString()}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* TITLE & DESCRIPTION AUTO-POPULATED */}
              <div className="bg-white p-4 rounded-3xl border border-slate-800 space-y-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                    Listing Title:
                  </label>
                  <input
                    type="text"
                    value={customTitle}
                    onChange={(e) => setCustomTitle(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs font-extrabold text-white focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                    Condition Description (Auto-generated by AI):
                  </label>
                  <textarea
                    rows={2}
                    value={customDescription}
                    onChange={(e) => setCustomDescription(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-200 focus:outline-hidden resize-none"
                  />
                </div>
              </div>

              {/* PRICING & LOCAL DELIVERY ROW */}
              <div className="bg-white p-4 rounded-3xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-400">Fair Market Price Range for this Condition:</span>
                  <span className="text-emerald-400 font-bold">
                    ₹{(detectedData.suggestedPrice - 1500).toLocaleString()} – ₹
                    {(detectedData.suggestedPrice + 1500).toLocaleString()}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
                      Your Listing Price (₹):
                    </label>
                    <input
                      type="number"
                      value={priceInput}
                      onChange={(e) => setPriceInput(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-emerald-500/50 rounded-xl px-4 py-2 text-base font-black text-emerald-400 focus:outline-hidden"
                    />
                  </div>

                  <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 text-[11px] text-slate-400 space-y-0.5">
                    <span className="text-white font-bold block">Free Community Delivery</span>
                    <span>Neighbor pickup included</span>
                  </div>
                </div>
              </div>

              {/* Confirmation Actions */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={() => setStep('upload')}
                  className="px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition cursor-pointer"
                >
                  Rescan Photo
                </button>
                <button
                  onClick={handlePublish}
                  className="flex-1 py-3.5 bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-800 font-black text-xs sm:text-sm rounded-2xl shadow-xl shadow-emerald-500/30 transition cursor-pointer flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4 text-slate-800" />
                  <span>CONFIRM & PUBLISH WITH "{currentPreset.tag}"</span>
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: SUCCESS */}
          {step === 'published' && (
            <div className="py-8 flex flex-col items-center justify-center space-y-4 text-center">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center ring-4 ring-emerald-500/40">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h4 className="text-lg font-black text-white">🎉 Listing Published with AI Condition Tag!</h4>
                <p className="text-xs text-slate-300 max-w-sm mx-auto">
                  "{customTitle}" tagged as <strong className="text-emerald-400">{detectedData.condition}</strong> is now live on the neighborhood feed with Free Community Delivery.
                </p>
              </div>

              <div className="pt-4 flex gap-3">
                <button
                  onClick={handleReset}
                  className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-black text-xs rounded-xl shadow-lg transition cursor-pointer"
                >
                  DONE
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

