import React, { useState } from 'react';
import {
  X,
  MapPin,
  Clock,
  DollarSign,
  Package,
  CheckCircle2,
  QrCode,
  ShieldCheck,
  Navigation,
  ArrowRight,
  AlertTriangle,
  RefreshCw,
  Phone,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface SmartDeliveryCardModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SmartDeliveryCardModal: React.FC<SmartDeliveryCardModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { showToast, smartRecoverCancelledDelivery } = useApp();

  const [deliveryState, setDeliveryState] = useState<'decision' | 'accepted' | 'picked_up' | 'delivered'>('decision');
  const [pickupOTP, setPickupOTP] = useState<string>('8492');
  const [deliveryOTP, setDeliveryOTP] = useState<string>('3159');
  const [enteredOTP, setEnteredOTP] = useState<string>('');
  const [otpError, setOtpError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAccept = () => {
    setDeliveryState('accepted');
    showToast('🚀 Delivery Accepted! Head to Pickup at Vijay Nagar (1.8 km).');
  };

  const handleVerifyPickup = () => {
    if (enteredOTP === pickupOTP || enteredOTP === '8492') {
      setDeliveryState('picked_up');
      setEnteredOTP('');
      setOtpError(null);
      showToast('✓ Pickup Verified! Parcel safely in transit to Palasia.');
    } else {
      setOtpError('Invalid OTP. Please ask seller for 4-digit Pickup Code.');
    }
  };

  const handleVerifyDelivery = () => {
    if (enteredOTP === deliveryOTP || enteredOTP === '3159') {
      setDeliveryState('delivered');
      setEnteredOTP('');
      setOtpError(null);
      showToast('🎉 Delivered successfully! ₹75 added instantly to your wallet.');
    } else {
      setOtpError('Invalid OTP. Please ask customer for Delivery Confirmation Code.');
    }
  };

  const handleCancelSim = () => {
    smartRecoverCancelledDelivery('del-8839');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl w-full max-w-lg shadow-2xl text-slate-100 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-700 px-6 py-4 flex items-center justify-between text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center">
              <Navigation className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black">Smart Community Delivery</h3>
              <p className="text-xs text-emerald-100">Zero-confusion, instant 5-second decision</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* STAGE 1: 5-SECOND DECISION CARD */}
          {deliveryState === 'decision' && (
            <div className="space-y-5">
              <div className="bg-white p-5 rounded-2xl border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2.5 py-0.5 rounded-full font-bold">
                    ⚡ Same Direction as Your Route
                  </span>
                  <span className="text-xs font-mono text-slate-400">#ORD-9921</span>
                </div>

                {/* Route visualization */}
                <div className="space-y-3 relative pl-6 border-l-2 border-dashed border-slate-800 ml-2">
                  <div className="relative">
                    <span className="absolute -left-[31px] top-0.5 w-4 h-4 rounded-full bg-emerald-500 ring-4 ring-slate-900" />
                    <span className="text-[10px] font-bold text-slate-400 uppercase block">Pickup Location</span>
                    <p className="text-xs font-bold text-white">Vijay Nagar Market, Indore (1.8 km)</p>
                  </div>

                  <div className="relative pt-2">
                    <span className="absolute -left-[31px] top-2.5 w-4 h-4 rounded-full bg-cyan-500 ring-4 ring-slate-900" />
                    <span className="text-[10px] font-bold text-slate-400 uppercase block">Destination</span>
                    <p className="text-xs font-bold text-white">Old Palasia Colony, Indore (8.4 km)</p>
                  </div>
                </div>

                {/* 4 Core Metrics */}
                <div className="grid grid-cols-3 gap-2 pt-3 border-t border-slate-800 text-center">
                  <div className="bg-slate-900 p-2 rounded-xl">
                    <span className="text-[10px] text-slate-400 block">Time</span>
                    <span className="text-xs font-black text-white">28 mins</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-xl">
                    <span className="text-[10px] text-slate-400 block">Parcel</span>
                    <span className="text-xs font-black text-white">Small (0.8kg)</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-xl">
                    <span className="text-[10px] text-slate-400 block">Detour</span>
                    <span className="text-xs font-black text-emerald-400">+1.2 km</span>
                  </div>
                </div>

                {/* Total Earning */}
                <div className="bg-emerald-950/60 border border-emerald-500/40 p-3.5 rounded-xl flex items-center justify-between">
                  <span className="text-xs text-slate-300 font-medium">You Can Earn:</span>
                  <span className="text-xl font-black text-emerald-400">₹75</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <button
                  onClick={onClose}
                  className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 text-xs font-bold transition cursor-pointer"
                >
                  Decline
                </button>
                <button
                  onClick={handleAccept}
                  className="flex-1 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-black text-sm rounded-xl shadow-xl shadow-emerald-500/20 transition cursor-pointer flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>ACCEPT DELIVERY (₹75)</span>
                </button>
              </div>
            </div>
          )}

          {/* STAGE 2: ACCEPTED -> GO TO PICKUP */}
          {deliveryState === 'accepted' && (
            <div className="space-y-4">
              <div className="bg-white p-4 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5" /> Step 1: Seller Pickup
                  </span>
                  <span className="text-[10px] text-slate-400">Vijay Nagar • 1.8 km away</span>
                </div>

                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 text-xs space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Seller Contact:</span>
                  <p className="text-white font-bold">Shree Sweets & Snacks (Vijay Nagar)</p>
                  <p className="text-slate-400 text-[11px]">+91 98260 55443 • Prepared & Packed</p>
                </div>

                <div className="space-y-2 pt-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase block">
                    Enter Seller 4-Digit Pickup OTP (or use demo code: 8492):
                  </label>
                  <input
                    type="text"
                    maxLength={4}
                    placeholder="Enter 4-digit code"
                    value={enteredOTP}
                    onChange={(e) => setEnteredOTP(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-center font-mono text-lg font-black tracking-widest text-emerald-400 focus:outline-hidden"
                  />
                  {otpError && <p className="text-xs text-rose-400">{otpError}</p>}
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={handleCancelSim}
                  className="px-3 py-2.5 bg-slate-800 text-slate-400 hover:text-white rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  Need to Cancel
                </button>
                <button
                  onClick={handleVerifyPickup}
                  className="flex-1 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-black text-xs rounded-xl shadow-lg transition cursor-pointer"
                >
                  VERIFY PICKUP & START TRIP
                </button>
              </div>
            </div>
          )}

          {/* STAGE 3: PICKED UP -> IN TRANSIT TO CUSTOMER */}
          {deliveryState === 'picked_up' && (
            <div className="space-y-4">
              <div className="bg-white p-4 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                    <Navigation className="w-3.5 h-3.5" /> Step 2: In Transit to Customer
                  </span>
                  <span className="text-[10px] text-emerald-300">Arriving in ~18 Mins</span>
                </div>

                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 text-xs space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Delivery Address:</span>
                  <p className="text-white font-bold">Aarav Sharma • Flat 402, Royal Palms, Old Palasia</p>
                  <p className="text-slate-400 text-[11px]">Contact: +91 98200 11223</p>
                </div>

                <div className="space-y-2 pt-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase block">
                    Enter Customer 4-Digit Delivery Code (or use demo code: 3159):
                  </label>
                  <input
                    type="text"
                    maxLength={4}
                    placeholder="Enter 4-digit code"
                    value={enteredOTP}
                    onChange={(e) => setEnteredOTP(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-center font-mono text-lg font-black tracking-widest text-cyan-400 focus:outline-hidden"
                  />
                  {otpError && <p className="text-xs text-rose-400">{otpError}</p>}
                </div>
              </div>

              <button
                onClick={handleVerifyDelivery}
                className="w-full py-3 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-800 font-black text-xs rounded-xl shadow-xl transition cursor-pointer"
              >
                COMPLETE DELIVERY & CLAIM ₹75
              </button>
            </div>
          )}

          {/* STAGE 4: DELIVERED SUCCESS */}
          {deliveryState === 'delivered' && (
            <div className="py-6 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center ring-4 ring-emerald-500/40">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h4 className="text-lg font-black text-white">💰 You Earned ₹75!</h4>
                <p className="text-xs text-slate-300">
                  You helped Aarav receive their package on time. Total today: ₹315.
                </p>
              </div>

              <button
                onClick={onClose}
                className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-black text-xs rounded-xl shadow-lg transition cursor-pointer"
              >
                CLOSE
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
