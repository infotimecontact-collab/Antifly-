import React, { useState } from 'react';
import {
  X,
  User,
  ShoppingBag,
  Store,
  Truck,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  Award,
  Flame,
  Star,
  DollarSign,
  ArrowRight,
  TrendingUp,
  MapPin,
  Clock,
  Heart,
  ChevronRight,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface UniversalProfileIdentityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UniversalProfileIdentityModal: React.FC<UniversalProfileIdentityModalProps> = ({
  isOpen,
  onClose,
}) => {
  const {
    currentCustomer,
    userUniversalCapabilities,
    toggleUserUniversalCapability,
    showToast,
    setIsOneTapSellOpen,
    setIsDestinationDetourOpen,
    setIsTimeToEarnOpen,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'identity' | 'earnings' | 'achievements'>('identity');
  const [vehicle, setVehicle] = useState<string>('EV Two-Wheeler (Ather 450X)');
  const [deliveryMaxDistance, setDeliveryMaxDistance] = useState<number>(25);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl w-full max-w-2xl shadow-2xl text-slate-100 flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 px-6 py-5 flex items-center justify-between text-white">
          <div className="flex items-center gap-3.5">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"
                alt="Avatar"
                className="w-12 h-12 rounded-2xl object-cover border-2 border-white/40 shadow-md"
              />
              <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-400 border-2 border-slate-900 rounded-full" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black">{currentCustomer?.name || 'Aarav Sharma'}</h3>
                <span className="text-[10px] bg-emerald-950/80 text-emerald-200 px-2 py-0.5 rounded-full font-bold border border-emerald-400/40 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> Verified Citizen
                </span>
              </div>
              <p className="text-xs text-emerald-100 flex items-center gap-1">
                <MapPin className="w-3 h-3" /> Indore, MP • 98 Successful Deliveries • 4.9 ★ Rating
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-white px-6 pt-2">
          <button
            onClick={() => setActiveTab('identity')}
            className={`py-3 px-4 text-xs font-black border-b-2 transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'identity'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Universal Capabilities</span>
          </button>

          <button
            onClick={() => setActiveTab('earnings')}
            className={`py-3 px-4 text-xs font-black border-b-2 transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'earnings'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span>Earnings Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('achievements')}
            className={`py-3 px-4 text-xs font-black border-b-2 transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'achievements'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>Badges & Reputation</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: UNIVERSAL CAPABILITIES */}
          {activeTab === 'identity' && (
            <div className="space-y-5">
              <div className="bg-white p-4 rounded-2xl border border-slate-800 space-y-1">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">
                  ONE ACCOUNT — MULTIPLE POSSIBILITIES
                </span>
                <p className="text-xs text-slate-300">
                  You never need separate customer, seller, or driver accounts. Activate capabilities on-the-fly with a single tap.
                </p>
              </div>

              {/* Capabilities Grid */}
              <div className="space-y-3">
                {/* 1. Buying */}
                <div className="bg-white border border-slate-800 p-4 rounded-2xl flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                      <ShoppingBag className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">🛍️ Buying & Discovering</h4>
                      <p className="text-[11px] text-slate-400">Order from nearby or global sellers with Free Community Delivery.</p>
                    </div>
                  </div>

                  <span className="px-3 py-1 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-bold">
                    ALWAYS ON
                  </span>
                </div>

                {/* 2. Selling */}
                <div className="bg-white border border-slate-800 p-4 rounded-2xl flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center">
                      <Store className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">🏪 Selling & Listing</h4>
                      <p className="text-[11px] text-slate-400">Turn any item into a live listing in 5 seconds with AI detection.</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {userUniversalCapabilities.selling && (
                      <button
                        onClick={() => {
                          onClose();
                          setIsOneTapSellOpen(true);
                        }}
                        className="px-2.5 py-1 bg-teal-600 hover:bg-teal-500 text-white rounded-lg text-[10px] font-bold cursor-pointer"
                      >
                        + SELL ITEM
                      </button>
                    )}
                    <button
                      onClick={() => toggleUserUniversalCapability('selling')}
                      className={`px-3 py-1 rounded-full text-xs font-black transition cursor-pointer ${
                        userUniversalCapabilities.selling
                          ? 'bg-teal-500 text-slate-800 shadow-md'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {userUniversalCapabilities.selling ? 'ON' : 'OFF'}
                    </button>
                  </div>
                </div>

                {/* 3. Delivery / Help */}
                <div className="bg-white border border-slate-800 p-4 rounded-2xl flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                      <Truck className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">🚚 Community Delivery & Earning</h4>
                      <p className="text-[11px] text-slate-400">Carry packages on your route or monetise spare time.</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {userUniversalCapabilities.delivery && (
                      <button
                        onClick={() => {
                          onClose();
                          setIsDestinationDetourOpen(true);
                        }}
                        className="px-2.5 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-[10px] font-bold cursor-pointer"
                      >
                        MATCH ROUTE
                      </button>
                    )}
                    <button
                      onClick={() => toggleUserUniversalCapability('delivery')}
                      className={`px-3 py-1 rounded-full text-xs font-black transition cursor-pointer ${
                        userUniversalCapabilities.delivery
                          ? 'bg-cyan-500 text-slate-800 shadow-md'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {userUniversalCapabilities.delivery ? 'ON' : 'OFF'}
                    </button>
                  </div>
                </div>

                {/* 4. Creator */}
                <div className="bg-white border border-slate-800 p-4 rounded-2xl flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-pink-500/20 text-pink-400 flex items-center justify-center">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">🎨 Social Creator & Reels</h4>
                      <p className="text-[11px] text-slate-400">Publish video reels, tag products, and earn creator commissions.</p>
                    </div>
                  </div>

                  <button
                    onClick={() => toggleUserUniversalCapability('creator')}
                    className={`px-3 py-1 rounded-full text-xs font-black transition cursor-pointer ${
                      userUniversalCapabilities.creator
                        ? 'bg-pink-500 text-white shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {userUniversalCapabilities.creator ? 'ON' : 'OFF'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: EARNINGS DASHBOARD */}
          {activeTab === 'earnings' && (
            <div className="space-y-5">
              {/* Today summary */}
              <div className="bg-gradient-to-br from-emerald-950 via-slate-950 to-teal-950 p-5 rounded-3xl border border-emerald-500/30 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                    TODAY'S EARNINGS
                  </span>
                  <span className="text-[10px] bg-emerald-900/60 text-emerald-300 px-2 py-0.5 rounded-full font-mono">
                    Updated 2m ago
                  </span>
                </div>

                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black text-white">₹240</span>
                  <span className="text-xs text-emerald-400 font-bold">earned today</span>
                </div>

                <div className="grid grid-cols-3 gap-2 pt-2 border-t border-emerald-900/40 text-center">
                  <div className="bg-slate-900/60 p-2.5 rounded-xl">
                    <span className="text-xs font-bold text-slate-300 block">3</span>
                    <span className="text-[10px] text-slate-400">Deliveries</span>
                  </div>
                  <div className="bg-slate-900/60 p-2.5 rounded-xl">
                    <span className="text-xs font-bold text-slate-300 block">28 km</span>
                    <span className="text-[10px] text-slate-400">Route Covered</span>
                  </div>
                  <div className="bg-slate-900/60 p-2.5 rounded-xl">
                    <span className="text-xs font-bold text-amber-400 block">4.9 ★</span>
                    <span className="text-[10px] text-slate-400">Rating</span>
                  </div>
                </div>
              </div>

              {/* Weekly and Monthly */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white p-4 rounded-2xl border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">This Week</span>
                  <p className="text-lg font-black text-emerald-400">₹1,280</p>
                  <span className="text-[10px] text-slate-500">14 drops completed</span>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">This Month</span>
                  <p className="text-lg font-black text-teal-400">₹5,420</p>
                  <span className="text-[10px] text-slate-500">62 drops completed</span>
                </div>
              </div>

              {/* Instant Action buttons */}
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    onClose();
                    setIsDestinationDetourOpen(true);
                  }}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-slate-800 font-black text-xs rounded-xl transition cursor-pointer shadow-md text-center"
                >
                  🚗 ON MY WAY (ROUTE MATCH)
                </button>
                <button
                  onClick={() => {
                    onClose();
                    setIsTimeToEarnOpen(true);
                  }}
                  className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-black text-xs rounded-xl transition cursor-pointer shadow-md text-center"
                >
                  ⏱️ I HAVE FREE TIME (15m–2h)
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: ACHIEVEMENTS & GAMIFICATION */}
          {activeTab === 'achievements' && (
            <div className="space-y-4">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                Community Reputation Badges
              </span>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white border border-amber-500/40 p-3.5 rounded-2xl space-y-1">
                  <span className="text-base">🏆 Community Hero</span>
                  <p className="text-[11px] text-slate-400">Top 5% timely deliveries in Indore district.</p>
                </div>

                <div className="bg-white border border-emerald-500/40 p-3.5 rounded-2xl space-y-1">
                  <span className="text-base">⭐ Trusted Partner</span>
                  <p className="text-[11px] text-slate-400">100% OTP safe verification record.</p>
                </div>

                <div className="bg-white border border-orange-500/40 p-3.5 rounded-2xl space-y-1">
                  <span className="text-base">🔥 7-Day Streak</span>
                  <p className="text-[11px] text-slate-400">Active community helper for 7 straight days.</p>
                </div>

                <div className="bg-white border border-cyan-500/40 p-3.5 rounded-2xl space-y-1">
                  <span className="text-base">🚀 100 Deliveries</span>
                  <p className="text-[11px] text-slate-400">98 / 100 achieved (2 drops to milestone!)</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
