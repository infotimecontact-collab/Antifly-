import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Compass,
  MapPin,
  Sparkles,
  Plane,
  X,
  Clock,
  Navigation,
  Luggage,
  Award,
  Zap,
  CheckCircle2,
  Calendar,
  Flame,
  ChevronRight,
  ShieldCheck,
  RotateCcw,
  Camera,
  Coffee,
  Sun,
  Moon,
  CloudRain,
  Mountain,
  Palmtree,
  Tent,
  Send,
  Sliders,
  Star,
  Layers,
} from 'lucide-react';
import { JustAwayEscape, JustAwayGearKit } from '../../types';

interface JustAwayHubModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const JustAwayHubModal: React.FC<JustAwayHubModalProps> = ({ isOpen, onClose }) => {
  const {
    justAwayEscapes,
    justAwayGearKits,
    justAwayNomadStamps,
    driftMilesBalance,
    addDriftMiles,
    awayModeActive,
    toggleAwayMode,
    bookJustAwayEscape,
    claimWanderKitTrial,
    showToast,
    userLocation,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'escapes' | 'gear' | 'radar' | 'ooo' | 'passport'>('escapes');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeEscapeDetail, setActiveEscapeDetail] = useState<JustAwayEscape | null>(null);

  // OOO Trip Generator state
  const [driveDistancePref, setDriveDistancePref] = useState<'short' | 'medium' | 'deep'>('medium');
  const [travelMood, setTravelMood] = useState<'Serenity' | 'Adrenaline' | 'Heritage' | 'Solitude'>('Serenity');
  const [generatedTripPlan, setGeneratedTripPlan] = useState<{
    title: string;
    route: string;
    driveTime: string;
    stops: string[];
    gearKit: string;
    totalBudget: number;
    driftMiles: number;
  } | null>(null);
  const [isGeneratingTrip, setIsGeneratingTrip] = useState(false);

  if (!isOpen) return null;

  const categories = ['All', 'Serene Nature', 'Off-Grid Cabin', 'Mountain Trail', 'Heritage Trail', 'Sunset Coast', 'Nomadic Camping'];

  const filteredEscapes = selectedCategory === 'All'
    ? justAwayEscapes
    : justAwayEscapes.filter((e) => e.category === selectedCategory);

  const handleGenerateOOOTrip = () => {
    setIsGeneratingTrip(true);
    setTimeout(() => {
      if (travelMood === 'Serenity') {
        setGeneratedTripPlan({
          title: 'Narmada River Gorges & Hidden Rock Pools Escape',
          route: `${userLocation.city || 'Indore'} → Maheshwar Ghats → Omkareshwar Quiet Island`,
          driveTime: '2h 10m Scenic Drive',
          stops: [
            'Sunrise meditation on Ahilya Fort stone balconies',
            'Fresh sugar cane juice & handloom weaver workshop',
            'Private wooden boat drift to secluded river bend',
            'Starlit bonfire and organic Malwa dinner',
          ],
          gearKit: 'Waterproof Daypack + Breathable Linen Set',
          totalBudget: 3200,
          driftMiles: 340,
        });
      } else if (travelMood === 'Heritage') {
        setGeneratedTripPlan({
          title: 'Mandu Lost Kingdom & Stargazing Citadel',
          route: `${userLocation.city || 'Indore'} → Dhar Forest Pass → Mandu Plateau Edge`,
          driveTime: '1h 55m Smooth Highway',
          stops: [
            'Acoustic echo experiment in Baz Bahadur palace',
            'Sunset view over 1000ft Nimar Valley canyon',
            'Local Baobab fruit tasting & heritage walk',
            'Night astronomical stargazing from Rupmati Pavilion',
          ],
          gearKit: 'Polarized Sunglasses + Ultralight Rucksack',
          totalBudget: 2800,
          driftMiles: 290,
        });
      } else if (travelMood === 'Adrenaline') {
        setGeneratedTripPlan({
          title: 'Satpura Highland Forest Safari & Waterfall Trek',
          route: `${userLocation.city || 'Indore'} → Hoshangabad Gorges → Pachmarhi High Ridge`,
          driveTime: '5h 45m Mountain Pass',
          stops: [
            '4x4 Jeep trail through dense teak and sal woods',
            'Scramble down Bee Falls crystal rock pools',
            'Cave exploration with prehistoric rock paintings',
            'Highland pine campfire & acoustic guitar jam',
          ],
          gearKit: 'Vibram Trail Boots + 4K Action Camera',
          totalBudget: 4800,
          driftMiles: 750,
        });
      } else {
        setGeneratedTripPlan({
          title: 'Chikhaldara Deep Mist & Wild Coffee Grove Solitude',
          route: `${userLocation.city || 'Indore'} → Melghat Buffer Hills → Chikhaldara Ridge`,
          driveTime: '4h 15m Forest Stretch',
          stops: [
            'Freshly harvested Arabica coffee roasting session',
            'Solitary cliff walk along Hurricane Point',
            'Zero digital noise journal writing session',
            'Tribal Gond herbal tea & stargazing pod',
          ],
          gearKit: 'All-Weather Shell Jacket + Solar Camp Pod',
          totalBudget: 3900,
          driftMiles: 520,
        });
      }
      setIsGeneratingTrip(false);
      showToast('⚡ Spontaneous Getaway Itinerary Generated in 1.4s!');
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-white/85 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-5xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-amber-500/30 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Top Glow & Shimmer Accent */}
        <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-amber-400 via-orange-500 to-rose-500 animate-pulse" />

        {/* Modal Header & Brand Identity Banner */}
        <div className="p-4 sm:p-6 border-b border-slate-800 bg-white/60 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-600 flex items-center justify-center text-slate-800 font-black shadow-lg shadow-orange-500/20 flex-shrink-0">
              <Compass className="w-6 h-6 animate-spin text-white drop-shadow" style={{ animationDuration: '24s' }} />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl sm:text-2xl font-black tracking-tight text-white">
                  Just<span className="text-amber-400">Away</span>
                </span>
                <span className="bg-gradient-to-r from-amber-500 to-orange-500 text-slate-800 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider shadow-sm">
                  Just go. Just away.
                </span>
              </div>
              <p className="text-xs text-slate-300 font-medium mt-0.5 flex items-center gap-1.5">
                <span>Freedom</span>
                <span className="text-amber-400">•</span>
                <span>Movement</span>
                <span className="text-amber-400">•</span>
                <span>Travel</span>
                <span className="text-amber-400">•</span>
                <span className="text-amber-300 font-semibold">Away from the ordinary • Anywhere, Anytime</span>
              </p>
            </div>
          </div>

          {/* Top Quick Actions & AwayMode Toggle */}
          <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
            {/* DriftMiles Wallet Badge */}
            <div
              onClick={() => {
                addDriftMiles(50, 'Daily Nomad Check-In');
              }}
              title="Click to claim daily DriftMiles reward (+50)"
              className="px-3 py-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-800 border border-amber-500/30 text-amber-300 flex items-center gap-1.5 text-xs font-bold transition cursor-pointer shadow-inner"
            >
              <Award className="w-4 h-4 text-amber-400 animate-bounce" />
              <span>{driftMilesBalance.toLocaleString()} DriftMiles™</span>
            </div>

            {/* AwayMode Switch */}
            <button
              onClick={toggleAwayMode}
              className={`px-3 py-1.5 rounded-xl border flex items-center gap-2 text-xs font-black transition cursor-pointer ${
                awayModeActive
                  ? 'bg-emerald-500 text-slate-800 border-emerald-400 shadow-md shadow-emerald-500/30'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              }`}
            >
              <Zap className={`w-3.5 h-3.5 ${awayModeActive ? 'text-slate-800 fill-current' : 'text-amber-400'}`} />
              <span>{awayModeActive ? 'AwayMode ACTIVE' : 'Turn On AwayMode'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation Navigation Strip */}
        <div className="px-4 sm:px-6 bg-slate-900/90 border-b border-slate-800 flex items-center gap-2 overflow-x-auto no-scrollbar py-2.5">
          {[
            { id: 'escapes', label: '⚡ 1-Tap Escapes ("Just Go")', icon: Flame },
            { id: 'gear', label: '🎒 WanderKits™ (Try-Before-You-Fly)', icon: Luggage },
            { id: 'radar', label: '🧭 WanderPulse™ Movement Radar', icon: Navigation },
            { id: 'ooo', label: '🗺️ OutOfOffice (OOO) Generator', icon: Sliders },
            { id: 'passport', label: '🛂 NomadPassport & Stamps', icon: Award },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all flex-shrink-0 cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-800 shadow-md shadow-orange-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Main Tab Content Canvas */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: 1-TAP SPONTANEOUS GETAWAYS */}
          {activeTab === 'escapes' && (
            <div className="space-y-5">
              {/* Motto Banner */}
              <div className="bg-gradient-to-r from-amber-950/70 via-slate-900 to-orange-950/70 border border-amber-500/40 p-4 sm:p-5 rounded-2xl flex flex-wrap items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs uppercase tracking-widest font-black text-amber-400">
                      Spontaneous Weekend Escapes
                    </span>
                    <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-black px-2 py-0.5 rounded-full border border-emerald-500/30">
                      ⚡ 1-Tap Booking • ₹0 Free Cancellation
                    </span>
                  </div>
                  <h3 className="text-lg font-black text-white">
                    Step Away From The Routine. Leave Tonight or Tomorrow.
                  </h3>
                  <p className="text-xs text-slate-300">
                    Hand-picked offbeat retreats within 1–6 hours. Pack your bag in 5 minutes — gear, road status, and itinerary ready.
                  </p>
                </div>

                <button
                  onClick={() => setActiveTab('ooo')}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-orange-400 text-slate-800 font-black text-xs hover:brightness-110 transition shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Custom Escape</span>
                </button>
              </div>

              {/* Category Filter Pills */}
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex-shrink-0 cursor-pointer ${
                      selectedCategory === cat
                        ? 'bg-amber-400 text-slate-800 shadow'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* Escapes Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
                {filteredEscapes.map((escape) => (
                  <div
                    key={escape.id}
                    className="bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 rounded-2xl overflow-hidden flex flex-col group transition-all duration-200 hover:-translate-y-1 shadow-lg"
                  >
                    {/* Image & Badges */}
                    <div className="relative h-48 overflow-hidden">
                      <img
                        src={escape.imageUrl}
                        alt={escape.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />

                      {/* Category Badge */}
                      <span className="absolute top-3 left-3 bg-slate-900/90 border border-slate-700 text-amber-300 text-[10px] font-black px-2.5 py-1 rounded-full backdrop-blur-md">
                        {escape.category}
                      </span>

                      {/* Distance & Drive Time */}
                      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs text-white font-bold">
                        <div className="flex items-center gap-1.5 bg-white/80 px-2.5 py-1 rounded-lg backdrop-blur-sm">
                          <Navigation className="w-3.5 h-3.5 text-amber-400" />
                          <span>{escape.distanceKm} km ({escape.driveTimeHours})</span>
                        </div>
                        <div className="flex items-center gap-1 bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-lg text-[11px] backdrop-blur-sm">
                          <Star className="w-3 h-3 fill-current text-amber-400" />
                          <span>{escape.rating} ({escape.reviewsCount})</span>
                        </div>
                      </div>
                    </div>

                    {/* Card Body */}
                    <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                      <div className="space-y-1.5">
                        <h4 className="font-black text-white text-base leading-tight group-hover:text-amber-400 transition-colors">
                          {escape.title}
                        </h4>
                        <p className="text-xs text-slate-400 font-medium">
                          {escape.tagline}
                        </p>
                        <div className="flex items-center gap-2 pt-1 text-[11px] text-slate-300">
                          <span className="text-emerald-400 font-semibold flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            {escape.roadCondition}
                          </span>
                          <span>•</span>
                          <span className="text-amber-300">+{escape.driftMilesEarn} DriftMiles</span>
                        </div>
                      </div>

                      {/* Highlights checklist */}
                      <div className="space-y-1 bg-white/50 p-2.5 rounded-xl border border-slate-800/80 text-[11px] text-slate-300">
                        {escape.highlights.slice(0, 2).map((hl, i) => (
                          <div key={i} className="flex items-start gap-1.5">
                            <span className="text-amber-400 font-bold">✓</span>
                            <span className="line-clamp-1">{hl}</span>
                          </div>
                        ))}
                      </div>

                      {/* Price & 1-Tap Book Button */}
                      <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
                        <div>
                          <span className="text-[10px] text-slate-400 block">From</span>
                          <div className="flex items-baseline gap-1">
                            <span className="text-base font-black text-white">₹{escape.pricePerNightINR.toLocaleString()}</span>
                            <span className="text-[10px] text-slate-400">/ night</span>
                          </div>
                        </div>

                        <button
                          onClick={() => bookJustAwayEscape(escape.id)}
                          className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-800 font-black text-xs transition shadow-md flex items-center gap-1.5 cursor-pointer"
                        >
                          <span>Just Go (1-Tap)</span>
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: WANDERKITS GEAR LOCKER */}
          {activeTab === 'gear' && (
            <div className="space-y-5">
              <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/40 p-4 sm:p-5 rounded-2xl flex flex-wrap items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs uppercase tracking-widest font-black text-indigo-300">
                      Try-Before-You-Fly Gear Locker
                    </span>
                    <span className="bg-amber-400 text-slate-800 text-[10px] font-black px-2 py-0.5 rounded-full">
                      3-DAY ₹0 DOORSTEP TRIAL
                    </span>
                  </div>
                  <h3 className="text-lg font-black text-white">
                    Pack Light. Move Free. Test Premium Adventure Gear For Free.
                  </h3>
                  <p className="text-xs text-slate-300">
                    Get rucksacks, 4K action cameras, waterproof shells, and pop-up pods delivered to your door in 60 mins. If you don't take it on your trip, return with zero charge.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {justAwayGearKits.map((gear) => (
                  <div
                    key={gear.id}
                    className="bg-slate-900/90 border border-slate-800 hover:border-indigo-500/40 rounded-2xl p-4 flex flex-col justify-between space-y-3 group shadow-md"
                  >
                    <div className="relative h-44 rounded-xl overflow-hidden bg-white">
                      <img
                        src={gear.imageUrl}
                        alt={gear.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <span className="absolute top-2.5 left-2.5 bg-indigo-600 text-white text-[9px] font-black px-2 py-0.5 rounded-md uppercase tracking-wider">
                        {gear.badge}
                      </span>
                      <span className="absolute top-2.5 right-2.5 bg-slate-900/80 text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1 backdrop-blur-sm">
                        ★ {gear.rating}
                      </span>
                    </div>

                    <div className="space-y-1.5">
                      <div className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider">
                        {gear.brandTag}
                      </div>
                      <h4 className="text-sm font-black text-white group-hover:text-amber-400 transition-colors">
                        {gear.name}
                      </h4>
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {gear.specs.slice(0, 2).map((spec, i) => (
                          <span
                            key={i}
                            className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-md"
                          >
                            {spec}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
                      <div>
                        <div className="text-xs font-black text-amber-300">
                          ₹{gear.rentalDailyINR}/day rental
                        </div>
                        <span className="text-[10px] text-slate-400">Buy for ₹{gear.purchaseINR}</span>
                      </div>

                      <button
                        onClick={() => claimWanderKitTrial(gear.id)}
                        className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs transition shadow flex items-center gap-1 cursor-pointer"
                      >
                        <Luggage className="w-3.5 h-3.5" />
                        <span>Try ₹0 For 3 Days</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: WANDERPULSE MOVEMENT RADAR */}
          {activeTab === 'radar' && (
            <div className="space-y-5">
              <div className="bg-gradient-to-r from-teal-950 via-slate-900 to-emerald-950 border border-teal-500/40 p-4 sm:p-5 rounded-2xl space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-xs uppercase tracking-widest font-black text-teal-300">
                    Live Hyperlocal Movement Radar ({userLocation.city || 'Indore'} Corridor)
                  </span>
                </div>
                <h3 className="text-lg font-black text-white">
                  Real-Time Scenic Routes, Live Weather & Road Conditions
                </h3>
                <p className="text-xs text-slate-300">
                  Community-powered movement radar tracking live sunset spots, roadside artisan tea stalls, and traffic-free forest detours.
                </p>
              </div>

              {/* Live Road Status Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  {
                    route: 'Indore ⇄ Mandu Pass (NH-52)',
                    status: 'Clear & Fast',
                    speed: '82 km/h avg',
                    weather: 'Sunset Fog 24°C',
                    detour: 'Stop at Dhar Tribal Handloom Circle for fresh jaggery tea',
                    color: 'emerald',
                  },
                  {
                    route: 'Indore ⇄ Omkareshwar Gorge (SH-27)',
                    status: 'Smooth & Scenic',
                    speed: '65 km/h avg',
                    weather: 'Gentle River Breeze 26°C',
                    detour: 'Riverside wooden pier accessible via Mortakka detour',
                    color: 'teal',
                  },
                  {
                    route: 'Indore ⇄ Pachmarhi Highland Pass',
                    status: 'Lush Pine Fog',
                    speed: '55 km/h hills',
                    weather: 'Crisp Rain 19°C',
                    detour: 'Forest check-post hot bhutta (roasted corn) stall open',
                    color: 'amber',
                  },
                ].map((item, idx) => (
                  <div key={idx} className="bg-slate-900/80 border border-slate-800 p-4 rounded-2xl space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-white">{item.route}</span>
                      <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                        item.color === 'emerald'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : item.color === 'teal'
                          ? 'bg-teal-500/20 text-teal-300'
                          : 'bg-amber-500/20 text-amber-300'
                      }`}>
                        {item.status}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-300 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Flow:</span>
                        <span className="font-bold text-white">{item.speed}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Atmosphere:</span>
                        <span className="font-bold text-amber-300">{item.weather}</span>
                      </div>
                    </div>

                    <div className="bg-white p-2 rounded-xl text-[10px] text-slate-300 border border-slate-800 flex items-start gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400 flex-shrink-0 mt-0.5" />
                      <span>{item.detour}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: OUT OF OFFICE (OOO) GENERATOR */}
          {activeTab === 'ooo' && (
            <div className="space-y-5">
              <div className="bg-gradient-to-r from-amber-950/80 via-slate-900 to-rose-950/80 border border-amber-500/40 p-4 sm:p-5 rounded-2xl space-y-2">
                <span className="text-xs uppercase tracking-widest font-black text-amber-400">
                  Instant OutOfOffice (OOO) Getaway AI Engine
                </span>
                <h3 className="text-lg font-black text-white">
                  Tell Us Your Mood. We Build Your Spontaneous 48h Escape.
                </h3>
                <p className="text-xs text-slate-300">
                  Generate a complete zero-friction weekend pack-and-go plan with travel stops, curated cabins, and gear essentials.
                </p>
              </div>

              {/* Generator Selectors */}
              <div className="bg-slate-900/90 border border-slate-800 p-4 sm:p-6 rounded-2xl space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-2">
                      1. How far do you want to travel?
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: 'short', label: '1–2 Hours', sub: 'Micro-Escape' },
                        { id: 'medium', label: '2–4 Hours', sub: 'Weekend Haven' },
                        { id: 'deep', label: '4–8 Hours', sub: 'Deep Wilderness' },
                      ].map((dist) => (
                        <button
                          key={dist.id}
                          onClick={() => setDriveDistancePref(dist.id as any)}
                          className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${
                            driveDistancePref === dist.id
                              ? 'bg-amber-400 text-slate-800 font-black border-amber-300'
                              : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                          }`}
                        >
                          <span className="text-xs block">{dist.label}</span>
                          <span className="text-[9px] opacity-75 block">{dist.sub}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-2">
                      2. What vibe are you craving?
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {(['Serenity', 'Adrenaline', 'Heritage', 'Solitude'] as const).map((mood) => (
                        <button
                          key={mood}
                          onClick={() => setTravelMood(mood)}
                          className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${
                            travelMood === mood
                              ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-800 font-black border-amber-300'
                              : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                          }`}
                        >
                          <span className="text-xs font-bold">{mood}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="pt-2 flex justify-center">
                  <button
                    onClick={handleGenerateOOOTrip}
                    disabled={isGeneratingTrip}
                    className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-400 via-orange-500 to-rose-500 hover:brightness-110 text-slate-800 font-black text-sm transition shadow-xl shadow-orange-500/25 flex items-center gap-2 cursor-pointer"
                  >
                    {isGeneratingTrip ? (
                      <>
                        <Sparkles className="w-4 h-4 animate-spin text-slate-800" />
                        <span>Crafting Spontaneous Route...</span>
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 text-slate-800 fill-current" />
                        <span>Generate Instant 48h Escape ("Just Go")</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Generated Result Display */}
              {generatedTripPlan && (
                <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-amber-500/50 p-5 rounded-2xl space-y-4 shadow-xl">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div>
                      <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider">
                        Curated Spontaneous Itinerary
                      </span>
                      <h4 className="text-base font-black text-white">{generatedTripPlan.title}</h4>
                      <p className="text-xs text-slate-400 mt-0.5">{generatedTripPlan.route} • {generatedTripPlan.driveTime}</p>
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-black text-amber-300">+{generatedTripPlan.driftMiles} DriftMiles</span>
                      <span className="text-[10px] text-slate-400 block">Est. ₹{generatedTripPlan.totalBudget} all-inclusive</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <span className="text-xs font-bold text-slate-300 block">Planned Journey Highlights:</span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {generatedTripPlan.stops.map((stop, i) => (
                        <div key={i} className="p-2.5 bg-white/70 border border-slate-800 rounded-xl text-xs text-slate-300 flex items-start gap-2">
                          <span className="w-5 h-5 rounded-full bg-amber-400/20 text-amber-300 font-black text-[10px] flex items-center justify-center flex-shrink-0 mt-0.5">
                            {i + 1}
                          </span>
                          <span>{stop}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2 flex items-center justify-between gap-3 border-t border-slate-800">
                    <div className="text-xs text-slate-300 flex items-center gap-1.5">
                      <Luggage className="w-4 h-4 text-indigo-400" />
                      <span>Recommended Gear: <strong>{generatedTripPlan.gearKit}</strong></span>
                    </div>

                    <button
                      onClick={() => {
                        showToast('🎉 Spontaneous Getaway Booked! Safe Travels & Wander Free!');
                        onClose();
                      }}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-800 font-black text-xs transition shadow cursor-pointer"
                    >
                      Confirm & Pack Now
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: NOMAD PASSPORT & STAMPS */}
          {activeTab === 'passport' && (
            <div className="space-y-5">
              <div className="bg-gradient-to-r from-slate-900 via-amber-950/50 to-slate-900 border border-amber-500/40 p-4 sm:p-5 rounded-2xl flex flex-wrap items-center justify-between gap-4">
                <div className="space-y-1">
                  <span className="text-xs uppercase tracking-widest font-black text-amber-400">
                    Your Digital Nomad Passport
                  </span>
                  <h3 className="text-lg font-black text-white">
                    Proof of Adventure & Wanderlust Stamps
                  </h3>
                  <p className="text-xs text-slate-300">
                    Every spontaneous escape logs a permanent decentralized adventure stamp in your passport.
                  </p>
                </div>

                <div className="flex items-center gap-2 bg-white px-3.5 py-2 rounded-xl border border-slate-800">
                  <Award className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-bold text-white">Nomad Rank: <strong className="text-amber-400">Trailblazer Tier</strong></span>
                </div>
              </div>

              {/* Stamps Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {justAwayNomadStamps.map((stamp) => (
                  <div
                    key={stamp.id}
                    className="bg-slate-900/90 border border-amber-500/30 p-4 rounded-2xl space-y-2 relative overflow-hidden shadow-inner text-center group hover:border-amber-400 transition"
                  >
                    <div className="text-3xl mb-1">{stamp.badgeIcon}</div>
                    <h4 className="text-xs font-black text-white group-hover:text-amber-400 transition-colors">
                      {stamp.placeName}
                    </h4>
                    <p className="text-[10px] text-slate-400">{stamp.state} • {stamp.category}</p>
                    <div className="text-[10px] font-mono text-amber-300 bg-white/80 px-2 py-1 rounded-lg border border-slate-800">
                      {stamp.coordinates}
                    </div>
                    <div className="text-[9px] text-slate-500">
                      Stamped on {stamp.stampDate}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
