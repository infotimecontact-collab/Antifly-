import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Coins,
  Gem,
  Sparkles,
  Flame,
  Crown,
  Calendar,
  Gift,
  TrendingUp,
  Clock,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Share2,
  Users,
  Award,
  Zap,
  Tag,
  ChevronRight,
  RefreshCw,
  Sliders,
  DollarSign,
  AlertTriangle,
  ArrowRightLeft,
  X,
  Copy,
  ShoppingBag,
  Video,
  Radio,
  Check,
  Percent,
} from 'lucide-react';
import {
  LoyaltyTierLevel,
  DailyCheckInDay,
  RewardMissionItem,
  FlashCoinEvent,
  UniversalCoinTransaction,
} from '../../types';

export const SuperCoinDiamondRewardsModal: React.FC = () => {
  const {
    isRewardsEconomyModalOpen,
    setIsRewardsEconomyModalOpen,
    activeRewardsTab,
    setActiveRewardsTab,
    superCoinWallet,
    diamondWallet,
    loyaltyTiers,
    dailyCheckInDays,
    rewardMissions,
    flashCoinEvents,
    referralEconomy,
    sellerRewardConfigs,
    creatorRewardStats,
    personalizedRewards,
    universalCoinTransactions,
    claimDailyCheckInReward,
    claimMissionReward,
    convertDiamondsToCoins,
    claimReferralReward,
    updateSellerRewardConfig,
    showToast,
  } = useApp();

  const [diamondsToConvert, setDiamondsToConvert] = useState<number>(50);
  const [copiedReferral, setCopiedReferral] = useState<boolean>(false);
  const [selectedTxFilter, setSelectedTxFilter] = useState<'all' | 'SuperCoin' | 'Diamond'>('all');

  // Seller config editing state
  const [activeSellerConfig, setActiveSellerConfig] = useState(sellerRewardConfigs?.[0] || null);

  if (!isRewardsEconomyModalOpen) return null;

  const currentTierConfig = loyaltyTiers?.find((t) => t.level === superCoinWallet?.currentTier) || loyaltyTiers?.[2] || loyaltyTiers?.[0];

  const handleCopyReferralLink = () => {
    navigator.clipboard.writeText(referralEconomy.referralLink);
    setCopiedReferral(true);
    showToast('Copied Referral Link to Clipboard! Share with friends to earn 1,000 Super Coins.');
    setTimeout(() => setCopiedReferral(false), 2500);
  };

  const handleConvert = (e: React.FormEvent) => {
    e.preventDefault();
    if (diamondsToConvert <= 0 || diamondsToConvert > diamondWallet.availableDiamonds) {
      showToast(`Invalid Diamond amount. Max available: ${diamondWallet.availableDiamonds} 💎`);
      return;
    }
    convertDiamondsToCoins(diamondsToConvert);
  };

  const filteredTransactions = universalCoinTransactions.filter((tx) => {
    if (selectedTxFilter === 'all') return true;
    return tx.currency === selectedTxFilter;
  });

  return (
    <div
      id="supercoin-diamond-rewards-modal"
      className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 lg:p-6 animate-fade-in"
    >
      <div className="bg-white dark:bg-slate-900 w-full max-w-5xl rounded-3xl shadow-2xl border border-amber-200 dark:border-amber-900/30 overflow-hidden flex flex-col my-auto max-h-[92vh]">
        {/* Flagship Currency Header */}
        <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-500 p-5 sm:p-6 text-slate-800 relative overflow-hidden flex-shrink-0">
          <div className="absolute right-0 top-0 translate-x-8 -translate-y-8 opacity-15 pointer-events-none">
            <Coins className="w-56 h-56 text-slate-800" />
          </div>

          <div className="flex items-start justify-between relative z-10">
            <div className="flex items-center gap-3.5">
              <div className="w-13 h-13 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center border border-slate-200/10 shadow-inner">
                <Coins className="w-8 h-8 text-slate-800 fill-amber-300" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase tracking-wider bg-white text-amber-400 px-2.5 py-0.5 rounded-full shadow-xs">
                    👑 {superCoinWallet.currentTier} VIP Club
                  </span>
                  <span className="text-[11px] font-black bg-gradient-to-r from-orange-600 to-amber-700 text-white px-2 py-0.5 rounded-full shadow-xs">
                    🔥 {currentTierConfig.multiplier}X MULTIPLIER ACTIVE
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-800 tracking-tight mt-0.5">
                  Super Coins & Diamond Economy Hub
                </h2>
                <p className="text-xs text-slate-900 font-medium">
                  Earn, redeem, and level up with shopping loyalty coins and creator virtual diamonds.
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsRewardsEconomyModalOpen(false)}
              className="p-2 text-slate-900 hover:text-slate-800 rounded-full hover:bg-slate-100/10 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Dual Balance Cards Ribbon */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4 pt-3 border-t border-slate-200/10 relative z-10">
            {/* Super Coins Card */}
            <div className="bg-white/20 backdrop-blur-md rounded-2xl p-3.5 border border-slate-200/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400/30 flex items-center justify-center font-black text-amber-950 text-lg">
                  🪙
                </div>
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-900 block">
                    Available Super Coins
                  </span>
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-2xl font-black text-slate-800 tracking-tight">
                      {superCoinWallet.availableBalance.toLocaleString()}
                    </span>
                    <span className="text-[11px] font-bold text-amber-950">
                      (₹{superCoinWallet.availableBalance} value)
                    </span>
                  </div>
                </div>
              </div>
              <div className="text-right text-[11px] text-amber-950 font-semibold">
                <span>Pending: +{superCoinWallet.pendingBalance}</span>
                <span className="block text-[10px] text-rose-900 font-bold">
                  ⏱ {superCoinWallet.expiringCoins} expiring soon
                </span>
              </div>
            </div>

            {/* Diamonds Card */}
            <div className="bg-white/20 backdrop-blur-md rounded-2xl p-3.5 border border-slate-200/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-400/30 flex items-center justify-center font-black text-cyan-950 text-lg">
                  💎
                </div>
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-900 block">
                    Creator Diamonds
                  </span>
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-2xl font-black text-slate-800 tracking-tight">
                      {diamondWallet.availableDiamonds.toLocaleString()}
                    </span>
                    <span className="text-[11px] font-bold text-cyan-950">
                      (Live/Social Currency)
                    </span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setActiveRewardsTab('diamonds')}
                className="px-3 py-1.5 bg-white text-amber-300 hover:bg-slate-900 rounded-xl text-xs font-bold transition shadow-xs"
              >
                Convert to Coins
              </button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 px-4 flex gap-1 overflow-x-auto scrollbar-none flex-shrink-0">
          {[
            { id: 'home', label: 'Rewards Home', icon: Sparkles },
            { id: 'supercoins', label: 'Super Coin Wallet', icon: Coins },
            { id: 'diamonds', label: 'Diamond Wallet', icon: Gem },
            { id: 'missions', label: 'Daily & Missions', icon: Calendar, badge: 'Daily' },
            { id: 'tiers', label: 'Loyalty Tiers', icon: Crown },
            { id: 'flash', label: 'Flash 10X Events', icon: Zap, badge: 'Live' },
            { id: 'referrals', label: 'Refer & Earn', icon: Users },
            { id: 'creator', label: 'Creator Hub', icon: Video },
            { id: 'seller', label: 'Seller Economy', icon: ShoppingBag },
            { id: 'ledger', label: 'Passbook Ledger', icon: Clock },
            { id: 'admin', label: 'Fraud & Rules', icon: ShieldCheck },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeRewardsTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveRewardsTab(tab.id as any)}
                className={`py-3 px-3 text-xs font-bold whitespace-nowrap flex items-center gap-1.5 border-b-2 transition ${
                  isActive
                    ? 'border-amber-600 text-amber-600 dark:text-amber-400 bg-white dark:bg-slate-900 rounded-t-xl shadow-xs'
                    : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className="bg-amber-500 text-slate-800 font-black text-[9px] px-1.5 py-0.2 rounded-full">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Tab Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* TAB 1: REWARDS HOME */}
          {activeRewardsTab === 'home' && (
            <div className="space-y-6 animate-fade-in">
              {/* Daily Goal Progress Bar */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-amber-500/10 via-yellow-500/5 to-transparent border border-amber-200 dark:border-amber-900/30">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Flame className="w-5 h-5 text-amber-600 animate-bounce" />
                    <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                      Today's Reward Goal: 80/100 Coins
                    </span>
                  </div>
                  <span className="text-xs font-bold text-amber-600 dark:text-amber-400">
                    80% Complete
                  </span>
                </div>

                <div className="w-full bg-slate-200 dark:bg-slate-700 h-3 rounded-full overflow-hidden">
                  <div className="bg-gradient-to-r from-amber-500 to-yellow-400 h-full rounded-full w-[80%] transition-all duration-500" />
                </div>

                <div className="flex items-center justify-between mt-2 text-xs text-slate-600 dark:text-slate-400">
                  <span>Complete 1 more activity to unlock 20 bonus coins</span>
                  <button
                    onClick={() => setActiveRewardsTab('missions')}
                    className="font-bold text-amber-600 hover:underline flex items-center gap-1"
                  >
                    <span>View Missions</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Personalized Contextual Rewards */}
              <div>
                <h3 className="font-black text-sm text-slate-900 dark:text-white uppercase tracking-wider mb-3 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>Personalized Reward Drops Just For You</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {personalizedRewards.map((rec) => (
                    <div
                      key={rec.id}
                      className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 flex items-start justify-between gap-3 shadow-xs hover:border-amber-300 transition"
                    >
                      <div className="space-y-1">
                        <span className="text-[10px] font-extrabold px-2 py-0.5 bg-amber-100 text-amber-800 rounded-full">
                          {rec.multiplierBadge}
                        </span>
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                          {rec.title}
                        </h4>
                        <p className="text-xs text-slate-500">{rec.description}</p>
                        <p className="text-[11px] text-amber-600 dark:text-amber-400 font-semibold pt-1">
                          💡 {rec.recommendedReason}
                        </p>
                      </div>
                      <button
                        onClick={() => showToast(`Activated: ${rec.title}`)}
                        className="px-3 py-1.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl text-xs font-bold hover:scale-105 transition shrink-0"
                      >
                        {rec.actionText}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quick Action Matrix */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <button
                  onClick={() => setActiveRewardsTab('missions')}
                  className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 text-left hover:scale-102 transition"
                >
                  <Calendar className="w-6 h-6 text-amber-600 mb-2" />
                  <span className="font-bold text-xs text-slate-900 dark:text-white block">
                    Daily Check-In
                  </span>
                  <span className="text-[11px] text-slate-500">Claim 7-day streak</span>
                </button>

                <button
                  onClick={() => setActiveRewardsTab('flash')}
                  className="p-4 rounded-2xl bg-orange-50 dark:bg-orange-950/20 border border-orange-200 dark:border-orange-900/40 text-left hover:scale-102 transition"
                >
                  <Zap className="w-6 h-6 text-orange-600 mb-2" />
                  <span className="font-bold text-xs text-slate-900 dark:text-white block">
                    10X Flash Event
                  </span>
                  <span className="text-[11px] text-slate-500">Live for 28 mins</span>
                </button>

                <button
                  onClick={() => setActiveRewardsTab('referrals')}
                  className="p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-900/40 text-left hover:scale-102 transition"
                >
                  <Users className="w-6 h-6 text-indigo-600 mb-2" />
                  <span className="font-bold text-xs text-slate-900 dark:text-white block">
                    Refer & Earn
                  </span>
                  <span className="text-[11px] text-slate-500">1,000 Coins / Friend</span>
                </button>

                <button
                  onClick={() => setActiveRewardsTab('tiers')}
                  className="p-4 rounded-2xl bg-purple-50 dark:bg-purple-950/20 border border-purple-200 dark:border-purple-900/40 text-left hover:scale-102 transition"
                >
                  <Crown className="w-6 h-6 text-purple-600 mb-2" />
                  <span className="font-bold text-xs text-slate-900 dark:text-white block">
                    VIP Loyalty Tier
                  </span>
                  <span className="text-[11px] text-slate-500">
                    {superCoinWallet.coinsToNextTier} to Platinum
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: SUPER COIN WALLET & EXPIRY TIMELINE */}
          {activeRewardsTab === 'supercoins' && (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <span className="text-slate-500 block">Lifetime Earned</span>
                  <span className="text-xl font-black text-amber-600 dark:text-amber-400">
                    🪙 {superCoinWallet.lifetimeEarned.toLocaleString()}
                  </span>
                </div>
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <span className="text-slate-500 block">Lifetime Redeemed</span>
                  <span className="text-xl font-black text-emerald-600 dark:text-emerald-400">
                    ₹{superCoinWallet.lifetimeRedeemed.toLocaleString()}
                  </span>
                </div>
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <span className="text-slate-500 block">Today's Earnings</span>
                  <span className="text-xl font-black text-slate-900 dark:text-white">
                    +{superCoinWallet.todayEarned} Coins
                  </span>
                </div>
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <span className="text-slate-500 block">Expiring Soon</span>
                  <span className="text-xl font-black text-rose-600">
                    {superCoinWallet.expiringCoins} Coins
                  </span>
                </div>
              </div>

              {/* Coin Expiry Timeline */}
              <div className="p-5 rounded-2xl border border-rose-200 dark:border-rose-900/30 bg-rose-50/50 dark:bg-rose-950/10 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-rose-600" />
                    <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
                      Super Coin Expiry Timeline
                    </h3>
                  </div>
                  <span className="text-xs font-bold text-rose-700">
                    Use before expiry at checkout
                  </span>
                </div>

                <div className="space-y-2">
                  {superCoinWallet.expiryTimeline.map((item) => (
                    <div
                      key={item.id}
                      className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-rose-100 dark:border-rose-900/20 flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-slate-900 dark:text-white block">
                          🪙 {item.amount} Coins Expiring
                        </span>
                        <span className="text-slate-500 text-[11px]">{item.reason}</span>
                      </div>
                      <div className="text-right">
                        <span className="font-mono font-bold text-rose-600 block">
                          {item.date}
                        </span>
                        <span className="text-[10px] text-slate-400 font-semibold">
                          in {item.daysRemaining} days
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: DIAMOND WALLET & CONVERSION */}
          {activeRewardsTab === 'diamonds' && (
            <div className="space-y-6 animate-fade-in">
              <div className="bg-gradient-to-r from-cyan-900 to-slate-900 text-white p-6 rounded-3xl relative overflow-hidden">
                <div className="flex items-start justify-between relative z-10">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded-full border border-cyan-400/30">
                      Creator & Social Rewards
                    </span>
                    <h3 className="text-2xl font-black tracking-tight mt-1">
                      💎 {diamondWallet.availableDiamonds.toLocaleString()} Diamonds Available
                    </h3>
                    <p className="text-xs text-slate-300 mt-0.5">
                      Earned through live shopping stream achievements, high-converting product showcases, and community milestones.
                    </p>
                  </div>
                </div>
              </div>

              {/* Conversion Form */}
              <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-4">
                <div className="flex items-center gap-2">
                  <ArrowRightLeft className="w-5 h-5 text-cyan-600" />
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                    Convert Diamonds into Super Coins
                  </h3>
                </div>
                <p className="text-xs text-slate-500">
                  Instant conversion rate: 1 Diamond = 10 Super Coins (Redeemable immediately for product discounts at checkout).
                </p>

                <form onSubmit={handleConvert} className="flex flex-col sm:flex-row gap-3">
                  <div className="relative flex-1">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm">💎</span>
                    <input
                      type="number"
                      min="10"
                      max={diamondWallet.availableDiamonds}
                      value={diamondsToConvert}
                      onChange={(e) => setDiamondsToConvert(Number(e.target.value))}
                      className="w-full pl-9 pr-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-cyan-600 hover:bg-cyan-700 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center justify-center gap-1.5"
                  >
                    <span>Convert to {diamondsToConvert * 10} Super Coins</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* TAB 4: DAILY CHECK-IN & MISSIONS */}
          {activeRewardsTab === 'missions' && (
            <div className="space-y-6 animate-fade-in">
              {/* 7-Day Streak Calendar */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="font-black text-sm text-slate-900 dark:text-white flex items-center gap-2">
                      <Flame className="w-4 h-4 text-amber-500" />
                      <span>7-Day Daily Check-In Streak</span>
                    </h3>
                    <p className="text-xs text-slate-500">Check in consecutively to unlock massive Day 7 Diamond milestone.</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-7 gap-2.5">
                  {dailyCheckInDays.map((day) => (
                    <div
                      key={day.dayNumber}
                      className={`p-3 rounded-2xl border flex flex-col items-center justify-between gap-2 text-center transition ${
                        day.isClaimed
                          ? 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900/40 text-emerald-800 dark:text-emerald-300'
                          : day.isToday
                          ? 'bg-amber-50 dark:bg-amber-950/30 border-amber-400 dark:border-amber-500 shadow-md ring-2 ring-amber-400/20'
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      <span className="text-[10px] font-bold uppercase tracking-wider">{day.dayLabel}</span>
                      <div className="text-lg">
                        {day.isClaimed ? '✅' : day.isSpecialMilestone ? '🎁' : '🪙'}
                      </div>
                      <span className="font-black text-xs">+{day.superCoins}</span>

                      {day.isToday && !day.isClaimed ? (
                        <button
                          onClick={() => claimDailyCheckInReward(day.dayNumber)}
                          className="w-full py-1 bg-amber-500 hover:bg-amber-600 text-slate-800 text-[10px] font-black rounded-lg shadow-xs transition active:scale-95"
                        >
                          Claim
                        </button>
                      ) : day.isClaimed ? (
                        <span className="text-[9px] font-bold uppercase tracking-wider text-emerald-600">
                          Claimed
                        </span>
                      ) : (
                        <span className="text-[9px] text-slate-400 font-semibold">Locked</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Daily & Shopping Missions */}
              <div>
                <h3 className="font-black text-sm text-slate-900 dark:text-white mb-3">
                  Today's Active Missions & Challenges
                </h3>

                <div className="space-y-3">
                  {rewardMissions.map((mission) => (
                    <div
                      key={mission.id}
                      className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs hover:border-amber-300 transition"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950/50 flex items-center justify-center text-lg flex-shrink-0">
                          {mission.icon}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                              {mission.title}
                            </h4>
                            <span className="text-[10px] font-black text-amber-700 bg-amber-100 px-2 py-0.2 rounded-full">
                              +{mission.rewardSuperCoins} Coins {mission.rewardDiamonds ? `+ ${mission.rewardDiamonds} 💎` : ''}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500">{mission.description}</p>
                          <div className="flex items-center gap-2 mt-1.5">
                            <div className="w-28 bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                              <div
                                className="bg-amber-500 h-full rounded-full transition-all"
                                style={{ width: `${(mission.progress / mission.maxProgress) * 100}%` }}
                              />
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {mission.progress}/{mission.maxProgress}
                            </span>
                          </div>
                        </div>
                      </div>

                      {mission.isClaimed ? (
                        <span className="px-3 py-1.5 text-xs font-bold text-emerald-600 bg-emerald-50 rounded-xl">
                          Completed & Claimed
                        </span>
                      ) : mission.isCompleted ? (
                        <button
                          onClick={() => claimMissionReward(mission.id)}
                          className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-800 rounded-xl text-xs font-black transition shadow-xs"
                        >
                          Claim Reward
                        </button>
                      ) : (
                        <button
                          onClick={() => showToast(`Opening activity for: ${mission.title}`)}
                          className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold transition"
                        >
                          {mission.actionButtonLabel}
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: LOYALTY TIERS */}
          {activeRewardsTab === 'tiers' && (
            <div className="space-y-6 animate-fade-in">
              <div className="bg-gradient-to-r from-purple-900 to-indigo-950 text-white p-5 rounded-2xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider bg-purple-500/30 text-purple-300 px-2 py-0.5 rounded-full border border-purple-400/30">
                    Tier Journey
                  </span>
                  <h3 className="text-xl font-black mt-1">
                    {superCoinWallet.currentTier} Level Member
                  </h3>
                  <p className="text-xs text-purple-200">
                    Only {superCoinWallet.coinsToNextTier} coins needed to reach Platinum VIP status.
                  </p>
                </div>
                <Crown className="w-12 h-12 text-amber-400" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                {loyaltyTiers.map((tier) => {
                  const isCurrent = tier.level === superCoinWallet.currentTier;
                  return (
                    <div
                      key={tier.level}
                      className={`p-4 rounded-2xl border relative flex flex-col justify-between gap-3 ${
                        isCurrent
                          ? 'border-amber-400 bg-amber-50/40 dark:bg-amber-950/20 shadow-md'
                          : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800'
                      }`}
                    >
                      {isCurrent && (
                        <span className="absolute top-3 right-3 bg-amber-500 text-slate-800 font-black text-[9px] uppercase px-2 py-0.5 rounded-full">
                          Your Tier
                        </span>
                      )}
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xl">{tier.icon}</span>
                          <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">
                            {tier.name}
                          </h4>
                        </div>
                        <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 block mb-2">
                          🔥 {tier.multiplier}x SuperCoin Earning Rate
                        </span>

                        <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                          {tier.perks.map((perk, idx) => (
                            <li key={idx} className="flex items-start gap-1.5">
                              <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                              <span>{perk}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="pt-2 border-t border-slate-100 dark:border-slate-700 text-[11px] text-slate-400">
                        Unlocked at {tier.minCoinsRequired.toLocaleString()} lifetime coins
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 6: FLASH 10X COIN EVENTS */}
          {activeRewardsTab === 'flash' && (
            <div className="space-y-4 animate-fade-in">
              <div className="bg-gradient-to-r from-orange-600 to-amber-600 text-white p-5 rounded-2xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider bg-white/20 text-white px-2 py-0.5 rounded-full">
                    ⚡ High-Urgency Campaigns
                  </span>
                  <h3 className="text-xl font-black mt-1">Limited-Time Flash Coin Multipliers</h3>
                  <p className="text-xs text-orange-100">
                    Earn up to 10X Super Coins on eligible items before timer countdown expires.
                  </p>
                </div>
                <Flame className="w-10 h-10 text-yellow-300 animate-bounce" />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {flashCoinEvents.map((evt) => (
                  <div
                    key={evt.id}
                    className="p-4 rounded-2xl border border-orange-200 dark:border-orange-900/30 bg-white dark:bg-slate-800 space-y-3"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-[10px] font-black px-2 py-0.5 bg-orange-100 text-orange-800 rounded-full">
                          {evt.multiplierText}
                        </span>
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white mt-1">
                          {evt.title}
                        </h4>
                        <p className="text-xs text-slate-500">{evt.subtitle}</p>
                      </div>
                      <span className="text-xs font-mono font-black text-rose-600 bg-rose-50 px-2 py-1 rounded-lg">
                        ⏱ {evt.remainingMinutes}m remaining
                      </span>
                    </div>

                    <button
                      onClick={() => showToast(`Applied ${evt.multiplierText} on ${evt.category}!`)}
                      className="w-full py-2 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-slate-800 font-black text-xs rounded-xl transition shadow-xs"
                    >
                      Shop {evt.category} Now
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 7: REFERRAL HUB */}
          {activeRewardsTab === 'referrals' && (
            <div className="space-y-6 animate-fade-in">
              <div className="bg-gradient-to-r from-indigo-900 to-purple-950 text-white p-6 rounded-3xl space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider bg-indigo-500/30 text-indigo-300 px-2 py-0.5 rounded-full border border-indigo-400/30">
                      Viral Referral Engine
                    </span>
                    <h3 className="text-2xl font-black mt-1">
                      Invite Friends & Earn 1,000 Super Coins
                    </h3>
                    <p className="text-xs text-indigo-200">
                      Give ₹200 off first order, get 1,000 Super Coins (₹1,000 value) when they shop!
                    </p>
                  </div>
                  <Users className="w-10 h-10 text-indigo-400" />
                </div>

                <div className="flex flex-col sm:flex-row gap-2 pt-2">
                  <div className="p-2.5 bg-white/10 rounded-xl border border-white/20 flex-1 flex items-center justify-between text-xs">
                    <span className="font-mono text-amber-300 font-bold">{referralEconomy.referralCode}</span>
                    <span className="text-slate-300 text-[11px]">{referralEconomy.referralLink}</span>
                  </div>
                  <button
                    onClick={handleCopyReferralLink}
                    className="px-4 py-2.5 bg-amber-400 hover:bg-amber-500 text-slate-800 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition"
                  >
                    <Copy className="w-4 h-4" />
                    <span>{copiedReferral ? 'Copied Link!' : 'Copy Invite Link'}</span>
                  </button>
                </div>
              </div>

              {/* Anti-Abuse Fraud Safeguard Badge */}
              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center gap-3 text-xs text-slate-600 dark:text-slate-300">
                <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">
                    Verified Anti-Abuse & Device-ID Protection
                  </span>
                  Rewards unlock automatically upon legitimate first order confirmation. Duplicate phone/device referrals are blocked.
                </div>
              </div>
            </div>
          )}

          {/* TAB 8: CREATOR DIAMOND HUB */}
          {activeRewardsTab === 'creator' && (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
                  <span className="text-slate-500 block">Sales Generated</span>
                  <span className="text-xl font-black text-emerald-600">
                    ₹{creatorRewardStats.salesGeneratedINR.toLocaleString()}
                  </span>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
                  <span className="text-slate-500 block">Diamond Rewards</span>
                  <span className="text-xl font-black text-cyan-600">
                    💎 {creatorRewardStats.diamondRewards.toLocaleString()}
                  </span>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
                  <span className="text-slate-500 block">Conversion Rate</span>
                  <span className="text-xl font-black text-indigo-600">
                    {creatorRewardStats.conversionRatePercent}%
                  </span>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
                  <span className="text-slate-500 block">Monthly Creator Rank</span>
                  <span className="text-xl font-black text-amber-500">
                    #{creatorRewardStats.monthlyRank}
                  </span>
                </div>
              </div>

              {/* Top Performing Showcase Products */}
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white mb-3">
                  Top Converting Creator Showcase Products
                </h3>
                <div className="space-y-2.5">
                  {creatorRewardStats.topPerformingProducts.map((p) => (
                    <div
                      key={p.productId}
                      className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={p.productImage}
                          alt={p.productName}
                          className="w-10 h-10 rounded-lg object-cover"
                        />
                        <div>
                          <h4 className="font-bold text-slate-900 dark:text-white">
                            {p.productName}
                          </h4>
                          <span className="text-slate-500 text-[11px]">
                            {p.salesCount} units sold &bull; ₹{p.gmvINR.toLocaleString()} GMV
                          </span>
                        </div>
                      </div>
                      <span className="font-black text-cyan-600 bg-cyan-50 dark:bg-cyan-950/50 px-2.5 py-1 rounded-lg">
                        +{p.diamondsEarned} 💎
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 9: SELLER REWARD ECONOMY */}
          {activeRewardsTab === 'seller' && (
            <div className="space-y-4 animate-fade-in">
              <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-2xl border border-slate-200 dark:border-slate-700">
                <h3 className="font-bold text-sm text-slate-900 dark:text-white mb-1">
                  Seller Customer Loyalty Program Configurator
                </h3>
                <p className="text-xs text-slate-500">
                  Fund custom SuperCoin cashbacks to boost conversion and drive repeat buyer retention.
                </p>
              </div>

              {activeSellerConfig && (
                <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 space-y-4 text-xs">
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                    <span className="font-bold text-sm text-slate-900 dark:text-white">
                      Store: {activeSellerConfig.storeName}
                    </span>
                    <span className="text-amber-600 font-black">
                      Distributed: {activeSellerConfig.coinsDistributedThisMonth} / {activeSellerConfig.monthlyBudgetCoins} Coins
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="p-3 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
                      <span className="text-slate-500 block mb-1">Coin Cashback %</span>
                      <input
                        type="number"
                        min="1"
                        max="20"
                        value={activeSellerConfig.coinCashbackPercent}
                        onChange={(e) =>
                          updateSellerRewardConfig(activeSellerConfig.sellerId, {
                            coinCashbackPercent: Number(e.target.value),
                          })
                        }
                        className="w-full p-1.5 bg-white dark:bg-slate-900 border rounded-lg font-bold"
                      />
                    </div>

                    <div className="p-3 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
                      <span className="text-slate-500 block mb-1">First-Order Bonus Coins</span>
                      <input
                        type="number"
                        min="50"
                        max="500"
                        value={activeSellerConfig.firstOrderBonusCoins}
                        onChange={(e) =>
                          updateSellerRewardConfig(activeSellerConfig.sellerId, {
                            firstOrderBonusCoins: Number(e.target.value),
                          })
                        }
                        className="w-full p-1.5 bg-white dark:bg-slate-900 border rounded-lg font-bold"
                      />
                    </div>

                    <div className="p-3 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
                      <span className="text-slate-500 block mb-1">Repeat Purchase Bonus</span>
                      <input
                        type="number"
                        min="50"
                        max="1000"
                        value={activeSellerConfig.repeatPurchaseBonusCoins}
                        onChange={(e) =>
                          updateSellerRewardConfig(activeSellerConfig.sellerId, {
                            repeatPurchaseBonusCoins: Number(e.target.value),
                          })
                        }
                        className="w-full p-1.5 bg-white dark:bg-slate-900 border rounded-lg font-bold"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 10: PASSBOOK LEDGER */}
          {activeRewardsTab === 'ledger' && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                  Universal Financial Transaction Passbook
                </h3>
                <div className="flex items-center gap-1.5 text-xs">
                  {['all', 'SuperCoin', 'Diamond'].map((filter) => (
                    <button
                      key={filter}
                      onClick={() => setSelectedTxFilter(filter as any)}
                      className={`px-3 py-1 rounded-lg font-bold transition ${
                        selectedTxFilter === filter
                          ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
                      }`}
                    >
                      {filter}
                    </button>
                  ))}
                </div>
              </div>

              <div className="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden divide-y divide-slate-100 dark:divide-slate-800">
                {filteredTransactions.map((tx) => (
                  <div
                    key={tx.id}
                    className="p-3.5 bg-white dark:bg-slate-800/60 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-700 flex items-center justify-center font-bold">
                        {tx.currency === 'SuperCoin' ? '🪙' : '💎'}
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900 dark:text-white">{tx.title}</h4>
                        <span className="text-slate-500 text-[11px]">{tx.timestamp} &bull; {tx.subtitle}</span>
                      </div>
                    </div>

                    <span
                      className={`font-mono font-black ${
                        tx.amount > 0 ? 'text-emerald-600' : 'text-rose-600'
                      }`}
                    >
                      {tx.amount > 0 ? `+${tx.amount}` : tx.amount} {tx.currency === 'SuperCoin' ? '🪙' : '💎'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 11: ADMIN FRAUD PROTECTION & RISK ENGINE */}
          {activeRewardsTab === 'admin' && (
            <div className="space-y-4 animate-fade-in text-xs">
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/30 rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <ShieldCheck className="w-6 h-6 text-emerald-600" />
                  <div>
                    <h4 className="font-bold text-sm text-emerald-950 dark:text-emerald-200">
                      Fraud Protection & Risk Score: 99.8% Clean
                    </h4>
                    <p className="text-emerald-800 dark:text-emerald-300">
                      Automated device fingerprinting, IP velocity checks, and fake review blockers active.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => showToast('🛡️ Ran deep fraud audit scan. No duplicate farming detected.')}
                  className="px-3 py-1.5 bg-emerald-600 text-white font-bold rounded-xl"
                >
                  Run Deep Scan
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-100 dark:bg-slate-800/80 p-4 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between flex-shrink-0 text-xs">
          <span className="text-slate-500 flex items-center gap-1.5">
            <Coins className="w-4 h-4 text-amber-500" />
            <span>Super Coin Loyalty & Creator Diamond Ledger Synchronized</span>
          </span>
          <button
            onClick={() => setIsRewardsEconomyModalOpen(false)}
            className="px-5 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold rounded-xl hover:bg-slate-800 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
