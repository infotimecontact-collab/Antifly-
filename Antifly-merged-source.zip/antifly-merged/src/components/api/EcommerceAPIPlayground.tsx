import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Code,
  Terminal,
  Play,
  Copy,
  Check,
  Zap,
  Globe,
  Layers,
  Send,
  Shield,
  Clock,
  Key,
  Server,
  FileJson,
  Trash2,
  ExternalLink,
  ChevronRight,
  Sparkles,
  BookOpen,
} from 'lucide-react';
import { EcomAPIEndpoint } from '../../types';

export const EcommerceAPIPlayground: React.FC = () => {
  const {
    apiEndpoints,
    apiLogs,
    executeApiCall,
    clearApiLogs,
    showToast,
  } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedEndpointId, setSelectedEndpointId] = useState<string>(apiEndpoints?.[0]?.id || '');
  const [customRequestBody, setCustomRequestBody] = useState<string>('');
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [lastResponse, setLastResponse] = useState<any>(null);
  const [lastStatusCode, setLastStatusCode] = useState<number | null>(null);
  const [lastDurationMs, setLastDurationMs] = useState<number | null>(null);
  const [hasCopiedCurl, setHasCopiedCurl] = useState<boolean>(false);
  const [hasCopiedKey, setHasCopiedKey] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'tester' | 'logs' | 'keys' | 'webhooks'>('tester');

  const selectedEndpoint = apiEndpoints?.find((e) => e.id === selectedEndpointId) || apiEndpoints?.[0];

  // Keep custom request body in sync when endpoint changes
  React.useEffect(() => {
    if (selectedEndpoint?.requestBodyExample) {
      setCustomRequestBody(JSON.stringify(selectedEndpoint.requestBodyExample, null, 2));
    } else {
      setCustomRequestBody('');
    }
    setLastResponse(null);
    setLastStatusCode(null);
    setLastDurationMs(null);
  }, [selectedEndpointId]);

  const categories = ['All', ...Array.from(new Set(apiEndpoints.map((e) => e.category)))];

  const filteredEndpoints = selectedCategory === 'All'
    ? apiEndpoints
    : apiEndpoints.filter((e) => e.category === selectedCategory);

  const handleExecute = async () => {
    setIsExecuting(true);
    try {
      let parsedBody = undefined;
      if (customRequestBody.trim()) {
        try {
          parsedBody = JSON.parse(customRequestBody);
        } catch (err) {
          showToast('Invalid JSON in request body');
          setIsExecuting(false);
          return;
        }
      }

      const start = performance.now();
      const res = await executeApiCall(selectedEndpoint.id, undefined, parsedBody);
      const duration = Math.round(performance.now() - start);

      setLastResponse(res);
      setLastStatusCode(selectedEndpoint.method === 'POST' ? 201 : 200);
      setLastDurationMs(duration);
      showToast(`⚡ ${selectedEndpoint.method} ${selectedEndpoint.path} (200 OK - ${duration}ms)`);
    } catch (err: any) {
      setLastResponse({ error: err.message });
      setLastStatusCode(500);
    } finally {
      setIsExecuting(false);
    }
  };

  const getCurlCommand = () => {
    let curl = `curl -X ${selectedEndpoint.method} "https://api.antifly.com${selectedEndpoint.path}" \\\n  -H "Authorization: Bearer sk_live_wise9928190283" \\\n  -H "Content-Type: application/json"`;
    if (customRequestBody.trim() && selectedEndpoint.method !== 'GET') {
      curl += ` \\\n  -d '${customRequestBody.replace(/\n/g, '')}'`;
    }
    return curl;
  };

  const handleCopyCurl = () => {
    navigator.clipboard.writeText(getCurlCommand());
    setHasCopiedCurl(true);
    showToast('cURL snippet copied to clipboard');
    setTimeout(() => setHasCopiedCurl(false), 2000);
  };

  return (
    <div id="ecommerce-api-playground" className="min-h-screen bg-white text-slate-100 pb-28">
      {/* Top Header */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 sm:px-8 py-5 sticky top-12 z-30 shadow-md">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-black shadow-lg">
              <Code className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-bold tracking-tight text-white">
                  Worldwide E-Commerce Open REST API Suite
                </h1>
                <span className="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  v1.4.2 REST & Webhooks
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Unified APIs for Customer Storefront, Seller Central, Driver Telemetry, Payments & GA4.
              </p>
            </div>
          </div>

          {/* Quick API Key badge */}
          <div className="flex items-center gap-2">
            <div className="bg-slate-850 px-3 py-1.5 rounded-xl border border-slate-700 text-xs font-mono flex items-center gap-2">
              <Key className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-slate-400">Key:</span>
              <span className="text-emerald-400">sk_live_wise99281...</span>
            </div>
            <button
              onClick={() => {
                navigator.clipboard.writeText('sk_live_wise9928190283019283');
                showToast('API Key copied to clipboard');
              }}
              className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300"
              title="Copy Key"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 mt-6">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
          {[
            { id: 'tester', label: 'Interactive API Explorer & Tester', icon: Terminal },
            { id: 'logs', label: `Live API Traffic Logs (${apiLogs.length})`, icon: Server },
            { id: 'webhooks', label: 'Webhooks & Event Streams', icon: Zap },
            { id: 'keys', label: 'API Keys & OAuth Tokens', icon: Key },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-indigo-500 text-white font-bold shadow-md'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* TAB 1: INTERACTIVE TESTER */}
        {activeTab === 'tester' && (
          <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Endpoints Sidebar (Left 4 cols) */}
            <div className="lg:col-span-4 space-y-3">
              {/* Category Filter Pills */}
              <div className="flex flex-wrap gap-1.5 pb-2">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                      selectedCategory === cat
                        ? 'bg-slate-700 text-white'
                        : 'bg-slate-900 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* Endpoint Item Cards */}
              <div className="space-y-2 max-h-[700px] overflow-y-auto pr-1">
                {filteredEndpoints.map((ep) => {
                  const isSelected = ep.id === selectedEndpoint.id;
                  const methodColor =
                    ep.method === 'GET'
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                      : ep.method === 'POST'
                      ? 'bg-blue-500/20 text-blue-300 border-blue-500/30'
                      : ep.method === 'PUT' || ep.method === 'PATCH'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                      : 'bg-rose-500/20 text-rose-300 border-rose-500/30';

                  return (
                    <div
                      key={ep.id}
                      onClick={() => setSelectedEndpointId(ep.id)}
                      className={`p-3 rounded-xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-slate-850 border-indigo-500 shadow-md ring-1 ring-indigo-500/40'
                          : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${methodColor}`}>
                          {ep.method}
                        </span>
                        <span className="font-mono text-xs text-slate-200 font-semibold truncate">
                          {ep.path}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                        {ep.summary}
                      </p>
                      <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2">
                        <span>{ep.category}</span>
                        {ep.authRequired && (
                          <span className="flex items-center gap-0.5 text-amber-400">
                            <Shield className="w-3 h-3" />
                            Auth
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Execution Console (Right 8 cols) */}
            <div className="lg:col-span-8 space-y-4">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
                {/* Method & Path Bar */}
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold ${
                        selectedEndpoint.method === 'GET'
                          ? 'bg-emerald-500 text-slate-800'
                          : selectedEndpoint.method === 'POST'
                          ? 'bg-blue-500 text-white'
                          : 'bg-amber-500 text-slate-800'
                      }`}
                    >
                      {selectedEndpoint.method}
                    </span>
                    <span className="font-mono text-sm font-bold text-white">
                      {selectedEndpoint.path}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleCopyCurl}
                      className="flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-medium transition-all"
                    >
                      {hasCopiedCurl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{hasCopiedCurl ? 'Copied' : 'cURL'}</span>
                    </button>

                    <button
                      id="api-send-request-btn"
                      onClick={handleExecute}
                      disabled={isExecuting}
                      className="flex items-center gap-1.5 px-4 py-1.5 bg-indigo-500 hover:bg-indigo-600 text-white font-bold rounded-xl text-xs transition-all shadow-md disabled:opacity-50"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>{isExecuting ? 'Calling API...' : 'Send Request'}</span>
                    </button>
                  </div>
                </div>

                {/* Description */}
                <div className="my-3 text-xs text-slate-300">
                  <p>{selectedEndpoint.description}</p>
                </div>

                {/* Request Body & Params Editor */}
                {selectedEndpoint.method !== 'GET' && (
                  <div className="mt-4">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                      Request JSON Payload (Body)
                    </label>
                    <textarea
                      rows={6}
                      value={customRequestBody}
                      onChange={(e) => setCustomRequestBody(e.target.value)}
                      className="w-full bg-white border border-slate-800 rounded-xl p-3 font-mono text-xs text-emerald-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 leading-relaxed"
                    />
                  </div>
                )}

                {/* Response Viewer HUD */}
                <div className="mt-5">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                      Response Output
                    </label>
                    {lastStatusCode !== null && (
                      <div className="flex items-center gap-2 text-xs font-mono">
                        <span
                          className={`px-2 py-0.5 rounded font-bold ${
                            lastStatusCode < 300
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          Status: {lastStatusCode} OK
                        </span>
                        <span className="text-slate-400">{lastDurationMs} ms</span>
                      </div>
                    )}
                  </div>

                  <div className="bg-white border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-200 overflow-x-auto max-h-[360px] leading-relaxed shadow-inner">
                    <pre className="text-emerald-300">
                      {lastResponse
                        ? JSON.stringify(lastResponse, null, 2)
                        : JSON.stringify(selectedEndpoint.responseSuccessExample, null, 2)}
                    </pre>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: LIVE TRAFFIC LOGS */}
        {activeTab === 'logs' && (
          <div className="mt-6 space-y-4">
            <div className="flex justify-between items-center bg-slate-900 p-3 rounded-2xl border border-slate-800">
              <span className="text-xs text-slate-400">Showing last {apiLogs.length} real-time REST events</span>
              <button
                onClick={clearApiLogs}
                className="flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear Logs</span>
              </button>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-white text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                    <tr>
                      <th className="px-4 py-3">Timestamp</th>
                      <th className="px-4 py-3">Method</th>
                      <th className="px-4 py-3">Endpoint Path</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3">Duration</th>
                      <th className="px-4 py-3">Client IP / Role</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 font-mono">
                    {apiLogs.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-850 transition-colors">
                        <td className="px-4 py-3 text-slate-400">{log.timestamp}</td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              log.method === 'GET'
                                ? 'bg-emerald-500/20 text-emerald-300'
                                : 'bg-blue-500/20 text-blue-300'
                            }`}
                          >
                            {log.method}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-slate-200 font-semibold">{log.endpoint}</td>
                        <td className="px-4 py-3">
                          <span className="text-emerald-400 font-bold">{log.statusCode}</span>
                        </td>
                        <td className="px-4 py-3 text-slate-400">{log.durationMs}ms</td>
                        <td className="px-4 py-3 text-slate-400">{log.clientIp} ({log.role})</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: WEBHOOKS */}
        {activeTab === 'webhooks' && (
          <div className="mt-6 bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              Event Webhook Subscriptions (Stripe, Razorpay, Logistics)
            </h3>
            <p className="text-xs text-slate-400">
              Antifly sends HMAC SHA-256 signed event payloads to registered listener URLs on order updates, dispatches, and refunds.
            </p>

            <div className="space-y-3 pt-2">
              {[
                { event: 'order.created', url: 'https://webhook.site/antifly-order-sink', status: 'Active (200 OK)' },
                { event: 'driver.delivery_completed', url: 'https://crm.antifly.com/webhooks/logistics', status: 'Active (200 OK)' },
                { event: 'seller.payout_settled', url: 'https://finance.antifly.com/api/v1/settle', status: 'Active (200 OK)' },
              ].map((wh, i) => (
                <div key={i} className="bg-white p-3.5 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div>
                    <span className="font-mono font-bold text-indigo-400">{wh.event}</span>
                    <span className="text-slate-400 font-mono block text-[11px] mt-0.5">{wh.url}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 font-bold">
                    {wh.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: API KEYS */}
        {activeTab === 'keys' && (
          <div className="mt-6 bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Key className="w-4 h-4 text-emerald-400" />
              Production & Sandbox API Credentials
            </h3>
            <div className="space-y-3">
              <div className="bg-white p-4 rounded-xl border border-slate-800 flex justify-between items-center">
                <div>
                  <span className="text-slate-400 text-xs font-semibold block">Live Production Secret Key:</span>
                  <span className="font-mono text-emerald-400 text-sm font-bold">sk_live_wise9928190283019283</span>
                </div>
                <button
                  onClick={() => showToast('New secret key generated and sent to Admin email!')}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-lg"
                >
                  Roll Key
                </button>
              </div>

              <div className="bg-white p-4 rounded-xl border border-slate-800 flex justify-between items-center">
                <div>
                  <span className="text-slate-400 text-xs font-semibold block">Public Publishable Key (Client Web/Apps):</span>
                  <span className="font-mono text-blue-400 text-sm font-bold">pk_live_wise7718291028391829</span>
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText('pk_live_wise7718291028391829');
                    showToast('Public key copied');
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-lg"
                >
                  Copy
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
