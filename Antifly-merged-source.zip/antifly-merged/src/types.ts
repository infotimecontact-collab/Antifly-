export type DeviceMode =
  | 'website'
  | 'mobile-ios'
  | 'mobile-android'
  | 'seller'
  | 'seller-android'
  | 'seller-ios'
  | 'driver'
  | 'admin'
  | 'api-docs';
export type ThemeMode = 'light' | 'dark' | 'system';
export type LanguageCode =
  | 'en' // English
  | 'hi' // Hindi (हिन्दी)
  | 'mr' // Marathi (मराठी)
  | 'bn' // Bengali (বাংলা)
  | 'te' // Telugu (తెలుగు)
  | 'ta' // Tamil (தமிழ்)
  | 'gu' // Gujarati (ગુજરાતી)
  | 'kn' // Kannada (ಕನ್ನಡ)
  | 'ml' // Malayalam (മലയാളം)
  | 'pa' // Punjabi (ਪੰਜਾਬੀ)
  | 'or' // Odia (ଓଡ଼ିଆ)
  | 'ur' // Urdu (اردو)
  | 'as' // Assamese (অসমীয়া)
  | 'bho' // Bhojpuri (भोजपुरी)
  | 'mwr' // Marwari (मारवाड़ी)
  | 'mai' // Maithili (मैथिली)
  | 'es' // Spanish (Español)
  | 'fr' // French (Français)
  | 'de' // German (Deutsch)
  | 'ar' // Arabic (العربية)
  | 'zh' // Chinese (中文)
  | 'ja' // Japanese (日本語)
  | 'pt'; // Portuguese (Português)

export interface LanguageInfo {
  code: LanguageCode;
  name: string;
  nativeName: string;
  flag: string;
  dir: 'ltr' | 'rtl';
}
export type OrderSource = 'Website' | 'Android App' | 'iOS App' | 'Admin';
export type OrderStatus = 'Pending' | 'Confirmed' | 'Packed' | 'Shipped' | 'Out for delivery' | 'Delivered' | 'Cancelled' | 'Returned' | 'Refunded';
export type PaymentMethod =
  | 'UPI'
  | 'Credit/Debit Card'
  | 'Net Banking'
  | 'Wallets'
  | 'Cash on Delivery'
  | 'Stripe (Apple/Google Pay)'
  | 'PayPal Worldwide'
  | 'Klarna (BNPL)';

export type CountryCode = 'IN' | 'US' | 'GB' | 'EU' | 'AE' | 'CA' | 'AU' | 'SG';
export type CurrencyCode = 'INR' | 'USD' | 'GBP' | 'EUR' | 'AED' | 'CAD' | 'AUD' | 'SGD';

export interface RegionConfig {
  code: CountryCode;
  name: string;
  flag: string;
  currency: CurrencyCode;
  symbol: string;
  rateFromINR: number; // e.g. 1 INR = 0.012 USD
  taxRate: number; // e.g. 0.0825 for US, 0.18 for India
  taxName: string; // GST, US State Tax, UK VAT, EU VAT, UAE VAT
  phoneCode: string;
  postalCodeLabel: string;
  postalCodePlaceholder: string;
  defaultCourier: string;
  supportedPaymentMethods: PaymentMethod[];
  states: string[];
  freeShippingThresholdUSD: number;
  standardShippingFeeUSD: number;
}

export interface ProductVariant {
  id: string;
  sku: string;
  color: string;
  colorHex: string;
  size: string;
  price: number;
  mrp: number;
  stock: number;
  image?: string;
}

export interface ProductSpecification {
  label: string;
  value: string;
}

export interface ProductReview {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  title: string;
  comment: string;
  date: string;
  verifiedPurchase: boolean;
  isVerified?: boolean;
  images?: string[];
  pros?: string[];
  cons?: string[];
  helpfulCount?: number;
  location?: string;
  status: 'Approved' | 'Pending' | 'Rejected';
  featured?: boolean;
}

export interface ProductQuestion {
  id: string;
  question: string;
  askedBy: string;
  date: string;
  answer?: string;
  answeredBy?: string;
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  barcode: string;
  brand: string;
  category: string;
  subcategory: string;
  shortDescription: string;
  description: string;
  price: number;
  mrp: number;
  discountPercentage: number;
  taxPercentage: number;
  finalPrice: number;
  totalStock: number;
  rating: number;
  reviewCount: number;
  images: string[];
  videoUrl?: string;
  variants: ProductVariant[];
  colors: { name: string; hex: string }[];
  sizes: string[];
  materials: string[];
  specifications: ProductSpecification[];
  features: string[];
  tags: string[];
  searchKeywords: string[];
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  shippingInfo: string;
  returnPolicy: string;
  exchangePolicy: string;
  reviews?: ProductReview[];
  isPublished: boolean;
  isFeatured?: boolean;
  isTrending?: boolean;
  isNewArrival?: boolean;
  isBestSeller?: boolean;
  isBestseller?: boolean;
  isDealOfTheDay?: boolean;
  title?: string;
  image?: string;
  stock?: number;
  reviewsCount?: number;
  slug?: string;
  createdAt?: string;
  updatedAt?: string;
  sellerId?: string;
  storeName?: string;
  storeCity?: string;
  storeAddress?: string;
  storeLat?: number;
  storeLng?: number;
  deliveryRadiusKm?: number;
  isWholesale?: boolean;
  minOrderQuantity?: number;
  wholesalePricePerUnit?: number;
  wholesaleLotSize?: number;
  wholesaleLotPrice?: number;
  wholesalePackagingType?: string;
  isDealershipProduct?: boolean;
  dealershipAuthorized?: boolean;
  dealershipMarginPercentage?: number;
  isSingleSellerVendor?: boolean;
  wholesaleTiers?: Array<{ minQty: number; pricePerUnit: number; discountPercent: number; label: string }>;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: string;
  iconName: string;
  subcategories: string[];
  itemCount: number;
  isFeatured: boolean;
  bannerImage?: string;
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  type: 'Hero' | 'Promotional' | 'Category' | 'Offer' | 'App' | 'Popup';
  desktopImage: string;
  mobileImage: string;
  ctaText: string;
  destinationUrl: string;
  categorySlug?: string;
  productId?: string;
  discountBadge?: string;
  priority: number;
  isActive: boolean;
  startDate?: string;
  endDate?: string;
  timingSeconds?: number;
  liveTag?: string;
  themeStyle?: string;
}

export interface HomepageSection {
  id: string;
  title: string;
  subtitle?: string;
  type:
    | 'hero-banner'
    | 'categories-grid'
    | 'trending-products'
    | 'flash-deals'
    | 'ai-recommendations'
    | 'new-arrivals'
    | 'best-sellers'
    | 'deal-of-day'
    | 'collection-spotlight'
    | 'shop-by-price'
    | 'shop-by-occasion'
    | 'customer-reviews'
    | 'app-download'
    | 'features-bar';
  order: number;
  isVisible: boolean;
  config?: Record<string, any>;
}

export interface CartItem {
  id: string;
  productId: string;
  variantId: string;
  productName: string;
  brand: string;
  color: string;
  size: string;
  price: number;
  mrp: number;
  image: string;
  quantity: number;
  stock: number;
  isWholesale?: boolean;
  minOrderQuantity?: number;
  wholesaleLotSize?: number;
  wholesalePricePerUnit?: number;
  wholesalePackagingType?: string;
  isDealershipProduct?: boolean;
  isSingleSellerVendor?: boolean;
}

export interface Address {
  id: string;
  fullName: string;
  phone: string;
  street: string;
  apartment?: string;
  city: string;
  state: string;
  pincode: string;
  country: string;
  isDefault: boolean;
  type: 'Home' | 'Work' | 'Other';
}

export interface OrderItem {
  productId: string;
  variantId: string;
  productName: string;
  brand: string;
  color: string;
  size: string;
  price: number;
  mrp: number;
  quantity: number;
  image: string;
  isWholesale?: boolean;
  minOrderQuantity?: number;
  wholesaleLotSize?: number;
  wholesalePricePerUnit?: number;
  wholesalePackagingType?: string;
  isDealershipProduct?: boolean;
  isSingleSellerVendor?: boolean;
}

export interface OrderTrackingEvent {
  status: OrderStatus;
  timestamp: string;
  location: string;
  description: string;
  isCompleted: boolean;
}

export interface Order {
  id: string;
  orderNumber: string;
  source: OrderSource;
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  shippingAddress: Address;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  tax: number;
  shippingFee: number;
  totalAmount: number;
  paymentMethod: PaymentMethod;
  paymentStatus: 'Pending' | 'Paid' | 'Failed' | 'Refunded';
  transactionId?: string;
  status: OrderStatus;
  createdAt: string;
  updatedAt: string;
  estimatedDelivery: string;
  courierName?: string;
  trackingNumber?: string;
  timeline: OrderTrackingEvent[];
  cancelReason?: string;
  returnReason?: string;
  returnStatus?: 'None' | 'Requested' | 'Approved' | 'Rejected' | 'Refunded' | 'Exchanged';
  invoiceUrl?: string;
  deliveryOtp?: string;
  sellerId?: string;
  storeName?: string;
  storeAddress?: string;
  storeCity?: string;
  distanceKm?: number;
  assignedDriverId?: string;
  assignedDriverName?: string;
  assignedDriverPhone?: string;
}

export interface Coupon {
  id: string;
  code: string;
  description: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minCartValue: number;
  maxDiscount?: number;
  startDate: string;
  endDate: string;
  usageLimit: number;
  usedCount: number;
  isActive: boolean;
  appOnly: boolean;
  websiteOnly: boolean;
  categoryRestriction?: string;
}

export interface ReturnRequest {
  id: string;
  orderId: string;
  orderNumber: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  productId: string;
  productName: string;
  productImage: string;
  reason: string;
  type: 'Refund' | 'Exchange';
  requestedExchangeSize?: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Completed';
  createdAt: string;
  comment?: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  registeredAt: string;
  totalOrders: number;
  totalSpent: number;
  lastOrderDate?: string;
  addresses: Address[];
  status: 'Active' | 'Inactive' | 'Blocked';
  tags: string[];
  preferredSource: OrderSource;
  avatar?: string;
  followingSellerIds?: string[];
}

export interface AbandonedCart {
  id: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  source: OrderSource;
  items: CartItem[];
  cartValue: number;
  abandonedAt: string;
  reminderSent: boolean;
  reminderCount: number;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  userRole: string;
  action: string;
  module: 'Products' | 'Orders' | 'Banners' | 'Coupons' | 'Inventory' | 'Settings' | 'Returns' | 'CMS';
  details: string;
  timestamp: string;
  ipAddress?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'order' | 'promo' | 'system' | 'email_preview';
  timestamp: string;
  isRead: boolean;
  link?: string;
  emailHtml?: string;
}

export interface CMSPage {
  slug: string;
  title: string;
  metaDescription: string;
  content: string;
  lastUpdated: string;
  version: string;
}

export interface StoreSettings {
  storeName: string;
  contactPhone: string;
  contactEmail: string;
  businessAddress: string;
  currencySymbol: string;
  freeShippingThreshold: number;
  standardShippingFee: number;
  expressShippingFee: number;
  gstPercentage: number;
  codEnabled: boolean;
  upiEnabled: boolean;
  cardsEnabled: boolean;
  netBankingEnabled: boolean;
  stripeEnabled: boolean;
  paypalEnabled: boolean;
  klarnaEnabled: boolean;
  wiseAiEnabled: boolean;
  // Geolocation & Delivery Radius Config
  defaultStoreSearchRadiusKm?: number;
  maxStoreSearchRadiusKm?: number;
  platformCommissionPercentage?: number;
  baseDeliveryFee?: number;
  deliveryFeePerKm?: number;
  driverBaseFee?: number;
  driverPerKmFee?: number;
  driverSearchRadiusKm?: number;
  driverAutoExpandRadius?: boolean;
}

export interface SupportTicket {
  id: string;
  ticketNumber: string;
  creatorRole: 'customer' | 'seller' | 'driver';
  creatorId: string;
  creatorName: string;
  creatorPhone: string;
  subject: string;
  category: 'Order Issue' | 'Delivery Delay' | 'Payment/Payout' | 'Account Verification' | 'Product Dispute' | 'Technical Bug' | 'Other';
  status: 'OPEN' | 'ASSIGNED' | 'IN_PROGRESS' | 'WAITING' | 'RESOLVED' | 'CLOSED';
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
  assignedTo?: string;
  createdAt: string;
  updatedAt: string;
  internalNotes?: string;
  messages: Array<{
    id: string;
    senderRole: string;
    senderName: string;
    text: string;
    timestamp: string;
    isStaff: boolean;
  }>;
}

export interface StoreCommunityPost {
  id: string;
  sellerId: string;
  storeName: string;
  storeAvatar: string;
  title: string;
  content: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video' | 'reel';
  videoThumbnail?: string;
  featuredProductIds?: string[];
  likesCount: number;
  likedByUserIds: string[];
  commentsCount: number;
  comments: Array<{
    id: string;
    userId: string;
    userName: string;
    userAvatar?: string;
    text: string;
    timestamp: string;
  }>;
  pinned: boolean;
  createdAt: string;
  discountBadge?: string;
}

export interface StoreCommunity {
  sellerId: string;
  storeName: string;
  tagline: string;
  bannerUrl: string;
  avatarUrl: string;
  membersCount: number;
  memberUserIds: string[];
  rules: string[];
  topics: string[];
  isVerified: boolean;
}

export type ChatMode = 'normal' | 'disappearing' | 'private_media' | 'shopping';

export type MessageDeliveryStatus = 'pending' | 'sent' | 'delivered' | 'read';

export interface MessageReaction {
  emoji: string;
  userId: string;
  userName: string;
  timestamp: string;
}

export interface MessageReplyQuote {
  id: string;
  senderName: string;
  text: string;
  mediaUrl?: string;
  mediaType?: string;
}

export interface MessageProductCard {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  mrp?: number;
  image: string;
  brand?: string;
  rating?: number;
  category?: string;
  inStock?: boolean;
  storeName?: string;
  discountPercent?: number;
}

export interface MessageProfileCard {
  id: string;
  name: string;
  avatar: string;
  role?: 'customer' | 'seller' | 'driver';
  handle?: string;
  bio?: string;
  city?: string;
  followersCount?: number;
  isVerified?: boolean;
  badge?: string;
}

export interface MessageStoreCard {
  id: string;
  name: string;
  avatar: string;
  banner?: string;
  rating: number;
  category: string;
  city: string;
  address?: string;
  isVerified?: boolean;
  totalProducts?: number;
}

export interface MessagePostCard {
  id: string;
  title: string;
  image?: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video';
  authorName?: string;
  authorAvatar?: string;
  storeName?: string;
  storeAvatar?: string;
  content?: string;
  likesCount?: number;
  badge?: string;
}

export interface VoiceNoteData {
  durationSec: number;
  waveform: number[];
  audioUrl?: string;
  isPlayed?: boolean;
}

export interface ViewOnceSnapData {
  isViewOnce?: boolean;
  maxViews?: number;
  viewCount?: number;
  isOpened?: boolean;
  isExpired?: boolean;
  mediaUrl?: string;
  durationSec?: number;
  caption?: string;
}

export interface StoreChatBargainOffer {
  id: string;
  productId: string;
  productName: string;
  productImage: string;
  originalPrice: number;
  requestedPrice: number;
  quantity: number;
  status: 'PENDING' | 'ACCEPTED' | 'COUNTERED' | 'REJECTED' | 'ORDERED';
  counterPrice?: number;
  sellerNote?: string;
  createdAt: string;
  expiresAt: string;
}

export interface StoreChatMessage {
  id: string;
  chatId: string;
  senderRole: 'customer' | 'seller' | 'driver';
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  text: string;
  timestamp: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video' | 'reel' | 'audio';
  bargainOffer?: StoreChatBargainOffer;
  replyTo?: MessageReplyQuote;
  reactions?: MessageReaction[];
  deliveryStatus?: MessageDeliveryStatus;
  isEdited?: boolean;
  editedAt?: string;
  isDeleted?: boolean;
  deletedForEveryone?: boolean;
  isPinned?: boolean;
  chatModeSnapshot?: ChatMode;
  expiresAt?: string;
  isDisappearing?: boolean;
  productCard?: MessageProductCard;
  profileCard?: MessageProfileCard;
  storeCard?: MessageStoreCard;
  postCard?: MessagePostCard;
  voiceNote?: VoiceNoteData;
  viewOnceSnap?: ViewOnceSnapData;
  isSystemAlert?: boolean;
  systemAlertType?: 'screenshot' | 'mode_changed' | 'timer_changed' | 'call_log';
}

export interface ChatPartnerUser {
  id: string;
  name: string;
  avatar: string;
  role?: 'customer' | 'seller' | 'driver';
  storeName?: string;
  phone?: string;
  handle?: string;
  isOnline?: boolean;
  lastSeen?: string;
  isVerified?: boolean;
  bio?: string;
  location?: string;
}

export interface StoreChatSession {
  id: string;
  sellerId?: string;
  storeName: string;
  storeAvatar: string;
  customerId?: string;
  customerName: string;
  customerPhone: string;
  lastMessageText: string;
  lastMessageTime: string;
  unreadCustomerCount: number;
  unreadSellerCount: number;
  unreadCount?: number;
  activeBargain?: StoreChatBargainOffer;
  messages: StoreChatMessage[];
  
  // Extended 1-to-1 Social & Commerce Messaging
  chatType?: 'direct_user' | 'store_customer' | 'driver_customer' | 'group';
  chatMode?: ChatMode;
  disappearingTimerSec?: number; // 0 = off, 10, 60, 86400, 604800
  isMuted?: boolean;
  isBlocked?: boolean;
  isArchived?: boolean;
  isPinned?: boolean;
  isRequest?: boolean; // Requests tab
  isMessageRequest?: boolean;
  partnerUser?: ChatPartnerUser;
  readReceiptsEnabled?: boolean;
  isTyping?: boolean;
  draftMessage?: string;
}

export interface ActiveCallState {
  isOpen: boolean;
  partner: ChatPartnerUser;
  type: 'audio' | 'video';
  status: 'ringing' | 'connected' | 'ended';
  isMuted: boolean;
  isCameraOff: boolean;
  isSpeaker: boolean;
  durationSec: number;
}


export interface AdminRole {
  id: string;
  roleName: string;
  description: string;
  permissions: string[];
}

export interface RefundRecord {
  id: string;
  orderId: string;
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  amount: number;
  currency: CurrencyCode;
  paymentMethod: PaymentMethod;
  initiatedAt: string;
  expectedCreditDate: string; // 5 working days
  currentDay: number; // 1, 2, 3, 4, or 5
  status: 'Initiated' | 'Bank_Processing' | 'Gateway_Clearance' | 'Settlement_Scheduled' | 'Credited';
  bankReferenceNumber: string; // ARN / UTR
  refundReason: string;
  destinationAccount: string; // e.g. "HDFC Bank (ending in 4821)" or "Stripe card (ending in 9214)"
  dayLog: { day: number; title: string; desc: string; date: string; isComplete: boolean }[];
}

export interface GatewayKeysConfig {
  stripePublishableKey: string;
  stripeSecretKey: string;
  stripeWebhookSecret: string;
  stripeLiveMode: boolean;
  
  razorpayKeyId: string;
  razorpayKeySecret: string;
  razorpayLiveMode: boolean;
  
  paypalClientId: string;
  paypalSecretKey: string;
  paypalLiveMode: boolean;

  twilioSid: string;
  twilioAuthToken: string;
  twilioFromNumber: string;
  twilioEnabled: boolean;

  msg91AuthKey: string;
  msg91SenderId: string;
  msg91Enabled: boolean;

  sendgridApiKey: string;
  sendgridFromEmail: string;
  sendgridFromName: string;
  sendgridEnabled: boolean;

  googleMapsApiKey: string;
  mapsTrackingEnabled: boolean;

  geminiApiKey: string;
  aiModelName: string;
}

export interface DataPrivacySettings {
  gdprActive: boolean;
  dpdpIndiaActive: boolean;
  ccpaActive: boolean;
  cookieConsentBanner: boolean;
  dataRetentionDays: number;
  allowSelfAccountDeletion: boolean;
  anonymizeOrdersAfterMonths: number;
  auditTrailExportEnabled: boolean;
  complianceContactEmail: string;
}

export interface InvoiceData {
  invoiceNumber: string;
  orderNumber: string;
  invoiceDate: string;
  orderDate: string;
  sellerDetails: {
    name: string;
    tradeName: string;
    gstinOrVat: string;
    pan: string;
    cin: string;
    address: string;
    phone: string;
    email: string;
  };
  buyerDetails: {
    name: string;
    address: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
    phone: string;
    email: string;
    taxId?: string;
  };
  items: {
    name: string;
    sku: string;
    hsnCode: string;
    quantity: number;
    unitPrice: number;
    taxRate: number;
    taxAmount: number;
    total: number;
  }[];
  subtotal: number;
  taxTotal: number;
  taxLabel: string;
  shippingFee: number;
  discount: number;
  grandTotal: number;
  currency: CurrencyCode;
  currencySymbol: string;
  paymentMethod: PaymentMethod;
  paymentStatus: string;
  irnNumber?: string;
  qrCodeUrl?: string;
}

export interface MapTrackingState {
  orderId: string;
  courierName: string;
  trackingNumber: string;
  riderName: string;
  riderPhone: string;
  vehicleNumber: string;
  vehicleType: 'bike' | 'van' | 'plane';
  currentStepIndex: number;
  originHub: { name: string; city: string; lat: number; lng: number };
  transitHub: { name: string; city: string; lat: number; lng: number };
  deliveryHub: { name: string; city: string; lat: number; lng: number };
  destination: { name: string; city: string; lat: number; lng: number };
  currentLocation: { lat: number; lng: number; address: string };
  etaMinutes: number;
}

// ==========================================
// DYNAMIC DRIVER LOGISTICS & SEASONAL PRICING ENGINE
// ==========================================
export type DeliverySeasonType = 'NORMAL' | 'SUMMER' | 'RAINY' | 'WINTER';

export interface AdminDriverRateConfig {
  baseFare: number; // Minimum ₹30 floor (can be ₹30 or more than ₹30)
  ratePerKm: number; // e.g. ₹15/km
  currentSeason: DeliverySeasonType;
  autoWeatherSync: boolean;
  
  // Seasonal Allowances & Multipliers
  summerHeatAllowance: number; // e.g. ₹15 extra per trip in hot weather
  summerMultiplier: number; // e.g. 1.25x
  summerTemperatureThreshold: number; // e.g. 38°C
  
  rainyMonsoonAllowance: number; // e.g. ₹25 extra per trip during rain
  rainyMultiplier: number; // e.g. 1.4x
  
  winterColdAllowance: number; // e.g. ₹10 extra per trip
  winterMultiplier: number; // e.g. 1.15x
  
  // Night shift & priority express surge
  nightShiftAllowance: number; // e.g. ₹20 extra
  expressPriorityBonus: number; // e.g. ₹30 extra
  
  // Guaranteed Payout Floor (Must be >= ₹30)
  minGuaranteedPayoutFloor: number;
  lastUpdated: string;
}

// ==========================================
// DYNAMIC GAMIFICATION, COINS, DIAMONDS & MEMBERSHIPS
// ==========================================
export interface DynamicMembershipTier {
  id: string;
  name: string; // e.g. 'Silver Starter', 'Gold Elite', 'Diamond VIP', 'WiseOne Master'
  badgeIcon: string;
  minPointsOrSpend: number;
  coinsMultiplier: number; // e.g. 1x, 1.5x, 2x, 3x, 5x
  diamondCashbackPercent: number; // e.g. 2%, 5%, 10%
  freeExpressDelivery: boolean;
  priorityDispatch: boolean;
  earlyAccessHours: number;
  annualFee: number; // In ₹ or 0 for earn-by-spend
  colorGradient: string;
  perks: string[];
}

export interface DiamondTransaction {
  id: string;
  type: 'Earned' | 'Converted' | 'Spent';
  diamondsAmount: number;
  coinsEquivalent?: number;
  description: string;
  date: string;
}

export interface AdminGamificationConfig {
  // SuperCoins System
  coinsEarnedPer100Spent: number; // e.g. 4 coins per ₹100
  coinsToInrRedemptionRatio: number; // e.g. 1 Coin = ₹1
  welcomeBonusCoins: number; // e.g. 500 Coins
  dailyCheckInBonus: number; // e.g. 25 Coins
  maxCoinsRedemptionPercentagePerOrder: number; // e.g. 25% of order

  // Diamonds Currency System
  diamondToInrRatio: number; // e.g. 1 Diamond = ₹10
  diamondsEarnedPerOrder: number; // e.g. 5 Diamonds
  diamondsToCoinsConversionRate: number; // e.g. 1 Diamond = 10 SuperCoins
  referralRewardDiamonds: number; // e.g. 50 Diamonds
  spinWheelMinDiamonds: number;
  spinWheelMaxDiamonds: number;

  // Seasonal Multipliers for Gamification
  activeSeasonMultiplier: number; // e.g. 2x Coins & Diamonds in Summer / Monsoon
  seasonCampaignName: string; // e.g. "Monsoon Double Rewards Carnival"

  // Membership Tiers
  membershipTiers: DynamicMembershipTier[];
  lastUpdated: string;
}

// ==========================================
// FLIPKART SIGNATURE FEATURES
// ==========================================
export interface SuperCoinReward {
  id: string;
  title: string;
  description: string;
  coinsCost: number;
  monetaryValue: number;
  category: 'Discount' | 'OTT' | 'Travel' | 'GiftCard' | 'Dining';
  badge: string;
  imageUrl: string;
  partnerBrand: string;
  expiresInDays: number;
}

export interface SuperCoinTransaction {
  id: string;
  type: 'Earned' | 'Spent';
  amount: number;
  description: string;
  date: string;
  orderNumber?: string;
}

export interface PlusMemberTier {
  tierName: 'Silver' | 'Plus Member' | 'Plus Premium';
  superCoinsBalance: number;
  coinsMultiplier: number;
  freeExpressDelivery: boolean;
  earlyAccessHours: number;
  exclusiveDeals: boolean;
}

// ==========================================
// MEESHO SIGNATURE FEATURES
// ==========================================
export interface ResellerConfig {
  isReselling: boolean;
  resellerShopName: string;
  resellerPhone: string;
  resellerMarginPercentage?: number;
  totalEarnings: number;
  withdrawnEarnings: number;
  pendingEarnings: number;
}

export interface GroupBuyDeal {
  id: string;
  productId: string;
  productName: string;
  productImage: string;
  originalPrice: number;
  groupPrice: number;
  savings: number;
  requiredMembers: number;
  currentMembers: number;
  leaderName: string;
  leaderAvatar: string;
  expiresInSeconds: number;
  groupCode: string;
}

// ==========================================
// MYNTRA SIGNATURE FEATURES
// ==========================================
export interface StyleCastLook {
  id: string;
  title: string;
  influencerName: string;
  influencerHandle: string;
  influencerAvatar: string;
  coverImage: string;
  videoPreview?: string;
  occasion: 'Festive Glam' | 'Streetwear Casual' | 'Royal Wedding' | 'Old Money' | 'Workplace Chic';
  likesCount: number;
  viewsCount: string;
  taggedProductIds: string[];
  stylingTips: string[];
  bundleDiscountPercentage: number;
}

export interface SizeRecommendationProfile {
  heightCm: number;
  weightKg: number;
  bodyType: 'Slim' | 'Athletic' | 'Average' | 'Curvy' | 'Broad';
  fitPreference: 'Fitted' | 'Regular' | 'Relaxed / Oversized';
  recommendedSize: string;
  confidenceScore: number;
  matchedShoppersCount: number;
}

export interface CompleteTheLookBundle {
  id: string;
  mainProductId: string;
  title: string;
  bundleDiscountPercent: number;
  pairedProductIds: string[];
}

// ==========================================
// FOOD DELIVERY (WISEBITES / CLOUD KITCHENS)
// ==========================================
export interface FoodItemCustomization {
  name: string;
  required?: boolean;
  options: { label: string; price: number }[];
}

export interface FoodItem {
  id: string;
  name: string;
  description: string;
  price: number;
  mrp: number;
  isVeg: boolean;
  image: string;
  rating: number;
  votes: number;
  category: string;
  inStock: boolean;
  isBestseller?: boolean;
  isSpicy?: boolean;
  customizationOptions?: FoodItemCustomization[];
}

export interface RestaurantMenuCategory {
  id: string;
  name: string;
  items: FoodItem[];
}

export interface Restaurant {
  id: string;
  name: string;
  cuisines: string[];
  rating: number;
  ratingCount: string;
  deliveryTimeMin: number;
  deliveryTimeMax: number;
  priceForTwo: number;
  address: string;
  distanceKm: number;
  image: string;
  bannerImage: string;
  isPureVeg?: boolean;
  discountOffer: string;
  isPromoted?: boolean;
  menuCategories: RestaurantMenuCategory[];
}

export interface FoodCartItem {
  foodItem: FoodItem;
  restaurantId: string;
  restaurantName: string;
  quantity: number;
  selectedOptions?: { [key: string]: string };
  extraPrice: number;
  specialInstructions?: string;
}

export interface FoodOrder {
  id: string;
  restaurantId: string;
  restaurantName: string;
  restaurantImage: string;
  items: FoodCartItem[];
  subtotal: number;
  deliveryFee: number;
  discount: number;
  taxes: number;
  total: number;
  deliveryAddress: string;
  status: 'Confirmed' | 'Preparing in Kitchen' | 'Rider Picked Up' | 'Out for Delivery' | 'Delivered';
  placedAt: string;
  etaMinutes: number;
  riderName: string;
  riderPhone: string;
  riderVehicle: string;
  tipAmount: number;
}

// ==========================================
// ALL-IN-ONE MASTER SUBSCRIPTION (WISEONE PASS)
// ==========================================
export interface WiseOnePlan {
  id: string;
  name: string;
  price: number;
  originalPrice: number;
  duration: '1 Month' | '12 Months' | '3 Years';
  badge: string;
  tagline: string;
  benefits: string[];
  isPopular?: boolean;
  ottIncluded: string[];
  color: string;
}

export interface WiseOneSubscription {
  isActive: boolean;
  planId?: string;
  planName?: string;
  expiryDate?: string;
  totalSavedSoFar: number;
  freeDeliveriesUsed: number;
  ottPassesClaimed: string[];
}

// ==========================================
// ALL BANK CREDIT CARDS & EMI OFFERS
// ==========================================
export interface EMIOption {
  months: number;
  monthlyAmount: number;
  interestRate: number;
  totalInterest: number;
  isNoCost: boolean;
  minAmount: number;
}

export interface BankCardOffer {
  id: string;
  bankName: string;
  bankCode: 'HDFC' | 'SBI' | 'ICICI' | 'AXIS' | 'KOTAK' | 'AMEX' | 'RBL' | 'INDUSIND' | 'HSBC' | 'SC';
  cardType: 'Credit Card' | 'Debit Card' | 'EMI' | 'All Cards';
  discountPercent: number;
  maxDiscount: number;
  minOrderValue: number;
  code: string;
  title: string;
  description: string;
  iconBg: string;
  logoText: string;
  instantDiscountText: string;
  popularCardNames: string[];
  emiOptions?: EMIOption[];
}

// ==========================================
// OTT ENTERTAINMENT PLATFORM (WISESTREAM)
// ==========================================
export interface OTTPlatform {
  id: string;
  name: string;
  logo: string;
  brandColor: string;
  tagline: string;
  includedInPass: boolean;
  monthlyValue: number;
  featuredContentCount: string;
}

export interface OTTShow {
  id: string;
  title: string;
  platform: string;
  platformColor: string;
  category: 'Trending Movie' | 'Web Series' | 'Live Cricket & Sports' | 'Blockbuster' | 'Documentary';
  genre: string;
  rating: string;
  duration: string;
  releaseYear: number;
  thumbnail: string;
  bannerUrl: string;
  trailerVideoUrl?: string;
  description: string;
  cast: string[];
  isLiveEvent?: boolean;
  exclusiveBadge?: string;
}

// ==========================================
// GOOGLE ANALYTICS 4 (GA4) & TELEMETRY
// ==========================================
export type GA4EventName =
  | 'page_view'
  | 'view_item'
  | 'view_item_list'
  | 'select_item'
  | 'add_to_cart'
  | 'remove_from_cart'
  | 'view_cart'
  | 'begin_checkout'
  | 'add_shipping_info'
  | 'add_payment_info'
  | 'purchase'
  | 'refund'
  | 'search'
  | 'view_promotion'
  | 'select_promotion'
  | 'add_to_wishlist'
  | 'share'
  | 'rate_product'
  | 'food_order_placed'
  | 'subscription_purchased'
  | 'video_start'
  | 'video_progress'
  | 'video_complete';

export interface GA4AnalyticsEvent {
  id: string;
  eventName: GA4EventName;
  timestamp: string;
  source: string;
  url: string;
  params: {
    currency?: string;
    value?: number;
    transaction_id?: string;
    item_id?: string;
    item_name?: string;
    item_brand?: string;
    item_category?: string;
    price?: number;
    quantity?: number;
    search_term?: string;
    coupon?: string;
    shipping_tier?: string;
    payment_type?: string;
    promotion_id?: string;
    promotion_name?: string;
    rating?: number;
    [key: string]: any;
  };
  userProperties?: {
    user_id?: string;
    customer_tier?: string;
    region?: string;
    device_category?: string;
  };
}

export interface GA4Config {
  measurementId: string; // e.g. G-WISEIND99X
  gtmId: string; // e.g. GTM-WISE882
  trackingEnabled: boolean;
  debugMode: boolean;
  enhancedMeasurement: {
    scrolls: boolean;
    outboundClicks: boolean;
    siteSearch: boolean;
    videoEngagement: boolean;
    fileDownloads: boolean;
    ecommercePurchase: boolean;
  };
}

// ==========================================
// SEO & STRUCTURED DATA (SCHEMA.ORG)
// ==========================================
export interface SEOMetadata {
  metaTitle: string;
  metaDescription: string;
  metaKeywords: string[];
  canonicalUrl: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
  ogType: 'website' | 'product' | 'article';
  twitterCard: 'summary' | 'summary_large_image';
  structuredDataJsonLd: string;
  noIndex?: boolean;
}

// ==========================================
// SMART PRODUCT FINDER & OCCASION QUIZ
// ==========================================
export interface ProductFinderCriteria {
  recipient: 'Myself' | 'Partner' | 'Parents / Family' | 'Friend / Colleague' | 'Kids';
  occasion: 'Wedding & Festive' | 'Office & Formal' | 'Daily Casual & Lounging' | 'Party & Night Out' | 'Travel & Vacation' | 'Fitness & Active';
  budgetMax: number;
  categoryPreference: string;
  priorityFeature: 'Pure Breathable Fabric' | 'Heavy Discount (40%+)' | 'Customer Top Rated (4.5★+)' | 'Express Same-Day Dispatch' | 'Handcrafted Artisan Exclusive';
}

export interface ProductFinderMatch {
  product: Product;
  matchScore: number; // 0 - 100
  matchReason: string;
  highlightBadge: string;
}

// ==========================================
// SELLER CENTRAL & VENDOR MANAGEMENT
// ==========================================
export interface SellerProfile {
  id: string;
  storeName: string;
  name?: string;
  legalEntityName?: string;
  email: string;
  phone: string;
  gstNumber?: string;
  panNumber?: string;
  rating: number;
  totalOrders: number;
  totalRevenue?: number;
  balanceEscrow?: number;
  balanceAvailable?: number;
  commissionRate?: number; // e.g., 0.08 (8%)
  status?: string;
  tier?: 'Diamond Vendor' | 'Gold Supplier' | 'Silver Merchant' | 'New Onboard' | 'Verified Merchant' | string;
  locality?: string;
  isFollowed?: boolean;
  warehouseAddress?: {
    street: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
  };
  bankAccount?: {
    accountNumber: string;
    ifscCode: string;
    bankName: string;
    beneficiaryName: string;
  };
  fulfillmentType?: 'WiseFulfilled (FBF)' | 'Seller Self-Ship (FBM)';
  badge?: string;
  city?: string;
  lat?: number;
  lng?: number;
  deliveryRadiusKm?: number;
  isActive?: boolean;
  onboardingBonusClaimed?: boolean;
  category?: string;
  description?: string;
  bannerImage?: string;
  logoImage?: string;
  joinedDate?: string;
  accountType?: 'retail' | 'wholesale' | 'dealership' | 'hybrid';
  sellerRoleType?: 'Retailer' | 'Wholesaler' | 'Authorized Dealership' | 'Single Seller Vendor' | 'Master Wholesaler & Dealership';
  isWholesaler?: boolean;
  isDealershipVendor?: boolean;
  isSingleSellerVendor?: boolean;
  dealershipBrand?: string;
  dealershipAuthorized?: boolean;
  dealershipLicenseNo?: string;
  wholesaleMOQDefault?: number;
  wholesaleDiscountDefault?: number;
  wholesaleCatalogCategories?: string[];
  followersCount?: number;
  followedCustomerIds?: string[];
  isServiceProvider?: boolean;
  serviceType?: 'electrician' | 'plumber' | 'handyman' | 'carpenter' | 'cleaning' | 'general';
  serviceVisitFee?: number;
  serviceHourlyRate?: number;
  serviceEmergencyAvailable?: boolean;
  hasBulkUploadEnabled?: boolean;
  paymentQrUrl?: string;
  storeUpiId?: string;
  allowDirectPayment?: boolean;
  guaranteed7DayExchange?: boolean;
  storeQrUrl?: string;
  // Account Deactivation & Customer Conversion Lifecycle (7-Day Dynamic)
  isDeactivated?: boolean;
  deactivatedAt?: string;
  deactivationGraceDays?: number;
  deactivationScheduledDeletionDate?: string;
  deactivationReason?: string;
  isAutoApproved?: boolean;
}

export interface SellerPayout {
  id: string;
  sellerId: string;
  amount: number;
  currency: string;
  utrNumber: string;
  status: 'Completed' | 'Processing' | 'Pending';
  date: string;
  orderCount: number;
}

export type DriverKycStatus = 'PENDING_ADMIN_VERIFICATION' | 'APPROVED' | 'REJECTED' | 'SUSPENDED';

export interface DriverKycDocuments {
  // Original Bike / Vehicle proofs
  bikeRegistrationNumber: string;
  bikeRcDocumentUrl?: string;
  bikeInsuranceDocUrl?: string;
  bikePhotoUrl?: string;
  
  // Driving License
  drivingLicenseNumber: string;
  drivingLicenseFrontUrl?: string;
  drivingLicenseBackUrl?: string;
  
  // Aadhaar Card
  aadhaarNumber: string;
  aadhaarFrontUrl?: string;
  aadhaarBackUrl?: string;
  
  // Voter ID Card
  voterIdNumber: string;
  voterIdDocUrl?: string;
  
  // Profile / Live Selfie proof
  selfieUrl?: string;
  
  submittedAt: string;
  verifiedAt?: string;
  verifiedByAdmin?: string;
  rejectionReason?: string;
  slaExpiresAt?: string; // 24 hours SLA window
}

export interface AccountLifecycleConfig {
  driverGraceDays: number; // default 7 days (Admin dynamic)
  sellerGraceDays: number; // default 7 days (Admin dynamic)
  customerGraceDays: number; // default 30 days (Admin dynamic)
  driverVerificationSlaHours: number; // default 24 hours
  sellerAutoApprovalEnabled: boolean; // default true (Direct approval without admin blocking)
  allowInstantRoleConversion: boolean; // default true (Converts directly to normal customer)
  lastUpdated: string;
}

// ==========================================
// DRIVER & DELIVERY PARTNER MANAGEMENT
// ==========================================
export interface DriverProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  avatar: string;
  vehicleType: 'Electric Bike' | 'Motorcycle' | 'Cargo Van' | 'EV Scooter' | string;
  vehicleNumber: string;
  drivingLicense: string;
  city: string;
  rating: number;
  completedDeliveries: number;
  isOnline: boolean;
  isActive: boolean;
  isVerified?: boolean;
  kycStatus?: DriverKycStatus;
  kycDocs?: DriverKycDocuments;
  onboardingBonusClaimed: boolean;
  currentLat: number;
  currentLng: number;
  todayEarnings: number;
  todayTrips: number;
  walletBalance: number;
  cashInHand: number; // For COD collected
  badge: 'Top Gun Rider' | 'Speed Master' | 'Star Partner' | string;
  joinedDate: string;
  // Account Deactivation & Role Conversion Lifecycle (7-Day Dynamic)
  isDeactivated?: boolean;
  deactivatedAt?: string;
  deactivationGraceDays?: number;
  deactivationScheduledDeletionDate?: string;
  deactivationReason?: string;
}

export interface DriverDeliveryTask {
  id: string;
  orderId: string;
  trackingNumber: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  sellerId?: string;
  sellerName: string;
  sellerAddress: string;
  sellerPhone?: string;
  pickupLat: number;
  pickupLng: number;
  dropLat: number;
  dropLng: number;
  status: 'Assigned' | 'Heading to Pickup' | 'Picked Up' | 'In Transit' | 'Arrived at Drop' | 'Delivered' | 'Failed Attempt';
  paymentMode: 'PREPAID' | 'COD';
  codAmountToCollect: number;
  itemsCount: number;
  otpCode: string;
  distanceKm: number;
  estimatedMinutes: number;
  payoutFee: number;
  tipAmount: number;
  specialInstructions?: string;
  proofPhoto?: string;
  customerSignature?: string;
  deliveredAt?: string;
  assignedDriverId?: string;
  assignedDriverName?: string;
  assignedDriverPhone?: string;
  // Distance-Based Seller to Driver Payment
  ventureDistanceKm?: number;
  ventureRatePerKm?: number;
  ventureBaseFare?: number;
  venturePayableAmount?: number;
  venturePaymentStatus?: 'PAID' | 'PENDING' | 'SETTLED_ON_PICKUP';
  venturePaymentMethod?: 'VENTURE_WALLET' | 'DIRECT_UPI' | 'CASH_ON_PICKUP';
  venturePaymentUtr?: string;
  venturePaidAt?: string;
  seasonApplied?: DeliverySeasonType;
  seasonalSurgeBonus?: number;
}

export interface VentureBuddyBookingCall {
  id: string;
  ventureId: string;
  ventureName: string;
  venturePhone: string; // The caller number e.g. "9425821388"
  ventureStoreAddress: string;
  ventureLat: number;
  ventureLng: number;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  parcelDescription: string;
  packageWeightKg?: number;
  estimatedFare: number;
  radiusKm: number; // 5 km standard
  // Distance-based pricing breakdown (e.g. 1km=$15, 2km=$30, 3km=$45, 4km=$60, min ₹30 floor)
  deliveryDistanceKm: number;
  ratePerKm: number; // e.g. 15
  baseFee: number; // minimum ₹30 floor
  seasonalSurge: number; // Summer or Rainy or Winter hazard allowance
  seasonApplied: DeliverySeasonType;
  totalAmount: number; // max(minFloor, baseFee + deliveryDistanceKm * ratePerKm + seasonalSurge)
  paymentStatus: 'PAID' | 'PENDING' | 'SETTLED_ON_PICKUP';
  paymentMethod: 'VENTURE_WALLET' | 'DIRECT_UPI' | 'CASH_ON_PICKUP';
  paymentUtr?: string;
  paidAt?: string;
  status: 'RINGING' | 'ACCEPTED' | 'DECLINED' | 'CANCELLED' | 'COMPLETED';
  initiatedAt: string;
  ringingDriverIds: string[]; // List of all nearby buddies within 5km receiving the simultaneous call
  acceptedByDriverId?: string;
  acceptedByDriverName?: string;
  acceptedByDriverPhone?: string;
  acceptedByDriverDistanceKm?: number;
  etaMinutes?: number;
  linkedOrderId?: string;
  pickupOtp?: string;
}

export interface UserAccountProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar: string;
  city: string;
  currentLat: number;
  currentLng: number;
  isActive: boolean;
  superCoins: number;
  diamonds: number;
  membershipTierId?: string;
  welcomeBonusClaimed: boolean;
  joinedDate: string;
  rewardPoints?: number;
  ordersCount?: number;
  wishlistCount?: number;
  address?: string;
  lat?: number;
  lng?: number;
  savedAddresses?: Array<{
    id: string;
    title: string;
    street: string;
    city: string;
    state: string;
    pincode: string;
    phone: string;
    isDefault: boolean;
  }>;
  // Customer Deactivation & Deletion Lifecycle (30-Day Dynamic Admin Config)
  isDeactivated?: boolean;
  deactivatedAt?: string;
  deactivationGraceDays?: number;
  deactivationScheduledDeletionDate?: string;
  deactivationReason?: string;
  isPermanentlyDeleted?: boolean;
  deletedAt?: string;
}

// ==========================================
// ROLE EXCLUSIVITY & MOBILE NUMBER REGISTRY
// ==========================================
export type UserRole = 'customer' | 'seller' | 'driver';

export interface RegisteredAccount {
  id: string;
  phone: string;
  role: UserRole;
  name: string;
  email: string;
  registeredAt: string;
  entityId: string; // sellerId or driverId or customerId
  isActive: boolean;
  storeName?: string;
  vehicleType?: string;
  vehicleNumber?: string;
  drivingLicense?: string;
  category?: string;
  city?: string;
  // Lifecycle & Status fields
  isDeactivated?: boolean;
  deactivatedAt?: string;
  deactivationGraceDays?: number;
  deactivationScheduledDeletionDate?: string;
  kycStatus?: DriverKycStatus;
  kycDocs?: DriverKycDocuments;
}

export interface PhoneExclusivityCheckResult {
  hasConflict: boolean;
  isRegisteredForTargetRole: boolean;
  activeRole?: UserRole;
  conflictMessage?: string;
  account?: RegisteredAccount;
}

// ==========================================
// E-COMMERCE WORLD API SUITE
// ==========================================
export interface EcomAPIEndpoint {
  id: string;
  category: 'Authentication' | 'Catalog & Search' | 'Cart & Checkout' | 'Orders & Tracking' | 'Seller Central' | 'Driver Logistics' | 'Payments & Webhooks' | 'Analytics & Telemetry';
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  path: string;
  summary: string;
  description: string;
  authRequired: boolean;
  requiredRole?: 'customer' | 'seller' | 'driver' | 'admin' | 'public';
  requestParams?: Array<{
    name: string;
    type: string;
    required: boolean;
    description: string;
    example?: string;
  }>;
  requestBodyExample?: Record<string, any>;
  responseSuccessExample: Record<string, any>;
  responseErrorExample?: Record<string, any>;
}

export interface APIRequestLog {
  id: string;
  timestamp: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  endpoint: string;
  statusCode: number;
  durationMs: number;
  clientIp: string;
  role: string;
  payload?: any;
  response?: any;
}

// ==========================================
// UNIFIED ECOSYSTEM & MULTI-ROLE PERSONA (VICE-VERSA)
// ==========================================
export type UnifiedPersonaMode = 'customer' | 'seller' | 'driver' | 'admin';

export interface UserPersonaProfile {
  id: string;
  name: string;
  username?: string;
  phone: string;
  email: string;
  avatar: string;
  profilePictures: string[];
  bio?: string;
  city: string;
  activePersona: UnifiedPersonaMode;
  // Capability flags & proofs
  hasCustomerProfile: boolean;
  hasSellerProfile: boolean;
  hasDriverProfile: boolean;
  hasAdminProfile: boolean;
  rewardPoints: number;
  sharedStoreCount: number;
  followingUserIds: string[];
  followerUserIds: string[];
  // Shop details (if runs shop)
  shopName?: string;
  shopCategory?: string;
  shopAddress?: string;
  businessPhotos?: string[];
  // Driver details (if delivers)
  vehicleType?: string;
  vehicleNumber?: string;
  drivingLicenseNumber?: string;
  driverRadiusKm?: number;
  isDriverOnline?: boolean;
  // KYC verification
  isKycVerified: boolean;
  aadhaarOrGstDoc?: string;
  // Verified Badges (Blue/Gold Tick)
  hasCustomerTick: boolean;
  customerTickExpiresAt?: string;
  hasSellerTick: boolean;
  sellerTickExpiresAt?: string;
  isDiamondVendor?: boolean;
}

// ==========================================
// 5-SECOND SHORT PRODUCT VIDEO REELS
// ==========================================
export interface ShortVideoReel {
  id: string;
  sellerId: string;
  sellerName: string;
  sellerAvatar: string;
  isVerified: boolean;
  isDiamond: boolean;
  title: string;
  description: string;
  videoUrl: string;
  thumbnailUrl: string;
  durationSec: number;
  productId?: string;
  productName?: string;
  productPrice?: number;
  productImage?: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  tags: string[];
  musicTrackName?: string;
  createdAt: string;
}

// ==========================================
// SOCIAL COMMUNITY (THREADS & TWITTER STYLE)
// ==========================================
export interface CommunityMember {
  id: string;
  name: string;
  handle?: string;
  avatar: string;
  photos: string[];
  bio: string;
  location: string;
  isVerified: boolean;
  isDiamondVendor?: boolean;
  isMerchant?: boolean;
  merchantStoreName?: string;
  followersCount: number;
  followingCount: number;
  postsCount: number;
  recentPosts: Array<{
    id: string;
    text: string;
    image?: string;
    timestamp: string;
    likes: number;
    replies: number;
    storeMention?: string;
    storeId?: string;
  }>;
}

// ==========================================
// SELLER RATING & REVIEWS (1-10 SCALE)
// ==========================================
export interface SellerRatingReview {
  id: string;
  sellerId: string;
  customerId: string;
  customerName: string;
  customerAvatar?: string;
  rating10: number;
  feedback: string;
  verifiedOrder: boolean;
  createdAt: string;
}

// ==========================================
// DRIVER ON-DEMAND BROADCAST & PARCEL POOL
// ==========================================
export interface DriverBroadcastOrder {
  id: string;
  orderId: string;
  orderNumber: string;
  storeName: string;
  storeAddress: string;
  storeCity: string;
  storeLat: number;
  storeLng: number;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  customerCity: string;
  customerLat: number;
  customerLng: number;
  distanceKm: number;
  payoutINR: number;
  payoutUSD: number;
  itemCount: number;
  itemsSummary: string;
  status: 'BROADCASTING' | 'ACCEPTED' | 'PICKED_UP' | 'DELIVERED' | 'EXPIRED';
  acceptedByDriverId?: string;
  acceptedByDriverName?: string;
  acceptedByDriverPhone?: string;
  expiresAt: string;
  deliveryOtp: string;
  createdAt: string;
}

// ==========================================
// VENDOR CONNECT MEMBERSHIP & TIER QUOTA
// ==========================================
export type VendorConnectTier =
  | 'free_trial'
  | 'tier_10_sellers'
  | 'tier_100_sellers'
  | 'tier_500_sellers'
  | 'tier_1000_sellers';

export interface VendorConnectPlan {
  id: VendorConnectTier;
  title: string;
  priceUSD: number;
  priceINR: number;
  sellerQuota: number;
  description: string;
  isPopular?: boolean;
}

export interface CustomerConnectState {
  isFreeTrialActive: boolean;
  freeTrialDaysLeft: number;
  contactedSellerIds: string[];
  sellerQuota: number;
  currentTier: VendorConnectTier;
  purchasedAt?: string;
}

// ==========================================
// DRIVER MILESTONES & NEARBY GEOFENCING
// ==========================================
export interface DriverMilestoneProgress {
  deliveriesToday: number;
  targetTier1: number;
  targetTier2: number;
  tier1Achieved: boolean;
  tier2Achieved: boolean;
  bonusEarnedTodayUSD: number;
  bonusEarnedTodayINR: number;
  nearbyRadiusKm: number;
}

// ==========================================
// ADMIN SUPPORT & AI CHATBOT
// ==========================================
export interface SupportMessage {
  id: string;
  sender: 'user' | 'admin' | 'ai_bot';
  senderName: string;
  text: string;
  timestamp: string;
  attachmentUrl?: string;
}

// ==========================================
// SUB-ADMIN & ACCESS CONTROL DELEGATION
// ==========================================
export type AdminDepartment =
  | 'Operations'
  | 'Catalog & Products'
  | 'Logistics & Drivers'
  | 'Finance & Payouts'
  | 'Customer Support'
  | 'Merchant Verifications';

export interface SubAdmin {
  id: string;
  name: string;
  phone: string;
  email: string;
  department: AdminDepartment;
  roleTitle: string;
  permissions: string[]; // e.g. ['orders', 'sellers', 'drivers', 'inventory', 'cms', 'finance', 'support', 'broadcasts']
  status: 'ACTIVE' | 'SUSPENDED';
  createdAt: string;
  lastActive?: string;
  createdBy: string;
}

// ==========================================
// STORIES, WHATSAPP-LIKE STATUS & SELLER POSTS
// ==========================================
export type StoryMediaType = 'image' | 'video' | 'text' | 'deal';

export interface StoryViewRecord {
  userId: string;
  userName: string;
  userPhone?: string;
  userRole: 'customer' | 'driver' | 'seller';
  userAvatar?: string;
  viewedAt: string;
}

export interface StoryReply {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  text: string;
  createdAt: string;
}

export interface UserStory {
  id: string;
  authorId: string;
  authorName: string;
  authorPhone: string;
  authorRole: 'customer' | 'driver' | 'seller';
  authorAvatar: string;
  authorCity?: string;
  mediaType: StoryMediaType;
  mediaUrl?: string;
  text?: string;
  caption?: string;
  backgroundColor?: string;
  textColor?: string;
  createdAt: string;
  expiresAt: string;
  privacy: 'contacts_and_followers' | 'public';
  views: StoryViewRecord[];
  likes: string[]; // user IDs who liked
  replies: StoryReply[];
  isViewedByCurrentUser?: boolean;
  taggedSellerId?: string;
  taggedProductId?: string;
}

export interface UserPhoneContact {
  id: string;
  name: string;
  phone: string;
  avatar?: string;
  role: 'customer' | 'driver' | 'seller';
  isFollowed: boolean;
  isRegistered: boolean;
  addedAt: string;
  hasActiveStory?: boolean;
}

export interface SellerFeedComment {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  userRole?: 'customer' | 'driver' | 'seller';
  text: string;
  createdAt: string;
}

export interface SellerFeedPost {
  id: string;
  sellerId: string;
  sellerName: string;
  sellerPhone: string;
  sellerAvatar: string;
  sellerCity?: string;
  title: string;
  content: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video';
  badge?: string; // e.g. "FLAT 40% OFF", "NEW ARRIVAL", "FRESH BATCH"
  taggedProductIds?: string[];
  likesCount: number;
  likedByUserIds: string[];
  commentsCount: number;
  comments: SellerFeedComment[];
  sharesCount: number;
  createdAt: string;
  pinned?: boolean;
}

// ==========================================
// UNIVERSAL SAVE, FAVORITES, INTERESTED & NOT INTERESTED SYSTEM
// ==========================================
export type SaveItemType =
  | 'product'
  | 'seller'
  | 'user'
  | 'post'
  | 'reel'
  | 'story'
  | 'chat'
  | 'collection'
  | 'category'
  | 'search'
  | 'deal';

export interface UniversalSaveItem {
  id: string;
  itemType: SaveItemType;
  targetId: string; // Product ID, Seller ID, User ID, Post ID, Reel ID, Chat Session ID, etc.
  title: string;
  subtitle?: string;
  imageUrl?: string;
  savedAt: string;
  price?: number;
  originalPrice?: number;
  badge?: string;
  collectionIds: string[]; // Belongs to one or multiple custom collections
  notes?: string; // Personal private note
  tags?: string[];
  notifyPriceDrop?: boolean;
  notifyRestock?: boolean;
  notifyNewPosts?: boolean;
  socialSignals?: {
    savedByFriendsCount?: number;
    friendAvatars?: string[];
    friendNames?: string[];
    isTrendingInCity?: boolean;
    trendingRank?: number;
  };
  metadata?: {
    sellerId?: string;
    sellerName?: string;
    authorName?: string;
    authorHandle?: string;
    categorySlug?: string;
    rating?: number;
    reviewCount?: number;
    inStock?: boolean;
    location?: string;
    videoDurationSec?: number;
    lastMessageText?: string;
    searchQuery?: string;
    filters?: Record<string, any>;
    linkUrl?: string;
  };
}

export interface SaveCollection {
  id: string;
  title: string;
  description?: string;
  coverImage: string;
  isPrivate: boolean;
  isShared: boolean;
  collaboratorUserIds?: string[];
  colorTheme?: string;
  iconName?: string;
  tags?: string[];
  itemCount: number;
  createdAt: string;
  updatedAt: string;
  previewImages?: string[];
}

export type InterestFeedbackType = 'interested' | 'not_interested';
export type NotInterestedReason =
  | 'not_relevant'
  | 'already_bought'
  | 'seen_too_much'
  | 'dislike_brand_or_seller'
  | 'offensive_or_misleading'
  | 'other';

export interface InterestFeedbackRecord {
  id: string;
  targetId: string;
  targetType: SaveItemType;
  targetTitle: string;
  feedback: InterestFeedbackType;
  reason?: NotInterestedReason;
  customReasonText?: string;
  timestamp: string;
  appliedPersonalizationEffect: string; // e.g. "Reduced weight for Category: Ethnic Wear by 40%"
}

export interface SavedSearchQuery {
  id: string;
  query: string;
  categorySlug?: string;
  filters?: {
    minPrice?: number;
    maxPrice?: number;
    sortBy?: string;
    city?: string;
    inStockOnly?: boolean;
  };
  savedAt: string;
  notifyNewResults: boolean;
  lastResultsCount?: number;
}

// ==========================================
// UNIVERSAL DISAPPEARING CONTENT & AUTO-DELETE SYSTEM TYPES
// ==========================================

export type ExpirationPreset =
  | 'view_once'
  | '10m'
  | '1h'
  | '6h'
  | '24h'
  | '3d'
  | '7d'
  | '14d'
  | '30d'
  | 'custom'
  | 'permanent';

export type ContentLifecycleType =
  | 'message'
  | 'media'
  | 'voice'
  | 'doc'
  | 'product_share'
  | 'collection_share'
  | 'post'
  | 'reel'
  | 'story'
  | 'seller_profile'
  | 'creator_profile'
  | 'comment'
  | 'like'
  | 'link';

export type ContentAudience =
  | 'everyone'
  | 'followers'
  | 'close_friends'
  | 'selected_people'
  | 'only_me';

export type ContentLifecycleStatus =
  | 'active'
  | 'expiring_today'
  | 'expiring_soon'
  | 'scheduled_delete'
  | 'expired'
  | 'deleted'
  | 'preserved_compliance';

export interface ContentPrivacySettings {
  audience: ContentAudience;
  allowedViewerUserIds?: string[];
  allowReplies: boolean;
  allowSharing: boolean;
  allowSaving: boolean;
  allowDownloads: boolean;
  allowDirectMessages: boolean;
}

export interface ContentLifecycleItem {
  id: string;
  contentType: ContentLifecycleType;
  targetId: string; // Message ID, Post ID, Reel ID, Story ID, Product ID
  title: string;
  previewText?: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video' | 'voice' | 'doc' | 'product';
  ownerId: string;
  ownerName: string;
  createdAt: string;
  publishedAt: string;
  expirationPreset: ExpirationPreset;
  expiresAt: string | null; // ISO string, or null if permanent
  isViewOnce: boolean;
  viewCount: number;
  maxViews?: number;
  firstViewedAt?: string;
  isScheduledDelete: boolean;
  scheduledDeleteAt?: string; // ISO string
  status: ContentLifecycleStatus;
  privacy: ContentPrivacySettings;
  autoArchiveStory?: boolean;
  storageSizeBytes?: number;
  isMarketplaceListingPreserved?: boolean; // For product shares: message expires but marketplace product remains safe
  retentionCategory?: 'transient' | 'standard' | 'tax_legal_preserved' | 'fraud_audit_lock';
  metadata?: Record<string, any>;
}

export interface ScheduledDeletionJob {
  id: string;
  itemId: string;
  contentType: ContentLifecycleType;
  title: string;
  ownerId: string;
  scheduledFor: string;
  countdownDays: number;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  createdAt: string;
}

export interface ContentLifecycleEngineStats {
  totalActiveItems: number;
  expiringTodayCount: number;
  expiringThisWeekCount: number;
  scheduledDeletionsCount: number;
  totalExpiredToday: number;
  messagesExpiredToday: number;
  postsExpiredToday: number;
  reelsExpiredToday: number;
  storiesExpiredToday: number;
  storageReclaimedGB: number;
  failedDeletionJobs: number;
  legalPreservationLocksCount: number;
}

// ==========================================
// SUPER COIN + DIAMOND ECONOMY SYSTEM TYPES
// ==========================================

export type LoyaltyTierLevel = 'Bronze' | 'Silver' | 'Gold' | 'Platinum' | 'Diamond';

export interface LoyaltyTierConfig {
  level: LoyaltyTierLevel;
  name: string;
  minCoinsRequired: number;
  multiplier: number; // e.g. 1.0, 1.25, 1.5, 2.0, 3.0
  colorHex: string;
  gradientBg: string;
  icon: string;
  perks: string[];
  exclusiveDiscountPercent: number;
  earlyAccessHours: number;
  freeShippingNoMin: boolean;
  birthdayRewardCoins: number;
}

export interface SuperCoinWalletState {
  availableBalance: number;
  pendingBalance: number;
  expiringCoins: number;
  expiringCoinsDate: string;
  lifetimeEarned: number;
  lifetimeRedeemed: number;
  todayEarned: number;
  currentTier: LoyaltyTierLevel;
  coinsToNextTier: number;
  tierProgressPercent: number;
  expiryTimeline: Array<{
    id: string;
    date: string;
    amount: number;
    reason: string;
    daysRemaining: number;
  }>;
}

export interface DiamondWalletState {
  availableDiamonds: number;
  pendingDiamonds: number;
  lifetimeEarned: number;
  lifetimeSpent: number;
  creatorSalesVolumeINR: number;
  diamondRewardsEarned: number;
  conversionRate: number; // e.g. 1 Diamond = 10 SuperCoins or Creator Cashout
  monthlyRank: number;
  topProductSold: string;
}

export type CoinTransactionType =
  | 'purchase_earn'
  | 'daily_checkin'
  | 'video_watch'
  | 'product_discovery'
  | 'follow_creator'
  | 'share_product'
  | 'review_bonus'
  | 'referral_bonus'
  | 'mission_reward'
  | 'festival_campaign'
  | 'checkout_redeem'
  | 'shipping_discount'
  | 'creator_achievement'
  | 'live_shopping_gift'
  | 'diamond_conversion'
  | 'coin_expired'
  | 'fraud_reversal';

export interface UniversalCoinTransaction {
  id: string;
  timestamp: string;
  currency: 'SuperCoin' | 'Diamond';
  type: CoinTransactionType;
  amount: number; // positive for earn, negative for redeem/expire
  title: string;
  subtitle?: string;
  orderId?: string;
  campaignId?: string;
  sellerName?: string;
  status: 'completed' | 'pending' | 'reversed' | 'expired';
  expiryDate?: string;
}

export interface DailyCheckInDay {
  dayNumber: number;
  dayLabel: string; // e.g. "Day 1", "Day 2"
  superCoins: number;
  diamonds?: number;
  isSpecialMilestone?: boolean;
  isClaimed: boolean;
  isToday: boolean;
}

export interface RewardMissionItem {
  id: string;
  title: string;
  description: string;
  rewardSuperCoins: number;
  rewardDiamonds?: number;
  progress: number;
  maxProgress: number;
  isCompleted: boolean;
  isClaimed: boolean;
  category: 'daily' | 'shopping' | 'discovery' | 'social' | 'creator' | 'festival';
  icon: string;
  actionButtonLabel: string;
  actionLink?: string;
  expiresInHours?: number;
}

export interface FlashCoinEvent {
  id: string;
  title: string;
  subtitle: string;
  multiplierText: string; // e.g. "10X Super Coins", "2X on Fashion"
  category: string;
  badge: string;
  endsAt: string;
  remainingMinutes: number;
  themeGradient: string;
  icon: string;
  isActive: boolean;
}

export interface ReferralFriendRecord {
  id: string;
  friendName: string;
  phoneOrEmail: string;
  avatar: string;
  joinedDate: string;
  status: 'invited' | 'registered' | 'first_order_completed' | 'reward_unlocked';
  coinsAwarded: number;
}

export interface ReferralEconomyData {
  referralCode: string;
  referralLink: string;
  totalInvited: number;
  successfulReferrals: number;
  pendingReferrals: number;
  totalCoinsEarned: number;
  nextMilestoneTarget: number;
  nextMilestoneBonus: number;
  friendsList: ReferralFriendRecord[];
}

export interface SellerRewardSettings {
  sellerId: string;
  sellerName: string;
  storeName: string;
  coinCashbackPercent: number; // e.g. 5%
  firstOrderBonusCoins: number; // e.g. 100
  repeatPurchaseBonusCoins: number; // e.g. 150
  festivalMultiplierActive: boolean;
  festivalMultiplier: number;
  monthlyBudgetCoins: number;
  coinsDistributedThisMonth: number;
}

export interface CreatorDiamondEarnings {
  creatorId: string;
  creatorName: string;
  creatorHandle: string;
  salesGeneratedINR: number;
  diamondRewards: number;
  conversionRatePercent: number;
  monthlyRank: number;
  topPerformingProducts: Array<{
    productId: string;
    productName: string;
    productImage: string;
    salesCount: number;
    gmvINR: number;
    diamondsEarned: number;
  }>;
  recentLiveShowEarnings: Array<{
    showId: string;
    title: string;
    date: string;
    viewers: number;
    diamondsGifted: number;
    ordersPlaced: number;
  }>;
}

export interface PersonalizedRewardRecommendation {
  id: string;
  title: string;
  description: string;
  category: string;
  multiplierBadge: string;
  validUntil: string;
  recommendedReason: string;
  imageUrl?: string;
  actionText: string;
}

// ==========================================
// 1. Live Stream Commerce Arena Types
// ==========================================
export interface LiveStreamChatMessage {
  id: string;
  userName: string;
  userAvatar?: string;
  userBadge?: string;
  message: string;
  timestamp: string;
  isGift?: boolean;
  giftType?: 'diamond' | 'supercoin' | 'heart' | 'rose';
  giftAmount?: number;
}

export interface LiveStreamShow {
  id: string;
  title: string;
  hostName: string;
  hostAvatar: string;
  hostHandle: string;
  category: 'Fashion' | 'Jewelry' | 'Food' | 'Electronics' | 'Handicrafts';
  viewerCount: number;
  likesCount: number;
  status: 'live' | 'upcoming' | 'replay';
  streamVideoUrl: string;
  thumbnailUrl: string;
  pinnedProductId: string;
  flashDiscountPercent: number;
  flashStockRemaining: number;
  tags: string[];
  pollQuestion?: string;
  pollOptions?: Array<{ id: string; text: string; votes: number }>;
}

// ==========================================
// 2. Multilingual Voice Studio Types
// ==========================================
export interface MultilingualVoicePreset {
  code: LanguageCode;
  name: string;
  nativeName: string;
  samplePhrases: string[];
  flag: string;
}

export interface MultilingualTranslationRecord {
  id: string;
  sourceLang: LanguageCode;
  targetLang: LanguageCode;
  sourceText: string;
  translatedText: string;
  detectedIntent?: 'search' | 'cart' | 'bargain' | 'order_status' | 'general';
  actionPayload?: any;
  timestamp: string;
}

// ==========================================
// 3. Virtual 3D Try-On, Custom Photo Upload & Free Trial Types
// ==========================================
export type ProductTryOnCategory =
  | 'tops_shirts'
  | 'bottoms_pants'
  | 'ethnic_sarees'
  | 'dresses_gowns'
  | 'jackets_coats'
  | 'eyewear'
  | 'jewelry'
  | 'footwear'
  | 'watches'
  | 'hats_caps'
  | 'home_decor'
  | 'general';

export interface VirtualTryOnItem {
  id: string;
  productId: string;
  name: string;
  category: 'apparel' | 'eyewear' | 'jewelry' | 'footwear' | 'home_decor';
  model3dType: 'cylinder' | 'cube' | 'torus' | 'sphere' | 'mesh';
  image: string;
  price: number;
  colors: Array<{ name: string; hex: string }>;
  defaultScale: number;
  arModeSupported: boolean;
}

export interface CustomUploadedProduct {
  id: string;
  name: string;
  category: ProductTryOnCategory;
  imageUrl: string;
  cutoutImageUrl?: string;
  detectedItemType: string;
  colorPalette?: string[];
  fabricType?: string;
  aiFitRecommendation?: string;
  uploadedAt: string;
  userNotes?: string;
}

export interface TryOnPersonModel {
  id: string;
  name: string;
  gender: 'male' | 'female' | 'unisex';
  bodyType: 'regular' | 'athletic' | 'curvy' | 'slim' | 'plus_size';
  suitableCategories: ProductTryOnCategory[];
  poseDescription: string;
  imageUrl: string;
  heightTag?: string;
  fitTag?: string;
  isCustomUpload?: boolean;
}

export interface FreeTrialBooking {
  id: string;
  productName: string;
  productImage: string;
  productCategory: string;
  productId?: string;
  customerName: string;
  customerPhone: string;
  deliveryAddress: string;
  selectedSize: string;
  selectedColor?: string;
  trialDurationDays: number;
  securityDeposit: number;
  status: 'CONFIRMED' | 'DISPATCHED' | 'ACTIVE_TRIAL' | 'TRIAL_ENDED' | 'PURCHASED' | 'RETURN_PICKED';
  bookedAt: string;
  expiresAt: string;
  trackingCode: string;
}

// ==========================================
// 4. NAVA — Next-Gen Social Network & Mission Architecture Types
// ==========================================
export type NavaGoal =
  | 'entrepreneur'
  | 'developer'
  | 'designer'
  | 'creator'
  | 'student'
  | 'athlete'
  | 'freelancer'
  | 'investor'
  | 'artist'
  | 'teacher'
  | 'community_leader'
  | 'researcher'
  | 'custom';

export type NavaIdentityMode =
  | 'anonymous'
  | 'pseudonym'
  | 'username'
  | 'verified'
  | 'professional';

export interface NavaTrustIndicators {
  overallScore: number;
  reliability: number; // 0-100
  helpfulness: number; // 0-100
  skillEvidence: number; // 0-100
  communityConduct: number; // 0-100
  missionCompletionRate: number; // 0-100
  peerConfirmationsCount: number;
  verificationLevel: 'Anonymous' | 'Basic Verified' | 'Phone Verified' | 'Identity Verified' | 'Professional Verified';
}

export interface NavaMilestone {
  id: string;
  order: number;
  title: string;
  description: string;
  targetDurationWeeks: number;
  isCompleted: boolean;
  completedDate?: string;
  proofUrl?: string;
  proofSummary?: string;
  peerVerifiedBy?: string[];
}

export interface NavaTask {
  id: string;
  milestoneId?: string;
  title: string;
  isCompleted: boolean;
  assignedToName?: string;
  dueDate?: string;
}

export interface NavaMission {
  id: string;
  title: string;
  description: string;
  goalCategory: NavaGoal;
  targetOutcome: string;
  durationDays: number;
  startDate: string;
  endDate: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  isPublic: boolean;
  isTeam: boolean;
  location?: {
    city: string;
    venue?: string;
    isRealWorld: boolean;
    lat?: number;
    lng?: number;
  };
  requiredSkills: string[];
  gainedSkills: string[];
  maxParticipants: number;
  currentParticipantsCount: number;
  milestones: NavaMilestone[];
  progressPct: number;
  creatorId: string;
  creatorName: string;
  creatorAvatar: string;
  creatorTrustScore: number;
  circleId?: string;
  tags: string[];
  status: 'active' | 'completed' | 'draft';
  explainableReason: string;
  hasJoined?: boolean;
}

export interface NavaCircle {
  id: string;
  missionId: string;
  name: string;
  description: string;
  privacy: 'public' | 'private' | 'invite-only' | 'anonymous';
  memberCount: number;
  maxMembers: number;
  members: Array<{
    id: string;
    name: string;
    avatar: string;
    role: 'host' | 'moderator' | 'teammate';
    trustScore: number;
    identityMode: NavaIdentityMode;
    speciality: string;
  }>;
  activeGoal: string;
  tasksBoard: Array<{
    id: string;
    title: string;
    status: 'todo' | 'in_progress' | 'done';
    assignedToName: string;
    priority: 'high' | 'medium' | 'low';
  }>;
  recentMessages: Array<{
    id: string;
    senderId: string;
    senderName: string;
    senderAvatar: string;
    text: string;
    timestamp: string;
    isHelpRequest?: boolean;
  }>;
  isVoiceRoomLive: boolean;
  activeVoiceListeners?: number;
}

export interface NavaProofOfProgress {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  userTrustScore: number;
  missionId: string;
  missionTitle: string;
  milestoneTitle: string;
  accomplished: string;
  learned: string;
  difficult: string;
  nextStep: string;
  proofUrl?: string;
  proofType: 'project_repo' | 'certificate' | 'live_demo' | 'screenshot' | 'document' | 'video';
  peerVerificationsCount: number;
  verifiedByPeers: string[];
  meaningfulReactions: {
    helpedMe: number;
    joinMission: number;
    collaborate: number;
    verifyProgress: number;
    support: number;
  };
  userReactions: { [key: string]: boolean };
  timestamp: string;
  explainableReason: string;
}

export interface NavaHelpListing {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  type: 'can_help' | 'need_help';
  skillCategory: string;
  title: string;
  description: string;
  timeCreditsPerHour: number;
  locationName: string;
  availability: string;
  trustScore: number;
  matchScorePct: number;
  explainableReason: string;
  status: 'open' | 'in_session' | 'resolved';
}

export interface NavaTimeTransaction {
  id: string;
  type: 'earned' | 'spent' | 'grant';
  amount: number;
  description: string;
  date: string;
  counterpartyName: string;
  sessionDurationHours: number;
}

export interface NavaTimeWallet {
  availableCredits: number;
  lifetimeEarned: number;
  lifetimeSpent: number;
  transactions: NavaTimeTransaction[];
}

export interface NavaSocialImpactLedger {
  hoursVolunteered: number;
  peopleHelped: number;
  skillsShared: number;
  missionsCompleted: number;
  communityProjectsCount: number;
  environmentalImpactHours: number;
  recentImpactLogs: Array<{
    id: string;
    title: string;
    category: string;
    date: string;
    metric: string;
  }>;
}

export type NavaFeedActionType =
  | 'DO'
  | 'LEARN'
  | 'HELP'
  | 'JOIN'
  | 'BUILD'
  | 'DISCOVER'
  | 'DISCUSS';

export interface NavaActionFeedItem {
  id: string;
  actionType: NavaFeedActionType;
  title: string;
  subtitle: string;
  description: string;
  tag: string;
  ctaLabel: string;
  ctaActionType: string;
  explainableReason: string;
  timestamp: string;
  authorName?: string;
  authorAvatar?: string;
  authorTrustScore?: number;
  metaInfo?: string;
  targetId?: string;
  iconName?: string;
}

export interface NavaAICoachRoadmap {
  id: string;
  userGoal: string;
  targetDurationDays: number;
  currentWeek: number;
  totalWeeks: number;
  weeklyRoadmap: Array<{
    weekNumber: number;
    weekRange: string;
    title: string;
    focus: string;
    tasks: Array<{ id: string; title: string; isCompleted: boolean }>;
    isCompleted: boolean;
  }>;
  suggestedResources: Array<{
    title: string;
    type: 'Interactive Doc' | 'Open Source Project' | 'Community Masterclass' | 'Tooling';
    url: string;
    author: string;
  }>;
  recommendedTeammates: Array<{
    name: string;
    role: string;
    avatar: string;
    matchReason: string;
    trustScore: number;
  }>;
}

export interface NavaGoalGraphNode {
  id: string;
  label: string;
  type: 'user' | 'goal' | 'skill' | 'mission' | 'person' | 'impact';
  color: string;
  x: number;
  y: number;
  details: string;
}

export interface NavaGoalGraphLink {
  source: string;
  target: string;
  relationship: string;
}

// ============================================================================
// NEXT-GENERATION AUTONOMOUS COMMERCE & DELIVERY PLATFORM (60 PILLARS)
// ============================================================================

export type AutonomousAgentType =
  | 'HUMAN_RIDER'
  | 'EV_FLEET'
  | 'AUTONOMOUS_DRONE'
  | 'SIDEWALK_ROBOT'
  | 'SMART_LOCKER'
  | 'MICRO_HUB';

export interface AutonomousDeliveryAgent {
  id: string;
  name: string;
  type: AutonomousAgentType;
  avatar: string;
  batteryOrFuelPercent: number;
  status: 'IDLE' | 'ON_MISSION' | 'RECHARGING' | 'RELAY_READY' | 'MAINTENANCE';
  currentLocation: {
    lat: number;
    lng: number;
    areaName: string;
  };
  dnaScore: number; // 0-100 Dynamic Delivery DNA
  metrics: {
    pickupEfficiency: number; // %
    routeCompliance: number; // %
    weatherRating: number; // %
    fragileCareRating: number; // %
    cancellationRisk: number; // %
    carbonEfficiencyGramsPerKm: number;
  };
  currentMission?: {
    id: string;
    orderId: string;
    pickup: string;
    dropoff: string;
    etaMinutes: number;
    type: 'DIRECT' | 'RELAY_HOP_1' | 'RELAY_HOP_2' | 'LOCKER_DROP' | 'RETURN_CONSOLIDATION';
    urgencyLevel: 'STANDARD' | 'PRIORITY' | 'EMERGENCY_CRITICAL';
  };
}

export interface PackageDigitalPassport {
  packageId: string;
  orderNumber: string;
  qrHash: string;
  senderBusiness: string;
  recipientAddress: string;
  dimensionsCm: { length: number; width: number; height: number };
  weightKg: number;
  fragilityLevel: 'STANDARD' | 'FRAGILE' | 'TEMPERATURE_SENSITIVE' | 'HIGH_VALUE';
  requiredTempCelsius?: { min: number; max: number };
  currentTempCelsius?: number;
  shockGForceMax: number;
  tamperSealVerified: boolean;
  transitHistory: Array<{
    timestamp: string;
    stage: string;
    agentId: string;
    agentName: string;
    location: string;
    verificationType: 'VISUAL_AI_SCAN' | 'NFC_HANDSHAKE' | 'BIOMETRIC_PROOF' | 'LOCKER_TELEMETRY';
  }>;
}

export interface FutureDemandForecast {
  timeframe: '30_MIN' | '2_HOURS' | '6_HOURS' | '24_HOURS' | '7_DAYS';
  predictedOrders: number;
  highDemandZones: Array<{
    zoneId: string;
    zoneName: string;
    category: string;
    expectedSurgeFactor: number;
    recommendedPrepositionFleet: number;
    topPredictedItem: string;
  }>;
  aiActionTaken: string;
}

export interface WhatIfScenarioSimulation {
  id: string;
  title: string;
  description: string;
  parameters: {
    orderSurgePercent: number;
    driverShortagePercent: number;
    rainStormSeverity: 'NONE' | 'MODERATE' | 'HEAVY_MONSOON';
    trafficCongestionMultiplier: number;
  };
  projectedOutcome: {
    avgDeliveryTimeMinutes: number;
    onTimeRatePercent: number;
    selfHealingAutoRecoveries: number;
    activeRelayHops: number;
    droneDeployments: number;
    estimatedNetworkCost: number;
  };
}

// ==========================================
// 5. ZERO-ADMIN AUTONOMOUS ENGINE & SELF-SERVICE ARCHITECTURE
// ==========================================

export interface AutonomousPlatformConfig {
  zeroTouchModeEnabled: boolean; // When true, all approvals/payouts/refunds execute 100% autonomously without human admin
  autoApproveSellers: boolean; // Instant AI OCR verification for GSTIN, PAN, Aadhaar
  autoApproveProducts: boolean; // Instant live publishing with AI safety & pricing screening
  autoApproveDrivers: boolean; // Instant DL check and autonomous dispatch routing
  instantEscrowPayouts: boolean; // 24x7 1-click merchant UPI/IMPS payouts with zero manual approval
  aiDisputeArbitration: boolean; // AI vision-based defect analysis and instant auto-refund release
  directPeerPaymentsEnabled: boolean; // Allow direct buyer-seller UPI QR settlements (bypassing platform escrow)
  selfServiceOrderControl: boolean; // 1-click cancel, exchange, address change, delivery rescheduling
  communityTrustScoring: boolean; // Decentralized peer ratings & proof-of-authenticity badges
  minTrustScoreForAutoPublish: number; // e.g. 70 out of 100
  instantRefundLimitINR: number; // e.g. up to ₹15,000 auto-approved by AI
}

export interface AutonomousAuditLogEntry {
  id: string;
  timestamp: string;
  actionType:
    | 'SELLER_AUTO_KYC'
    | 'PRODUCT_AUTO_PUBLISH'
    | 'INSTANT_PAYOUT_RELEASE'
    | 'AI_REFUND_ARBITRATION'
    | 'SELF_SERVICE_ORDER_EDIT'
    | 'AUTONOMOUS_DRIVER_DISPATCH'
    | 'DIRECT_PEER_SETTLEMENT'
    | 'POLICY_INTEGRITY_CHECK';
  actorName: string;
  entityId: string;
  summary: string;
  decisionReason: string;
  adminTouchCount: 0; // Always 0 human admin touches
  status: 'COMPLETED_AUTONOMOUSLY' | 'AI_FLAGGED_POLICY_PASS' | 'ESCROW_SETTLED';
  executionTimeMs: number;
}

export interface AutonomousDisputeCase {
  id: string;
  orderId: string;
  customerName: string;
  sellerName: string;
  productName: string;
  claimAmount: number;
  claimReason: 'DAMAGED_ITEM' | 'WRONG_PRODUCT' | 'SIZE_MISMATCH' | 'TRANSIT_DELAY' | 'NOT_DELIVERED';
  photoEvidenceUrl?: string;
  aiConfidenceScore: number; // 0-100%
  aiDecision: 'AUTO_REFUND_FULL' | 'INSTANT_EXCHANGE_DISPATCHED' | 'DIRECT_RETURN_PICKUP' | 'PARTIAL_STORE_CREDIT';
  settlementMethod: 'UPI_DIRECT' | 'ORIGINAL_PAYMENT' | 'INSTANT_STORE_CREDIT';
  status: 'RESOLVED_INSTANTLY' | 'PICKUP_SCHEDULED';
  resolvedAt: string;
  resolutionTimeSeconds: number;
}

// ==========================================
// JUSTAWAY — "Just go. Just away."
// Freedom • Movement • Travel • Away From The Ordinary • Anywhere, Anytime
// ==========================================

export interface JustAwayEscape {
  id: string;
  title: string;
  tagline: string;
  destination: string;
  region: string;
  category: 'Serene Nature' | 'Off-Grid Cabin' | 'Mountain Trail' | 'Heritage Trail' | 'Sunset Coast' | 'Nomadic Camping';
  distanceKm: number;
  driveTimeHours: string;
  vibe: string;
  pricePerNightINR: number;
  rating: number;
  reviewsCount: number;
  imageUrl: string;
  highlights: string[];
  gearRecommended: string[];
  availableDates: string;
  instantBook: boolean;
  awayPassEligible: boolean;
  driftMilesEarn: number;
  roadCondition: 'Smooth Highway' | 'Scenic Hills' | 'Off-Road 4x4' | 'Forest Stretch';
}

export interface JustAwayGearKit {
  id: string;
  name: string;
  brandTag: string;
  category: 'Rucksacks' | 'All-Weather Jackets' | 'Action Cams' | 'Trail Footwear' | 'Solar Tech' | 'Camp Pods';
  rentalDailyINR: number;
  purchaseINR: number;
  freeTrialDays: number; // 3-Day Free Doorstep Trial
  badge: string;
  imageUrl: string;
  rating: number;
  specs: string[];
  inStock: boolean;
}

export interface JustAwayNomadStamp {
  id: string;
  placeName: string;
  state: string;
  stampDate: string;
  coordinates: string;
  category: string;
  driftMiles: number;
  badgeIcon: string;
}



