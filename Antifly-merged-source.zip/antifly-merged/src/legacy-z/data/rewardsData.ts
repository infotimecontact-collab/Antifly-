import {
  LoyaltyTierInfo,
  SuperCoinWalletState,
  DiamondWalletState,
  RewardMissionItem,
  FlashCoinEventItem,
  ReferralEconomyData,
  CreatorDiamondStats,
  SellerRewardConfig,
  UnifiedRewardTransaction,
  FraudRiskRule,
  FraudAuditRecord,
  CurrencyEconomyConfig,
  SuperCoinReward,
} from '../types';

// ==========================================
// 1. SUPER COIN WALLET INITIAL STATE
// ==========================================
export const INITIAL_SUPER_COIN_WALLET: SuperCoinWalletState = {
  availableBalance: 1480,
  pendingCoins: 240, // From in-transit delivery
  expiringCoins: 120,
  expiryDate: '28 Aug 2026',
  lifetimeEarned: 8920,
  lifetimeRedeemed: 7440,
  todayEarnings: 65,
  dailyGoalTarget: 100,
  dailyGoalCurrent: 80,
  conversionRateRupeesPerCoin: 1.0,
  maxRedemptionPercentPerOrder: 50,
};

// ==========================================
// 2. DIAMOND WALLET INITIAL STATE (CREATOR & SOCIAL)
// ==========================================
export const INITIAL_DIAMOND_WALLET: DiamondWalletState = {
  balance: 3850,
  lifetimeEarned: 18450,
  lifetimeSpent: 14600,
  pendingDiamonds: 850,
  todayEarnings: 320,
  conversionRateRupeesPer100Diamonds: 50, // 100 Diamonds = ₹50 bank payout
  totalGMVGenerated: 42500, // ₹42,500 in content-driven sales
  monthlyEarningsDiamonds: 6420,
  creatorRank: 'Gold Creator (Top 3% Influencer)',
};

// ==========================================
// 3. LOYALTY TIER HIERARCHY (GOLD TIER USER)
// ==========================================
export const INITIAL_LOYALTY_TIER: LoyaltyTierInfo = {
  tier: 'Gold',
  currentCoinsLifetime: 3550,
  coinsNeededForNextTier: 450, // 450 coins to Platinum
  nextTier: 'Platinum',
  coinsMultiplier: 1.5, // 6 Super Coins per ₹100 spent
  earlyAccessHours: 12,
  freeExpressDelivery: true,
  birthdayBonusCoins: 250,
  vipSupport: true,
  perks: [
    {
      title: '1.5X Super Coin Multiplier',
      description: 'Earn 6 Super Coins for every ₹100 spent across all verified vendors',
      icon: 'zap',
      isUnlocked: true,
    },
    {
      title: 'Free Express Delivery',
      description: 'Zero shipping fee on all orders above ₹499 with live GPS tracking',
      icon: 'truck',
      isUnlocked: true,
    },
    {
      title: '12-Hour Early Access to Drops',
      description: 'Shop viral studio collections & festive flash sales before general public',
      icon: 'clock',
      isUnlocked: true,
    },
    {
      title: 'Dedicated VIP Support Concierge',
      description: 'Direct priority WhatsApp connect with human resolution specialist within 2 mins',
      icon: 'shield',
      isUnlocked: true,
    },
    {
      title: 'Platinum Perk: 2.0X Multiplier & No-Questions-Asked Returns',
      description: 'Instant 1-hour doorstep return & refund SLA plus double-coin weekends',
      icon: 'crown',
      isUnlocked: false,
    },
  ],
};

// ==========================================
// 4. DAILY CHECK-IN STREAK (7-DAY CALENDAR)
// ==========================================
export interface DailyCheckInDay {
  dayNumber: number;
  dayLabel: string;
  coins: number;
  diamonds?: number;
  isClaimed: boolean;
  isToday: boolean;
  isSpecialChest?: boolean;
}

export const INITIAL_CHECKIN_DAYS: DailyCheckInDay[] = [
  { dayNumber: 1, dayLabel: 'Mon', coins: 10, isClaimed: true, isToday: false },
  { dayNumber: 2, dayLabel: 'Tue', coins: 15, isClaimed: true, isToday: false },
  { dayNumber: 3, dayLabel: 'Wed', coins: 20, isClaimed: true, isToday: false },
  { dayNumber: 4, dayLabel: 'Thu', coins: 25, isClaimed: true, isToday: false },
  { dayNumber: 5, dayLabel: 'Fri', coins: 35, diamonds: 20, isClaimed: false, isToday: true },
  { dayNumber: 6, dayLabel: 'Sat', coins: 50, diamonds: 50, isClaimed: false, isToday: false },
  { dayNumber: 7, dayLabel: 'Sun', coins: 100, diamonds: 150, isClaimed: false, isToday: false, isSpecialChest: true },
];

// ==========================================
// 5. DAILY MISSIONS & QUESTS
// ==========================================
export const INITIAL_REWARD_MISSIONS: RewardMissionItem[] = [
  {
    id: 'mission-checkin',
    title: 'Daily App Check-in',
    description: 'Keep your 5-day streak alive and unlock progressive bonus multipliers',
    category: 'check_in',
    currency: 'both',
    rewardCoins: 35,
    rewardDiamonds: 20,
    progress: 1,
    maxProgress: 1,
    isCompleted: true,
    isClaimed: false,
    icon: 'calendar',
    ctaLabel: 'Claim Reward',
    badge: 'Daily Streak',
  },
  {
    id: 'mission-discovery',
    title: 'Discover 3 Handcrafted Silks',
    description: 'Explore at least 3 artisan silk collections from verified boutique sellers',
    category: 'discovery',
    currency: 'super_coins',
    rewardCoins: 25,
    rewardDiamonds: 0,
    progress: 2,
    maxProgress: 3,
    isCompleted: false,
    isClaimed: false,
    icon: 'search',
    ctaLabel: 'Discover Now',
    badge: 'Easy',
  },
  {
    id: 'mission-video',
    title: 'Watch 2 Shoppable Studio Reels',
    description: 'Watch community style reels and discover trending influencer outfits',
    category: 'video',
    currency: 'both',
    rewardCoins: 20,
    rewardDiamonds: 15,
    progress: 2,
    maxProgress: 2,
    isCompleted: true,
    isClaimed: false,
    icon: 'play',
    ctaLabel: 'Claim Reward',
    badge: 'Social Quest',
  },
  {
    id: 'mission-social-follow',
    title: 'Follow a Verified Artisan Seller',
    description: 'Follow Heritage Weaves or Royal Brocades to stay updated on live launches',
    category: 'social',
    currency: 'super_coins',
    rewardCoins: 20,
    rewardDiamonds: 10,
    progress: 1,
    maxProgress: 1,
    isCompleted: true,
    isClaimed: false,
    icon: 'user-plus',
    ctaLabel: 'Claim Reward',
    badge: 'Community',
  },
  {
    id: 'mission-share-look',
    title: 'Share a Shoppable Lookbook',
    description: 'Share your favorite ethnic collection or AR lens reel with friends on WhatsApp',
    category: 'social',
    currency: 'super_coins',
    rewardCoins: 15,
    rewardDiamonds: 0,
    progress: 0,
    maxProgress: 1,
    isCompleted: false,
    isClaimed: false,
    icon: 'share-2',
    ctaLabel: 'Share Look',
    badge: 'Quick Win',
  },
  {
    id: 'mission-review',
    title: 'Write a Verified Photo Review',
    description: 'Upload a clear photo review of your recent delivered handloom apparel order',
    category: 'review',
    currency: 'both',
    rewardCoins: 50,
    rewardDiamonds: 50,
    progress: 0,
    maxProgress: 1,
    isCompleted: false,
    isClaimed: false,
    icon: 'camera',
    ctaLabel: 'Write Review',
    badge: 'Creator Bounty',
  },
  {
    id: 'mission-shopping-order',
    title: 'Place an Order above ₹999',
    description: 'Shop authentic artisan wear today to trigger an instant 100-Coin power bonus',
    category: 'shopping',
    currency: 'super_coins',
    rewardCoins: 100,
    rewardDiamonds: 30,
    progress: 0,
    maxProgress: 1,
    isCompleted: false,
    isClaimed: false,
    icon: 'shopping-bag',
    ctaLabel: 'Shop Now',
    badge: 'High Value',
  },
];

// ==========================================
// 6. FLASH COIN EVENTS & TIME-LIMITED DROPS
// ==========================================
export const INITIAL_FLASH_EVENTS: FlashCoinEventItem[] = [
  {
    id: 'flash-10x-drop',
    title: '10X Super Coins Flash Rush',
    subtitle: 'Earn up to 1,000 Super Coins on all Festive Saree Collections',
    multiplier: '10X Coins',
    categoryTag: 'Festive Silks',
    bonusCoinsPerPurchase: 350,
    endsAt: 'In 28 minutes',
    remainingMinutes: 28,
    totalPoolBudget: 50000,
    claimedPercent: 78,
    bgGradient: 'from-amber-600 via-orange-600 to-yellow-500',
    isLive: true,
  },
  {
    id: 'flash-midnight-drop',
    title: 'Midnight Creator Carnival',
    subtitle: 'Double Diamond payouts on all live-stream and UGC shoppable sales',
    multiplier: '2X Diamonds',
    categoryTag: 'Creator Live',
    bonusCoinsPerPurchase: 200,
    endsAt: 'Starts at 12:00 AM',
    remainingMinutes: 240,
    totalPoolBudget: 25000,
    claimedPercent: 15,
    bgGradient: 'from-purple-900 via-indigo-900 to-slate-900',
    isLive: true,
  },
  {
    id: 'flash-first-buyers',
    title: 'Early Bird Golden 500',
    subtitle: 'First 500 customers receive +250 Instant Super Coins & Free Express Ship',
    multiplier: '+250 Bonus',
    categoryTag: 'New Arrivals',
    bonusCoinsPerPurchase: 250,
    endsAt: '142 slots remaining',
    remainingMinutes: 90,
    totalPoolBudget: 125000,
    claimedPercent: 71,
    bgGradient: 'from-emerald-700 via-teal-800 to-slate-900',
    isLive: true,
  },
];

// ==========================================
// 7. REFERRAL ECONOMY DATA
// ==========================================
export const INITIAL_REFERRAL_DATA: ReferralEconomyData = {
  referralCode: 'ZOLO-PRIYA-77',
  referralLink: 'https://antifly.app/invite/ZOLO-PRIYA-77',
  totalInvited: 8,
  successfulReferrals: 4,
  totalCoinsEarned: 2250,
  totalDiamondsEarned: 450,
  pendingCoins: 500,
  currentMilestoneIndex: 2,
  milestones: [
    {
      friendsCount: 1,
      coinsReward: 250,
      diamondsReward: 50,
      specialBonus: 'Silver Referral Badge',
      isUnlocked: true,
    },
    {
      friendsCount: 3,
      coinsReward: 1000,
      diamondsReward: 200,
      specialBonus: 'Free Express Delivery Pass for 30 Days',
      isUnlocked: true,
    },
    {
      friendsCount: 5,
      coinsReward: 2500,
      diamondsReward: 500,
      specialBonus: '₹500 Artisan Shopping Voucher',
      isUnlocked: false,
    },
    {
      friendsCount: 10,
      coinsReward: 6000,
      diamondsReward: 1500,
      specialBonus: 'Gold Ambassador Tier & VIP Box',
      isUnlocked: false,
    },
  ],
  friendsList: [
    {
      id: 'ref-1',
      friendName: 'Ananya Verma',
      friendPhone: '+91 98234 •••••',
      joinedDate: '18 Aug 2026',
      status: 'Completed',
      superCoinsEarned: 500,
      diamondsEarned: 100,
    },
    {
      id: 'ref-2',
      friendName: 'Rohit Kulkarni',
      friendPhone: '+91 97112 •••••',
      joinedDate: '15 Aug 2026',
      status: 'Completed',
      superCoinsEarned: 500,
      diamondsEarned: 100,
    },
    {
      id: 'ref-3',
      friendName: 'Deepika Sen',
      friendPhone: '+91 99401 •••••',
      joinedDate: '10 Aug 2026',
      status: 'Completed',
      superCoinsEarned: 500,
      diamondsEarned: 100,
    },
    {
      id: 'ref-4',
      friendName: 'Siddharth Roy',
      friendPhone: '+91 98330 •••••',
      joinedDate: '02 Aug 2026',
      status: 'Completed',
      superCoinsEarned: 500,
      diamondsEarned: 100,
    },
    {
      id: 'ref-5',
      friendName: 'Meera Nambiar',
      friendPhone: '+91 94470 •••••',
      joinedDate: '20 Aug 2026',
      status: 'First Order Placed',
      superCoinsEarned: 0,
      diamondsEarned: 0,
    },
  ],
};

// ==========================================
// 8. CREATOR DIAMOND STATS & ANALYTICS
// ==========================================
export const INITIAL_CREATOR_DIAMOND_STATS: CreatorDiamondStats = {
  creatorId: 'creator-priya-01',
  creatorName: 'Priya Sharma',
  handle: '@priyasharma_style',
  verifiedBadge: true,
  totalGMVDriven: 42500,
  totalDiamondsEarned: 12450,
  currentBalance: 3850,
  affiliateCommissionPercent: 10,
  topProducts: [
    {
      productId: 'prod-001',
      productName: 'Royal Kanjivaram Pure Silk Saree',
      productImage: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=500&auto=format&fit=crop&q=80',
      productPrice: 4299,
      salesCount: 6,
      gmvDriven: 25794,
      diamondsEarned: 5158,
      conversionRatePercent: 8.4,
    },
    {
      productId: 'prod-002',
      productName: 'Handloom Banarasi Georgette Kurta Set',
      productImage: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=500&auto=format&fit=crop&q=80',
      productPrice: 2899,
      salesCount: 4,
      gmvDriven: 11596,
      diamondsEarned: 2319,
      conversionRatePercent: 6.2,
    },
    {
      productId: 'prod-003',
      productName: 'Temple Motif Antique Gold Choker Set',
      productImage: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=500&auto=format&fit=crop&q=80',
      productPrice: 1799,
      salesCount: 3,
      gmvDriven: 5397,
      diamondsEarned: 1079,
      conversionRatePercent: 5.1,
    },
  ],
  monthlyBreakdown: [
    { month: 'August 2026', gmv: 42500, diamonds: 8500, postsCount: 14 },
    { month: 'July 2026', gmv: 31200, diamonds: 6240, postsCount: 11 },
    { month: 'June 2026', gmv: 18900, diamonds: 3780, postsCount: 8 },
  ],
  payoutHistory: [
    {
      id: 'payout-101',
      date: '15 Aug 2026',
      diamondsRedeemed: 5000,
      inrAmount: 2500,
      upiId: 'priya@okhdfcbank',
      utr: 'UTR-DIAM-908123847',
      status: 'Settled',
    },
    {
      id: 'payout-102',
      date: '01 Aug 2026',
      diamondsRedeemed: 4000,
      inrAmount: 2000,
      upiId: 'priya@okhdfcbank',
      utr: 'UTR-DIAM-819237461',
      status: 'Settled',
    },
  ],
};

// ==========================================
// 9. SELLER REWARD CONFIGURATION
// ==========================================
export const INITIAL_SELLER_REWARD_CONFIG: SellerRewardConfig = {
  sellerId: 'seller-01',
  storeName: 'Heritage Silk Studio',
  coinCashbackPercentage: 5, // 5% extra coins sponsored by seller
  firstOrderBonusCoins: 50,
  repeatPurchaseMilestoneOrders: 3,
  repeatPurchaseBonusCoins: 150,
  productSpecificBounties: [
    {
      productId: 'prod-001',
      productName: 'Royal Kanjivaram Pure Silk Saree',
      extraBonusCoins: 100,
      isActive: true,
    },
    {
      productId: 'prod-002',
      productName: 'Handloom Banarasi Georgette Kurta Set',
      extraBonusCoins: 75,
      isActive: true,
    },
  ],
  activeCampaignName: 'Festive Weaves Super-Coin Boost',
  campaignMultiplier: 2.0,
  isCampaignActive: true,
  monthlyRewardBudget: 25000,
  rewardBudgetUsed: 14200,
};

// ==========================================
// 10. UNIFIED REWARDS & DIAMONDS TRANSACTION LEDGER
// ==========================================
export const INITIAL_REWARD_TRANSACTIONS: UnifiedRewardTransaction[] = [
  {
    id: 'tx-sc-01',
    date: '21 Aug 2026, 11:42 AM',
    activityTitle: 'Delivered Order Reward #ORD-98214',
    activityType: 'purchase_earn',
    currency: 'super_coins',
    direction: 'credit',
    amount: 120,
    status: 'Completed',
    orderNumber: 'ORD-98214',
    sellerName: 'Heritage Silk Studio',
    notes: 'Base 80 Coins + 40 Gold Member 1.5X Bonus',
    expiryDate: '17 Feb 2027',
  },
  {
    id: 'tx-dm-02',
    date: '20 Aug 2026, 06:15 PM',
    activityTitle: 'Creator Affiliate Sale — Kanjivaram Saree',
    activityType: 'creator_affiliate',
    currency: 'diamonds',
    direction: 'credit',
    amount: 430,
    status: 'Completed',
    orderNumber: 'ORD-98199',
    notes: '10% UGC Commission credited via Lookbook Reel',
  },
  {
    id: 'tx-sc-03',
    date: '20 Aug 2026, 09:30 AM',
    activityTitle: 'Daily App Check-in (Day 4 Streak)',
    activityType: 'daily_checkin',
    currency: 'super_coins',
    direction: 'credit',
    amount: 25,
    status: 'Completed',
    notes: 'Streak active: 4 days in a row',
    expiryDate: '16 Feb 2027',
  },
  {
    id: 'tx-sc-04',
    date: '19 Aug 2026, 04:20 PM',
    activityTitle: 'Instant Checkout Discount Used #ORD-98150',
    activityType: 'checkout_redeem',
    currency: 'super_coins',
    direction: 'debit',
    amount: 200,
    status: 'Completed',
    orderNumber: 'ORD-98150',
    notes: 'Direct 1:1 deduction (-₹200 on cart)',
  },
  {
    id: 'tx-dm-05',
    date: '18 Aug 2026, 02:10 PM',
    activityTitle: 'Friend Referral Milestone — Ananya Verma',
    activityType: 'referral_bonus',
    currency: 'diamonds',
    direction: 'credit',
    amount: 100,
    status: 'Completed',
    notes: 'Friend placed first order of ₹1,499',
  },
  {
    id: 'tx-sc-06',
    date: '18 Aug 2026, 02:10 PM',
    activityTitle: 'Friend Referral Milestone — Ananya Verma',
    activityType: 'referral_bonus',
    currency: 'super_coins',
    direction: 'credit',
    amount: 500,
    status: 'Completed',
    notes: 'Referral reward for verified first purchase',
    expiryDate: '14 Feb 2027',
  },
  {
    id: 'tx-dm-07',
    date: '15 Aug 2026, 10:00 AM',
    activityTitle: 'Creator Bank Payout via UPI',
    activityType: 'diamond_payout',
    currency: 'diamonds',
    direction: 'debit',
    amount: 5000,
    status: 'Completed',
    notes: '₹2,500 transferred to priya@okhdfcbank (UTR-DIAM-908123847)',
  },
  {
    id: 'tx-sc-08',
    date: '14 Aug 2026, 08:45 PM',
    activityTitle: 'Seller Loyalty Bonus — 3rd Store Order',
    activityType: 'seller_loyalty',
    currency: 'super_coins',
    direction: 'credit',
    amount: 150,
    status: 'Completed',
    sellerName: 'Heritage Silk Studio',
    notes: 'Sponsored directly by seller for repeat loyalty',
    expiryDate: '10 Feb 2027',
  },
];

// ==========================================
// 11. FRAUD RISK RULES & AUDIT ENGINE
// ==========================================
export const INITIAL_FRAUD_RULES: FraudRiskRule[] = [
  {
    id: 'rule-daily-velocity',
    ruleName: 'Daily Social Mission Velocity Cap',
    description: 'Block claims exceeding 500 Super Coins in 24 hours from non-purchase tasks',
    limitValue: 500,
    timeWindow: 'daily',
    severity: 'high',
    isEnabled: true,
  },
  {
    id: 'rule-referral-ip',
    ruleName: 'Duplicate IP / Device Referral Guard',
    description: 'Hold referral rewards if inviter and invitee share identical hardware fingerprint',
    limitValue: 2,
    timeWindow: 'per_account',
    severity: 'critical',
    isEnabled: true,
  },
  {
    id: 'rule-order-cancellation-clawback',
    ruleName: 'Order Return Coin Clawback Rule',
    description: 'Automatically reverse credited Super Coins and Creator Diamonds upon order refund',
    limitValue: 1,
    timeWindow: 'per_account',
    severity: 'high',
    isEnabled: true,
  },
  {
    id: 'rule-bot-video-detection',
    ruleName: 'Reel Watch Time Integrity Check',
    description: 'Reject video mission completion if playback duration is under 12 seconds',
    limitValue: 12,
    timeWindow: 'hourly',
    severity: 'medium',
    isEnabled: true,
  },
];

export const INITIAL_FRAUD_AUDIT_LOGS: FraudAuditRecord[] = [
  {
    id: 'fraud-log-01',
    timestamp: '21 Aug 2026, 09:12 AM',
    userId: 'usr-bot-8812',
    userName: 'RapidClicks99',
    activity: 'Rapid Mission Claim Spurt',
    riskScore: 92,
    reason: 'Claimed 12 social missions in 3.4 seconds from same IP proxy',
    actionTaken: 'Auto_Blocked',
    currencyImpacted: 'super_coins',
    amount: 360,
    isReversed: true,
  },
  {
    id: 'fraud-log-02',
    timestamp: '20 Aug 2026, 11:30 PM',
    userId: 'usr-77218',
    userName: 'SameDeviceReferral',
    activity: 'Self Referral Attempt',
    riskScore: 78,
    reason: 'Referral code submitted from device sharing browser session cookie',
    actionTaken: 'Reward_Held',
    currencyImpacted: 'super_coins',
    amount: 500,
    isReversed: false,
  },
  {
    id: 'fraud-log-03',
    timestamp: '19 Aug 2026, 03:40 PM',
    userId: 'usr-priya-01',
    userName: 'Priya Sharma (Current User)',
    activity: 'Delivered Purchase Earning Check',
    riskScore: 4,
    reason: 'Verified legitimate order settlement with GPS courier completion',
    actionTaken: 'Approved',
    currencyImpacted: 'super_coins',
    amount: 120,
    isReversed: false,
  },
];

// ==========================================
// 12. CURRENCY ECONOMY CONFIGURATION
// ==========================================
export const INITIAL_CURRENCY_ECONOMY_CONFIG: CurrencyEconomyConfig = {
  superCoinValueInINR: 1.0, // 1 Super Coin = ₹1.00
  maxSuperCoinsRedemptionPercent: 50, // 50% max of cart total
  baseCoinsPer100RupeesSpent: 4, // 4 Coins per ₹100 for Bronze
  defaultCoinExpiryDays: 180,
  diamondValueInINRPer100: 50, // 100 Diamonds = ₹50 bank payout
  creatorAffiliateDiamondPercent: 10,
  dailyMissionMaxCoinsCap: 250,
  antiFraudVelocityMaxDailyCoins: 1000,
};

// ==========================================
// 13. SUPER COIN REWARDS STORE CATALOG
// ==========================================
export const INITIAL_SUPERCOIN_REWARDS_CATALOG: SuperCoinReward[] = [
  {
    id: 'rew-01',
    title: '₹200 Instant Artisan Store Voucher',
    description: 'Flat ₹200 off on handloom and silk apparel with no minimum order value.',
    coinsCost: 200,
    monetaryValue: 200,
    category: 'Discount',
    badge: '100% Value',
    imageUrl: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=400',
    partnerBrand: 'Antifly Storefront',
    expiresInDays: 30,
  },
  {
    id: 'rew-02',
    title: '1-Month SonyLIV Premium Subscription',
    description: 'Stream live sports, blockbusters and original series in full 4K HDR.',
    coinsCost: 299,
    monetaryValue: 299,
    category: 'OTT',
    badge: 'Popular',
    imageUrl: 'https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?w=400',
    partnerBrand: 'SonyLIV Streaming',
    expiresInDays: 60,
  },
  {
    id: 'rew-03',
    title: 'Free Express Delivery Pass (3 Orders)',
    description: 'Enjoy guaranteed same-day dispatch and zero shipping fee on your next 3 orders.',
    coinsCost: 150,
    monetaryValue: 297,
    category: 'Discount',
    badge: 'Saver',
    imageUrl: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=400',
    partnerBrand: 'Antifly Express',
    expiresInDays: 45,
  },
  {
    id: 'rew-04',
    title: 'MakeMyTrip ₹500 Flight Discount Voucher',
    description: 'Save flat ₹500 on all domestic flights booked via MakeMyTrip.',
    coinsCost: 350,
    monetaryValue: 500,
    category: 'Travel',
    badge: 'Hot Deal',
    imageUrl: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=400',
    partnerBrand: 'MakeMyTrip',
    expiresInDays: 90,
  },
  {
    id: 'rew-05',
    title: 'Swiggy Gourmet ₹150 Dining Voucher',
    description: 'Flat ₹150 off on gourmet restaurant orders above ₹399.',
    coinsCost: 150,
    monetaryValue: 150,
    category: 'Dining',
    badge: 'Foodie Pick',
    imageUrl: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400',
    partnerBrand: 'Swiggy Gourmet',
    expiresInDays: 30,
  },
  {
    id: 'rew-06',
    title: 'Artisan Heritage Pure Brass Diyas Set',
    description: 'Exclusive physical product drop redeemable 100% using Super Coins.',
    coinsCost: 800,
    monetaryValue: 1200,
    category: 'GiftCard',
    badge: 'Exclusive Drop',
    imageUrl: 'https://images.unsplash.com/photo-1606293926075-69a00dbfde81?w=400',
    partnerBrand: 'Heritage Crafts Guild',
    expiresInDays: 14,
  },
];
