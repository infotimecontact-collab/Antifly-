import { GA4AnalyticsEvent, GA4Config, GA4EventName } from '../types';

export const DEFAULT_GA4_CONFIG: GA4Config = {
  measurementId: 'G-WISEIND2026',
  gtmId: 'GTM-WISE7788',
  trackingEnabled: true,
  debugMode: true,
  enhancedMeasurement: {
    scrolls: true,
    outboundClicks: true,
    siteSearch: true,
    videoEngagement: true,
    fileDownloads: true,
    ecommercePurchase: true,
  },
};

// Event listener registry for live telemetry dashboard in Admin
type AnalyticsSubscriber = (event: GA4AnalyticsEvent) => void;
const subscribers: Set<AnalyticsSubscriber> = new Set();
const eventHistory: GA4AnalyticsEvent[] = [];
const MAX_HISTORY = 100;

export function subscribeToAnalytics(callback: AnalyticsSubscriber): () => void {
  subscribers.add(callback);
  return () => subscribers.delete(callback);
}

export function getAnalyticsEventHistory(): GA4AnalyticsEvent[] {
  return [...eventHistory];
}

/**
 * Dispatch a Google Analytics 4 E-Commerce or Telemetry Event
 */
export function trackGA4Event(
  eventName: GA4EventName,
  params: GA4AnalyticsEvent['params'] = {},
  userProperties: GA4AnalyticsEvent['userProperties'] = {}
): GA4AnalyticsEvent {
  const event: GA4AnalyticsEvent = {
    id: `ga4-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    eventName,
    timestamp: new Date().toISOString(),
    source: typeof window !== 'undefined' ? window.location.pathname : '/',
    url: typeof window !== 'undefined' ? window.location.href : 'https://antifly.in',
    params: {
      currency: params.currency || 'INR',
      ...params,
    },
    userProperties: {
      region: 'IN',
      device_category: typeof window !== 'undefined' && window.innerWidth < 768 ? 'mobile' : 'desktop',
      ...userProperties,
    },
  };

  // Keep in memory event stream
  eventHistory.unshift(event);
  if (eventHistory.length > MAX_HISTORY) {
    eventHistory.pop();
  }

  // Notify any active Admin telemetry viewers
  subscribers.forEach((cb) => {
    try {
      cb(event);
    } catch (e) {
      console.warn('Analytics subscriber error:', e);
    }
  });

  // If real window.gtag exists, push to dataLayer
  if (typeof window !== 'undefined') {
    const win = window as any;
    if (typeof win.gtag === 'function') {
      win.gtag('event', eventName, params);
    } else if (win.dataLayer && Array.isArray(win.dataLayer)) {
      win.dataLayer.push({
        event: eventName,
        ...params,
      });
    }
  }

  return event;
}

/**
 * E-commerce specific GA4 helpers
 */
export const Analytics = {
  viewItem: (product: { id: string; name: string; brand: string; category: string; price: number }) => {
    trackGA4Event('view_item', {
      value: product.price,
      currency: 'INR',
      item_id: product.id,
      item_name: product.name,
      item_brand: product.brand,
      item_category: product.category,
      price: product.price,
    });
  },

  addToCart: (item: { productId: string; productName: string; brand: string; price: number; quantity: number }) => {
    trackGA4Event('add_to_cart', {
      value: item.price * item.quantity,
      currency: 'INR',
      item_id: item.productId,
      item_name: item.productName,
      item_brand: item.brand,
      price: item.price,
      quantity: item.quantity,
    });
  },

  removeFromCart: (item: { productId: string; productName: string; price: number; quantity: number }) => {
    trackGA4Event('remove_from_cart', {
      value: item.price * item.quantity,
      currency: 'INR',
      item_id: item.productId,
      item_name: item.productName,
      price: item.price,
      quantity: item.quantity,
    });
  },

  beginCheckout: (cartTotal: number, itemCount: number) => {
    trackGA4Event('begin_checkout', {
      value: cartTotal,
      currency: 'INR',
      quantity: itemCount,
    });
  },

  purchase: (order: { orderNumber: string; totalAmount: number; discount: number; paymentMethod: string; couponCode?: string }) => {
    trackGA4Event('purchase', {
      transaction_id: order.orderNumber,
      value: order.totalAmount,
      currency: 'INR',
      coupon: order.couponCode || 'NONE',
      payment_type: order.paymentMethod,
    });
  },

  search: (searchTerm: string, resultsCount: number) => {
    trackGA4Event('search', {
      search_term: searchTerm,
      results_count: resultsCount,
    });
  },

  rateProduct: (productId: string, productName: string, rating: number) => {
    trackGA4Event('rate_product', {
      item_id: productId,
      item_name: productName,
      rating,
    });
  },
};
