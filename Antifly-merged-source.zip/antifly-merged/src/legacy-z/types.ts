export type DeviceMode = 'lifeos' | 'social' | 'website' | 'mobile-ios' | 'mobile-android' | 'seller' | 'driver' | 'admin' | 'api-docs';
export type ThemeMode = 'light' | 'dark' | 'system';
export type LanguageCode =
  | 'en' // English
  | 'hi' // Hindi (हिन्दी)
  | 'es' // Spanish (Español)
  | 'fr' // French (Français)
  | 'de' // German (Deutsch)
  | 'ar' // Arabic (العربية)
  | 'zh' // Chinese (中文)
  | 'ja' // Japanese (日本語)
  | 'pt' // Portuguese (Português)
  | 'bn' // Bengali (বাংলা)
  | 'te' // Telugu (తెలుగు)
  | 'ta'; // Tamil (தமிழ்)

export interface LanguageInfo {
  code: LanguageCode;
  name: string;
  nativeName: string;
  flag: string;
  dir: 'ltr' | 'rtl';
}
export type OrderSource = 'Website' | 'Android App' | 'iOS App' | 'Admin';
export type OrderStatus = 'Pending' | 'Confirmed' | 'Packed' | 'Shipped' | 'Out for delivery' | 'Delivered' | 'Cancelled' | 'Returned' | 'Refunded';
export type PaymentMethod =
  | 'UPI'
  | 'Credit/Debit Card'
  | 'Net Banking'
  | 'Wallets'
  | 'Cash on Delivery'
  | 'Stripe (Apple/Google Pay)'
  | 'PayPal Worldwide'
  | 'Klarna (BNPL)';

export type CountryCode = 'IN' | 'US' | 'GB' | 'EU' | 'AE' | 'CA' | 'AU' | 'SG';
export type CurrencyCode = 'INR' | 'USD' | 'GBP' | 'EUR' | 'AED' | 'CAD' | 'AUD' | 'SGD';

export interface RegionConfig {
  code: CountryCode;
  name: string;
  flag: string;
  currency: CurrencyCode;
  symbol: string;
  rateFromINR: number; // e.g. 1 INR = 0.012 USD
  taxRate: number; // e.g. 0.0825 for US, 0.18 for India
  taxName: string; // GST, US State Tax, UK VAT, EU VAT, UAE VAT
  phoneCode: string;
  postalCodeLabel: string;
  postalCodePlaceholder: string;
  defaultCourier: string;
  supportedPaymentMethods: PaymentMethod[];
  states: string[];
  freeShippingThresholdUSD: number;
  standardShippingFeeUSD: number;
}

export interface ProductVariant {
  id: string;
  sku: string;
  color: string;
  colorHex: string;
  size: string;
  price: number;
  mrp: number;
  stock: number;
  image?: string;
}

export interface ProductSpecification {
  label: string;
  value: string;
}

export interface ProductReview {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  title: string;
  comment: string;
  date: string;
  verifiedPurchase: boolean;
  isVerified?: boolean;
  images?: string[];
  pros?: string[];
  cons?: string[];
  helpfulCount?: number;
  location?: string;
  status: 'Approved' | 'Pending' | 'Rejected';
  featured?: boolean;
}

export interface ProductQuestion {
  id: string;
  question: string;
  askedBy: string;
  date: string;
  answer?: string;
  answeredBy?: string;
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  barcode: string;
  brand: string;
  category: string;
  subcategory: string;
  shortDescription: string;
  description: string;
  price: number;
  mrp: number;
  discountPercentage: number;
  taxPercentage: number;
  finalPrice: number;
  totalStock: number;
  rating: number;
  reviewCount: number;
  images: string[];
  videoUrl?: string;
  variants: ProductVariant[];
  colors: { name: string; hex: string }[];
  sizes: string[];
  materials: string[];
  specifications: ProductSpecification[];
  features: string[];
  tags: string[];
  searchKeywords: string[];
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  shippingInfo: string;
  returnPolicy: string;
  exchangePolicy: string;
  reviews?: ProductReview[];
  isPublished: boolean;
  isFeatured?: boolean;
  isTrending?: boolean;
  isNewArrival?: boolean;
  isBestSeller?: boolean;
  isBestseller?: boolean;
  isDealOfTheDay?: boolean;
  title?: string;
  image?: string;
  stock?: number;
  reviewsCount?: number;
  slug?: string;
  createdAt?: string;
  updatedAt?: string;
  sellerId?: string;
  sellerName?: string;
  sellerVerified?: boolean;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: string;
  iconName: string;
  subcategories: string[];
  itemCount: number;
  isFeatured: boolean;
  bannerImage?: string;
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  type: 'Hero' | 'Promotional' | 'Category' | 'Offer' | 'App' | 'Popup';
  desktopImage: string;
  mobileImage: string;
  ctaText: string;
  destinationUrl: string;
  categorySlug?: string;
  productId?: string;
  discountBadge?: string;
  priority: number;
  isActive: boolean;
  startDate?: string;
  endDate?: string;
  timingSeconds?: number;
  liveTag?: string;
  themeStyle?: string;
}

export interface HomepageSection {
  id: string;
  title: string;
  subtitle?: string;
  type:
    | 'hero-banner'
    | 'categories-grid'
    | 'trending-products'
    | 'flash-deals'
    | 'ai-recommendations'
    | 'new-arrivals'
    | 'best-sellers'
    | 'deal-of-day'
    | 'collection-spotlight'
    | 'shop-by-price'
    | 'shop-by-occasion'
    | 'customer-reviews'
    | 'app-download'
    | 'features-bar';
  order: number;
  isVisible: boolean;
  config?: Record<string, any>;
}

export interface CartItem {
  id: string;
  productId: string;
  variantId: string;
  productName: string;
  brand: string;
  color: string;
  size: string;
  price: number;
  mrp: number;
  image: string;
  quantity: number;
  stock: number;
}

export interface Address {
  id: string;
  fullName: string;
  phone: string;
  street: string;
  apartment?: string;
  city: string;
  state: string;
  pincode: string;
  country: string;
  isDefault: boolean;
  type: 'Home' | 'Work' | 'Other';
}

export interface OrderItem {
  productId: string;
  variantId: string;
  productName: string;
  brand: string;
  color: string;
  size: string;
  price: number;
  mrp: number;
  quantity: number;
  image: string;
}

export interface OrderTrackingEvent {
  status: OrderStatus;
  timestamp: string;
  location: string;
  description: string;
  isCompleted: boolean;
}

export interface Order {
  id: string;
  orderNumber: string;
  source: OrderSource;
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  shippingAddress: Address;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  tax: number;
  shippingFee: number;
  totalAmount: number;
  paymentMethod: PaymentMethod;
  paymentStatus: 'Pending' | 'Paid' | 'Failed' | 'Refunded';
  transactionId?: string;
  status: OrderStatus;
  createdAt: string;
  updatedAt: string;
  estimatedDelivery: string;
  courierName?: string;
  trackingNumber?: string;
  timeline: OrderTrackingEvent[];
  cancelReason?: string;
  returnReason?: string;
  returnStatus?: 'None' | 'Requested' | 'Approved' | 'Rejected' | 'Refunded' | 'Exchanged';
  invoiceUrl?: string;
  deliveryOtp?: string;
  sellerId?: string;
  sellerName?: string;
  originApp?: string;
  adminPlatformFee?: number;
  adminPlatformFeeStatus?: 'Paid' | 'Auto-Deducted' | 'Pending';
  isExternalAppOrder?: boolean;
}

export interface SellerAdminFeeRecord {
  id: string;
  orderId: string;
  orderNumber: string;
  sellerId: string;
  sellerName: string;
  originApp: string;
  productName: string;
  couponCode?: string;
  adminFee: number;
  date: string;
  status: 'Auto-Deducted' | 'Paid' | 'Pending';
}

export interface Coupon {
  id: string;
  code: string;
  description: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minCartValue: number;
  maxDiscount?: number;
  startDate: string;
  endDate: string;
  usageLimit: number;
  usedCount: number;
  isActive: boolean;
  appOnly: boolean;
  websiteOnly: boolean;
  categoryRestriction?: string;
  sellerId?: string;
  sellerName?: string;
  isSellerCoupon?: boolean;
  applicableProductIds?: string[];
  syndicateToExternalApps?: boolean;
}

export interface ReturnRequest {
  id: string;
  orderId: string;
  orderNumber: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  productId: string;
  productName: string;
  productImage: string;
  reason: string;
  type: 'Refund' | 'Exchange';
  requestedExchangeSize?: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Completed';
  createdAt: string;
  comment?: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  registeredAt: string;
  totalOrders: number;
  totalSpent: number;
  lastOrderDate?: string;
  addresses: Address[];
  status: 'Active' | 'Inactive' | 'Blocked';
  tags: string[];
  preferredSource: OrderSource;
}

export interface AbandonedCart {
  id: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  source: OrderSource;
  items: CartItem[];
  cartValue: number;
  abandonedAt: string;
  reminderSent: boolean;
  reminderCount: number;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  userRole: string;
  action: string;
  module: 'Products' | 'Orders' | 'Banners' | 'Coupons' | 'Inventory' | 'Settings' | 'Returns' | 'CMS';
  details: string;
  timestamp: string;
  ipAddress?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'order' | 'promo' | 'system' | 'email_preview' | 'stock_alert';
  timestamp: string;
  isRead: boolean;
  link?: string;
  emailHtml?: string;
  productId?: string;
  productImage?: string;
}

export interface StockAlertSubscription {
  id: string;
  productId: string;
  variantId?: string;
  variantName?: string;
  color?: string;
  size?: string;
  userEmail: string;
  userPhone?: string;
  enablePush: boolean;
  enableEmail: boolean;
  enableWhatsapp: boolean;
  subscribedAt: string;
  productName: string;
  productImage: string;
  productPrice: number;
  brand: string;
  status: 'active' | 'notified' | 'cancelled';
}

export interface PushNotificationMockData {
  id: string;
  title: string;
  body: string;
  icon?: string;
  image?: string;
  productId?: string;
  productName?: string;
  timestamp: string;
  actionUrl?: string;
  variantInfo?: string;
  badge?: string;
}

export interface CMSPage {
  slug: string;
  title: string;
  metaDescription: string;
  content: string;
  lastUpdated: string;
  version: string;
}

export interface StoreSettings {
  storeName: string;
  contactPhone: string;
  contactEmail: string;
  businessAddress: string;
  currencySymbol: string;
  freeShippingThreshold: number;
  standardShippingFee: number;
  expressShippingFee: number;
  gstPercentage: number;
  codEnabled: boolean;
  upiEnabled: boolean;
  cardsEnabled: boolean;
  netBankingEnabled: boolean;
  stripeEnabled: boolean;
  paypalEnabled: boolean;
  klarnaEnabled: boolean;
  antiflyAiEnabled: boolean;
}

export interface AdminRole {
  id: string;
  roleName: string;
  description: string;
  permissions: string[];
}

export interface RefundRecord {
  id: string;
  orderId: string;
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  amount: number;
  currency: CurrencyCode;
  paymentMethod: PaymentMethod;
  initiatedAt: string;
  expectedCreditDate: string; // 5 working days
  currentDay: number; // 1, 2, 3, 4, or 5
  status: 'Initiated' | 'Bank_Processing' | 'Gateway_Clearance' | 'Settlement_Scheduled' | 'Credited';
  bankReferenceNumber: string; // ARN / UTR
  refundReason: string;
  destinationAccount: string; // e.g. "HDFC Bank (ending in 4821)" or "Stripe card (ending in 9214)"
  dayLog: { day: number; title: string; desc: string; date: string; isComplete: boolean }[];
}

export interface GatewayKeysConfig {
  stripePublishableKey: string;
  stripeSecretKey: string;
  stripeWebhookSecret: string;
  stripeLiveMode: boolean;
  
  razorpayKeyId: string;
  razorpayKeySecret: string;
  razorpayLiveMode: boolean;
  
  paypalClientId: string;
  paypalSecretKey: string;
  paypalLiveMode: boolean;

  twilioSid: string;
  twilioAuthToken: string;
  twilioFromNumber: string;
  twilioEnabled: boolean;

  msg91AuthKey: string;
  msg91SenderId: string;
  msg91Enabled: boolean;

  sendgridApiKey: string;
  sendgridFromEmail: string;
  sendgridFromName: string;
  sendgridEnabled: boolean;

  googleMapsApiKey: string;
  mapsTrackingEnabled: boolean;

  geminiApiKey: string;
  aiModelName: string;
}

export interface DataPrivacySettings {
  gdprActive: boolean;
  dpdpIndiaActive: boolean;
  ccpaActive: boolean;
  cookieConsentBanner: boolean;
  dataRetentionDays: number;
  allowSelfAccountDeletion: boolean;
  anonymizeOrdersAfterMonths: number;
  auditTrailExportEnabled: boolean;
  complianceContactEmail: string;
}

export interface InvoiceData {
  invoiceNumber: string;
  orderNumber: string;
  invoiceDate: string;
  orderDate: string;
  sellerDetails: {
    name: string;
    tradeName: string;
    gstinOrVat: string;
    pan: string;
    cin: string;
    address: string;
    phone: string;
    email: string;
  };
  buyerDetails: {
    name: string;
    address: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
    phone: string;
    email: string;
    taxId?: string;
  };
  items: {
    name: string;
    sku: string;
    hsnCode: string;
    quantity: number;
    unitPrice: number;
    taxRate: number;
    taxAmount: number;
    total: number;
  }[];
  subtotal: number;
  taxTotal: number;
  taxLabel: string;
  shippingFee: number;
  discount: number;
  grandTotal: number;
  currency: CurrencyCode;
  currencySymbol: string;
  paymentMethod: PaymentMethod;
  paymentStatus: string;
  irnNumber?: string;
  qrCodeUrl?: string;
}

export interface MapTrackingState {
  orderId: string;
  courierName: string;
  trackingNumber: string;
  riderName: string;
  riderPhone: string;
  vehicleNumber: string;
  vehicleType: 'bike' | 'van' | 'plane';
  currentStepIndex: number;
  originHub: { name: string; city: string; lat: number; lng: number };
  transitHub: { name: string; city: string; lat: number; lng: number };
  deliveryHub: { name: string; city: string; lat: number; lng: number };
  destination: { name: string; city: string; lat: number; lng: number };
  currentLocation: { lat: number; lng: number; address: string };
  etaMinutes: number;
}

// ==========================================
// FLIPKART SIGNATURE FEATURES
// ==========================================
export interface SuperCoinReward {
  id: string;
  title: string;
  description: string;
  coinsCost: number;
  monetaryValue: number;
  category: 'Discount' | 'OTT' | 'Travel' | 'GiftCard' | 'Dining';
  badge: string;
  imageUrl: string;
  partnerBrand: string;
  expiresInDays: number;
}

export interface SuperCoinTransaction {
  id: string;
  type: 'Earned' | 'Spent';
  amount: number;
  description: string;
  date: string;
  orderNumber?: string;
}

export interface PlusMemberTier {
  tierName: 'Silver' | 'Plus Member' | 'Plus Premium';
  superCoinsBalance: number;
  coinsMultiplier: number;
  freeExpressDelivery: boolean;
  earlyAccessHours: number;
  exclusiveDeals: boolean;
}

// ==========================================
// MEESHO SIGNATURE FEATURES
// ==========================================
export interface ResellerConfig {
  isReselling: boolean;
  resellerShopName: string;
  resellerPhone: string;
  resellerMarginPercentage?: number;
  totalEarnings: number;
  withdrawnEarnings: number;
  pendingEarnings: number;
}

export interface GroupBuyDeal {
  id: string;
  productId: string;
  productName: string;
  productImage: string;
  originalPrice: number;
  groupPrice: number;
  savings: number;
  requiredMembers: number;
  currentMembers: number;
  leaderName: string;
  leaderAvatar: string;
  expiresInSeconds: number;
  groupCode: string;
}

// ==========================================
// MYNTRA SIGNATURE FEATURES
// ==========================================
export interface StyleCastLook {
  id: string;
  title: string;
  influencerName: string;
  influencerHandle: string;
  influencerAvatar: string;
  coverImage: string;
  videoPreview?: string;
  occasion: 'Festive Glam' | 'Streetwear Casual' | 'Royal Wedding' | 'Old Money' | 'Workplace Chic';
  likesCount: number;
  viewsCount: string;
  taggedProductIds: string[];
  stylingTips: string[];
  bundleDiscountPercentage: number;
}

export interface SizeRecommendationProfile {
  heightCm: number;
  weightKg: number;
  bodyType: 'Slim' | 'Athletic' | 'Average' | 'Curvy' | 'Broad';
  fitPreference: 'Fitted' | 'Regular' | 'Relaxed / Oversized';
  recommendedSize: string;
  confidenceScore: number;
  matchedShoppersCount: number;
}

export interface CompleteTheLookBundle {
  id: string;
  mainProductId: string;
  title: string;
  bundleDiscountPercent: number;
  pairedProductIds: string[];
}

// ==========================================
// FOOD DELIVERY (WISEBITES / CLOUD KITCHENS)
// ==========================================
export interface FoodItemCustomization {
  name: string;
  required?: boolean;
  options: { label: string; price: number }[];
}

export interface FoodItem {
  id: string;
  name: string;
  description: string;
  price: number;
  mrp: number;
  isVeg: boolean;
  image: string;
  rating: number;
  votes: number;
  category: string;
  inStock: boolean;
  isBestseller?: boolean;
  isSpicy?: boolean;
  customizationOptions?: FoodItemCustomization[];
}

export interface RestaurantMenuCategory {
  id: string;
  name: string;
  items: FoodItem[];
}

export interface Restaurant {
  id: string;
  name: string;
  cuisines: string[];
  rating: number;
  ratingCount: string;
  deliveryTimeMin: number;
  deliveryTimeMax: number;
  priceForTwo: number;
  address: string;
  distanceKm: number;
  image: string;
  bannerImage: string;
  isPureVeg?: boolean;
  discountOffer: string;
  isPromoted?: boolean;
  menuCategories: RestaurantMenuCategory[];
}

export interface FoodCartItem {
  foodItem: FoodItem;
  restaurantId: string;
  restaurantName: string;
  quantity: number;
  selectedOptions?: { [key: string]: string };
  extraPrice: number;
  specialInstructions?: string;
}

export interface FoodOrder {
  id: string;
  restaurantId: string;
  restaurantName: string;
  restaurantImage: string;
  items: FoodCartItem[];
  subtotal: number;
  deliveryFee: number;
  discount: number;
  taxes: number;
  total: number;
  deliveryAddress: string;
  status: 'Confirmed' | 'Preparing in Kitchen' | 'Rider Picked Up' | 'Out for Delivery' | 'Delivered';
  placedAt: string;
  etaMinutes: number;
  riderName: string;
  riderPhone: string;
  riderVehicle: string;
  tipAmount: number;
}

// ==========================================
// ALL-IN-ONE MASTER SUBSCRIPTION (WISEONE PASS)
// ==========================================
export interface AntiflyOnePlan {
  id: string;
  name: string;
  price: number;
  originalPrice: number;
  duration: '1 Month' | '12 Months' | '3 Years';
  badge: string;
  tagline: string;
  benefits: string[];
  isPopular?: boolean;
  ottIncluded: string[];
  color: string;
}

export interface AntiflyOneSubscription {
  isActive: boolean;
  planId?: string;
  planName?: string;
  expiryDate?: string;
  totalSavedSoFar: number;
  freeDeliveriesUsed: number;
  ottPassesClaimed: string[];
}

// ==========================================
// ALL BANK CREDIT CARDS & EMI OFFERS
// ==========================================
export interface EMIOption {
  months: number;
  monthlyAmount: number;
  interestRate: number;
  totalInterest: number;
  isNoCost: boolean;
  minAmount: number;
}

export interface BankCardOffer {
  id: string;
  bankName: string;
  bankCode: 'HDFC' | 'SBI' | 'ICICI' | 'AXIS' | 'KOTAK' | 'AMEX' | 'RBL' | 'INDUSIND' | 'HSBC' | 'SC';
  cardType: 'Credit Card' | 'Debit Card' | 'EMI' | 'All Cards';
  discountPercent: number;
  maxDiscount: number;
  minOrderValue: number;
  code: string;
  title: string;
  description: string;
  iconBg: string;
  logoText: string;
  instantDiscountText: string;
  popularCardNames: string[];
  emiOptions?: EMIOption[];
}

// ==========================================
// OTT ENTERTAINMENT PLATFORM (WISESTREAM)
// ==========================================
export interface OTTPlatform {
  id: string;
  name: string;
  logo: string;
  brandColor: string;
  tagline: string;
  includedInPass: boolean;
  monthlyValue: number;
  featuredContentCount: string;
}

export interface OTTShow {
  id: string;
  title: string;
  platform: string;
  platformColor: string;
  category: 'Trending Movie' | 'Web Series' | 'Live Cricket & Sports' | 'Blockbuster' | 'Documentary';
  genre: string;
  rating: string;
  duration: string;
  releaseYear: number;
  thumbnail: string;
  bannerUrl: string;
  trailerVideoUrl?: string;
  description: string;
  cast: string[];
  isLiveEvent?: boolean;
  exclusiveBadge?: string;
}

// ==========================================
// GOOGLE ANALYTICS 4 (GA4) & TELEMETRY
// ==========================================
export type GA4EventName =
  | 'page_view'
  | 'view_item'
  | 'view_item_list'
  | 'select_item'
  | 'add_to_cart'
  | 'remove_from_cart'
  | 'view_cart'
  | 'begin_checkout'
  | 'add_shipping_info'
  | 'add_payment_info'
  | 'purchase'
  | 'refund'
  | 'search'
  | 'view_promotion'
  | 'select_promotion'
  | 'add_to_wishlist'
  | 'share'
  | 'rate_product'
  | 'food_order_placed'
  | 'subscription_purchased'
  | 'video_start'
  | 'video_progress'
  | 'video_complete';

export interface GA4AnalyticsEvent {
  id: string;
  eventName: GA4EventName;
  timestamp: string;
  source: string;
  url: string;
  params: {
    currency?: string;
    value?: number;
    transaction_id?: string;
    item_id?: string;
    item_name?: string;
    item_brand?: string;
    item_category?: string;
    price?: number;
    quantity?: number;
    search_term?: string;
    coupon?: string;
    shipping_tier?: string;
    payment_type?: string;
    promotion_id?: string;
    promotion_name?: string;
    rating?: number;
    [key: string]: any;
  };
  userProperties?: {
    user_id?: string;
    customer_tier?: string;
    region?: string;
    device_category?: string;
  };
}

export interface GA4Config {
  measurementId: string; // e.g. G-ZOLONIK99X
  gtmId: string; // e.g. GTM-ZOLONIK882
  trackingEnabled: boolean;
  debugMode: boolean;
  enhancedMeasurement: {
    scrolls: boolean;
    outboundClicks: boolean;
    siteSearch: boolean;
    videoEngagement: boolean;
    fileDownloads: boolean;
    ecommercePurchase: boolean;
  };
}

// ==========================================
// SEO & STRUCTURED DATA (SCHEMA.ORG)
// ==========================================
export interface SEOMetadata {
  metaTitle: string;
  metaDescription: string;
  metaKeywords: string[];
  canonicalUrl: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
  ogType: 'website' | 'product' | 'article';
  twitterCard: 'summary' | 'summary_large_image';
  structuredDataJsonLd: string;
  noIndex?: boolean;
}

// ==========================================
// SMART PRODUCT FINDER & OCCASION QUIZ
// ==========================================
export interface ProductFinderCriteria {
  recipient: 'Myself' | 'Partner' | 'Parents / Family' | 'Friend / Colleague' | 'Kids';
  occasion: 'Wedding & Festive' | 'Office & Formal' | 'Daily Casual & Lounging' | 'Party & Night Out' | 'Travel & Vacation' | 'Fitness & Active';
  budgetMax: number;
  categoryPreference: string;
  priorityFeature: 'Pure Breathable Fabric' | 'Heavy Discount (40%+)' | 'Customer Top Rated (4.5★+)' | 'Express Same-Day Dispatch' | 'Handcrafted Artisan Exclusive';
}

export interface ProductFinderMatch {
  product: Product;
  matchScore: number; // 0 - 100
  matchReason: string;
  highlightBadge: string;
}

// ==========================================
// SELLER CENTRAL & VENDOR MANAGEMENT & SOCIAL PORTFOLIO
// ==========================================
export interface ProductCommentItem {
  id: string;
  productId: string;
  userName: string;
  userAvatar?: string;
  userRole?: 'Verified Buyer' | 'Top Contributor' | 'Shopper' | 'Seller';
  text: string;
  timestamp: string;
  likesCount: number;
  isLikedByMe?: boolean;
  quickReactionType?: 'good' | 'not_good' | 'bad' | 'dont_buy' | 'custom';
  replies?: {
    id: string;
    userName: string;
    userAvatar?: string;
    userRole?: string;
    text: string;
    timestamp: string;
    likesCount: number;
    isLikedByMe?: boolean;
  }[];
}

export interface SellerPost {
  id: string;
  sellerId: string;
  sellerName: string;
  sellerAvatar: string;
  imageUrl: string;
  caption: string;
  uploadedAt: string;
  likesCount: number;
  dislikesCount: number;
  isLikedByMe?: boolean;
  isDislikedByMe?: boolean;
  isSavedByMe?: boolean;
  commentsCount: number;
  comments: {
    id: string;
    userName: string;
    userAvatar?: string;
    text: string;
    timestamp: string;
    likesCount: number;
    isLikedByMe?: boolean;
  }[];
  taggedProductId?: string;
  taggedProductName?: string;
  taggedProductPrice?: number;
  category?: string;
}

export interface SellerPortfolioItem {
  id: string;
  sellerId: string;
  sellerName: string;
  title: string;
  description: string;
  imageUrl: string;
  category: 'Craftsmanship' | 'Workshop & Weaving' | 'Awards & GI Certification' | 'Lookbook & Studio' | 'Master Creations';
  likesCount: number;
  dislikesCount: number;
  isLikedByMe?: boolean;
  isDislikedByMe?: boolean;
  isSavedByMe?: boolean;
  tags: string[];
  dateAdded?: string;
}

export interface SellerRecentImage {
  id: string;
  sellerId: string;
  sellerName: string;
  sellerAvatar: string;
  imageUrl: string;
  caption: string;
  uploadedAt: string;
  likesCount: number;
  dislikesCount?: number;
  isLikedByMe?: boolean;
  isDislikedByMe?: boolean;
  isSavedByMe?: boolean;
  taggedProductId?: string;
  taggedProductName?: string;
  taggedProductPrice?: number;
}

export interface SellerProfile {
  id: string;
  storeName: string;
  legalEntityName: string;
  email: string;
  phone: string;
  gstNumber: string;
  panNumber: string;
  rating: number;
  totalOrders: number;
  totalRevenue: number;
  balanceEscrow: number;
  balanceAvailable: number;
  commissionRate: number; // e.g., 0.08 (8%)
  tier: 'Diamond Vendor' | 'Gold Supplier' | 'Silver Merchant' | 'New Onboard';
  warehouseAddress: {
    street: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
  };
  bankAccount: {
    accountNumber: string;
    ifscCode: string;
    bankName: string;
    beneficiaryName: string;
  };
  fulfillmentType: 'AntiflyFulfilled (FBF)' | 'Seller Self-Ship (FBM)';
  badge: string;
  storeBannerImage?: string;
  storeAvatar?: string;
  distanceKm?: number;
  category?: string;
  followersCount: number;
  isFollowedByMe?: boolean;
  deliveryTimeMin?: number;
  isOpen?: boolean;
  recentImages?: SellerRecentImage[];
  posts?: SellerPost[];
  portfolio?: SellerPortfolioItem[];
  savedItemIds?: string[];
  bio?: string;
}

export interface SellerPayout {
  id: string;
  sellerId: string;
  amount: number;
  currency: string;
  utrNumber: string;
  status: 'Completed' | 'Processing' | 'Pending';
  date: string;
  orderCount: number;
}

// ==========================================
// DRIVER & DELIVERY PARTNER MANAGEMENT
// ==========================================
export interface DriverProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  avatar: string;
  vehicleType: 'Electric Bike' | 'Motorcycle' | 'Cargo Van' | 'EV Scooter';
  vehicleNumber: string;
  rating: number;
  completedDeliveries: number;
  isOnline: boolean;
  currentLat: number;
  currentLng: number;
  todayEarnings: number;
  todayTrips: number;
  walletBalance: number;
  cashInHand: number; // For COD collected
  badge: 'Top Gun Rider' | 'Speed Master' | 'Star Partner';
}

export interface DriverDeliveryTask {
  id: string;
  orderId: string;
  trackingNumber: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  sellerName: string;
  sellerAddress: string;
  pickupLat: number;
  pickupLng: number;
  dropLat: number;
  dropLng: number;
  status: 'Assigned' | 'Heading to Pickup' | 'Picked Up' | 'In Transit' | 'Arrived at Drop' | 'Delivered' | 'Failed Attempt';
  paymentMode: 'PREPAID' | 'COD';
  codAmountToCollect: number;
  itemsCount: number;
  otpCode: string;
  distanceKm: number;
  estimatedMinutes: number;
  payoutFee: number;
  tipAmount: number;
  specialInstructions?: string;
  proofPhoto?: string;
  customerSignature?: string;
  deliveredAt?: string;
}

export interface DriverIncentiveLedgerEntry {
  id: string;
  driverId: string;
  driverName: string;
  driverPhone: string;
  driverAvatar: string;
  vehicleType: string;
  vehicleNumber: string;
  orderId: string;
  timestamp: string;
  creditsEarned: number;
  conversionRate: number; // e.g. 1 Credit = 1 INR
  rupeesTransferred: number;
  ordersMilestoneCount: number;
  incentiveType: 'Delivery Milestone Bonus' | 'Daily Target 20 Orders Bonus' | 'Rain / Peak Surge' | '5-Star Customer Rating' | 'On-Time Express Dispatch' | 'Fuel & Weekend Bonus';
  status: 'Settled to UPI' | 'Processing' | 'Direct Bank IMPS';
  transactionReference: string;
}

// ==========================================
// E-COMMERCE WORLD API SUITE
// ==========================================
export interface EcomAPIEndpoint {
  id: string;
  category: 'Authentication' | 'Catalog & Search' | 'Cart & Checkout' | 'Orders & Tracking' | 'Seller Central' | 'Driver Logistics' | 'Payments & Webhooks' | 'Analytics & Telemetry';
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  path: string;
  summary: string;
  description: string;
  authRequired: boolean;
  requiredRole?: 'customer' | 'seller' | 'driver' | 'admin' | 'public';
  requestParams?: Array<{
    name: string;
    type: string;
    required: boolean;
    description: string;
    example?: string;
  }>;
  requestBodyExample?: Record<string, any>;
  responseSuccessExample: Record<string, any>;
  responseErrorExample?: Record<string, any>;
}

export interface APIRequestLog {
  id: string;
  timestamp: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  endpoint: string;
  statusCode: number;
  durationMs: number;
  clientIp: string;
  role: string;
  payload?: any;
  response?: any;
}

export interface UserSession {
  isLoggedIn: boolean;
  role: 'customer' | 'seller' | 'driver' | 'admin';
  name: string;
  phone: string;
  email?: string;
  avatar: string;
  authMethod: 'mobile_otp' | 'google' | 'apple' | 'github';
  sellerId?: string;
  driverId?: string;
  token?: string;
}

// ==========================================
// WHATSAPP-STYLE UNIVERSAL 1-TO-1 & AI CHAT
// ==========================================
export type ChatMessageType =
  | 'text'
  | 'image'
  | 'video_15s'
  | 'reel'
  | 'voice_note'
  | 'location'
  | 'product_card'
  | 'order_summary'
  | 'system';

export interface ChatMessageItem {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderRole: 'customer' | 'seller' | 'driver' | 'support_ai' | 'community';
  senderAvatar: string;
  content: string;
  type: ChatMessageType;
  mediaUrl?: string;
  durationSeconds?: number;
  viewOnce?: boolean;
  viewOnceOpened?: boolean;
  productSnippet?: {
    id: string;
    name: string;
    price: number;
    mrp: number;
    image: string;
  };
  locationSnippet?: {
    name: string;
    address: string;
    lat: number;
    lng: number;
  };
  orderSnippet?: {
    orderNumber: string;
    status: string;
    totalAmount: number;
    itemsCount: number;
  };
  timestamp: string;
  status: 'sending' | 'sent' | 'delivered' | 'read';
  isSelf: boolean;
}

export interface ChatConversation {
  id: string;
  peerId: string;
  peerName: string;
  peerRole: 'customer' | 'seller' | 'driver' | 'support_ai' | 'community_group';
  peerAvatar: string;
  peerSubtitle: string;
  isOnline: boolean;
  isVerified: boolean;
  unreadCount: number;
  lastMessage: string;
  lastMessageTime: string;
  isMuted: boolean;
  isBlocked: boolean;
  isEncrypted: boolean;
  disappearingTimer: 'off' | '24h' | '7d';
  chatEnabled: boolean;
  contextTag?: string; // e.g. "Order #ORD-78912" or "Saree Collection" or "Driver Dispatch"
}

// ==========================================
// COMMUNITY HUB & 15s SHORT VIDEO REELS
// ==========================================
export interface CommunityCommentItem {
  id: string;
  authorName: string;
  authorAvatar: string;
  authorRole: 'customer' | 'creator' | 'seller';
  text: string;
  timestamp: string;
  likes: number;
}

export interface CommunityPostItem {
  id: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  authorRole: 'creator' | 'seller' | 'customer';
  isVerified: boolean;
  mediaType: 'reel_15s' | 'image' | 'video' | 'post';
  mediaUrl: string;
  thumbnailUrl?: string;
  videoDurationSeconds?: number; // 15 for reels
  caption: string;
  tags: string[];
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  isLikedByMe: boolean;
  isSavedByMe: boolean;
  taggedProductIds: string[];
  comments: CommunityCommentItem[];
  createdAt: string;
  location?: string;
}

// ==========================================
// RESELLER WALLET & MARGIN EARNINGS
// ==========================================
export interface ResellerEarningRecord {
  id: string;
  orderNumber: string;
  productName: string;
  wholesalePrice: number;
  sellingPrice: number;
  marginEarned: number;
  customerName: string;
  status: 'Credited' | 'Pending Dispatch' | 'Withdrawn';
  date: string;
}

// ==========================================
// UPI PAYMENT APPS & PIN SECURITY
// ==========================================
export type UPIAppType = 'paytm' | 'phonepe' | 'gpay' | 'bhim' | 'cred' | 'amazonpay' | 'custom';

export interface CustomerUPIProfile {
  vpa: string;
  bankName: string;
  accountNumberMask: string;
  linkedApp: UPIAppType;
  isDefault: boolean;
  hasPinSet: boolean;
  pinLength: 4 | 6;
  dailyLimit: number;
}

export interface SellerUPIProfile {
  sellerId: string;
  vpa: string;
  merchantName: string;
  bankName: string;
  accountNumberMask: string;
  ifsc: string;
  linkedApp: UPIAppType;
  autoSettle: boolean;
  instantPayoutEnabled: boolean;
  qrCodeUrl?: string;
}

export interface DriverUPIProfile {
  driverId: string;
  vpa: string;
  riderName: string;
  bankName: string;
  accountNumberMask: string;
  phoneLinked: string;
  linkedApp: UPIAppType;
  instantSweepEnabled: boolean;
  isVerified: boolean;
}

export interface UPIPinModalConfig {
  isOpen: boolean;
  amount: number;
  payeeName: string;
  payeeVpa: string;
  upiApp: UPIAppType;
  bankName: string;
  accountMask: string;
  onSuccess: (utr: string) => void;
  onCancel?: () => void;
}

// ==========================================
// INSTAGRAM-STYLE BLOCK RECORDS
// ==========================================
export interface InstagramBlockRecord {
  id: string;
  blockerRole: 'customer' | 'seller';
  blockerId: string;
  blockedType: 'user' | 'seller';
  blockedId: string;
  blockedName: string;
  blockedAvatar?: string;
  blockedHandle?: string;
  blockedRole?: string;
  reason?: string;
  timestamp: string;
}

// ==========================================
// USER INTEREST, NON-INTEREST & NEARBY ENGINE
// ==========================================
export type NotInterestedReason =
  | 'already_bought'
  | 'dont_like_style'
  | 'price_too_high'
  | 'not_relevant'
  | 'dont_show_brand'
  | 'seen_too_much'
  | 'poor_reviews'
  | 'other';

export interface NotInterestedRecord {
  productId: string;
  productName: string;
  brand: string;
  category: string;
  reason: NotInterestedReason;
  reasonText: string;
  timestamp: string;
}

export interface UserInterestProfile {
  interestedProductIds: string[];
  notInterestedRecords: Record<string, NotInterestedRecord>;
  categoryAffinities: Record<string, number>; // Category name -> 0 to 100 affinity score
  brandAffinities: Record<string, number>; // Brand name -> 0 to 100 affinity score
  activeInterestTags: string[];
  userCity: string;
  userPincode: string;
  maxDistanceRadiusKm: number;
  shoppingVibe: 'all' | 'festive' | 'daily' | 'luxury' | 'budget';
  lastUpdated: string;
}

export interface NearbyProductMatch {
  product: Product;
  seller: SellerProfile;
  distanceKm: number;
  etaMinutes: number;
  deliveryType: 'Express 30-Min' | 'Same Day' | 'Next Day';
  stockCount: number;
}

// ==========================================
// FAVORITES & SAVED PRODUCTS SYSTEM (INSTAGRAM + SNAPCHAT + WISHLIST)
// ==========================================
export type CollectionPrivacy = 'private' | 'followers' | 'public' | 'collaborative';

export interface CollectionCollaborator {
  id: string;
  name: string;
  avatar: string;
  role: 'owner' | 'editor' | 'viewer';
}

export interface CollectionItemReaction {
  likes: number;
  loves: number;
  fires: number;
  userReactions: ('like' | 'love' | 'fire')[];
}

export interface CollectionItemComment {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  text: string;
  time: string;
}

export interface ProductCollection {
  id: string;
  name: string;
  emoji: string;
  description?: string;
  coverImage?: string;
  itemProductIds: string[];
  itemPostIds?: string[];
  privacy: CollectionPrivacy;
  collaborators?: CollectionCollaborator[];
  itemReactions?: Record<string, CollectionItemReaction>;
  itemComments?: Record<string, CollectionItemComment[]>;
  isCreatorPick?: boolean;
  creatorInfo?: {
    name: string;
    handle: string;
    avatar: string;
    badge?: string;
    followersCount?: string;
  };
  createdAt: string;
  updatedAt: string;
}

export interface WishlistItemDetails {
  productId: string;
  addedAt: string;
  originalPrice: number;
  currentPrice: number;
  priceDropAlertEnabled: boolean;
  smartState: 'price_dropped' | 'back_in_stock' | 'almost_sold_out' | 'recently_added' | 'normal';
  stockCount: number;
  savedAmount?: number;
  notes?: string;
}

export interface SmartCategorySuggestion {
  categoryName: string;
  count: number;
  productIds: string[];
  suggestedCover: string;
  suggestedEmoji: string;
}

export interface FlyingSaveAnimationState {
  isActive: boolean;
  imageUrl: string;
  productName: string;
  startX?: number;
  startY?: number;
}

export interface SmartSaveBottomSheetState {
  isOpen: boolean;
  productId: string | null;
  product: Product | null;
}

// ==========================================
// CAMERA CREATION STUDIO SYSTEM (SNAPCHAT + INSTAGRAM + WHATSAPP + SOCIAL-COMMERCE)
// ==========================================
export type CameraMode =
  | 'photo'
  | 'video'
  | 'lens'
  | 'product'
  | 'story'
  | 'reel'
  | 'seller'
  | 'chat';

export type CameraFlashMode = 'off' | 'on' | 'auto' | 'torch';
export type CameraFacing = 'user' | 'environment';
export type CameraAspectRatio = '9:16' | '1:1' | '4:5' | '16:9';

export interface CameraLens {
  id: string;
  name: string;
  emoji: string;
  category: 'ar_face' | 'glamour' | 'cyber' | 'vibe' | 'studio' | 'commerce' | 'retro';
  filterCss?: string;
  overlayType?: 'neon_glasses' | 'gold_sparkles' | 'halo_crown' | 'cyber_visor' | 'beauty_glow' | 'vhs_glitch' | 'bokeh_luxury' | 'studio_pedestal' | 'product_halo';
  soundName?: string;
  skinSmoothLevel?: number;
  description: string;
}

export interface CameraProductTag {
  id: string;
  productId: string;
  productName: string;
  price: number;
  mrp?: number;
  discountPercent?: number;
  image: string;
  x: number; // percentage 0-100
  y: number; // percentage 0-100
  style: 'pill' | 'badge' | 'card' | 'minimal';
  colorHex?: string;
}

export interface CameraTextOverlay {
  id: string;
  text: string;
  fontStyle: 'modern' | 'serif' | 'cyber' | 'script' | 'typewriter';
  color: string;
  bgColor?: string;
  x: number;
  y: number;
  scale?: number;
}

export interface CameraSticker {
  id: string;
  type: 'emoji' | 'badge' | 'poll' | 'question' | 'location' | 'sale_banner' | 'countdown';
  content: string;
  x: number;
  y: number;
  scale?: number;
  pollData?: {
    question: string;
    optionA: string;
    optionB: string;
    votesA?: number;
    votesB?: number;
  };
  countdownData?: {
    title: string;
    endMinutes: number;
  };
}

export interface CameraDrawingPoint {
  x: number;
  y: number;
}

export interface CameraDrawingPath {
  id: string;
  points: CameraDrawingPoint[];
  color: string;
  brushType: 'pen' | 'neon' | 'highlighter' | 'eraser';
  strokeWidth: number;
}

export interface CameraMusicTrack {
  id: string;
  title: string;
  artist: string;
  genre: string;
  duration: number; // seconds
  coverArt: string;
  previewUrl: string;
  bpm?: number;
}

export interface CameraCapturedMedia {
  id: string;
  type: 'photo' | 'video';
  mediaUrl: string;
  thumbnailUrl?: string;
  aspectRatio: CameraAspectRatio;
  durationSeconds?: number;
  mode: CameraMode;
  createdAt: string;
  caption?: string;
  hashtags?: string[];
  productTags: CameraProductTag[];
  textOverlays: CameraTextOverlay[];
  stickers: CameraSticker[];
  drawingPaths: CameraDrawingPath[];
  filterCss?: string;
  filterName?: string;
  lensId?: string;
  musicTrack?: CameraMusicTrack;
  ctaText?: string;
  ctaType?: 'buy_now' | 'add_to_cart' | 'view_pdp' | 'chat_seller' | 'shop_collection';
  privacy: 'public' | 'followers' | 'close_friends' | 'chat_direct' | 'view_once' | 'disappearing';
  viewOnce?: boolean;
  disappearingTimerHours?: number; // 0, 24, 168 (7 days)
  sellerStudioDetails?: {
    brandName?: string;
    brandLogo?: string;
    promoCode?: string;
    discountHighlight?: string;
    whiteBackgroundApplied?: boolean;
  };
  isDraft?: boolean;
  isSavedGallery?: boolean;
}

export interface CameraFilterPreset {
  id: string;
  name: string;
  css: string;
  thumbnailColor: string;
}

// ==========================================
// SUPER COIN + DIAMOND ECONOMY SYSTEM
// ==========================================

export type LoyaltyTierLevel = 'Bronze' | 'Silver' | 'Gold' | 'Platinum' | 'Diamond';

export interface LoyaltyTierInfo {
  tier: LoyaltyTierLevel;
  currentCoinsLifetime: number;
  coinsNeededForNextTier: number;
  nextTier: LoyaltyTierLevel | null;
  coinsMultiplier: number; // e.g. 1.0x, 1.25x, 1.5x, 2.0x, 2.5x
  perks: {
    title: string;
    description: string;
    icon: string;
    isUnlocked: boolean;
  }[];
  earlyAccessHours: number;
  freeExpressDelivery: boolean;
  birthdayBonusCoins: number;
  vipSupport: boolean;
}

export interface SuperCoinWalletState {
  availableBalance: number;
  pendingCoins: number;
  expiringCoins: number;
  expiryDate: string;
  lifetimeEarned: number;
  lifetimeRedeemed: number;
  todayEarnings: number;
  dailyGoalTarget: number;
  dailyGoalCurrent: number;
  conversionRateRupeesPerCoin: number; // e.g. 1.0 (1 Coin = ₹1)
  maxRedemptionPercentPerOrder: number; // e.g. 50 (50% max of cart total)
}

export interface DiamondWalletState {
  balance: number;
  lifetimeEarned: number;
  lifetimeSpent: number;
  pendingDiamonds: number;
  todayEarnings: number;
  conversionRateRupeesPer100Diamonds: number; // e.g. ₹50 per 100 Diamonds
  totalGMVGenerated: number; // In INR, total creator sales driven
  monthlyEarningsDiamonds: number;
  creatorRank: string; // e.g. "Top 5% Creator Partner"
}

export type RewardMissionCategory = 'check_in' | 'discovery' | 'social' | 'video' | 'review' | 'shopping' | 'referral';
export type RewardMissionCurrency = 'super_coins' | 'diamonds' | 'both';

export interface RewardMissionItem {
  id: string;
  title: string;
  description: string;
  category: RewardMissionCategory;
  currency: RewardMissionCurrency;
  rewardCoins: number;
  rewardDiamonds: number;
  progress: number;
  maxProgress: number;
  isCompleted: boolean;
  isClaimed: boolean;
  icon: string;
  ctaLabel: string;
  actionRoute?: string;
  badge?: string;
  expiresInHours?: number;
}

export interface FlashCoinEventItem {
  id: string;
  title: string;
  subtitle: string;
  multiplier: string; // "10X", "3X", "Double"
  categoryTag: string; // "Fashion", "Handlooms", "Midnight Drop"
  bonusCoinsPerPurchase: number;
  endsAt: string; // ISO or relative
  remainingMinutes: number;
  totalPoolBudget: number;
  claimedPercent: number;
  bgGradient: string;
  isLive: boolean;
}

export interface ReferralFriendRecord {
  id: string;
  friendName: string;
  friendPhone: string;
  joinedDate: string;
  status: 'Registered' | 'First Order Placed' | 'Completed';
  superCoinsEarned: number;
  diamondsEarned: number;
}

export interface ReferralEconomyData {
  referralCode: string;
  referralLink: string;
  totalInvited: number;
  successfulReferrals: number;
  totalCoinsEarned: number;
  totalDiamondsEarned: number;
  pendingCoins: number;
  currentMilestoneIndex: number;
  milestones: {
    friendsCount: number;
    coinsReward: number;
    diamondsReward: number;
    specialBonus?: string;
    isUnlocked: boolean;
  }[];
  friendsList: ReferralFriendRecord[];
}

export interface CreatorProductStat {
  productId: string;
  productName: string;
  productImage: string;
  productPrice: number;
  salesCount: number;
  gmvDriven: number;
  diamondsEarned: number;
  conversionRatePercent: number;
}

export interface CreatorDiamondStats {
  creatorId: string;
  creatorName: string;
  handle: string;
  verifiedBadge: boolean;
  totalGMVDriven: number;
  totalDiamondsEarned: number;
  currentBalance: number;
  affiliateCommissionPercent: number;
  topProducts: CreatorProductStat[];
  monthlyBreakdown: {
    month: string;
    gmv: number;
    diamonds: number;
    postsCount: number;
  }[];
  payoutHistory: {
    id: string;
    date: string;
    diamondsRedeemed: number;
    inrAmount: number;
    upiId: string;
    utr: string;
    status: 'Settled' | 'Processing';
  }[];
}

export interface SellerRewardConfig {
  sellerId: string;
  storeName: string;
  coinCashbackPercentage: number; // e.g. 5%
  firstOrderBonusCoins: number; // e.g. 50 coins
  repeatPurchaseMilestoneOrders: number; // e.g. 3 orders
  repeatPurchaseBonusCoins: number; // e.g. 100 coins
  productSpecificBounties: {
    productId: string;
    productName: string;
    extraBonusCoins: number;
    isActive: boolean;
  }[];
  activeCampaignName: string;
  campaignMultiplier: number; // e.g. 2.0x
  isCampaignActive: boolean;
  monthlyRewardBudget: number;
  rewardBudgetUsed: number;
}

export interface UnifiedRewardTransaction {
  id: string;
  date: string;
  activityTitle: string;
  activityType: 'purchase_earn' | 'checkout_redeem' | 'daily_checkin' | 'mission_reward' | 'creator_affiliate' | 'referral_bonus' | 'review_reward' | 'seller_loyalty' | 'admin_adjustment' | 'diamond_payout';
  currency: 'super_coins' | 'diamonds';
  direction: 'credit' | 'debit';
  amount: number;
  status: 'Completed' | 'Pending' | 'Reversed' | 'Expired';
  orderNumber?: string;
  sellerName?: string;
  notes?: string;
  expiryDate?: string;
}

export interface FraudRiskRule {
  id: string;
  ruleName: string;
  description: string;
  limitValue: number;
  timeWindow: 'daily' | 'hourly' | 'per_account';
  severity: 'low' | 'medium' | 'high' | 'critical';
  isEnabled: boolean;
}

export interface FraudAuditRecord {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  activity: string;
  riskScore: number; // 0 to 100
  reason: string;
  actionTaken: 'Flagged' | 'Auto_Blocked' | 'Reward_Held' | 'Approved';
  currencyImpacted: 'super_coins' | 'diamonds';
  amount: number;
  isReversed: boolean;
}

export interface CurrencyEconomyConfig {
  superCoinValueInINR: number; // 1.0
  maxSuperCoinsRedemptionPercent: number; // 50%
  baseCoinsPer100RupeesSpent: number; // 4
  defaultCoinExpiryDays: number; // 180
  diamondValueInINRPer100: number; // 50
  creatorAffiliateDiamondPercent: number; // 10%
  dailyMissionMaxCoinsCap: number; // 250
  antiFraudVelocityMaxDailyCoins: number; // 1000
}

// ==========================================
// TIME-SHIFT 3D STORY CAMERA & 2-HOUR LIVING STORIES
// ==========================================
export type StoryLifetimeDuration =
  | '15m'
  | '30m'
  | '1h'
  | '2h' // Signature 2-Hour Mode
  | '4h'
  | '6h'
  | '12h'
  | '24h';

export type StoryCameraCaptureMode =
  | 'real'
  | 'depth'
  | 'world'
  | 'cinematic'
  | 'motion'
  | 'auto';

export type StoryPhaseType =
  | 'reveal'       // 0 - 30 min
  | 'interaction'  // 30 - 60 min
  | 'community'    // 60 - 90 min
  | 'final_call';  // 90 - 120 min

export type StoryMood =
  | 'Happy'
  | 'Exciting'
  | 'Luxury'
  | 'Calm'
  | 'Energetic'
  | 'Emotional'
  | 'Urgent'
  | 'Cool';

export interface InteractiveStoryObject {
  id: string;
  label: string;
  category: 'product' | 'seller' | 'person' | 'location' | 'secret_offer' | 'custom_action';
  productId?: string;
  productDetails?: {
    name: string;
    price: number;
    mrp?: number;
    discountPercent?: number;
    image: string;
    inStock: boolean;
    deliveryEta: string;
    sellerName: string;
  };
  sellerId?: string;
  sellerName?: string;
  sellerRating?: number;
  personHandle?: string;
  personName?: string;
  personAvatar?: string;
  locationName?: string;
  locationDistanceMeters?: number;
  secretReward?: {
    title: string;
    promoCode: string;
    discountPercent: number;
    badgeName: string;
    claimed: boolean;
  };
  x: number; // 0-100 percentage
  y: number; // 0-100 percentage
  depthZ?: number; // -10 to +10 for 3D parallax
  spatialSurface?: 'table' | 'wall' | 'floor' | 'floating';
  actionType?: 'buy_now' | 'view_product' | 'view_store' | 'view_profile' | 'reveal_offer' | 'get_directions';
}

export type AISmartTagType =
  | 'person'
  | 'business'
  | 'creator'
  | 'collaborator'
  | 'product'
  | 'store'
  | 'location';

export interface AISmartTagSuggestion {
  id: string;
  type: AISmartTagType;
  targetId: string;
  name: string;
  handle?: string;
  avatar?: string;
  confidence: 'high' | 'medium' | 'low';
  reasonWhy: string; // e.g. "Appears in your Story", "Product detected in catalog", "Collaborator"
  isTagged: boolean;
  privacyStatus?: 'allowed' | 'requires_approval' | 'opted_out';
}

export type StoryReactionType =
  | 'heart'
  | 'fire'
  | 'sparkle'
  | 'clap'
  | 'mindblown'
  | 'hundred'
  | 'diamond'
  | 'wow'
  | 'rocket'
  | 'want'
  | 'laugh';

export type StoryVisualFilter =
  | 'none'
  | 'cyberpunk_neon'
  | 'golden_hour'
  | 'vintage_35mm'
  | 'hologram_mesh'
  | 'dreamy_soft'
  | 'noir_monochrome'
  | 'nordic_clean';

export type StoryAudienceScope =
  | 'public_radar'
  | 'inner_syndicate'
  | 'community_sprint'
  | 'zk_ghost_anon';

export interface StorySoundtrack {
  id: string;
  title: string;
  artist: string;
  genre: string;
  durationFormatted: string;
  energyLevel: 'high' | 'chill' | 'focus' | 'ambient';
  audioWaveform?: number[];
  coverGradient: string;
}

export interface StoryCountdownSticker {
  id: string;
  title: string;
  targetMinutes: number;
  badgeTheme: 'cyan' | 'purple' | 'amber' | 'emerald' | 'rose';
  x: number;
  y: number;
  depthZ?: number;
}

export interface StoryBountySticker {
  id: string;
  questTitle: string;
  tokenReward: number;
  tokenSymbol: string;
  claimLimit: number;
  claimedCount: number;
  x: number;
  y: number;
  depthZ?: number;
}

export interface StorySpatialTextSticker {
  id: string;
  text: string;
  fontStyle: 'cyber_mono' | 'editorial_serif' | 'neon_glow' | 'bold_marker';
  color: string;
  x: number;
  y: number;
  depthZ: number;
  scale?: number;
}

export interface StoryPollOption {
  id: string; // 'opt-a' | 'opt-b'
  text: string;
  votes: number;
  voterNames?: string[];
}

export interface StoryPollSticker {
  id: string;
  question: string;
  optionA: StoryPollOption;
  optionB: StoryPollOption;
  x: number; // 0-100 percentage
  y: number; // 0-100 percentage
  depthZ?: number; // -10 to +10 for 3D parallax
  totalVotes: number;
  userVotedOptionId?: string; // 'opt-a' | 'opt-b'
  themeColor?: 'cyan' | 'purple' | 'amber' | 'emerald' | 'rose' | 'slate';
  createdAt?: string;
}

export interface StoryMomentReaction {
  timestampSecond: number;
  reactionType: StoryReactionType;
  count: number;
}

export interface MultiPersonContribution {
  id: string;
  name: string;
  role: 'Creator' | 'Seller' | 'Shopper' | 'Driver';
  avatar: string;
  mediaUrl: string;
  caption: string;
  time: string;
}

export interface TimeShiftStoryItem {
  id: string;
  storyDna: string; // e.g. "MOMENT-8F42"
  authorId: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  authorRole: 'creator' | 'seller' | 'customer' | 'driver';
  isVerified: boolean;
  captureMode: StoryCameraCaptureMode;
  mediaUrl: string;
  depthMapUrl?: string;
  parallaxStrength?: number;
  mediaType: 'photo' | 'video';
  durationSeconds: number;
  lifetimeDuration: StoryLifetimeDuration;
  publishedAt: string; // ISO string
  expiresAt: string; // ISO string
  totalLifetimeSeconds: number;
  remainingSeconds: number;
  currentPhase: StoryPhaseType;
  mood: StoryMood;
  caption?: string;
  interactiveObjects: InteractiveStoryObject[];
  pollSticker?: StoryPollSticker;
  countdownSticker?: StoryCountdownSticker;
  bountySticker?: StoryBountySticker;
  spatialTextStickers?: StorySpatialTextSticker[];
  visualFilter?: StoryVisualFilter;
  soundtrack?: StorySoundtrack;
  audienceScope?: StoryAudienceScope;
  remixPermission?: 'open_to_all' | 'community_only' | 'disabled';
  ephemeralGhostMode?: boolean;
  aiTags: AISmartTagSuggestion[];
  location?: {
    name: string;
    lat: number;
    lng: number;
    radiusKm: number;
    distanceMeters?: number;
  };
  multiContributors?: MultiPersonContribution[];
  deliveryProgress?: {
    currentStep: 'order_received' | 'preparing' | 'ready' | 'driver_assigned' | 'picked_up' | 'driver_nearby' | 'delivered';
    driverName: string;
    etaMinutes: number;
  };
  secretLayerUnlockedCount: number;
  livePulse: {
    currentViewers: number;
    reactionsCount: number;
    productClicks: number;
    isTrendingNearby: boolean;
  };
  momentReactions: StoryMomentReaction[];
  status: 'active' | 'ending_soon' | 'expired';
  // Interconnected LifeOS Social & Community Fields
  communityId?: string;
  communityName?: string;
  communityType?: 'goal_community' | 'temporary_community' | 'world' | 'local_circle';
  communityBadgeColor?: string;
  milestoneTag?: string;
  isPersonalStory?: boolean;
  isProfileStory?: boolean;
  viewedByUsers?: { id: string; name: string; avatar: string; viewedAt: string }[];
  analytics?: {
    totalViews: number;
    uniqueViewers: number;
    completionRate: number;
    averageWatchSeconds: number;
    productClicks: number;
    buyClicks: number;
    conversionsCount: number;
    peakPhase: string;
    bestMomentSecond: number;
  };
}

export interface StoryExpirationEventReport {
  storyId: string;
  storyDna: string;
  title: string;
  publishedAt: string;
  endedAt: string;
  totalViews: number;
  uniqueViewers: number;
  interactionsCount: number;
  productClicks: number;
  buyClicks: number;
  conversions: number;
  sharesCount: number;
  peakEngagementPhase: string;
  topReactionType: string;
  locationReach: string;
}

// ==========================================
// NEXT-GENERATION AI SOCIAL NETWORK TYPES
// ==========================================

export type SocialAccountPersona = 'personal' | 'creator' | 'business' | 'professional' | 'community' | 'creative' | 'casual' | 'anonymous';

export type UserIntentType =
  | 'explore'
  | 'learn'
  | 'buy'
  | 'sell'
  | 'meet'
  | 'connect'
  | 'collaborate'
  | 'hire'
  | 'find_help'
  | 'find_people'
  | 'find_products'
  | 'find_businesses'
  | 'discover_nearby'
  | 'talk'
  | 'create';

export type SocialFeedMode =
  | 'explore'
  | 'people'
  | 'nearby'
  | 'commerce'
  | 'learn'
  | 'collaborate'
  | 'opportunities'
  | 'personalized'
  | 'intent_matched'
  | 'anonymous';

export type UserCurrentState =
  | 'Building'
  | 'Learning'
  | 'Looking for collaborators'
  | 'Looking for customers'
  | 'Looking for opportunities'
  | 'Exploring'
  | 'Available'
  | 'Busy'
  | 'Mentoring';

export type LocationVisibilityMode = 'exact' | 'approximate' | 'neighborhood' | 'city' | 'hidden';

export type SocialVerificationType =
  | 'identity_verified'
  | 'business_verified'
  | 'skill_verified'
  | 'transaction_verified'
  | 'experience_verified'
  | 'creator_verified';

export type ContentProvenanceType =
  | 'human_created'
  | 'ai_assisted'
  | 'ai_generated'
  | 'verified_purchase'
  | 'verified_experience'
  | 'verified_business';

export type ContextReactionType =
  | 'relate'
  | 'understand'
  | 'agree'
  | 'disagree'
  | 'needThis'
  | 'interested'
  | 'helpedMe'
  | 'discuss'
  | 'experiencingToo';

export type MomentLifetime = '30m' | '1h' | '2h' | '6h' | '12h' | '24h' | 'permanent';

export type MomentPurpose =
  | 'I am here'
  | 'Need help'
  | 'Selling'
  | 'Looking for people'
  | 'Looking for collaboration'
  | 'Join me'
  | 'Event'
  | 'Announcement'
  | 'Question';

export interface PersonaDetails {
  headline: string;
  bio: string;
  tags: string[];
  publicMetrics: string;
  avatar?: string;
}

export interface ProofOfExperienceReputation {
  overallScore: number; // 0 - 100
  trust: number;
  expertise: number;
  commerce: number;
  collaboration: number;
  community: number;
  verifiedTransactions: number;
  successfulCollaborations: number;
  verifiedSkillsCount: number;
  helpfulContributions: number;
  customerSatisfactionPct: number;
}

export interface LivingUserProfile {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  activePersona: SocialAccountPersona;
  currentIntent: UserIntentType;
  currentState: UserCurrentState;
  skills: string[];
  currentGoals: string[];
  lookingFor: string[];
  location: {
    city: string;
    neighborhood: string;
    distanceKm?: number;
    visibility: LocationVisibilityMode;
    lat?: number;
    lng?: number;
  };
  reputation: ProofOfExperienceReputation;
  verifications: SocialVerificationType[];
  personas: {
    personal: PersonaDetails;
    professional: PersonaDetails;
    creator: PersonaDetails;
    business: PersonaDetails;
    community: PersonaDetails;
  };
  relationshipSignals?: {
    isFollowing: boolean;
    isFriend: boolean;
    hasCollaborated: boolean;
    hasTransacted: boolean;
    sharedCommunitiesCount: number;
    sharedInterests: string[];
  };
}

export interface CollaborativeContribution {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  type: 'idea' | 'solution' | 'photo' | 'design' | 'product' | 'resource' | 'experience';
  content: string;
  mediaUrl?: string;
  createdAt: string;
  upvotes: number;
  hasUpvoted?: boolean;
}

export interface CommunityConsensusItem {
  topic: string;
  summary: string;
  breakdown: {
    label: string;
    recommendation: string;
    votes: number;
    confidencePct: number;
  }[];
}

export interface SocialCommerceAttachedProduct {
  id: string;
  title: string;
  price: number;
  originalPrice?: number;
  currency: string;
  image: string;
  category: string;
  sellerId: string;
  sellerName: string;
  inStock: boolean;
  rating: number;
  variants?: string[];
  deliveryEstimate?: string;
}

export interface NextGenSocialPost {
  id: string;
  author: LivingUserProfile;
  createdAt: string;
  content: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video' | '3d_moment';
  intentTag: UserIntentType;
  provenance: ContentProvenanceType;
  isCollaborative: boolean;
  collaborativeContributions: CollaborativeContribution[];
  contextReactions: {
    relate: number;
    understand: number;
    agree: number;
    disagree: number;
    needThis: number;
    interested: number;
    helpedMe: number;
    discuss: number;
    experiencingToo: number;
  };
  userReaction?: ContextReactionType;
  communityConsensus?: CommunityConsensusItem;
  commerceProduct?: SocialCommerceAttachedProduct;
  isAnonymous?: boolean;
  anonymousAlias?: string;
  identityRevealState?: 'none' | 'requested' | 'revealed';
  translation?: {
    originalLanguage: string;
    translatedContent: string;
    isShowingOriginal: boolean;
  };
}

export interface NextGenMomentItem {
  id: string;
  author: LivingUserProfile;
  purpose: MomentPurpose;
  headline: string;
  content: string;
  mediaUrl?: string;
  lifetime: MomentLifetime;
  expiresAt: string;
  remainingMinutes: number;
  locationName: string;
  distanceKm: number;
  participantsCount: number;
  intentMatches: string[];
  isNearby: boolean;
  tags: string[];
}

export interface PersonRecommendationItem {
  id?: string;
  name?: string;
  handle?: string;
  avatar?: string;
  headline?: string;
  location?: string;
  compatibilityScore?: number;
  commonGoals?: string[];
  proofBadges?: string[];
  reason?: string;
  profile?: LivingUserProfile;
  whyExplanation?: string[];
  mutualConnection?: {
    id: string;
    name: string;
    avatar: string;
    relation: string;
  };
  opportunityType?: 'collaboration' | 'mentorship' | 'commerce' | 'hire' | 'startup' | 'local_interest';
  status?: 'pending' | 'connected' | 'introduced' | 'hidden';
}

export interface TemporaryCommunityItem {
  id: string;
  name: string;
  tagline: string;
  icon: string;
  category: string;
  lifetime: '30m' | '2h' | '1d' | '1w' | 'permanent';
  expiresAt?: string;
  membersCount: number;
  activeDiscussionsCount: number;
  locationContext?: string;
  purpose: string;
  isJoined?: boolean;
}

export interface SocialMissionItem {
  id: string;
  title: string;
  description: string;
  rewardPoints: number;
  category: 'connection' | 'learning' | 'commerce' | 'collaboration' | 'local';
  progress: number; // 0 - 100
  targetRequirement: string;
  matchedProfiles?: LivingUserProfile[];
  status: 'available' | 'in_progress' | 'completed';
}

export interface AIOpportunityMatch {
  id: string;
  title: string;
  pitch: string;
  rolesNeeded: { role: string; filledBy?: LivingUserProfile; matchedSkills: string[] }[];
  matchScore: number;
  industry: string;
  canJoinRoom: boolean;
}

export interface AISocialTwinMemoryRecord {
  id: string;
  category: 'interest' | 'skill' | 'goal' | 'shopping' | 'collaboration' | 'location';
  title: string;
  details: string;
  source: string;
  permitted: boolean;
  learnedAt: string;
}

export interface AISocialConversationMemory {
  id: string;
  query: string;
  answer: string;
  sourceContext: string;
  timestamp: string;
}

export interface SpecializedAIAgent {
  id: string;
  name: string;
  avatar: string;
  type: 'shopping' | 'travel' | 'learning' | 'business' | 'creator' | 'local';
  description: string;
  capabilities: string[];
  isActive: boolean;
  interactionCount: number;
}

export interface UserAttentionBudget {
  learningMinutes: number;
  opportunitiesMinutes: number;
  localMinutes: number;
  creatorsMinutes: number;
  commerceMinutes: number;
  showVerifiedOnly: boolean;
}

// ==========================================
// LIFEOS: THE SOCIAL OPERATING SYSTEM TYPES
// ==========================================

export type LifeIntentCategory =
  | 'doing'
  | 'feeling'
  | 'looking_for'
  | 'learning'
  | 'building'
  | 'planning'
  | 'experiencing'
  | 'offering'
  | 'needing'
  | 'interested_in';

export type LifePrivacyScope = 'private' | 'friends' | 'community' | 'nearby' | 'public';

export interface LifeIntent {
  id: string;
  category: LifeIntentCategory;
  title: string;
  description: string;
  keywords: string[];
  createdAt: string;
  expiresAt?: string;
  privacy: LifePrivacyScope;
  status: 'active' | 'fulfilled' | 'paused';
  locationContext?: string;
  matchedConnectionsCount: number;
  urgency: 'immediate' | 'this_week' | 'long_term';
  aiSuggestedMatchSummary?: string;
}

export type SocialWorldType = 'travel' | 'startup' | 'event' | 'project' | 'learning' | 'community' | 'lifestyle';

export interface SocialWorld {
  id: string;
  title: string;
  type: SocialWorldType;
  subtitle: string;
  description: string;
  bannerImage: string;
  locationZone: string;
  privacy: 'public' | 'invite_only' | 'private' | 'location_based';
  status: 'active' | 'archived_memory' | 'ephemeral';
  remainingDuration?: string;
  participantsCount: number;
  activeIntents: string[];
  tags: string[];
  isJoined?: boolean;
  memberList: {
    id: string;
    name: string;
    avatar: string;
    role: string;
    headline: string;
    intentMatch?: string;
  }[];
  activities: {
    id: string;
    user: string;
    avatar: string;
    text: string;
    time: string;
    intentType?: string;
  }[];
  resources: {
    title: string;
    link: string;
    type: 'doc' | 'github' | 'event' | 'guide';
  }[];
}

export type SynchronicityType =
  | 'startup_co_creation'
  | 'travel_companionship'
  | 'skill_barter'
  | 'mentorship'
  | 'local_collaboration'
  | 'business_synergy';

export interface SocialSynchronicity {
  id: string;
  title: string;
  matchType: SynchronicityType;
  compatibilityScore: number;
  rationale: string;
  participants: {
    id: string;
    name: string;
    avatar: string;
    role: string;
    intent: string;
    verifiedProof: string[];
  }[];
  mutualGoals: string[];
  status: 'pending' | 'approved' | 'connected' | 'declined';
  discoveredAt: string;
  suggestedIcebreaker: string;
}

export type DiscoveryCategory = 'people' | 'knowledge' | 'business' | 'opportunity' | 'place';

export interface UniversalDiscoveryItem {
  id: string;
  entityType: DiscoveryCategory;
  title: string;
  subtitle: string;
  description: string;
  image: string;
  tags: string[];
  locationZone: string;
  matchRelevancePercent: number;
  verifiedBadge: string;
  intentAlignment: string;
  distanceKm?: number;
  actionLabel: string;
  meta: {
    price?: number;
    rating?: number;
    skills?: string[];
    author?: string;
    followersCount?: number;
    deadline?: string;
    language?: string;
  };
}

export interface LifeMemoryItem {
  id: string;
  title: string;
  category: 'startup_journey' | 'trip' | 'project' | 'achievement' | 'people_met' | 'moment';
  date: string;
  description: string;
  photos: string[];
  peopleInvolved: { name: string; avatar: string; role?: string }[];
  location: string;
  isPrivate: boolean;
  aiSummary: string;
  tags: string[];
}

export interface LifeMapZoneNode {
  id: string;
  title: string;
  type: 'world' | 'event' | 'cluster' | 'business' | 'opportunity' | 'creator';
  xPercent: number;
  yPercent: number;
  privacyZone: 'nearby' | 'district' | 'city' | 'event';
  participantsCount: number;
  tags: string[];
  distanceKm: number;
  description: string;
  iconType: string;
}

export interface RelationshipGraphNode {
  id: string;
  label: string;
  type: 'person' | 'community' | 'business' | 'event' | 'knowledge' | 'opportunity' | 'place';
  avatar?: string;
  strength: number;
  connections: string[];
  mutualIntents: string[];
  category: string;
}

export interface AISocialTwinConfig {
  isEnabled: boolean;
  autoDiscoverOpportunities: boolean;
  autonomousNegotiation?: boolean;
  permissions: {
    canShareInterests: boolean;
    canShareSkills: boolean;
    canShareGoals: boolean;
    canShareAvailability: boolean;
    canShareCurrentIntentions: boolean;
    canShareLocationZone: boolean;
  };
  permissionInterests?: boolean;
  permissionSkills?: boolean;
  permissionGoals?: boolean;
  permissionAvailability?: boolean;
  permissionCurrentIntentions?: boolean;
  permissionLocationZone?: boolean;
  maxDailyIntroductions: number;
  autonomousAgentList: {
    id: string;
    name: string;
    role: string;
    isActive: boolean;
    description: string;
  }[];
}

export interface ExperiencePostItem {
  id: string;
  author: {
    id: string;
    name: string;
    avatar: string;
    handle: string;
    verifiedProof: string[];
  };
  contentType: 'moment' | 'experience' | 'goal' | 'question' | 'request' | 'offer' | 'project' | 'collaboration';
  intent: {
    category: LifeIntentCategory;
    statement: string;
  };
  title?: string;
  content: string;
  mediaUrl?: string;
  tags: string[];
  timestamp: string;
  isCollaborativeBranchable: boolean;
  branchesCount: number;
  reactions: {
    relate: number;
    understand: number;
    collaborate: number;
    insightful: number;
  };
  userReaction?: string;
  aiMatchedPeersCount: number;
  locationZone?: string;
}

// ==========================================
// EXPANDED LIFEOS 28-PILLAR ARCHITECTURE TYPES
// ==========================================

export type LifeOSTab =
  | 'my_world'
  | 'feed'
  | 'planner'
  | 'stories'
  | 'journal'
  | 'goals'
  | 'radar'
  | 'future_you'
  | 'bio_energy'
  | 'quantum_decision'
  | 'agent_swarm'
  | 'intents'
  | 'opportunity_exchange'
  | 'skill_graph'
  | 'goal_communities'
  | 'worlds'
  | 'moments'
  | 'synchronicity'
  | 'discovery'
  | 'map'
  | 'growth_graph'
  | 'memory';

export interface LifeRadarOpportunity {
  id: string;
  category:
    | 'co_founder'
    | 'developer'
    | 'designer'
    | 'investor'
    | 'mentor'
    | 'customer'
    | 'community'
    | 'event'
    | 'resource'
    | 'business';
  title: string;
  name?: string;
  avatar?: string;
  role?: string;
  matchScore: number;
  purposeCompatibility: {
    purpose: string;
    score: number;
    rationale: string;
  };
  whyItMatters: string;
  signalsMatched: string[];
  locationZone: string;
  actionType: 'connect' | 'request_intro' | 'attend' | 'visit' | 'apply' | 'collaborate' | 'join';
  actionLabel: string;
  isIgnored?: boolean;
  isRelevant?: boolean;
  status: 'available' | 'requested' | 'connected';
  contributionReputation?: {
    score: number;
    tier: string;
    verifiedProof: string[];
  };
}

export interface FutureYouScenario {
  id: string;
  hypothesis: string;
  horizon: '6_months' | '1_year' | '3_years';
  scenarioTitle: string;
  likelihoodTrajectory: 'High Momentum' | 'Exponential Pivot' | 'Disciplined Mastery';
  summary: string;
  potentialSkills: string[];
  possibleCommunities: string[];
  potentialOpportunities: string[];
  suggestedPeople: {
    name: string;
    role: string;
    avatar: string;
    reason: string;
  }[];
  possibleProjects: string[];
  recommendedNextSteps: {
    step: string;
    timeline: string;
    impact: string;
  }[];
  disclaimer: string;
}

export interface OpportunityExchangeItem {
  id: string;
  type: 'need' | 'offer';
  category:
    | 'developer'
    | 'designer'
    | 'mentor'
    | 'photographer'
    | 'co_founder'
    | 'tutor'
    | 'business_partner'
    | 'customer'
    | 'consulting'
    | 'investment'
    | 'marketing';
  title: string;
  description: string;
  author: {
    id: string;
    name: string;
    avatar: string;
    headline: string;
    contributionScore: number;
    verifiedBadges: string[];
  };
  skillsTags: string[];
  urgency: 'immediate' | 'this_week' | 'flexible';
  exchangeType: 'mutual_barter' | 'revenue_share' | 'equity' | 'pro_bono' | 'paid_service';
  locationZone: string;
  compatibilityWithUserPercent?: number;
  matchedOfferOrNeedId?: string;
  status: 'active' | 'in_negotiation' | 'fulfilled';
  createdAt: string;
}

export interface SkillGraphNode {
  id: string;
  name: string;
  category: 'engineering' | 'ai_systems' | 'design' | 'product' | 'hardware' | 'creative' | 'business';
  level: 'exploring' | 'practitioner' | 'expert' | 'mentor';
  connections: string[]; // Connected skill IDs (e.g. python -> ml -> computer_vision)
  linkedProjects: {
    id: string;
    title: string;
    role: string;
  }[];
  verifiedMentors: {
    name: string;
    avatar: string;
    company: string;
  }[];
  goalCommunities: string[];
  opportunitiesCount: number;
  isPublic: boolean;
  learningResources: {
    title: string;
    type: 'paper' | 'course' | 'repo' | 'interactive';
    url: string;
  }[];
}

export interface GoalCommunity {
  id: string;
  title: string;
  goalType: 'startup' | 'ai_mastery' | 'fitness_marathon' | 'creative_craft' | 'travel_sojourn' | 'language';
  targetOutcome: string;
  timelineWeeks: number;
  currentSprintWeek: number;
  membersCount: number;
  activeMentorsCount: number;
  isJoined?: boolean;
  milestones: {
    week: number;
    milestone: string;
    isCompleted: boolean;
  }[];
  activeSprintTasks: {
    id: string;
    user: string;
    task: string;
    status: 'in_progress' | 'completed';
  }[];
  mentorHighlights: {
    name: string;
    avatar: string;
    role: string;
  }[];
}

export interface PersonalGrowthNode {
  id: string;
  type?: 'goal' | 'skill' | 'project' | 'experience' | 'achievement' | 'relationship';
  category: 'project_shipped' | 'skill_mastered' | 'relationship_formed' | 'community_led' | string;
  title: string;
  description?: string;
  date: string;
  outcome?: string;
  impactScore?: number;
  skillsGained?: string[];
  peopleInvolved?: string[];
  verifiedByEvidence?: boolean;
  impactMetrics?: string;
  verifiedProof?: string;
  nextHorizonSuggestion?: string;
}

export interface IdeaCollision {
  id: string;
  title?: string;
  description?: string;
  synthesisTitle?: string;
  emergentConcept?: string;
  complementaryValue?: string;
  domainsCollided?: string[];
  viabilityScore?: number;
  optedIn?: boolean;
  contributorProfiles?: {
    name: string;
    avatar: string;
    skill: string;
  }[];
  participants?: {
    id: string;
    name: string;
    avatar: string;
    contributionDomain: string;
    optedIn: boolean;
  }[];
  complementaryStack?: string[];
  emergentHypothesis?: string;
  status?: 'discovered' | 'handshake_pending' | 'incubating' | 'declined';
  discoveredAt?: string;
}

export interface LifeOSMoment {
  id: string;
  locationName?: string;
  venueName?: string;
  venueType?: string;
  city: string;
  timeWindow?: string;
  radiusMeters?: number;
  attendeesCount?: number;
  sharedIntent?: string;
  verifiedAttendees?: {
    name: string;
    avatar: string;
    headline: string;
    intentHere: string;
  }[];
  situationType?:
    | 'airport'
    | 'concert'
    | 'conference'
    | 'college'
    | 'stadium'
    | 'restaurant'
    | 'festival'
    | 'hackathon'
    | 'cafe'
    | 'travel_hub';
  activePeersCount?: number;
  activeDiscussionsCount?: number;
  activeIntentsMatched?: string[];
  remainingDuration?: string;
  isArchived: boolean;
  privacy?: 'nearby_500m' | 'venue_only' | 'public_city';
  suggestedAction?: string;
}

export interface ContributionReputation {
  score?: number;
  totalScore?: number;
  tier: 'Emerging Catalyst' | 'Master Contributor' | 'Founding Architect' | 'Ecosystem Pillar' | string;
  mentorshipHoursGiven?: number;
  knowledgeArtifactsCreated?: number;
  collaborationsShipped?: number;
  communityHelpfulnessRating?: number;
  verifiedBadges?: {
    id: string;
    label: string;
    issuer: string;
    date: string;
  }[];
}

export interface AIPrivacyControlState {
  isAIActive: boolean;
  isContextEngineActive: boolean;
  allowAutonomousTwinNegotiation?: boolean;
  allowTravelSync?: boolean;
  allowAnonymousWorlds?: boolean;
  locationFuzzingRadius?: 'venue_only' | '500m' | '2km' | 'city_level' | string;
  locationFuzzingLevel?: 'exact_venue' | 'nearby_500m' | 'district_2km' | 'city_only';
  personalizationEnabled?: boolean;
  autonomousTwinNegotiation?: boolean;
  externalDataSyncAllowed?: boolean;
  auditLogs?: {
    id: string;
    timestamp: string;
    action: string;
    signalsUsed: string[];
    reasoning: string;
  }[];
  transparencyLogs?: {
    timestamp: string;
    action: string;
    signalsUsed: string[];
    reasoning: string;
  }[];
}

// ==========================================
// 1. BIOENERGY & COGNITIVE FLOW MATRIX
// ==========================================
export interface CognitiveFlowWindow {
  id: string;
  title: string;
  windowType: 'deep_flow' | 'creative_spark' | 'serendipity_networking' | 'strategic_reflection' | 'restorative_recovery';
  startTime: string; // e.g. "09:00"
  endTime: string;   // e.g. "12:00"
  cognitiveLoadCapacity: number; // 0-100
  serendipityReadiness: number; // 0-100
  suggestedAction: string;
  isActiveNow: boolean;
  recommendedSoundscape: string;
  recommendedLifeOSMode: 'flow_shield' | 'open_radar' | 'synthesis_mode' | 'unplugged';
}

export interface BioEnergyProfile {
  currentEnergyScore: number; // 0-100
  focusResonanceState: 'Hyper-Focus Flow' | 'Optimal Creative' | 'Serendipity Receptive' | 'Recovery Wind-down';
  flowShieldActive: boolean;
  circadianPeakHour: string;
  dailyFlowHoursLogged: number;
  heartRateVariabilityState: 'High Resonance (Optimal)' | 'Balanced Dynamic' | 'Elevated Stress';
  cognitiveSurplusRemaining: number; // in hours, e.g. 4.5
  activeSoundscapeId: string;
  isSoundscapePlaying: boolean;
  flowWindows: CognitiveFlowWindow[];
  aiBioRecommendations: {
    id: string;
    category: 'neuro_focus' | 'social_timing' | 'recovery';
    insight: string;
    suggestedAction: string;
    priority: 'high' | 'medium' | 'low';
  }[];
}

// ==========================================
// 2. QUANTUM LIFE DECISION & DESTINY SIMULATOR
// ==========================================
export interface QuantumBranchScenario {
  id: string;
  branchTitle: string;
  horizon: '6_months' | '2_years' | '5_years';
  pathDescription: string;
  probabilityOfFulfillment: number; // 0-100%
  regretMinimizationScore: number; // 0-100
  serendipityMultiplier: number; // e.g. 2.4x
  dimensions: {
    skillMastery: number;      // 0-100
    financialAutonomy: number; // 0-100
    socialCapital: number;     // 0-100
    mentalWellbeing: number;   // 0-100
    creativeFreedom: number;   // 0-100
    globalImpact: number;      // 0-100
  };
  keyMilestones: string[];
  devilsAdvocateCritique: string;
  optimistTrajectory: string;
  recommendedPreRequisites: string[];
}

export interface QuantumLifeDecision {
  id: string;
  title: string;
  coreQuestion: string;
  category: 'career_venture' | 'geography_relocation' | 'creative_calling' | 'relationship_network' | 'deep_learning';
  urgency: 'high_inflection_point' | 'deliberate_planning' | 'vision_horizon';
  createdAt: string;
  userRiskTolerance: number; // 1-10
  capitalRunwayMonths: number;
  geographicFlexibility: 'full_nomad' | 'hybrid_hub' | 'grounded_local';
  branches: QuantumBranchScenario[];
  activeSelectedBranchId?: string;
  aiSynthesisVerdict: string;
}

// ==========================================
// 3. AUTONOMOUS LIFE AGENT SYNDICATE & SWARM
// ==========================================
export interface AgentTaskExecution {
  id: string;
  timestamp: string;
  agentId: string;
  agentName: string;
  actionTitle: string;
  description: string;
  status: 'executed' | 'awaiting_human_approval' | 'scheduled' | 'rejected';
  urgency: 'high' | 'medium' | 'routine';
  impactCategory: 'serendipity_connection' | 'venture_deal' | 'knowledge_synthesis' | 'bio_optimization';
  deliverable?: string;
  contextSignalsUsed: string[];
}

export interface AutonomousLifeAgent {
  id: string;
  codeName: string;
  roleTitle: string;
  specialization: 'serendipity_scout' | 'deal_negotiator' | 'wisdom_synthesizer' | 'bio_optimizer';
  avatarIcon: string;
  colorTheme: string;
  autonomyLevel: 'conservative' | 'collaborative' | 'high_agency';
  status: 'active_hunting' | 'synthesizing' | 'idle_monitoring';
  actionsCompletedToday: number;
  pendingApprovalsCount: number;
  missionStatement: string;
  recentTasks: AgentTaskExecution[];
  currentSignalRadar: string;
}

