import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { DeviceSwitcher } from './components/common/DeviceSwitcher';
import { WebsiteHeader } from './components/website/WebsiteHeader';
import { WebsiteHero } from './components/website/WebsiteHero';
import { WebsiteModularHomepage } from './components/website/WebsiteModularHomepage';
import { WebsiteCatalog } from './components/website/WebsiteCatalog';
import { WebsiteAccountOrders } from './components/website/WebsiteAccountOrders';
import { WebsiteFooter } from './components/website/WebsiteFooter';
import { MobileAppContainer } from './components/mobile/MobileAppContainer';
import { AdminLayout } from './components/admin/AdminLayout';
import { SellerCentralPortal } from './components/seller/SellerCentralPortal';
import { DriverPartnerPortal } from './components/driver/DriverPartnerPortal';
import { EcommerceAPIPlayground } from './components/api/EcommerceAPIPlayground';
import { SocialNetworkContainer } from './components/social/SocialNetworkContainer';
import { LifeOSContainer } from './components/lifeos/LifeOSContainer';

// Common Global Modals & Drawers
import { CartDrawer } from './components/common/CartDrawer';
import { CheckoutModal } from './components/common/CheckoutModal';
import { ProductDetailModal } from './components/common/ProductDetailModal';
import { AntiflyAIChatModal } from './components/common/AntiflyAIChatModal';
import { VoiceSearchModal } from './components/common/VoiceSearchModal';
import { ImageSearchModal } from './components/common/ImageSearchModal';
import { NotificationDrawer } from './components/common/NotificationDrawer';
import { OrderTrackingModal } from './components/common/OrderTrackingModal';
import { ProductComparisonModal } from './components/common/ProductComparisonModal';
import { CMSModal } from './components/common/CMSModal';
import { ToastNotification } from './components/common/ToastNotification';
import { GoogleAnalytics4Modal } from './components/common/GoogleAnalytics4Modal';
import { SEOManagerModal } from './components/common/SEOManagerModal';
import { ProductFinderModal } from './components/common/ProductFinderModal';
import { UniversalLoginModal } from './components/common/UniversalLoginModal';

// ZoloCoins, WiseReseller, AntiflyStyle & Squad Buy Feature Modals
import { SuperCoinsZoneModal } from './components/common/SuperCoinsZoneModal';
import { MeeshoResellerModal } from './components/common/MeeshoResellerModal';
import { MyntraStudioModal } from './components/common/MyntraStudioModal';
import { SizeAssistantModal } from './components/common/SizeAssistantModal';
import { GroupBuyModal } from './components/common/GroupBuyModal';
import { LiveMapTrackingModal } from './components/common/LiveMapTrackingModal';
import { InvoiceModal } from './components/common/InvoiceModal';
import { FoodDeliveryModal } from './components/common/FoodDeliveryModal';
import { AntiflyOneSubscriptionModal } from './components/common/AntiflyOneSubscriptionModal';
import { BankOffersModal } from './components/common/BankOffersModal';
import { OTTEntertainmentModal } from './components/common/OTTEntertainmentModal';
import { UniversalChatModal } from './components/common/UniversalChatModal';
import { CommunityHubModal } from './components/common/CommunityHubModal';
import { AppArchitectureModal } from './components/common/AppArchitectureModal';
import { ProductCommentsModal } from './components/common/ProductCommentsModal';
import { ProductShareModal } from './components/common/ProductShareModal';
import { SavePortfolioModal } from './components/common/SavePortfolioModal';
import { SellerStorefrontModal } from './components/seller/SellerStorefrontModal';
import { InstagramBlockConfirmationModal } from './components/common/InstagramBlockConfirmationModal';
import { BlockedAccountsModal } from './components/common/BlockedAccountsModal';
import { UserInterestManagerModal } from './components/common/UserInterestManagerModal';
import { GlobalAppDock } from './components/common/GlobalAppDock';

// Favorites & Saved Products System
import { FavoritesHubModal } from './components/favorites/FavoritesHubModal';
import { SmartSaveBottomSheet } from './components/favorites/SmartSaveBottomSheet';
import { FavoritesFlyingAnimation } from './components/favorites/FavoritesFlyingAnimation';

// Camera Creation Studio System (Snapchat + Instagram + WhatsApp + Social Commerce)
import { CameraStudioModal } from './components/camera/CameraStudioModal';
import { TimeShiftStoryCameraModal } from './components/camera/TimeShiftStoryCameraModal';
import { TimeShift3DStoryViewerModal } from './components/camera/TimeShift3DStoryViewerModal';
import { WhatsNewFeaturesModal } from './components/common/WhatsNewFeaturesModal';

const AppContent: React.FC = () => {
  const {
    deviceMode,
    themeMode,
    setSelectedCategorySlug,
    isTimeShiftCameraOpen,
    setIsTimeShiftCameraOpen,
    isTimeShiftStoryViewerOpen,
    setIsTimeShiftStoryViewerOpen,
    activeTimeShiftStory,
    isWhatsNewModalOpen,
    setIsWhatsNewModalOpen,
  } = useApp();

  const [websiteView, setWebsiteView] = useState<'home' | 'catalog' | 'account'>('home');

  const handleSelectCategory = (slug: string) => {
    setSelectedCategorySlug(slug);
    setWebsiteView('catalog');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleViewCatalog = () => {
    setWebsiteView('catalog');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div
      className="min-h-screen font-sans antialiased selection:bg-amber-500 selection:text-slate-800 bg-slate-50 text-slate-900"
    >
      {/* Top Global Ecosystem Switcher */}
      <DeviceSwitcher />

      {/* Main View Switcher */}
      {deviceMode === 'lifeos' && (
        <div id="lifeos-main-container">
          <LifeOSContainer />
        </div>
      )}

      {deviceMode === 'website' && (
        <div id="antifly-website-container" className="flex flex-col min-h-[calc(100vh-50px)]">
          <WebsiteHeader currentView={websiteView} setCurrentView={setWebsiteView} />

          <main className="flex-1">
            {websiteView === 'home' && (
              <>
                <WebsiteHero onExplore={handleViewCatalog} />
                <WebsiteModularHomepage
                  onSelectCategory={handleSelectCategory}
                  onViewCatalog={handleViewCatalog}
                />
              </>
            )}

            {websiteView === 'catalog' && (
              <WebsiteCatalog onGoHome={() => setWebsiteView('home')} />
            )}

            {websiteView === 'account' && (
              <WebsiteAccountOrders onGoHome={() => setWebsiteView('home')} />
            )}
          </main>

          <WebsiteFooter onNavigate={setWebsiteView} />
        </div>
      )}

      {(deviceMode === 'mobile-ios' || deviceMode === 'mobile-android') && (
        <div id="antifly-mobile-container" className="py-4">
          <MobileAppContainer />
        </div>
      )}

      {deviceMode === 'social' && (
        <div id="lifeos-social-merged-container">
          <LifeOSContainer />
        </div>
      )}

      {deviceMode === 'seller' && (
        <div id="antifly-seller-container">
          <SellerCentralPortal />
        </div>
      )}

      {deviceMode === 'driver' && (
        <div id="antifly-driver-container">
          <DriverPartnerPortal />
        </div>
      )}

      {deviceMode === 'api-docs' && (
        <div id="antifly-api-container">
          <EcommerceAPIPlayground />
        </div>
      )}

      {deviceMode === 'admin' && (
        <div id="antifly-admin-container">
          <AdminLayout />
        </div>
      )}

      {/* Global Drawers & Modals (Shared across the ecosystem) */}
      <CartDrawer />
      <CheckoutModal />
      <ProductDetailModal />
      <AntiflyAIChatModal />
      <VoiceSearchModal />
      <ImageSearchModal />
      <NotificationDrawer />
      <OrderTrackingModal />
      <ProductComparisonModal />
      <CMSModal />
      <ToastNotification />
      <GoogleAnalytics4Modal />
      <SEOManagerModal />
      <ProductFinderModal />
      <UniversalLoginModal />

      {/* Antifly Ecosystem Feature Modals */}
      <SuperCoinsZoneModal />
      <MeeshoResellerModal />
      <MyntraStudioModal />
      <SizeAssistantModal />
      <GroupBuyModal />
      <LiveMapTrackingModal />
      <InvoiceModal />
      <FoodDeliveryModal />
      <AntiflyOneSubscriptionModal />
      <BankOffersModal />
      <OTTEntertainmentModal />
      <UniversalChatModal />
      <CommunityHubModal />
      <AppArchitectureModal />
      <ProductCommentsModal />
      <ProductShareModal />
      <SavePortfolioModal />
      <SellerStorefrontModal />
      <UserInterestManagerModal />
      <InstagramBlockConfirmationModal />
      <BlockedAccountsModal />

      {/* Premium Favorites & Saved Products System */}
      <FavoritesHubModal />
      <SmartSaveBottomSheet />
      <FavoritesFlyingAnimation />

      {/* Camera Creation Studio System */}
      <CameraStudioModal />
      <TimeShiftStoryCameraModal
        isOpen={isTimeShiftCameraOpen}
        onClose={() => setIsTimeShiftCameraOpen(false)}
      />
      <TimeShift3DStoryViewerModal
        isOpen={isTimeShiftStoryViewerOpen}
        story={activeTimeShiftStory}
        onClose={() => setIsTimeShiftStoryViewerOpen(false)}
      />

      {/* Latest Features Release & Prompt Hub */}
      <WhatsNewFeaturesModal
        isOpen={isWhatsNewModalOpen}
        onClose={() => setIsWhatsNewModalOpen(false)}
      />

      {/* Floating 3-in-1 App Ecosystem Dock */}
      <GlobalAppDock />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
