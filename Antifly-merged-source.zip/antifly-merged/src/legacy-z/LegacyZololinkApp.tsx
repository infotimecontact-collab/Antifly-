import App from './App';
export const LegacyZololinkApp = App;
export default App;
