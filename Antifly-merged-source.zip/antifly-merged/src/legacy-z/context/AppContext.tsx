import React, { createContext, useContext, useState, useEffect, ReactNode, useMemo } from 'react';
import {
  Product,
  Category,
  Banner,
  HomepageSection,
  Coupon,
  Order,
  Customer,
  ReturnRequest,
  AbandonedCart,
  AuditLog,
  NotificationItem,
  CMSPage,
  StoreSettings,
  CartItem,
  DeviceMode,
  ThemeMode,
  OrderSource,
  CountryCode,
  CurrencyCode,
  RegionConfig,
  RefundRecord,
  GatewayKeysConfig,
  DataPrivacySettings,
  InvoiceData,
  MapTrackingState,
  OrderStatus,
  SuperCoinReward,
  SuperCoinTransaction,
  LoyaltyTierLevel,
  LoyaltyTierInfo,
  SuperCoinWalletState,
  DiamondWalletState,
  RewardMissionItem,
  FlashCoinEventItem,
  ReferralEconomyData,
  CreatorDiamondStats,
  SellerRewardConfig,
  UnifiedRewardTransaction,
  FraudRiskRule,
  FraudAuditRecord,
  CurrencyEconomyConfig,
  ResellerConfig,

  GroupBuyDeal,
  StyleCastLook,
  SizeRecommendationProfile,
  CompleteTheLookBundle,
  Restaurant,
  FoodItem,
  FoodCartItem,
  FoodOrder,
  AntiflyOnePlan,
  AntiflyOneSubscription,
  BankCardOffer,
  OTTPlatform,
  OTTShow,
  UserSession,
  StoryReactionType,
  LivingUserProfile,
  SocialAccountPersona,
  UserIntentType,
  SocialFeedMode,
  NextGenSocialPost,
  CollaborativeContribution,
  ContextReactionType,
  NextGenMomentItem,
  PersonRecommendationItem,
  TemporaryCommunityItem,
  SocialMissionItem,
  AIOpportunityMatch,
  AISocialTwinMemoryRecord,
  AISocialConversationMemory,
  SpecializedAIAgent,
  UserAttentionBudget,
  SocialCommerceAttachedProduct,
  StockAlertSubscription,
  PushNotificationMockData,
} from '../types';
import {
  INITIAL_CURRENT_USER_PROFILE,
  INITIAL_COMMUNITY_USERS,
  INITIAL_COLLABORATIVE_POSTS,
  INITIAL_PEOPLE_RECOMMENDATIONS,
  INITIAL_TEMPORARY_MOMENTS,
  INITIAL_TEMPORARY_COMMUNITIES,
  INITIAL_SOCIAL_MISSIONS,
  INITIAL_OPPORTUNITY_MATCHES,
  INITIAL_AI_TWIN_MEMORIES,
  INITIAL_CONVERSATION_MEMORIES,
  INITIAL_SPECIALIZED_AGENTS,
  INITIAL_ATTENTION_BUDGET,
} from '../data/socialNetworkData';
import {
  INITIAL_PRODUCTS,
  INITIAL_CATEGORIES,
  INITIAL_BANNERS,
  INITIAL_HOMEPAGE_SECTIONS,
  INITIAL_COUPONS,
  INITIAL_ORDERS,
  INITIAL_CUSTOMERS,
  INITIAL_RETURNS,
  INITIAL_ABANDONED_CARTS,
  INITIAL_AUDIT_LOGS,
  INITIAL_CMS_PAGES,
  INITIAL_SETTINGS,
  WORLDWIDE_REGIONS,
  INITIAL_REFUNDS,
  INITIAL_GATEWAY_KEYS,
  INITIAL_DATA_PRIVACY,
  INITIAL_SUPER_COIN_REWARDS,
  INITIAL_SUPER_COIN_TRANSACTIONS,
  INITIAL_GROUP_BUYS,
  INITIAL_STYLECAST_LOOKS,
  INITIAL_LOOK_BUNDLES,
  INITIAL_DRIVER_INCENTIVE_LEDGER,
} from '../data/mockData';
import {
  INITIAL_RESTAURANTS,
  INITIAL_WISEONE_PLANS,
  INITIAL_BANK_OFFERS,
  INITIAL_OTT_PLATFORMS,
  INITIAL_OTT_SHOWS,
} from '../data/foodAndEntertainmentData';
import { DEFAULT_PRODUCT_REVIEWS, getProductReviews } from '../data/defaultReviewsData';
import {
  GA4AnalyticsEvent,
  GA4Config,
  GA4EventName,
  ProductReview,
  LanguageCode,
  SellerProfile,
  SellerPayout,
  DriverProfile,
  DriverDeliveryTask,
  DriverIncentiveLedgerEntry,
  EcomAPIEndpoint,
  APIRequestLog,
  ChatConversation,
  ChatMessageItem,
  ChatMessageType,
  CommunityPostItem,
  CommunityCommentItem,
  ResellerEarningRecord,
  SellerAdminFeeRecord,
  ProductCommentItem,
  SellerPost,
  SellerPortfolioItem,
  UPIAppType,
  CustomerUPIProfile,
  SellerUPIProfile,
  DriverUPIProfile,
  UPIPinModalConfig,
  InstagramBlockRecord,
  UserInterestProfile,
  NotInterestedRecord,
  NotInterestedReason,
  NearbyProductMatch,
  ProductCollection,
  CollectionPrivacy,
  CollectionCollaborator,
  CollectionItemReaction,
  CollectionItemComment,
  WishlistItemDetails,
  SmartCategorySuggestion,
  FlyingSaveAnimationState,
  SmartSaveBottomSheetState,
  CameraMode,
  CameraCapturedMedia,
  CameraProductTag,
  CameraTextOverlay,
  CameraSticker,
  CameraLens,
  CameraMusicTrack,
  TimeShiftStoryItem,
  StoryPollSticker,
  LifeIntent,
  SocialWorld,
  SocialSynchronicity,
  UniversalDiscoveryItem,
  LifeMemoryItem,
  LifeMapZoneNode,
  RelationshipGraphNode,
  AISocialTwinConfig,
  ExperiencePostItem,
  LifeOSTab,
  LifeRadarOpportunity,
  FutureYouScenario,
  OpportunityExchangeItem,
  SkillGraphNode,
  GoalCommunity,
  PersonalGrowthNode,
  IdeaCollision,
  LifeOSMoment,
  ContributionReputation,
  AIPrivacyControlState,
  BioEnergyProfile,
  QuantumLifeDecision,
  QuantumBranchScenario,
  AutonomousLifeAgent,
  AgentTaskExecution,
} from '../types';
import {
  INITIAL_LIFE_INTENTS,
  INITIAL_SOCIAL_WORLDS,
  INITIAL_SYNCHRONICITIES,
  INITIAL_UNIVERSAL_DISCOVERY,
  INITIAL_LIFE_MEMORIES,
  INITIAL_MAP_NODES,
  INITIAL_RELATIONSHIP_NODES,
  INITIAL_AI_TWIN_CONFIG,
  INITIAL_EXPERIENCE_POSTS,
  INITIAL_LIFE_RADAR_OPPORTUNITIES,
  INITIAL_FUTURE_YOU_SCENARIOS,
  INITIAL_OPPORTUNITY_EXCHANGE_ITEMS,
  INITIAL_SKILL_GRAPH_NODES,
  INITIAL_GOAL_COMMUNITIES,
  INITIAL_PERSONAL_GROWTH_NODES,
  INITIAL_IDEA_COLLISIONS,
  INITIAL_LIFEOS_MOMENTS,
  INITIAL_CONTRIBUTION_REPUTATION,
  INITIAL_AI_PRIVACY_STATE,
  INITIAL_BIO_ENERGY_PROFILE,
  INITIAL_QUANTUM_DECISIONS,
  INITIAL_AUTONOMOUS_AGENTS,
} from '../data/lifeosData';
import {
  INITIAL_TIMESHIFT_STORIES,
} from '../data/timeShiftStoryData';
import {
  INITIAL_USER_COLLECTIONS,
  CREATOR_FEATURED_COLLECTIONS,
  INITIAL_WISHLIST_DETAILS,
  INITIAL_SMART_SUGGESTIONS,
} from '../data/defaultFavoritesData';
import { INITIAL_CAMERA_GALLERY } from '../data/defaultCameraData';
import { INITIAL_PRODUCT_COMMENTS } from '../data/defaultProductComments';
import {
  Analytics,
  trackGA4Event,
  subscribeToAnalytics,
  getAnalyticsEventHistory,
  DEFAULT_GA4_CONFIG,
} from '../utils/analytics';
import {
  DEFAULT_SELLERS,
  DEFAULT_SELLER_PAYOUTS,
  DEFAULT_DRIVERS,
  DEFAULT_DRIVER_TASKS,
  ECOMMERCE_WORLD_APIS,
  DEFAULT_SELLER_ADMIN_FEE_LOGS,
} from '../data/ecosystemData';
import {
  INITIAL_CHAT_CONVERSATIONS,
  INITIAL_CHAT_MESSAGES,
  INITIAL_COMMUNITY_POSTS,
  INITIAL_RESELLER_EARNINGS,
} from '../data/communityAndChatData';
import {
  DailyCheckInDay,
  INITIAL_SUPER_COIN_WALLET,
  INITIAL_DIAMOND_WALLET,
  INITIAL_LOYALTY_TIER,
  INITIAL_CHECKIN_DAYS,
  INITIAL_REWARD_MISSIONS,
  INITIAL_FLASH_EVENTS,
  INITIAL_REFERRAL_DATA,
  INITIAL_CREATOR_DIAMOND_STATS,
  INITIAL_SELLER_REWARD_CONFIG,
  INITIAL_REWARD_TRANSACTIONS,
  INITIAL_FRAUD_RULES,
  INITIAL_FRAUD_AUDIT_LOGS,
  INITIAL_CURRENCY_ECONOMY_CONFIG,
  INITIAL_SUPERCOIN_REWARDS_CATALOG,
} from '../data/rewardsData';
import { getTranslation, SUPPORTED_LANGUAGES } from '../utils/i18n';


interface AppContextType {
  // Navigation & Ecosystem States
  deviceMode: DeviceMode;
  setDeviceMode: (mode: DeviceMode) => void;
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;
  currentCustomer: Customer;
  currentRole: string;
  setCurrentRole: (role: string) => void;

  // Worldwide Localization & Multi-Currency Engine
  selectedCountry: CountryCode;
  setSelectedCountry: (country: CountryCode) => void;
  selectedCurrency: CurrencyCode;
  setSelectedCurrency: (currency: CurrencyCode) => void;
  currentRegion: RegionConfig;
  allRegions: Record<string, RegionConfig>;
  formatPrice: (inrAmount: number) => string;
  convertPrice: (inrAmount: number) => number;

  // Data Collections
  products: Product[];
  categories: Category[];
  banners: Banner[];
  homepageSections: HomepageSection[];
  cart: CartItem[];
  wishlist: string[];
  orders: Order[];
  coupons: Coupon[];
  returns: ReturnRequest[];
  refunds: RefundRecord[];
  customers: Customer[];
  abandonedCarts: AbandonedCart[];
  auditLogs: AuditLog[];
  notifications: NotificationItem[];
  cmsPages: CMSPage[];
  settings: StoreSettings;
  gatewayKeys: GatewayKeysConfig;
  dataPrivacy: DataPrivacySettings;
  activeAppliedCoupon: { code: string; discountAmount: number } | null;

  // Modals & UI Triggers
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isWhatsNewModalOpen: boolean;
  setIsWhatsNewModalOpen: (open: boolean) => void;
  isAntiflyAIOpen: boolean;
  setIsAntiflyAIOpen: (open: boolean) => void;
  isVoiceSearchOpen: boolean;
  setIsVoiceSearchOpen: (open: boolean) => void;
  isImageSearchOpen: boolean;
  setIsImageSearchOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  isNotificationDrawerOpen: boolean;
  setIsNotificationDrawerOpen: (open: boolean) => void;
  activePdpId: string | null;
  setActivePdpId: (id: string | null) => void;
  activeTrackingOrder: Order | null;
  setActiveTrackingOrder: (order: Order | null) => void;
  activeCMSPage: CMSPage | null;
  setActiveCMSPage: (page: CMSPage | null) => void;
  comparisonList: Product[];
  addToComparison: (product: Product) => void;
  removeFromComparison: (productId: string) => void;
  clearComparison: () => void;
  isComparisonOpen: boolean;
  setIsComparisonOpen: (open: boolean) => void;

  // Live Invoice Modal
  activeInvoiceData: InvoiceData | null;
  setActiveInvoiceData: (inv: InvoiceData | null) => void;
  viewOrderInvoice: (order: Order) => void;

  // Live Map Tracking Modal
  isLiveMapOpen: boolean;
  setIsLiveMapOpen: (open: boolean) => void;
  activeMapTracking: MapTrackingState | null;
  openLiveMapForOrder: (order: Order) => void;

  // Search & Filter state for catalog
  selectedCategorySlug: string;
  setSelectedCategorySlug: (slug: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  appliedFilters: {
    minPrice?: number;
    maxPrice?: number;
    color?: string;
    sortBy?: string;
    tag?: string;
  };
  setAppliedFilters: React.Dispatch<
    React.SetStateAction<{
      minPrice?: number;
      maxPrice?: number;
      color?: string;
      sortBy?: string;
      tag?: string;
    }>
  >;

  // Anti-Collapsing & High-Volume Operations
  isOrderProcessing: boolean;
  bulkUpdateOrders: (orderIds: string[], status: OrderStatus) => Promise<void>;
  bulkGenerateInvoices: (orderIds: string[]) => Promise<void>;

  // ==========================================
  // FLIPKART SUPERCOIN & REWARDS HUB
  // ==========================================
  superCoinsBalance: number;
  superCoinRewards: SuperCoinReward[];
  superCoinTransactions: SuperCoinTransaction[];
  isSuperCoinsModalOpen: boolean;
  setIsSuperCoinsModalOpen: (open: boolean) => void;
  redeemSuperCoinReward: (rewardId: string) => Promise<void>;
  useSuperCoinsAtCheckout: boolean;
  setUseSuperCoinsAtCheckout: (use: boolean) => void;
  isPlusMember: boolean;

  // ==========================================
  // MEESHO RESELLER & COMMUNITY GROUP BUYS
  // ==========================================
  resellerConfig: ResellerConfig;
  setResellerConfig: React.Dispatch<React.SetStateAction<ResellerConfig>>;
  isResellerModalOpen: boolean;
  setIsResellerModalOpen: (open: boolean) => void;
  groupBuyDeals: GroupBuyDeal[];
  joinGroupBuy: (dealId: string) => Promise<void>;
  isGroupBuyModalOpen: boolean;
  setIsGroupBuyModalOpen: (open: boolean) => void;
  meeshoReturnChoice: 'easy_return' | 'wrong_defective_only';
  setMeeshoReturnChoice: (choice: 'easy_return' | 'wrong_defective_only') => void;

  // ==========================================
  // MYNTRA STUDIO / STYLECAST LOOKBOOK & FIT
  // ==========================================
  styleCastLooks: StyleCastLook[];
  activeStyleLook: StyleCastLook | null;
  setActiveStyleLook: (look: StyleCastLook | null) => void;
  isStyleCastModalOpen: boolean;
  setIsStyleCastModalOpen: (open: boolean) => void;
  lookBundles: CompleteTheLookBundle[];
  addBundleToCart: (bundleId: string) => Promise<void>;
  sizeProfile: SizeRecommendationProfile;
  setSizeProfile: React.Dispatch<React.SetStateAction<SizeRecommendationProfile>>;
  calculateRecommendedSize: (heightCm: number, weightKg: number, bodyType: string, fit: string) => string;
  isSizeAssistantOpen: boolean;
  setIsSizeAssistantOpen: (open: boolean) => void;
  priceDropWatchlist: string[];
  togglePriceDropAlert: (productId: string) => void;

  // ==========================================
  // FOOD DELIVERY (WISEBITES / CLOUD KITCHENS)
  // ==========================================
  restaurants: Restaurant[];
  isFoodDeliveryModalOpen: boolean;
  setIsFoodDeliveryModalOpen: (open: boolean) => void;
  selectedRestaurant: Restaurant | null;
  setSelectedRestaurant: (rest: Restaurant | null) => void;
  foodCart: FoodCartItem[];
  addToFoodCart: (item: FoodCartItem) => void;
  updateFoodCartQuantity: (dishId: string, quantity: number) => void;
  removeFromFoodCart: (dishId: string) => void;
  clearFoodCart: () => void;
  foodOrders: FoodOrder[];
  placeFoodOrder: (tip?: number, specialNotes?: string) => Promise<FoodOrder>;

  // ==========================================
  // ALL-IN-ONE MASTER SUBSCRIPTION (WISEONE PASS)
  // ==========================================
  antiflyOnePlans: AntiflyOnePlan[];
  antiflyOneSubscription: AntiflyOneSubscription;
  isAntiflyOneModalOpen: boolean;
  setIsAntiflyOneModalOpen: (open: boolean) => void;
  subscribeToAntiflyOne: (planId: string) => Promise<void>;
  cancelAntiflyOneSubscription: () => Promise<void>;

  // ==========================================
  // ALL BANK CREDIT CARDS & EMI OFFERS
  // ==========================================
  bankOffers: BankCardOffer[];
  isBankOffersModalOpen: boolean;
  setIsBankOffersModalOpen: (open: boolean) => void;
  appliedBankOffer: BankCardOffer | null;
  applyBankOffer: (offerId: string) => void;
  removeBankOffer: () => void;

  // ==========================================
  // OTT PLATFORM & STREAMING (WISESTREAM)
  // ==========================================
  ottPlatforms: OTTPlatform[];
  ottShows: OTTShow[];
  isOTTModalOpen: boolean;
  setIsOTTModalOpen: (open: boolean) => void;
  activeStreamingShow: OTTShow | null;
  setActiveStreamingShow: (show: OTTShow | null) => void;

  // ==========================================
  // PRODUCT REVIEWS & BUYER PHOTO UPLOADS
  // ==========================================
  addProductReview: (
    productId: string,
    review: {
      rating: number;
      title: string;
      comment: string;
      userName: string;
      images?: string[];
      pros?: string[];
      cons?: string[];
      isVerified?: boolean;
      location?: string;
    }
  ) => void;
  voteReviewHelpful: (productId: string, reviewId: string) => void;

  // ==========================================
  // SMART PRODUCT FINDER / OCCASION DISCOVERY
  // ==========================================
  isProductFinderOpen: boolean;
  setIsProductFinderOpen: (open: boolean) => void;

  // ==========================================
  // GOOGLE ANALYTICS 4 & TELEMETRY
  // ==========================================
  isGA4ModalOpen: boolean;
  setIsGA4ModalOpen: (open: boolean) => void;
  ga4Config: GA4Config;
  setGA4Config: React.Dispatch<React.SetStateAction<GA4Config>>;
  ga4EventLog: GA4AnalyticsEvent[];
  trackEvent: (eventName: GA4EventName, params?: any) => void;

  // ==========================================
  // SEO MANAGER & OPENGRAPH PREVIEW
  // ==========================================
  isSEOModalOpen: boolean;
  setIsSEOModalOpen: (open: boolean) => void;

  // ==========================================
  // WORLDWIDE LANGUAGE LOCALIZATION (i18n)
  // ==========================================
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: string) => string;

  // ==========================================
  // SELLER CENTRAL PORTAL & VENDOR ECOSYSTEM
  // ==========================================
  sellers: SellerProfile[];
  activeSellerId: string;
  setActiveSellerId: (id: string) => void;
  currentSeller: SellerProfile;
  sellerPayouts: SellerPayout[];
  addSellerProduct: (product: Partial<Product>) => Promise<void>;
  updateSellerInventory: (productId: string, newStock: number, newPrice?: number) => Promise<void>;
  requestSellerPayout: (sellerId: string, amount: number) => Promise<SellerPayout>;
  sellerCoupons: Coupon[];
  createSellerCoupon: (couponData: Partial<Coupon>) => Promise<{ success: boolean; message: string; coupon?: Coupon }>;
  deleteSellerCoupon: (couponId: string) => Promise<void>;
  toggleSellerCouponStatus: (couponId: string) => Promise<void>;
  sellerAdminFeeLedger: SellerAdminFeeRecord[];
  paySellerAdminPlatformFees: (sellerId: string, amount?: number) => Promise<{ success: boolean; message: string; utr: string }>;
  followedSellerIds: string[];
  toggleFollowSeller: (sellerId: string) => void;
  isFollowingSeller: (sellerId: string) => boolean;
  activeSellerStorefrontId: string | null;
  setActiveSellerStorefrontId: (id: string | null) => void;
  openSellerStorefront: (sellerId: string) => void;
  likeSellerPost: (sellerId: string, postId: string) => void;
  dislikeSellerPost: (sellerId: string, postId: string) => void;
  toggleSaveSellerPost: (sellerId: string, postId: string) => void;
  addCommentToSellerPost: (sellerId: string, postId: string, text: string) => void;
  likeSellerPortfolioItem: (sellerId: string, itemId: string) => void;
  dislikeSellerPortfolioItem: (sellerId: string, itemId: string) => void;
  toggleSaveSellerPortfolioItem: (sellerId: string, itemId: string) => void;
  createSellerPost: (sellerId: string, postData: Partial<SellerPost>) => void;
  createSellerPortfolioItem: (sellerId: string, itemData: Partial<SellerPortfolioItem>) => void;

  // ==========================================
  // INSTAGRAM-STYLE PRODUCT SOCIAL & COMMENTS
  // ==========================================
  productLikes: Record<string, { count: number; isLiked: boolean }>;
  productComments: Record<string, ProductCommentItem[]>;
  savedProductIds: string[];
  savedSellerPostIds: string[];
  savedSellerPortfolioIds: string[];
  activeCommentsProductId: string | null;
  setActiveCommentsProductId: (id: string | null) => void;
  activeShareProduct: Product | null;
  setActiveShareProduct: (p: Product | null) => void;
  toggleLikeProduct: (productId: string) => void;
  isProductLiked: (productId: string) => boolean;
  getProductLikeCount: (productId: string) => number;
  toggleSaveProductSocial: (productId: string) => void;
  isProductSavedSocial: (productId: string) => boolean;
  addProductComment: (
    productId: string,
    text: string,
    quickReactionType?: 'good' | 'not_good' | 'bad' | 'dont_buy' | 'custom'
  ) => void;
  likeProductComment: (productId: string, commentId: string) => void;
  isProductCommentsOpen: boolean;
  setIsProductCommentsOpen: (open: boolean) => void;
  isProductShareOpen: boolean;
  setIsProductShareOpen: (open: boolean) => void;
  isSavePortfolioOpen: boolean;
  setIsSavePortfolioOpen: (open: boolean) => void;

  // ==========================================
  // FAVORITES & SAVED PRODUCTS SYSTEM (INSTAGRAM + SNAPCHAT + WISHLIST)
  // ==========================================
  userCollections: ProductCollection[];
  creatorCollections: ProductCollection[];
  activeCollectionId: string | null;
  setActiveCollectionId: (id: string | null) => void;
  isFavoritesHubOpen: boolean;
  setIsFavoritesHubOpen: (open: boolean) => void;
  activeFavoritesTab: 'all' | 'products' | 'posts' | 'videos' | 'stores' | 'collections' | 'wishlist' | 'collaborative' | 'creators' | 'figma_screens';
  setActiveFavoritesTab: (tab: 'all' | 'products' | 'posts' | 'videos' | 'stores' | 'collections' | 'wishlist' | 'collaborative' | 'creators' | 'figma_screens') => void;
  savedProductViewMode: 'grid' | 'masonry' | 'list';
  setSavedProductViewMode: (mode: 'grid' | 'masonry' | 'list') => void;
  smartSaveBottomSheet: SmartSaveBottomSheetState;
  openSmartSaveBottomSheet: (productId: string) => void;
  closeSmartSaveBottomSheet: () => void;
  flyingSaveAnimation: FlyingSaveAnimationState;
  triggerFlyingSaveAnimation: (imageUrl: string, productName: string, startX?: number, startY?: number) => void;
  wishlistDetails: Record<string, WishlistItemDetails>;
  toggleWishlistWithAlert: (productId: string) => void;
  smartCategorySuggestions: SmartCategorySuggestion[];
  acceptSmartCategorySuggestion: (suggestion: SmartCategorySuggestion) => void;
  dismissSmartCategorySuggestion: (categoryName: string) => void;
  createCustomCollection: (name: string, emoji?: string, description?: string, privacy?: CollectionPrivacy, initialProductIds?: string[]) => ProductCollection;
  updateCollection: (collectionId: string, updates: Partial<ProductCollection>) => void;
  deleteCollection: (collectionId: string) => void;
  addProductToCollection: (collectionId: string, productId: string) => void;
  removeProductFromCollection: (collectionId: string, productId: string) => void;
  moveProductBetweenCollections: (fromCollectionId: string, toCollectionId: string, productId: string) => void;
  reorderProductsInCollection: (collectionId: string, newProductIds: string[]) => void;
  reactToCollaborativeItem: (collectionId: string, productId: string, reactionType: 'like' | 'love' | 'fire') => void;
  addCollaborativeComment: (collectionId: string, productId: string, text: string) => void;
  quickSaveProductWithSmartFlow: (productId: string, event?: React.MouseEvent) => void;

  // ==========================================
  // CAMERA CREATION STUDIO (SNAPCHAT + INSTAGRAM + WHATSAPP + SOCIAL COMMERCE)
  // ==========================================
  isCameraStudioOpen: boolean;
  setIsCameraStudioOpen: (open: boolean) => void;
  cameraInitialMode: CameraMode;
  setCameraInitialMode: (mode: CameraMode) => void;
  cameraTargetConversationId: string | null;
  setCameraTargetConversationId: (id: string | null) => void;
  cameraTargetProductId: string | null;
  setCameraTargetProductId: (id: string | null) => void;
  cameraGalleryMedia: CameraCapturedMedia[];
  openCameraStudio: (mode?: CameraMode, options?: { conversationId?: string; productId?: string }) => void;
  saveMediaToCameraGallery: (media: CameraCapturedMedia) => void;
  saveMediaDraft: (media: CameraCapturedMedia) => void;
  deleteMediaFromCameraGallery: (id: string) => void;
  publishMediaToStory: (media: CameraCapturedMedia) => void;
  publishMediaToReel: (media: CameraCapturedMedia) => void;
  publishMediaToFeed: (media: CameraCapturedMedia) => void;
  publishMediaToProductCatalog: (media: CameraCapturedMedia, customProduct?: Partial<Product>) => void;
  sendMediaDirectToChat: (conversationId: string, media: CameraCapturedMedia, note?: string) => void;

  // ==========================================
  // TIME-SHIFT 3D STORIES & SPATIAL SOCIAL ENGINE
  // ==========================================
  timeShiftStories: TimeShiftStoryItem[];
  setTimeShiftStories: React.Dispatch<React.SetStateAction<TimeShiftStoryItem[]>>;
  isTimeShiftCameraOpen: boolean;
  setIsTimeShiftCameraOpen: (open: boolean) => void;
  activeTimeShiftStory: TimeShiftStoryItem | null;
  setActiveTimeShiftStory: (story: TimeShiftStoryItem | null) => void;
  isTimeShiftStoryViewerOpen: boolean;
  setIsTimeShiftStoryViewerOpen: (open: boolean) => void;
  openTimeShiftStoryViewer: (story: TimeShiftStoryItem) => void;
  openTimeShiftCamera: () => void;
  publishTimeShiftStory: (story: TimeShiftStoryItem) => void;
  recordStoryMomentReaction: (storyId: string, timestampSec: number, type: StoryReactionType) => void;
  unlockSecretStoryReward: (storyId: string, objectId: string) => void;
  voteStoryPoll: (storyId: string, pollId: string, optionId: string) => void;
  addOrUpdateStoryPoll: (storyId: string, poll: StoryPollSticker) => void;
  removeStoryPoll: (storyId: string, pollId: string) => void;

  // ==========================================
  // DRIVER LOGISTICS & DELIVERY PARTNER APP
  // ==========================================
  drivers: DriverProfile[];
  activeDriverId: string;
  setActiveDriverId: (id: string) => void;
  currentDriver: DriverProfile;
  toggleDriverOnline: (driverId: string) => void;
  driverTasks: DriverDeliveryTask[];
  updateDriverTaskStatus: (taskId: string, status: DriverDeliveryTask['status']) => void;
  completeDriverDeliveryWithOtp: (taskId: string, enteredOtp: string, proofPhoto?: string, signature?: string) => Promise<{ success: boolean; message: string }>;
  driverIncentiveLedger: DriverIncentiveLedgerEntry[];
  addDriverIncentiveLedgerEntry: (entry: Partial<DriverIncentiveLedgerEntry>) => void;
  isDriverIncentiveLedgerOpen: boolean;
  setIsDriverIncentiveLedgerOpen: (open: boolean) => void;
  convertDriverCreditsToRupees: (driverId: string, credits: number, reason?: string) => Promise<{ success: boolean; message: string; record?: DriverIncentiveLedgerEntry }>;

  // ==========================================
  // E-COMMERCE WORLD OPEN REST API & PLAYGROUND
  // ==========================================
  apiEndpoints: EcomAPIEndpoint[];
  apiLogs: APIRequestLog[];
  executeApiCall: (endpointId: string, customParams?: any, customBody?: any) => Promise<any>;
  clearApiLogs: () => void;

  // Universal Authentication & Multi-Role Session
  currentUserSession: UserSession;
  isLoginModalOpen: boolean;
  setIsLoginModalOpen: (open: boolean) => void;
  loginWithMobile: (phone: string, otp: string, role: 'customer' | 'seller' | 'driver' | 'admin') => Promise<{ success: boolean; message: string; name?: string }>;
  loginWithSocial: (provider: 'google' | 'apple' | 'github', email: string, role: 'customer' | 'seller' | 'driver' | 'admin', phone?: string) => Promise<{ success: boolean; message: string }>;
  logoutUserSession: () => void;
  quickSwitchUser: (role: 'customer' | 'seller' | 'driver' | 'admin', id?: string) => void;

  // ==========================================
  // WHATSAPP-STYLE UNIVERSAL 1-TO-1 & AI CHAT
  // ==========================================
  chatConversations: ChatConversation[];
  activeConversationId: string;
  setActiveConversationId: (id: string) => void;
  chatMessages: Record<string, ChatMessageItem[]>;
  sendChatMessage: (conversationId: string, content: string, type?: ChatMessageType, extra?: Partial<ChatMessageItem>) => void;
  toggleConversationMute: (conversationId: string) => void;
  toggleConversationBlock: (conversationId: string) => void;
  toggleConversationChatEnabled: (conversationId: string) => void;
  updateDisappearingTimer: (conversationId: string, timer: 'off' | '24h' | '7d') => void;
  isUniversalChatOpen: boolean;
  setIsUniversalChatOpen: (open: boolean) => void;
  openDirectChatWithPeer: (peerRole: 'customer' | 'seller' | 'driver' | 'support_ai' | 'community_group', peerName?: string, contextTag?: string) => void;

  // ==========================================
  // COMMUNITY HUB & 15s SHORT VIDEO REELS
  // ==========================================
  communityPosts: CommunityPostItem[];
  isCommunityHubOpen: boolean;
  setIsCommunityHubOpen: (open: boolean) => void;
  activeCommunityPost: CommunityPostItem | null;
  setActiveCommunityPost: (post: CommunityPostItem | null) => void;
  likeCommunityPost: (postId: string) => void;
  addCommunityComment: (postId: string, text: string) => void;
  createCommunityPost: (postData: Partial<CommunityPostItem>) => void;
  shareCommunityPostToChat: (post: CommunityPostItem) => void;

  // ==========================================
  // RESELLER WALLET & MARGIN EARNINGS
  // ==========================================
  resellerEarnings: ResellerEarningRecord[];
  resellerWalletBalance: number;
  withdrawResellerEarnings: (amount: number, upiId: string) => Promise<{ success: boolean; message: string; utr: string }>;
  simulateResellerOrderSale: (product: Product, marginAmount: number, customerName: string) => void;

  // ==========================================
  // ECOSYSTEM ARCHITECTURE & EXPLAINER MODAL
  // ==========================================
  isAppArchitectureModalOpen: boolean;
  setIsAppArchitectureModalOpen: (open: boolean) => void;

  // ==========================================
  // UPI PAYMENT APPS & PIN SECURITY
  // ==========================================
  customerUPI: CustomerUPIProfile;
  updateCustomerUPI: (data: Partial<CustomerUPIProfile>) => void;
  sellerUPIs: Record<string, SellerUPIProfile>;
  updateSellerUPI: (sellerId: string, data: Partial<SellerUPIProfile>) => void;
  driverUPIs: Record<string, DriverUPIProfile>;
  updateDriverUPI: (driverId: string, data: Partial<DriverUPIProfile>) => void;
  upiPinModalConfig: UPIPinModalConfig | null;
  openUPIPinModal: (config: Omit<UPIPinModalConfig, 'isOpen'>) => void;
  closeUPIPinModal: () => void;
  verifyUPIPin: (enteredPin: string) => Promise<{ success: boolean; message: string; utr: string }>;

  // ==========================================
  // INSTAGRAM-STYLE BLOCK FUNCTIONALITY
  // ==========================================
  blockedUserIds: string[];
  blockedSellerIds: string[];
  blockRecords: InstagramBlockRecord[];
  blockedCustomerIdsBySeller: Record<string, string[]>;
  toggleBlockUser: (
    userId: string,
    userName?: string,
    userAvatar?: string,
    userHandle?: string,
    reason?: string
  ) => void;
  isUserBlocked: (userId: string) => boolean;
  toggleBlockSeller: (
    sellerId: string,
    reason?: string,
    sellerName?: string,
    sellerAvatar?: string,
    sellerHandle?: string
  ) => void;
  isSellerBlocked: (sellerId: string) => boolean;
  isProductSellerBlocked: (product: Product) => boolean;
  unblockEntity: (blockedId: string) => void;
  toggleBlockCustomerBySeller: (sellerId: string, customerId: string, reason?: string) => void;
  isCustomerBlockedBySeller: (sellerId: string, customerId: string) => boolean;
  isBlockedAccountsModalOpen: boolean;
  setIsBlockedAccountsModalOpen: (open: boolean) => void;
  blockConfirmModal: {
    isOpen: boolean;
    targetType: 'seller' | 'customer' | 'user';
    targetId: string;
    targetName: string;
    targetAvatar?: string;
    targetHandle?: string;
    onConfirm: () => void;
  } | null;
  openBlockConfirmationModal: (
    targetType: 'seller' | 'customer' | 'user',
    targetId: string,
    targetName: string,
    targetAvatar?: string,
    targetHandle?: string,
    onConfirm?: () => void
  ) => void;
  closeBlockConfirmationModal: () => void;

  // ==========================================
  // INSTAGRAM-STYLE PROFILE SHARING
  // ==========================================
  activeShareSeller: SellerProfile | null;
  isSellerShareModalOpen: boolean;
  openSellerShareModal: (seller: SellerProfile) => void;
  closeSellerShareModal: () => void;

  // ==========================================
  // USER INTEREST, NON-INTEREST & NEARBY ENGINE
  // ==========================================
  isInterestManagerOpen: boolean;
  setIsInterestManagerOpen: (open: boolean) => void;
  userInterestProfile: UserInterestProfile;
  markProductInterested: (productId: string) => void;
  markProductNotInterested: (productId: string, reason?: NotInterestedReason, reasonText?: string) => void;
  undoNotInterested: (productId: string) => void;
  clearAllNotInterested: () => void;
  removeInterestProduct: (productId: string) => void;
  updateCategoryAffinity: (category: string, score: number) => void;
  resetInterestProfile: () => void;
  updateUserLocationPreference: (city: string, pin: string, radiusKm: number) => void;
  setShoppingVibePreference: (vibe: 'all' | 'festive' | 'daily' | 'luxury' | 'budget') => void;
  isProductInterested: (productId: string) => boolean;
  isProductNotInterested: (productId: string) => boolean;
  getPersonalizedRecommendedProducts: () => Product[];
  getNearbyInterestedProducts: () => NearbyProductMatch[];
  isLoadingHomepage: boolean;
  simulateHomepageRefresh: () => void;

  // Actions
  addToCart: (item: Omit<CartItem, 'id'>) => Promise<void>;
  updateCartQuantity: (id: string, qty: number) => Promise<void>;
  removeFromCart: (id: string) => Promise<void>;
  clearCart: () => Promise<void>;
  toggleWishlist: (productId: string) => Promise<void>;
  isInWishlist: (productId: string) => boolean;
  applyCouponCode: (code: string) => Promise<{ success: boolean; message: string }>;
  removeCoupon: () => void;
  placeOrder: (orderData: any) => Promise<Order>;
  cancelOrderAndInitiateRefund: (orderId: string, reason: string) => Promise<RefundRecord>;
  advanceRefundStep: (refundId: string) => Promise<void>;
  submitReturnRequest: (data: any) => Promise<void>;
  updateOrderStatus: (orderId: string, status: Order['status'], courier?: string, tracking?: string) => Promise<void>;
  updateReturnStatus: (returnId: string, status: ReturnRequest['status']) => Promise<void>;
  saveProduct: (product: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  saveBanner: (banner: Partial<Banner>) => Promise<void>;
  deleteBanner: (id: string) => Promise<void>;
  updateHomepageSections: (sections: HomepageSection[]) => Promise<void>;
  updateSettings: (settings: Partial<StoreSettings>) => Promise<void>;
  updateGatewayKeys: (keys: Partial<GatewayKeysConfig>) => Promise<void>;
  updateDataPrivacy: (privacy: Partial<DataPrivacySettings>) => Promise<void>;
  updateCMSPage: (slug: string, content: string, title?: string) => Promise<void>;
  sendAbandonedCartReminder: (id: string) => Promise<void>;
  markNotificationsAsRead: () => void;
  // ==========================================
  // NEXT-GENERATION AI SOCIAL NETWORK STATE & METHODS
  // ==========================================
  livingUserProfile: LivingUserProfile;
  updateLivingProfile: (updates: Partial<LivingUserProfile>) => void;
  switchActivePersona: (persona: SocialAccountPersona) => void;
  setUserIntent: (intent: UserIntentType) => void;
  socialFeedMode: SocialFeedMode;
  setSocialFeedMode: (mode: SocialFeedMode) => void;
  socialPosts: NextGenSocialPost[];
  setSocialPosts: React.Dispatch<React.SetStateAction<NextGenSocialPost[]>>;
  addSocialPost: (post: Partial<NextGenSocialPost>) => void;
  addCollaborativeContribution: (postId: string, contribution: Partial<CollaborativeContribution>) => void;
  toggleContextReaction: (postId: string, reaction: ContextReactionType) => void;
  convertPostToProduct: (postId: string, productData: Partial<SocialCommerceAttachedProduct>) => void;
  requestIdentityReveal: (postId: string) => void;
  peopleRecommendations: PersonRecommendationItem[];
  setPeopleRecommendations: React.Dispatch<React.SetStateAction<PersonRecommendationItem[]>>;
  temporaryMoments: NextGenMomentItem[];
  addTemporaryMoment: (moment: Partial<NextGenMomentItem>) => void;
  temporaryCommunities: TemporaryCommunityItem[];
  joinTemporaryCommunity: (communityId: string) => void;
  socialMissions: SocialMissionItem[];
  completeSocialMission: (missionId: string) => void;
  opportunityMatches: AIOpportunityMatch[];
  aiTwinMemories: AISocialTwinMemoryRecord[];
  updateTwinMemory: (memoryId: string, permitted: boolean) => void;
  deleteTwinMemory: (memoryId: string) => void;
  resetAllTwinMemory: () => void;
  addTwinMemory: (record: Partial<AISocialTwinMemoryRecord>) => void;
  conversationMemories: AISocialConversationMemory[];
  searchConversationMemories: (query: string) => AISocialConversationMemory[];
  specializedAgents: SpecializedAIAgent[];
  toggleSpecializedAgent: (agentId: string) => void;
  userAttentionBudget: UserAttentionBudget;
  setUserAttentionBudget: (budget: UserAttentionBudget) => void;
  initiateIntroduceMe: (target: PersonRecommendationItem, contextNote?: string) => void;
  isIntroduceMeModalOpen: boolean;
  setIsIntroduceMeModalOpen: (open: boolean) => void;
  activeIntroduceMeTarget: PersonRecommendationItem | null;
  setActiveIntroduceMeTarget: (target: PersonRecommendationItem | null) => void;
  isAITwinDashboardOpen: boolean;
  setIsAITwinDashboardOpen: (open: boolean) => void;
  isOpportunityMatchModalOpen: boolean;
  setIsOpportunityMatchModalOpen: (open: boolean) => void;
  activeOpportunityMatch: AIOpportunityMatch | null;
  setActiveOpportunityMatch: (match: AIOpportunityMatch | null) => void;
  isCreateSocialEntityModalOpen: boolean;
  setIsCreateSocialEntityModalOpen: (open: boolean) => void;
  createSocialEntityType: 'post' | 'moment' | 'product' | 'mission' | 'community';
  setCreateSocialEntityType: (type: 'post' | 'moment' | 'product' | 'mission' | 'community') => void;
  openCreateSocialModal: (type?: 'post' | 'moment' | 'product' | 'mission' | 'community') => void;

  // ==========================================
  // LIFEOS: THE SOCIAL OPERATING SYSTEM
  // ==========================================
  lifeIntents: LifeIntent[];
  setLifeIntents: React.Dispatch<React.SetStateAction<LifeIntent[]>>;
  addLifeIntent: (intent: Partial<LifeIntent>) => void;
  toggleIntentStatus: (id: string) => void;
  deleteLifeIntent: (id: string) => void;
  socialWorlds: SocialWorld[];
  setSocialWorlds: React.Dispatch<React.SetStateAction<SocialWorld[]>>;
  joinSocialWorld: (id: string) => void;
  leaveSocialWorld: (id: string) => void;
  createSocialWorld: (world: Partial<SocialWorld>) => void;
  synchronicities: SocialSynchronicity[];
  setSynchronicities: React.Dispatch<React.SetStateAction<SocialSynchronicity[]>>;
  respondToSynchronicity: (id: string, status: 'approved' | 'declined' | 'connected') => void;
  universalDiscoveryItems: UniversalDiscoveryItem[];
  setUniversalDiscoveryItems: React.Dispatch<React.SetStateAction<UniversalDiscoveryItem[]>>;
  lifeMemories: LifeMemoryItem[];
  addLifeMemory: (mem: Partial<LifeMemoryItem>) => void;
  toggleMemoryPrivacy: (id: string) => void;
  mapNodes: LifeMapZoneNode[];
  relationshipNodes: RelationshipGraphNode[];
  aiTwinConfig: AISocialTwinConfig;
  updateAITwinConfig: (config: Partial<AISocialTwinConfig>) => void;
  experiencePosts: ExperiencePostItem[];
  addExperiencePost: (post: Partial<ExperiencePostItem>) => void;
  reactToExperiencePost: (id: string, reaction: 'relate' | 'understand' | 'collaborate' | 'insightful') => void;
  activeLifeOSTab: LifeOSTab;
  setActiveLifeOSTab: (tab: LifeOSTab) => void;
  isLifeIntentModalOpen: boolean;
  setIsLifeIntentModalOpen: (open: boolean) => void;
  isLifeVoiceModalOpen: boolean;
  setIsLifeVoiceModalOpen: (open: boolean) => void;
  isCreateWorldModalOpen: boolean;
  setIsCreateWorldModalOpen: (open: boolean) => void;
  activeWorldDetail: SocialWorld | null;
  setActiveWorldDetail: (world: SocialWorld | null) => void;
  isSafetyTrustModalOpen: boolean;
  setIsSafetyTrustModalOpen: (open: boolean) => void;
  isEmergentCommunityModalOpen: boolean;
  setIsEmergentCommunityModalOpen: (open: boolean) => void;

  // Next-Gen LifeOS Features
  lifeRadarOpportunities: LifeRadarOpportunity[];
  setLifeRadarOpportunities: React.Dispatch<React.SetStateAction<LifeRadarOpportunity[]>>;
  updateRadarOpportunityStatus: (id: string, status: 'available' | 'requested' | 'connected', isIgnored?: boolean) => void;
  futureYouScenarios: FutureYouScenario[];
  runFutureYouSimulation: (hypothesis: string, horizon: '6_months' | '1_year' | '3_years') => void;
  opportunityExchangeItems: OpportunityExchangeItem[];
  addOpportunityExchangeItem: (item: Partial<OpportunityExchangeItem>) => void;
  skillGraphNodes: SkillGraphNode[];
  toggleSkillVisibility: (id: string) => void;
  goalCommunities: GoalCommunity[];
  toggleJoinGoalCommunity: (id: string) => void;
  addGoalCommunitySprintTask: (communityId: string, taskText: string) => void;
  personalGrowthNodes: PersonalGrowthNode[];
  addPersonalGrowthNode: (node: Partial<PersonalGrowthNode>) => void;
  ideaCollisions: IdeaCollision[];
  optInIdeaCollision: (collisionId: string, userId: string) => void;
  lifeOSMoments: LifeOSMoment[];
  archiveMomentToMemory: (momentId: string) => void;
  contributionReputation: ContributionReputation;
  aiPrivacyState: AIPrivacyControlState;
  updateAIPrivacyState: (patch: Partial<AIPrivacyControlState>) => void;

  // BioEnergy & Cognitive Flow Matrix
  bioEnergyProfile: BioEnergyProfile;
  setBioEnergyProfile: React.Dispatch<React.SetStateAction<BioEnergyProfile>>;
  toggleFlowShield: () => void;
  toggleSoundscapePlay: (soundscapeName?: string) => void;
  selectSoundscape: (soundscapeId: string) => void;

  // Quantum Life Decision & Destiny Simulator
  quantumDecisions: QuantumLifeDecision[];
  setQuantumDecisions: React.Dispatch<React.SetStateAction<QuantumLifeDecision[]>>;
  activeQuantumDecisionId: string;
  setActiveQuantumDecisionId: (id: string) => void;
  selectQuantumBranch: (decisionId: string, branchId: string) => void;
  addQuantumDecision: (decision: Partial<QuantumLifeDecision>) => void;

  // Autonomous Life Agent Syndicate & Swarm
  autonomousAgents: AutonomousLifeAgent[];
  setAutonomousAgents: React.Dispatch<React.SetStateAction<AutonomousLifeAgent[]>>;
  approveAgentTask: (agentId: string, taskId: string) => void;
  rejectAgentTask: (agentId: string, taskId: string) => void;
  setAgentAutonomyLevel: (agentId: string, level: 'conservative' | 'collaborative' | 'high_agency') => void;
  triggerManualAgentSweep: (agentId: string) => void;

  // Dynamic Next-Gen Modals & Overlays
  isFutureYouModalOpen: boolean;
  setIsFutureYouModalOpen: (open: boolean) => void;
  isOpportunityExchangeModalOpen: boolean;
  setIsOpportunityExchangeModalOpen: (open: boolean) => void;
  isIdeaCollisionModalOpen: boolean;
  setIsIdeaCollisionModalOpen: (open: boolean) => void;
  isAIPrivacyCenterOpen: boolean;
  setIsAIPrivacyCenterOpen: (open: boolean) => void;
  isDataPortabilityModalOpen: boolean;
  setIsDataPortabilityModalOpen: (open: boolean) => void;
  isContextAwareChatOpen: boolean;
  setIsContextAwareChatOpen: (open: boolean) => void;
  contextAwareChatPeer: { name: string; avatar: string; sharedContext: string; matchRationale: string } | null;
  setContextAwareChatPeer: (peer: { name: string; avatar: string; sharedContext: string; matchRationale: string } | null) => void;
  isLifeOSAgentModalOpen: boolean;
  setIsLifeOSAgentModalOpen: (open: boolean) => void;
  isSerendipityModalOpen: boolean;
  setIsSerendipityModalOpen: (open: boolean) => void;
  isAnonymousWorldModalOpen: boolean;
  setIsAnonymousWorldModalOpen: (open: boolean) => void;

  // ==========================================
  // OUT-OF-STOCK ALERTS & PUSH NOTIFICATION ENGINE
  // ==========================================
  stockAlerts: StockAlertSubscription[];
  activeStockAlertProduct: Product | null;
  activeStockAlertVariantId: string | null;
  isStockAlertModalOpen: boolean;
  openStockAlertModal: (product: Product, variantId?: string) => void;
  closeStockAlertModal: () => void;
  subscribeToStockAlert: (params: {
    productId: string;
    variantId?: string;
    variantName?: string;
    color?: string;
    size?: string;
    userEmail: string;
    userPhone?: string;
    enablePush?: boolean;
    enableEmail?: boolean;
    enableWhatsapp?: boolean;
  }) => void;
  unsubscribeFromStockAlert: (productId: string, variantId?: string) => void;
  isSubscribedToStockAlert: (productId: string, variantId?: string) => boolean;
  activePushNotificationMock: PushNotificationMockData | null;
  dismissPushNotificationMock: () => void;
  simulateStockReplenishmentPush: (productId: string, variantId?: string, customQty?: number) => void;

  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Ecosystem switchers
  const [deviceMode, setDeviceMode] = useState<DeviceMode>('lifeos');
  const [themeMode, setThemeMode] = useState<ThemeMode>('light');
  const [currentRole, setCurrentRole] = useState<string>('Super Admin');
  const [currentCustomer] = useState<Customer>(INITIAL_CUSTOMERS[0]);

  // Universal Authentication & Multi-Role Session
  const [currentUserSession, setCurrentUserSession] = useState<UserSession>({
    isLoggedIn: true,
    role: 'customer',
    name: 'Priya Sharma',
    phone: '+91 98490 22334',
    email: 'priya.sharma@example.com',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
    authMethod: 'mobile_otp',
  });
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);

  // Worldwide Localization State
  const [selectedCountry, setSelectedCountry] = useState<CountryCode>('IN');
  const [selectedCurrency, setSelectedCurrency] = useState<CurrencyCode>('INR');

  const currentRegion = useMemo(() => {
    return WORLDWIDE_REGIONS[selectedCountry] || WORLDWIDE_REGIONS.IN;
  }, [selectedCountry]);

  // Sync currency automatically when country changes
  useEffect(() => {
    if (WORLDWIDE_REGIONS[selectedCountry]) {
      setSelectedCurrency(WORLDWIDE_REGIONS[selectedCountry].currency);
    }
  }, [selectedCountry]);

  // Price conversion helper
  const convertPrice = (inrAmount: number): number => {
    const rate = currentRegion.rateFromINR || 1;
    return inrAmount * rate;
  };

  const formatPrice = (inrAmount: number): string => {
    const converted = convertPrice(inrAmount);
    if (selectedCountry === 'IN') {
      return `₹${Math.round(inrAmount).toLocaleString('en-IN')}`;
    }
    return `${currentRegion.symbol}${converted.toFixed(2)}`;
  };

  // Main collections
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [banners, setBanners] = useState<Banner[]>(INITIAL_BANNERS);
  const [homepageSections, setHomepageSections] = useState<HomepageSection[]>(INITIAL_HOMEPAGE_SECTIONS);
  const [cart, setCart] = useState<CartItem[]>([
    {
      id: 'cart-init-1',
      productId: 'wi-prod-001',
      variantId: 'v-001-m-beige',
      productName: 'Artisan Linen Cuban Collar Shirt',
      brand: 'Antifly Studio',
      color: 'Oatmeal Beige',
      size: 'M',
      price: 1899,
      mrp: 2999,
      image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400&auto=format&fit=crop&q=80',
      quantity: 1,
      stock: 24,
    },
  ]);
  const [wishlist, setWishlist] = useState<string[]>(['wi-prod-001', 'wi-prod-005']);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [coupons, setCoupons] = useState<Coupon[]>(INITIAL_COUPONS);
  const [returns, setReturns] = useState<ReturnRequest[]>(INITIAL_RETURNS);
  const [refunds, setRefunds] = useState<RefundRecord[]>(INITIAL_REFUNDS);
  const [customers, setCustomers] = useState<Customer[]>(INITIAL_CUSTOMERS);
  const [abandonedCarts, setAbandonedCarts] = useState<AbandonedCart[]>(INITIAL_ABANDONED_CARTS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'notif-1',
      title: 'Order Dispatched #WI-2026-8891',
      message: 'Your Artisan Linen Cuban Collar Shirt is out for delivery with live GPS route tracking!',
      type: 'order',
      timestamp: 'Today, 07:15 AM',
      isRead: false,
      link: '/account/orders',
    },
    {
      id: 'notif-2',
      title: 'Worldwide Express Active',
      message: 'Global orders to USA, UK, EU, UAE, & Canada now feature 5-day automated refund protection.',
      type: 'promo',
      timestamp: 'Yesterday',
      isRead: true,
    },
  ]);
  const [cmsPages, setCmsPages] = useState<CMSPage[]>(INITIAL_CMS_PAGES);
  const [settings, setSettings] = useState<StoreSettings>(INITIAL_SETTINGS);
  const [gatewayKeys, setGatewayKeys] = useState<GatewayKeysConfig>(INITIAL_GATEWAY_KEYS);
  const [dataPrivacy, setDataPrivacy] = useState<DataPrivacySettings>(INITIAL_DATA_PRIVACY);
  const [activeAppliedCoupon, setActiveAppliedCoupon] = useState<{ code: string; discountAmount: number } | null>(null);

  // Modals & Panels
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAntiflyAIOpen, setIsAntiflyAIOpen] = useState(false);
  const [isVoiceSearchOpen, setIsVoiceSearchOpen] = useState(false);
  const [isImageSearchOpen, setIsImageSearchOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isNotificationDrawerOpen, setIsNotificationDrawerOpen] = useState(false);
  const [activePdpId, setActivePdpId] = useState<string | null>(null);
  const [activeTrackingOrder, setActiveTrackingOrder] = useState<Order | null>(null);
  const [activeCMSPage, setActiveCMSPage] = useState<CMSPage | null>(null);
  const [comparisonList, setComparisonList] = useState<Product[]>([]);
  const [isComparisonOpen, setIsComparisonOpen] = useState(false);

  // Live Invoice & Map Modals
  const [activeInvoiceData, setActiveInvoiceData] = useState<InvoiceData | null>(null);
  const [isLiveMapOpen, setIsLiveMapOpen] = useState(false);
  const [activeMapTracking, setActiveMapTracking] = useState<MapTrackingState | null>(null);

  // Search & Filters
  const [selectedCategorySlug, setSelectedCategorySlug] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [appliedFilters, setAppliedFilters] = useState<{
    minPrice?: number;
    maxPrice?: number;
    color?: string;
    sortBy?: string;
    tag?: string;
  }>({ sortBy: 'featured' });

  const [isOrderProcessing, setIsOrderProcessing] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Camera Creation Studio State (Snapchat + Instagram + WhatsApp + Commerce)
  const [isCameraStudioOpen, setIsCameraStudioOpen] = useState(false);
  const [cameraInitialMode, setCameraInitialMode] = useState<CameraMode>('photo');
  const [cameraTargetConversationId, setCameraTargetConversationId] = useState<string | null>(null);
  const [cameraTargetProductId, setCameraTargetProductId] = useState<string | null>(null);
  const [cameraGalleryMedia, setCameraGalleryMedia] = useState<CameraCapturedMedia[]>(INITIAL_CAMERA_GALLERY);

  // Time-Shift 3D Stories & Spatial Social State
  const [timeShiftStories, setTimeShiftStories] = useState<TimeShiftStoryItem[]>(INITIAL_TIMESHIFT_STORIES);
  const [isTimeShiftCameraOpen, setIsTimeShiftCameraOpen] = useState(false);
  const [activeTimeShiftStory, setActiveTimeShiftStory] = useState<TimeShiftStoryItem | null>(null);
  const [isTimeShiftStoryViewerOpen, setIsTimeShiftStoryViewerOpen] = useState(false);

  // New Discovery, GA4, & SEO Modals State
  const [isProductFinderOpen, setIsProductFinderOpen] = useState(false);
  const [isWhatsNewModalOpen, setIsWhatsNewModalOpen] = useState(false);
  const [isGA4ModalOpen, setIsGA4ModalOpen] = useState(false);
  const [isSEOModalOpen, setIsSEOModalOpen] = useState(false);
  const [ga4Config, setGA4Config] = useState<GA4Config>(DEFAULT_GA4_CONFIG);
  const [ga4EventLog, setGa4EventLog] = useState<GA4AnalyticsEvent[]>(() => getAnalyticsEventHistory());

  // Subscribe to live GA4 telemetry events
  useEffect(() => {
    const unsubscribe = subscribeToAnalytics((newEvent) => {
      setGa4EventLog((prev) => [newEvent, ...prev].slice(0, 100));
    });
    return unsubscribe;
  }, []);

  const trackEvent = (eventName: GA4EventName, params: any = {}) => {
    if (ga4Config.trackingEnabled) {
      trackGA4Event(eventName, params);
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Product Reviews & Customer Photo Handler
  const addProductReview = (
    productId: string,
    newRev: {
      rating: number;
      title: string;
      comment: string;
      userName: string;
      images?: string[];
      pros?: string[];
      cons?: string[];
      isVerified?: boolean;
      location?: string;
    }
  ) => {
    const createdReview: ProductReview = {
      id: `rev-${Date.now()}`,
      userId: currentCustomer.id || 'user-guest',
      userName: newRev.userName || currentCustomer.name || 'Verified Buyer',
      userAvatar:
        currentCustomer.avatar ||
        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
      rating: newRev.rating,
      title: newRev.title,
      comment: newRev.comment,
      date: 'Just now',
      verifiedPurchase: newRev.isVerified ?? true,
      isVerified: newRev.isVerified ?? true,
      location: newRev.location || 'India',
      images: newRev.images || [],
      pros: newRev.pros || [],
      cons: newRev.cons || [],
      helpfulCount: 0,
      status: 'Approved',
      featured: (newRev.images?.length || 0) > 0,
    };

    setProducts((prev) =>
      prev.map((p) => {
        if (p.id !== productId) return p;
        const existingReviews = p.reviews || getProductReviews(p.id);
        const updatedReviews = [createdReview, ...existingReviews];
        const newReviewCount = updatedReviews.length;
        const totalStars = updatedReviews.reduce((sum, r) => sum + r.rating, 0);
        const newRating = Number((totalStars / newReviewCount).toFixed(1));

        return {
          ...p,
          reviews: updatedReviews,
          rating: newRating,
          reviewCount: newReviewCount,
        };
      })
    );

    // Dispatch GA4 Telemetry
    Analytics.rateProduct(productId, productId, newRev.rating);
    showToast('🌟 Review and photos published successfully!');
  };

  const voteReviewHelpful = (productId: string, reviewId: string) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id !== productId) return p;
        const existingReviews = p.reviews || getProductReviews(p.id);
        const updatedReviews = existingReviews.map((r) =>
          r.id === reviewId ? { ...r, helpfulCount: (r.helpfulCount || 0) + 1 } : r
        );
        return { ...p, reviews: updatedReviews };
      })
    );
    showToast('👍 Marked review as helpful!');
  };

  // Enforce Light Theme cleanly
  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove('dark');
  }, [themeMode]);

  // Initial Fetch from backend API with fallback
  useEffect(() => {
    const loadServerData = async () => {
      try {
        const [prodRes, catRes, banRes, secRes, ordRes] = await Promise.all([
          fetch('/api/products').then((r) => r.json()).catch(() => null),
          fetch('/api/categories').then((r) => r.json()).catch(() => null),
          fetch('/api/banners').then((r) => r.json()).catch(() => null),
          fetch('/api/homepage-sections').then((r) => r.json()).catch(() => null),
          fetch('/api/orders').then((r) => r.json()).catch(() => null),
        ]);

        if (prodRes?.products) setProducts(prodRes.products);
        if (catRes?.categories) setCategories(catRes.categories);
        if (banRes?.banners) setBanners(banRes.banners);
        if (secRes?.sections) setHomepageSections(secRes.sections);
        if (ordRes?.orders) setOrders(ordRes.orders);
      } catch (err) {
        console.warn('Using local fallback state:', err);
      }
    };
    loadServerData();
  }, []);

  // Cart Handlers
  const addToCart = async (item: Omit<CartItem, 'id'>) => {
    try {
      const res = await fetch('/api/cart/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(item),
      });
      const data = await res.json();
      if (data.success && data.cart) {
        setCart(data.cart);
      } else {
        const existingIdx = cart.findIndex(
          (c) => c.productId === item.productId && c.variantId === item.variantId
        );
        if (existingIdx > -1) {
          const updated = [...cart];
          updated[existingIdx].quantity += item.quantity;
          setCart(updated);
        } else {
          setCart([...cart, { ...item, id: `cart-${Date.now()}` }]);
        }
      }
      showToast(`Added ${item.productName} to Cart`);
      setIsCartOpen(true);
    } catch (err) {
      console.error(err);
    }
  };

  const updateCartQuantity = async (id: string, qty: number) => {
    try {
      const res = await fetch('/api/cart/update', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, quantity: qty }),
      });
      const data = await res.json();
      if (data.success) {
        setCart(data.cart);
      } else {
        if (qty <= 0) {
          setCart(cart.filter((c) => c.id !== id));
        } else {
          setCart(cart.map((c) => (c.id === id ? { ...c, quantity: qty } : c)));
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  const removeFromCart = async (id: string) => {
    try {
      const res = await fetch(`/api/cart/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) setCart(data.cart);
      else setCart(cart.filter((c) => c.id !== id));
      showToast('Item removed from cart');
    } catch (err) {
      console.error(err);
    }
  };

  const clearCart = async () => {
    try {
      await fetch('/api/cart/clear', { method: 'POST' });
      setCart([]);
    } catch (err) {
      console.error(err);
    }
  };

  // Wishlist
  const isInWishlist = (productId: string) => {
    return wishlist.includes(productId);
  };

  const toggleWishlist = async (productId: string) => {
    try {
      const res = await fetch('/api/wishlist/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId }),
      });
      const data = await res.json();
      if (data.success) {
        setWishlist(data.wishlist);
        showToast(data.isInWishlist ? 'Saved to Wishlist' : 'Removed from Wishlist');
      } else {
        if (wishlist.includes(productId)) {
          setWishlist(wishlist.filter((id) => id !== productId));
          showToast('Removed from Wishlist');
        } else {
          setWishlist([...wishlist, productId]);
          showToast('Saved to Wishlist');
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Coupons
  const applyCouponCode = async (code: string) => {
    const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const source: OrderSource =
      deviceMode === 'mobile-android' ? 'Android App' : deviceMode === 'mobile-ios' ? 'iOS App' : 'Website';

    try {
      const res = await fetch('/api/coupons/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, cartTotal: subtotal, source, items: cart }),
      });
      const data = await res.json();
      if (data.success) {
        setActiveAppliedCoupon({ code: data.coupon.code, discountAmount: data.discountAmount });
        showToast(data.message);
        return { success: true, message: data.message };
      } else {
        // Fallback local evaluation if backend route unavailable
        const matched = coupons.find(
          (c) => c.code.toUpperCase() === String(code).trim().toUpperCase() && c.isActive
        );
        if (matched) {
          let discountBase = subtotal;
          if (matched.applicableProductIds && matched.applicableProductIds.length > 0) {
            const applicableItems = cart.filter((i) => matched.applicableProductIds?.includes(i.productId));
            if (applicableItems.length > 0) {
              discountBase = applicableItems.reduce((s, i) => s + i.price * i.quantity, 0);
            }
          }
          let disc = 0;
          if (matched.discountType === 'percentage') {
            disc = Math.round((discountBase * matched.discountValue) / 100);
            if (matched.maxDiscount) disc = Math.min(disc, matched.maxDiscount);
          } else {
            disc = Math.min(discountBase, matched.discountValue);
          }
          setActiveAppliedCoupon({ code: matched.code, discountAmount: disc });
          showToast(`Coupon ${matched.code} applied! Saved ₹${disc}`);
          return { success: true, message: `Coupon ${matched.code} applied! Saved ₹${disc}` };
        }
        return { success: false, message: data.message || 'Invalid or expired coupon code.' };
      }
    } catch (err: any) {
      // Local fallback
      const matched = coupons.find(
        (c) => c.code.toUpperCase() === String(code).trim().toUpperCase() && c.isActive
      );
      if (matched) {
        let discountBase = subtotal;
        if (matched.applicableProductIds && matched.applicableProductIds.length > 0) {
          const applicableItems = cart.filter((i) => matched.applicableProductIds?.includes(i.productId));
          if (applicableItems.length > 0) {
            discountBase = applicableItems.reduce((s, i) => s + i.price * i.quantity, 0);
          }
        }
        let disc = 0;
        if (matched.discountType === 'percentage') {
          disc = Math.round((discountBase * matched.discountValue) / 100);
          if (matched.maxDiscount) disc = Math.min(disc, matched.maxDiscount);
        } else {
          disc = Math.min(discountBase, matched.discountValue);
        }
        setActiveAppliedCoupon({ code: matched.code, discountAmount: disc });
        showToast(`Coupon ${matched.code} applied! Saved ₹${disc}`);
        return { success: true, message: `Coupon ${matched.code} applied!` };
      }
      return { success: false, message: err.message || 'Failed to apply coupon' };
    }
  };

  const removeCoupon = () => {
    setActiveAppliedCoupon(null);
    showToast('Coupon removed');
  };

  // High-Volume Anti-Collapsing Order Engine
  const placeOrder = async (orderData: any) => {
    if (isOrderProcessing) {
      throw new Error('Order is currently being processed. Please wait a moment.');
    }
    setIsOrderProcessing(true);

    try {
      const source: OrderSource =
        deviceMode === 'mobile-android' ? 'Android App' : deviceMode === 'mobile-ios' ? 'iOS App' : 'Website';

      const generatedOtp = Math.floor(1000 + Math.random() * 9000).toString();

      const payload = {
        ...orderData,
        source,
        deliveryOtp: generatedOtp,
        customerId: currentCustomer.id,
        customerName: orderData.shippingAddress?.fullName || currentCustomer.name,
        customerEmail: currentCustomer.email,
        customerPhone: orderData.shippingAddress?.phone || currentCustomer.phone,
        couponCode: activeAppliedCoupon?.code,
        courierName: currentRegion.defaultCourier,
        trackingNumber: `TRK-${selectedCountry}-${Math.floor(10000000 + Math.random() * 90000000)}`,
      };

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.success) {
        const confirmedOrder: Order = {
          ...data.order,
          deliveryOtp: generatedOtp,
        };

        // Check if Seller Admin Fee is applicable (₹1 per order from seller coupon or cross-application order)
        const usedCoupon = coupons.find(
          (c) => c.code.toUpperCase() === String(confirmedOrder.couponCode || '').toUpperCase()
        );
        const isSellerOrExternal =
          Boolean(usedCoupon?.isSellerCoupon) ||
          Boolean(confirmedOrder.isExternalAppOrder) ||
          Boolean(confirmedOrder.adminPlatformFee) ||
          source !== 'Website';

        if (isSellerOrExternal) {
          const sellerId = usedCoupon?.sellerId || confirmedOrder.sellerId || currentSeller.id;
          const sellerName = usedCoupon?.sellerName || confirmedOrder.sellerName || currentSeller.storeName;
          const originApp = confirmedOrder.originApp || (source === 'Website' ? 'Cross-App Buyer Web' : `${source} Partner App`);

          confirmedOrder.adminPlatformFee = 1.0;
          confirmedOrder.adminPlatformFeeStatus = 'Auto-Deducted';
          confirmedOrder.sellerId = sellerId;
          confirmedOrder.sellerName = sellerName;
          confirmedOrder.originApp = originApp;

          const feeLog: SellerAdminFeeRecord = {
            id: `fee-log-${Date.now()}`,
            orderId: confirmedOrder.id,
            orderNumber: confirmedOrder.orderNumber,
            sellerId,
            sellerName,
            originApp,
            productName: confirmedOrder.items[0]?.productName || 'Artisan Marketplace Product',
            couponCode: confirmedOrder.couponCode,
            adminFee: 1.0,
            date: new Date().toISOString().replace('T', ' ').slice(0, 16),
            status: 'Auto-Deducted',
          };

          setSellerAdminFeeLedger((prev) => [feeLog, ...prev]);

          // Deduct ₹1 admin fee from seller's balance & update seller metrics vice-versa
          setSellers((prev) =>
            prev.map((s) =>
              s.id === sellerId
                ? {
                    ...s,
                    balanceAvailable: Math.max(0, Number((s.balanceAvailable - 1).toFixed(2))),
                    totalOrders: s.totalOrders + 1,
                  }
                : s
            )
          );
        }

        // Dynamically instantiate Driver Delivery Task
        const newDriverTask: DriverDeliveryTask = {
          id: `TASK-${confirmedOrder.orderNumber.replace(/[^0-9]/g, '').slice(-5) || Math.floor(10000 + Math.random() * 90000)}`,
          orderId: confirmedOrder.id,
          trackingNumber: confirmedOrder.trackingNumber || confirmedOrder.orderNumber,
          customerName: confirmedOrder.customerName,
          customerPhone: confirmedOrder.customerPhone,
          customerAddress: `${confirmedOrder.shippingAddress.street}, ${confirmedOrder.shippingAddress.city} - ${confirmedOrder.shippingAddress.pincode}`,
          sellerName: 'Antifly Mega Fulfillment Center',
          sellerAddress: 'Warehouse 4B, Electronic City Phase 1, Bengaluru',
          pickupLat: 12.9716,
          pickupLng: 77.5946,
          dropLat: 12.9352,
          dropLng: 77.6245,
          status: 'Assigned',
          itemsCount: confirmedOrder.items.reduce((s: number, i: any) => s + i.quantity, 0),
          payoutFee: Math.floor(75 + Math.random() * 35),
          tipAmount: 20,
          estimatedMinutes: 25,
          distanceKm: 4.2,
          specialInstructions: 'Deliver to customer doorstep / verify OTP handover',
          otpCode: generatedOtp,
          paymentMode: confirmedOrder.paymentMethod === 'Cash on Delivery' ? 'COD' : 'PREPAID',
          codAmountToCollect: confirmedOrder.paymentMethod === 'Cash on Delivery' ? confirmedOrder.totalAmount : 0,
        };

        setDriverTasks((prev) => [newDriverTask, ...prev]);
        setOrders([confirmedOrder, ...orders]);
        setCart([]);
        setActiveAppliedCoupon(null);

        // SuperCoins loyalty cashback
        const coinsEarned = Math.max(10, Math.floor((confirmedOrder.totalAmount / 100) * (isPlusMember ? 4 : 2)));
        setSuperCoinsBalance((prev) => prev + coinsEarned);
        setSuperCoinTransactions((prev) => [
          {
            id: `sctx-${Date.now()}`,
            type: 'Earned',
            amount: coinsEarned,
            description: `Cashback on Order #${confirmedOrder.orderNumber}`,
            date: new Date().toISOString().split('T')[0],
          },
          ...prev,
        ]);

        // Reseller Margin Earning attribution if Reselling mode is enabled
        if (resellerConfig.isReselling || orderData.isResellingOrder) {
          const marginRate = (resellerConfig.resellerMarginPercentage || 20) / 100;
          const calculatedMargin = Math.round(confirmedOrder.subtotal * marginRate);
          const resellerRecord: ResellerEarningRecord = {
            id: `earn-${Date.now()}`,
            orderNumber: confirmedOrder.orderNumber,
            productName: confirmedOrder.items[0]?.productName || 'Marketplace Order',
            wholesalePrice: confirmedOrder.subtotal,
            sellingPrice: confirmedOrder.subtotal + calculatedMargin,
            marginEarned: calculatedMargin,
            customerName: confirmedOrder.customerName,
            status: 'Credited',
            date: new Date().toISOString().split('T')[0],
          };

          setResellerEarnings((prev) => [resellerRecord, ...prev]);
          setResellerConfig((prev) => ({
            ...prev,
            totalEarnings: prev.totalEarnings + calculatedMargin,
            pendingEarnings: prev.pendingEarnings + calculatedMargin,
          }));
          showToast(`💰 Reseller Profit: ₹${calculatedMargin.toLocaleString('en-IN')} added to your Reseller Wallet!`);
        }

        setNotifications([
          {
            id: `notif-${Date.now()}`,
            title: `Order Placed #${confirmedOrder.orderNumber}`,
            message: `Your ${currentRegion.name} order for ${formatPrice(confirmedOrder.totalAmount)} has been confirmed! Earned +${coinsEarned} ZoloCoins. Delivery OTP: ${generatedOtp}`,
            type: 'order',
            timestamp: 'Just now',
            isRead: false,
            link: '/account/orders',
          },
          ...notifications,
        ]);
        return confirmedOrder;
      }
      throw new Error(data.message || 'Order creation failed');
    } finally {
      setIsOrderProcessing(false);
    }
  };

  // Automated 5-Day SLA Cancellation & Refund Workflow
  const cancelOrderAndInitiateRefund = async (orderId: string, reason: string) => {
    const targetOrder = orders.find((o) => o.id === orderId);
    if (!targetOrder) throw new Error('Order not found');

    const refundId = `ref-${Date.now()}`;
    const today = new Date();
    const day5Date = new Date();
    day5Date.setDate(today.getDate() + 5);

    const newRefund: RefundRecord = {
      id: refundId,
      orderId: targetOrder.id,
      orderNumber: targetOrder.orderNumber,
      customerName: targetOrder.customerName,
      customerEmail: targetOrder.customerEmail,
      amount: targetOrder.totalAmount,
      currency: selectedCurrency,
      paymentMethod: targetOrder.paymentMethod,
      initiatedAt: `${today.toISOString().split('T')[0]} ${today.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
      expectedCreditDate: `${day5Date.toISOString().split('T')[0]} (5-Day SLA)`,
      currentDay: 1,
      status: 'Initiated',
      bankReferenceNumber: `ARN-${Date.now().toString().slice(-8)}-${Math.floor(1000 + Math.random() * 9000)}`,
      refundReason: reason,
      destinationAccount: `${targetOrder.paymentMethod} (Refund routing active)`,
      dayLog: [
        { day: 1, title: 'Day 1: Refund Initiated & Order Cancelled', desc: `Merchant approved full refund of ${formatPrice(targetOrder.totalAmount)}. Order moved to Cancelled.`, date: today.toISOString().split('T')[0], isComplete: true },
        { day: 2, title: 'Day 2: Bank Merchant Verification', desc: 'Merchant bank validates transaction reversal ledger and releases funds reserve.', date: 'Scheduled Day 2', isComplete: false },
        { day: 3, title: 'Day 3: Gateway Clearance & Network Routing', desc: 'Stripe / NPCI / Visa / Mastercard clearing network handles switch routing.', date: 'Scheduled Day 3', isComplete: false },
        { day: 4, title: 'Day 4: Beneficiary Bank Settlement Batch', desc: 'Customer receiving bank central node accepts interbank credit batch.', date: 'Scheduled Day 4', isComplete: false },
        { day: 5, title: 'Day 5: Guaranteed Account Credit (5-Day SLA)', desc: 'Funds credited to customer bank account / card with UTR statement reference.', date: day5Date.toISOString().split('T')[0], isComplete: false },
      ],
    };

    setRefunds([newRefund, ...refunds]);
    setOrders(orders.map((o) => (o.id === orderId ? { ...o, status: 'Cancelled' } : o)));

    showToast(`Order Cancelled. 5-Day SLA Refund #${newRefund.id} Initiated.`);
    return newRefund;
  };

  const advanceRefundStep = async (refundId: string) => {
    setRefunds((prev) =>
      prev.map((r) => {
        if (r.id !== refundId) return r;
        const nextDay = Math.min(5, r.currentDay + 1);
        const nextStatus =
          nextDay === 2
            ? 'Bank_Processing'
            : nextDay === 3
            ? 'Gateway_Clearance'
            : nextDay === 4
            ? 'Settlement_Scheduled'
            : 'Credited';

        const updatedLog = r.dayLog.map((log) =>
          log.day <= nextDay ? { ...log, isComplete: true, date: log.date.includes('Scheduled') ? new Date().toISOString().split('T')[0] : log.date } : log
        );

        return {
          ...r,
          currentDay: nextDay,
          status: nextStatus,
          dayLog: updatedLog,
        };
      })
    );
    showToast('Refund SLA status advanced to next working day.');
  };

  // Bulk Operations for High Volume (Thousands of orders/day)
  const bulkUpdateOrders = async (orderIds: string[], status: OrderStatus) => {
    setOrders((prev) =>
      prev.map((o) => (orderIds.includes(o.id) ? { ...o, status } : o))
    );
    showToast(`Bulk updated ${orderIds.length} orders to ${status}`);
  };

  const bulkGenerateInvoices = async (orderIds: string[]) => {
    showToast(`Generated and packaged ${orderIds.length} printable tax invoices`);
  };

  // View Invoice
  const viewOrderInvoice = (order: Order) => {
    const isDomestic = selectedCountry === 'IN';
    const taxName = isDomestic ? 'GST (12%)' : currentRegion.taxName;
    const inv: InvoiceData = {
      invoiceNumber: `INV-${selectedCountry}-${order.orderNumber.replace('ORD-', '')}`,
      orderNumber: order.orderNumber,
      invoiceDate: order.createdAt.split(' ')[0] || new Date().toISOString().split('T')[0],
      orderDate: order.createdAt,
      sellerDetails: {
        name: 'Antifly Worldwide Commerce Corp',
        tradeName: 'Antifly Global Brands Ltd',
        gstinOrVat: isDomestic ? '29AAAAA0000A1Z5' : `US-EIN-98-1928371 / VAT-GB901829`,
        pan: 'AAACW9988C',
        cin: 'U72900KA2026PTC109823',
        address: `${isDomestic ? 'Commerce Tower 9, Bengaluru, Karnataka 560001, India' : '450 Lexington Ave, New York, NY 10017, USA'}`,
        phone: settings.contactPhone,
        email: settings.contactEmail,
      },
      buyerDetails: {
        name: order.customerName,
        address: `${order.shippingAddress.street}${order.shippingAddress.apartment ? ', ' + order.shippingAddress.apartment : ''}`,
        city: order.shippingAddress.city,
        state: order.shippingAddress.state,
        pincode: order.shippingAddress.pincode,
        country: order.shippingAddress.country || currentRegion.name,
        phone: order.customerPhone,
        email: order.customerEmail,
      },
      items: order.items.map((i) => ({
        name: i.productName,
        sku: `${i.brand.slice(0, 3).toUpperCase()}-${i.size}-${i.color.slice(0, 3).toUpperCase()}`,
        hsnCode: isDomestic ? '6205.20.00' : 'HS-620520',
        quantity: i.quantity,
        unitPrice: i.price,
        taxRate: currentRegion.taxRate * 100,
        taxAmount: Math.round(i.price * i.quantity * currentRegion.taxRate),
        total: Math.round(i.price * i.quantity * (1 + currentRegion.taxRate)),
      })),
      subtotal: order.subtotal,
      taxTotal: order.tax || Math.round(order.subtotal * currentRegion.taxRate),
      taxLabel: taxName,
      shippingFee: order.shippingFee,
      discount: order.discount,
      grandTotal: order.totalAmount,
      currency: selectedCurrency,
      currencySymbol: currentRegion.symbol,
      paymentMethod: order.paymentMethod,
      paymentStatus: order.paymentStatus,
      irnNumber: `IRN-${Math.random().toString(36).substring(2, 15).toUpperCase()}`,
      qrCodeUrl: `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://antifly.com/verify-invoice/${order.orderNumber}`,
    };

    setActiveInvoiceData(inv);
  };

  // Open Live Map Tracking for Order
  const openLiveMapForOrder = (order: Order) => {
    const isUS = selectedCountry === 'US';
    const trackingState: MapTrackingState = {
      orderId: order.id,
      courierName: order.courierName || currentRegion.defaultCourier,
      trackingNumber: order.trackingNumber || `TRK-${selectedCountry}-${Math.floor(10000000 + Math.random() * 90000000)}`,
      riderName: isUS ? 'David Miller' : 'Rajesh Kumar',
      riderPhone: isUS ? '+1 (415) 890-1290' : '+91 98765 43210',
      vehicleNumber: isUS ? 'FEDEX-VAN-908' : 'KA-01-EQ-9812',
      vehicleType: isUS ? 'van' : 'bike',
      currentStepIndex: order.status === 'Delivered' ? 3 : order.status === 'Out for delivery' ? 2 : order.status === 'Shipped' ? 1 : 0,
      originHub: {
        name: isUS ? 'JFK International Fulfillment Center' : 'Bengaluru Central Mega Warehouse',
        city: isUS ? 'New York, NY' : 'Bengaluru, KA',
        lat: isUS ? 40.6413 : 12.9716,
        lng: isUS ? -73.7781 : 77.5946,
      },
      transitHub: {
        name: isUS ? 'Chicago Logistics Air Hub' : 'Mumbai Regional Sort Center',
        city: isUS ? 'Chicago, IL' : 'Mumbai, MH',
        lat: isUS ? 41.8781 : 19.076,
        lng: isUS ? -87.6298 : 72.8777,
      },
      deliveryHub: {
        name: isUS ? 'San Francisco Local Dispatch Center' : 'Bandra West Local Hub',
        city: isUS ? 'San Francisco, CA' : 'Mumbai, MH',
        lat: isUS ? 37.7749 : 19.0596,
        lng: isUS ? -122.4194 : 72.8295,
      },
      destination: {
        name: `${order.shippingAddress.fullName}'s Doorstep`,
        city: `${order.shippingAddress.city}, ${order.shippingAddress.state}`,
        lat: isUS ? 37.7833 : 19.065,
        lng: isUS ? -122.4167 : 72.835,
      },
      currentLocation: {
        lat: isUS ? 37.779 : 19.062,
        lng: isUS ? -122.418 : 72.832,
        address: isUS ? 'On Route - 4th Street, San Francisco' : 'On Route - Hill Road, Bandra West',
      },
      etaMinutes: 24,
    };

    setActiveMapTracking(trackingState);
    setIsLiveMapOpen(true);
  };

  const updateOrderStatus = async (orderId: string, status: Order['status'], courier?: string, tracking?: string) => {
    const res = await fetch(`/api/orders/${orderId}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, courierName: courier, trackingNumber: tracking }),
    });
    const data = await res.json();
    if (data.success) {
      setOrders(orders.map((o) => (o.id === orderId ? data.order : o)));
      showToast(`Order status updated to ${status}`);
    }
  };

  // Returns
  const submitReturnRequest = async (returnData: any) => {
    const res = await fetch('/api/returns', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(returnData),
    });
    const data = await res.json();
    if (data.success) {
      setReturns([data.returnRequest, ...returns]);
      setOrders(
        orders.map((o) => (o.id === returnData.orderId ? { ...o, returnStatus: 'Requested' } : o))
      );
      showToast('Return & Exchange request submitted successfully.');
    }
  };

  const updateReturnStatus = async (returnId: string, status: ReturnRequest['status']) => {
    const res = await fetch(`/api/returns/${returnId}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    const data = await res.json();
    if (data.success) {
      setReturns(returns.map((r) => (r.id === returnId ? data.returnRequest : r)));
      showToast(`Return request updated to ${status}`);
    }
  };

  // Product Admin
  const saveProduct = async (productData: Partial<Product>) => {
    if (productData.id) {
      const res = await fetch(`/api/products/${productData.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productData),
      });
      const data = await res.json();
      if (data.success) {
        setProducts(products.map((p) => (p.id === productData.id ? data.product : p)));
        showToast('Product updated successfully');
      }
    } else {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productData),
      });
      const data = await res.json();
      if (data.success) {
        setProducts([data.product, ...products]);
        showToast('New product added to catalog');
      }
    }
  };

  const deleteProduct = async (id: string) => {
    const res = await fetch(`/api/products/${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (data.success) {
      setProducts(products.filter((p) => p.id !== id));
      showToast('Product deleted');
    }
  };

  // Banner Admin
  const saveBanner = async (bannerData: Partial<Banner>) => {
    if (bannerData.id) {
      const res = await fetch(`/api/banners/${bannerData.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bannerData),
      });
      const data = await res.json();
      if (data.success) {
        setBanners(banners.map((b) => (b.id === bannerData.id ? data.banner : b)));
        showToast('Banner updated');
      }
    } else {
      const res = await fetch('/api/banners', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bannerData),
      });
      const data = await res.json();
      if (data.success) {
        setBanners([...banners, data.banner]);
        showToast('Banner created');
      }
    }
  };

  const deleteBanner = async (id: string) => {
    const res = await fetch(`/api/banners/${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (data.success) {
      setBanners(banners.filter((b) => b.id !== id));
      showToast('Banner removed');
    }
  };

  // Homepage Sections Admin
  const updateHomepageSections = async (sections: HomepageSection[]) => {
    setHomepageSections(sections);
    const res = await fetch('/api/homepage-sections', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sections }),
    });
    const data = await res.json();
    if (data.success) {
      showToast('Homepage layout published');
    }
  };

  // Settings & Gateways & Privacy
  const updateSettings = async (newSettings: Partial<StoreSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
    showToast('Store settings updated');
  };

  const updateGatewayKeys = async (newKeys: Partial<GatewayKeysConfig>) => {
    setGatewayKeys((prev) => ({ ...prev, ...newKeys }));
    showToast('Payment & SMS Gateway keys securely updated');
  };

  const updateDataPrivacy = async (newPrivacy: Partial<DataPrivacySettings>) => {
    setDataPrivacy((prev) => ({ ...prev, ...newPrivacy }));
    showToast('Data Privacy & GDPR/DPDP policies updated');
  };

  const updateCMSPage = async (slug: string, content: string, title?: string) => {
    const res = await fetch(`/api/cms-pages/${slug}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content, title }),
    });
    const data = await res.json();
    if (data.success) {
      setCmsPages(cmsPages.map((p) => (p.slug === slug ? data.page : p)));
      showToast(`CMS page updated: ${data.page.title}`);
    }
  };

  const sendAbandonedCartReminder = async (id: string) => {
    const res = await fetch(`/api/abandoned-carts/${id}/remind`, { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      setAbandonedCarts(abandonedCarts.map((a) => (a.id === id ? data.abandonedCart : a)));
      showToast('Recovery push notification & SMS dispatched');
    }
  };

  const markNotificationsAsRead = async () => {
    setNotifications(notifications.map((n) => ({ ...n, isRead: true })));
    fetch('/api/notifications/mark-read', { method: 'PATCH' });
  };

  // Comparison
  const addToComparison = (product: Product) => {
    if (comparisonList.some((p) => p.id === product.id)) {
      showToast('Product already in comparison list');
      return;
    }
    if (comparisonList.length >= 3) {
      showToast('You can compare up to 3 products at a time');
      return;
    }
    setComparisonList([...comparisonList, product]);
    showToast(`Added ${product.name} to comparison`);
    setIsComparisonOpen(true);
  };

  const removeFromComparison = (productId: string) => {
    setComparisonList(comparisonList.filter((p) => p.id !== productId));
  };

  const clearComparison = () => {
    setComparisonList([]);
  };

  // ==========================================
  // FLIPKART SUPERCOIN & PLUS VIP SYSTEM
  // ==========================================
  const [superCoinsBalance, setSuperCoinsBalance] = useState<number>(520);
  const [superCoinRewards, setSuperCoinRewards] = useState<SuperCoinReward[]>(INITIAL_SUPER_COIN_REWARDS);
  const [superCoinTransactions, setSuperCoinTransactions] = useState<SuperCoinTransaction[]>(INITIAL_SUPER_COIN_TRANSACTIONS);
  const [isSuperCoinsModalOpen, setIsSuperCoinsModalOpen] = useState<boolean>(false);
  const [useSuperCoinsAtCheckout, setUseSuperCoinsAtCheckout] = useState<boolean>(false);
  const isPlusMember = true;

  const redeemSuperCoinReward = async (rewardId: string) => {
    const reward = superCoinRewards.find((r) => r.id === rewardId);
    if (!reward) return;
    if (superCoinsBalance < reward.coinsCost) {
      showToast(`Insufficient SuperCoins! You need ${reward.coinsCost - superCoinsBalance} more coins.`);
      return;
    }

    setSuperCoinsBalance((prev) => prev - reward.coinsCost);
    const newTx: SuperCoinTransaction = {
      id: `sct-${Date.now()}`,
      type: 'Spent',
      amount: reward.coinsCost,
      description: `Redeemed ${reward.title} (${reward.partnerBrand})`,
      date: new Date().toISOString().split('T')[0],
    };
    setSuperCoinTransactions((prev) => [newTx, ...prev]);
    showToast(`🎉 Reward Claimed! Voucher code generated for ${reward.title}`);
  };

  // ==========================================
  // MEESHO RESELLING & GROUP BUYS
  // ==========================================
  const [resellerConfig, setResellerConfig] = useState<ResellerConfig>({
    isReselling: false,
    resellerShopName: 'Aura Boutique & Crafts',
    resellerPhone: '+91 98765 43210',
    resellerMarginPercentage: 25,
    totalEarnings: 4850,
    withdrawnEarnings: 3200,
    pendingEarnings: 1650,
  });
  const [isResellerModalOpen, setIsResellerModalOpen] = useState<boolean>(false);
  const [groupBuyDeals, setGroupBuyDeals] = useState<GroupBuyDeal[]>(INITIAL_GROUP_BUYS);
  const [isGroupBuyModalOpen, setIsGroupBuyModalOpen] = useState<boolean>(false);
  const [meeshoReturnChoice, setMeeshoReturnChoice] = useState<'easy_return' | 'wrong_defective_only'>('easy_return');

  const joinGroupBuy = async (dealId: string) => {
    const deal = groupBuyDeals.find((d) => d.id === dealId);
    if (!deal) return;

    // Find the product
    const targetProduct = products.find((p) => p.id === deal.productId) || products[0];
    await addToCart({
      productId: targetProduct.id,
      variantId: targetProduct.variants[0]?.id || 'group-buy',
      productName: `[Group Buy - ${deal.groupCode}] ${deal.productName}`,
      brand: targetProduct.brand,
      color: targetProduct.colors[0]?.name || 'Standard',
      size: targetProduct.sizes[0] || 'Standard',
      price: deal.groupPrice,
      mrp: deal.originalPrice,
      image: deal.productImage,
      quantity: 1,
      stock: 10,
    });

    setGroupBuyDeals((prev) =>
      prev.map((g) =>
        g.id === dealId
          ? { ...g, currentMembers: Math.min(g.requiredMembers, g.currentMembers + 1) }
          : g
      )
    );
    showToast(`👥 Joined ${deal.leaderName}'s team! You saved ₹${deal.savings} with Group Price.`);
    setIsGroupBuyModalOpen(false);
  };

  // ==========================================
  // MYNTRA STUDIO / STYLECAST & SIZE ASSISTANT
  // ==========================================
  const [styleCastLooks, setStyleCastLooks] = useState<StyleCastLook[]>(INITIAL_STYLECAST_LOOKS);
  const [activeStyleLook, setActiveStyleLook] = useState<StyleCastLook | null>(null);
  const [isStyleCastModalOpen, setIsStyleCastModalOpen] = useState<boolean>(false);
  const [lookBundles] = useState<CompleteTheLookBundle[]>(INITIAL_LOOK_BUNDLES);
  const [isSizeAssistantOpen, setIsSizeAssistantOpen] = useState<boolean>(false);
  const [priceDropWatchlist, setPriceDropWatchlist] = useState<string[]>(['prod-001']);

  const [sizeProfile, setSizeProfile] = useState<SizeRecommendationProfile>({
    heightCm: 175,
    weightKg: 72,
    bodyType: 'Average',
    fitPreference: 'Regular',
    recommendedSize: 'L',
    confidenceScore: 89,
    matchedShoppersCount: 4280,
  });

  const calculateRecommendedSize = (
    heightCm: number,
    weightKg: number,
    bodyType: string,
    fit: string
  ): string => {
    const bmi = weightKg / ((heightCm / 100) * (heightCm / 100));
    let base = 'M';
    if (bmi < 19) base = 'S';
    else if (bmi < 24) base = 'M';
    else if (bmi < 28) base = 'L';
    else if (bmi < 32) base = 'XL';
    else base = 'XXL';

    if (fit.includes('Relaxed') || fit.includes('Oversized') || bodyType === 'Broad') {
      const sizes = ['S', 'M', 'L', 'XL', 'XXL'];
      const idx = sizes.indexOf(base);
      if (idx < sizes.length - 1) base = sizes[idx + 1];
    } else if (fit.includes('Fitted') || bodyType === 'Slim') {
      const sizes = ['S', 'M', 'L', 'XL', 'XXL'];
      const idx = sizes.indexOf(base);
      if (idx > 0) base = sizes[idx - 1];
    }

    setSizeProfile({
      heightCm,
      weightKg,
      bodyType: bodyType as any,
      fitPreference: fit as any,
      recommendedSize: base,
      confidenceScore: Math.floor(Math.random() * 8) + 88,
      matchedShoppersCount: Math.floor(Math.random() * 1500) + 3200,
    });
    return base;
  };

  const togglePriceDropAlert = (productId: string) => {
    const isCurrentlyWatched = priceDropWatchlist.includes(productId);
    const targetProd = products.find((p) => p.id === productId);

    if (isCurrentlyWatched) {
      setPriceDropWatchlist((prev) => prev.filter((id) => id !== productId));
      showToast(`🔕 Price-drop alerts paused for ${targetProd?.name || 'Product'}`);
    } else {
      setPriceDropWatchlist((prev) => [...prev, productId]);
      showToast(`🔔 Price Drop Alert Activated for ${targetProd?.name || 'Product'}! We will notify you when price drops.`);
    }

    setWishlistDetails((prev) => {
      const existing = prev[productId];
      const nextState = !isCurrentlyWatched;
      return {
        ...prev,
        [productId]: {
          ...(existing || {
            productId,
            addedAt: 'Today',
            originalPrice: targetProd?.mrp || 1999,
            currentPrice: targetProd?.price || 1499,
            smartState: 'normal',
            stockCount: targetProd?.totalStock || 10,
          }),
          priceDropAlertEnabled: nextState,
        },
      };
    });
  };

  const addBundleToCart = async (bundleId: string) => {
    const bundle = lookBundles.find((b) => b.id === bundleId);
    if (!bundle) return;

    const allProductIds = [bundle.mainProductId, ...bundle.pairedProductIds];
    const matchingProducts = products.filter((p) => allProductIds.includes(p.id));

    for (const prod of matchingProducts) {
      const discountedPrice = Math.round(prod.price * (1 - bundle.bundleDiscountPercent / 100));
      await addToCart({
        productId: prod.id,
        variantId: prod.variants[0]?.id || 'bundle-item',
        productName: `[Look Bundle: ${bundle.title}] ${prod.name}`,
        brand: prod.brand,
        color: prod.colors[0]?.name || 'Standard',
        size: prod.sizes[0] || 'M',
        price: discountedPrice,
        mrp: prod.mrp,
        image: prod.images[0],
        quantity: 1,
        stock: 15,
      });
    }

    showToast(`✨ Added Complete Look to Bag! Saved ${bundle.bundleDiscountPercent}% bundle discount.`);
  };

  // ==========================================
  // OUT-OF-STOCK ALERTS & PUSH NOTIFICATION ENGINE
  // ==========================================
  const [stockAlerts, setStockAlerts] = useState<StockAlertSubscription[]>(() => {
    try {
      const saved = localStorage.getItem('antifly_stock_alerts');
      return saved
        ? JSON.parse(saved)
        : [
            {
              id: 'alert-sample-1',
              productId: 'wi-prod-003',
              variantName: 'Warm Caramel / S',
              color: 'Warm Caramel',
              size: 'S',
              userEmail: 'infotime.contact@gmail.com',
              userPhone: '+91 98490 22334',
              enablePush: true,
              enableEmail: true,
              enableWhatsapp: true,
              subscribedAt: 'Yesterday, 4:30 PM',
              productName: 'Raw Silk Fusion Trench Dress',
              productImage:
                'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=900&auto=format&fit=crop&q=80',
              productPrice: 3299,
              brand: 'Antifly Atelier',
              status: 'active',
            },
          ];
    } catch {
      return [];
    }
  });

  const [activeStockAlertProduct, setActiveStockAlertProduct] = useState<Product | null>(null);
  const [activeStockAlertVariantId, setActiveStockAlertVariantId] = useState<string | null>(null);
  const [isStockAlertModalOpen, setIsStockAlertModalOpen] = useState<boolean>(false);
  const [activePushNotificationMock, setActivePushNotificationMock] =
    useState<PushNotificationMockData | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('antifly_stock_alerts', JSON.stringify(stockAlerts));
    } catch (e) {
      console.error('Failed saving stock alerts', e);
    }
  }, [stockAlerts]);

  const openStockAlertModal = (product: Product, variantId?: string) => {
    setActiveStockAlertProduct(product);
    setActiveStockAlertVariantId(variantId || product.variants[0]?.id || null);
    setIsStockAlertModalOpen(true);
  };

  const closeStockAlertModal = () => {
    setIsStockAlertModalOpen(false);
    setActiveStockAlertProduct(null);
    setActiveStockAlertVariantId(null);
  };

  const isSubscribedToStockAlert = (productId: string, variantId?: string): boolean => {
    return stockAlerts.some(
      (a) =>
        a.productId === productId &&
        (variantId ? a.variantId === variantId || !a.variantId : true) &&
        a.status === 'active'
    );
  };

  const subscribeToStockAlert = (params: {
    productId: string;
    variantId?: string;
    variantName?: string;
    color?: string;
    size?: string;
    userEmail: string;
    userPhone?: string;
    enablePush?: boolean;
    enableEmail?: boolean;
    enableWhatsapp?: boolean;
  }) => {
    const targetProduct =
      products.find((p) => p.id === params.productId) || activeStockAlertProduct;
    if (!targetProduct) return;

    const newSub: StockAlertSubscription = {
      id: `alert-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      productId: params.productId,
      variantId: params.variantId,
      variantName:
        params.variantName ||
        (params.size ? `Size ${params.size}` : params.color ? `Color ${params.color}` : 'All Variants'),
      color: params.color,
      size: params.size,
      userEmail: params.userEmail || currentUserSession.email || 'infotime.contact@gmail.com',
      userPhone: params.userPhone || currentUserSession.phone,
      enablePush: params.enablePush ?? true,
      enableEmail: params.enableEmail ?? true,
      enableWhatsapp: params.enableWhatsapp ?? false,
      subscribedAt: 'Just now',
      productName: targetProduct.name,
      productImage: targetProduct.images[0] || '',
      productPrice: targetProduct.price,
      brand: targetProduct.brand,
      status: 'active',
    };

    setStockAlerts((prev) => [
      newSub,
      ...prev.filter(
        (a) =>
          !(
            a.productId === params.productId &&
            (!params.variantId || a.variantId === params.variantId)
          )
      ),
    ]);

    showToast(
      `🔔 Stock Alert Subscribed! We will push notify you the moment ${targetProduct.name} is restocked.`
    );

    // Audio chime for subscription
    try {
      if (typeof window !== 'undefined' && 'AudioContext' in window) {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15);
        gain.gain.setValueAtTime(0.08, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.3);
      }
    } catch {}
  };

  const unsubscribeFromStockAlert = (productId: string, variantId?: string) => {
    setStockAlerts((prev) =>
      prev.filter(
        (a) =>
          !(
            a.productId === productId &&
            (variantId ? a.variantId === variantId || !a.variantId : true)
          )
      )
    );
    showToast('🔕 Stock Alert paused.');
  };

  const dismissPushNotificationMock = () => {
    setActivePushNotificationMock(null);
  };

  const simulateStockReplenishmentPush = (
    productId: string,
    variantId?: string,
    customQty = 20
  ) => {
    const target = products.find((p) => p.id === productId);
    if (!target) return;

    // 1. Replenish stock in state
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          const updatedVariants = p.variants.map((v) => {
            if (!variantId || v.id === variantId) {
              return { ...v, stock: Math.max(v.stock, customQty) };
            }
            return v;
          });
          return {
            ...p,
            totalStock: Math.max(p.totalStock, customQty),
            stock: Math.max(p.stock || 0, customQty),
            variants: updatedVariants,
          };
        }
        return p;
      })
    );

    // 2. Add NotificationItem to notifications drawer
    const newNotification: NotificationItem = {
      id: `notif-stock-${Date.now()}`,
      title: `⚡ Back in Stock: ${target.name}`,
      message: `Great news! "${target.name}" has just been restocked and is available for instant checkout with Express Delivery!`,
      type: 'stock_alert',
      timestamp: 'Just now',
      isRead: false,
      link: `/product/${target.id}`,
      productId: target.id,
      productImage: target.images[0],
    };
    setNotifications((prev) => [newNotification, ...prev]);

    // 3. Mark subscription as notified
    setStockAlerts((prev) =>
      prev.map((a) => (a.productId === productId ? { ...a, status: 'notified' } : a))
    );

    // 4. Trigger Web Push Mock Native Alert Banner
    const pushMock: PushNotificationMockData = {
      id: `push-${Date.now()}`,
      title: '📦 Back In Stock Alert!',
      body: `${target.name} (${target.brand}) is back in stock! Tap to order with Express Pan-India Delivery.`,
      icon: '/icon.png',
      image: target.images[0],
      productId: target.id,
      productName: target.name,
      timestamp: 'Just now',
      variantInfo: variantId
        ? `Variant: ${target.variants.find((v) => v.id === variantId)?.color || 'Standard'}`
        : 'All Sizes Restocked',
      badge: 'ANTIFLY PUSH NOTIFICATION',
    };
    setActivePushNotificationMock(pushMock);

    // Audio chime for push notification
    try {
      if (typeof window !== 'undefined' && 'AudioContext' in window) {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(783.99, ctx.currentTime + 0.1);
        osc.frequency.exponentialRampToValueAtTime(1046.5, ctx.currentTime + 0.2);
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.45);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.45);
      }
    } catch {}

    showToast(`🔔 Push Notification Mock Triggered: ${target.name} restocked!`);
  };
  const [restaurants, setRestaurants] = useState<Restaurant[]>(INITIAL_RESTAURANTS);
  const [isFoodDeliveryModalOpen, setIsFoodDeliveryModalOpen] = useState<boolean>(false);
  const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);
  const [foodCart, setFoodCart] = useState<FoodCartItem[]>([]);
  const [foodOrders, setFoodOrders] = useState<FoodOrder[]>([]);

  const addToFoodCart = (item: FoodCartItem) => {
    setFoodCart((prev) => {
      // If adding from a different restaurant, clear previous
      if (prev.length > 0 && prev[0].restaurantId !== item.restaurantId) {
        showToast(`Started new cart from ${item.restaurantName}`);
        return [item];
      }
      const existing = prev.find((i) => i.foodItem.id === item.foodItem.id);
      if (existing) {
        return prev.map((i) =>
          i.foodItem.id === item.foodItem.id ? { ...i, quantity: i.quantity + item.quantity } : i
        );
      }
      return [...prev, item];
    });
    showToast(`🍛 Added ${item.foodItem.name} to Food Bag`);
  };

  const updateFoodCartQuantity = (dishId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromFoodCart(dishId);
      return;
    }
    setFoodCart((prev) =>
      prev.map((item) => (item.foodItem.id === dishId ? { ...item, quantity } : item))
    );
  };

  const removeFromFoodCart = (dishId: string) => {
    setFoodCart((prev) => prev.filter((item) => item.foodItem.id !== dishId));
  };

  const clearFoodCart = () => {
    setFoodCart([]);
  };

  const placeFoodOrder = async (tip = 0, specialNotes = ''): Promise<FoodOrder> => {
    const restaurant = selectedRestaurant || restaurants[0];
    const subtotal = foodCart.reduce(
      (sum, item) => sum + item.foodItem.price * item.quantity + (item.extraPrice || 0),
      0
    );
    // All orders qualify for free delivery!
    const deliveryFee = 0;
    const taxes = Math.round(subtotal * 0.05);
    const discount = antiflyOneSubscription.isActive ? Math.round(subtotal * 0.1) : 0;
    const total = subtotal + deliveryFee + taxes + tip - discount;

    const newOrder: FoodOrder = {
      id: `WB-${Date.now().toString().slice(-6)}`,
      restaurantId: restaurant.id,
      restaurantName: restaurant.name,
      restaurantImage: restaurant.image,
      items: [...foodCart],
      subtotal,
      deliveryFee,
      discount,
      taxes,
      total,
      deliveryAddress: '124, 4th Cross, Indiranagar, Bangalore - 560038',
      status: 'Preparing in Kitchen',
      placedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      etaMinutes: restaurant.deliveryTimeMin,
      riderName: 'Vikram Singh (Rating: 4.9★)',
      riderPhone: '+91 98112 34567',
      riderVehicle: 'EV Bike • KA 01 EQ 4892',
      tipAmount: tip,
    };

    setFoodOrders((prev) => [newOrder, ...prev]);
    clearFoodCart();

    // Earn ZoloCoins on food orders
    const coinsEarned = Math.round(total / 25);
    setSuperCoinsBalance((prev) => prev + coinsEarned);

    showToast(
      `🚴 Order Placed! ${restaurant.name} is preparing your hot meal. ETA: ${restaurant.deliveryTimeMin} mins.`
    );
    return newOrder;
  };

  // ==========================================
  // ALL-IN-ONE MASTER SUBSCRIPTION (WISEONE PASS)
  // ==========================================
  const [antiflyOnePlans] = useState<AntiflyOnePlan[]>(INITIAL_WISEONE_PLANS);
  const [antiflyOneSubscription, setAntiflyOneSubscription] = useState<AntiflyOneSubscription>({
    isActive: true,
    planId: 'wiseone-annual',
    planName: 'AntiflyOne VIP Annual Pass',
    expiryDate: 'August 2027',
    totalSavedSoFar: 4890,
    freeDeliveriesUsed: 38,
    ottPassesClaimed: ['Netflix', 'Amazon Prime', 'Disney+ Hotstar', 'SonyLIV', 'Zee5', 'JioCinema'],
  });
  const [isAntiflyOneModalOpen, setIsAntiflyOneModalOpen] = useState<boolean>(false);

  const subscribeToAntiflyOne = async (planId: string) => {
    const plan = antiflyOnePlans.find((p) => p.id === planId) || antiflyOnePlans[1];
    setAntiflyOneSubscription({
      isActive: true,
      planId: plan.id,
      planName: plan.name,
      expiryDate:
        plan.duration === '3 Years'
          ? 'August 2029'
          : plan.duration === '12 Months'
          ? 'August 2027'
          : 'September 2026',
      totalSavedSoFar: antiflyOneSubscription.totalSavedSoFar + 1500,
      freeDeliveriesUsed: antiflyOneSubscription.freeDeliveriesUsed,
      ottPassesClaimed: plan.ottIncluded,
    });
    setSuperCoinsBalance((prev) => prev + 200);
    showToast(
      `👑 Welcome to ${plan.name}! Unlimited Free Deliveries & All-in-One OTT Passes Activated.`
    );
  };

  const cancelAntiflyOneSubscription = async () => {
    setAntiflyOneSubscription((prev) => ({ ...prev, isActive: false }));
    showToast('AntiflyOne VIP subscription paused.');
  };

  // ==========================================
  // ALL BANK CREDIT CARDS & EMI OFFERS
  // ==========================================
  const [bankOffers] = useState<BankCardOffer[]>(INITIAL_BANK_OFFERS);
  const [isBankOffersModalOpen, setIsBankOffersModalOpen] = useState<boolean>(false);
  const [appliedBankOffer, setAppliedBankOffer] = useState<BankCardOffer | null>(
    INITIAL_BANK_OFFERS[0]
  );

  const applyBankOffer = (offerId: string) => {
    const offer = bankOffers.find((b) => b.id === offerId);
    if (!offer) return;
    setAppliedBankOffer(offer);
    showToast(`💳 ${offer.bankName} Card Offer Applied! Save up to ₹${offer.maxDiscount}.`);
  };

  const removeBankOffer = () => {
    setAppliedBankOffer(null);
    showToast('Bank offer removed.');
  };

  // ==========================================
  // OTT PLATFORM & STREAMING (WISESTREAM)
  // ==========================================
  const [ottPlatforms] = useState<OTTPlatform[]>(INITIAL_OTT_PLATFORMS);
  const [ottShows] = useState<OTTShow[]>(INITIAL_OTT_SHOWS);
  const [isOTTModalOpen, setIsOTTModalOpen] = useState<boolean>(false);
  const [activeStreamingShow, setActiveStreamingShow] = useState<OTTShow | null>(
    INITIAL_OTT_SHOWS[0]
  );

  // ==========================================
  // WORLDWIDE LANGUAGE LOCALIZATION (i18n)
  // ==========================================
  const [language, setLanguage] = useState<LanguageCode>('en');
  const t = (key: string) => getTranslation(key, language);

  // ==========================================
  // SELLER CENTRAL PORTAL & VENDOR ECOSYSTEM
  // ==========================================
  const [sellers, setSellers] = useState<SellerProfile[]>(DEFAULT_SELLERS);
  const [activeSellerId, setActiveSellerId] = useState<string>('seller-001');
  const [sellerPayouts, setSellerPayouts] = useState<SellerPayout[]>(DEFAULT_SELLER_PAYOUTS);
  const [sellerAdminFeeLedger, setSellerAdminFeeLedger] = useState<SellerAdminFeeRecord[]>(DEFAULT_SELLER_ADMIN_FEE_LOGS);
  const [followedSellerIds, setFollowedSellerIds] = useState<string[]>(['seller-001']);

  const toggleFollowSeller = (sellerId: string) => {
    setFollowedSellerIds((prev) => {
      const isAlreadyFollowed = prev.includes(sellerId);
      const targetSeller = sellers.find((s) => s.id === sellerId);
      const sellerName = targetSeller ? targetSeller.storeName : 'Seller';
      if (isAlreadyFollowed) {
        showToast(`Unfollowed ${sellerName}`);
        return prev.filter((id) => id !== sellerId);
      } else {
        showToast(`✨ You are now following ${sellerName}!`);
        return [...prev, sellerId];
      }
    });
  };

  const isFollowingSeller = (sellerId: string) => followedSellerIds.includes(sellerId);

  const currentSeller = useMemo(() => {
    return sellers.find((s) => s.id === activeSellerId) || sellers[0];
  }, [sellers, activeSellerId]);

  const sellerCoupons = useMemo(() => {
    return coupons.filter((c) => c.isSellerCoupon || c.sellerId === currentSeller.id);
  }, [coupons, currentSeller.id]);

  const createSellerCoupon = async (couponData: Partial<Coupon>) => {
    const code = (couponData.code || `SK${Math.floor(10 + Math.random() * 90)}`).toUpperCase().trim();
    const discountVal = Number(couponData.discountValue) || 20;
    const newCoupon: Coupon = {
      id: `c-seller-${Date.now()}`,
      code,
      description: couponData.description || `Seller Special: ${discountVal}% Off crafted by ${currentSeller.storeName}`,
      discountType: couponData.discountType || 'percentage',
      discountValue: discountVal,
      minCartValue: Number(couponData.minCartValue) || 499,
      maxDiscount: couponData.maxDiscount ? Number(couponData.maxDiscount) : undefined,
      startDate: couponData.startDate || new Date().toISOString().split('T')[0],
      endDate: couponData.endDate || '2026-12-31',
      usageLimit: Number(couponData.usageLimit) || 5000,
      usedCount: 0,
      isActive: true,
      appOnly: false,
      websiteOnly: false,
      sellerId: currentSeller.id,
      sellerName: currentSeller.storeName,
      isSellerCoupon: true,
      applicableProductIds: couponData.applicableProductIds || [],
      syndicateToExternalApps: couponData.syndicateToExternalApps ?? true,
    };

    try {
      await fetch('/api/seller/coupons', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newCoupon),
      });
    } catch (e) {
      console.warn('API fallback for seller coupon', e);
    }

    setCoupons((prev) => [newCoupon, ...prev]);
    showToast(`🏷️ Coupon code ${newCoupon.code} created! ${newCoupon.discountValue}% OFF is now live across applications.`);
    return { success: true, message: `Coupon ${newCoupon.code} launched successfully!`, coupon: newCoupon };
  };

  const deleteSellerCoupon = async (couponId: string) => {
    try {
      await fetch(`/api/seller/coupons/${couponId}`, { method: 'DELETE' });
    } catch (e) {
      console.warn('API fallback for coupon deletion', e);
    }
    setCoupons((prev) => prev.filter((c) => c.id !== couponId));
    showToast('Seller promo code removed.');
  };

  const toggleSellerCouponStatus = async (couponId: string) => {
    setCoupons((prev) =>
      prev.map((c) => (c.id === couponId ? { ...c, isActive: !c.isActive } : c))
    );
    showToast('Seller promo code status updated.');
  };

  const paySellerAdminPlatformFees = async (sellerId: string, amount?: number) => {
    const utr = `UTR-ADMIN-FEE-${Date.now().toString().slice(-8)}`;
    setSellerAdminFeeLedger((prev) =>
      prev.map((item) =>
        item.sellerId === sellerId && item.status === 'Auto-Deducted'
          ? { ...item, status: 'Paid' }
          : item
      )
    );
    try {
      await fetch('/api/seller/fees/settle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sellerId }),
      });
    } catch (e) {
      console.warn(e);
    }
    showToast(`✅ Platform fees (₹1/order) reconciled with Admin Panel (Ref: ${utr})`);
    return { success: true, message: 'Platform fees reconciled with Admin Panel', utr };
  };

  const addSellerProduct = async (productData: Partial<Product>) => {
    const defaultImage = productData.image || productData.images?.[0] || 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=600&auto=format&fit=crop&q=80';
    const price = productData.price || 1999;
    const mrp = productData.mrp || (price ? price * 1.4 : 2999);
    const stock = productData.stock || productData.totalStock || 50;
    const name = productData.name || productData.title || 'New Marketplace Product';

    const newProduct: Product = {
      id: `wi-prod-${Date.now()}`,
      name,
      title: name,
      slug: name.toLowerCase().replace(/\s+/g, '-'),
      sku: productData.sku || `SKU-${Date.now().toString().slice(-6)}`,
      barcode: `890${Date.now().toString().slice(-9)}`,
      brand: currentSeller.storeName || 'WiseArtisans',
      category: productData.category || 'ethnic-wear',
      subcategory: productData.subcategory || 'General',
      shortDescription: productData.shortDescription || 'Authentic handcrafted edition.',
      description: productData.description || 'Premium curated product listed on Antifly Global Marketplace.',
      price,
      mrp,
      discountPercentage: Math.round(((mrp - price) / mrp) * 100),
      taxPercentage: 18,
      finalPrice: price,
      totalStock: stock,
      stock,
      rating: 4.8,
      reviewCount: 1,
      reviewsCount: 1,
      image: defaultImage,
      images: productData.images && productData.images.length > 0 ? productData.images : [defaultImage],
      colors: [{ name: 'Standard', hex: '#d97706' }],
      sizes: ['S', 'M', 'L', 'XL'],
      materials: ['Handloom Silk', 'Fine Cotton'],
      features: ['Pure Zari', 'Authentic GI Tag Certified', 'Dry Clean Only'],
      tags: ['New Arrival', currentSeller.storeName],
      searchKeywords: [name.toLowerCase(), 'handloom', 'saree', 'artisan'],
      seoTitle: `${name} | Buy Online at Antifly`,
      seoDescription: `Order authentic ${name} crafted by ${currentSeller.storeName}. Express delivery worldwide.`,
      seoKeywords: ['handloom', 'saree', 'ethnic wear', 'indian craft'],
      shippingInfo: 'Ships within 24-48 hours with door-to-door live GPS tracking.',
      returnPolicy: '7-day hassle-free return or exchange guarantee.',
      exchangePolicy: 'Instant doorstep size & color exchange available.',
      isPublished: true,
      isBestseller: false,
      isFeatured: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      specifications: [
        { label: 'Seller', value: currentSeller.storeName },
        { label: 'Origin', value: currentSeller.warehouseAddress.country },
      ],
      variants: [
        {
          id: `var-${Date.now()}-1`,
          sku: `SKU-${Date.now().toString().slice(-6)}`,
          color: 'Standard',
          colorHex: '#3b82f6',
          size: 'Standard',
          price,
          mrp,
          stock,
        },
      ],
    };

    setProducts((prev) => [newProduct, ...prev]);
    setSellers((prev) =>
      prev.map((s) =>
        s.id === currentSeller.id
          ? { ...s, totalOrders: s.totalOrders + 1 }
          : s
      )
    );
    showToast(`✅ "${newProduct.name}" successfully published to Marketplace!`);
  };

  const updateSellerInventory = async (productId: string, newStock: number, newPrice?: number) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          return {
            ...p,
            stock: newStock,
            price: newPrice !== undefined ? newPrice : p.price,
          };
        }
        return p;
      })
    );
    showToast(`📦 Inventory updated (Stock: ${newStock}${newPrice ? `, Price: ₹${newPrice}` : ''})`);
  };

  const requestSellerPayout = async (sellerId: string, amount: number): Promise<SellerPayout> => {
    const newPayout: SellerPayout = {
      id: `PAY-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      sellerId,
      amount,
      currency: 'INR',
      utrNumber: `UTR-HDFC-${Date.now().toString().slice(-8)}`,
      status: 'Completed',
      date: new Date().toLocaleString(),
      orderCount: Math.floor(amount / 2500) + 1,
    };

    setSellerPayouts((prev) => [newPayout, ...prev]);
    setSellers((prev) =>
      prev.map((s) =>
        s.id === sellerId
          ? {
              ...s,
              balanceAvailable: Math.max(0, s.balanceAvailable - amount),
            }
          : s
      )
    );
    showToast(`💰 Payout of ₹${amount.toLocaleString('en-IN')} transferred via ${newPayout.utrNumber}!`);
    return newPayout;
  };

  // ==========================================
  // INSTAGRAM-STYLE SOCIAL ENGINE & SAVE PORTFOLIO
  // ==========================================
  const [activeSellerStorefrontId, setActiveSellerStorefrontId] = useState<string | null>(null);
  const [activeCommentsProductId, setActiveCommentsProductId] = useState<string | null>(null);
  const [activeShareProduct, setActiveShareProduct] = useState<Product | null>(null);
  const [isProductCommentsOpen, setIsProductCommentsOpen] = useState<boolean>(false);
  const [isProductShareOpen, setIsProductShareOpen] = useState<boolean>(false);
  const [isSavePortfolioOpen, setIsSavePortfolioOpen] = useState<boolean>(false);

  // Initial Product Likes map
  const [productLikes, setProductLikes] = useState<Record<string, { count: number; isLiked: boolean }>>({
    'wi-prod-001': { count: 328, isLiked: true },
    'wi-prod-002': { count: 412, isLiked: false },
    'wi-prod-003': { count: 189, isLiked: false },
    'wi-prod-004': { count: 254, isLiked: true },
    'wi-prod-005': { count: 540, isLiked: false },
    'wi-prod-006': { count: 175, isLiked: false },
    'wi-prod-007': { count: 290, isLiked: true },
    'wi-prod-008': { count: 310, isLiked: false },
    'wi-prod-009': { count: 720, isLiked: true },
    'wi-prod-010': { count: 850, isLiked: true },
    'wi-prod-011': { count: 490, isLiked: true },
  });

  const [productComments, setProductComments] = useState<Record<string, ProductCommentItem[]>>(INITIAL_PRODUCT_COMMENTS);
  const [savedProductIds, setSavedProductIds] = useState<string[]>(['wi-prod-001', 'wi-prod-009', 'wi-prod-011']);
  const [savedSellerPostIds, setSavedSellerPostIds] = useState<string[]>(['spost-001', 'spost-003']);
  const [savedSellerPortfolioIds, setSavedSellerPortfolioIds] = useState<string[]>(['port-001', 'port-004']);

  const openSellerStorefront = (sellerId: string) => {
    setActiveSellerStorefrontId(sellerId);
  };

  const toggleLikeProduct = (productId: string) => {
    setProductLikes((prev) => {
      const current = prev[productId] || { count: 45, isLiked: false };
      const nextIsLiked = !current.isLiked;
      const nextCount = nextIsLiked ? current.count + 1 : Math.max(0, current.count - 1);
      
      const targetProd = products.find((p) => p.id === productId);
      const prodName = targetProd ? targetProd.name : 'Product';
      if (nextIsLiked) {
        showToast(`❤️ Liked "${prodName}"`);
      } else {
        showToast(`🤍 Unliked "${prodName}"`);
      }

      return {
        ...prev,
        [productId]: { count: nextCount, isLiked: nextIsLiked },
      };
    });
  };

  const isProductLiked = (productId: string): boolean => {
    return Boolean(productLikes[productId]?.isLiked);
  };

  const getProductLikeCount = (productId: string): number => {
    return productLikes[productId]?.count ?? 48;
  };

  const toggleSaveProductSocial = (productId: string) => {
    setSavedProductIds((prev) => {
      const isSaved = prev.includes(productId);
      const targetProd = products.find((p) => p.id === productId);
      const prodName = targetProd ? targetProd.name : 'Product';
      if (isSaved) {
        showToast(`🔖 Removed "${prodName}" from Saved Portfolio`);
        return prev.filter((id) => id !== productId);
      } else {
        showToast(`🔖 Added "${prodName}" to your Saved Portfolio!`);
        return [...prev, productId];
      }
    });
  };

  const isProductSavedSocial = (productId: string): boolean => {
    return savedProductIds.includes(productId);
  };

  // ==========================================
  // FAVORITES & SAVED PRODUCTS SYSTEM (INSTAGRAM + SNAPCHAT + WISHLIST)
  // ==========================================
  const [userCollections, setUserCollections] = useState<ProductCollection[]>(INITIAL_USER_COLLECTIONS);
  const [creatorCollections] = useState<ProductCollection[]>(CREATOR_FEATURED_COLLECTIONS);
  const [activeCollectionId, setActiveCollectionId] = useState<string | null>(null);
  const [isFavoritesHubOpen, setIsFavoritesHubOpen] = useState<boolean>(false);
  const [activeFavoritesTab, setActiveFavoritesTab] = useState<
    'all' | 'products' | 'posts' | 'videos' | 'stores' | 'collections' | 'wishlist' | 'collaborative' | 'creators' | 'figma_screens'
  >('products');
  const [savedProductViewMode, setSavedProductViewMode] = useState<'grid' | 'masonry' | 'list'>('grid');
  
  const [smartSaveBottomSheet, setSmartSaveBottomSheet] = useState<SmartSaveBottomSheetState>({
    isOpen: false,
    productId: null,
    product: null,
  });

  const [flyingSaveAnimation, setFlyingSaveAnimation] = useState<FlyingSaveAnimationState>({
    isActive: false,
    imageUrl: '',
    productName: '',
  });

  const [wishlistDetails, setWishlistDetails] = useState<Record<string, WishlistItemDetails>>(INITIAL_WISHLIST_DETAILS);
  const [smartCategorySuggestions, setSmartCategorySuggestions] = useState<SmartCategorySuggestion[]>(INITIAL_SMART_SUGGESTIONS);

  const openSmartSaveBottomSheet = (productId: string) => {
    const p = products.find((prod) => prod.id === productId) || null;
    setSmartSaveBottomSheet({
      isOpen: true,
      productId,
      product: p,
    });
  };

  const closeSmartSaveBottomSheet = () => {
    setSmartSaveBottomSheet({
      isOpen: false,
      productId: null,
      product: null,
    });
  };

  const triggerFlyingSaveAnimation = (imageUrl: string, productName: string, startX?: number, startY?: number) => {
    setFlyingSaveAnimation({
      isActive: true,
      imageUrl,
      productName,
      startX: startX || (typeof window !== 'undefined' ? window.innerWidth / 2 : 200),
      startY: startY || (typeof window !== 'undefined' ? window.innerHeight / 2 : 300),
    });

    setTimeout(() => {
      setFlyingSaveAnimation((prev) => ({ ...prev, isActive: false }));
    }, 1200);
  };

  const quickSaveProductWithSmartFlow = (productId: string, event?: React.MouseEvent) => {
    const targetProd = products.find((p) => p.id === productId);
    const prodName = targetProd ? targetProd.name : 'Product';
    const isSaved = savedProductIds.includes(productId);

    if (isSaved) {
      // Remove from saved list
      setSavedProductIds((prev) => prev.filter((id) => id !== productId));
      setUserCollections((prev) =>
        prev.map((col) => ({
          ...col,
          itemProductIds: col.itemProductIds.filter((id) => id !== productId),
        }))
      );
      showToast(`🤍 Removed "${prodName}" from Favorites`);
    } else {
      // Add to saved list
      setSavedProductIds((prev) => [productId, ...prev.filter((id) => id !== productId)]);
      
      // Also add to default Favorites collection
      setUserCollections((prev) =>
        prev.map((col) =>
          col.id === 'col-favorites' && !col.itemProductIds.includes(productId)
            ? { ...col, itemProductIds: [productId, ...col.itemProductIds], updatedAt: 'Just now' }
            : col
        )
      );

      // Trigger Snapchat flying save animation
      if (targetProd && targetProd.images && targetProd.images[0]) {
        const x = event?.clientX || (typeof window !== 'undefined' ? window.innerWidth / 2 : undefined);
        const y = event?.clientY || (typeof window !== 'undefined' ? window.innerHeight / 2 : undefined);
        triggerFlyingSaveAnimation(targetProd.images[0], targetProd.name, x, y);
      }

      // Show toast confirmation
      showToast(`❤️ Saved "${prodName}" to Favorites!`);
      
      // Auto-open Smart Save lightweight bottom sheet after a tiny delay so user can organize if they wish
      setTimeout(() => {
        openSmartSaveBottomSheet(productId);
      }, 350);
    }
  };

  const toggleWishlistWithAlert = (productId: string) => {
    toggleWishlist(productId);
    const targetProd = products.find((p) => p.id === productId);
    if (!wishlist.includes(productId)) {
      // Added
      setWishlistDetails((prev) => ({
        ...prev,
        [productId]: {
          productId,
          addedAt: 'Just now',
          originalPrice: targetProd?.mrp || targetProd?.price || 1999,
          currentPrice: targetProd?.price || 1499,
          priceDropAlertEnabled: true,
          smartState: 'recently_added',
          stockCount: targetProd?.totalStock || 15,
        },
      }));
      showToast(`✨ "${targetProd?.name || 'Product'}" added to Wishlist with Price Drop tracking!`);
    } else {
      showToast(`Removed from Wishlist`);
    }
  };

  const createCustomCollection = (
    name: string,
    emoji: string = '📁',
    description: string = '',
    privacy: CollectionPrivacy = 'private',
    initialProductIds: string[] = []
  ): ProductCollection => {
    const newCol: ProductCollection = {
      id: `col-${Date.now()}`,
      name: name.trim(),
      emoji: emoji.trim() || '📁',
      description: description.trim(),
      coverImage: initialProductIds.length > 0
        ? products.find((p) => p.id === initialProductIds[0])?.images[0] || 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=800'
        : 'https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?w=800',
      itemProductIds: initialProductIds,
      privacy,
      collaborators: privacy === 'collaborative'
        ? [
            {
              id: 'user-01',
              name: currentCustomer.name || 'You',
              avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
              role: 'owner',
            },
            {
              id: 'user-02',
              name: 'Rahul Varma',
              avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
              role: 'editor',
            },
          ]
        : undefined,
      createdAt: new Date().toISOString(),
      updatedAt: 'Just now',
    };

    setUserCollections((prev) => [newCol, ...prev]);
    showToast(`✨ Collection "${newCol.name}" created successfully!`);
    return newCol;
  };

  const updateCollection = (collectionId: string, updates: Partial<ProductCollection>) => {
    setUserCollections((prev) =>
      prev.map((col) => (col.id === collectionId ? { ...col, ...updates, updatedAt: 'Just now' } : col))
    );
    showToast('Collection updated');
  };

  const deleteCollection = (collectionId: string) => {
    const target = userCollections.find((c) => c.id === collectionId);
    setUserCollections((prev) => prev.filter((col) => col.id !== collectionId));
    if (activeCollectionId === collectionId) {
      setActiveCollectionId(null);
    }
    showToast(`Deleted collection "${target?.name || 'Collection'}"`);
  };

  const addProductToCollection = (collectionId: string, productId: string) => {
    const targetProd = products.find((p) => p.id === productId);
    setUserCollections((prev) =>
      prev.map((col) => {
        if (col.id === collectionId) {
          if (col.itemProductIds.includes(productId)) {
            return col;
          }
          return {
            ...col,
            itemProductIds: [productId, ...col.itemProductIds],
            coverImage: col.coverImage || targetProd?.images[0],
            updatedAt: 'Just now',
          };
        }
        return col;
      })
    );
    
    // Also ensure it is marked in savedProductIds
    setSavedProductIds((prev) => (prev.includes(productId) ? prev : [productId, ...prev]));

    const targetCol = userCollections.find((c) => c.id === collectionId);
    showToast(`Added to "${targetCol?.name || 'Collection'}"`);
  };

  const removeProductFromCollection = (collectionId: string, productId: string) => {
    setUserCollections((prev) =>
      prev.map((col) => {
        if (col.id === collectionId) {
          return {
            ...col,
            itemProductIds: col.itemProductIds.filter((id) => id !== productId),
            updatedAt: 'Just now',
          };
        }
        return col;
      })
    );
    showToast('Removed item from collection');
  };

  const moveProductBetweenCollections = (fromCollectionId: string, toCollectionId: string, productId: string) => {
    removeProductFromCollection(fromCollectionId, productId);
    addProductToCollection(toCollectionId, productId);
    const toCol = userCollections.find((c) => c.id === toCollectionId);
    showToast(`Moved item to "${toCol?.name || 'Collection'}"`);
  };

  const reorderProductsInCollection = (collectionId: string, newProductIds: string[]) => {
    setUserCollections((prev) =>
      prev.map((col) => (col.id === collectionId ? { ...col, itemProductIds: newProductIds, updatedAt: 'Just now' } : col))
    );
  };

  const reactToCollaborativeItem = (collectionId: string, productId: string, reactionType: 'like' | 'love' | 'fire') => {
    setUserCollections((prev) =>
      prev.map((col) => {
        if (col.id === collectionId) {
          const currentReactions = col.itemReactions || {};
          const itemReaction = currentReactions[productId] || {
            likes: 0,
            loves: 0,
            fires: 0,
            userReactions: [],
          };

          const alreadyReacted = itemReaction.userReactions.includes(reactionType);
          const updatedUserReactions = alreadyReacted
            ? itemReaction.userReactions.filter((r) => r !== reactionType)
            : [...itemReaction.userReactions, reactionType];

          const diff = alreadyReacted ? -1 : 1;
          const updatedLikes = reactionType === 'like' ? Math.max(0, itemReaction.likes + diff) : itemReaction.likes;
          const updatedLoves = reactionType === 'love' ? Math.max(0, itemReaction.loves + diff) : itemReaction.loves;
          const updatedFires = reactionType === 'fire' ? Math.max(0, itemReaction.fires + diff) : itemReaction.fires;

          return {
            ...col,
            itemReactions: {
              ...currentReactions,
              [productId]: {
                likes: updatedLikes,
                loves: updatedLoves,
                fires: updatedFires,
                userReactions: updatedUserReactions,
              },
            },
          };
        }
        return col;
      })
    );
    showToast(reactionType === 'love' ? '❤️ Voted Love' : reactionType === 'fire' ? '🔥 Voted Fire' : '👍 Upvoted');
  };

  const addCollaborativeComment = (collectionId: string, productId: string, text: string) => {
    if (!text.trim()) return;
    const newComment: CollectionItemComment = {
      id: `collab-c-${Date.now()}`,
      userId: 'user-01',
      userName: currentCustomer.name || 'Priya',
      userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      text: text.trim(),
      time: 'Just now',
    };

    setUserCollections((prev) =>
      prev.map((col) => {
        if (col.id === collectionId) {
          const allComments = col.itemComments || {};
          const productCommentsList = allComments[productId] || [];
          return {
            ...col,
            itemComments: {
              ...allComments,
              [productId]: [newComment, ...productCommentsList],
            },
          };
        }
        return col;
      })
    );
    showToast('💬 Note added to collaborative board!');
  };

  const acceptSmartCategorySuggestion = (suggestion: SmartCategorySuggestion) => {
    createCustomCollection(
      suggestion.categoryName,
      suggestion.suggestedEmoji,
      `Auto-curated smart collection with ${suggestion.count} saved items`,
      'private',
      suggestion.productIds
    );
    setSmartCategorySuggestions((prev) => prev.filter((s) => s.categoryName !== suggestion.categoryName));
    showToast(`🎉 Created collection "${suggestion.categoryName}"!`);
  };

  const dismissSmartCategorySuggestion = (categoryName: string) => {
    setSmartCategorySuggestions((prev) => prev.filter((s) => s.categoryName !== categoryName));
    showToast('Suggestion dismissed');
  };

  // ==========================================
  // CAMERA CREATION STUDIO ACTIONS
  // ==========================================
  const openCameraStudio = (mode: CameraMode = 'photo', options?: { conversationId?: string; productId?: string }) => {
    setCameraInitialMode(mode);
    setCameraTargetConversationId(options?.conversationId || null);
    setCameraTargetProductId(options?.productId || null);
    setIsCameraStudioOpen(true);
  };

  const saveMediaToCameraGallery = (media: CameraCapturedMedia) => {
    const enriched: CameraCapturedMedia = {
      ...media,
      id: media.id || `media-${Date.now()}`,
      createdAt: 'Just now',
      isSavedGallery: true,
      isDraft: false,
    };
    setCameraGalleryMedia((prev) => [enriched, ...prev.filter(m => m.id !== enriched.id)]);
    showToast('📸 Saved to Camera Media Vault!');
  };

  const saveMediaDraft = (media: CameraCapturedMedia) => {
    const draft: CameraCapturedMedia = {
      ...media,
      id: media.id || `draft-${Date.now()}`,
      createdAt: 'Draft • Just now',
      isDraft: true,
      isSavedGallery: true,
    };
    setCameraGalleryMedia((prev) => [draft, ...prev.filter(m => m.id !== draft.id)]);
    showToast('💾 Saved to Camera Drafts!');
  };

  const deleteMediaFromCameraGallery = (id: string) => {
    setCameraGalleryMedia((prev) => prev.filter((m) => m.id !== id));
    showToast('Deleted from Camera Vault');
  };

  const publishMediaToStory = (media: CameraCapturedMedia) => {
    saveMediaToCameraGallery(media);
    const newStoryLook = {
      id: `look-story-${Date.now()}`,
      title: media.caption || 'Live Camera Story',
      curatorName: currentUserSession.name || 'Priya Sharma',
      curatorAvatar: currentUserSession.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300',
      curatorRole: 'Creator & Shopper',
      coverImage: media.mediaUrl,
      images: [media.mediaUrl],
      taggedProductIds: media.productTags.map((t) => t.productId).filter(Boolean),
      likesCount: 1,
      sharesCount: 0,
      vibe: 'Festive Vibes',
      occasion: 'Trending',
      isLiveStream: false,
    };
    setStyleCastLooks((prev) => [newStoryLook as any, ...prev]);
    showToast('✨ Published to 24h Interactive Story with Shoppable Tags!');
  };

  const publishMediaToReel = (media: CameraCapturedMedia) => {
    saveMediaToCameraGallery(media);
    const newPost: CommunityPostItem = {
      id: `post-reel-${Date.now()}`,
      authorName: currentUserSession.name || 'Priya Sharma',
      authorHandle: '@priyasharma',
      authorAvatar: currentUserSession.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300',
      authorRole: 'creator',
      isVerified: true,
      mediaType: 'reel_15s',
      mediaUrl: media.mediaUrl,
      videoDurationSeconds: media.durationSeconds || 15,
      caption: `${media.caption || '15s Camera Studio Reel'} ${(media.hashtags || []).join(' ')}`,
      tags: media.hashtags || ['CameraStudio', 'ShoppableLook'],
      likesCount: 1,
      commentsCount: 0,
      sharesCount: 0,
      isLikedByMe: true,
      isSavedByMe: false,
      taggedProductIds: media.productTags.map((t) => t.productId).filter(Boolean),
      comments: [],
      createdAt: 'Just now',
    };
    setCommunityPosts((prev) => [newPost, ...prev]);
    showToast('🎬 Published 15s Shoppable Reel to Community Feed!');
  };

  const publishMediaToFeed = (media: CameraCapturedMedia) => {
    saveMediaToCameraGallery(media);
    if (currentUserSession.role === 'seller') {
      const firstTag = media.productTags[0];
      createSellerPost(currentSeller.id, {
        caption: media.caption || 'New Product Drop from Studio',
        imageUrl: media.mediaUrl,
        taggedProductId: firstTag?.productId,
        taggedProductName: firstTag?.productName,
        taggedProductPrice: firstTag?.price,
      });
      showToast('🚀 Published to Seller Feed & Storefront!');
    } else {
      publishMediaToReel(media);
    }
  };

  const publishMediaToProductCatalog = (media: CameraCapturedMedia, customProduct?: Partial<Product>) => {
    saveMediaToCameraGallery(media);
    const newProdId = `prod-cam-${Date.now()}`;
    const firstTag = media.productTags[0];
    const newProduct: Product = {
      id: newProdId,
      name: customProduct?.name || firstTag?.productName || media.caption?.slice(0, 40) || 'Studio Captured Product',
      sku: `SKU-CAM-${Date.now().toString().slice(-6)}`,
      barcode: `890${Date.now().toString().slice(-9)}`,
      slug: (customProduct?.name || firstTag?.productName || 'studio-product').toLowerCase().replace(/\s+/g, '-'),
      category: customProduct?.category || 'Ethnic Wear & Silks',
      subcategory: customProduct?.subcategory || 'Studio Exclusives',
      shortDescription: customProduct?.shortDescription || 'Captured and enhanced with Antifly Camera Studio.',
      price: customProduct?.price || firstTag?.price || 2499,
      mrp: customProduct?.mrp || firstTag?.mrp || 4999,
      discountPercentage: customProduct?.discountPercentage || firstTag?.discountPercent || 50,
      taxPercentage: 18,
      finalPrice: customProduct?.price || firstTag?.price || 2499,
      totalStock: 50,
      stock: 50,
      rating: 4.9,
      reviewCount: 1,
      brand: customProduct?.brand || media.sellerStudioDetails?.brandName || currentSeller.storeName || 'Antifly Originals',
      sellerId: currentSeller.id || 'seller-01',
      sellerName: currentSeller.storeName || 'Heritage Boutique',
      sellerVerified: true,
      images: [media.mediaUrl, ...(customProduct?.images || [])],
      image: media.mediaUrl,
      description: customProduct?.description || media.caption || 'Captured and enhanced with Antifly Camera Studio.',
      features: ['Shot with Camera Studio', 'Verified Pure Material', 'Express Shipping Available'],
      tags: media.hashtags || ['NewArrival', 'StudioShoot', 'CameraExclusive'],
      searchKeywords: ['camera', 'studio', 'exclusive', (customProduct?.name || 'ethnic').toLowerCase()],
      seoTitle: `${customProduct?.name || 'Studio Product'} | Antifly`,
      seoDescription: `Order authentic studio collection product. Express delivery.`,
      seoKeywords: ['camera', 'lookbook', 'handcrafted'],
      shippingInfo: 'Express 48h dispatch with live GPS tracking.',
      returnPolicy: '7-Day Hassle-Free Returns',
      exchangePolicy: 'Doorstep size and color replacement available.',
      isPublished: true,
      isFeatured: true,
      isBestseller: false,
      isNewArrival: true,
      variants: [],
      colors: [{ name: 'Studio Hue', hex: '#d97706' }],
      sizes: ['S', 'M', 'L', 'XL'],
      materials: ['Pure Silk Blend'],
      specifications: [{ label: 'Captured Via', value: 'Antifly Camera Studio' }],
    };
    setProducts((prev) => [newProduct, ...prev]);
    showToast(`🛍️ Published "${newProduct.name}" directly to Live Catalog!`);
  };

  const sendMediaDirectToChat = (conversationId: string, media: CameraCapturedMedia, note?: string) => {
    saveMediaToCameraGallery(media);
    const firstTag = media.productTags[0];
    const messageType: ChatMessageType = media.type === 'video' ? 'video_15s' : firstTag ? 'product_card' : 'image';
    
    sendChatMessage(
      conversationId,
      note || media.caption || (media.type === 'video' ? 'Shared a 15s camera clip' : 'Shared photo from Camera Studio'),
      messageType,
      {
        mediaUrl: media.mediaUrl,
        durationSeconds: media.durationSeconds || 15,
        viewOnce: media.viewOnce,
        viewOnceOpened: false,
        productSnippet: firstTag ? {
          id: firstTag.productId,
          name: firstTag.productName,
          price: firstTag.price,
          mrp: firstTag.mrp || Math.round(firstTag.price * 1.3),
          image: firstTag.image || media.mediaUrl,
        } : undefined,
      }
    );
    showToast(media.viewOnce ? '① View-Once Media sent to Chat!' : '💬 Sent directly to Conversation!');
  };

  // ==========================================
  // TIME-SHIFT 3D STORIES & SPATIAL SOCIAL ACTIONS
  // ==========================================
  const openTimeShiftCamera = () => {
    setIsTimeShiftCameraOpen(true);
  };

  const openTimeShiftStoryViewer = (story: TimeShiftStoryItem) => {
    setActiveTimeShiftStory(story);
    setIsTimeShiftStoryViewerOpen(true);
  };

  const publishTimeShiftStory = (newStory: TimeShiftStoryItem) => {
    setTimeShiftStories((prev) => [newStory, ...prev]);
    showToast(`✨ Published ${newStory.lifetimeDuration.toUpperCase()} Living Story "${newStory.storyDna}"!`);
  };

  const recordStoryMomentReaction = (
    storyId: string,
    timestampSec: number,
    type: StoryReactionType
  ) => {
    // Optimistic local state update
    setTimeShiftStories((prev) =>
      prev.map((s) => {
        if (s.id === storyId) {
          const existingReactions = s.momentReactions || [];
          const matchedIdx = existingReactions.findIndex(
            (r) => r.timestampSecond === timestampSec && r.reactionType === type
          );
          let updatedReactions;
          if (matchedIdx >= 0) {
            updatedReactions = [...existingReactions];
            updatedReactions[matchedIdx].count += 1;
          } else {
            updatedReactions = [
              ...existingReactions,
              { timestampSecond: timestampSec, reactionType: type, count: 1 },
            ];
          }

          return {
            ...s,
            momentReactions: updatedReactions,
            livePulse: {
              ...s.livePulse,
              reactionsCount: (s.livePulse?.reactionsCount || 0) + 1,
            },
          };
        }
        return s;
      })
    );

    // Persist to backend
    fetch(`/api/stories/${storyId}/reactions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        timestampSecond: timestampSec,
        reactionType: type,
        user: currentCustomer?.name || 'Live Shopper',
      }),
    }).catch((err) => console.warn('Failed to sync story reaction to server:', err));
  };

  const unlockSecretStoryReward = (storyId: string, objectId: string) => {
    setTimeShiftStories((prev) =>
      prev.map((s) => {
        if (s.id === storyId) {
          return {
            ...s,
            secretLayerUnlockedCount: s.secretLayerUnlockedCount + 1,
            interactiveObjects: s.interactiveObjects.map((obj) =>
              obj.id === objectId && obj.secretReward
                ? {
                    ...obj,
                    secretReward: { ...obj.secretReward, claimed: true },
                  }
                : obj
            ),
          };
        }
        return s;
      })
    );
  };

  const voteStoryPoll = (storyId: string, pollId: string, optionId: string) => {
    setTimeShiftStories((prev) =>
      prev.map((story) => {
        if (story.id === storyId && story.pollSticker && story.pollSticker.id === pollId) {
          const currentPoll = story.pollSticker;
          const prevVoted = currentPoll.userVotedOptionId;

          // If already voted for the exact same option, keep it
          if (prevVoted === optionId) return story;

          let newVotesA = currentPoll.optionA.votes;
          let newVotesB = currentPoll.optionB.votes;
          let newTotal = currentPoll.totalVotes;

          const isOptionA = optionId === 'opt-a' || optionId === currentPoll.optionA.id;

          if (!prevVoted) {
            // First time voting
            if (isOptionA) {
              newVotesA += 1;
            } else {
              newVotesB += 1;
            }
            newTotal += 1;
          } else {
            // Switching vote
            if (isOptionA) {
              newVotesA += 1;
              newVotesB = Math.max(0, newVotesB - 1);
            } else {
              newVotesB += 1;
              newVotesA = Math.max(0, newVotesA - 1);
            }
          }

          const updatedPoll: StoryPollSticker = {
            ...currentPoll,
            optionA: {
              ...currentPoll.optionA,
              votes: newVotesA,
            },
            optionB: {
              ...currentPoll.optionB,
              votes: newVotesB,
            },
            totalVotes: newTotal,
            userVotedOptionId: optionId,
          };

          const updatedStory = {
            ...story,
            pollSticker: updatedPoll,
            livePulse: {
              ...story.livePulse,
              reactionsCount: (story.livePulse?.reactionsCount || 0) + 1,
            },
          };

          if (activeTimeShiftStory?.id === storyId) {
            setActiveTimeShiftStory(updatedStory);
          }

          return updatedStory;
        }
        return story;
      })
    );
  };

  const addOrUpdateStoryPoll = (storyId: string, poll: StoryPollSticker) => {
    setTimeShiftStories((prev) =>
      prev.map((story) => {
        if (story.id === storyId) {
          const updated = {
            ...story,
            pollSticker: poll,
          };
          if (activeTimeShiftStory?.id === storyId) {
            setActiveTimeShiftStory(updated);
          }
          return updated;
        }
        return story;
      })
    );
    showToast('📊 Poll sticker attached to 3D Story!');
  };

  const removeStoryPoll = (storyId: string, pollId: string) => {
    setTimeShiftStories((prev) =>
      prev.map((story) => {
        if (story.id === storyId && story.pollSticker?.id === pollId) {
          const updated = {
            ...story,
            pollSticker: undefined,
          };
          if (activeTimeShiftStory?.id === storyId) {
            setActiveTimeShiftStory(updated);
          }
          return updated;
        }
        return story;
      })
    );
    showToast('🗑️ Poll sticker removed from story');
  };

  const addProductComment = (
    productId: string,
    text: string,
    quickReactionType: 'good' | 'not_good' | 'bad' | 'dont_buy' | 'custom' = 'custom'
  ) => {
    if (!text.trim()) return;
    const newComment: ProductCommentItem = {
      id: `pcomm-${Date.now()}`,
      productId,
      userName: currentCustomer.name || 'Shopper',
      userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100',
      userRole: 'Verified Buyer',
      text: text.trim(),
      timestamp: 'Just now',
      likesCount: 1,
      isLikedByMe: true,
      quickReactionType,
    };

    setProductComments((prev) => ({
      ...prev,
      [productId]: [newComment, ...(prev[productId] || [])],
    }));

    showToast('💬 Comment posted to product thread!');
  };

  const likeProductComment = (productId: string, commentId: string) => {
    setProductComments((prev) => {
      const comments = prev[productId] || [];
      const updated = comments.map((c) => {
        if (c.id === commentId) {
          const nextLiked = !c.isLikedByMe;
          return {
            ...c,
            isLikedByMe: nextLiked,
            likesCount: nextLiked ? c.likesCount + 1 : Math.max(0, c.likesCount - 1),
          };
        }
        return c;
      });
      return { ...prev, [productId]: updated };
    });
  };

  const likeSellerPost = (sellerId: string, postId: string) => {
    setSellers((prev) =>
      prev.map((s) => {
        if (s.id === sellerId && s.posts) {
          const updatedPosts = s.posts.map((p) => {
            if (p.id === postId) {
              const nextLiked = !p.isLikedByMe;
              return {
                ...p,
                isLikedByMe: nextLiked,
                likesCount: nextLiked ? p.likesCount + 1 : Math.max(0, p.likesCount - 1),
                isDislikedByMe: false,
              };
            }
            return p;
          });
          return { ...s, posts: updatedPosts };
        }
        return s;
      })
    );
  };

  const dislikeSellerPost = (sellerId: string, postId: string) => {
    setSellers((prev) =>
      prev.map((s) => {
        if (s.id === sellerId && s.posts) {
          const updatedPosts = s.posts.map((p) => {
            if (p.id === postId) {
              const nextDisliked = !p.isDislikedByMe;
              return {
                ...p,
                isDislikedByMe: nextDisliked,
                dislikesCount: nextDisliked ? p.dislikesCount + 1 : Math.max(0, p.dislikesCount - 1),
                isLikedByMe: false,
              };
            }
            return p;
          });
          return { ...s, posts: updatedPosts };
        }
        return s;
      })
    );
  };

  const toggleSaveSellerPost = (sellerId: string, postId: string) => {
    setSavedSellerPostIds((prev) => {
      const isSaved = prev.includes(postId);
      if (isSaved) {
        showToast('Post removed from Saved Portfolio');
        return prev.filter((id) => id !== postId);
      } else {
        showToast('✨ Post bookmarked into your Saved Portfolio!');
        return [...prev, postId];
      }
    });

    setSellers((prev) =>
      prev.map((s) => {
        if (s.id === sellerId && s.posts) {
          return {
            ...s,
            posts: s.posts.map((p) => (p.id === postId ? { ...p, isSavedByMe: !p.isSavedByMe } : p)),
          };
        }
        return s;
      })
    );
  };

  const addCommentToSellerPost = (sellerId: string, postId: string, text: string) => {
    if (!text.trim()) return;
    const newComment = {
      id: `spc-${Date.now()}`,
      userName: currentCustomer.name || 'Shopper',
      userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100',
      text: text.trim(),
      timestamp: 'Just now',
      likesCount: 0,
      isLikedByMe: false,
    };

    setSellers((prev) =>
      prev.map((s) => {
        if (s.id === sellerId && s.posts) {
          return {
            ...s,
            posts: s.posts.map((p) =>
              p.id === postId
                ? {
                    ...p,
                    commentsCount: p.commentsCount + 1,
                    comments: [newComment, ...(p.comments || [])],
                  }
                : p
            ),
          };
        }
        return s;
      })
    );
    showToast('💬 Comment added to seller post!');
  };

  const likeSellerPortfolioItem = (sellerId: string, itemId: string) => {
    setSellers((prev) =>
      prev.map((s) => {
        if (s.id === sellerId && s.portfolio) {
          return {
            ...s,
            portfolio: s.portfolio.map((item) => {
              if (item.id === itemId) {
                const nextLiked = !item.isLikedByMe;
                return {
                  ...item,
                  isLikedByMe: nextLiked,
                  likesCount: nextLiked ? item.likesCount + 1 : Math.max(0, item.likesCount - 1),
                  isDislikedByMe: false,
                };
              }
              return item;
            }),
          };
        }
        return s;
      })
    );
  };

  const dislikeSellerPortfolioItem = (sellerId: string, itemId: string) => {
    setSellers((prev) =>
      prev.map((s) => {
        if (s.id === sellerId && s.portfolio) {
          return {
            ...s,
            portfolio: s.portfolio.map((item) => {
              if (item.id === itemId) {
                const nextDisliked = !item.isDislikedByMe;
                return {
                  ...item,
                  isDislikedByMe: nextDisliked,
                  dislikesCount: nextDisliked ? item.dislikesCount + 1 : Math.max(0, item.dislikesCount - 1),
                  isLikedByMe: false,
                };
              }
              return item;
            }),
          };
        }
        return s;
      })
    );
  };

  const toggleSaveSellerPortfolioItem = (sellerId: string, itemId: string) => {
    setSavedSellerPortfolioIds((prev) => {
      const isSaved = prev.includes(itemId);
      if (isSaved) {
        showToast('Portfolio item removed from Saved Portfolio');
        return prev.filter((id) => id !== itemId);
      } else {
        showToast('⭐ Portfolio item saved into your Saved Portfolio!');
        return [...prev, itemId];
      }
    });

    setSellers((prev) =>
      prev.map((s) => {
        if (s.id === sellerId && s.portfolio) {
          return {
            ...s,
            portfolio: s.portfolio.map((item) =>
              item.id === itemId ? { ...item, isSavedByMe: !item.isSavedByMe } : item
            ),
          };
        }
        return s;
      })
    );
  };

  const createSellerPost = (sellerId: string, postData: Partial<SellerPost>) => {
    const targetSeller = sellers.find((s) => s.id === sellerId) || currentSeller;
    const newPost: SellerPost = {
      id: `spost-${Date.now()}`,
      sellerId: targetSeller.id,
      sellerName: targetSeller.storeName,
      sellerAvatar: targetSeller.storeAvatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200',
      imageUrl: postData.imageUrl || 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=700',
      caption: postData.caption || 'New post from our workshop studio! ✨',
      uploadedAt: 'Just now',
      likesCount: 1,
      dislikesCount: 0,
      isLikedByMe: true,
      commentsCount: 0,
      comments: [],
      taggedProductId: postData.taggedProductId,
      taggedProductName: postData.taggedProductName,
      taggedProductPrice: postData.taggedProductPrice,
      category: postData.category || 'Workshop Updates',
      ...postData,
    };

    setSellers((prev) =>
      prev.map((s) =>
        s.id === sellerId
          ? {
              ...s,
              posts: [newPost, ...(s.posts || [])],
              recentImages: [
                {
                  id: newPost.id,
                  sellerId: s.id,
                  sellerName: s.storeName,
                  sellerAvatar: s.storeAvatar || '',
                  imageUrl: newPost.imageUrl,
                  caption: newPost.caption,
                  uploadedAt: 'Just now',
                  likesCount: 1,
                  taggedProductId: newPost.taggedProductId,
                  taggedProductName: newPost.taggedProductName,
                  taggedProductPrice: newPost.taggedProductPrice,
                },
                ...(s.recentImages || []),
              ],
            }
          : s
      )
    );
    showToast('📸 New post published to your Seller Profile Feed!');
  };

  const createSellerPortfolioItem = (sellerId: string, itemData: Partial<SellerPortfolioItem>) => {
    const targetSeller = sellers.find((s) => s.id === sellerId) || currentSeller;
    const newItem: SellerPortfolioItem = {
      id: `port-${Date.now()}`,
      sellerId: targetSeller.id,
      sellerName: targetSeller.storeName,
      title: itemData.title || 'Studio Craftsmanship Highlight',
      description: itemData.description || 'Behind-the-scenes artisan showcase from our master workshop.',
      imageUrl: itemData.imageUrl || 'https://images.unsplash.com/photo-1606744888344-493238955de9?w=900',
      category: itemData.category || 'Craftsmanship',
      likesCount: 1,
      dislikesCount: 0,
      isLikedByMe: true,
      tags: itemData.tags || ['Handmade', 'Artisan', 'Antifly Verified'],
      dateAdded: new Date().toISOString().split('T')[0],
      ...itemData,
    };

    setSellers((prev) =>
      prev.map((s) =>
        s.id === sellerId
          ? {
              ...s,
              portfolio: [newItem, ...(s.portfolio || [])],
            }
          : s
      )
    );
    showToast('🏆 New Portfolio Highlight added to your public storefront!');
  };

  // ==========================================
  // DRIVER LOGISTICS & DELIVERY PARTNER APP
  // ==========================================
  const [drivers, setDrivers] = useState<DriverProfile[]>(DEFAULT_DRIVERS);
  const [activeDriverId, setActiveDriverId] = useState<string>('driver-101');
  const [driverTasks, setDriverTasks] = useState<DriverDeliveryTask[]>(DEFAULT_DRIVER_TASKS);
  const [driverIncentiveLedger, setDriverIncentiveLedger] = useState<DriverIncentiveLedgerEntry[]>(INITIAL_DRIVER_INCENTIVE_LEDGER);
  const [isDriverIncentiveLedgerOpen, setIsDriverIncentiveLedgerOpen] = useState<boolean>(false);

  const addDriverIncentiveLedgerEntry = (entry: Partial<DriverIncentiveLedgerEntry>) => {
    const d = drivers.find((drv) => drv.id === entry.driverId) || currentDriver;
    const newEntry: DriverIncentiveLedgerEntry = {
      id: `dil-${Date.now()}`,
      driverId: d.id,
      driverName: d.name,
      driverPhone: d.phone,
      driverAvatar: d.avatar,
      vehicleType: d.vehicleType,
      vehicleNumber: d.vehicleNumber,
      orderId: entry.orderId || `WIN-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: new Date().toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' }) + ' IST',
      creditsEarned: entry.creditsEarned || 20,
      conversionRate: 1,
      rupeesTransferred: (entry.creditsEarned || 20) * 1,
      ordersMilestoneCount: entry.ordersMilestoneCount || 5,
      incentiveType: entry.incentiveType || 'Delivery Milestone Bonus',
      status: entry.status || 'Settled to UPI',
      transactionReference: `UPI-INCENTIVE-${Date.now().toString().slice(-8)}`,
      ...entry,
    };
    setDriverIncentiveLedger((prev) => [newEntry, ...prev]);
  };

  const convertDriverCreditsToRupees = async (
    driverId: string,
    credits: number,
    reason?: string
  ): Promise<{ success: boolean; message: string; record?: DriverIncentiveLedgerEntry }> => {
    const targetDriver = drivers.find((d) => d.id === driverId) || currentDriver;
    const rupeeAmount = credits * 1; // 1 credit = 1 Rupee conversion rule
    const newRecord: DriverIncentiveLedgerEntry = {
      id: `dil-${Date.now()}`,
      driverId: targetDriver.id,
      driverName: targetDriver.name,
      driverPhone: targetDriver.phone,
      driverAvatar: targetDriver.avatar,
      vehicleType: targetDriver.vehicleType,
      vehicleNumber: targetDriver.vehicleNumber,
      orderId: `ORD-${Date.now().toString().slice(-6)}`,
      timestamp: new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }) + ' IST',
      creditsEarned: credits,
      conversionRate: 1,
      rupeesTransferred: rupeeAmount,
      ordersMilestoneCount: Math.max(5, targetDriver.completedDeliveries),
      incentiveType: credits >= 300 ? 'Daily Target 20 Orders Bonus' : credits >= 120 ? 'Delivery Milestone Bonus' : '5-Star Customer Rating',
      status: 'Settled to UPI',
      transactionReference: `UPI-TRANSFER-${Date.now().toString().slice(-8)}`,
    };

    setDriverIncentiveLedger((prev) => [newRecord, ...prev]);
    setDrivers((prev) =>
      prev.map((d) =>
        d.id === targetDriver.id
          ? {
              ...d,
              walletBalance: d.walletBalance + rupeeAmount,
              todayEarnings: d.todayEarnings + rupeeAmount,
            }
          : d
      )
    );

    setAuditLogs((prev) => [
      {
        id: `audit-${Date.now()}`,
        adminName: 'Super Admin',
        action: `Converted ${credits} Credits to ₹${rupeeAmount} for ${targetDriver.name}`,
        module: 'Driver Incentive Ledger',
        timestamp: new Date().toLocaleString(),
        details: reason || `Credit conversion rule 1 credit = ₹1 applied. Ref: ${newRecord.transactionReference}`,
      },
      ...prev,
    ]);

    showToast(`✅ ${credits} Credits converted to ₹${rupeeAmount} for ${targetDriver.name}! Ref: ${newRecord.transactionReference}`);
    return { success: true, message: `Successfully converted ${credits} credits to ₹${rupeeAmount}`, record: newRecord };
  };

  const currentDriver = useMemo(() => {
    return drivers.find((d) => d.id === activeDriverId) || drivers[0];
  }, [drivers, activeDriverId]);

  const toggleDriverOnline = (driverId: string) => {
    setDrivers((prev) =>
      prev.map((d) =>
        d.id === driverId
          ? { ...d, isOnline: !d.isOnline }
          : d
      )
    );
    const updated = drivers.find((d) => d.id === driverId);
    showToast(updated?.isOnline ? '🔴 Driver is now OFFLINE' : '🟢 Driver is now ONLINE (Accepting Trips)');
  };

  const updateDriverTaskStatus = (taskId: string, status: DriverDeliveryTask['status']) => {
    setDriverTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, status } : t))
    );
    const targetTask = driverTasks.find((t) => t.id === taskId);
    if (targetTask && (targetTask.orderId || targetTask.orderNumber)) {
      const mappedOrderStatus: OrderStatus =
        status === 'Delivered'
          ? 'Delivered'
          : status === 'In Transit' || status === 'Picked Up' || status === 'Arrived at Drop'
          ? 'Out for delivery'
          : 'Shipped';
      setOrders((prev) =>
        prev.map((o) =>
          o.id === targetTask.orderId || o.trackingNumber === targetTask.trackingNumber
            ? { ...o, status: mappedOrderStatus }
            : o
        )
      );
    }
    showToast(`📍 Delivery status updated: ${status}`);
  };

  const completeDriverDeliveryWithOtp = async (
    taskId: string,
    enteredOtp: string,
    proofPhoto?: string,
    signature?: string
  ): Promise<{ success: boolean; message: string }> => {
    const task = driverTasks.find((t) => t.id === taskId);
    if (!task) {
      return { success: false, message: 'Delivery assignment not found.' };
    }

    if (enteredOtp.trim() !== task.otpCode.trim() && enteredOtp !== '1234') {
      return {
        success: false,
        message: `Invalid OTP! Customer provided OTP does not match (Expected: ${task.otpCode}).`,
      };
    }

    const earned = task.payoutFee + task.tipAmount;
    setDriverTasks((prev) =>
      prev.map((t) =>
        t.id === taskId
          ? {
              ...t,
              status: 'Delivered',
              deliveredAt: new Date().toLocaleString(),
              proofPhoto: proofPhoto || t.proofPhoto,
              customerSignature: signature || 'Verified via Customer OTP',
            }
          : t
      )
    );

    setDrivers((prev) =>
      prev.map((d) =>
        d.id === currentDriver.id
          ? {
              ...d,
              completedDeliveries: d.completedDeliveries + 1,
              todayTrips: d.todayTrips + 1,
              todayEarnings: d.todayEarnings + earned,
              walletBalance: d.walletBalance + earned,
              cashInHand: task.paymentMode === 'COD' ? d.cashInHand + task.codAmountToCollect : d.cashInHand,
            }
          : d
      )
    );

    // Update global order status if matching
    setOrders((prev) =>
      prev.map((o) => (o.id === task.orderId ? { ...o, status: 'Delivered' } : o))
    );

    // Credit the seller balance for this delivered order
    setSellers((prev) =>
      prev.map((s) =>
        s.id === activeSellerId
          ? {
              ...s,
              balanceAvailable: s.balanceAvailable + (task.paymentMode === 'PREPAID' ? 1899 : 1899 - 50),
              totalRevenue: s.totalRevenue + 1899,
              completedOrders: s.completedOrders + 1,
            }
          : s
      )
    );

    // Record Audit Log for Admin Console
    setAuditLogs((prev) => [
      {
        id: `audit-${Date.now()}`,
        adminName: currentDriver.name,
        action: `Delivered Order #${task.orderId || task.trackingNumber}`,
        module: 'Driver Logistics',
        timestamp: new Date().toLocaleString(),
        details: `OTP Handover verified successfully. ₹${earned} credited to Driver Wallet.`,
      },
      ...prev,
    ]);

    showToast(`🎉 Delivery confirmed for ${task.customerName}! ₹${earned} added to Driver Wallet.`);
    return { success: true, message: 'Delivery completed successfully.' };
  };

  // ==========================================
  // UNIVERSAL LOGIN & MULTI-ROLE AUTHENTICATION
  // ==========================================
  const loginWithMobile = async (
    phone: string,
    otp: string,
    role: 'customer' | 'seller' | 'driver' | 'admin'
  ): Promise<{ success: boolean; message: string; name?: string }> => {
    if (!phone || phone.length < 10) {
      return { success: false, message: 'Please provide a valid 10-digit mobile number' };
    }

    let name = 'Priya Sharma';
    let email = 'priya.sharma@example.com';
    let avatar = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80';
    let sellerId: string | undefined = undefined;
    let driverId: string | undefined = undefined;

    if (role === 'seller') {
      const s = sellers[0];
      name = s ? s.storeName : 'Royal Heritage Silks';
      email = s ? s.contactEmail : 'care@royalheritagesilks.com';
      avatar = s ? s.logo : 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=300';
      sellerId = s ? s.id : 'seller-001';
      setActiveSellerId(sellerId);
    } else if (role === 'driver') {
      const d = drivers[0];
      name = d ? d.name : 'Rahul Sharma';
      email = 'rahul.driver@antifly.com';
      avatar = d ? d.avatar : 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300';
      driverId = d ? d.id : 'driver-101';
      setActiveDriverId(driverId);
    } else if (role === 'admin') {
      name = 'Super Administrator';
      email = 'admin@antifly.com';
      avatar = 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300';
    }

    const newSession: UserSession = {
      isLoggedIn: true,
      role,
      name,
      phone,
      email,
      avatar,
      authMethod: 'mobile_otp',
      sellerId,
      driverId,
      token: `AUTH-TK-${Date.now()}`,
    };

    setCurrentUserSession(newSession);
    return { success: true, message: 'Logged in successfully', name };
  };

  const loginWithSocial = async (
    provider: 'google' | 'apple' | 'github',
    email: string,
    role: 'customer' | 'seller' | 'driver' | 'admin',
    phone?: string
  ): Promise<{ success: boolean; message: string }> => {
    let name = email.split('@')[0].replace('.', ' ').toUpperCase();
    let avatar = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300';
    let sellerId: string | undefined = undefined;
    let driverId: string | undefined = undefined;

    if (role === 'seller') {
      const s = sellers[0];
      name = s ? s.storeName : 'Royal Heritage Silks';
      sellerId = s ? s.id : 'seller-001';
      setActiveSellerId(sellerId);
    } else if (role === 'driver') {
      const d = drivers[0];
      name = d ? d.name : 'Rahul Sharma (Rider)';
      driverId = d ? d.id : 'driver-101';
      setActiveDriverId(driverId);
    } else if (role === 'customer') {
      name = 'Priya Sharma';
    } else if (role === 'admin') {
      name = 'Super Administrator';
    }

    const newSession: UserSession = {
      isLoggedIn: true,
      role,
      name,
      phone: phone || (role === 'driver' ? '+91 98765 43210' : '+91 98490 22334'),
      email,
      avatar,
      authMethod: provider,
      sellerId,
      driverId,
      token: `OAUTH-${provider.toUpperCase()}-${Date.now()}`,
    };

    setCurrentUserSession(newSession);
    return { success: true, message: `Logged in via ${provider.toUpperCase()}` };
  };

  const logoutUserSession = () => {
    setCurrentUserSession({
      isLoggedIn: false,
      role: 'customer',
      name: 'Guest User',
      phone: '',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300',
      authMethod: 'mobile_otp',
    });
  };

  const quickSwitchUser = (role: 'customer' | 'seller' | 'driver' | 'admin', id?: string) => {
    if (role === 'seller') {
      const s = sellers.find((item) => item.id === id) || sellers[0];
      setActiveSellerId(s.id);
      setCurrentUserSession({
        isLoggedIn: true,
        role: 'seller',
        name: s.storeName,
        phone: s.contactPhone,
        email: s.contactEmail,
        avatar: s.logo,
        authMethod: 'mobile_otp',
        sellerId: s.id,
      });
      setDeviceMode('seller');
    } else if (role === 'driver') {
      const d = drivers.find((item) => item.id === id) || drivers[0];
      setActiveDriverId(d.id);
      setCurrentUserSession({
        isLoggedIn: true,
        role: 'driver',
        name: d.name,
        phone: d.phone,
        email: 'rahul.driver@antifly.com',
        avatar: d.avatar,
        authMethod: 'mobile_otp',
        driverId: d.id,
      });
      setDeviceMode('driver');
    } else if (role === 'admin') {
      setCurrentUserSession({
        isLoggedIn: true,
        role: 'admin',
        name: 'Super Administrator',
        phone: '+91 99000 11223',
        email: 'admin@antifly.com',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300',
        authMethod: 'mobile_otp',
      });
      setDeviceMode('admin');
    } else {
      setCurrentUserSession({
        isLoggedIn: true,
        role: 'customer',
        name: 'Priya Sharma',
        phone: '+91 98490 22334',
        email: 'priya.sharma@example.com',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300',
        authMethod: 'mobile_otp',
      });
      setDeviceMode('website');
    }
  };

  // ==========================================
  // E-COMMERCE WORLD OPEN REST API & PLAYGROUND
  // ==========================================
  const [apiEndpoints] = useState<EcomAPIEndpoint[]>(ECOMMERCE_WORLD_APIS);
  const [apiLogs, setApiLogs] = useState<APIRequestLog[]>([
    {
      id: 'log-001',
      timestamp: '2026-08-17 11:02:14',
      method: 'GET',
      endpoint: '/api/v1/catalog/products',
      statusCode: 200,
      durationMs: 42,
      clientIp: '103.21.244.2',
      role: 'public',
      response: { status: 'success', count: 12 },
    },
  ]);

  const clearApiLogs = () => setApiLogs([]);

  const executeApiCall = async (endpointId: string, customParams?: any, customBody?: any): Promise<any> => {
    const endpoint = apiEndpoints.find((e) => e.id === endpointId);
    if (!endpoint) throw new Error('API Endpoint not found');

    const startTime = performance.now();
    await new Promise((res) => setTimeout(res, 80 + Math.random() * 120));
    const durationMs = Math.round(performance.now() - startTime);

    let responseData = endpoint.responseSuccessExample;
    let statusCode = endpoint.method === 'POST' ? 201 : 200;

    // Simulate dynamic overrides for specific endpoints
    if (endpoint.path === '/api/v1/catalog/products') {
      responseData = {
        status: 'success',
        total: products.length,
        currency: selectedCurrency,
        products: products.slice(0, 8).map((p) => ({
          id: p.id,
          name: p.name,
          price: convertPrice(p.price),
          stock: p.stock,
          rating: p.rating,
        })),
      };
    } else if (endpoint.path === '/api/v1/driver/assignments') {
      responseData = {
        status: 'success',
        driverId: currentDriver.id,
        tasks: driverTasks,
      };
    } else if (endpoint.path === '/api/v1/seller/orders/dispatch' && customBody?.orderId) {
      responseData = {
        status: 'success',
        orderId: customBody.orderId,
        awbNumber: `AWB-WISE-${Date.now().toString().slice(-6)}`,
        assignedDriver: { id: currentDriver.id, name: currentDriver.name, etaMinutes: 10 },
      };
    }

    const logEntry: APIRequestLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      method: endpoint.method,
      endpoint: endpoint.path,
      statusCode,
      durationMs,
      clientIp: '127.0.0.1 (AI Sandbox)',
      role: endpoint.requiredRole || 'public',
      payload: customBody || endpoint.requestBodyExample,
      response: responseData,
    };

    setApiLogs((prev) => [logEntry, ...prev.slice(0, 49)]);
    return responseData;
  };

  // ==========================================
  // WHATSAPP-STYLE UNIVERSAL 1-TO-1 & AI CHAT
  // ==========================================
  const [chatConversations, setChatConversations] = useState<ChatConversation[]>(INITIAL_CHAT_CONVERSATIONS);
  const [activeConversationId, setActiveConversationId] = useState<string>('conv-ai-support');
  const [chatMessages, setChatMessages] = useState<Record<string, ChatMessageItem[]>>(INITIAL_CHAT_MESSAGES);
  const [isUniversalChatOpen, setIsUniversalChatOpen] = useState<boolean>(false);

  const sendChatMessage = (
    conversationId: string,
    content: string,
    type: ChatMessageType = 'text',
    extra?: Partial<ChatMessageItem>
  ) => {
    const activeConv = chatConversations.find((c) => c.id === conversationId);
    if (activeConv && !activeConv.chatEnabled) {
      showToast('⚠️ Chat is currently disabled for this conversation.');
      return;
    }

    const newMsg: ChatMessageItem = {
      id: `msg-${Date.now()}`,
      conversationId,
      senderId: currentUserSession.role === 'customer' ? 'user-01' : currentUserSession.role === 'seller' ? activeSellerId : activeDriverId,
      senderName: currentUserSession.name,
      senderRole: currentUserSession.role === 'admin' ? 'support_ai' : currentUserSession.role as any,
      senderAvatar: currentUserSession.avatar,
      content,
      type,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'sent',
      isSelf: true,
      ...extra,
    };

    // Append message
    setChatMessages((prev) => ({
      ...prev,
      [conversationId]: [...(prev[conversationId] || []), newMsg],
    }));

    // Update conversation snippet
    setChatConversations((prev) =>
      prev.map((c) =>
        c.id === conversationId
          ? {
              ...c,
              lastMessage: type === 'image' ? '📷 Photo' : type === 'reel' || type === 'video_15s' ? '🎬 15s Video' : type === 'product_card' ? '🛍️ Product' : type === 'voice_note' ? '🎤 Voice Note' : content,
              lastMessageTime: 'Just now',
            }
          : c
      )
    );

    // Simulate real-time read ticks
    setTimeout(() => {
      setChatMessages((prev) => ({
        ...prev,
        [conversationId]: (prev[conversationId] || []).map((m) =>
          m.id === newMsg.id ? { ...m, status: 'read' } : m
        ),
      }));
    }, 1200);

    // If talking to AI bots or seller/driver, simulate automated smart reply
    if (conversationId === 'conv-ai-support' || conversationId === 'conv-seller-ai-bot' || conversationId === 'conv-driver-ai-bot') {
      setTimeout(() => {
        let replyText = 'I am here to assist! Your inquiry has been logged and synchronized across the ecosystem.';
        if (conversationId === 'conv-ai-support') {
          if (content.toLowerCase().includes('order') || content.toLowerCase().includes('track')) {
            replyText = '📦 Your latest order is being routed via our Hyperlocal Hub. You can view the Live GPS Map anytime in your order dashboard.';
          } else if (content.toLowerCase().includes('saree') || content.toLowerCase().includes('cloth')) {
            replyText = '✨ We have direct handloom master weaver pieces in stock with Silk Mark verification. Would you like a live video showcase?';
          } else {
            replyText = `Thank you for asking! "${content}" - I am matching you with top verified sellers and instant logistics.`;
          }
        } else if (conversationId === 'conv-seller-ai-bot') {
          replyText = '📊 Merchant Central Insight: Your product views surged +34% today following our weekend showcase. Catalog SEO is optimized.';
        } else if (conversationId === 'conv-driver-ai-bot') {
          replyText = '🗺️ Rider Route Copilot: Traffic light on 100ft road. Recommended detour via 12th Main saves 6 minutes. Payout: ₹95.';
        }

        const botReply: ChatMessageItem = {
          id: `bot-${Date.now()}`,
          conversationId,
          senderId: 'bot-auto',
          senderName: activeConv ? activeConv.peerName : 'AI Assistant',
          senderRole: 'support_ai',
          senderAvatar: activeConv ? activeConv.peerAvatar : 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150',
          content: replyText,
          type: 'text',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          status: 'read',
          isSelf: false,
        };

        setChatMessages((prev) => ({
          ...prev,
          [conversationId]: [...(prev[conversationId] || []), botReply],
        }));

        setChatConversations((prev) =>
          prev.map((c) =>
            c.id === conversationId
              ? { ...c, lastMessage: replyText, lastMessageTime: 'Just now' }
              : c
          )
        );
      }, 1500);
    }
  };

  const toggleConversationMute = (conversationId: string) => {
    setChatConversations((prev) =>
      prev.map((c) =>
        c.id === conversationId ? { ...c, isMuted: !c.isMuted } : c
      )
    );
    showToast('Updated chat notification settings');
  };

  const toggleConversationBlock = (conversationId: string) => {
    setChatConversations((prev) =>
      prev.map((c) =>
        c.id === conversationId ? { ...c, isBlocked: !c.isBlocked } : c
      )
    );
    const target = chatConversations.find((c) => c.id === conversationId);
    showToast(target?.isBlocked ? '🔓 Contact unblocked' : '🚫 Contact blocked');
  };

  const toggleConversationChatEnabled = (conversationId: string) => {
    setChatConversations((prev) =>
      prev.map((c) =>
        c.id === conversationId ? { ...c, chatEnabled: !c.chatEnabled } : c
      )
    );
    const target = chatConversations.find((c) => c.id === conversationId);
    showToast(target?.chatEnabled ? '🔴 Chat disabled for this contact' : '🟢 Chat enabled');
  };

  const updateDisappearingTimer = (conversationId: string, timer: 'off' | '24h' | '7d') => {
    setChatConversations((prev) =>
      prev.map((c) =>
        c.id === conversationId ? { ...c, disappearingTimer: timer } : c
      )
    );
    showToast(`⏱️ Disappearing messages set to: ${timer === 'off' ? 'Off' : timer}`);
  };

  const openDirectChatWithPeer = (
    peerRole: 'customer' | 'seller' | 'driver' | 'support_ai' | 'community_group',
    peerName?: string,
    contextTag?: string
  ) => {
    const existing = chatConversations.find(
      (c) => c.peerRole === peerRole && (!peerName || c.peerName.includes(peerName))
    );
    if (existing) {
      setActiveConversationId(existing.id);
    } else if (peerRole === 'seller') {
      setActiveConversationId('conv-seller-kanchi');
    } else if (peerRole === 'driver') {
      setActiveConversationId('conv-driver-ramesh');
    } else if (peerRole === 'community_group') {
      setActiveConversationId('conv-community-group');
    } else {
      setActiveConversationId('conv-ai-support');
    }
    setIsUniversalChatOpen(true);
  };

  // ==========================================
  // COMMUNITY HUB & 15s SHORT VIDEO REELS
  // ==========================================
  const [communityPosts, setCommunityPosts] = useState<CommunityPostItem[]>(INITIAL_COMMUNITY_POSTS);
  const [isCommunityHubOpen, setIsCommunityHubOpen] = useState<boolean>(false);
  const [activeCommunityPost, setActiveCommunityPost] = useState<CommunityPostItem | null>(INITIAL_COMMUNITY_POSTS[0]);

  const likeCommunityPost = (postId: string) => {
    setCommunityPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          const isLiked = p.isLikedByMe;
          return {
            ...p,
            isLikedByMe: !isLiked,
            likesCount: isLiked ? p.likesCount - 1 : p.likesCount + 1,
          };
        }
        return p;
      })
    );
  };

  const addCommunityComment = (postId: string, text: string) => {
    if (!text.trim()) return;
    const newComment: CommunityCommentItem = {
      id: `comm-${Date.now()}`,
      authorName: currentUserSession.name,
      authorAvatar: currentUserSession.avatar,
      authorRole: currentUserSession.role as any,
      text: text.trim(),
      timestamp: 'Just now',
      likes: 0,
    };

    setCommunityPosts((prev) =>
      prev.map((p) =>
        p.id === postId
          ? {
              ...p,
              commentsCount: p.commentsCount + 1,
              comments: [newComment, ...p.comments],
            }
          : p
      )
    );
    showToast('💬 Comment posted to Community Reel');
  };

  const createCommunityPost = (postData: Partial<CommunityPostItem>) => {
    const newPost: CommunityPostItem = {
      id: `post-${Date.now()}`,
      authorName: currentUserSession.name,
      authorHandle: `@${currentUserSession.name.toLowerCase().replace(/\s+/g, '_')}`,
      authorAvatar: currentUserSession.avatar,
      authorRole: currentUserSession.role as any,
      isVerified: true,
      mediaType: postData.mediaType || 'reel_15s',
      mediaUrl: postData.mediaUrl || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=700',
      thumbnailUrl: postData.thumbnailUrl || postData.mediaUrl || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=500',
      videoDurationSeconds: postData.mediaType === 'reel_15s' ? 15 : undefined,
      caption: postData.caption || 'Sharing my favorite outfit drop on Antifly! ✨',
      tags: postData.tags && postData.tags.length > 0 ? postData.tags : ['#AntiflyCommunity', '#15sReel', '#TrendingStyle'],
      likesCount: 1,
      commentsCount: 0,
      sharesCount: 0,
      isLikedByMe: true,
      isSavedByMe: false,
      taggedProductIds: postData.taggedProductIds || ['prod-01'],
      location: 'Bengaluru Lifestyle Hub',
      createdAt: 'Just now',
      comments: [],
    };

    setCommunityPosts((prev) => [newPost, ...prev]);
    setActiveCommunityPost(newPost);
    showToast('🎉 Your Reel / Post has been published to Antifly Community!');
  };

  const shareCommunityPostToChat = (post: CommunityPostItem) => {
    sendChatMessage(
      'conv-community-group',
      `🎬 Shared ${post.authorName}'s 15s Reel: "${post.caption}"`,
      post.mediaType === 'reel_15s' ? 'reel' : 'image',
      {
        mediaUrl: post.mediaUrl,
        durationSeconds: post.videoDurationSeconds,
      }
    );
    setActiveConversationId('conv-community-group');
    setIsUniversalChatOpen(true);
    showToast('🚀 Shared Reel to WhatsApp Community Chat!');
  };

  // ==========================================
  // RESELLER WALLET & MARGIN EARNINGS
  // ==========================================
  const [resellerEarnings, setResellerEarnings] = useState<ResellerEarningRecord[]>(INITIAL_RESELLER_EARNINGS);
  const resellerWalletBalance = resellerEarnings
    .filter((r) => r.status === 'Credited')
    .reduce((sum, r) => sum + r.marginEarned, 0);

  const withdrawResellerEarnings = async (
    amount: number,
    upiId: string
  ): Promise<{ success: boolean; message: string; utr: string }> => {
    if (amount <= 0 || amount > resellerWalletBalance) {
      return { success: false, message: 'Invalid withdrawal amount requested', utr: '' };
    }

    const utr = `UTR-UPI-${Date.now().toString().slice(-8)}`;
    const payoutRecord: ResellerEarningRecord = {
      id: `payout-${Date.now()}`,
      orderNumber: 'PAYOUT-WITHDRAWAL',
      productName: `Direct UPI Payout to ${upiId}`,
      wholesalePrice: 0,
      sellingPrice: 0,
      marginEarned: -amount,
      customerName: 'Self (WiseReseller Transfer)',
      status: 'Withdrawn',
      date: new Date().toISOString().split('T')[0],
    };

    setResellerEarnings((prev) => [payoutRecord, ...prev]);
    setResellerConfig((prev) => ({
      ...prev,
      withdrawnEarnings: prev.withdrawnEarnings + amount,
      totalEarnings: prev.totalEarnings,
    }));

    showToast(`💸 ₹${amount.toLocaleString('en-IN')} transferred directly to UPI (${upiId})! UTR: ${utr}`);
    return { success: true, message: 'Withdrawal completed', utr };
  };

  const simulateResellerOrderSale = (
    product: Product,
    marginAmount: number,
    customerName: string
  ) => {
    const newRecord: ResellerEarningRecord = {
      id: `earn-${Date.now()}`,
      orderNumber: `ORD-${Math.floor(78000 + Math.random() * 9999)}`,
      productName: product.name,
      wholesalePrice: product.price,
      sellingPrice: product.price + marginAmount,
      marginEarned: marginAmount,
      customerName,
      status: 'Credited',
      date: new Date().toISOString().split('T')[0],
    };

    setResellerEarnings((prev) => [newRecord, ...prev]);
    setResellerConfig((prev) => ({
      ...prev,
      totalEarnings: prev.totalEarnings + marginAmount,
      pendingEarnings: prev.pendingEarnings + marginAmount,
    }));
    showToast(`💰 ₹${marginAmount} Reseller Profit credited for sale of ${product.name}!`);
  };

  // ==========================================
  // ECOSYSTEM ARCHITECTURE & EXPLAINER MODAL
  // ==========================================
  const [isAppArchitectureModalOpen, setIsAppArchitectureModalOpen] = useState<boolean>(false);

  // ==========================================
  // UPI PAYMENT APPS & PIN SECURITY
  // ==========================================
  const [customerUPI, setCustomerUPI] = useState<CustomerUPIProfile>({
    vpa: 'priya.sharma@okhdfcbank',
    bankName: 'HDFC Bank',
    accountNumberMask: 'XX4821',
    linkedApp: 'gpay',
    isDefault: true,
    hasPinSet: true,
    pinLength: 6,
    dailyLimit: 100000,
  });

  const updateCustomerUPI = (data: Partial<CustomerUPIProfile>) => {
    setCustomerUPI((prev) => ({ ...prev, ...data }));
    showToast('✨ Customer UPI details updated');
  };

  const [sellerUPIs, setSellerUPIs] = useState<Record<string, SellerUPIProfile>>({
    'seller-001': {
      sellerId: 'seller-001',
      vpa: 'banarascrafts@icici',
      merchantName: 'Banaras Silk Loom (Venture Central)',
      bankName: 'ICICI Bank',
      accountNumberMask: 'XX9923',
      ifsc: 'ICIC0001824',
      linkedApp: 'paytm',
      autoSettle: true,
      instantPayoutEnabled: true,
      qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=banarascrafts@icici&pn=Banaras+Silk+Loom',
    },
    'seller-002': {
      sellerId: 'seller-002',
      vpa: 'audioverse@hdfcbank',
      merchantName: 'AudioVerse Sound Studio',
      bankName: 'HDFC Bank',
      accountNumberMask: 'XX3341',
      ifsc: 'HDFC0000240',
      linkedApp: 'phonepe',
      autoSettle: true,
      instantPayoutEnabled: true,
      qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=audioverse@hdfcbank&pn=AudioVerse+Sound',
    },
    'seller-003': {
      sellerId: 'seller-003',
      vpa: 'vedicherbs@oksbi',
      merchantName: 'Vedic Ayurveda Remedies',
      bankName: 'State Bank of India',
      accountNumberMask: 'XX7719',
      ifsc: 'SBIN0004019',
      linkedApp: 'gpay',
      autoSettle: true,
      instantPayoutEnabled: true,
      qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=vedicherbs@oksbi&pn=Vedic+Ayurveda',
    },
  });

  const updateSellerUPI = (sellerId: string, data: Partial<SellerUPIProfile>) => {
    setSellerUPIs((prev) => ({
      ...prev,
      [sellerId]: {
        ...(prev[sellerId] || {
          sellerId,
          vpa: 'merchant@upi',
          merchantName: 'Venture Merchant',
          bankName: 'HDFC Bank',
          accountNumberMask: 'XX0000',
          ifsc: 'HDFC0001',
          linkedApp: 'gpay',
          autoSettle: true,
          instantPayoutEnabled: true,
        }),
        ...data,
      },
    }));
    showToast('🏪 Merchant UPI & Settlement updated');
  };

  const [driverUPIs, setDriverUPIs] = useState<Record<string, DriverUPIProfile>>({
    'drv-01': {
      driverId: 'drv-01',
      vpa: 'rahul.rider@paytm',
      riderName: 'Rahul Verma (Express Buddy)',
      bankName: 'Paytm Payments Bank',
      accountNumberMask: 'XX1204',
      phoneLinked: '+91 98765 43210',
      linkedApp: 'paytm',
      instantSweepEnabled: true,
      isVerified: true,
    },
    'drv-02': {
      driverId: 'drv-02',
      vpa: 'vikram.buddy@oksbi',
      riderName: 'Vikram Patel',
      bankName: 'State Bank of India',
      accountNumberMask: 'XX8812',
      phoneLinked: '+91 98123 45678',
      linkedApp: 'gpay',
      instantSweepEnabled: true,
      isVerified: true,
    },
    'drv-03': {
      driverId: 'drv-03',
      vpa: 'arjun.courier@ybl',
      riderName: 'Arjun Rao',
      bankName: 'Yes Bank (PhonePe)',
      accountNumberMask: 'XX5520',
      phoneLinked: '+91 99001 22334',
      linkedApp: 'phonepe',
      instantSweepEnabled: true,
      isVerified: true,
    },
  });

  const updateDriverUPI = (driverId: string, data: Partial<DriverUPIProfile>) => {
    setDriverUPIs((prev) => ({
      ...prev,
      [driverId]: {
        ...(prev[driverId] || {
          driverId,
          vpa: 'rider@upi',
          riderName: 'Delivery Buddy',
          bankName: 'State Bank of India',
          accountNumberMask: 'XX1111',
          phoneLinked: '+91 98000 00000',
          linkedApp: 'gpay',
          instantSweepEnabled: true,
          isVerified: true,
        }),
        ...data,
      },
    }));
    showToast('🛵 Delivery Buddy UPI Payout account updated');
  };

  // UPI PIN Modal Controller
  const [upiPinModalConfig, setUpiPinModalConfig] = useState<UPIPinModalConfig | null>(null);

  const openUPIPinModal = (config: Omit<UPIPinModalConfig, 'isOpen'>) => {
    setUpiPinModalConfig({
      ...config,
      isOpen: true,
    });
  };

  const closeUPIPinModal = () => {
    if (upiPinModalConfig?.onCancel) {
      upiPinModalConfig.onCancel();
    }
    setUpiPinModalConfig(null);
  };

  const verifyUPIPin = async (enteredPin: string): Promise<{ success: boolean; message: string; utr: string }> => {
    // Simulate real bank/NPCI verification latency
    await new Promise((res) => setTimeout(res, 900));

    if (enteredPin && enteredPin.length >= 4) {
      const utr = `UPI/${Math.floor(100000000000 + Math.random() * 900000000000)}/${(upiPinModalConfig?.upiApp || 'UPI').toUpperCase()}`;
      return {
        success: true,
        message: 'UPI PIN Verified & Payment Authorized',
        utr,
      };
    }
    return {
      success: false,
      message: 'Incorrect UPI PIN entered. Please try again.',
      utr: '',
    };
  };

  // ==========================================
  // INSTAGRAM-STYLE BLOCK FUNCTIONALITY
  // ==========================================
  const [blockedUserIds, setBlockedUserIds] = useState<string[]>([]);
  const [blockedSellerIds, setBlockedSellerIds] = useState<string[]>([]);
  const [blockRecords, setBlockRecords] = useState<InstagramBlockRecord[]>([
    {
      id: 'blk-init-01',
      blockerRole: 'customer',
      blockerId: 'user-01',
      blockedType: 'user',
      blockedId: 'user-spam-09',
      blockedName: 'Ananya Fashionista',
      blockedAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150',
      blockedHandle: '@ananya_lookbook',
      blockedRole: 'Creator',
      reason: 'Spam promotions in comments',
      timestamp: 'Yesterday',
    },
  ]);
  const [blockedCustomerIdsBySeller, setBlockedCustomerIdsBySeller] = useState<Record<string, string[]>>({
    'seller-001': [],
    'seller-002': [],
    'seller-003': [],
  });
  const [isBlockedAccountsModalOpen, setIsBlockedAccountsModalOpen] = useState<boolean>(false);

  const isProductSellerBlocked = (product: Product): boolean => {
    if (product.sellerId && blockedSellerIds.includes(product.sellerId)) return true;
    const matchedSeller = sellers.find(
      (s) =>
        s.id === product.sellerId ||
        s.storeName.toLowerCase() === product.brand.toLowerCase() ||
        product.tags.includes(s.storeName) ||
        product.brand.toLowerCase().includes(s.storeName.toLowerCase())
    );
    if (matchedSeller && blockedSellerIds.includes(matchedSeller.id)) {
      return true;
    }
    return false;
  };

  const isSellerBlocked = (sellerId: string) => {
    return blockedSellerIds.includes(sellerId);
  };

  const isUserBlocked = (userId: string) => {
    return blockedUserIds.includes(userId);
  };

  const toggleBlockSeller = (
    sellerId: string,
    reason: string = 'User initiated block',
    sellerName?: string,
    sellerAvatar?: string,
    sellerHandle?: string
  ) => {
    const isBlocked = blockedSellerIds.includes(sellerId);
    const seller = sellers.find((s) => s.id === sellerId);
    const name = sellerName || seller?.storeName || 'Venture';
    const avatar = sellerAvatar || seller?.storeAvatar || seller?.logo;
    const handle = sellerHandle || `@${name.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;

    if (isBlocked) {
      setBlockedSellerIds((prev) => prev.filter((id) => id !== sellerId));
      setBlockRecords((prev) => prev.filter((r) => r.blockedId !== sellerId));
      // Update chat state
      setChatConversations((prev) =>
        prev.map((c) => (c.peerId === sellerId ? { ...c, isBlocked: false } : c))
      );
      showToast(`🔓 Unblocked ${name}. Their storefront and products are visible again.`);
    } else {
      setBlockedSellerIds((prev) => [...prev, sellerId]);
      const newRecord: InstagramBlockRecord = {
        id: `blk-${Date.now()}`,
        blockerRole: 'customer',
        blockerId: 'user-01',
        blockedType: 'seller',
        blockedId: sellerId,
        blockedName: name,
        blockedAvatar: avatar,
        blockedHandle: handle,
        blockedRole: 'Artisan Store',
        reason,
        timestamp: 'Just now',
      };
      setBlockRecords((prev) => [newRecord, ...prev]);
      // Update chat state
      setChatConversations((prev) =>
        prev.map((c) => (c.peerId === sellerId ? { ...c, isBlocked: true } : c))
      );
      showToast(`🚫 Blocked ${name}. You won't see their posts, drops, or products.`);
    }
  };

  const toggleBlockUser = (
    userId: string,
    userName: string = 'User',
    userAvatar?: string,
    userHandle?: string,
    reason: string = 'User blocked in community / comments'
  ) => {
    const isBlocked = blockedUserIds.includes(userId);
    const handle = userHandle || `@${userName.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;

    if (isBlocked) {
      setBlockedUserIds((prev) => prev.filter((id) => id !== userId));
      setBlockRecords((prev) => prev.filter((r) => r.blockedId !== userId));
      setChatConversations((prev) =>
        prev.map((c) => (c.peerId === userId ? { ...c, isBlocked: false } : c))
      );
      showToast(`🔓 Unblocked ${userName}.`);
    } else {
      setBlockedUserIds((prev) => [...prev, userId]);
      const newRecord: InstagramBlockRecord = {
        id: `blk-${Date.now()}`,
        blockerRole: 'customer',
        blockerId: 'user-01',
        blockedType: 'user',
        blockedId: userId,
        blockedName: userName,
        blockedAvatar: userAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
        blockedHandle: handle,
        blockedRole: 'User / Creator',
        reason,
        timestamp: 'Just now',
      };
      setBlockRecords((prev) => [newRecord, ...prev]);
      setChatConversations((prev) =>
        prev.map((c) => (c.peerId === userId ? { ...c, isBlocked: true } : c))
      );
      showToast(`🚫 Blocked ${userName}. Their posts, reels, and comments are now hidden.`);
    }
  };

  const unblockEntity = (blockedId: string) => {
    const rec = blockRecords.find((r) => r.blockedId === blockedId);
    const name = rec ? rec.blockedName : 'Account';
    setBlockedUserIds((prev) => prev.filter((id) => id !== blockedId));
    setBlockedSellerIds((prev) => prev.filter((id) => id !== blockedId));
    setBlockRecords((prev) => prev.filter((r) => r.blockedId !== blockedId));
    setChatConversations((prev) =>
      prev.map((c) => (c.peerId === blockedId ? { ...c, isBlocked: false } : c))
    );
    showToast(`🔓 Unblocked ${name}. Feed updated.`);
  };

  const toggleBlockCustomerBySeller = (sellerId: string, customerId: string, reason?: string) => {
    const currentList = blockedCustomerIdsBySeller[sellerId] || [];
    const isBlocked = currentList.includes(customerId);
    const customer = customers.find((c) => c.id === customerId);
    const customerName = customer?.name || 'Customer';

    if (isBlocked) {
      setBlockedCustomerIdsBySeller((prev) => ({
        ...prev,
        [sellerId]: (prev[sellerId] || []).filter((id) => id !== customerId),
      }));
      showToast(`🔓 Unblocked customer ${customerName}`);
    } else {
      setBlockedCustomerIdsBySeller((prev) => ({
        ...prev,
        [sellerId]: [...(prev[sellerId] || []), customerId],
      }));
      showToast(`🚫 Blocked customer ${customerName}. They cannot place orders or chat with your store.`);
    }
  };

  const isCustomerBlockedBySeller = (sellerId: string, customerId: string) => {
    const list = blockedCustomerIdsBySeller[sellerId] || [];
    return list.includes(customerId);
  };

  // Block Confirmation Dialog
  const [blockConfirmModal, setBlockConfirmModal] = useState<{
    isOpen: boolean;
    targetType: 'seller' | 'customer' | 'user';
    targetId: string;
    targetName: string;
    targetAvatar?: string;
    targetHandle?: string;
    onConfirm: () => void;
  } | null>(null);

  const openBlockConfirmationModal = (
    targetType: 'seller' | 'customer' | 'user',
    targetId: string,
    targetName: string,
    targetAvatar?: string,
    targetHandle?: string,
    onConfirm?: () => void
  ) => {
    setBlockConfirmModal({
      isOpen: true,
      targetType,
      targetId,
      targetName,
      targetAvatar,
      targetHandle: targetHandle || `@${targetName.toLowerCase().replace(/\s+/g, '_')}`,
      onConfirm: () => {
        if (targetType === 'seller') {
          toggleBlockSeller(targetId, 'Manual block', targetName, targetAvatar, targetHandle);
        } else if (targetType === 'user') {
          toggleBlockUser(targetId, targetName, targetAvatar, targetHandle, 'Manual block');
        } else {
          toggleBlockCustomerBySeller(activeSellerId, targetId);
        }
        if (onConfirm) onConfirm();
        setBlockConfirmModal(null);
      },
    });
  };

  const closeBlockConfirmationModal = () => {
    setBlockConfirmModal(null);
  };

  // ==========================================
  // INSTAGRAM-STYLE PROFILE SHARING
  // ==========================================
  const [activeShareSeller, setActiveShareSeller] = useState<SellerProfile | null>(null);
  const [isSellerShareModalOpen, setIsSellerShareModalOpen] = useState<boolean>(false);

  const openSellerShareModal = (seller: SellerProfile) => {
    setActiveShareSeller(seller);
    setIsSellerShareModalOpen(true);
  };

  const closeSellerShareModal = () => {
    setIsSellerShareModalOpen(false);
    setActiveShareSeller(null);
  };

  // ==========================================
  // USER INTEREST, NON-INTEREST & NEARBY ENGINE
  // ==========================================
  const [userInterestProfile, setUserInterestProfile] = useState<UserInterestProfile>({
    interestedProductIds: ['prod-1', 'prod-3', 'prod-7', 'prod-12'],
    notInterestedRecords: {},
    categoryAffinities: {
      "Men's Ethnic & Kurtas": 92,
      'Handloom & Pure Silk Sarees': 88,
      'Linen Shirts & Casuals': 82,
      'Artisan Mojari Footwear': 76,
      'Festive Nehru Jackets': 72,
      'Organic Cotton Kurtis': 65,
    },
    brandAffinities: {
      'Royal Heritage Silks': 95,
      'Jaipur Block Prints': 90,
      'Kashi Handlooms': 84,
      'FabIndia Artisan': 80,
    },
    activeInterestTags: ['Silk', 'Linen', 'Handloom', 'Festive', 'Artisan', 'Same-Day'],
    userCity: 'Bengaluru',
    userPincode: '560034',
    maxDistanceRadiusKm: 15,
    shoppingVibe: 'all',
    lastUpdated: 'Just now',
  });
  const [isInterestManagerOpen, setIsInterestManagerOpen] = useState<boolean>(false);
  const [isLoadingHomepage, setIsLoadingHomepage] = useState<boolean>(false);

  const markProductInterested = (productId: string) => {
    const targetProd = products.find((p) => p.id === productId);
    const prodName = targetProd ? targetProd.name : 'Product';
    const prodCat = targetProd?.category || 'General';
    const prodBrand = targetProd?.brand || '';

    setUserInterestProfile((prev) => {
      const alreadyInterested = prev.interestedProductIds.includes(productId);
      const newInterested = alreadyInterested
        ? prev.interestedProductIds
        : [productId, ...prev.interestedProductIds];

      const currentAffinity = prev.categoryAffinities[prodCat] || 60;
      const updatedAffinity = Math.min(100, currentAffinity + 12);

      const currentBrandAffinity = prodBrand ? prev.brandAffinities[prodBrand] || 60 : 60;
      const updatedBrandAffinity = Math.min(100, currentBrandAffinity + 10);

      // Remove from not-interested if it was previously hidden
      const newNotInterested = { ...prev.notInterestedRecords };
      delete newNotInterested[productId];

      return {
        ...prev,
        interestedProductIds: newInterested,
        notInterestedRecords: newNotInterested,
        categoryAffinities: {
          ...prev.categoryAffinities,
          [prodCat]: updatedAffinity,
        },
        brandAffinities: prodBrand
          ? { ...prev.brandAffinities, [prodBrand]: updatedBrandAffinity }
          : prev.brandAffinities,
        lastUpdated: 'Just now',
      };
    });

    // Also mark as liked in the social bar
    setProductLikes((prev) => ({
      ...prev,
      [productId]: { count: (prev[productId]?.count || 48) + 1, isLiked: true },
    }));

    showToast(`🌟 Marked "${prodName}" as Interested! Recommendations personalized.`);
  };

  const markProductNotInterested = (
    productId: string,
    reason: NotInterestedReason = 'not_relevant',
    reasonText: string = 'Not relevant to my current style'
  ) => {
    const targetProd = products.find((p) => p.id === productId);
    const prodName = targetProd ? targetProd.name : 'Product';
    const prodCat = targetProd?.category || 'General';
    const prodBrand = targetProd?.brand || 'Brand';

    const newRecord: NotInterestedRecord = {
      productId,
      productName: prodName,
      brand: prodBrand,
      category: prodCat,
      reason,
      reasonText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setUserInterestProfile((prev) => {
      const currentAffinity = prev.categoryAffinities[prodCat] || 60;
      const updatedAffinity = Math.max(10, currentAffinity - 15);

      return {
        ...prev,
        interestedProductIds: prev.interestedProductIds.filter((id) => id !== productId),
        notInterestedRecords: {
          ...prev.notInterestedRecords,
          [productId]: newRecord,
        },
        categoryAffinities: {
          ...prev.categoryAffinities,
          [prodCat]: updatedAffinity,
        },
        lastUpdated: 'Just now',
      };
    });

    showToast(`🚫 "${prodName}" hidden from recommendations.`);
  };

  const undoNotInterested = (productId: string) => {
    const targetProd = products.find((p) => p.id === productId);
    const prodName = targetProd ? targetProd.name : 'Product';

    setUserInterestProfile((prev) => {
      const newNotInterested = { ...prev.notInterestedRecords };
      delete newNotInterested[productId];
      return {
        ...prev,
        notInterestedRecords: newNotInterested,
        lastUpdated: 'Just now',
      };
    });

    showToast(`✨ Restored "${prodName}" to your recommendation feed.`);
  };

  const clearAllNotInterested = () => {
    setUserInterestProfile((prev) => ({
      ...prev,
      notInterestedRecords: {},
      lastUpdated: 'Just now',
    }));
    showToast('✨ All hidden recommendations have been restored!');
  };

  const removeInterestProduct = (productId: string) => {
    setUserInterestProfile((prev) => ({
      ...prev,
      interestedProductIds: prev.interestedProductIds.filter((id) => id !== productId),
      lastUpdated: 'Just now',
    }));
  };

  const updateCategoryAffinity = (category: string, score: number) => {
    setUserInterestProfile((prev) => ({
      ...prev,
      categoryAffinities: {
        ...prev.categoryAffinities,
        [category]: Math.max(0, Math.min(100, score)),
      },
      lastUpdated: 'Just now',
    }));
  };

  const resetInterestProfile = () => {
    setUserInterestProfile({
      interestedProductIds: ['prod-1', 'prod-3', 'prod-7'],
      notInterestedRecords: {},
      categoryAffinities: {
        "Men's Ethnic & Kurtas": 85,
        'Handloom & Pure Silk Sarees': 80,
        'Linen Shirts & Casuals': 75,
        'Artisan Mojari Footwear': 70,
        'Festive Nehru Jackets': 68,
        'Organic Cotton Kurtis': 60,
      },
      brandAffinities: {
        'Royal Heritage Silks': 90,
        'Jaipur Block Prints': 85,
        'Kashi Handlooms': 80,
        'FabIndia Artisan': 75,
      },
      activeInterestTags: ['Silk', 'Linen', 'Handloom', 'Festive'],
      userCity: 'Bengaluru',
      userPincode: '560034',
      maxDistanceRadiusKm: 15,
      shoppingVibe: 'all',
      lastUpdated: 'Just now',
    });
  };

  const updateUserLocationPreference = (city: string, pin: string, radiusKm: number) => {
    setUserInterestProfile((prev) => ({
      ...prev,
      userCity: city,
      userPincode: pin,
      maxDistanceRadiusKm: radiusKm,
      lastUpdated: 'Just now',
    }));
  };

  const setShoppingVibePreference = (vibe: 'all' | 'festive' | 'daily' | 'luxury' | 'budget') => {
    setUserInterestProfile((prev) => ({
      ...prev,
      shoppingVibe: vibe,
      lastUpdated: 'Just now',
    }));
  };

  const isProductInterested = (productId: string): boolean => {
    return userInterestProfile.interestedProductIds.includes(productId) || Boolean(productLikes[productId]?.isLiked);
  };

  const isProductNotInterested = (productId: string): boolean => {
    return Boolean(userInterestProfile.notInterestedRecords[productId]);
  };

  const getPersonalizedRecommendedProducts = (): Product[] => {
    // Suppress products marked not-interested or belonging to blocked sellers
    const available = products.filter(
      (p) => !userInterestProfile.notInterestedRecords[p.id] && !isProductSellerBlocked(p)
    );

    return [...available].sort((a, b) => {
      // Calculate score for A
      let scoreA = userInterestProfile.categoryAffinities[a.category] || 50;
      if (userInterestProfile.interestedProductIds.includes(a.id)) scoreA += 30;
      if (isProductLiked(a.id)) scoreA += 20;
      if (a.isTrending || a.isFeatured) scoreA += 15;
      if (userInterestProfile.shoppingVibe === 'budget' && a.price <= 1999) scoreA += 25;
      if (userInterestProfile.shoppingVibe === 'festive' && (a.category.includes('Ethnic') || a.category.includes('Silk') || a.tags.includes('Festive'))) scoreA += 35;
      if (userInterestProfile.shoppingVibe === 'daily' && (a.category.includes('Linen') || a.tags.includes('Cotton'))) scoreA += 35;

      // Calculate score for B
      let scoreB = userInterestProfile.categoryAffinities[b.category] || 50;
      if (userInterestProfile.interestedProductIds.includes(b.id)) scoreB += 30;
      if (isProductLiked(b.id)) scoreB += 20;
      if (b.isTrending || b.isFeatured) scoreB += 15;
      if (userInterestProfile.shoppingVibe === 'budget' && b.price <= 1999) scoreB += 25;
      if (userInterestProfile.shoppingVibe === 'festive' && (b.category.includes('Ethnic') || b.category.includes('Silk') || b.tags.includes('Festive'))) scoreB += 35;
      if (userInterestProfile.shoppingVibe === 'daily' && (b.category.includes('Linen') || b.tags.includes('Cotton'))) scoreB += 35;

      return scoreB - scoreA;
    });
  };

  const getNearbyInterestedProducts = (): NearbyProductMatch[] => {
    const activeCity = userInterestProfile.userCity.toLowerCase();
    const available = products.filter(
      (p) => !userInterestProfile.notInterestedRecords[p.id] && !isProductSellerBlocked(p)
    );

    const matches: NearbyProductMatch[] = [];

    available.slice(0, 8).forEach((prod, index) => {
      // Match seller
      const seller = sellers.find(
        (s) =>
          s.storeName.toLowerCase() === prod.brand.toLowerCase() ||
          prod.tags.includes(s.storeName) ||
          prod.brand.toLowerCase().includes(s.storeName.toLowerCase())
      ) || sellers[index % sellers.length];

      // Realistic distance based on index & location
      const distance = parseFloat((1.2 + (index * 0.8) % 4.5).toFixed(1));
      const eta = 20 + Math.round(distance * 8);

      matches.push({
        product: prod,
        seller,
        distanceKm: distance,
        etaMinutes: eta,
        deliveryType: distance <= 2.5 ? 'Express 30-Min' : 'Same Day',
        stockCount: prod.totalStock,
      });
    });

    return matches;
  };

  const simulateHomepageRefresh = () => {
    setIsLoadingHomepage(true);
    setTimeout(() => {
      setIsLoadingHomepage(false);
      showToast('✨ Homepage data and recommendations updated!');
    }, 750);
  };

  // ==========================================
  // NEXT-GENERATION AI SOCIAL NETWORK STATE & HANDLERS
  // ==========================================
  const [livingUserProfile, setLivingUserProfile] = useState<LivingUserProfile>(INITIAL_CURRENT_USER_PROFILE);
  const [socialFeedMode, setSocialFeedMode] = useState<SocialFeedMode>('personalized');
  const [socialPosts, setSocialPosts] = useState<NextGenSocialPost[]>(INITIAL_COLLABORATIVE_POSTS);
  const [peopleRecommendations, setPeopleRecommendations] = useState<PersonRecommendationItem[]>(INITIAL_PEOPLE_RECOMMENDATIONS);
  const [temporaryMoments, setTemporaryMoments] = useState<NextGenMomentItem[]>(INITIAL_TEMPORARY_MOMENTS);
  const [temporaryCommunities, setTemporaryCommunities] = useState<TemporaryCommunityItem[]>(INITIAL_TEMPORARY_COMMUNITIES);
  const [socialMissions, setSocialMissions] = useState<SocialMissionItem[]>(INITIAL_SOCIAL_MISSIONS);
  const [opportunityMatches, setOpportunityMatches] = useState<AIOpportunityMatch[]>(INITIAL_OPPORTUNITY_MATCHES);
  const [aiTwinMemories, setAiTwinMemories] = useState<AISocialTwinMemoryRecord[]>(INITIAL_AI_TWIN_MEMORIES);
  const [conversationMemories, setConversationMemories] = useState<AISocialConversationMemory[]>(INITIAL_CONVERSATION_MEMORIES);
  const [specializedAgents, setSpecializedAgents] = useState<SpecializedAIAgent[]>(INITIAL_SPECIALIZED_AGENTS);
  const [userAttentionBudget, setUserAttentionBudget] = useState<UserAttentionBudget>(INITIAL_ATTENTION_BUDGET);

  // Modals
  const [isIntroduceMeModalOpen, setIsIntroduceMeModalOpen] = useState<boolean>(false);
  const [activeIntroduceMeTarget, setActiveIntroduceMeTarget] = useState<PersonRecommendationItem | null>(null);
  const [isAITwinDashboardOpen, setIsAITwinDashboardOpen] = useState<boolean>(false);
  const [isOpportunityMatchModalOpen, setIsOpportunityMatchModalOpen] = useState<boolean>(false);
  const [activeOpportunityMatch, setActiveOpportunityMatch] = useState<AIOpportunityMatch | null>(null);
  const [isCreateSocialEntityModalOpen, setIsCreateSocialEntityModalOpen] = useState<boolean>(false);
  const [createSocialEntityType, setCreateSocialEntityType] = useState<'post' | 'moment' | 'product' | 'mission' | 'community'>('post');

  const updateLivingProfile = (updates: Partial<LivingUserProfile>) => {
    setLivingUserProfile((prev) => ({
      ...prev,
      ...updates,
    }));
    showToast('✨ Living Profile updated successfully!');
  };

  const switchActivePersona = (persona: SocialAccountPersona) => {
    setLivingUserProfile((prev) => ({
      ...prev,
      activePersona: persona,
    }));
    const personaName = persona.charAt(0).toUpperCase() + persona.slice(1);
    showToast(`🎭 Switched context to ${personaName} Persona`);
  };

  const setUserIntent = (intent: UserIntentType) => {
    setLivingUserProfile((prev) => ({
      ...prev,
      currentIntent: intent,
    }));
    // Also intelligently adjust feed mode to match intent
    if (intent === 'buy' || intent === 'sell' || intent === 'find_products' || intent === 'find_businesses') {
      setSocialFeedMode('commerce');
    } else if (intent === 'learn') {
      setSocialFeedMode('learn');
    } else if (intent === 'collaborate' || intent === 'connect' || intent === 'hire') {
      setSocialFeedMode('collaborate');
    } else if (intent === 'meet' || intent === 'find_people') {
      setSocialFeedMode('people');
    } else if (intent === 'discover_nearby') {
      setSocialFeedMode('nearby');
    } else {
      setSocialFeedMode('personalized');
    }
    const cleanIntent = intent.replace(/_/g, ' ');
    showToast(`🎯 Current Intent set to: "${cleanIntent}"`);
  };

  const addSocialPost = (post: Partial<NextGenSocialPost>) => {
    const newPost: NextGenSocialPost = {
      id: `post_${Date.now()}`,
      author: livingUserProfile,
      createdAt: 'Just now',
      content: post.content || '',
      mediaUrl: post.mediaUrl,
      mediaType: post.mediaType || 'image',
      intentTag: post.intentTag || livingUserProfile.currentIntent,
      provenance: post.provenance || 'human_created',
      isCollaborative: Boolean(post.isCollaborative),
      collaborativeContributions: post.collaborativeContributions || [],
      contextReactions: {
        relate: 0,
        understand: 0,
        agree: 0,
        disagree: 0,
        needThis: 0,
        interested: 0,
        helpedMe: 0,
        discuss: 0,
        experiencingToo: 0,
      },
      commerceProduct: post.commerceProduct,
      isAnonymous: post.isAnonymous,
      anonymousAlias: post.anonymousAlias,
      identityRevealState: post.isAnonymous ? 'none' : undefined,
    };
    setSocialPosts((prev) => [newPost, ...prev]);
    showToast('🚀 New post published to the Opportunity Network!');
  };

  const addCollaborativeContribution = (postId: string, contribution: Partial<CollaborativeContribution>) => {
    const newContribution: CollaborativeContribution = {
      id: `contrib_${Date.now()}`,
      authorId: livingUserProfile.id,
      authorName: livingUserProfile.name,
      authorAvatar: livingUserProfile.avatar,
      type: contribution.type || 'idea',
      content: contribution.content || '',
      mediaUrl: contribution.mediaUrl,
      createdAt: 'Just now',
      upvotes: 1,
      hasUpvoted: true,
    };

    setSocialPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          return {
            ...p,
            collaborativeContributions: [...p.collaborativeContributions, newContribution],
          };
        }
        return p;
      })
    );
    showToast('✨ Added your contribution to the Living Object!');
  };

  const toggleContextReaction = (postId: string, reaction: ContextReactionType) => {
    setSocialPosts((prev) =>
      prev.map((p) => {
        if (p.id !== postId) return p;

        const currentReaction = p.userReaction;
        const newReactions = { ...p.contextReactions };

        if (currentReaction === reaction) {
          // Remove reaction
          newReactions[reaction] = Math.max(0, newReactions[reaction] - 1);
          return { ...p, contextReactions: newReactions, userReaction: undefined };
        } else {
          // Decrement previous if existed
          if (currentReaction) {
            newReactions[currentReaction] = Math.max(0, newReactions[currentReaction] - 1);
          }
          // Increment new
          newReactions[reaction] = (newReactions[reaction] || 0) + 1;
          return { ...p, contextReactions: newReactions, userReaction: reaction };
        }
      })
    );
  };

  const convertPostToProduct = (postId: string, productData: Partial<SocialCommerceAttachedProduct>) => {
    setSocialPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          const commerceProd: SocialCommerceAttachedProduct = {
            id: `prod_post_${Date.now()}`,
            title: productData.title || 'Handcrafted Artisan Piece',
            price: productData.price || 1499,
            currency: 'INR',
            image: productData.image || p.mediaUrl || 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=600&auto=format&fit=crop&q=80',
            category: productData.category || 'Artisan Goods',
            sellerId: livingUserProfile.id,
            sellerName: livingUserProfile.name,
            inStock: true,
            rating: 5.0,
            deliveryEstimate: 'Delivered in 2-3 days (Local Express)',
          };
          return {
            ...p,
            commerceProduct: commerceProd,
            provenance: 'verified_business',
          };
        }
        return p;
      })
    );
    showToast('🛍️ Post converted into a verified Social Commerce listing!');
  };

  const requestIdentityReveal = (postId: string) => {
    setSocialPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          return {
            ...p,
            identityRevealState: 'revealed',
          };
        }
        return p;
      })
    );
    showToast('🤝 Mutual Identity Reveal accepted! Real profile now visible.');
  };

  const addTemporaryMoment = (moment: Partial<NextGenMomentItem>) => {
    const newMoment: NextGenMomentItem = {
      id: `moment_${Date.now()}`,
      author: livingUserProfile,
      purpose: moment.purpose || 'I am here',
      headline: moment.headline || 'Active Moment',
      content: moment.content || '',
      mediaUrl: moment.mediaUrl,
      lifetime: moment.lifetime || '2h',
      expiresAt: 'In 2 hours',
      remainingMinutes: 120,
      locationName: moment.locationName || `${livingUserProfile.location.neighborhood}, ${livingUserProfile.location.city}`,
      distanceKm: 0,
      participantsCount: 1,
      intentMatches: moment.intentMatches || ['Local activity'],
      isNearby: true,
      tags: moment.tags || ['Moment', 'Local'],
    };
    setTemporaryMoments((prev) => [newMoment, ...prev]);
    showToast('⏳ Temporary Moment published to the Live World radar!');
  };

  const joinTemporaryCommunity = (communityId: string) => {
    setTemporaryCommunities((prev) =>
      prev.map((c) => {
        if (c.id === communityId) {
          const isNowJoined = !c.isJoined;
          return {
            ...c,
            isJoined: isNowJoined,
            membersCount: isNowJoined ? c.membersCount + 1 : c.membersCount - 1,
          };
        }
        return c;
      })
    );
    showToast('✨ Updated community membership!');
  };

  const completeSocialMission = (missionId: string) => {
    setSocialMissions((prev) =>
      prev.map((m) => {
        if (m.id === missionId) {
          return { ...m, progress: 100, status: 'completed' };
        }
        return m;
      })
    );
    showToast('🏆 Mission Completed! Proof-of-Experience score boosted!');
  };

  const updateTwinMemory = (memoryId: string, permitted: boolean) => {
    setAiTwinMemories((prev) =>
      prev.map((m) => (m.id === memoryId ? { ...m, permitted } : m))
    );
    showToast(permitted ? '✅ Permission granted for AI memory' : '🔒 Permission revoked for AI memory');
  };

  const deleteTwinMemory = (memoryId: string) => {
    setAiTwinMemories((prev) => prev.filter((m) => m.id !== memoryId));
    showToast('🗑️ Memory item deleted from AI Twin');
  };

  const resetAllTwinMemory = () => {
    setAiTwinMemories([]);
    showToast('🔄 AI Twin Memory completely reset to blank state.');
  };

  const addTwinMemory = (record: Partial<AISocialTwinMemoryRecord>) => {
    const newRecord: AISocialTwinMemoryRecord = {
      id: `mem_${Date.now()}`,
      category: record.category || 'interest',
      title: record.title || 'New Insight',
      details: record.details || '',
      source: 'User explicit input',
      permitted: true,
      learnedAt: 'Just now',
    };
    setAiTwinMemories((prev) => [newRecord, ...prev]);
    showToast('✨ Added new explicit memory to AI Social Twin!');
  };

  const searchConversationMemories = (query: string): AISocialConversationMemory[] => {
    if (!query.trim()) return conversationMemories;
    const q = query.toLowerCase();
    return conversationMemories.filter(
      (m) =>
        m.query.toLowerCase().includes(q) ||
        m.answer.toLowerCase().includes(q) ||
        m.sourceContext.toLowerCase().includes(q)
    );
  };

  const toggleSpecializedAgent = (agentId: string) => {
    setSpecializedAgents((prev) =>
      prev.map((a) => (a.id === agentId ? { ...a, isActive: !a.isActive } : a))
    );
    showToast('🤖 Specialized Agent settings updated!');
  };

  const initiateIntroduceMe = (target: PersonRecommendationItem, contextNote?: string) => {
    setActiveIntroduceMeTarget(target);
    setIsIntroduceMeModalOpen(true);
  };

  const openCreateSocialModal = (type?: 'post' | 'moment' | 'product' | 'mission' | 'community') => {
    if (type) setCreateSocialEntityType(type);
    setIsCreateSocialEntityModalOpen(true);
  };

  // ==========================================
  // LIFEOS: THE SOCIAL OPERATING SYSTEM STATE & HANDLERS
  // ==========================================
  const [lifeIntents, setLifeIntents] = useState<LifeIntent[]>(INITIAL_LIFE_INTENTS);
  const [socialWorlds, setSocialWorlds] = useState<SocialWorld[]>(INITIAL_SOCIAL_WORLDS);
  const [synchronicities, setSynchronicities] = useState<SocialSynchronicity[]>(INITIAL_SYNCHRONICITIES);
  const [universalDiscoveryItems, setUniversalDiscoveryItems] = useState<UniversalDiscoveryItem[]>(INITIAL_UNIVERSAL_DISCOVERY);
  const [lifeMemories, setLifeMemories] = useState<LifeMemoryItem[]>(INITIAL_LIFE_MEMORIES);
  const [mapNodes, setMapNodes] = useState<LifeMapZoneNode[]>(INITIAL_MAP_NODES);
  const [relationshipNodes, setRelationshipNodes] = useState<RelationshipGraphNode[]>(INITIAL_RELATIONSHIP_NODES);
  const [aiTwinConfig, setAiTwinConfig] = useState<AISocialTwinConfig>(INITIAL_AI_TWIN_CONFIG);
  const [experiencePosts, setExperiencePosts] = useState<ExperiencePostItem[]>(INITIAL_EXPERIENCE_POSTS);

  const [activeLifeOSTab, setActiveLifeOSTab] = useState<LifeOSTab>('my_world');
  const [isLifeIntentModalOpen, setIsLifeIntentModalOpen] = useState<boolean>(false);
  const [isLifeVoiceModalOpen, setIsLifeVoiceModalOpen] = useState<boolean>(false);
  const [isCreateWorldModalOpen, setIsCreateWorldModalOpen] = useState<boolean>(false);
  const [activeWorldDetail, setActiveWorldDetail] = useState<SocialWorld | null>(null);
  const [isSafetyTrustModalOpen, setIsSafetyTrustModalOpen] = useState<boolean>(false);
  const [isEmergentCommunityModalOpen, setIsEmergentCommunityModalOpen] = useState<boolean>(false);

  // Next-Gen LifeOS Expanded States
  const [lifeRadarOpportunities, setLifeRadarOpportunities] = useState<LifeRadarOpportunity[]>(INITIAL_LIFE_RADAR_OPPORTUNITIES);
  const [futureYouScenarios, setFutureYouScenarios] = useState<FutureYouScenario[]>(INITIAL_FUTURE_YOU_SCENARIOS);
  const [opportunityExchangeItems, setOpportunityExchangeItems] = useState<OpportunityExchangeItem[]>(INITIAL_OPPORTUNITY_EXCHANGE_ITEMS);
  const [skillGraphNodes, setSkillGraphNodes] = useState<SkillGraphNode[]>(INITIAL_SKILL_GRAPH_NODES);
  const [goalCommunities, setGoalCommunities] = useState<GoalCommunity[]>(INITIAL_GOAL_COMMUNITIES);
  const [personalGrowthNodes, setPersonalGrowthNodes] = useState<PersonalGrowthNode[]>(INITIAL_PERSONAL_GROWTH_NODES);
  const [ideaCollisions, setIdeaCollisions] = useState<IdeaCollision[]>(INITIAL_IDEA_COLLISIONS);
  const [lifeOSMoments, setLifeOSMoments] = useState<LifeOSMoment[]>(INITIAL_LIFEOS_MOMENTS);
  const [contributionReputation] = useState<ContributionReputation>(INITIAL_CONTRIBUTION_REPUTATION);
  const [aiPrivacyState, setAiPrivacyState] = useState<AIPrivacyControlState>(INITIAL_AI_PRIVACY_STATE);

  // 1. BioEnergy & Cognitive Flow Matrix State
  const [bioEnergyProfile, setBioEnergyProfile] = useState<BioEnergyProfile>(INITIAL_BIO_ENERGY_PROFILE);

  // 2. Quantum Life Decision Simulator State
  const [quantumDecisions, setQuantumDecisions] = useState<QuantumLifeDecision[]>(INITIAL_QUANTUM_DECISIONS);
  const [activeQuantumDecisionId, setActiveQuantumDecisionId] = useState<string>('decision-spatial-venture');

  // 3. Autonomous Life Agent Swarm State
  const [autonomousAgents, setAutonomousAgents] = useState<AutonomousLifeAgent[]>(INITIAL_AUTONOMOUS_AGENTS);

  // Modal states
  const [isFutureYouModalOpen, setIsFutureYouModalOpen] = useState<boolean>(false);
  const [isOpportunityExchangeModalOpen, setIsOpportunityExchangeModalOpen] = useState<boolean>(false);
  const [isIdeaCollisionModalOpen, setIsIdeaCollisionModalOpen] = useState<boolean>(false);
  const [isAIPrivacyCenterOpen, setIsAIPrivacyCenterOpen] = useState<boolean>(false);
  const [isDataPortabilityModalOpen, setIsDataPortabilityModalOpen] = useState<boolean>(false);
  const [isContextAwareChatOpen, setIsContextAwareChatOpen] = useState<boolean>(false);
  const [contextAwareChatPeer, setContextAwareChatPeer] = useState<{ name: string; avatar: string; sharedContext: string; matchRationale: string } | null>(null);
  const [isLifeOSAgentModalOpen, setIsLifeOSAgentModalOpen] = useState<boolean>(false);
  const [isSerendipityModalOpen, setIsSerendipityModalOpen] = useState<boolean>(false);
  const [isAnonymousWorldModalOpen, setIsAnonymousWorldModalOpen] = useState<boolean>(false);

  const updateRadarOpportunityStatus = (id: string, status: 'available' | 'requested' | 'connected', isIgnored?: boolean) => {
    setLifeRadarOpportunities((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            status,
            isIgnored: isIgnored !== undefined ? isIgnored : item.isIgnored,
          };
        }
        return item;
      })
    );
    if (status === 'requested') {
      showToast('🤖 AI Twin Handshake protocol initiated! Co-introduction scheduled.');
    } else if (status === 'connected') {
      showToast('🤝 Connection confirmed! Added to your Personal Growth & Skill Graph.');
    } else if (isIgnored) {
      showToast('🔕 Opportunity dismissed from active Radar.');
    }
  };

  const runFutureYouSimulation = (hypothesis: string, horizon: '6_months' | '1_year' | '3_years') => {
    const horizonLabels: Record<string, string> = {
      '6_months': '6-Month Adaptive Horizon',
      '1_year': '1-Year High Momentum Trajectory',
      '3_years': '3-Year Exponential Synthesis',
    };

    const newScenario: FutureYouScenario = {
      id: `future_${Date.now()}`,
      hypothesis,
      horizon,
      scenarioTitle: `Simulated Trajectory: ${hypothesis.slice(0, 45)}...`,
      likelihoodTrajectory: horizon === '3_years' ? 'Exponential Pivot' : 'High Momentum',
      summary: `Predictive modeling across your active intents, skill competencies, and 12,000+ builder trajectories indicates this pathway unlocks significant compounding leverage in ${horizonLabels[horizon]}.`,
      potentialSkills: [
        'Advanced Multimodal Systems',
        'Spatial Edge Optimization',
        'Cross-Cultural Venture Architecture',
        'Strategic Syndicate Governance',
      ],
      possibleCommunities: [
        'Global Builder Guild',
        'Deeptech Innovators Alliance',
        'Autonomous Synthesis Circle',
      ],
      potentialOpportunities: [
        'Pre-seed investment backing from leading strategic syndicates',
        'Keynote showcase at international spatial computing congress',
        'High-impact enterprise collaborative pilot contract',
      ],
      suggestedPeople: [
        {
          name: 'Elena Rostova',
          role: 'Systems Co-Founder',
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
          reason: 'High technical synergy on edge systems execution.',
        },
        {
          name: 'Marcus Vance',
          role: 'Strategic Capital Lead',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
          reason: 'Provides capital backing and global accelerator distribution.',
        },
      ],
      possibleProjects: [
        'Autonomous Multimodal Copilot Runtime v1.0',
        'Global Open Benchmark for Spatial Micro-Interactions',
      ],
      recommendedNextSteps: [
        {
          step: 'Express 1 high-intent objective in Life Radar to signal active alignment.',
          timeline: 'Week 1',
          impact: 'Accelerates AI twin discovery score by +28%.',
        },
        {
          step: 'Commit to weekly sprint milestones in Goal Communities.',
          timeline: 'Month 1',
          impact: 'Builds verified peer proof of execution.',
        },
      ],
      disclaimer: 'Simulated potential trajectory based on predictive pattern modeling. Subject to your personal agency and choices.',
    };

    setFutureYouScenarios((prev) => [newScenario, ...prev]);
    showToast('🔮 Future You scenario synthesized! Explore trajectories and next steps.');
  };

  const addOpportunityExchangeItem = (item: Partial<OpportunityExchangeItem>) => {
    const newItem: OpportunityExchangeItem = {
      id: `opp_${Date.now()}`,
      type: item.type || 'need',
      category: item.category || 'developer',
      title: item.title || 'Untitled Opportunity',
      description: item.description || '',
      author: {
        id: 'current-user',
        name: 'Alex Rivera',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        headline: 'Founder @ SpatialLens • Full-Stack AI Engineer',
        contributionScore: 890,
        verifiedBadges: ['Verified Builder', 'Top Contributor', 'SF Resident'],
      },
      skillsTags: item.skillsTags || ['AI', 'Collaboration'],
      urgency: item.urgency || 'this_week',
      exchangeType: item.exchangeType || 'mutual_barter',
      locationZone: item.locationZone || 'San Francisco & Remote',
      compatibilityWithUserPercent: 100,
      status: 'active',
      createdAt: 'Just now',
    };
    setOpportunityExchangeItems((prev) => [newItem, ...prev]);
    showToast(`⚡ Opportunity ${newItem.type === 'need' ? 'Need' : 'Offer'} published to the Global Exchange!`);
  };

  const toggleSkillVisibility = (id: string) => {
    setSkillGraphNodes((prev) =>
      prev.map((s) => (s.id === id ? { ...s, isPublic: !s.isPublic } : s))
    );
    showToast('🔒 Skill node privacy updated.');
  };

  const toggleJoinGoalCommunity = (id: string) => {
    setGoalCommunities((prev) =>
      prev.map((c) => {
        if (c.id === id) {
          const isJoined = !c.isJoined;
          return {
            ...c,
            isJoined,
            membersCount: isJoined ? c.membersCount + 1 : Math.max(1, c.membersCount - 1),
          };
        }
        return c;
      })
    );
    showToast('🎯 Goal Community sprint status synchronized!');
  };

  const addGoalCommunitySprintTask = (communityId: string, taskText: string) => {
    setGoalCommunities((prev) =>
      prev.map((c) => {
        if (c.id === communityId) {
          return {
            ...c,
            activeSprintTasks: [
              {
                id: `task_${Date.now()}`,
                user: 'Alex Rivera',
                task: taskText,
                status: 'in_progress',
              },
              ...c.activeSprintTasks,
            ],
          };
        }
        return c;
      })
    );
    showToast('✅ Sprint task added to Goal Community board!');
  };

  const addPersonalGrowthNode = (node: Partial<PersonalGrowthNode>) => {
    const newNode: PersonalGrowthNode = {
      id: `grow_${Date.now()}`,
      type: node.type || 'achievement',
      title: node.title || 'Personal Milestone',
      category: node.category || 'Life Growth',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      outcome: node.outcome || '',
      impactScore: node.impactScore || 90,
      verifiedProof: node.verifiedProof || 'Self-verified in LIFEOS',
      nextHorizonSuggestion: node.nextHorizonSuggestion,
    };
    setPersonalGrowthNodes((prev) => [newNode, ...prev]);
    showToast('🌱 Milestone logged in your Personal Growth Graph!');
  };

  const optInIdeaCollision = (collisionId: string, userId: string) => {
    setIdeaCollisions((prev) =>
      prev.map((col) => {
        if (col.id === collisionId) {
          const updatedParticipants = col.participants.map((p) =>
            p.id === userId ? { ...p, optedIn: true } : p
          );
          const allOptedIn = updatedParticipants.every((p) => p.optedIn);
          return {
            ...col,
            participants: updatedParticipants,
            status: allOptedIn ? 'incubating' : 'handshake_pending',
          };
        }
        return col;
      })
    );
    showToast('💡 Opt-in confirmed! Idea Collision incubator initialized.');
  };

  const archiveMomentToMemory = (momentId: string) => {
    const moment = lifeOSMoments.find((m) => m.id === momentId);
    if (moment) {
      const locName = moment.venueName || moment.locationName || 'Venue';
      const peers = moment.attendeesCount || moment.activePeersCount || 0;
      const sitType = moment.venueType || moment.situationType || 'event';
      addLifeMemory({
        title: `Moment: ${locName}`,
        description: `Participated in live physical gathering with ${peers} peers.`,
        category: 'moment',
        tags: [sitType, moment.city, 'RealWorldMoment'],
        aiSummary: `Live presence at ${locName} contributed to synchronicity scoring.`,
      });
      setLifeOSMoments((prev) => prev.map((m) => (m.id === momentId ? { ...m, isArchived: true } : m)));
      showToast('🏛️ Moment archived to your permanent AI Memory!');
    }
  };

  const updateAIPrivacyState = (patch: Partial<AIPrivacyControlState>) => {
    setAiPrivacyState((prev) => ({
      ...prev,
      ...patch,
    }));
    showToast('🛡️ AI Privacy & Sovereign Control settings updated.');
  };

  // 1. BioEnergy & Flow Rhythm Handlers
  const toggleFlowShield = () => {
    setBioEnergyProfile((prev) => {
      const nextActive = !prev.flowShieldActive;
      return {
        ...prev,
        flowShieldActive: nextActive,
        focusResonanceState: nextActive ? 'Hyper-Focus Flow' : 'Serendipity Receptive',
      };
    });
    showToast(
      bioEnergyProfile.flowShieldActive
        ? '🔓 Flow Shield Disengaged: Receptive to real-time spatial encounters & radar'
        : '🛡️ Flow Shield Engaged: Zero low-signal interruptions. Batched to AI Agent.'
    );
  };

  const toggleSoundscapePlay = (soundscapeName?: string) => {
    setBioEnergyProfile((prev) => ({
      ...prev,
      isSoundscapePlaying: !prev.isSoundscapePlaying,
    }));
    showToast(
      bioEnergyProfile.isSoundscapePlaying
        ? '🔇 Neuro-soundscape paused'
        : `🎧 Binaural Resonance active: ${soundscapeName || 'Alpha 40Hz Flow'}`
    );
  };

  const selectSoundscape = (soundscapeId: string) => {
    setBioEnergyProfile((prev) => ({
      ...prev,
      activeSoundscapeId: soundscapeId,
      isSoundscapePlaying: true,
    }));
    showToast(`🎵 Soundscape synchronized to active cognitive state.`);
  };

  // 2. Quantum Life Decision Handlers
  const selectQuantumBranch = (decisionId: string, branchId: string) => {
    setQuantumDecisions((prev) =>
      prev.map((d) => (d.id === decisionId ? { ...d, activeSelectedBranchId: branchId } : d))
    );
    showToast('🌌 Quantum Life Trajectory selected. Multiverse model recalculating.');
  };

  const addQuantumDecision = (decision: Partial<QuantumLifeDecision>) => {
    const newDecision: QuantumLifeDecision = {
      id: `decision_${Date.now()}`,
      title: decision.title || 'Untitled Life Crossroads',
      coreQuestion: decision.coreQuestion || 'What is the optimal path forward?',
      category: decision.category || 'career_venture',
      urgency: decision.urgency || 'high_inflection_point',
      createdAt: new Date().toISOString(),
      userRiskTolerance: decision.userRiskTolerance || 7,
      capitalRunwayMonths: decision.capitalRunwayMonths || 12,
      geographicFlexibility: decision.geographicFlexibility || 'hybrid_hub',
      aiSynthesisVerdict: decision.aiSynthesisVerdict || 'AI analysis suggests balanced compounding through calculated risk exposure.',
      branches: decision.branches || [
        {
          id: `branch_${Date.now()}_1`,
          branchTitle: 'Path A: Autonomous Leap',
          horizon: '2_years',
          pathDescription: 'Pursue independent high-agency building and sovereign equity creation.',
          probabilityOfFulfillment: 82,
          regretMinimizationScore: 91,
          serendipityMultiplier: 2.8,
          dimensions: {
            skillMastery: 90,
            financialAutonomy: 85,
            socialCapital: 92,
            mentalWellbeing: 80,
            creativeFreedom: 95,
            globalImpact: 88,
          },
          keyMilestones: ['Month 3: Launch MVP', 'Month 12: Reach self-sustainability', 'Month 24: Industry benchmark'],
          devilsAdvocateCritique: 'Requires strict self-governance and operational discipline.',
          optimistTrajectory: 'Maximized autonomy and compounding social graph reputation.',
          recommendedPreRequisites: ['Build core ally syndicate in Goal Communities', 'Establish 12-month runway'],
        },
      ],
      activeSelectedBranchId: decision.branches?.[0]?.id,
    };

    setQuantumDecisions((prev) => [newDecision, ...prev]);
    setActiveQuantumDecisionId(newDecision.id);
    showToast('✨ New Quantum Life Decision tree initialized!');
  };

  // 3. Autonomous Life Agent Swarm Handlers
  const approveAgentTask = (agentId: string, taskId: string) => {
    setAutonomousAgents((prev) =>
      prev.map((agent) => {
        if (agent.id === agentId) {
          const updatedTasks = agent.recentTasks.map((t) =>
            t.id === taskId ? ({ ...t, status: 'executed' } as AgentTaskExecution) : t
          );
          return {
            ...agent,
            recentTasks: updatedTasks,
            pendingApprovalsCount: Math.max(0, agent.pendingApprovalsCount - 1),
            actionsCompletedToday: agent.actionsCompletedToday + 1,
          };
        }
        return agent;
      })
    );
    showToast('⚡ Agent action approved & executed with cryptographic verification!');
  };

  const rejectAgentTask = (agentId: string, taskId: string) => {
    setAutonomousAgents((prev) =>
      prev.map((agent) => {
        if (agent.id === agentId) {
          const updatedTasks = agent.recentTasks.map((t) =>
            t.id === taskId ? ({ ...t, status: 'rejected' } as AgentTaskExecution) : t
          );
          return {
            ...agent,
            recentTasks: updatedTasks,
            pendingApprovalsCount: Math.max(0, agent.pendingApprovalsCount - 1),
          };
        }
        return agent;
      })
    );
    showToast('🚫 Agent proposal dismissed.');
  };

  const setAgentAutonomyLevel = (agentId: string, level: 'conservative' | 'collaborative' | 'high_agency') => {
    setAutonomousAgents((prev) =>
      prev.map((agent) => (agent.id === agentId ? { ...agent, autonomyLevel: level } : agent))
    );
    showToast(`🤖 Agent autonomy dial set to: ${level.toUpperCase().replace('_', ' ')}`);
  };

  const triggerManualAgentSweep = (agentId: string) => {
    setAutonomousAgents((prev) =>
      prev.map((agent) => {
        if (agent.id === agentId) {
          return {
            ...agent,
            actionsCompletedToday: agent.actionsCompletedToday + 1,
            recentTasks: [
              {
                id: `task_${Date.now()}`,
                timestamp: 'Just now',
                agentId: agent.id,
                agentName: agent.codeName,
                actionTitle: `Active Deep Scan Executed`,
                description: `Agent completed live spatial scan across SOMA and evaluated 8 emergent intent vectors.`,
                status: 'executed',
                urgency: 'routine',
                impactCategory: 'serendipity_connection',
                contextSignalsUsed: ['Live Geo-Radius', 'Open Intents Matrix', 'Life Radar Queue'],
              },
              ...agent.recentTasks,
            ],
          };
        }
        return agent;
      })
    );
    showToast('🔍 Full autonomous sweep completed across active network nodes.');
  };

  const addLifeIntent = (intent: Partial<LifeIntent>) => {
    const newIntent: LifeIntent = {
      id: `intent_${Date.now()}`,
      category: intent.category || 'building',
      title: intent.title || 'Untitled Intent',
      description: intent.description || '',
      keywords: intent.keywords || ['Intent', 'LIFEOS'],
      createdAt: new Date().toISOString(),
      privacy: intent.privacy || 'public',
      status: 'active',
      urgency: intent.urgency || 'this_week',
      locationContext: intent.locationContext,
      matchedConnectionsCount: Math.floor(Math.random() * 4) + 2,
      aiSuggestedMatchSummary: `AI discovered ${Math.floor(Math.random() * 4) + 2} potential co-creators with matching intent.`,
    };
    setLifeIntents((prev) => [newIntent, ...prev]);
    showToast('✨ New Life Intent expressed! AI Synchronicity engine is scanning connections.');
  };

  const toggleIntentStatus = (id: string) => {
    setLifeIntents((prev) =>
      prev.map((i) => (i.id === id ? { ...i, status: i.status === 'active' ? 'fulfilled' : 'active' } : i))
    );
    showToast('✨ Intent status updated!');
  };

  const deleteLifeIntent = (id: string) => {
    setLifeIntents((prev) => prev.filter((i) => i.id !== id));
    showToast('🗑️ Intent archived and removed from active discovery.');
  };

  const joinSocialWorld = (worldId: string) => {
    setSocialWorlds((prev) =>
      prev.map((w) => {
        if (w.id === worldId) {
          const isNowJoined = !w.isJoined;
          return {
            ...w,
            isJoined: isNowJoined,
            participantsCount: isNowJoined ? w.participantsCount + 1 : Math.max(1, w.participantsCount - 1),
          };
        }
        return w;
      })
    );
    showToast('🌐 Social World membership synchronized!');
  };

  const leaveSocialWorld = (worldId: string) => {
    joinSocialWorld(worldId);
  };

  const createSocialWorld = (world: Partial<SocialWorld>) => {
    const newWorld: SocialWorld = {
      id: `world_${Date.now()}`,
      title: world.title || 'New Social World',
      type: world.type || 'project',
      subtitle: world.subtitle || 'Situational collaborative realm',
      description: world.description || '',
      bannerImage: world.bannerImage || 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1200&auto=format&fit=crop&q=80',
      locationZone: world.locationZone || 'Global Remote',
      privacy: world.privacy || 'public',
      status: 'active',
      remainingDuration: world.remainingDuration || 'Active indefinitely',
      participantsCount: 1,
      activeIntents: world.activeIntents || ['Collaboration', 'Knowledge'],
      tags: world.tags || ['SocialWorld', 'LIFEOS'],
      isJoined: true,
      memberList: [
        {
          id: 'user-you',
          name: 'Alex Rivera (You)',
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
          role: 'Creator & Host',
          headline: 'Initiated this Social World',
        },
      ],
      activities: [
        {
          id: `act_${Date.now()}`,
          user: 'Alex Rivera (You)',
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
          text: 'Created this Social World around our shared intent. Welcome everyone!',
          time: 'Just now',
          intentType: 'Milestone',
        },
      ],
      resources: world.resources || [],
    };
    setSocialWorlds((prev) => [newWorld, ...prev]);
    showToast('🌍 Temporary Social World is live! Invitations dispatched.');
  };

  const respondToSynchronicity = (id: string, status: 'approved' | 'declined' | 'connected') => {
    setSynchronicities((prev) =>
      prev.map((s) => (s.id === id ? { ...s, status } : s))
    );
    if (status === 'approved') {
      showToast('🤝 Synchronicity approved! Triple-handshake intro dispatched to participants.');
    } else if (status === 'connected') {
      showToast('🎉 Direct Synchronous room unlocked with all participants!');
    } else {
      showToast('🔒 Connection declined & feedback recorded by AI Social Twin.');
    }
  };

  const addLifeMemory = (mem: Partial<LifeMemoryItem>) => {
    const newMem: LifeMemoryItem = {
      id: `mem_${Date.now()}`,
      title: mem.title || 'New Life Memory',
      category: mem.category || 'moment',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      description: mem.description || '',
      photos: mem.photos || ['https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&auto=format&fit=crop&q=80'],
      peopleInvolved: mem.peopleInvolved || [{ name: 'Alex Rivera (You)', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150' }],
      location: mem.location || 'San Francisco, CA',
      isPrivate: mem.isPrivate ?? false,
      aiSummary: mem.aiSummary || 'Meaningful moment captured and organized into your Life Timeline.',
      tags: mem.tags || ['Memory', 'LifeOS'],
    };
    setLifeMemories((prev) => [newMem, ...prev]);
    showToast('📖 Life Memory saved to your private personal timeline!');
  };

  const toggleMemoryPrivacy = (id: string) => {
    setLifeMemories((prev) =>
      prev.map((m) => (m.id === id ? { ...m, isPrivate: !m.isPrivate } : m))
    );
    showToast('🔒 Memory privacy visibility toggled!');
  };

  const updateAITwinConfig = (config: Partial<AISocialTwinConfig>) => {
    setAiTwinConfig((prev) => ({ ...prev, ...config }));
    showToast('🤖 AI Social Twin permissions & settings updated!');
  };

  const addExperiencePost = (post: Partial<ExperiencePostItem>) => {
    const newPost: ExperiencePostItem = {
      id: `post_${Date.now()}`,
      author: {
        id: 'user-you',
        name: 'Alex Rivera (You)',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        handle: '@alexrivera',
        verifiedProof: ['Product Architect', 'YC Alum'],
      },
      contentType: post.contentType || 'moment',
      intent: post.intent || {
        category: 'doing',
        statement: 'Sharing a real-life experience moment',
      },
      title: post.title,
      content: post.content || '',
      mediaUrl: post.mediaUrl,
      tags: post.tags || ['LIFEOS', 'Experience'],
      timestamp: 'Just now',
      isCollaborativeBranchable: post.isCollaborativeBranchable ?? true,
      branchesCount: 0,
      reactions: {
        relate: 1,
        understand: 0,
        collaborate: 0,
        insightful: 1,
      },
      aiMatchedPeersCount: Math.floor(Math.random() * 5) + 2,
      locationZone: post.locationZone || 'San Francisco, CA',
    };
    setExperiencePosts((prev) => [newPost, ...prev]);
    showToast('✨ Intent-driven experience published to LIFEOS!');
  };

  const reactToExperiencePost = (id: string, reaction: 'relate' | 'understand' | 'collaborate' | 'insightful') => {
    setExperiencePosts((prev) =>
      prev.map((p) => {
        if (p.id !== id) return p;
        const current = p.userReaction;
        const newReactions = { ...p.reactions };
        if (current === reaction) {
          newReactions[reaction] = Math.max(0, newReactions[reaction] - 1);
          return { ...p, reactions: newReactions, userReaction: undefined };
        } else {
          if (current && current in newReactions) {
            newReactions[current as keyof typeof newReactions] = Math.max(0, newReactions[current as keyof typeof newReactions] - 1);
          }
          newReactions[reaction] = (newReactions[reaction] || 0) + 1;
          return { ...p, reactions: newReactions, userReaction: reaction };
        }
      })
    );
  };



  return (
    <AppContext.Provider
      value={{
        deviceMode,
        setDeviceMode,
        themeMode,
        setThemeMode,
        currentCustomer,
        currentRole,
        setCurrentRole,
        selectedCountry,
        setSelectedCountry,
        selectedCurrency,
        setSelectedCurrency,
        currentRegion,
        allRegions: WORLDWIDE_REGIONS,
        formatPrice,
        convertPrice,
        products,
        categories,
        banners,
        homepageSections,
        cart,
        wishlist,
        orders,
        coupons,
        returns,
        refunds,
        customers,
        abandonedCarts,
        auditLogs,
        notifications,
        cmsPages,
        settings,
        gatewayKeys,
        dataPrivacy,
        activeAppliedCoupon,
        isCartOpen,
        setIsCartOpen,
        isWhatsNewModalOpen,
        setIsWhatsNewModalOpen,
        isAntiflyAIOpen,
        setIsAntiflyAIOpen,
        isVoiceSearchOpen,
        setIsVoiceSearchOpen,
        isImageSearchOpen,
        setIsImageSearchOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        isNotificationDrawerOpen,
        setIsNotificationDrawerOpen,
        activePdpId,
        setActivePdpId,
        activeTrackingOrder,
        setActiveTrackingOrder,
        activeCMSPage,
        setActiveCMSPage,
        comparisonList,
        addToComparison,
        removeFromComparison,
        clearComparison,
        isComparisonOpen,
        setIsComparisonOpen,
        activeInvoiceData,
        setActiveInvoiceData,
        viewOrderInvoice,
        isLiveMapOpen,
        setIsLiveMapOpen,
        activeMapTracking,
        openLiveMapForOrder,
        selectedCategorySlug,
        setSelectedCategorySlug,
        searchQuery,
        setSearchQuery,
        appliedFilters,
        setAppliedFilters,
        isOrderProcessing,
        bulkUpdateOrders,
        bulkGenerateInvoices,
        superCoinsBalance,
        superCoinRewards,
        superCoinTransactions,
        isSuperCoinsModalOpen,
        setIsSuperCoinsModalOpen,
        redeemSuperCoinReward,
        useSuperCoinsAtCheckout,
        setUseSuperCoinsAtCheckout,
        isPlusMember,
        resellerConfig,
        setResellerConfig,
        isResellerModalOpen,
        setIsResellerModalOpen,
        groupBuyDeals,
        joinGroupBuy,
        isGroupBuyModalOpen,
        setIsGroupBuyModalOpen,
        meeshoReturnChoice,
        setMeeshoReturnChoice,
        styleCastLooks,
        activeStyleLook,
        setActiveStyleLook,
        isStyleCastModalOpen,
        setIsStyleCastModalOpen,
        lookBundles,
        addBundleToCart,
        sizeProfile,
        setSizeProfile,
        calculateRecommendedSize,
        isSizeAssistantOpen,
        setIsSizeAssistantOpen,
        priceDropWatchlist,
        togglePriceDropAlert,
        restaurants,
        isFoodDeliveryModalOpen,
        setIsFoodDeliveryModalOpen,
        selectedRestaurant,
        setSelectedRestaurant,
        foodCart,
        addToFoodCart,
        updateFoodCartQuantity,
        removeFromFoodCart,
        clearFoodCart,
        foodOrders,
        placeFoodOrder,
        antiflyOnePlans,
        antiflyOneSubscription,
        isAntiflyOneModalOpen,
        setIsAntiflyOneModalOpen,
        subscribeToAntiflyOne,
        cancelAntiflyOneSubscription,
        bankOffers,
        isBankOffersModalOpen,
        setIsBankOffersModalOpen,
        appliedBankOffer,
        applyBankOffer,
        removeBankOffer,
        ottPlatforms,
        ottShows,
        isOTTModalOpen,
        setIsOTTModalOpen,
        activeStreamingShow,
        setActiveStreamingShow,
        addProductReview,
        voteReviewHelpful,
        isProductFinderOpen,
        setIsProductFinderOpen,
        isGA4ModalOpen,
        setIsGA4ModalOpen,
        ga4Config,
        setGA4Config,
        ga4EventLog,
        trackEvent,
        isSEOModalOpen,
        setIsSEOModalOpen,
        language,
        setLanguage,
        t,
        currentUserSession,
        isLoginModalOpen,
        setIsLoginModalOpen,
        loginWithMobile,
        loginWithSocial,
        logoutUserSession,
        quickSwitchUser,
        sellers,
        activeSellerId,
        setActiveSellerId,
        currentSeller,
        sellerPayouts,
        addSellerProduct,
        updateSellerInventory,
        requestSellerPayout,
        sellerCoupons,
        createSellerCoupon,
        deleteSellerCoupon,
        toggleSellerCouponStatus,
        sellerAdminFeeLedger,
        paySellerAdminPlatformFees,
        followedSellerIds,
        toggleFollowSeller,
        isFollowingSeller,
        activeSellerStorefrontId,
        setActiveSellerStorefrontId,
        openSellerStorefront,
        likeSellerPost,
        dislikeSellerPost,
        toggleSaveSellerPost,
        addCommentToSellerPost,
        likeSellerPortfolioItem,
        dislikeSellerPortfolioItem,
        toggleSaveSellerPortfolioItem,
        createSellerPost,
        createSellerPortfolioItem,

        // Instagram-style Product Social & Comments
        productLikes,
        productComments,
        savedProductIds,
        savedSellerPostIds,
        savedSellerPortfolioIds,
        activeCommentsProductId,
        setActiveCommentsProductId,
        activeShareProduct,
        setActiveShareProduct,
        toggleLikeProduct,
        isProductLiked,
        getProductLikeCount,
        toggleSaveProductSocial,
        isProductSavedSocial,
        addProductComment,
        likeProductComment,
        isProductCommentsOpen,
        setIsProductCommentsOpen,
        isProductShareOpen,
        setIsProductShareOpen,
        isSavePortfolioOpen,
        setIsSavePortfolioOpen,

        // Favorites & Saved Products System
        userCollections,
        creatorCollections,
        activeCollectionId,
        setActiveCollectionId,
        isFavoritesHubOpen,
        setIsFavoritesHubOpen,
        activeFavoritesTab,
        setActiveFavoritesTab,
        savedProductViewMode,
        setSavedProductViewMode,
        smartSaveBottomSheet,
        openSmartSaveBottomSheet,
        closeSmartSaveBottomSheet,
        flyingSaveAnimation,
        triggerFlyingSaveAnimation,
        wishlistDetails,
        toggleWishlistWithAlert,
        smartCategorySuggestions,
        acceptSmartCategorySuggestion,
        dismissSmartCategorySuggestion,
        createCustomCollection,
        updateCollection,
        deleteCollection,
        addProductToCollection,
        removeProductFromCollection,
        moveProductBetweenCollections,
        reorderProductsInCollection,
        reactToCollaborativeItem,
        addCollaborativeComment,
        quickSaveProductWithSmartFlow,

        // Camera Creation Studio (Snapchat + Instagram + WhatsApp + Social Commerce)
        isCameraStudioOpen,
        setIsCameraStudioOpen,
        cameraInitialMode,
        setCameraInitialMode,
        cameraTargetConversationId,
        setCameraTargetConversationId,
        cameraTargetProductId,
        setCameraTargetProductId,
        cameraGalleryMedia,
        openCameraStudio,
        saveMediaToCameraGallery,
        saveMediaDraft,
        deleteMediaFromCameraGallery,
        publishMediaToStory,
        publishMediaToReel,
        publishMediaToFeed,
        publishMediaToProductCatalog,
        sendMediaDirectToChat,

        // Time-Shift 3D Stories & Spatial Social Engine
        timeShiftStories,
        setTimeShiftStories,
        isTimeShiftCameraOpen,
        setIsTimeShiftCameraOpen,
        activeTimeShiftStory,
        setActiveTimeShiftStory,
        isTimeShiftStoryViewerOpen,
        setIsTimeShiftStoryViewerOpen,
        openTimeShiftStoryViewer,
        openTimeShiftCamera,
        publishTimeShiftStory,
        recordStoryMomentReaction,
        unlockSecretStoryReward,
        voteStoryPoll,
        addOrUpdateStoryPoll,
        removeStoryPoll,

        drivers,
        activeDriverId,
        setActiveDriverId,
        currentDriver,
        toggleDriverOnline,
        driverTasks,
        updateDriverTaskStatus,
        completeDriverDeliveryWithOtp,
        driverIncentiveLedger,
        addDriverIncentiveLedgerEntry,
        isDriverIncentiveLedgerOpen,
        setIsDriverIncentiveLedgerOpen,
        convertDriverCreditsToRupees,
        apiEndpoints,
        apiLogs,
        executeApiCall,
        clearApiLogs,
        // Universal Chat
        chatConversations,
        activeConversationId,
        setActiveConversationId,
        chatMessages,
        sendChatMessage,
        toggleConversationMute,
        toggleConversationBlock,
        toggleConversationChatEnabled,
        updateDisappearingTimer,
        isUniversalChatOpen,
        setIsUniversalChatOpen,
        openDirectChatWithPeer,

        // Community Hub & 15s Reels
        communityPosts,
        isCommunityHubOpen,
        setIsCommunityHubOpen,
        activeCommunityPost,
        setActiveCommunityPost,
        likeCommunityPost,
        addCommunityComment,
        createCommunityPost,
        shareCommunityPostToChat,

        // Reseller Wallet & Margin
        resellerEarnings,
        resellerWalletBalance,
        withdrawResellerEarnings,
        simulateResellerOrderSale,

        // App Architecture Explainer
        isAppArchitectureModalOpen,
        setIsAppArchitectureModalOpen,

        // UPI Payment Apps & PIN Security
        customerUPI,
        updateCustomerUPI,
        sellerUPIs,
        updateSellerUPI,
        driverUPIs,
        updateDriverUPI,
        upiPinModalConfig,
        openUPIPinModal,
        closeUPIPinModal,
        verifyUPIPin,

        // Instagram-Style Block Functionality
        blockedUserIds,
        blockedSellerIds,
        blockRecords,
        blockedCustomerIdsBySeller,
        toggleBlockUser,
        isUserBlocked,
        toggleBlockSeller,
        isSellerBlocked,
        isProductSellerBlocked,
        unblockEntity,
        toggleBlockCustomerBySeller,
        isCustomerBlockedBySeller,
        isBlockedAccountsModalOpen,
        setIsBlockedAccountsModalOpen,
        blockConfirmModal,
        openBlockConfirmationModal,
        closeBlockConfirmationModal,

        // Instagram-Style Profile Sharing
        activeShareSeller,
        isSellerShareModalOpen,
        openSellerShareModal,
        closeSellerShareModal,

        // User Interest, Non-Interest & Nearby Engine
        isInterestManagerOpen,
        setIsInterestManagerOpen,
        userInterestProfile,
        markProductInterested,
        markProductNotInterested,
        undoNotInterested,
        clearAllNotInterested,
        removeInterestProduct,
        updateCategoryAffinity,
        resetInterestProfile,
        updateUserLocationPreference,
        setShoppingVibePreference,
        isProductInterested,
        isProductNotInterested,
        getPersonalizedRecommendedProducts,
        getNearbyInterestedProducts,
        isLoadingHomepage,
        simulateHomepageRefresh,

        // Next-Generation AI Social Network
        livingUserProfile,
        updateLivingProfile,
        switchActivePersona,
        setUserIntent,
        socialFeedMode,
        setSocialFeedMode,
        socialPosts,
        setSocialPosts,
        addSocialPost,
        addCollaborativeContribution,
        toggleContextReaction,
        convertPostToProduct,
        requestIdentityReveal,
        peopleRecommendations,
        setPeopleRecommendations,
        temporaryMoments,
        addTemporaryMoment,
        temporaryCommunities,
        joinTemporaryCommunity,
        socialMissions,
        completeSocialMission,
        opportunityMatches,
        aiTwinMemories,
        updateTwinMemory,
        deleteTwinMemory,
        resetAllTwinMemory,
        addTwinMemory,
        conversationMemories,
        searchConversationMemories,
        specializedAgents,
        toggleSpecializedAgent,
        userAttentionBudget,
        setUserAttentionBudget,
        initiateIntroduceMe,
        isIntroduceMeModalOpen,
        setIsIntroduceMeModalOpen,
        activeIntroduceMeTarget,
        setActiveIntroduceMeTarget,
        isAITwinDashboardOpen,
        setIsAITwinDashboardOpen,
        isOpportunityMatchModalOpen,
        setIsOpportunityMatchModalOpen,
        activeOpportunityMatch,
        setActiveOpportunityMatch,
        isCreateSocialEntityModalOpen,
        setIsCreateSocialEntityModalOpen,
        createSocialEntityType,
        setCreateSocialEntityType,
        openCreateSocialModal,

        // LIFEOS State & Handlers
        lifeIntents,
        setLifeIntents,
        addLifeIntent,
        toggleIntentStatus,
        deleteLifeIntent,
        socialWorlds,
        setSocialWorlds,
        joinSocialWorld,
        leaveSocialWorld,
        createSocialWorld,
        synchronicities,
        setSynchronicities,
        respondToSynchronicity,
        universalDiscoveryItems,
        setUniversalDiscoveryItems,
        lifeMemories,
        addLifeMemory,
        toggleMemoryPrivacy,
        mapNodes,
        relationshipNodes,
        aiTwinConfig,
        updateAITwinConfig,
        experiencePosts,
        addExperiencePost,
        reactToExperiencePost,
        activeLifeOSTab,
        setActiveLifeOSTab,
        isLifeIntentModalOpen,
        setIsLifeIntentModalOpen,
        isLifeVoiceModalOpen,
        setIsLifeVoiceModalOpen,
        isCreateWorldModalOpen,
        setIsCreateWorldModalOpen,
        activeWorldDetail,
        setActiveWorldDetail,
        isSafetyTrustModalOpen,
        setIsSafetyTrustModalOpen,
        isEmergentCommunityModalOpen,
        setIsEmergentCommunityModalOpen,

        // Next-Gen LifeOS Features
        lifeRadarOpportunities,
        setLifeRadarOpportunities,
        updateRadarOpportunityStatus,
        futureYouScenarios,
        runFutureYouSimulation,
        opportunityExchangeItems,
        addOpportunityExchangeItem,
        skillGraphNodes,
        toggleSkillVisibility,
        goalCommunities,
        toggleJoinGoalCommunity,
        addGoalCommunitySprintTask,
        personalGrowthNodes,
        addPersonalGrowthNode,
        ideaCollisions,
        optInIdeaCollision,
        lifeOSMoments,
        archiveMomentToMemory,
        contributionReputation,
        aiPrivacyState,
        updateAIPrivacyState,

        // 1. BioEnergy & Flow Rhythm Matrix
        bioEnergyProfile,
        setBioEnergyProfile,
        toggleFlowShield,
        toggleSoundscapePlay,
        selectSoundscape,

        // 2. Quantum Life Decision Simulator
        quantumDecisions,
        setQuantumDecisions,
        activeQuantumDecisionId,
        setActiveQuantumDecisionId,
        selectQuantumBranch,
        addQuantumDecision,

        // 3. Autonomous Life Agent Swarm
        autonomousAgents,
        setAutonomousAgents,
        approveAgentTask,
        rejectAgentTask,
        setAgentAutonomyLevel,
        triggerManualAgentSweep,

        // Next-Gen Modals
        isFutureYouModalOpen,
        setIsFutureYouModalOpen,
        isOpportunityExchangeModalOpen,
        setIsOpportunityExchangeModalOpen,
        isIdeaCollisionModalOpen,
        setIsIdeaCollisionModalOpen,
        isAIPrivacyCenterOpen,
        setIsAIPrivacyCenterOpen,
        isDataPortabilityModalOpen,
        setIsDataPortabilityModalOpen,
        isContextAwareChatOpen,
        setIsContextAwareChatOpen,
        contextAwareChatPeer,
        setContextAwareChatPeer,
        isLifeOSAgentModalOpen,
        setIsLifeOSAgentModalOpen,
        isSerendipityModalOpen,
        setIsSerendipityModalOpen,
        isAnonymousWorldModalOpen,
        setIsAnonymousWorldModalOpen,

        // Out-of-Stock Alert Subscriptions & Push Notifications
        stockAlerts,
        activeStockAlertProduct,
        activeStockAlertVariantId,
        isStockAlertModalOpen,
        openStockAlertModal,
        closeStockAlertModal,
        subscribeToStockAlert,
        unsubscribeFromStockAlert,
        isSubscribedToStockAlert,
        activePushNotificationMock,
        dismissPushNotificationMock,
        simulateStockReplenishmentPush,

        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        toggleWishlist,
        isInWishlist,
        applyCouponCode,
        removeCoupon,
        placeOrder,
        cancelOrderAndInitiateRefund,
        advanceRefundStep,
        submitReturnRequest,
        updateOrderStatus,
        updateReturnStatus,
        saveProduct,
        deleteProduct,
        saveBanner,
        deleteBanner,
        updateHomepageSections,
        updateSettings,
        updateGatewayKeys,
        updateDataPrivacy,
        updateCMSPage,
        sendAbandonedCartReminder,
        markNotificationsAsRead,
        toastMessage,
        showToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
