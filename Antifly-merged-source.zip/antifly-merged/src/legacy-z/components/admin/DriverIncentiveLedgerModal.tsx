import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { DriverIncentiveLedgerEntry } from '../../types';
import {
  Coins,
  Search,
  Filter,
  ArrowUpDown,
  Download,
  Calendar,
  CheckCircle2,
  Clock,
  Bike,
  Truck,
  Zap,
  TrendingUp,
  UserCheck,
  ChevronLeft,
  ChevronRight,
  X,
  ExternalLink,
  ShieldCheck,
  RefreshCw,
  PlusCircle,
  Award,
  Wallet,
  Receipt,
  FileSpreadsheet,
  IndianRupee,
} from 'lucide-react';

interface DriverIncentiveLedgerModalProps {
  isOpen?: boolean;
  onClose?: () => void;
  isStandaloneTab?: boolean;
}

export const DriverIncentiveLedgerModal: React.FC<DriverIncentiveLedgerModalProps> = ({
  isOpen = true,
  onClose,
  isStandaloneTab = false,
}) => {
  const {
    driverIncentiveLedger,
    drivers,
    convertDriverCreditsToRupees,
    showToast,
  } = useApp();

  // Search & Filter state
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDriverId, setSelectedDriverId] = useState<string>('all');
  const [selectedIncentiveType, setSelectedIncentiveType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'date-desc' | 'date-asc' | 'credits-desc' | 'credits-asc'>('date-desc');

  // Pagination state
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [itemsPerPage, setItemsPerPage] = useState<number>(6);

  // Selected ledger entry for detailed modal
  const [selectedEntry, setSelectedEntry] = useState<DriverIncentiveLedgerEntry | null>(null);

  // Manual conversion form state
  const [isManualConvertOpen, setIsManualConvertOpen] = useState(false);
  const [manualDriverId, setManualDriverId] = useState<string>(drivers[0]?.id || 'driver-101');
  const [manualCredits, setManualCredits] = useState<number>(120);
  const [manualReason, setManualReason] = useState<string>('Special Milestone Achievement & High Rating');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Filtered and Sorted entries
  const filteredEntries = useMemo(() => {
    return driverIncentiveLedger
      .filter((entry) => {
        // Driver filter
        if (selectedDriverId !== 'all' && entry.driverId !== selectedDriverId) {
          return false;
        }

        // Incentive Type filter
        if (selectedIncentiveType !== 'all' && entry.incentiveType !== selectedIncentiveType) {
          return false;
        }

        // Status filter
        if (selectedStatus !== 'all' && entry.status !== selectedStatus) {
          return false;
        }

        // Search term (driver name, order ID, phone, transactionRef, vehicleNumber)
        if (searchTerm.trim()) {
          const q = searchTerm.toLowerCase();
          const matches =
            entry.driverName.toLowerCase().includes(q) ||
            entry.orderId.toLowerCase().includes(q) ||
            entry.transactionReference.toLowerCase().includes(q) ||
            entry.driverPhone.includes(q) ||
            entry.vehicleNumber.toLowerCase().includes(q) ||
            entry.incentiveType.toLowerCase().includes(q);
          if (!matches) return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'date-desc') {
          return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime() || b.id.localeCompare(a.id);
        }
        if (sortBy === 'date-asc') {
          return new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime() || a.id.localeCompare(b.id);
        }
        if (sortBy === 'credits-desc') {
          return b.creditsEarned - a.creditsEarned;
        }
        if (sortBy === 'credits-asc') {
          return a.creditsEarned - b.creditsEarned;
        }
        return 0;
      });
  }, [driverIncentiveLedger, selectedDriverId, selectedIncentiveType, selectedStatus, searchTerm, sortBy]);

  // Pagination calculation
  const totalPages = Math.ceil(filteredEntries.length / itemsPerPage) || 1;
  const paginatedEntries = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredEntries.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredEntries, currentPage, itemsPerPage]);

  // Adjust current page if out of bounds
  React.useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(1);
    }
  }, [totalPages, currentPage]);

  // Aggregate Metrics
  const metrics = useMemo(() => {
    const totalCredits = driverIncentiveLedger.reduce((acc, curr) => acc + curr.creditsEarned, 0);
    const totalRupees = driverIncentiveLedger.reduce((acc, curr) => acc + curr.rupeesTransferred, 0);
    const totalTransactions = driverIncentiveLedger.length;
    const uniqueDriversCount = new Set(driverIncentiveLedger.map((e) => e.driverId)).size;
    const avgConversion = totalTransactions > 0 ? Math.round(totalRupees / totalTransactions) : 0;

    return {
      totalCredits,
      totalRupees,
      totalTransactions,
      uniqueDriversCount,
      avgConversion,
    };
  }, [driverIncentiveLedger]);

  const handleManualConvert = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCredits || manualCredits <= 0) {
      showToast('❌ Please enter a valid credit amount to convert.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await convertDriverCreditsToRupees(manualDriverId, manualCredits, manualReason);
      if (res.success) {
        setIsManualConvertOpen(false);
        setManualCredits(120);
        showToast(res.message);
      }
    } catch {
      showToast('❌ Failed to complete credit conversion.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const exportToCSV = () => {
    const headers = [
      'Transaction ID',
      'Driver Name',
      'Driver Phone',
      'Vehicle Number',
      'Order ID',
      'Timestamp',
      'Incentive Type',
      'Credits Converted',
      'Conversion Rate',
      'Rupees Transferred (INR)',
      'Status',
      'UTR Reference',
    ];

    const rows = filteredEntries.map((e) => [
      e.id,
      `"${e.driverName}"`,
      `"${e.driverPhone}"`,
      `"${e.vehicleNumber}"`,
      e.orderId,
      `"${e.timestamp}"`,
      `"${e.incentiveType}"`,
      e.creditsEarned,
      `1 Credit = 1 INR`,
      e.rupeesTransferred,
      e.status,
      e.transactionReference,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Driver_Incentive_Ledger_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('📥 Driver Incentive Ledger exported to CSV successfully.');
  };

  if (!isOpen && !isStandaloneTab) return null;

  const content = (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
              <Coins className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                Driver Incentive Ledger
                <span className="text-[11px] font-bold px-2 py-0.5 bg-amber-50 text-amber-800 border border-amber-200 rounded-full">
                  1 Credit = ₹1.00 INR
                </span>
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                Audited real-time history of delivery credits converted to Indian Rupees (INR) for registered drivers.
              </p>
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIsManualConvertOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Process New Conversion</span>
          </button>

          <button
            onClick={exportToCSV}
            className="flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Export CSV</span>
          </button>

          {onClose && !isStandaloneTab && (
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Metric Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Total Converted Credits</p>
            <p className="text-xl font-black text-slate-900 mt-1 flex items-baseline gap-1">
              {metrics.totalCredits.toLocaleString('en-IN')}
              <span className="text-xs font-bold text-amber-600">Pts</span>
            </p>
            <p className="text-[10px] text-slate-400 mt-0.5">1 Credit = 1 Rupee formula</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
            <Coins className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Total Rupees Transferred</p>
            <p className="text-xl font-black text-emerald-700 mt-1">
              ₹{metrics.totalRupees.toLocaleString('en-IN')}
            </p>
            <p className="text-[10px] text-slate-400 mt-0.5">Instant UPI & IMPS settlement</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
            <IndianRupee className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Active Drivers Rewarded</p>
            <p className="text-xl font-black text-slate-900 mt-1">
              {metrics.uniqueDriversCount}{' '}
              <span className="text-xs font-bold text-slate-500">of {drivers.length} Fleet</span>
            </p>
            <p className="text-[10px] text-slate-400 mt-0.5">{metrics.totalTransactions} total incentive payouts</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
            <UserCheck className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Avg Incentive / Order</p>
            <p className="text-xl font-black text-slate-900 mt-1">
              ₹{metrics.avgConversion.toLocaleString('en-IN')}
            </p>
            <p className="text-[10px] text-slate-400 mt-0.5">Dynamic milestone tiers</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
          {/* Search Input */}
          <div className="relative lg:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search by Driver, Order ID, UTR, Vehicle..."
              className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500 font-medium"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Driver Filter */}
          <div>
            <select
              value={selectedDriverId}
              onChange={(e) => {
                setSelectedDriverId(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:border-amber-500 cursor-pointer"
            >
              <option value="all">All Fleet Drivers ({drivers.length})</option>
              {drivers.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.vehicleType})
                </option>
              ))}
            </select>
          </div>

          {/* Incentive Type Filter */}
          <div>
            <select
              value={selectedIncentiveType}
              onChange={(e) => {
                setSelectedIncentiveType(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:border-amber-500 cursor-pointer"
            >
              <option value="all">All Incentive Triggers</option>
              <option value="Delivery Milestone Bonus">Milestone Bonus</option>
              <option value="Daily Target 20 Orders Bonus">Daily 20-Order Target</option>
              <option value="Rain / Peak Surge">Rain / Surge Bonus</option>
              <option value="5-Star Customer Rating">5-Star Customer Rating</option>
              <option value="On-Time Express Dispatch">On-Time Dispatch</option>
              <option value="Fuel & Weekend Bonus">Fuel & Weekend Bonus</option>
            </select>
          </div>

          {/* Sort By Filter */}
          <div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:border-amber-500 cursor-pointer"
            >
              <option value="date-desc">Newest Transactions</option>
              <option value="date-asc">Oldest Transactions</option>
              <option value="credits-desc">Highest Credits Amount</option>
              <option value="credits-asc">Lowest Credits Amount</option>
            </select>
          </div>
        </div>

        {/* Active Filters Row */}
        {(searchTerm || selectedDriverId !== 'all' || selectedIncentiveType !== 'all' || selectedStatus !== 'all') && (
          <div className="flex items-center gap-2 pt-2 border-t border-slate-100 flex-wrap text-xs">
            <span className="text-[11px] font-bold text-slate-400">Active Filters:</span>
            {searchTerm && (
              <span className="px-2 py-0.5 bg-amber-50 text-amber-800 border border-amber-200 rounded-md text-[11px] font-bold flex items-center gap-1">
                Query: "{searchTerm}"
                <X className="w-3 h-3 cursor-pointer" onClick={() => setSearchTerm('')} />
              </span>
            )}
            {selectedDriverId !== 'all' && (
              <span className="px-2 py-0.5 bg-blue-50 text-blue-800 border border-blue-200 rounded-md text-[11px] font-bold flex items-center gap-1">
                Driver: {drivers.find((d) => d.id === selectedDriverId)?.name}
                <X className="w-3 h-3 cursor-pointer" onClick={() => setSelectedDriverId('all')} />
              </span>
            )}
            {selectedIncentiveType !== 'all' && (
              <span className="px-2 py-0.5 bg-purple-50 text-purple-800 border border-purple-200 rounded-md text-[11px] font-bold flex items-center gap-1">
                Type: {selectedIncentiveType}
                <X className="w-3 h-3 cursor-pointer" onClick={() => setSelectedIncentiveType('all')} />
              </span>
            )}
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedDriverId('all');
                setSelectedIncentiveType('all');
                setSelectedStatus('all');
              }}
              className="text-[11px] text-rose-600 hover:text-rose-800 font-bold ml-auto cursor-pointer"
            >
              Reset All Filters
            </button>
          </div>
        )}
      </div>

      {/* Ledger Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Receipt className="w-4 h-4 text-slate-500" />
            <h3 className="text-sm font-black text-slate-900">
              Audit Transaction Records ({filteredEntries.length})
            </h3>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span>Rows per page:</span>
            <select
              value={itemsPerPage}
              onChange={(e) => {
                setItemsPerPage(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-xs font-bold text-slate-700"
            >
              <option value={5}>5</option>
              <option value={6}>6</option>
              <option value={10}>10</option>
              <option value={20}>20</option>
            </select>
          </div>
        </div>

        {paginatedEntries.length === 0 ? (
          <div className="p-12 text-center">
            <Coins className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h4 className="text-sm font-black text-slate-900">No Ledger Records Found</h4>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              No conversion history matches your current search or filter criteria. Try resetting the filters or trigger a manual conversion.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase text-[10px] font-black tracking-wider">
                <tr>
                  <th className="py-3.5 px-4">Timestamp</th>
                  <th className="py-3.5 px-4">Driver Partner</th>
                  <th className="py-3.5 px-4">Order ID</th>
                  <th className="py-3.5 px-4">Incentive Trigger</th>
                  <th className="py-3.5 px-4 text-right">Credits Converted</th>
                  <th className="py-3.5 px-4 text-right">INR Transferred</th>
                  <th className="py-3.5 px-4 text-center">Settlement Status</th>
                  <th className="py-3.5 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                {paginatedEntries.map((entry) => (
                  <tr
                    key={entry.id}
                    className="hover:bg-amber-50/40 transition-colors group cursor-pointer"
                    onClick={() => setSelectedEntry(entry)}
                  >
                    {/* Timestamp */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="flex items-center gap-1.5 text-slate-900 font-bold">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        <span>{entry.timestamp}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono">ID: {entry.id}</span>
                    </td>

                    {/* Driver Profile */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={entry.driverAvatar}
                          alt={entry.driverName}
                          className="w-8 h-8 rounded-xl object-cover border border-slate-200"
                        />
                        <div>
                          <div className="font-extrabold text-slate-900 text-xs flex items-center gap-1">
                            {entry.driverName}
                            <span className="text-[10px] text-slate-400 font-normal">({entry.driverId})</span>
                          </div>
                          <div className="text-[10px] text-slate-500 flex items-center gap-1 mt-0.5">
                            {entry.vehicleType === 'Cargo Van' ? (
                              <Truck className="w-3 h-3 text-slate-400" />
                            ) : (
                              <Bike className="w-3 h-3 text-slate-400" />
                            )}
                            <span>{entry.vehicleNumber}</span>
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Order ID */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-1 rounded-md text-[11px]">
                        {entry.orderId}
                      </span>
                    </td>

                    {/* Incentive Trigger */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-1.5">
                        <Award className="w-3.5 h-3.5 text-amber-600 flex-shrink-0" />
                        <span className="font-bold text-slate-900 text-xs">{entry.incentiveType}</span>
                      </div>
                      <span className="text-[10px] text-slate-400">
                        Milestone: {entry.ordersMilestoneCount} deliveries
                      </span>
                    </td>

                    {/* Credits Converted */}
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <span className="font-black text-amber-700 text-xs px-2 py-0.5 bg-amber-50 rounded-md border border-amber-200">
                        {entry.creditsEarned} Credits
                      </span>
                      <div className="text-[10px] text-slate-400 mt-0.5">Rate: 1 cr = ₹1</div>
                    </td>

                    {/* Final Amount Transferred in INR */}
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <div className="font-black text-slate-900 text-sm text-emerald-700">
                        ₹{entry.rupeesTransferred.toLocaleString('en-IN')}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono truncate max-w-[130px] ml-auto">
                        {entry.transactionReference}
                      </div>
                    </td>

                    {/* Status */}
                    <td className="py-3.5 px-4 text-center whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black ${
                          entry.status === 'Settled to UPI'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : entry.status === 'Direct Bank IMPS'
                            ? 'bg-blue-50 text-blue-800 border border-blue-200'
                            : 'bg-amber-50 text-amber-800 border border-amber-200'
                        }`}
                      >
                        {entry.status === 'Processing' ? (
                          <Clock className="w-3 h-3" />
                        ) : (
                          <CheckCircle2 className="w-3 h-3" />
                        )}
                        {entry.status}
                      </span>
                    </td>

                    {/* View Details Action */}
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedEntry(entry);
                        }}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-amber-500 hover:text-slate-800 text-slate-700 text-xs font-bold rounded-lg transition-all"
                      >
                        Details
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination Controls */}
        <div className="p-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="text-slate-500 font-medium">
            Showing <span className="font-bold text-slate-900">{filteredEntries.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0}</span> to{' '}
            <span className="font-bold text-slate-900">{Math.min(currentPage * itemsPerPage, filteredEntries.length)}</span> of{' '}
            <span className="font-bold text-slate-900">{filteredEntries.length}</span> entries
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
              <button
                key={pageNum}
                onClick={() => setCurrentPage(pageNum)}
                className={`min-w-[32px] h-8 px-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  currentPage === pageNum
                    ? 'bg-amber-500 text-slate-800 font-extrabold shadow-xs'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                {pageNum}
              </button>
            ))}

            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Transaction Detail Drawer Modal */}
      {selectedEntry && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full border border-slate-200 shadow-2xl p-6 relative animate-scale-up space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
                  <Receipt className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Incentive Transfer Receipt</h3>
                  <p className="text-[11px] text-slate-400 font-mono">Ref: {selectedEntry.transactionReference}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedEntry(null)}
                className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-all"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Main Transfer Amount Hero */}
            <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-2xl text-center">
              <span className="text-[10px] font-black text-emerald-800 uppercase tracking-wider">
                Direct Rupees Transferred to Driver Wallet
              </span>
              <div className="text-3xl font-black text-emerald-700 mt-1">
                ₹{selectedEntry.rupeesTransferred.toLocaleString('en-IN')}
              </div>
              <div className="flex items-center justify-center gap-2 mt-1 text-xs text-emerald-800 font-bold">
                <span>{selectedEntry.creditsEarned} Credits</span>
                <span>•</span>
                <span>Rate: 1 Credit = ₹1.00 INR</span>
              </div>
            </div>

            {/* Breakdown details */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Driver Partner:</span>
                <span className="font-bold text-slate-900">{selectedEntry.driverName} ({selectedEntry.driverId})</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Contact & Vehicle:</span>
                <span className="font-medium text-slate-700">{selectedEntry.driverPhone} • {selectedEntry.vehicleNumber} ({selectedEntry.vehicleType})</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Associated Order ID:</span>
                <span className="font-mono font-bold text-slate-900">{selectedEntry.orderId}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Incentive Trigger:</span>
                <span className="font-bold text-amber-700">{selectedEntry.incentiveType}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Milestone Deliveries:</span>
                <span className="font-bold text-slate-900">{selectedEntry.ordersMilestoneCount} completed deliveries</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Disbursement Status:</span>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-bold rounded-md text-[11px]">
                  {selectedEntry.status}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Audit Timestamp:</span>
                <span className="font-mono text-slate-700">{selectedEntry.timestamp}</span>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => {
                  showToast(`📋 Copied UTR ${selectedEntry.transactionReference} to clipboard!`);
                  setSelectedEntry(null);
                }}
                className="flex-1 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                Copy Reference & Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Manual Conversion Action Modal */}
      {isManualConvertOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl p-6 relative animate-scale-up space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
                  <PlusCircle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Process Credit Conversion</h3>
                  <p className="text-[11px] text-slate-500">Convert driver credits to real INR balance</p>
                </div>
              </div>
              <button
                onClick={() => setIsManualConvertOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleManualConvert} className="space-y-3.5 text-xs">
              {/* Select Driver */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                  Select Driver Partner
                </label>
                <select
                  value={manualDriverId}
                  onChange={(e) => setManualDriverId(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-amber-500 cursor-pointer"
                >
                  {drivers.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name} ({d.vehicleType} • {d.vehicleNumber}) - Current Balance: ₹{d.walletBalance}
                    </option>
                  ))}
                </select>
              </div>

              {/* Credits to Convert */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                  Credits to Convert (1 Credit = ₹1 INR)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={manualCredits}
                    onChange={(e) => setManualCredits(Math.max(1, Number(e.target.value)))}
                    min={1}
                    max={10000}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black text-slate-900 focus:outline-none focus:border-amber-500"
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                    = ₹{manualCredits} INR
                  </div>
                </div>
                {/* Preset quick buttons */}
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-[10px] text-slate-400 font-bold">Quick Presets:</span>
                  {[20, 50, 120, 300].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setManualCredits(preset)}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold border transition-all cursor-pointer ${
                        manualCredits === preset
                          ? 'bg-amber-500 text-slate-900 border-amber-500'
                          : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                      }`}
                    >
                      {preset} Pts (₹{preset})
                    </button>
                  ))}
                </div>
              </div>

              {/* Incentive Reason / Milestone */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                  Milestone Trigger / Admin Note
                </label>
                <input
                  type="text"
                  value={manualReason}
                  onChange={(e) => setManualReason(e.target.value)}
                  placeholder="e.g. 5 Deliveries Milestone Bonus or Daily Target Achieved"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="bg-amber-50 border border-amber-200 p-3 rounded-xl flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-700 flex-shrink-0 mt-0.5" />
                <p className="text-[11px] text-amber-900 leading-tight">
                  Funds will be credited immediately to the driver's in-app wallet balance and logged into the audit security ledger.
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsManualConvertOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-extrabold rounded-xl text-xs shadow-xs transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Converting...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Confirm & Transfer ₹{manualCredits}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );

  // Render as standalone tab or modal dialog
  if (isStandaloneTab) {
    return content;
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-5xl w-full border border-slate-200 shadow-2xl p-4 sm:p-6 max-h-[92vh] overflow-y-auto">
        {content}
      </div>
    </div>
  );
};
