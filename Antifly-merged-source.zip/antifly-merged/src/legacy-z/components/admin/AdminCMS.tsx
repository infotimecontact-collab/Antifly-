import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CMSPage, HomepageSection } from '../../types';
import {
  Layers,
  FileText,
  Save,
  Eye,
  CheckCircle,
  ArrowUp,
  ArrowDown,
  ToggleLeft,
  ToggleRight,
  Sparkles,
  Edit3,
  Globe,
  Sliders,
} from 'lucide-react';

export const AdminCMS: React.FC = () => {
  const {
    cmsPages,
    homepageSections,
    updateCMSPage,
    updateHomepageSections,
    setActiveCMSPage,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'pages' | 'homepage-builder'>('pages');
  const [selectedPage, setSelectedPage] = useState<CMSPage>(cmsPages[0] || {
    slug: 'about-us',
    title: 'About Antifly',
    metaDescription: 'Antifly brand story',
    content: 'Antifly crafts exceptional sustainable fashion...',
    lastUpdated: '2026-08-15',
    version: '1.2',
  });
  const [pageTitle, setPageTitle] = useState(selectedPage.title);
  const [pageContent, setPageContent] = useState(selectedPage.content);
  const [isSaving, setIsSaving] = useState(false);

  // Sections builder local state
  const [sections, setSections] = useState<HomepageSection[]>(homepageSections);

  const handleSelectPage = (page: CMSPage) => {
    setSelectedPage(page);
    setPageTitle(page.title);
    setPageContent(page.content);
  };

  const handleSavePage = async () => {
    setIsSaving(true);
    await updateCMSPage(selectedPage.slug, pageContent, pageTitle);
    setIsSaving(false);
  };

  const handleToggleSection = (id: string) => {
    const updated = sections.map((s) => (s.id === id ? { ...s, isVisible: !s.isVisible } : s));
    setSections(updated);
  };

  const handleMoveSection = (index: number, direction: 'up' | 'down') => {
    const newSections = [...sections];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newSections.length) return;

    const temp = newSections[index];
    newSections[index] = newSections[targetIndex];
    newSections[targetIndex] = temp;

    // re-assign order numbers
    newSections.forEach((s, idx) => {
      s.order = idx + 1;
    });

    setSections(newSections);
  };

  const handleSaveHomepageLayout = async () => {
    await updateHomepageSections(sections);
  };

  return (
    <div id="admin-cms-view" className="space-y-6 text-slate-900">
      {/* Header & Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-slate-200 p-5 rounded-2xl shadow-xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Layers className="w-5 h-5 text-amber-600" />
            CMS & Homepage Layout Builder
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Maintain legal policies, brand editorial pages, and dynamically orchestrate the storefront homepage modules.
          </p>
        </div>

        <div className="flex gap-1.5 bg-slate-100 p-1.5 rounded-xl border border-slate-200 text-xs">
          <button
            onClick={() => setActiveTab('pages')}
            className={`px-4 py-2 rounded-lg font-bold transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'pages'
                ? 'bg-amber-500 text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileText className="w-4 h-4" />
            Content & Policy Pages
          </button>
          <button
            onClick={() => setActiveTab('homepage-builder')}
            className={`px-4 py-2 rounded-lg font-bold transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'homepage-builder'
                ? 'bg-amber-500 text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sliders className="w-4 h-4" />
            Homepage Section Builder
          </button>
        </div>
      </div>

      {activeTab === 'pages' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Sidebar: Pages List */}
          <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-4 space-y-2 shadow-xs">
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider px-2 py-1 mb-2">
              Published CMS Pages ({cmsPages.length})
            </div>
            {cmsPages.map((page) => (
              <button
                key={page.slug}
                onClick={() => handleSelectPage(page)}
                className={`w-full text-left p-3 rounded-xl transition flex items-center justify-between group cursor-pointer ${
                  selectedPage.slug === page.slug
                    ? 'bg-amber-50 border border-amber-300 text-amber-900'
                    : 'bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <div>
                  <div className="text-xs font-bold">{page.title}</div>
                  <div className="text-[10px] text-slate-500 font-mono mt-0.5">/{page.slug}</div>
                </div>
                <span className="text-[10px] font-mono text-slate-500">v{page.version}</span>
              </button>
            ))}
          </div>

          {/* Right Editor: Content Editing */}
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <span className="text-[10px] uppercase font-mono text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                  Editing: /{selectedPage.slug}
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-1.5">{pageTitle}</h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveCMSPage(selectedPage)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl flex items-center gap-1.5 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  Preview Modal
                </button>
                <button
                  onClick={handleSavePage}
                  disabled={isSaving}
                  className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-900 text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  {isSaving ? 'Saving...' : 'Save & Publish'}
                </button>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Page Title</label>
                <input
                  type="text"
                  value={pageTitle}
                  onChange={(e) => setPageTitle(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 font-medium focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">SEO Meta Description</label>
                <input
                  type="text"
                  value={selectedPage.metaDescription}
                  readOnly
                  className="w-full bg-slate-100 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-500 focus:outline-none cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Page Content & Legal Terms (HTML / Markdown Formatted)
                </label>
                <textarea
                  rows={14}
                  value={pageContent}
                  onChange={(e) => setPageContent(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 text-slate-800 font-sans text-xs leading-relaxed focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100">
                <span>Last updated: {selectedPage.lastUpdated}</span>
                <span>Security verified & compliant with consumer protection norms</span>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Homepage Builder */
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-6 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
              <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                <Sliders className="w-4 h-4 text-amber-600" />
                Storefront Layout Orchestrator
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Drag or re-order sections, toggle visibility, and control the flow of the customer website and mobile home feeds.
              </p>
            </div>

            <button
              onClick={handleSaveHomepageLayout}
              className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              Publish Live Layout
            </button>
          </div>

          <div className="space-y-3">
            {sections.map((section, idx) => (
              <div
                key={section.id}
                className={`p-4 rounded-xl border flex items-center justify-between transition ${
                  section.isVisible
                    ? 'bg-slate-50 border-slate-200'
                    : 'bg-slate-100/60 border-slate-200/80 opacity-60'
                }`}
              >
                <div className="flex items-center gap-4">
                  <span className="w-7 h-7 rounded-lg bg-white border border-slate-200 text-slate-700 font-mono font-bold text-xs flex items-center justify-center shadow-xs">
                    #{section.order}
                  </span>
                  <div>
                    <div className="text-xs font-bold text-slate-900 flex items-center gap-2">
                      {section.title}
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-200">
                        {section.type}
                      </span>
                    </div>
                    {section.subtitle && (
                      <div className="text-[11px] text-slate-500 mt-0.5">{section.subtitle}</div>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  {/* Toggle Visibility */}
                  <button
                    onClick={() => handleToggleSection(section.id)}
                    className={`text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition cursor-pointer ${
                      section.isVisible
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : 'bg-slate-200 text-slate-600 border border-slate-300'
                    }`}
                  >
                    {section.isVisible ? (
                      <>
                        <CheckCircle className="w-3.5 h-3.5" /> Visible
                      </>
                    ) : (
                      'Hidden'
                    )}
                  </button>

                  {/* Move Up / Down */}
                  <div className="flex items-center bg-white border border-slate-200 rounded-lg p-0.5 shadow-xs">
                    <button
                      disabled={idx === 0}
                      onClick={() => handleMoveSection(idx, 'up')}
                      className="p-1.5 hover:text-slate-900 text-slate-500 disabled:opacity-30 rounded cursor-pointer"
                      title="Move section up"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      disabled={idx === sections.length - 1}
                      onClick={() => handleMoveSection(idx, 'down')}
                      className="p-1.5 hover:text-slate-900 text-slate-500 disabled:opacity-30 rounded cursor-pointer"
                      title="Move section down"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
