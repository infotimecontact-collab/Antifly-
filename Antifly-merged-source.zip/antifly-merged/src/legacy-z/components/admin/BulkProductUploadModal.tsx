import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { Product } from '../../types';
import {
  Upload,
  Download,
  FileSpreadsheet,
  FileText,
  CheckCircle2,
  AlertTriangle,
  X,
  FileCheck,
  RefreshCw,
  Sparkles,
  ArrowRight,
  Database,
  Trash2,
} from 'lucide-react';

interface BulkProductUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ParsedProductRow {
  name: string;
  brand: string;
  category: string;
  subcategory: string;
  price: number;
  mrp: number;
  totalStock: number;
  sku: string;
  sizes: string;
  colors: string;
  imageUrl: string;
  description: string;
  status: 'valid' | 'invalid';
  error?: string;
}

const SAMPLE_CSV_CONTENT = `name,brand,category,subcategory,price,mrp,totalStock,sku,sizes,colors,imageUrl,description
"Pure Handwoven Chanderi Silk Saree","Royal Weaves","Women","Ethnic Wear",4299,6999,35,"SKU-CHAN-441","Free Size","Gold;Maroon","https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&auto=format&fit=crop&q=80","Authentic handloom Zari border saree crafted by master artisans."
"Minimalist Linen Mandarin Shirt","Antifly Studio","Men","Casual Shirts",1899,2899,45,"SKU-LIN-882","M;L;XL;XXL","Sage Green;Ivory","https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=600&auto=format&fit=crop&q=80","Breathable 100% pure organic linen tailored for breezy tropical comfort."
"ActiveNoise Pro Wireless Earbuds","SoundCraft","Electronics","Audio",2499,4999,80,"SKU-ANC-091","Standard","Matte Black;Titanium","https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=600&auto=format&fit=crop&q=80","Ultra-low latency wireless earbuds with 40-hour battery and 35dB active noise cancelling."
"Kumkumadi Ayurvedic Glow Night Serum (30ml)","VedaBotanicals","Beauty","Skincare",899,1499,60,"SKU-KUM-312","30ml","Natural Amber","https://images.unsplash.com/photo-1556228720-195a672e8a03?w=600&auto=format&fit=crop&q=80","Kashmiri saffron and 26 therapeutic herbs infused botanical elixir."
"Handcrafted Brass Filter Coffee Maker","Heritage India","Home & Living","Kitchenware",1250,1850,25,"SKU-COF-103","Standard (4 Cups)","Antique Brass","https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=600&auto=format&fit=crop&q=80","Traditional South Indian decoction brass drip coffee brewer."`;

export const BulkProductUploadModal: React.FC<BulkProductUploadModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { saveProduct, showToast, products } = useApp();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [dragActive, setDragActive] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [parsedRows, setParsedRows] = useState<ParsedProductRow[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [importMode, setImportMode] = useState<'append' | 'replace'>('append');

  if (!isOpen) return null;

  // Download Dummy CSV File
  const handleDownloadSampleCSV = () => {
    const blob = new Blob([SAMPLE_CSV_CONTENT], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'antifly_products_bulk_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('📥 Sample CSV Template Downloaded!');
  };

  // Download Dummy JSON File
  const handleDownloadSampleJSON = () => {
    const sampleData = [
      {
        name: 'Pure Handwoven Chanderi Silk Saree',
        brand: 'Royal Weaves',
        category: 'Women',
        subcategory: 'Ethnic Wear',
        price: 4299,
        mrp: 6999,
        totalStock: 35,
        sku: 'SKU-CHAN-441',
        sizes: ['Free Size'],
        colors: [{ name: 'Gold', hex: '#D4AF37' }, { name: 'Maroon', hex: '#800000' }],
        imageUrl: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&auto=format&fit=crop&q=80',
        description: 'Authentic handloom Zari border saree crafted by master artisans.',
      },
      {
        name: 'Minimalist Linen Mandarin Shirt',
        brand: 'Antifly Studio',
        category: 'Men',
        subcategory: 'Casual Shirts',
        price: 1899,
        mrp: 2899,
        totalStock: 45,
        sku: 'SKU-LIN-882',
        sizes: ['M', 'L', 'XL', 'XXL'],
        colors: [{ name: 'Sage Green', hex: '#8A9A86' }, { name: 'Ivory', hex: '#FFFFF0' }],
        imageUrl: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=600&auto=format&fit=crop&q=80',
        description: 'Breathable 100% pure organic linen tailored for breezy tropical comfort.',
      },
    ];

    const blob = new Blob([JSON.stringify(sampleData, null, 2)], {
      type: 'application/json;charset=utf-8;',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'antifly_products_bulk_template.json');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('📥 Sample JSON Template Downloaded!');
  };

  // Pre-load dummy demo data into upload stage
  const handleLoadDemoData = () => {
    parseCSVText(SAMPLE_CSV_CONTENT);
    setFileName('sample_dummy_products.csv (Pre-loaded)');
    showToast('⚡ Sample dummy catalog loaded into preview table!');
  };

  // CSV Text Parser
  const parseCSVText = (text: string) => {
    try {
      const lines = text.trim().split('\n');
      if (lines.length < 2) {
        showToast('CSV file is empty or has no header row.');
        return;
      }

      // Simple CSV line parser supporting quoted values
      const parseCSVLine = (line: string): string[] => {
        const result: string[] = [];
        let cur = '';
        let inQuotes = false;
        for (let i = 0; i < line.length; i++) {
          const char = line[i];
          if (char === '"') {
            inQuotes = !inQuotes;
          } else if (char === ',' && !inQuotes) {
            result.push(cur.trim().replace(/^"|"$/g, ''));
            cur = '';
          } else {
            cur += char;
          }
        }
        result.push(cur.trim().replace(/^"|"$/g, ''));
        return result;
      };

      const headers = parseCSVLine(lines[0]).map((h) => h.toLowerCase());
      const rows: ParsedProductRow[] = [];

      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        const vals = parseCSVLine(line);

        const rowObj: Record<string, string> = {};
        headers.forEach((h, idx) => {
          rowObj[h] = vals[idx] || '';
        });

        const name = rowObj['name'] || rowObj['product'] || rowObj['title'] || '';
        const price = Number(rowObj['price']) || 0;
        const mrp = Number(rowObj['mrp']) || price * 1.25 || 0;
        const totalStock = Number(rowObj['totalstock'] || rowObj['stock'] || rowObj['quantity']) || 50;
        const sku = rowObj['sku'] || `SKU-IMP-${Math.floor(1000 + Math.random() * 9000)}`;

        let status: 'valid' | 'invalid' = 'valid';
        let error = '';

        if (!name) {
          status = 'invalid';
          error = 'Missing product name';
        } else if (price <= 0) {
          status = 'invalid';
          error = 'Price must be greater than 0';
        }

        rows.push({
          name,
          brand: rowObj['brand'] || 'Antifly Merchant',
          category: rowObj['category'] || 'Fashion',
          subcategory: rowObj['subcategory'] || 'Apparel',
          price,
          mrp,
          totalStock,
          sku,
          sizes: rowObj['sizes'] || 'S;M;L;XL',
          colors: rowObj['colors'] || 'Black;White',
          imageUrl:
            rowObj['imageurl'] ||
            rowObj['image'] ||
            'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80',
          description: rowObj['description'] || 'High quality verified product.',
          status,
          error,
        });
      }

      setParsedRows(rows);
    } catch (err) {
      console.error(err);
      showToast('Error parsing file. Please verify CSV formatting.');
    }
  };

  // JSON Parser
  const parseJSONText = (text: string) => {
    try {
      const data = JSON.parse(text);
      if (!Array.isArray(data)) {
        showToast('JSON must be an array of product objects.');
        return;
      }

      const rows: ParsedProductRow[] = data.map((item: any, idx: number) => {
        const name = item.name || item.title || '';
        const price = Number(item.price) || 0;
        let status: 'valid' | 'invalid' = 'valid';
        let error = '';

        if (!name) {
          status = 'invalid';
          error = 'Missing name';
        } else if (price <= 0) {
          status = 'invalid';
          error = 'Price must be > 0';
        }

        return {
          name,
          brand: item.brand || 'Antifly Merchant',
          category: item.category || 'General',
          subcategory: item.subcategory || 'Catalog',
          price,
          mrp: Number(item.mrp) || price * 1.3,
          totalStock: Number(item.totalStock || item.stock) || 50,
          sku: item.sku || `SKU-J-${idx + 100}`,
          sizes: Array.isArray(item.sizes) ? item.sizes.join(';') : item.sizes || 'Standard',
          colors: Array.isArray(item.colors)
            ? item.colors.map((c: any) => (typeof c === 'string' ? c : c.name)).join(';')
            : item.colors || 'Multi',
          imageUrl:
            item.imageUrl ||
            (Array.isArray(item.images) ? item.images[0] : null) ||
            'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80',
          description: item.description || 'Enterprise catalog verified.',
          status,
          error,
        };
      });

      setParsedRows(rows);
    } catch (e) {
      showToast('Invalid JSON file format.');
    }
  };

  // File Input Handler
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    readFile(file);
  };

  const readFile = (file: File) => {
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (file.name.endsWith('.json')) {
        parseJSONText(content);
      } else {
        parseCSVText(content);
      }
    };
    reader.readAsText(file);
  };

  // Drag & Drop Handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      readFile(e.dataTransfer.files[0]);
    }
  };

  // Commit Import
  const handleCommitImport = async () => {
    const validRows = parsedRows.filter((r) => r.status === 'valid');
    if (validRows.length === 0) {
      showToast('No valid products to import!');
      return;
    }

    setIsProcessing(true);

    for (const r of validRows) {
      const sizeArr = r.sizes.split(';').map((s) => s.trim());
      const colorArr = r.colors.split(';').map((c) => ({
        name: c.trim(),
        hex: '#0f172a',
      }));

      const newProduct: Partial<Product> = {
        name: r.name,
        brand: r.brand,
        category: r.category,
        subcategory: r.subcategory,
        price: r.price,
        mrp: r.mrp,
        totalStock: r.totalStock,
        sku: r.sku,
        rating: 4.8,
        reviewCount: Math.floor(Math.random() * 25) + 5,
        shortDescription: r.description.slice(0, 80),
        description: r.description,
        images: [r.imageUrl],
        sizes: sizeArr,
        colors: colorArr,
        isPublished: true,
        isFeatured: true,
        tags: [r.category, r.brand, 'BulkImported'],
        specifications: [
          { label: 'Origin', value: 'Certified Warehouse Fulfillment' },
          { label: 'Warranty', value: '1-Year Standard Guarantee' },
        ],
        shippingInfo: 'Standard 24-48 Hour Express Dispatch',
        returnPolicy: '7-Day Return & Replacement Guarantee',
        exchangePolicy: 'Doorstep Size Exchange Available',
      };

      await saveProduct(newProduct);
    }

    setIsProcessing(false);
    showToast(`🎉 Successfully imported ${validRows.length} products to live catalog!`);
    onClose();
  };

  const validCount = parsedRows.filter((r) => r.status === 'valid').length;
  const invalidCount = parsedRows.length - validCount;

  return (
    <div
      id="bulk-product-upload-modal"
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-fade-in"
    >
      <div className="bg-white border border-slate-200 w-full max-w-5xl rounded-3xl shadow-2xl overflow-hidden flex flex-col my-auto max-h-[92vh] text-slate-900">
        {/* Header */}
        <div className="p-5 sm:p-6 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 border border-amber-200 flex items-center justify-center text-amber-700 shadow-xs">
              <Upload className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-extrabold uppercase tracking-wider bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full border border-amber-200">
                  Admin Catalog Ingestion
                </span>
                <span className="text-xs text-slate-500">CSV & JSON Drag & Drop Engine</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-0.5">
                Bulk Upload Products via File
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-900 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action / Template Download Bar */}
        <div className="px-6 py-3.5 bg-slate-50/70 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-600 font-semibold">Download Dummy Sample Files:</span>
            <button
              onClick={handleDownloadSampleCSV}
              className="px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl text-amber-800 font-bold flex items-center gap-1.5 transition shadow-xs cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Sample CSV Template</span>
              <Download className="w-3 h-3 text-slate-400" />
            </button>

            <button
              onClick={handleDownloadSampleJSON}
              className="px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl text-sky-800 font-bold flex items-center gap-1.5 transition shadow-xs cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Sample JSON Template</span>
              <Download className="w-3 h-3 text-slate-400" />
            </button>
          </div>

          <button
            onClick={handleLoadDemoData}
            className="px-3.5 py-1.5 bg-amber-50 border border-amber-200 text-amber-800 hover:bg-amber-100 rounded-xl font-bold flex items-center gap-1.5 transition cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>Pre-load 5 Dummy Products</span>
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* Drag & Drop Upload Zone */}
          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-3xl p-8 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-3 ${
              dragActive
                ? 'border-amber-500 bg-amber-50 scale-[1.01]'
                : 'border-slate-300 bg-slate-50 hover:border-slate-400 hover:bg-slate-100/70'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.json,.txt,.tsv"
              onChange={handleFileChange}
              className="hidden"
            />
            <div className="w-16 h-16 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center">
              <Upload className="w-8 h-8" />
            </div>

            <div>
              <p className="font-extrabold text-sm text-slate-900">
                {fileName ? fileName : 'Click to Browse or Drag & Drop Product File Here'}
              </p>
              <p className="text-xs text-slate-500 mt-1">
                Supports Standard CSV (Comma-separated) and JSON catalogs with image URLs, SKUs, and stock
              </p>
            </div>

            <span className="px-3 py-1 bg-white rounded-full text-[11px] font-mono text-slate-600 border border-slate-200 shadow-xs">
              Format: name, brand, category, price, mrp, stock, sku, sizes, colors, image
            </span>
          </div>

          {/* Validation & Statistics Banner */}
          {parsedRows.length > 0 && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span className="text-xs font-bold text-slate-800">
                      {validCount} Valid Products Ready
                    </span>
                  </div>

                  {invalidCount > 0 && (
                    <div className="flex items-center gap-2 text-rose-600">
                      <AlertTriangle className="w-4 h-4" />
                      <span className="text-xs font-bold">{invalidCount} Rows Need Correction</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-600">Import Mode:</span>
                  <select
                    value={importMode}
                    onChange={(e) => setImportMode(e.target.value as any)}
                    className="p-1.5 bg-white border border-slate-200 rounded-lg text-slate-800 font-semibold focus:outline-none cursor-pointer"
                  >
                    <option value="append">Append to Catalog (Safe)</option>
                    <option value="replace">Update Existing SKUs</option>
                  </select>
                </div>
              </div>

              {/* Parsed Preview Table */}
              <div className="border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-xs">
                <div className="p-3 bg-slate-50 border-b border-slate-200 flex justify-between items-center text-xs">
                  <span className="font-bold uppercase tracking-wider text-slate-700">
                    File Parse Preview ({parsedRows.length} items detected)
                  </span>
                  <button
                    onClick={() => {
                      setParsedRows([]);
                      setFileName(null);
                    }}
                    className="text-rose-600 hover:text-rose-700 flex items-center gap-1 font-semibold cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Clear Preview
                  </button>
                </div>

                <div className="max-h-72 overflow-y-auto overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-700">
                    <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] border-b border-slate-200 sticky top-0">
                      <tr>
                        <th className="p-3">Product Name & Brand</th>
                        <th className="p-3">SKU / Dept</th>
                        <th className="p-3">Price & MRP</th>
                        <th className="p-3">Stock</th>
                        <th className="p-3">Sizes / Colors</th>
                        <th className="p-3">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {parsedRows.map((r, idx) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="p-3">
                            <div className="flex items-center gap-2.5">
                              <img
                                src={r.imageUrl}
                                alt={r.name}
                                className="w-10 h-10 rounded-lg object-cover bg-slate-100 border border-slate-200 flex-shrink-0"
                              />
                              <div className="min-w-0">
                                <span className="text-[10px] font-bold text-amber-700 uppercase">
                                  {r.brand}
                                </span>
                                <h5 className="font-bold text-slate-900 text-xs truncate max-w-[200px]">
                                  {r.name}
                                </h5>
                              </div>
                            </div>
                          </td>
                          <td className="p-3">
                            <p className="font-mono text-slate-800 font-semibold">{r.sku}</p>
                            <p className="text-[10px] text-slate-500">{r.category}</p>
                          </td>
                          <td className="p-3 font-mono">
                            <span className="font-bold text-slate-900">₹{r.price}</span>
                            <span className="text-[10px] text-slate-400 line-through ml-1.5">
                              ₹{r.mrp}
                            </span>
                          </td>
                          <td className="p-3">
                            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 font-mono">
                              {r.totalStock}
                            </span>
                          </td>
                          <td className="p-3 text-[11px] text-slate-600">
                            <p>{r.sizes}</p>
                            <p className="text-[10px] text-slate-400">{r.colors}</p>
                          </td>
                          <td className="p-3">
                            {r.status === 'valid' ? (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1 w-fit">
                                <CheckCircle2 className="w-3 h-3" /> Valid
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200 flex items-center gap-1 w-fit">
                                <AlertTriangle className="w-3 h-3" /> {r.error}
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer CTAs */}
        <div className="p-5 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition cursor-pointer"
          >
            Cancel
          </button>

          <button
            onClick={handleCommitImport}
            disabled={parsedRows.length === 0 || validCount === 0 || isProcessing}
            className={`px-6 py-2.5 rounded-xl font-extrabold text-xs flex items-center gap-2 shadow-sm transition ${
              parsedRows.length > 0 && validCount > 0 && !isProcessing
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-900 shadow-amber-500/20 active:scale-95 cursor-pointer'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
          >
            {isProcessing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Importing {validCount} Products...</span>
              </>
            ) : (
              <>
                <Database className="w-4 h-4" />
                <span>Commit & Import {validCount} Products to Live Catalog</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
