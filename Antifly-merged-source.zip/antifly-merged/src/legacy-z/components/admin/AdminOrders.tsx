import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Order, OrderStatus } from '../../types';
import {
  Search,
  Truck,
  PackageCheck,
  CheckCircle,
  Clock,
  RotateCcw,
  FileText,
  Filter,
  Eye,
  X,
  ExternalLink,
} from 'lucide-react';

export const AdminOrders: React.FC = () => {
  const { orders, updateOrderStatus, showToast } = useApp();

  const [sourceFilter, setSourceFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [search, setSearch] = useState('');
  const [activeOrderModal, setActiveOrderModal] = useState<Order | null>(null);

  // Status updating state inside modal
  const [newStatus, setNewStatus] = useState<OrderStatus>('Shipped');
  const [courier, setCourier] = useState('Delhivery Express');
  const [trackingNo, setTrackingNo] = useState('DEL98827419');

  const filteredOrders = orders.filter((o) => {
    if (sourceFilter !== 'All' && o.source.toLowerCase() !== sourceFilter.toLowerCase()) return false;
    if (statusFilter !== 'All' && o.status.toLowerCase() !== statusFilter.toLowerCase()) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        o.orderNumber.toLowerCase().includes(q) ||
        o.customerName.toLowerCase().includes(q) ||
        o.customerEmail.toLowerCase().includes(q) ||
        o.shippingAddress.city.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleUpdateStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeOrderModal) return;

    await updateOrderStatus(activeOrderModal.id, newStatus, courier, trackingNo);
    showToast(`Order #${activeOrderModal.orderNumber} updated to ${newStatus}`);
    setActiveOrderModal(null);
  };

  const handleQuickStatusChange = async (orderId: string, status: OrderStatus) => {
    await updateOrderStatus(orderId, status);
    showToast(`Order status updated to ${status}`);
  };

  const statuses: OrderStatus[] = [
    'Pending',
    'Confirmed',
    'Packed',
    'Shipped',
    'Out for delivery',
    'Delivered',
    'Cancelled',
    'Returned',
    'Refunded',
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white">
            Omnichannel Orders Manager
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Process fulfillment across Website, Android App, and iOS App orders
          </p>
        </div>
        <div className="flex items-center gap-2 font-mono text-xs text-slate-400">
          <span>Total Orders: <strong className="text-amber-400">{orders.length}</strong></span>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-900 p-3 rounded-2xl border border-slate-800">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search Order #, customer name, email..."
            className="w-full pl-9 pr-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-none"
          />
        </div>

        <select
          value={sourceFilter}
          onChange={(e) => setSourceFilter(e.target.value)}
          className="p-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:outline-none cursor-pointer"
        >
          <option value="All">All Channels (Web + Apps)</option>
          <option value="Website">Website</option>
          <option value="Android App">Android App</option>
          <option value="iOS App">iOS App</option>
        </select>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="p-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:outline-none cursor-pointer"
        >
          <option value="All">All Statuses</option>
          {statuses.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      {/* Orders Table */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase tracking-wider text-[10px] border-b border-slate-700">
              <tr>
                <th className="p-3.5">Order ID & Date</th>
                <th className="p-3.5">Source</th>
                <th className="p-3.5">Customer</th>
                <th className="p-3.5">Items</th>
                <th className="p-3.5">Total & Payment</th>
                <th className="p-3.5">Fulfillment Status</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredOrders.map((o) => {
                const isDelivered = o.status === 'Delivered';
                const isShipped = o.status === 'Shipped' || o.status === 'Out for delivery';

                return (
                  <tr key={o.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="p-3.5">
                      <p className="font-mono font-bold text-white text-xs">#{o.orderNumber}</p>
                      <p className="text-[10px] text-slate-400">
                        {new Date(o.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                      </p>
                    </td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-amber-300 border border-slate-700">
                        {o.source}
                      </span>
                    </td>
                    <td className="p-3.5">
                      <p className="font-bold text-white">{o.customerName}</p>
                      <p className="text-[10px] text-slate-400">{o.shippingAddress.city}, {o.shippingAddress.state}</p>
                    </td>
                    <td className="p-3.5">
                      <p className="font-bold text-slate-200">{o.items.length} items</p>
                      <p className="text-[10px] text-slate-400 truncate max-w-[140px]">
                        {o.items.map((i) => i.productName).join(', ')}
                      </p>
                    </td>
                    <td className="p-3.5">
                      <p className="font-mono font-bold text-white">₹{o.totalAmount.toLocaleString('en-IN')}</p>
                      <p className="text-[10px] text-slate-400">{o.paymentMethod} ({o.paymentStatus})</p>
                    </td>
                    <td className="p-3.5">
                      <select
                        value={o.status}
                        onChange={(e) => handleQuickStatusChange(o.id, e.target.value as OrderStatus)}
                        className={`p-1 rounded text-[11px] font-bold border focus:outline-none cursor-pointer ${
                          isDelivered
                            ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800'
                            : isShipped
                            ? 'bg-blue-950/60 text-blue-300 border-blue-800'
                            : 'bg-amber-950/60 text-amber-300 border-amber-800'
                        }`}
                      >
                        {statuses.map((s) => (
                          <option key={s} value={s} className="bg-slate-900 text-white">
                            {s}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className="p-3.5 text-right">
                      <button
                        onClick={() => {
                          setActiveOrderModal(o);
                          setNewStatus(o.status);
                          setCourier(o.courierName || 'Delhivery Express');
                          setTrackingNo(o.trackingNumber || `AWB-${Math.floor(100000 + Math.random() * 900000)}`);
                        }}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold rounded-lg text-[11px] inline-flex items-center gap-1"
                      >
                        <Eye className="w-3 h-3" />
                        <span>Fulfill</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Fulfillment Modal */}
      {activeOrderModal && (
        <div className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-lg rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-sm text-white">
                Fulfill Order #{activeOrderModal.orderNumber}
              </h3>
              <button onClick={() => setActiveOrderModal(null)}>
                <X className="w-4 h-4 text-slate-400 hover:text-white" />
              </button>
            </div>

            <form onSubmit={handleUpdateStatus} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Select Order Status</label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value as OrderStatus)}
                  className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-bold"
                >
                  {statuses.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Assigned Logistics Partner</label>
                <select
                  value={courier}
                  onChange={(e) => setCourier(e.target.value)}
                  className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                >
                  <option value="Delhivery Express">Delhivery Express</option>
                  <option value="Blue Dart Express Air">Blue Dart Express Air</option>
                  <option value="Shiprocket Direct">Shiprocket Direct</option>
                  <option value="Shadowfax Local">Shadowfax Local</option>
                  <option value="DTDC Premier">DTDC Premier</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">AWB Tracking Number</label>
                <input
                  type="text"
                  value={trackingNo}
                  onChange={(e) => setTrackingNo(e.target.value)}
                  className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono"
                />
              </div>

              <div className="flex gap-2 pt-2 border-t border-slate-800">
                <button
                  type="submit"
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold py-2.5 rounded-xl"
                >
                  Confirm Dispatch & Sync
                </button>
                <button
                  type="button"
                  onClick={() => setActiveOrderModal(null)}
                  className="px-4 bg-slate-800 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
