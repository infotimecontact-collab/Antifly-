import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
} from 'recharts';
import {
  TrendingUp,
  ShoppingBag,
  Users,
  CreditCard,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Smartphone,
  Globe,
  RotateCcw,
  CheckCircle,
  Truck,
  Bike,
  Coins,
} from 'lucide-react';

interface AdminDashboardProps {
  onNavigate: (tab: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate }) => {
  const {
    orders,
    products,
    customers,
    abandonedCarts,
    returns,
    sendAbandonedCartReminder,
    showToast,
  } = useApp();

  // Financial & Order KPIs
  const totalRevenue = orders.reduce((sum, o) => sum + o.totalAmount, 0);
  const totalOrders = orders.length;
  const averageOrderValue = totalOrders > 0 ? Math.round(totalRevenue / totalOrders) : 0;
  const activeCustomersCount = customers.length;

  // Omnichannel breakdown
  const websiteOrders = orders.filter((o) => o.source === 'Website').length;
  const androidOrders = orders.filter((o) => o.source === 'Android App').length;
  const iosOrders = orders.filter((o) => o.source === 'iOS App').length;

  const channelData = [
    { name: 'Website', value: websiteOrders || 1, color: '#f59e0b' },
    { name: 'Android App', value: androidOrders || 1, color: '#10b981' },
    { name: 'iOS App', value: iosOrders || 1, color: '#38bdf8' },
  ];

  // Daily revenue bar data (simulated 7 days)
  const revenueHistory = [
    { day: 'Mon', revenue: 42500, orders: 18 },
    { day: 'Tue', revenue: 58200, orders: 24 },
    { day: 'Wed', revenue: 64100, orders: 29 },
    { day: 'Thu', revenue: 51800, orders: 22 },
    { day: 'Fri', revenue: 89400, orders: 38 },
    { day: 'Sat', revenue: 112000, orders: 49 },
    { day: 'Sun', revenue: 98500, orders: 44 },
  ];

  // Low stock products (<40)
  const lowStockItems = products.filter((p) => p.totalStock < 40);

  const handleRemindCart = async (id: string, name: string) => {
    await sendAbandonedCartReminder(id);
    showToast(`Recovery voucher sent to ${name}`);
  };

  return (
    <div className="space-y-6 animate-fade-in text-slate-900">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            Omnichannel Executive Overview
          </h1>
          <p className="text-xs text-slate-500 mt-0.5 font-medium">
            Real-time multi-platform telemetry across Website, Android App & iOS App
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => onNavigate('driver-ledger')}
            className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-800 text-xs font-bold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
          >
            <Coins className="w-3.5 h-3.5" />
            <span>Buddy Incentive Ledger</span>
          </button>
          <button
            onClick={() => onNavigate('products')}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Bulk Upload Products</span>
          </button>
          <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            LIVE TELEMETRY ACTIVE
          </span>
        </div>
      </div>

      {/* 4 Core KPI Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Gross Revenue */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 space-y-2 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold">
            <span>Gross Revenue</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center font-bold">
              ₹
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 font-mono">
              ₹{totalRevenue.toLocaleString('en-IN')}
            </span>
            <span className="text-xs text-emerald-700 font-bold flex items-center gap-0.5">
              <TrendingUp className="w-3 h-3" /> +18.4%
            </span>
          </div>
          <p className="text-[11px] text-slate-400 font-medium">Across 3 active customer channels</p>
        </div>

        {/* Total Orders Placed */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 space-y-2 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold">
            <span>Total Orders</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 font-mono">
              {totalOrders}
            </span>
            <span className="text-xs text-emerald-700 font-bold flex items-center gap-0.5">
              <TrendingUp className="w-3 h-3" /> +12%
            </span>
          </div>
          <p className="text-[11px] text-slate-400 font-medium">Avg Delivery Time: 2.1 Days</p>
        </div>

        {/* Average Order Value (AOV) */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 space-y-2 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold">
            <span>Average Order Value</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 font-mono">
              ₹{averageOrderValue.toLocaleString('en-IN')}
            </span>
            <span className="text-xs text-emerald-700 font-bold">+8.2%</span>
          </div>
          <p className="text-[11px] text-slate-400 font-medium">Highest on Mobile App channels</p>
        </div>

        {/* Active Customer Patrons */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 space-y-2 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold">
            <span>Registered Patrons</span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 font-mono">
              {activeCustomersCount}
            </span>
            <span className="text-xs text-emerald-700 font-bold">+14.6%</span>
          </div>
          <p className="text-[11px] text-slate-400 font-medium">Repeat purchase rate: 64%</p>
        </div>
      </div>

      {/* Visual Charts: Omnichannel Sales & Channel Share */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 7-Day Revenue Trend */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-white border border-slate-200 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-slate-900">Daily Revenue & Order Volume</h3>
              <p className="text-[11px] text-slate-500">Past 7 days consolidated performance</p>
            </div>
            <span className="text-xs text-amber-700 font-bold font-mono">
              Weekly Total: ₹516,500
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revenueHistory} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="day" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} tickFormatter={(v) => `₹${v / 1000}k`} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#cbd5e1',
                    borderRadius: '12px',
                    fontSize: '12px',
                    color: '#0f172a',
                    boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                  }}
                  formatter={(val: any) => [`₹${Number(val).toLocaleString('en-IN')}`, 'Revenue']}
                />
                <Bar dataKey="revenue" fill="#f59e0b" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Omnichannel Channel Share Pie */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 space-y-4 flex flex-col justify-between shadow-xs">
          <div>
            <h3 className="font-bold text-sm text-slate-900">Sales Channel Share</h3>
            <p className="text-[11px] text-slate-500">Website vs Android vs iOS orders</p>
          </div>

          <div className="h-44 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={channelData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={70}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {channelData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#cbd5e1',
                    borderRadius: '8px',
                    fontSize: '11px',
                    color: '#0f172a',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-slate-700 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> Website
              </span>
              <span className="font-bold text-slate-900 font-mono">{websiteOrders} Orders</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-slate-700 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Android App
              </span>
              <span className="font-bold text-slate-900 font-mono">{androidOrders} Orders</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-slate-700 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-500" /> iOS App
              </span>
              <span className="font-bold text-slate-900 font-mono">{iosOrders} Orders</span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Row: Recent Orders + Abandoned Carts + Low Stock Alert */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Live Orders */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-white border border-slate-200 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-900">Recent Orders Stream</h3>
            <button
              onClick={() => onNavigate('orders')}
              className="text-xs text-amber-700 hover:underline font-bold flex items-center gap-1"
            >
              <span>Manage All</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="space-y-2.5">
            {orders.slice(0, 4).map((order) => (
              <div
                key={order.id}
                className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-bold font-mono text-[11px]">
                    #{order.orderNumber.slice(-4)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900">{order.customerName}</span>
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-slate-200 text-slate-700">
                        {order.source}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500">
                      {order.items.length} items &bull; {order.paymentMethod}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="font-mono font-bold text-slate-900 block">
                    ₹{order.totalAmount.toLocaleString('en-IN')}
                  </span>
                  <span
                    className={`text-[10px] font-bold ${
                      order.status === 'Delivered'
                        ? 'text-emerald-700'
                        : order.status === 'Shipped'
                        ? 'text-blue-700'
                        : 'text-amber-700'
                    }`}
                  >
                    ● {order.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Low Stock Urgent Alerts */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-rose-700">
              <AlertTriangle className="w-4 h-4" />
              <h3 className="font-bold text-sm text-slate-900">Stock Warnings</h3>
            </div>
            <button
              onClick={() => onNavigate('inventory')}
              className="text-xs text-amber-700 hover:underline font-bold"
            >
              Restock
            </button>
          </div>

          <div className="space-y-2.5">
            {lowStockItems.slice(0, 3).map((item) => (
              <div
                key={item.id}
                className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-3 text-xs"
              >
                <img
                  src={item.images[0]}
                  alt={item.name}
                  className="w-10 h-10 object-cover rounded-lg flex-shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-slate-900 truncate">{item.name}</p>
                  <p className="text-[11px] text-rose-700 font-medium">
                    Remaining: <strong>{item.totalStock} units</strong>
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Quick Abandoned Cart Recovery Widget */}
          <div className="pt-3 border-t border-slate-100 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-slate-700">Abandoned Carts ({abandonedCarts.length})</span>
              <button
                onClick={() => onNavigate('abandoned-carts')}
                className="text-amber-700 hover:underline text-[11px]"
              >
                View
              </button>
            </div>
            {abandonedCarts[0] && (
              <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1.5">
                <div className="flex justify-between font-bold text-slate-700">
                  <span>{abandonedCarts[0].customerName}</span>
                  <span className="font-mono text-amber-800">₹{abandonedCarts[0].cartValue}</span>
                </div>
                <button
                  onClick={() =>
                    handleRemindCart(abandonedCarts[0].id, abandonedCarts[0].customerName)
                  }
                  className="w-full bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold py-1.5 rounded-lg text-[10px] shadow-xs cursor-pointer"
                >
                  ⚡ Send 5% Nudge Reminder
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
