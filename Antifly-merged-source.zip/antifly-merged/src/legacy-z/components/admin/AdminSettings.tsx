import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StoreSettings } from '../../types';
import {
  Settings,
  Save,
  CheckCircle,
  Phone,
  Mail,
  MapPin,
  Truck,
  IndianRupee,
  CreditCard,
  Sparkles,
  ShieldCheck,
  Smartphone,
  Globe,
} from 'lucide-react';

export const AdminSettings: React.FC = () => {
  const { settings, updateSettings, showToast } = useApp();
  const [formData, setFormData] = useState<StoreSettings>(settings);
  const [isSaving, setIsSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    await updateSettings(formData);
    setIsSaving(false);
  };

  return (
    <div id="admin-settings-view" className="space-y-6 text-slate-900">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-slate-200 p-5 rounded-2xl shadow-xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Settings className="w-5 h-5 text-amber-600" />
            Store Architecture & Omnichannel Configuration
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure merchant business credentials, shipping logistics, payment switchboard, and AI models.
          </p>
        </div>

        <button
          form="store-settings-form"
          type="submit"
          disabled={isSaving}
          className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold px-5 py-2.5 rounded-xl text-xs flex items-center gap-2 transition shadow-xs cursor-pointer"
        >
          <Save className="w-4 h-4" />
          {isSaving ? 'Saving...' : 'Save Configuration'}
        </button>
      </div>

      <form id="store-settings-form" onSubmit={handleSubmit} className="space-y-6">
        {/* Business Credentials */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-3">
            <Globe className="w-4 h-4 text-amber-600" />
            Business & Merchant Profile
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Brand Name</label>
              <input
                type="text"
                required
                value={formData.storeName}
                onChange={(e) => setFormData({ ...formData, storeName: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 font-bold focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Official Support Phone</label>
              <div className="relative">
                <Phone className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={formData.contactPhone}
                  onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3.5 py-2 text-slate-900 font-medium focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Support Email</label>
              <div className="relative">
                <Mail className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={formData.contactEmail}
                  onChange={(e) => setFormData({ ...formData, contactEmail: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3.5 py-2 text-slate-900 font-medium focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>
          </div>

          <div className="text-xs">
            <label className="block text-slate-700 font-semibold mb-1">Registered Business Address</label>
            <div className="relative">
              <MapPin className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
              <textarea
                rows={2}
                value={formData.businessAddress}
                onChange={(e) => setFormData({ ...formData, businessAddress: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3.5 py-2 text-slate-900 font-medium focus:outline-none focus:border-amber-500 text-xs"
              />
            </div>
          </div>
        </div>

        {/* Shipping & GST Calculations */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-3">
            <Truck className="w-4 h-4 text-amber-600" />
            Shipping Logistics & Taxation
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Free Shipping Threshold (₹)</label>
              <input
                type="number"
                min="0"
                value={formData.freeShippingThreshold}
                onChange={(e) =>
                  setFormData({ ...formData, freeShippingThreshold: Number(e.target.value) })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 font-medium focus:outline-none focus:border-amber-500"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">Orders above this get free shipping</span>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Standard Shipping Fee (₹)</label>
              <input
                type="number"
                min="0"
                value={formData.standardShippingFee}
                onChange={(e) =>
                  setFormData({ ...formData, standardShippingFee: Number(e.target.value) })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 font-medium focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Express Shipping Fee (₹)</label>
              <input
                type="number"
                min="0"
                value={formData.expressShippingFee}
                onChange={(e) =>
                  setFormData({ ...formData, expressShippingFee: Number(e.target.value) })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 font-medium focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Apparel GST Rate (%)</label>
              <input
                type="number"
                min="0"
                value={formData.gstPercentage}
                onChange={(e) =>
                  setFormData({ ...formData, gstPercentage: Number(e.target.value) })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 font-medium focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>
        </div>

        {/* Payment Gateways Switchboard */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-3">
            <CreditCard className="w-4 h-4 text-amber-600" />
            Omnichannel Payment Gateway Switchboard
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-slate-900">UPI Instant Intent</div>
                <div className="text-[10px] text-slate-500">GPay, PhonePe, Paytm</div>
              </div>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, upiEnabled: !formData.upiEnabled })}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                  formData.upiEnabled
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-slate-200 text-slate-600'
                }`}
              >
                {formData.upiEnabled ? 'Enabled' : 'Disabled'}
              </button>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-slate-900">Cards & EMI</div>
                <div className="text-[10px] text-slate-500">Visa, Mastercard, RuPay</div>
              </div>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, cardsEnabled: !formData.cardsEnabled })}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                  formData.cardsEnabled
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-slate-200 text-slate-600'
                }`}
              >
                {formData.cardsEnabled ? 'Enabled' : 'Disabled'}
              </button>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-slate-900">Net Banking</div>
                <div className="text-[10px] text-slate-500">50+ Major Indian Banks</div>
              </div>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, netBankingEnabled: !formData.netBankingEnabled })}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                  formData.netBankingEnabled
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-slate-200 text-slate-600'
                }`}
              >
                {formData.netBankingEnabled ? 'Enabled' : 'Disabled'}
              </button>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-slate-900">Cash on Delivery (COD)</div>
                <div className="text-[10px] text-slate-500">Pay at Doorstep</div>
              </div>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, codEnabled: !formData.codEnabled })}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                  formData.codEnabled
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-slate-200 text-slate-600'
                }`}
              >
                {formData.codEnabled ? 'Enabled' : 'Disabled'}
              </button>
            </div>
          </div>
        </div>

        {/* AI & Automation Engine */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-600" />
                Antifly AI Smart Stylist & Search Engine
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Powers conversational fashion assistance, visual search matching, and smart size advisory.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setFormData({ ...formData, antiflyAiEnabled: !formData.antiflyAiEnabled })}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                formData.antiflyAiEnabled
                  ? 'bg-amber-500 text-slate-900 shadow-xs'
                  : 'bg-slate-100 text-slate-600'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              {formData.antiflyAiEnabled ? 'Antifly AI Active' : 'Antifly AI Paused'}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
