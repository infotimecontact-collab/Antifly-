import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Product } from '../../types';
import {
  Boxes,
  Search,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Plus,
  Minus,
  RefreshCw,
  Download,
  Filter,
  Layers,
  ArrowUpDown,
} from 'lucide-react';

export const AdminInventory: React.FC = () => {
  const { products, saveProduct, showToast } = useApp();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'low' | 'out'>('all');
  const [stockUpdates, setStockUpdates] = useState<Record<string, number>>({});

  // Flatten all variants for granular SKU inventory tracking
  const allVariants = products.flatMap((product) =>
    product.variants.map((v) => ({
      ...v,
      productId: product.id,
      productName: product.name,
      category: product.category,
      brand: product.brand,
    }))
  );

  const filteredVariants = allVariants.filter((variant) => {
    const matchesSearch =
      variant.productName.toLowerCase().includes(search.toLowerCase()) ||
      variant.sku.toLowerCase().includes(search.toLowerCase()) ||
      variant.color.toLowerCase().includes(search.toLowerCase()) ||
      variant.size.toLowerCase().includes(search.toLowerCase());
    if (!matchesSearch) return false;
    if (statusFilter === 'low') return variant.stock > 0 && variant.stock < 15;
    if (statusFilter === 'out') return variant.stock === 0;
    return true;
  });

  const handleStockAdjust = async (productId: string, variantId: string, delta: number) => {
    const product = products.find((p) => p.id === productId);
    if (!product) return;

    const updatedVariants = product.variants.map((v) =>
      v.id === variantId ? { ...v, stock: Math.max(0, v.stock + delta) } : v
    );
    const newTotalStock = updatedVariants.reduce((sum, v) => sum + v.stock, 0);

    await saveProduct({
      ...product,
      variants: updatedVariants,
      totalStock: newTotalStock,
    });
    showToast(`Inventory updated for SKU ${variantId}`);
  };

  const handleQuickRestockAllLow = async () => {
    for (const product of products) {
      let changed = false;
      const updatedVariants = product.variants.map((v) => {
        if (v.stock < 15) {
          changed = true;
          return { ...v, stock: v.stock + 25 };
        }
        return v;
      });
      if (changed) {
        const newTotal = updatedVariants.reduce((sum, v) => sum + v.stock, 0);
        await saveProduct({ ...product, variants: updatedVariants, totalStock: newTotal });
      }
    }
    showToast('Batch restocked +25 units for all low-stock variants');
  };

  const lowStockCount = allVariants.filter((v) => v.stock > 0 && v.stock < 15).length;
  const outOfStockCount = allVariants.filter((v) => v.stock === 0).length;
  const totalUnits = allVariants.reduce((sum, v) => sum + v.stock, 0);

  return (
    <div id="admin-inventory-view" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Boxes className="w-5 h-5 text-amber-400" />
            Inventory & Multi-Variant SKU Logistics
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time stock monitoring across warehouses, fulfillment centers, size grids, and colorways.
          </p>
        </div>

        <button
          onClick={handleQuickRestockAllLow}
          className="bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-2 transition shadow-lg shadow-amber-500/10"
        >
          <RefreshCw className="w-4 h-4" />
          Bulk Restock Low SKUs (+25 Units)
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="text-slate-400 text-xs font-medium">Total Live Inventory Units</div>
          <div className="text-2xl font-black text-white mt-1">{totalUnits.toLocaleString('en-IN')}</div>
          <div className="text-[11px] text-slate-400 mt-1">Across {allVariants.length} active variant SKUs</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="text-slate-400 text-xs font-medium">Low Stock Alerts (&lt; 15 units)</div>
          <div className="text-2xl font-black text-amber-400 mt-1">{lowStockCount}</div>
          <div className="text-[11px] text-amber-300/80 mt-1 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3 text-amber-400" /> Reorder threshold reached
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="text-slate-400 text-xs font-medium">Out of Stock Variants</div>
          <div className="text-2xl font-black text-rose-400 mt-1">{outOfStockCount}</div>
          <div className="text-[11px] text-rose-300/80 mt-1 flex items-center gap-1">
            <XCircle className="w-3 h-3 text-rose-400" /> Customer order risk
          </div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search SKU, product name, color, size..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs w-full sm:w-auto overflow-x-auto">
          {(['all', 'low', 'out'] as const).map((filter) => (
            <button
              key={filter}
              onClick={() => setStatusFilter(filter)}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition ${
                statusFilter === filter
                  ? 'bg-amber-500 text-slate-800 font-bold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {filter === 'all' && 'All SKU Variants'}
              {filter === 'low' && `Low Stock (${lowStockCount})`}
              {filter === 'out' && `Out of Stock (${outOfStockCount})`}
            </button>
          ))}
        </div>
      </div>

      {/* SKU Inventory Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-white/70 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="py-3.5 px-4">SKU / Code</th>
                <th className="py-3.5 px-4">Product Name</th>
                <th className="py-3.5 px-4">Colorway & Size</th>
                <th className="py-3.5 px-4">Unit Price</th>
                <th className="py-3.5 px-4">Live Stock</th>
                <th className="py-3.5 px-4">Health Status</th>
                <th className="py-3.5 px-4 text-right">Quick Stock Adjustment</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredVariants.map((v) => (
                <tr key={v.id} className="hover:bg-slate-800/30 transition">
                  <td className="py-3.5 px-4 font-mono font-bold text-amber-400">
                    {v.sku}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-white truncate max-w-xs">{v.productName}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">{v.category} • {v.brand}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2">
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-slate-700 inline-block"
                        style={{ backgroundColor: v.colorHex }}
                      />
                      <span className="text-slate-300 font-medium">{v.color}</span>
                      <span className="px-2 py-0.5 bg-slate-800 rounded text-[10px] font-bold text-white">
                        {v.size}
                      </span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-white">
                    ₹{v.price} <span className="text-slate-500 line-through text-[10px]">₹{v.mrp}</span>
                  </td>
                  <td className="py-3.5 px-4 font-extrabold text-white text-sm">
                    {v.stock}
                  </td>
                  <td className="py-3.5 px-4">
                    {v.stock === 0 ? (
                      <span className="px-2.5 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-bold inline-flex items-center gap-1">
                        <XCircle className="w-3 h-3" /> Out of Stock
                      </span>
                    ) : v.stock < 15 ? (
                      <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold inline-flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" /> Low Stock
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold inline-flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" /> Optimal
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleStockAdjust(v.productId, v.id, -5)}
                        className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold transition"
                        title="Reduce 5 units"
                      >
                        -5
                      </button>
                      <button
                        onClick={() => handleStockAdjust(v.productId, v.id, 10)}
                        className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 rounded-lg text-xs font-bold transition"
                        title="Add 10 units"
                      >
                        +10
                      </button>
                      <button
                        onClick={() => handleStockAdjust(v.productId, v.id, 50)}
                        className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-800 rounded-lg text-xs font-bold transition shadow-sm"
                        title="Add 50 units"
                      >
                        +50
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
