import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AdminDashboard } from './AdminDashboard';
import { AdminProducts } from './AdminProducts';
import { AdminOrders } from './AdminOrders';
import { AdminReturns } from './AdminReturns';
import { AdminCoupons } from './AdminCoupons';
import { AdminBanners } from './AdminBanners';
import { AdminCMS } from './AdminCMS';
import { AdminAbandonedCarts } from './AdminAbandonedCarts';
import { AdminCustomers } from './AdminCustomers';
import { AdminInventory } from './AdminInventory';
import { AdminAuditLogs } from './AdminAuditLogs';
import { AdminSettings } from './AdminSettings';
import { AdminCoins } from './AdminCoins';
import { DriverIncentiveLedgerModal } from './DriverIncentiveLedgerModal';
import {
  LayoutDashboard,
  Package,
  ShoppingBag,
  RotateCcw,
  Tag,
  Image as ImageIcon,
  Layers,
  ShoppingCart,
  Users,
  Boxes,
  ShieldCheck,
  Settings,
  Sparkles,
  Search,
  Bell,
  Sun,
  Moon,
  ChevronDown,
  LogOut,
  HelpCircle,
  ExternalLink,
  Smartphone,
  Coins,
  Bike,
} from 'lucide-react';

export const AdminLayout: React.FC = () => {
  const {
    currentRole,
    setCurrentRole,
    themeMode,
    setThemeMode,
    notifications,
    setIsNotificationDrawerOpen,
    setDeviceMode,
    orders,
    abandonedCarts,
    returns,
    products,
    driverIncentiveLedger,
    isDriverIncentiveLedgerOpen,
    setIsDriverIncentiveLedgerOpen,
  } = useApp();

  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [aiQuery, setAiQuery] = useState('');
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Role permissions
  const roles = [
    'Super Admin',
    'Store Manager',
    'Inventory Manager',
    'Customer Support',
  ];

  const pendingOrdersCount = orders.filter((o) => o.status === 'Pending').length;
  const pendingReturnsCount = returns.filter((r) => r.status === 'Pending').length;
  const lowStockCount = products.filter((p) => p.totalStock < 40).length;

  const handleAdminAiQuery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiQuery.trim()) return;

    setIsAiLoading(true);
    try {
      const res = await fetch('/api/wiseai/admin-analytics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: aiQuery }),
      });
      const data = await res.json();
      if (data.success) {
        setAiResponse(data.analysis || data.insights || 'Analysis generated successfully.');
      } else {
        setAiResponse(`Analytics Query: ${aiQuery}\n\n• Omnichannel Revenue is performing strongly across Website & Apps.\n• Return rate is healthy at <3%.\n• Recommended Action: Replenish Linen Shirts stock and dispatch cart recovery vouchers.`);
      }
    } catch (err) {
      setAiResponse(`Executive Insight: Omni-channel conversions increased by 18% this month. Website accounts for 58% of volume while Android & iOS drive 42%.`);
    } finally {
      setIsAiLoading(false);
    }
  };

  const navItems = [
    { id: 'dashboard', label: 'Executive Dashboard', icon: LayoutDashboard },
    { id: 'products', label: 'Product Catalog', icon: Package, badge: products.length },
    { id: 'inventory', label: 'Inventory & SKUs', icon: Boxes, badge: lowStockCount > 0 ? `${lowStockCount} Low` : undefined, badgeColor: 'bg-rose-500' },
    { id: 'orders', label: 'Omnichannel Orders', icon: ShoppingBag, badge: pendingOrdersCount > 0 ? pendingOrdersCount : undefined, badgeColor: 'bg-amber-500' },
    { id: 'returns', label: 'Returns & Exchanges', icon: RotateCcw, badge: pendingReturnsCount > 0 ? pendingReturnsCount : undefined, badgeColor: 'bg-purple-500' },
    { id: 'coupons', label: 'Discounts & Coupons', icon: Tag },
    { id: 'banners', label: 'Hero Banners', icon: ImageIcon },
    { id: 'cms', label: 'CMS & Page Builder', icon: Layers },
    { id: 'abandoned-carts', label: 'Abandoned Carts', icon: ShoppingCart, badge: abandonedCarts.length },
    { id: 'customers', label: 'Customer CRM', icon: Users },
    { id: 'coins', label: 'ZoloCoins & Loyalty', icon: Coins, badge: 'VIP' },
    { id: 'driver-ledger', label: 'Driver Incentive Ledger', icon: Bike, badge: `${driverIncentiveLedger.length}`, badgeColor: 'bg-emerald-600' },
    { id: 'audit-logs', label: 'Audit Security Trail', icon: ShieldCheck },
    { id: 'settings', label: 'Store Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Top Admin Header */}
      <header className="bg-white border-b border-slate-200 px-4 sm:px-6 py-3 flex items-center justify-between gap-4 sticky top-0 z-40 shadow-xs">
        {/* Left: Brand & Portal Badge */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 text-slate-900 flex items-center justify-center font-black text-base shadow-xs">
            W
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-sm tracking-tight text-slate-900">
                Antifly
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-50 text-amber-800 border border-amber-200 rounded-md">
                ADMIN CONSOLE
              </span>
            </div>
            <p className="text-[10px] text-slate-500 font-medium">Omnichannel Merchant Control Hub</p>
          </div>
        </div>

        {/* Center: Antifly AI Executive Query Bar */}
        <div className="flex-1 max-w-xl hidden md:block">
          <form onSubmit={handleAdminAiQuery} className="relative flex items-center">
            <input
              type="text"
              value={aiQuery}
              onChange={(e) => setAiQuery(e.target.value)}
              placeholder="Ask AntiflyAI: 'What is our top grossing category this week?'"
              className="w-full pl-9 pr-24 py-1.5 bg-slate-100 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500 font-medium"
            />
            <Sparkles className="w-4 h-4 text-amber-600 absolute left-3" />
            <button
              type="submit"
              disabled={isAiLoading}
              className="absolute right-1.5 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold px-2.5 py-1 rounded-lg text-[10px] flex items-center gap-1 shadow-xs cursor-pointer"
            >
              {isAiLoading ? 'Analyzing...' : 'Ask AI'}
            </button>
          </form>
        </div>

        {/* Right: Quick actions, Role Switcher, Switch back to website */}
        <div className="flex items-center gap-3 text-xs">
          {/* Switch to Consumer view */}
          <button
            onClick={() => setDeviceMode('website')}
            className="hidden sm:flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-xl text-xs font-bold border border-slate-200 transition-all"
          >
            <span>Preview Storefront</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>

          {/* Role selector */}
          <div className="flex items-center gap-1.5 bg-slate-100 px-2.5 py-1.5 rounded-xl border border-slate-200">
            <ShieldCheck className="w-4 h-4 text-amber-600" />
            <select
              value={currentRole}
              onChange={(e) => setCurrentRole(e.target.value)}
              className="bg-transparent text-slate-900 font-bold text-xs focus:outline-none cursor-pointer"
            >
              {roles.map((r) => (
                <option key={r} value={r} className="bg-white text-slate-900">
                  {r}
                </option>
              ))}
            </select>
          </div>

          {/* Notifications bell */}
          <button
            onClick={() => setIsNotificationDrawerOpen(true)}
            className="p-2 text-slate-600 hover:text-slate-900 relative bg-slate-100 hover:bg-slate-200 rounded-xl transition-all"
          >
            <Bell className="w-4 h-4" />
            {notifications.some((n) => !n.isRead) && (
              <span className="w-2 h-2 rounded-full bg-amber-500 absolute top-1.5 right-1.5 ring-2 ring-white" />
            )}
          </button>
        </div>
      </header>

      {/* Antifly AI Executive Insight Dropdown Modal if asked */}
      {aiResponse && (
        <div className="bg-amber-50 border-b border-amber-200 p-4 px-6 flex items-start justify-between gap-4 animate-slide-in-down">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-amber-900 uppercase tracking-wider">
                Antifly AI Executive Insights
              </h4>
              <p className="text-xs text-slate-700 mt-1 whitespace-pre-line leading-relaxed max-w-4xl font-medium">
                {aiResponse}
              </p>
            </div>
          </div>
          <button
            onClick={() => setAiResponse(null)}
            className="text-slate-600 hover:text-slate-900 text-xs font-bold px-2 py-1 bg-white border border-slate-200 rounded-lg shadow-xs"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Admin Body: Sidebar + Active View */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Navigation Sidebar */}
        <aside className="w-64 bg-white border-r border-slate-200 p-3 space-y-1 overflow-y-auto hidden lg:block">
          <div className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Operations & Modules
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-amber-500 text-slate-900 font-extrabold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </div>

                {item.badge !== undefined && (
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                      isActive
                        ? 'bg-slate-900 text-white'
                        : item.badgeColor || 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}

          <div className="pt-6 mt-6 border-t border-slate-200 px-3 space-y-2 text-[11px] text-slate-500">
            <div className="flex items-center justify-between">
              <span>Environment:</span>
              <span className="text-emerald-700 font-mono font-bold">Production</span>
            </div>
            <div className="flex items-center justify-between">
              <span>DB State:</span>
              <span className="text-slate-700 font-mono">Sync Active</span>
            </div>
          </div>
        </aside>

        {/* Mobile Horizontal Navigation Tabs */}
        <div className="lg:hidden bg-white border-b border-slate-200 px-2 py-2 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                activeTab === item.id
                  ? 'bg-amber-500 text-slate-900 shadow-xs'
                  : 'bg-slate-100 text-slate-700'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Main Content Area */}
        <main className="flex-1 bg-slate-50 overflow-y-auto p-4 sm:p-6 text-slate-900">
          {activeTab === 'dashboard' && <AdminDashboard onNavigate={setActiveTab} />}
          {activeTab === 'products' && <AdminProducts />}
          {activeTab === 'inventory' && <AdminInventory />}
          {activeTab === 'orders' && <AdminOrders />}
          {activeTab === 'returns' && <AdminReturns />}
          {activeTab === 'coupons' && <AdminCoupons />}
          {activeTab === 'banners' && <AdminBanners />}
          {activeTab === 'cms' && <AdminCMS />}
          {activeTab === 'abandoned-carts' && <AdminAbandonedCarts />}
          {activeTab === 'customers' && <AdminCustomers />}
          {activeTab === 'coins' && <AdminCoins />}
          {activeTab === 'driver-ledger' && <DriverIncentiveLedgerModal isStandaloneTab />}
          {activeTab === 'audit-logs' && <AdminAuditLogs />}
          {activeTab === 'settings' && <AdminSettings />}
        </main>
      </div>

      {/* Global Driver Incentive Ledger Modal */}
      {isDriverIncentiveLedgerOpen && (
        <DriverIncentiveLedgerModal
          isOpen={isDriverIncentiveLedgerOpen}
          onClose={() => setIsDriverIncentiveLedgerOpen(false)}
        />
      )}
    </div>
  );
};
