import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Coins,
  Crown,
  Sparkles,
  Gift,
  Plus,
  Trash2,
  Edit3,
  CheckCircle2,
  TrendingUp,
  Users,
  Flame,
  ShieldCheck,
  DollarSign,
  Search,
  ArrowUpRight,
  ArrowDownRight,
  Percent,
  Settings2,
  Save,
  Zap,
  Tag,
  Clock,
  Award,
  RefreshCw,
} from 'lucide-react';
import { SuperCoinReward } from '../../types';

export const AdminCoins: React.FC = () => {
  const {
    superCoinsBalance,
    superCoinRewards,
    superCoinTransactions,
    customers,
    orders,
    formatPrice,
    showToast,
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'rewards' | 'transactions' | 'rules'>('overview');
  const [searchTx, setSearchTx] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'Earned' | 'Spent'>('all');

  // Manual Grant Modal / Form State
  const [selectedCustomerForCoins, setSelectedCustomerForCoins] = useState(customers[0]?.id || '');
  const [coinGrantAmount, setCoinGrantAmount] = useState<number>(100);
  const [coinGrantType, setCoinGrantType] = useState<'Earned' | 'Spent'>('Earned');
  const [coinGrantReason, setCoinGrantReason] = useState('Super Admin Festival Loyalty Bonus');
  const [isGranting, setIsGranting] = useState(false);

  // Rewards Management State
  const [rewardsList, setRewardsList] = useState<SuperCoinReward[]>(superCoinRewards);
  const [isAddingReward, setIsAddingReward] = useState(false);
  const [newRewardTitle, setNewRewardTitle] = useState('');
  const [newRewardDesc, setNewRewardDesc] = useState('');
  const [newRewardCost, setNewRewardCost] = useState(150);
  const [newRewardValue, setNewRewardValue] = useState(500);
  const [newRewardCategory, setNewRewardCategory] = useState<'Discount' | 'OTT' | 'Travel' | 'GiftCard' | 'Dining'>('Discount');
  const [newRewardBrand, setNewRewardBrand] = useState('Antifly Exclusive');
  const [newRewardBadge, setNewRewardBadge] = useState('FLAT ₹500 OFF');
  const [newRewardImage, setNewRewardImage] = useState('https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=500&auto=format&fit=crop&q=80');

  // Loyalty Rules Config State
  const [earnRate, setEarnRate] = useState<number>(4); // 4 coins per 100 spent
  const [vipMultiplier, setVipMultiplier] = useState<number>(2); // 2x for VIP
  const [coinValueInr, setCoinValueInr] = useState<number>(1); // 1 Coin = ₹1
  const [maxCheckoutRedeemPercent, setMaxCheckoutRedeemPercent] = useState<number>(100); // 100% redemption
  const [expiryDays, setExpiryDays] = useState<number>(365); // 1 Year

  // Stats calculation
  const totalCoinsEarnedAllTime = superCoinTransactions
    .filter((t) => t.type === 'Earned')
    .reduce((acc, t) => acc + t.amount, 0);
  const totalCoinsSpentAllTime = superCoinTransactions
    .filter((t) => t.type === 'Spent')
    .reduce((acc, t) => acc + t.amount, 0);
  const totalLiabilityInr = (superCoinsBalance + 4520) * coinValueInr;

  const handleManualGrant = (e: React.FormEvent) => {
    e.preventDefault();
    if (coinGrantAmount <= 0) {
      showToast('Please enter a valid coin amount');
      return;
    }
    setIsGranting(true);
    setTimeout(() => {
      const targetCustomer = customers.find((c) => c.id === selectedCustomerForCoins) || customers[0];
      showToast(
        `🪙 Successfully ${coinGrantType === 'Earned' ? 'credited' : 'debited'} ${coinGrantAmount} ZoloCoins for ${targetCustomer?.name || 'Customer'}.`
      );
      setIsGranting(false);
      setCoinGrantAmount(100);
    }, 400);
  };

  const handleCreateReward = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRewardTitle.trim()) {
      showToast('Please enter reward title');
      return;
    }

    const created: SuperCoinReward = {
      id: `scr-${Date.now()}`,
      title: newRewardTitle,
      description: newRewardDesc || 'Redeemable on Antifly ecosystem partner outlets.',
      coinsCost: newRewardCost,
      monetaryValue: newRewardValue,
      category: newRewardCategory,
      badge: newRewardBadge,
      partnerBrand: newRewardBrand,
      imageUrl: newRewardImage,
      expiresInDays: 30,
    };

    setRewardsList([created, ...rewardsList]);
    setIsAddingReward(false);
    setNewRewardTitle('');
    setNewRewardDesc('');
    showToast(`🎉 Partner reward voucher "${created.title}" listed successfully!`);
  };

  const handleDeleteReward = (id: string) => {
    setRewardsList(rewardsList.filter((r) => r.id !== id));
    showToast('Reward voucher removed from catalog.');
  };

  const filteredTransactions = superCoinTransactions.filter((tx) => {
    const matchesSearch =
      tx.description.toLowerCase().includes(searchTx.toLowerCase()) ||
      tx.id.toLowerCase().includes(searchTx.toLowerCase());
    if (!matchesSearch) return false;
    if (filterType === 'all') return true;
    return tx.type === filterType;
  });

  return (
    <div id="admin-coins-management" className="space-y-6">
      {/* Top Banner / Header */}
      <div className="bg-gradient-to-r from-slate-900 via-amber-950/40 to-slate-900 border border-amber-500/30 p-6 rounded-2xl shadow-lg relative overflow-hidden">
        <div className="absolute right-4 top-1/2 -translate-y-1/2 opacity-10 pointer-events-none hidden md:block">
          <Coins className="w-48 h-48 text-amber-400" />
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-wider bg-amber-500 text-slate-800 px-2 py-0.5 rounded-full">
                👑 Super Admin & Loyalty Engine
              </span>
              <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Live Real-Time Ledger
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white mt-1.5 flex items-center gap-2">
              <Coins className="w-6 h-6 text-amber-400 fill-amber-400/20" />
              ZoloCoins & VIP Loyalty Administration
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Control cashback earn rules, issue promotional coin grants to customers, manage 100% partner voucher catalog, and monitor real-time treasury liability.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-white/80 border border-amber-500/30 px-4 py-2 rounded-xl text-right">
              <span className="text-[10px] text-amber-400 uppercase font-bold block">Active User Balance</span>
              <div className="text-xl font-black text-white font-mono flex items-center justify-end gap-1.5 mt-0.5">
                <Coins className="w-4 h-4 text-amber-400 fill-amber-400" />
                <span>{superCoinsBalance}</span>
                <span className="text-xs text-slate-400 font-sans">Coins</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Metric Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Coins in Circulation</span>
            <Coins className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-2">
            {(superCoinsBalance + 14820).toLocaleString()}
          </div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1 flex items-center gap-1 font-semibold">
            <ArrowUpRight className="w-3.5 h-3.5" /> +12.8% active shopper engagement
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Coin Treasury Liability</span>
            <DollarSign className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-black text-amber-600 dark:text-amber-400 mt-2">
            ₹{totalLiabilityInr.toLocaleString('en-IN')}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Backing: 1 ZoloCoin = ₹{coinValueInr}.00 INR
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Total Cashback Issued</span>
            <Award className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-2xl font-black text-purple-600 dark:text-purple-400 mt-2">
            {totalCoinsEarnedAllTime.toLocaleString()} Coins
          </div>
          <div className="text-[11px] text-purple-500 mt-1 font-medium">
            Across orders, food & referral streaks
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Burn / Redemption Rate</span>
            <Zap className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-2">
            {totalCoinsSpentAllTime.toLocaleString()} Coins
          </div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1 font-semibold">
            94.2% vouchers claimed successfully
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3 overflow-x-auto">
        {[
          { id: 'overview', label: 'Treasury & Customer Grants', icon: Users },
          { id: 'rewards', label: `Reward Vouchers Catalog (${rewardsList.length})`, icon: Gift },
          { id: 'transactions', label: `Real-Time Passbook Ledger (${superCoinTransactions.length})`, icon: Clock },
          { id: 'rules', label: 'Loyalty & VIP Multiplier Rules', icon: Settings2 },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-amber-500 text-slate-800 shadow-xs font-bold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* SUBTAB 1: TREASURY & CUSTOMER GRANTS */}
      {activeSubTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Manual Coin Grant Form (Left 5 Cols) */}
          <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  Issue Customer Coin Grant
                </h3>
                <p className="text-xs text-slate-500">Credit or debit ZoloCoins for any registered user.</p>
              </div>
              <span className="px-2 py-0.5 bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-[10px] font-bold rounded-md">
                Admin Action
              </span>
            </div>

            <form onSubmit={handleManualGrant} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                  Select Recipient Customer:
                </label>
                <select
                  value={selectedCustomerForCoins}
                  onChange={(e) => setSelectedCustomerForCoins(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                >
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.email}) - {c.tags.join(', ') || 'Customer'}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                    Action Type:
                  </label>
                  <select
                    value={coinGrantType}
                    onChange={(e) => setCoinGrantType(e.target.value as any)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-none"
                  >
                    <option value="Earned">Credit (+) Bonus Coins</option>
                    <option value="Spent">Debit (-) Penalty/Adjustment</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                    Coin Amount:
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={coinGrantAmount}
                    onChange={(e) => setCoinGrantAmount(Number(e.target.value))}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                  Reason / Audit Log Note:
                </label>
                <input
                  type="text"
                  value={coinGrantReason}
                  onChange={(e) => setCoinGrantReason(e.target.value)}
                  placeholder="e.g. Compensation for delivery delay / Festive bonus"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-[11px] text-slate-500">
                  Equivalent Value: <strong className="text-amber-500">₹{coinGrantAmount * coinValueInr}</strong>
                </span>
                <button
                  type="submit"
                  disabled={isGranting}
                  className="bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 transition shadow-sm"
                >
                  <Zap className="w-4 h-4" />
                  <span>{isGranting ? 'Dispatching...' : 'Dispatch Coins'}</span>
                </button>
              </div>
            </form>
          </div>

          {/* Quick Customers Coins Leaderboard (Right 7 Cols) */}
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2 mb-3">
              <Crown className="w-4 h-4 text-amber-500" />
              Top Loyalty Customers & VIP Segments
            </h3>

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {customers.slice(0, 5).map((cust, idx) => (
                <div key={cust.id} className="py-3 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 font-bold flex items-center justify-center text-xs">
                      #{idx + 1}
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white">{cust.name}</p>
                      <p className="text-[11px] text-slate-500">{cust.email} &bull; {cust.totalOrders} Orders</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="font-black text-amber-500 font-mono text-sm block">
                      {520 - idx * 60} Coins
                    </span>
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">
                      ZoloPlus VIP Active
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: REWARD VOUCHERS CATALOG */}
      {activeSubTab === 'rewards' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Partner Brand Reward Vouchers</h3>
              <p className="text-xs text-slate-500">Users can redeem these vouchers in ZoloCoins Hub using their accumulated coin balance.</p>
            </div>

            <button
              onClick={() => setIsAddingReward(!isAddingReward)}
              className="bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 transition shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>{isAddingReward ? 'Cancel' : 'Create New Partner Voucher'}</span>
            </button>
          </div>

          {/* New Reward Form Modal / Expandable */}
          {isAddingReward && (
            <div className="bg-amber-50/60 dark:bg-slate-900 border border-amber-300 dark:border-amber-500/40 p-5 rounded-2xl space-y-4">
              <h4 className="font-bold text-xs uppercase tracking-wider text-amber-900 dark:text-amber-300 flex items-center gap-2">
                <Gift className="w-4 h-4" /> Create Brand Reward Voucher
              </h4>

              <form onSubmit={handleCreateReward} className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Voucher Title *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. ₹500 Domino's Pizza E-Voucher"
                    value={newRewardTitle}
                    onChange={(e) => setNewRewardTitle(e.target.value)}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Partner Brand Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Domino's / Hotstar / Uber"
                    value={newRewardBrand}
                    onChange={(e) => setNewRewardBrand(e.target.value)}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Category</label>
                  <select
                    value={newRewardCategory}
                    onChange={(e) => setNewRewardCategory(e.target.value as any)}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white"
                  >
                    <option value="Discount">Discount Coupon</option>
                    <option value="OTT">OTT Streaming</option>
                    <option value="Travel">Flight & Travel</option>
                    <option value="Dining">Food & Dining</option>
                    <option value="GiftCard">Shopping Gift Card</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Coins Cost (To Redeem)</label>
                  <input
                    type="number"
                    min={10}
                    value={newRewardCost}
                    onChange={(e) => setNewRewardCost(Number(e.target.value))}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Real Monetary Value (₹)</label>
                  <input
                    type="number"
                    min={50}
                    value={newRewardValue}
                    onChange={(e) => setNewRewardValue(Number(e.target.value))}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Badge Tag</label>
                  <input
                    type="text"
                    value={newRewardBadge}
                    onChange={(e) => setNewRewardBadge(e.target.value)}
                    placeholder="e.g. 100% OFF / FREE PASS"
                    className="w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Description</label>
                  <input
                    type="text"
                    value={newRewardDesc}
                    onChange={(e) => setNewRewardDesc(e.target.value)}
                    placeholder="Valid on online and in-store orders above ₹1,000"
                    className="w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Image URL</label>
                  <input
                    type="text"
                    value={newRewardImage}
                    onChange={(e) => setNewRewardImage(e.target.value)}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white"
                  />
                </div>

                <div className="sm:col-span-3 flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsAddingReward(false)}
                    className="px-4 py-2 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-600 dark:text-slate-300 font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold rounded-xl shadow-xs"
                  >
                    Publish Reward Voucher
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Grid of Existing Rewards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {rewardsList.map((reward) => (
              <div
                key={reward.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center gap-3">
                    <img
                      src={reward.imageUrl}
                      alt={reward.title}
                      className="w-14 h-14 rounded-xl object-cover border border-slate-200 dark:border-slate-800 shrink-0"
                    />
                    <div>
                      <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300">
                        {reward.badge}
                      </span>
                      <h4 className="font-bold text-xs text-slate-900 dark:text-white mt-1 line-clamp-1">
                        {reward.title}
                      </h4>
                      <p className="text-[11px] text-slate-500 font-medium">{reward.partnerBrand}</p>
                    </div>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-2.5 line-clamp-2">
                    {reward.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 mt-3 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1 font-bold text-amber-600 dark:text-amber-400 font-mono">
                    <Coins className="w-4 h-4 fill-amber-400" />
                    <span>{reward.coinsCost} Coins</span>
                    <span className="text-slate-400 font-normal line-through text-[11px]">₹{reward.monetaryValue}</span>
                  </div>

                  <button
                    onClick={() => handleDeleteReward(reward.id)}
                    className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition"
                    title="Delete Reward"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUBTAB 3: REAL-TIME PASSBOOK LEDGER */}
      {activeSubTab === 'transactions' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs space-y-4 p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search ledger by reason, order ID..."
                value={searchTx}
                onChange={(e) => setSearchTx(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-900 dark:text-white focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-semibold">
              {(['all', 'Earned', 'Spent'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setFilterType(t)}
                  className={`px-3 py-1 rounded-lg transition ${
                    filterType === t
                      ? 'bg-amber-500 text-slate-800 font-bold shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {t === 'all' ? 'All Ledger' : t === 'Earned' ? 'Credits (+)' : 'Debits (-)'}
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-white text-slate-500 uppercase tracking-wider font-semibold border-y border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4">Transaction ID</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4">Description / Event</th>
                  <th className="py-3 px-4">Amount</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredTransactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition">
                    <td className="py-3 px-4 font-mono font-semibold text-slate-700 dark:text-slate-300">
                      {tx.id}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold inline-flex items-center gap-1 ${
                          tx.type === 'Earned'
                            ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                            : 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300'
                        }`}
                      >
                        {tx.type === 'Earned' ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                        {tx.type}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-900 dark:text-white">
                      {tx.description}
                    </td>
                    <td className="py-3 px-4 font-black font-mono">
                      <span
                        className={tx.type === 'Earned' ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}
                      >
                        {tx.type === 'Earned' ? '+' : '-'}{tx.amount} Coins
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-500 font-medium">
                      {tx.date}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded">
                        Settled
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUBTAB 4: RULES & MULTIPLIER SETTINGS */}
      {activeSubTab === 'rules' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-2xl shadow-xs space-y-6">
          <div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
              <Settings2 className="w-5 h-5 text-amber-500" />
              Global Loyalty & Cashback Math Parameters
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Tune coin earning formulas, VIP multiplier factors, and maximum cart redemption limits.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
              <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                Base Earn Rate (Coins per ₹100 spent)
              </label>
              <input
                type="number"
                min={1}
                max={20}
                value={earnRate}
                onChange={(e) => setEarnRate(Number(e.target.value))}
                className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg p-2 font-mono font-bold text-sm text-slate-900 dark:text-white"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">Standard customers earn {earnRate} coins per ₹100.</span>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
              <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                ZoloPlus VIP Multiplier Factor
              </label>
              <input
                type="number"
                min={1}
                max={5}
                value={vipMultiplier}
                onChange={(e) => setVipMultiplier(Number(e.target.value))}
                className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg p-2 font-mono font-bold text-sm text-slate-900 dark:text-white"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">VIP members earn {earnRate * vipMultiplier} coins per ₹100 ({vipMultiplier}X).</span>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
              <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                Max Checkout Discount (%)
              </label>
              <input
                type="number"
                min={10}
                max={100}
                value={maxCheckoutRedeemPercent}
                onChange={(e) => setMaxCheckoutRedeemPercent(Number(e.target.value))}
                className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg p-2 font-mono font-bold text-sm text-slate-900 dark:text-white"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">Allow up to {maxCheckoutRedeemPercent}% of cart to be paid via coins.</span>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
              <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                Coin Expiration Period (Days)
              </label>
              <input
                type="number"
                min={30}
                max={730}
                value={expiryDays}
                onChange={(e) => setExpiryDays(Number(e.target.value))}
                className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg p-2 font-mono font-bold text-sm text-slate-900 dark:text-white"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">Unused coins expire automatically after {expiryDays} days.</span>
            </div>
          </div>

          <div className="flex justify-end pt-3">
            <button
              onClick={() => showToast('✅ ZoloCoins loyalty rules & math parameters updated globally.')}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 shadow-md"
            >
              <Save className="w-4 h-4" />
              <span>Save Global Loyalty Rules</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
