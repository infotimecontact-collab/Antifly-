import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  BookOpen,
  Camera,
  Mic,
  Smile,
  Sparkles,
  Lock,
  Globe,
  Users,
  Radio,
  Plus,
  Send,
  Calendar,
  Tag,
  Share2,
  Trash2,
  Heart,
  Eye,
  Volume2,
} from 'lucide-react';

interface JournalEntry {
  id: string;
  title: string;
  content: string;
  mood: 'energized' | 'calm' | 'creative' | 'focused' | 'celebratory';
  moodEmoji: string;
  visibility: 'private' | 'circles' | 'public';
  date: string;
  voiceNoteDuration?: string;
  tags: string[];
  photoUrl?: string;
  aiReflection?: string;
}

export const LifeOSJournalView: React.FC = () => {
  const { showToast, setIsTimeShiftCameraOpen } = useApp();

  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [selectedMood, setSelectedMood] = useState<{ mood: JournalEntry['mood']; emoji: string }>({
    mood: 'creative',
    emoji: '🌸',
  });
  const [visibility, setVisibility] = useState<JournalEntry['visibility']>('private');
  const [tags, setTags] = useState('Mindfulness, Crafts, Growth');
  const [isRecording, setIsRecording] = useState(false);

  const [entries, setEntries] = useState<JournalEntry[]>([
    {
      id: 'j-1',
      title: 'Discovered a traditional brass artisan in Begumpet',
      content:
        'Walked through the old craft streets and met an artisan creating handmade diya oil lamps. Placed a custom order for Diwali. Feeling deeply inspired by the heritage techniques.',
      mood: 'creative',
      moodEmoji: '🌸',
      visibility: 'private',
      date: 'Today • 11:15 AM',
      voiceNoteDuration: '0:45s voice reflection',
      tags: ['Heritage', 'Begumpet', 'Artisans'],
      aiReflection: 'Key takeaway: Reconnecting with local craftsmanship grounds your focus and creativity.',
    },
    {
      id: 'j-2',
      title: 'Hyderabad Cricket Pod Championship Win',
      content:
        'Our LifeOS community cricket squad won the weekend tournament! Outstanding bowling spell in the final over. Celebrated with filter coffee and biryani.',
      mood: 'celebratory',
      moodEmoji: '🥳',
      visibility: 'circles',
      date: 'Yesterday • 8:30 PM',
      tags: ['Cricket', 'Community', 'Hyderabad'],
      aiReflection: 'High vitality day with strong social bonding signals recorded.',
    },
  ]);

  const moods: { mood: JournalEntry['mood']; emoji: string; label: string }[] = [
    { mood: 'energized', emoji: '⚡', label: 'Energized' },
    { mood: 'creative', emoji: '🌸', label: 'Creative' },
    { mood: 'calm', emoji: '🧘', label: 'Calm' },
    { mood: 'focused', emoji: '🎯', label: 'Focused' },
    { mood: 'celebratory', emoji: '🥳', label: 'Celebratory' },
  ];

  const handleSaveEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) {
      showToast('Please enter both a title and reflection', 'error');
      return;
    }

    const entry: JournalEntry = {
      id: `j-${Date.now()}`,
      title: newTitle.trim(),
      content: newContent.trim(),
      mood: selectedMood.mood,
      moodEmoji: selectedMood.emoji,
      visibility,
      date: 'Just now',
      tags: tags.split(',').map((t) => t.trim()).filter(Boolean),
      aiReflection: 'AI Reflection generated: Momentum recorded into your private sovereign Life Memory.',
    };

    setEntries([entry, ...entries]);
    setNewTitle('');
    setNewContent('');
    showToast('Moment saved to your private LifeOS Journal!', 'success');
  };

  const handlePublishToStory = (entry: JournalEntry) => {
    setIsTimeShiftCameraOpen(true);
    showToast(`Opening 3D Story Studio for "${entry.title}"`, 'info');
  };

  const handleDelete = (id: string) => {
    setEntries((prev) => prev.filter((e) => e.id !== id));
    showToast('Entry removed', 'info');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-purple-950/60 to-slate-900 border border-purple-500/20 p-5 sm:p-6 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-purple-300 text-xs font-bold uppercase tracking-wider mb-1">
            <BookOpen className="w-4 h-4 text-purple-400" />
            <span>Private Life Journal &amp; Moments Vault</span>
          </div>
          <h2 className="text-2xl font-black text-white">Capture Moments. Reflect. Share.</h2>
          <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-xl">
            A sovereign space for your private voice notes, photos, and life milestones. Easily convert any moment into a 3D Living Story when you wish.
          </p>
        </div>

        <button
          onClick={() => setIsTimeShiftCameraOpen(true)}
          className="bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white font-bold px-4 py-2.5 rounded-2xl text-xs flex items-center gap-2 shadow-lg self-start sm:self-auto"
        >
          <Camera className="w-4 h-4" />
          <span>Launch 3D Story Studio</span>
        </button>
      </div>

      {/* Creation Box & Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Col: New Entry Form */}
        <div className="lg:col-span-1 bg-slate-900/90 rounded-3xl border border-slate-800 p-5 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Plus className="w-4 h-4 text-purple-400" />
            <span>New Reflection or Voice Note</span>
          </h3>

          <form onSubmit={handleSaveEntry} className="space-y-3">
            <div>
              <label className="text-[11px] font-semibold text-slate-400 block mb-1">Title</label>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="What happened today?..."
                className="w-full bg-white rounded-xl border border-slate-800 px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-400 block mb-1">Your State / Mood</label>
              <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
                {moods.map((m) => (
                  <button
                    key={m.mood}
                    type="button"
                    onClick={() => setSelectedMood({ mood: m.mood, emoji: m.emoji })}
                    className={`px-2.5 py-1 rounded-xl text-xs flex items-center gap-1 transition-all ${
                      selectedMood.mood === m.mood
                        ? 'bg-purple-500 text-white font-bold shadow-sm'
                        : 'bg-white text-slate-400 border border-slate-800 hover:text-slate-200'
                    }`}
                  >
                    <span>{m.emoji}</span>
                    <span className="text-[10px]">{m.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-400 block mb-1">Reflections &amp; Notes</label>
              <textarea
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                rows={4}
                placeholder="Record your thoughts, discoveries, or memories..."
                className="w-full bg-white rounded-xl border border-slate-800 px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 resize-none"
              />
            </div>

            {/* Visibility & Voice Trigger */}
            <div className="flex items-center justify-between pt-1">
              <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-800 text-[11px]">
                <button
                  type="button"
                  onClick={() => setVisibility('private')}
                  className={`px-2 py-0.5 rounded-lg flex items-center gap-1 ${
                    visibility === 'private' ? 'bg-purple-500/20 text-purple-300 font-bold' : 'text-slate-500'
                  }`}
                >
                  <Lock className="w-3 h-3" />
                  <span>Private</span>
                </button>
                <button
                  type="button"
                  onClick={() => setVisibility('circles')}
                  className={`px-2 py-0.5 rounded-lg flex items-center gap-1 ${
                    visibility === 'circles' ? 'bg-purple-500/20 text-purple-300 font-bold' : 'text-slate-500'
                  }`}
                >
                  <Users className="w-3 h-3" />
                  <span>Circles</span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => {
                  setIsRecording(!isRecording);
                  showToast(isRecording ? 'Voice note recorded (0:32s)' : 'Recording voice note...', 'info');
                }}
                className={`p-2 rounded-xl border transition-all ${
                  isRecording
                    ? 'bg-rose-500 text-white border-rose-400 animate-pulse'
                    : 'bg-white text-slate-400 border-slate-800 hover:text-white'
                }`}
                title="Attach Voice Reflection"
              >
                <Mic className="w-4 h-4" />
              </button>
            </div>

            <button
              type="submit"
              className="w-full bg-purple-600 hover:bg-purple-500 text-white py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 shadow-md mt-2"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Save to Memory Vault</span>
            </button>
          </form>
        </div>

        {/* Right 2 Cols: Journal Timeline */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-purple-400" />
            <span>Recent Memories &amp; Moments Timeline</span>
          </h3>

          <div className="space-y-3">
            {entries.map((entry) => (
              <div
                key={entry.id}
                className="bg-slate-900/80 rounded-3xl border border-slate-800 p-5 space-y-3 hover:border-slate-700 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xl p-1.5 bg-white rounded-xl border border-slate-800">
                      {entry.moodEmoji}
                    </span>
                    <div>
                      <h4 className="text-sm font-bold text-white">{entry.title}</h4>
                      <span className="text-[10px] text-slate-400">{entry.date}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                        entry.visibility === 'private'
                          ? 'bg-white text-slate-400 border border-slate-800'
                          : 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                      }`}
                    >
                      {entry.visibility === 'private' ? <Lock className="w-2.5 h-2.5" /> : <Users className="w-2.5 h-2.5" />}
                      <span>{entry.visibility}</span>
                    </span>

                    <button
                      onClick={() => handlePublishToStory(entry)}
                      className="text-xs font-bold text-cyan-400 bg-cyan-500/10 hover:bg-cyan-500/20 px-2.5 py-1 rounded-xl border border-cyan-500/20 transition-all flex items-center gap-1"
                    >
                      <Camera className="w-3 h-3" />
                      <span>Story</span>
                    </button>

                    <button
                      onClick={() => handleDelete(entry.id)}
                      className="p-1.5 text-slate-600 hover:text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">{entry.content}</p>

                {entry.voiceNoteDuration && (
                  <div className="flex items-center gap-2 bg-white/80 p-2.5 rounded-2xl border border-slate-800 text-xs text-slate-300 w-fit">
                    <Volume2 className="w-4 h-4 text-purple-400" />
                    <span>{entry.voiceNoteDuration}</span>
                    <button
                      onClick={() => showToast('Playing recorded audio reflection...', 'info')}
                      className="text-[10px] font-bold text-purple-400 hover:underline ml-2"
                    >
                      Play ▶
                    </button>
                  </div>
                )}

                {entry.aiReflection && (
                  <div className="bg-indigo-950/30 border border-indigo-900/30 p-2.5 rounded-2xl flex items-start gap-2 text-[11px] text-indigo-300">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" />
                    <span>{entry.aiReflection}</span>
                  </div>
                )}

                <div className="flex items-center gap-1.5 pt-1">
                  {entry.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-[10px] font-medium text-slate-400 bg-white px-2 py-0.5 rounded-lg border border-slate-800/80"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
