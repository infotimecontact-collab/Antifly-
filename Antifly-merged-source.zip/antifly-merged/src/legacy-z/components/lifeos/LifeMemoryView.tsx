import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  BookOpen,
  Calendar,
  Sparkles,
  Plus,
  Lock,
  Globe,
  MapPin,
  Users,
  Image as ImageIcon,
  Share2,
  Trash2,
  CheckCircle2,
} from 'lucide-react';
import { LifeMemoryItem } from '../../types';

export const LifeMemoryView: React.FC = () => {
  const { lifeMemories, addLifeMemory, toggleMemoryPrivacy, showToast } = useApp();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<LifeMemoryItem['category']>('moment');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('San Francisco, CA');
  const [isPrivate, setIsPrivate] = useState(true);
  const [tags, setTags] = useState('Milestone, LIFEOS');

  const handleCreateMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    addLifeMemory({
      title: title.trim(),
      category,
      description: description.trim(),
      location,
      isPrivate,
      tags: tags
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean),
    });

    setIsAddModalOpen(false);
    setTitle('');
    setDescription('');
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-amber-950/40 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-2xl">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Life Memory Timeline • AI Narrative Synthesizer</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Your Sovereign Real-Life Journal
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
            Every intent fulfilled, temporary world completed, and authentic connection made is woven into your permanent personal memory stream.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center gap-2 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 hover:opacity-90 text-white font-bold text-sm px-5 py-3 rounded-2xl shadow-xl active:scale-95 transition-all shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add Life Memory</span>
        </button>
      </div>

      {/* Memory Timeline Stream */}
      <div className="space-y-6 max-w-4xl mx-auto">
        {lifeMemories.map((mem, idx) => (
          <div
            key={mem.id}
            className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-7 space-y-4 shadow-xl hover:border-amber-500/40 transition-all"
          >
            {/* Header */}
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-extrabold uppercase tracking-wider px-2.5 py-0.5 rounded-lg bg-amber-950 text-amber-400 border border-amber-800">
                    {mem.category}
                  </span>
                  <span className="text-xs text-slate-400 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" /> {mem.date}
                  </span>
                  <span className="text-xs text-slate-400 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-cyan-400" /> {mem.location}
                  </span>
                </div>

                <h3 className="text-lg sm:text-xl font-bold text-white mt-2">{mem.title}</h3>
              </div>

              {/* Privacy Pill */}
              <button
                onClick={() => toggleMemoryPrivacy(mem.id)}
                className={`flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg border transition-all ${
                  mem.isPrivate
                    ? 'bg-rose-950/60 border-rose-800 text-rose-400'
                    : 'bg-emerald-950/60 border-emerald-800 text-emerald-400'
                }`}
              >
                {mem.isPrivate ? <Lock className="w-3 h-3" /> : <Globe className="w-3 h-3" />}
                <span>{mem.isPrivate ? 'Private Only' : 'Shared with Circle'}</span>
              </button>
            </div>

            {/* Photos Strip */}
            {mem.photos && mem.photos.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {mem.photos.map((photo, pIdx) => (
                  <div key={pIdx} className="rounded-2xl overflow-hidden h-48 border border-slate-800">
                    <img src={photo} alt={mem.title} className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            )}

            {/* Description */}
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {mem.description}
            </p>

            {/* AI Summary synthesis */}
            {mem.aiSummary && (
              <div className="bg-white/80 p-3.5 rounded-2xl border border-slate-800/80 text-xs text-amber-200/90 leading-relaxed flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-amber-300">AI Synthesis: </span>
                  {mem.aiSummary}
                </div>
              </div>
            )}

            {/* Collaborators & Tags */}
            <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                <span className="text-slate-400 font-medium">Present:</span>
                {mem.peopleInvolved.map((p, i) => (
                  <div key={i} className="flex items-center gap-1.5 bg-white px-2 py-1 rounded-lg border border-slate-800">
                    {p.avatar && (
                      <img src={p.avatar} alt={p.name} className="w-4 h-4 rounded-full" />
                    )}
                    <span className="text-[11px] text-slate-300">{p.name}</span>
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-1">
                {mem.tags.map((t, i) => (
                  <span key={i} className="text-[10px] text-slate-400 bg-white px-2 py-0.5 rounded border border-slate-800">
                    #{t}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Memory Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-lg rounded-3xl p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold text-white">Record New Life Memory</h3>
            <form onSubmit={handleCreateMemory} className="space-y-3 text-xs">
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Memory Title / Milestone Name..."
                className="w-full bg-white border border-slate-800 rounded-xl px-3 py-2 text-white outline-none"
              />
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What made this moment or experience memorable?"
                className="w-full bg-white border border-slate-800 rounded-xl p-3 text-white outline-none resize-none"
              />
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Location (e.g., San Francisco, CA)"
                className="w-full bg-white border border-slate-800 rounded-xl px-3 py-2 text-white outline-none"
              />
              <div className="flex items-center justify-between pt-2">
                <label className="flex items-center gap-2 text-slate-300 font-semibold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isPrivate}
                    onChange={(e) => setIsPrivate(e.target.checked)}
                    className="rounded bg-white border-slate-800 text-amber-500"
                  />
                  <span>Keep this Memory 100% Private</span>
                </label>
              </div>
              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold px-5 py-2 rounded-xl"
                >
                  Save Memory
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
