import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkle,
  Zap,
  Users,
  CheckCircle2,
  ArrowRight,
  TrendingUp,
  X,
  PlusCircle,
  Lightbulb,
} from 'lucide-react';
import { IdeaCollision } from '../../types';

export const IdeaCollisionModal: React.FC = () => {
  const {
    isIdeaCollisionModalOpen,
    setIsIdeaCollisionModalOpen,
    ideaCollisions,
    optInIdeaCollision,
    setContextAwareChatPeer,
    setIsContextAwareChatOpen,
  } = useApp();

  if (!isIdeaCollisionModalOpen) return null;

  const handleStartCollisionRoom = (collision: IdeaCollision) => {
    setIsIdeaCollisionModalOpen(false);
    const peer = collision.contributorProfiles[0];
    if (peer) {
      setContextAwareChatPeer({
        name: peer.name,
        avatar: peer.avatar,
        sharedContext: `Idea Collision Room: "${collision.synthesisTitle}"`,
        matchRationale: `Complementary Domains: ${collision.domainsCollided.join(' + ')}`,
      });
      setIsContextAwareChatOpen(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-100/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl animate-scaleIn my-8">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-950/80 border border-amber-800 flex items-center justify-center text-amber-400">
              <Sparkle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold text-white">
                Emergent Idea Collision Engine
              </h2>
              <p className="text-xs text-slate-400">
                Cross-pollinating non-obvious combinations of complementary skills and intents.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsIdeaCollisionModalOpen(false)}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Idea Collision Cards */}
        <div className="space-y-4 max-h-[500px] overflow-y-auto pr-1">
          {ideaCollisions.map((collision) => (
            <div
              key={collision.id}
              className="bg-white/90 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-lg group hover:border-slate-700 transition-all"
            >
              {/* Top Domains Collided */}
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-1.5">
                  {collision.domainsCollided.map((domain, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-0.5 rounded-full bg-amber-950/80 border border-amber-800 text-amber-300 text-[10px] font-bold"
                    >
                      {domain}
                    </span>
                  ))}
                </div>

                <div className="flex items-center gap-1 text-xs text-emerald-400 font-bold">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>{collision.viabilityScore}% Viability Fit</span>
                </div>
              </div>

              {/* Title & Description */}
              <div>
                <h3 className="font-bold text-base text-white group-hover:text-amber-300 transition-colors">
                  {collision.synthesisTitle}
                </h3>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  {collision.emergentConcept}
                </p>
              </div>

              {/* Complementary Value Props */}
              <div className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-3 space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                  Collision Synergy Hypothesis
                </span>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {collision.complementaryValue}
                </p>
              </div>

              {/* Contributors Avatars */}
              <div className="space-y-2">
                <span className="text-[11px] font-bold text-slate-400 block">
                  Matched Potential Co-Creators:
                </span>
                <div className="flex flex-wrap gap-3">
                  {collision.contributorProfiles.map((contrib, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-2 p-2 rounded-xl bg-slate-900 border border-slate-800 text-xs"
                    >
                      <img
                        src={contrib.avatar}
                        alt={contrib.name}
                        className="w-7 h-7 rounded-lg object-cover"
                      />
                      <div>
                        <span className="font-bold text-white block text-[11px]">{contrib.name}</span>
                        <span className="text-[9px] text-slate-400">{contrib.skill}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Bar */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-3">
                <button
                  onClick={() => optInIdeaCollision(collision.id)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                    collision.optedIn
                      ? 'bg-emerald-950/80 border-emerald-800 text-emerald-300'
                      : 'bg-slate-900 border-slate-700 text-slate-300 hover:text-white'
                  }`}
                >
                  {collision.optedIn ? 'Opted In ✓' : 'Express Interest'}
                </button>

                <button
                  onClick={() => handleStartCollisionRoom(collision)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-800 text-xs font-bold transition-all shadow-md shadow-amber-500/20 active:scale-95"
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>Enter Collision Sandbox</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
