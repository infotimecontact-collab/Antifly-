import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Zap,
  Sparkles,
  Lock,
  Globe,
  Users,
  MapPin,
  Clock,
  ArrowRight,
  Mic,
  Bot,
  Layers,
  CheckCircle2,
} from 'lucide-react';
import { LifeIntentCategory, LifePrivacyScope } from '../../types';

export const IntentStudioModal: React.FC = () => {
  const { isLifeIntentModalOpen, setIsLifeIntentModalOpen, addLifeIntent } = useApp();

  const [category, setCategory] = useState<LifeIntentCategory>('building');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [privacy, setPrivacy] = useState<LifePrivacyScope>('public');
  const [urgency, setUrgency] = useState<'immediate' | 'this_week' | 'long_term'>('this_week');
  const [locationContext, setLocationContext] = useState('San Francisco, CA');
  const [keywords, setKeywords] = useState('Spatial AI, Startup, Founder, React');
  const [isAiDecomposing, setIsAiDecomposing] = useState(false);

  if (!isLifeIntentModalOpen) return null;

  const categories: { id: LifeIntentCategory; label: string; emoji: string }[] = [
    { id: 'doing', label: 'Doing', emoji: '⚡' },
    { id: 'feeling', label: 'Feeling', emoji: '🌊' },
    { id: 'looking_for', label: 'Looking For', emoji: '🔍' },
    { id: 'learning', label: 'Learning', emoji: '📚' },
    { id: 'building', label: 'Building', emoji: '🛠️' },
    { id: 'planning', label: 'Planning', emoji: '🗓️' },
    { id: 'experiencing', label: 'Experiencing', emoji: '🌌' },
    { id: 'offering', label: 'Offering', emoji: '🎁' },
    { id: 'needing', label: 'Needing', emoji: '🤝' },
    { id: 'interested_in', label: 'Interested In', emoji: '💡' },
  ];

  const handleSimulateAIDecomposition = () => {
    if (!title) return;
    setIsAiDecomposing(true);
    setTimeout(() => {
      setIsAiDecomposing(false);
      if (title.toLowerCase().includes('tokyo') || title.toLowerCase().includes('travel')) {
        setCategory('planning');
        setKeywords('Travel, Tokyo, Photography, Food, Guide');
        setDescription('Looking for local explorers and fellow travelers in Tokyo for street photography & culinary tours.');
      } else if (title.toLowerCase().includes('ai') || title.toLowerCase().includes('build')) {
        setCategory('building');
        setKeywords('Spatial AI, LLMs, Co-founder, Prototype, NextGen');
        setDescription('Building a next-gen ambient intelligence platform. Seeking an experienced technical co-founder in SF.');
      } else if (title.toLowerCase().includes('learn') || title.toLowerCase().includes('rust')) {
        setCategory('learning');
        setKeywords('Rust, Systems, Async, Mentorship, HighPerf');
        setDescription('Learning advanced Rust memory management & concurrency patterns. Open to weekly pair programming.');
      } else {
        setKeywords('Intent, Collaboration, RealLife, Synchronicities');
      }
    }, 600);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    addLifeIntent({
      category,
      title: title.trim(),
      description: description.trim(),
      privacy,
      urgency,
      locationContext,
      keywords: keywords
        .split(',')
        .map((k) => k.trim())
        .filter(Boolean),
    });

    setIsLifeIntentModalOpen(false);
    setTitle('');
    setDescription('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 my-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold text-white">Express a Life Intent</h2>
              <p className="text-xs text-slate-400">
                LIFEOS will intelligently match your real-life intention with people, knowledge & opportunities.
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsLifeIntentModalOpen(false)}
            className="p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Category Selector */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Select What You Are...
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {categories.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setCategory(c.id)}
                  className={`flex items-center gap-1.5 p-2 rounded-xl text-xs font-semibold border transition-all ${
                    category === c.id
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500 shadow-sm'
                      : 'bg-white border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  <span>{c.emoji}</span>
                  <span className="truncate">{c.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Title Input with Auto AI Decomposition */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Intent Headline / Statement
              </label>
              <button
                type="button"
                onClick={handleSimulateAIDecomposition}
                className="text-[11px] font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
              >
                <Sparkles className="w-3 h-3" />
                <span>{isAiDecomposing ? 'Decomposing...' : 'AI Auto-Complete'}</span>
              </button>
            </div>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., I want to build a Spatial AI startup in SF..."
              className="w-full bg-white border border-slate-800 focus:border-amber-500 rounded-2xl px-4 py-3 text-sm text-white placeholder-slate-500 outline-none transition-all shadow-inner"
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Details & Context (Optional)
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Share what skills you bring, what stage you are in, or what would make a dream connection..."
              className="w-full bg-white border border-slate-800 focus:border-amber-500 rounded-2xl p-4 text-xs sm:text-sm text-white placeholder-slate-500 outline-none transition-all resize-none shadow-inner"
            />
          </div>

          {/* Keywords & Location Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Key Topics & Tags
              </label>
              <input
                type="text"
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                placeholder="Comma separated topics"
                className="w-full bg-white border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 outline-none"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Location Context
              </label>
              <input
                type="text"
                value={locationContext}
                onChange={(e) => setLocationContext(e.target.value)}
                placeholder="e.g., San Francisco or Global Remote"
                className="w-full bg-white border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 outline-none"
              />
            </div>
          </div>

          {/* Privacy Scope & Urgency */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-800">
            {/* Privacy */}
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Privacy Scope
              </label>
              <div className="grid grid-cols-3 gap-1.5 text-xs">
                {(['private', 'friends', 'public'] as LifePrivacyScope[]).map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPrivacy(p)}
                    className={`py-2 px-2 rounded-xl font-semibold capitalize border text-center transition-all ${
                      privacy === p
                        ? 'bg-indigo-600 border-indigo-500 text-white shadow'
                        : 'bg-white border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            {/* Urgency */}
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Time Horizon
              </label>
              <div className="grid grid-cols-3 gap-1.5 text-xs">
                {[
                  { id: 'immediate', label: '24 Hours' },
                  { id: 'this_week', label: 'This Week' },
                  { id: 'long_term', label: 'Ongoing' },
                ].map((u) => (
                  <button
                    key={u.id}
                    type="button"
                    onClick={() => setUrgency(u.id as any)}
                    className={`py-2 px-2 rounded-xl font-semibold border text-center transition-all ${
                      urgency === u.id
                        ? 'bg-amber-500 border-amber-400 text-slate-800 font-bold shadow'
                        : 'bg-white border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    {u.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Submit Action */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsLifeIntentModalOpen(false)}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 hover:opacity-90 text-white text-xs sm:text-sm font-bold px-6 py-2.5 rounded-2xl shadow-xl shadow-amber-500/20 active:scale-95 transition-all"
            >
              <Sparkles className="w-4 h-4" />
              <span>Activate Intent in LIFEOS</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
