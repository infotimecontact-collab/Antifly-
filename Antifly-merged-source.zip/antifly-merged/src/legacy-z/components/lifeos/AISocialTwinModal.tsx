import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Bot,
  ShieldCheck,
  Zap,
  Sliders,
  Trash2,
  Lock,
  Eye,
  CheckCircle2,
  Sparkles,
  RefreshCw,
  Plus,
  Compass,
  Briefcase,
  Plane,
  BookOpen,
} from 'lucide-react';
import { AISocialTwinMemoryRecord } from '../../types';

export const AISocialTwinModal: React.FC = () => {
  const {
    isAITwinDashboardOpen,
    setIsAITwinDashboardOpen,
    aiTwinConfig,
    updateAITwinConfig,
    aiTwinMemories,
    updateTwinMemory,
    deleteTwinMemory,
    resetAllTwinMemory,
    addTwinMemory,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'permissions' | 'memory' | 'agents' | 'audit'>('permissions');
  const [newMemoryTitle, setNewMemoryTitle] = useState('');
  const [newMemoryDetails, setNewMemoryDetails] = useState('');

  if (!isAITwinDashboardOpen) return null;

  const handleAddMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemoryTitle.trim()) return;
    addTwinMemory({
      title: newMemoryTitle.trim(),
      details: newMemoryDetails.trim(),
      category: 'interest',
    });
    setNewMemoryTitle('');
    setNewMemoryDetails('');
  };

  const agentsList = [
    {
      id: 'venture_scout',
      name: 'Venture & Co-Founder Scout',
      desc: 'Autonomously identifies AI startup co-founders, technical leads, and angel syndicates.',
      icon: Briefcase,
      active: true,
    },
    {
      id: 'travel_navigator',
      name: 'Travel & Urban Explorer',
      desc: 'Pre-matches local photographers, guides, and tech communities in Tokyo and Kyoto.',
      icon: Plane,
      active: true,
    },
    {
      id: 'learning_mentor',
      name: 'Deep Learning & Systems Mentor',
      desc: 'Filters advanced research papers, Rust pairing partners, and spatial compute cohorts.',
      icon: BookOpen,
      active: false,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-3xl rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 my-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-extrabold text-white">AI Social Twin Control Center</h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] font-extrabold uppercase">
                  Active & Guarded
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Your sovereign digital representative in LIFEOS. Full transparency, zero opaque data sharing.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAITwinDashboardOpen(false)}
            className="p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 bg-white p-1.5 rounded-2xl border border-slate-800 text-xs font-bold">
          <button
            onClick={() => setActiveTab('permissions')}
            className={`flex-1 py-2 rounded-xl transition-all ${
              activeTab === 'permissions' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Permissions & Scope
          </button>
          <button
            onClick={() => setActiveTab('memory')}
            className={`flex-1 py-2 rounded-xl transition-all ${
              activeTab === 'memory' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Twin Memory Store ({aiTwinMemories.length})
          </button>
          <button
            onClick={() => setActiveTab('agents')}
            className={`flex-1 py-2 rounded-xl transition-all ${
              activeTab === 'agents' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Autonomous Agents
          </button>
        </div>

        {/* TAB 1: PERMISSIONS */}
        {activeTab === 'permissions' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {(() => {
                const currentPermissions = aiTwinConfig?.permissions || {
                  canShareInterests: aiTwinConfig?.permissionInterests ?? true,
                  canShareSkills: aiTwinConfig?.permissionSkills ?? true,
                  canShareGoals: aiTwinConfig?.permissionGoals ?? true,
                  canShareAvailability: aiTwinConfig?.permissionAvailability ?? true,
                  canShareCurrentIntentions: aiTwinConfig?.permissionCurrentIntentions ?? true,
                  canShareLocationZone: aiTwinConfig?.permissionLocationZone ?? true,
                };

                const permItems = [
                  { key: 'canShareInterests', label: 'Share Public Interests & Passions' },
                  { key: 'canShareSkills', label: 'Share Professional Skills & Verified Proof' },
                  { key: 'canShareGoals', label: 'Share Startup & Career Ambitions' },
                  { key: 'canShareAvailability', label: 'Share Real-Life Meeting Availability' },
                  { key: 'canShareCurrentIntentions', label: 'Share Active Life Intentions' },
                  { key: 'canShareLocationZone', label: 'Share Fuzzy Location Zone (Never exact GPS)' },
                ];

                return permItems.map((perm) => {
                  const isChecked = Boolean(currentPermissions[perm.key as keyof typeof currentPermissions]);
                  return (
                    <div
                      key={perm.key}
                      onClick={() =>
                        updateAITwinConfig({
                          permissions: {
                            ...currentPermissions,
                            [perm.key]: !isChecked,
                          },
                        })
                      }
                      className="flex items-center justify-between p-3.5 rounded-2xl bg-white/70 border border-slate-800 hover:border-slate-700 cursor-pointer transition-all"
                    >
                      <span className="text-xs font-semibold text-slate-200">{perm.label}</span>
                      <div
                        className={`w-10 h-6 rounded-full p-1 transition-colors ${
                          isChecked ? 'bg-emerald-500' : 'bg-slate-800'
                        }`}
                      >
                        <div
                          className={`w-4 h-4 rounded-full bg-white transition-transform ${
                            isChecked ? 'translate-x-4' : 'translate-x-0'
                          }`}
                        />
                      </div>
                    </div>
                  );
                });
              })()}
            </div>

            {/* Autonomous Negotiation Mode */}
            <div className="p-4 rounded-2xl bg-indigo-950/30 border border-indigo-900/60 space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-indigo-300">
                    Autonomous Introduction Negotiation
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Allow your AI Twin to engage with other users' AI Twins to pre-screen compatibility before pinging you.
                  </p>
                </div>
                <div
                  onClick={() =>
                    updateAITwinConfig({
                      autonomousNegotiation: !(aiTwinConfig?.autonomousNegotiation ?? true),
                    })
                  }
                  className={`w-10 h-6 rounded-full p-1 cursor-pointer transition-colors ${
                    (aiTwinConfig?.autonomousNegotiation ?? true) ? 'bg-indigo-500' : 'bg-slate-800'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white transition-transform ${
                      (aiTwinConfig?.autonomousNegotiation ?? true) ? 'translate-x-4' : 'translate-x-0'
                    }`}
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: MEMORY STORE */}
        {activeTab === 'memory' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-xs text-slate-400">
                Explicit facts and preferences learned by your AI Twin. You have full edit & delete authority.
              </p>
              <button
                onClick={resetAllTwinMemory}
                className="text-xs font-bold text-rose-400 hover:text-rose-300 flex items-center gap-1 bg-rose-950/40 border border-rose-900/60 px-3 py-1.5 rounded-xl transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" /> Wipe All Memory
              </button>
            </div>

            {/* Add Memory Box */}
            <form onSubmit={handleAddMemory} className="bg-white p-4 rounded-2xl border border-slate-800 space-y-3">
              <p className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Plus className="w-3.5 h-3.5 text-indigo-400" /> Teach AI Twin a New Preference / Fact
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  value={newMemoryTitle}
                  onChange={(e) => setNewMemoryTitle(e.target.value)}
                  placeholder="Fact / Preference Title..."
                  className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 outline-none"
                />
                <input
                  type="text"
                  value={newMemoryDetails}
                  onChange={(e) => setNewMemoryDetails(e.target.value)}
                  placeholder="Context details (e.g., Prefers async text first)"
                  className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 outline-none"
                />
              </div>
              <button
                type="submit"
                className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold px-4 py-2 rounded-xl transition-colors"
              >
                Save to Twin Memory
              </button>
            </form>

            {/* Memories List */}
            <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
              {aiTwinMemories.map((mem) => (
                <div
                  key={mem.id}
                  className="flex items-center justify-between p-3 rounded-2xl bg-white/60 border border-slate-800"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] uppercase font-bold text-indigo-400 bg-indigo-950 px-1.5 py-0.2 rounded">
                        {mem.category}
                      </span>
                      <h5 className="text-xs font-bold text-white">{mem.title}</h5>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">{mem.details}</p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => updateTwinMemory(mem.id, !mem.permitted)}
                      className={`text-[10px] font-bold px-2.5 py-1 rounded-lg border transition-colors ${
                        mem.permitted
                          ? 'bg-emerald-950 border-emerald-800 text-emerald-400'
                          : 'bg-slate-900 border-slate-800 text-slate-500'
                      }`}
                    >
                      {mem.permitted ? 'Permitted ✓' : 'Blocked ✕'}
                    </button>
                    <button
                      onClick={() => deleteTwinMemory(mem.id)}
                      className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: AUTONOMOUS AGENTS */}
        {activeTab === 'agents' && (
          <div className="space-y-3">
            {agentsList.map((agent) => {
              const Icon = agent.icon;
              return (
                <div
                  key={agent.id}
                  className="flex items-center justify-between p-4 rounded-2xl bg-white border border-slate-800"
                >
                  <div className="flex items-start gap-3">
                    <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 shrink-0">
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">{agent.name}</h4>
                      <p className="text-xs text-slate-400 mt-0.5">{agent.desc}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => showToast(`🤖 Toggled ${agent.name} status!`)}
                    className={`text-xs font-bold px-3 py-1.5 rounded-xl border transition-all ${
                      agent.active
                        ? 'bg-emerald-950 border-emerald-800 text-emerald-400'
                        : 'bg-slate-900 border-slate-800 text-slate-500'
                    }`}
                  >
                    {agent.active ? 'Active' : 'Disabled'}
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
