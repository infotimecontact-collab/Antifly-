import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Shuffle,
  Sparkles,
  Zap,
  Compass,
  ArrowRight,
  X,
  RefreshCw,
  Lightbulb,
  HeartHandshake,
} from 'lucide-react';

export const SerendipityModal: React.FC = () => {
  const {
    isSerendipityModalOpen,
    setIsSerendipityModalOpen,
    setContextAwareChatPeer,
    setIsContextAwareChatOpen,
  } = useApp();

  const serendipityDiscoveries = [
    {
      id: 'seren-1',
      title: 'Biomimetic Ceramic 3D Printing for Ocean Coral Restoration',
      domain: 'Marine Biology × Additive Manufacturing',
      whySerendipitous:
        'Far outside your core software graph, but shares your mathematical passion for topological mesh generation.',
      collaborator: {
        name: 'Dr. Elena Rostova',
        avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150',
        role: 'Ocean Materials Researcher',
      },
    },
    {
      id: 'seren-2',
      title: 'Autonomous Solar Micro-Grids in Rural Alpine Valleys',
      domain: 'CleanTech × Decentralized Edge Systems',
      whySerendipitous:
        'Uses the same low-latency fault-tolerant gossip protocol you designed for your distributed AI nodes.',
      collaborator: {
        name: 'Mateo Rossi',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
        role: 'Off-Grid Energy Architect',
      },
    },
    {
      id: 'seren-3',
      title: 'Acoustic Levitational Synthesis of High-Purity Pharmaceuticals',
      domain: 'BioTech × Acoustic Physics',
      whySerendipitous:
        'Pioneering ultrasonic transducer arrays with high overlap to your spatial haptic computing experiments.',
      collaborator: {
        name: 'Dr. Jun Takahashi',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
        role: 'Acoustic Physicist',
      },
    },
  ];

  if (!isSerendipityModalOpen) return null;

  const handleConnect = (item: (typeof serendipityDiscoveries)[0]) => {
    setIsSerendipityModalOpen(false);
    setContextAwareChatPeer({
      name: item.collaborator.name,
      avatar: item.collaborator.avatar,
      sharedContext: `Serendipity Collision: "${item.title}"`,
      matchRationale: item.whySerendipitous,
    });
    setIsContextAwareChatOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-100/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl animate-scaleIn my-8">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-950/80 border border-purple-800 flex items-center justify-center text-purple-400">
              <Shuffle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold text-white">
                Serendipity Mode & Anti-Bubble Explorer
              </h2>
              <p className="text-xs text-slate-400">
                Deliberately breaks algorithmic echo chambers with non-obvious cross-domain breakthroughs.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsSerendipityModalOpen(false)}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Serendipity Items */}
        <div className="space-y-4 max-h-[500px] overflow-y-auto pr-1">
          {serendipityDiscoveries.map((item) => (
            <div
              key={item.id}
              className="bg-white/90 border border-slate-800 rounded-3xl p-5 space-y-3.5 hover:border-purple-500/50 transition-all shadow-lg"
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-purple-950/80 text-purple-300 border border-purple-800">
                  {item.domain}
                </span>
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  Unexpected Intersection
                </span>
              </div>

              <h3 className="font-bold text-base text-white">{item.title}</h3>

              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-3 text-xs text-slate-300 space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-purple-400 block">
                  Why this Sparks High Serendipity:
                </span>
                <p className="leading-relaxed">{item.whySerendipitous}</p>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <img
                    src={item.collaborator.avatar}
                    alt={item.collaborator.name}
                    className="w-9 h-9 rounded-xl object-cover border border-slate-700"
                  />
                  <div>
                    <span className="font-bold text-xs text-white block">
                      {item.collaborator.name}
                    </span>
                    <span className="text-[10px] text-slate-400">{item.collaborator.role}</span>
                  </div>
                </div>

                <button
                  onClick={() => handleConnect(item)}
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all shadow-md shadow-purple-600/20 active:scale-95"
                >
                  Explore Collision
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
