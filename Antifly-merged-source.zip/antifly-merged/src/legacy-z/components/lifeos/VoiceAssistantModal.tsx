import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Mic,
  MicOff,
  Sparkles,
  Zap,
  Globe,
  Compass,
  ArrowRight,
  Bot,
} from 'lucide-react';

export const VoiceAssistantModal: React.FC = () => {
  const {
    isLifeVoiceModalOpen,
    setIsLifeVoiceModalOpen,
    setActiveLifeOSTab,
    setIsLifeIntentModalOpen,
    setIsCreateWorldModalOpen,
    showToast,
  } = useApp();

  const [isListening, setIsListening] = useState(true);
  const [transcript, setTranscript] = useState('');
  const [aiResponse, setAiResponse] = useState<string | null>(null);

  const samplePrompts = [
    'Find 3 co-founders building Spatial AI in SF',
    'Create a travel world for my Tokyo trip in September',
    'Connect me with someone who can teach me advanced Rust',
    'Show me active startup hackathons within 5 km',
  ];

  const handleSimulateVoice = (promptText: string) => {
    setTranscript(promptText);
    setIsListening(false);
    setAiResponse('Synthesizing life context and querying real-life synchronicities...');
    setTimeout(() => {
      if (promptText.includes('Tokyo')) {
        setAiResponse('Found 14 travelers and local creators in Tokyo. Navigating to Temporary Social Worlds.');
        setTimeout(() => {
          setIsLifeVoiceModalOpen(false);
          setActiveLifeOSTab('worlds');
        }, 1200);
      } else if (promptText.includes('Rust') || promptText.includes('teach')) {
        setAiResponse('Matched 2 senior systems engineers in your radius. Opening Universal Discovery.');
        setTimeout(() => {
          setIsLifeVoiceModalOpen(false);
          setActiveLifeOSTab('discovery');
        }, 1200);
      } else {
        setAiResponse('Discovered 3 co-creators with overlapping intent in SOMA. Opening Synchronicity Hub.');
        setTimeout(() => {
          setIsLifeVoiceModalOpen(false);
          setActiveLifeOSTab('synchronicity');
        }, 1200);
      }
    }, 800);
  };

  if (!isLifeVoiceModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/85 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-lg rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-center relative overflow-hidden">
        <button
          onClick={() => setIsLifeVoiceModalOpen(false)}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="space-y-2 pt-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Voice-First Life Navigator</span>
          </div>
          <h2 className="text-xl font-extrabold text-white">Speak Naturally to LIFEOS</h2>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            State what you need, where you are going, or what you are building.
          </p>
        </div>

        {/* Pulsing Mic Waveform */}
        <div className="py-4 flex flex-col items-center justify-center">
          <div
            onClick={() => setIsListening(!isListening)}
            className={`w-24 h-24 rounded-full flex items-center justify-center cursor-pointer transition-all duration-500 shadow-2xl ${
              isListening
                ? 'bg-gradient-to-tr from-cyan-500 to-indigo-600 ring-8 ring-cyan-500/20 scale-105 animate-pulse'
                : 'bg-slate-800 text-slate-400'
            }`}
          >
            {isListening ? (
              <Mic className="w-10 h-10 text-white" />
            ) : (
              <MicOff className="w-10 h-10 text-slate-400" />
            )}
          </div>
          <span className="text-xs font-bold text-slate-400 mt-3">
            {isListening ? 'Listening to ambient intent...' : 'Tap to activate voice'}
          </span>
        </div>

        {/* Transcript / AI Response */}
        {transcript ? (
          <div className="bg-white p-4 rounded-2xl border border-slate-800 space-y-2 text-left">
            <p className="text-xs text-slate-400">
              <strong className="text-cyan-400">You said:</strong> "{transcript}"
            </p>
            {aiResponse && (
              <p className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" /> {aiResponse}
              </p>
            )}
          </div>
        ) : (
          /* Suggested Shortcuts */
          <div className="space-y-2 text-left">
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 text-center">
              Or tap a pre-built natural prompt:
            </p>
            <div className="space-y-1.5">
              {samplePrompts.map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSimulateVoice(p)}
                  className="w-full text-left p-2.5 rounded-xl bg-white/70 hover:bg-white border border-slate-800 text-xs text-slate-300 hover:text-cyan-300 flex items-center justify-between transition-colors group"
                >
                  <span className="truncate">"{p}"</span>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400 shrink-0" />
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
