import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Radio,
  MapPin,
  ShieldCheck,
  Compass,
  Users,
  Building2,
  Calendar,
  Sparkles,
  Layers,
  Info,
  Navigation,
  Globe,
  Sliders,
} from 'lucide-react';
import { LifeMapZoneNode } from '../../types';

export const SocialMapView: React.FC = () => {
  const { mapNodes, showToast, setActiveWorldDetail, setActiveLifeOSTab } = useApp();

  const [activeRadiusKm, setActiveRadiusKm] = useState<number>(10);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedNode, setSelectedNode] = useState<LifeMapZoneNode | null>(null);

  const filteredNodes = mapNodes.filter((node) => {
    if (node.distanceKm > activeRadiusKm) return false;
    if (selectedCategory !== 'all' && node.category !== selectedCategory) return false;
    return true;
  });

  const categories = [
    { id: 'all', label: 'All Zones' },
    { id: 'world', label: 'Social Worlds' },
    { id: 'event', label: 'Events' },
    { id: 'business', label: 'Verified Businesses' },
    { id: 'opportunity', label: 'Opportunities' },
    { id: 'creator', label: 'Creator Hubs' },
  ];

  return (
    <div className="space-y-6 pb-16">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950/40 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-2xl">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold">
            <Radio className="w-3.5 h-3.5" />
            <span>Social Map & Radar • Privacy-Preserving Geographic Intelligence</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Real-Life Social Radar
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
            Discover active social worlds, gatherings, and opportunities nearby. LIFEOS uses geometric centroid obfuscation so exact GPS coordinates are never leaked.
          </p>
        </div>

        {/* Privacy Verified Badge */}
        <div className="bg-white/80 border border-emerald-800/80 p-4 rounded-2xl space-y-1 text-xs shrink-0">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Zero-GPS Tracking Mode Active</span>
          </div>
          <p className="text-slate-400 text-[11px]">
            Centroid precision: ±500 meters fuzzy grid
          </p>
        </div>
      </div>

      {/* Control Bar: Radius & Categories */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-4 rounded-2xl">
        {/* Radius Slider */}
        <div className="flex items-center gap-3 text-xs">
          <span className="font-bold text-slate-300 flex items-center gap-1">
            <Compass className="w-3.5 h-3.5 text-cyan-400" /> Radius:
          </span>
          <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-800">
            {[3, 5, 10, 25].map((r) => (
              <button
                key={r}
                onClick={() => setActiveRadiusKm(r)}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  activeRadiusKm === r
                    ? 'bg-emerald-500 text-slate-800 shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {r} km
              </button>
            ))}
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === c.id
                  ? 'bg-indigo-600 text-white shadow'
                  : 'bg-white text-slate-400 border border-slate-800 hover:text-white'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* Interactive Map Radar Stage & Nodes Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Radar Canvas Stage (Interactive SVG Canvas) */}
        <div className="lg:col-span-2 bg-white border border-slate-800 rounded-3xl p-6 relative overflow-hidden flex items-center justify-center min-h-[420px] shadow-2xl">
          {/* Radar Background Circles */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-40 h-40 rounded-full border border-slate-800/80" />
            <div className="w-72 h-72 rounded-full border border-slate-800/60" />
            <div className="w-96 h-96 rounded-full border border-cyan-900/30 animate-pulse" />
            <div className="w-[500px] h-[500px] rounded-full border border-slate-800/30" />
            {/* Crosshairs */}
            <div className="absolute w-full h-[1px] bg-slate-800/50" />
            <div className="absolute h-full w-[1px] bg-slate-800/50" />
          </div>

          {/* Center User Node */}
          <div className="relative z-10 flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-cyan-500/20 border-2 border-cyan-400 flex items-center justify-center shadow-lg shadow-cyan-500/30 animate-pulse">
              <Navigation className="w-5 h-5 text-cyan-400" />
            </div>
            <span className="text-[11px] font-extrabold text-cyan-300 mt-1 bg-white/80 px-2 py-0.5 rounded-full border border-slate-800">
              You (SOMA Centroid)
            </span>
          </div>

          {/* Placed Nodes on Radar Canvas */}
          {filteredNodes.map((node, index) => {
            // Distribute mathematically around the center
            const angle = (index * 360) / (filteredNodes.length || 1) + 20;
            const rad = (angle * Math.PI) / 180;
            const distanceScale = (node.distanceKm / activeRadiusKm) * 160 + 50;
            const x = Math.cos(rad) * distanceScale;
            const y = Math.sin(rad) * distanceScale;

            const isSelected = selectedNode?.id === node.id;

            return (
              <div
                key={node.id}
                style={{
                  transform: `translate(${x}px, ${y}px)`,
                }}
                onClick={() => setSelectedNode(node)}
                className={`absolute z-20 cursor-pointer p-1 rounded-2xl transition-all duration-300 ${
                  isSelected ? 'scale-125 z-30 ring-2 ring-emerald-400' : 'hover:scale-110'
                }`}
              >
                <div className="flex items-center gap-1.5 bg-slate-900/90 border border-slate-700 hover:border-emerald-400 px-2.5 py-1.5 rounded-2xl shadow-xl backdrop-blur-md">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <div className="text-left">
                    <p className="text-[10px] font-extrabold text-white truncate max-w-[100px]">
                      {node.title}
                    </p>
                    <p className="text-[9px] text-cyan-400 font-bold">{node.distanceKm} km</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected / Nearby List Sidebar */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Radio className="w-4 h-4 text-emerald-400" />
              Radar Detections ({filteredNodes.length})
            </h3>
            <span className="text-xs text-slate-400">Within {activeRadiusKm} km</span>
          </div>

          <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1 scrollbar-thin">
            {filteredNodes.map((node) => {
              const isSelected = selectedNode?.id === node.id;
              return (
                <div
                  key={node.id}
                  onClick={() => setSelectedNode(node)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-slate-900 border-emerald-500 shadow-xl'
                      : 'bg-slate-900/70 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] uppercase font-extrabold px-2 py-0.5 rounded bg-white text-indigo-400 border border-slate-800">
                        {node.category}
                      </span>
                      <h4 className="font-bold text-sm text-white mt-1">{node.title}</h4>
                      <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                        {node.description}
                      </p>
                    </div>
                    <span className="text-xs font-bold text-emerald-400 bg-emerald-950/80 px-2 py-1 rounded-lg border border-emerald-800 shrink-0">
                      {node.distanceKm} km
                    </span>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                    <span className="text-slate-400 flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-cyan-400" />
                      {node.activeParticipantsCount} active nearby
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        showToast(`📍 Centered radar on ${node.title}!`);
                      }}
                      className="text-emerald-400 hover:text-emerald-300 font-bold"
                    >
                      Connect →
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
