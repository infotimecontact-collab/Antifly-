import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Calendar,
  CheckCircle2,
  Circle,
  Clock,
  Sparkles,
  Plus,
  ArrowRight,
  Flame,
  ShoppingBag,
  Bell,
  SunMedium,
  Moon,
  ChevronRight,
  Send,
  Trash2,
  Tag,
  MapPin,
} from 'lucide-react';

interface PlannerTask {
  id: string;
  title: string;
  category: 'shopping' | 'personal' | 'work' | 'health' | 'social';
  dueTime: string;
  isCompleted: boolean;
  priority: 'high' | 'medium' | 'low';
  source?: 'ai_nlp' | 'manual' | 'order_tracker';
  actionUrl?: string;
  actionLabel?: string;
}

export const LifeOSPlannerView: React.FC = () => {
  const { showToast, setDeviceMode, orders } = useApp();
  const [naturalInput, setNaturalInput] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'today' | 'shopping' | 'habits'>('all');

  const [tasks, setTasks] = useState<PlannerTask[]>([
    {
      id: 'task-1',
      title: 'Order fresh Organic Kashmiri Saffron from Priya Crafts (Venture)',
      category: 'shopping',
      dueTime: 'Today • 2:30 PM',
      isCompleted: false,
      priority: 'high',
      source: 'ai_nlp',
      actionLabel: 'Open Storefront',
      actionUrl: 'storefront',
    },
    {
      id: 'task-2',
      title: 'Hyderabad Cricket Circle match at Jubilee Hills Turf',
      category: 'social',
      dueTime: 'Today • 5:00 PM',
      isCompleted: false,
      priority: 'high',
      source: 'manual',
    },
    {
      id: 'task-3',
      title: 'Complete 30-min Deep Breathing Bio-Energy meditation',
      category: 'health',
      dueTime: 'Today • 7:30 PM',
      isCompleted: true,
      priority: 'medium',
    },
    {
      id: 'task-4',
      title: 'Review weekly Seller Diamond earnings & UPI payout batch',
      category: 'work',
      dueTime: 'Tomorrow • 11:00 AM',
      isCompleted: false,
      priority: 'medium',
    },
  ]);

  const [habits, setHabits] = useState([
    { id: 'h1', title: 'Daily SuperCoins Check-in 🪙', streak: 14, completedToday: true },
    { id: 'h2', title: 'Hydration Goal (3L water)', streak: 8, completedToday: true },
    { id: 'h3', title: 'Support 1 Local Artisan Venture', streak: 5, completedToday: false },
    { id: 'h4', title: 'Evening 3D Story Post 📸', streak: 12, completedToday: false },
  ]);

  const handleToggleTask = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          const next = !t.isCompleted;
          if (next) showToast('Task completed! +5 SuperCoins earned 🪙', 'success');
          return { ...t, isCompleted: next };
        }
        return t;
      })
    );
  };

  const handleAddNaturalTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!naturalInput.trim()) return;

    const lower = naturalInput.toLowerCase();
    let cat: PlannerTask['category'] = 'personal';
    if (lower.includes('buy') || lower.includes('order') || lower.includes('shop') || lower.includes('gift')) {
      cat = 'shopping';
    } else if (lower.includes('workout') || lower.includes('cricket') || lower.includes('walk') || lower.includes('meditation')) {
      cat = 'health';
    } else if (lower.includes('meet') || lower.includes('call') || lower.includes('friend') || lower.includes('party')) {
      cat = 'social';
    } else if (lower.includes('meeting') || lower.includes('client') || lower.includes('review') || lower.includes('ship')) {
      cat = 'work';
    }

    const newTask: PlannerTask = {
      id: `task-${Date.now()}`,
      title: naturalInput.trim(),
      category: cat,
      dueTime: 'Today • Upcoming',
      isCompleted: false,
      priority: lower.includes('urgent') || lower.includes('important') ? 'high' : 'medium',
      source: 'ai_nlp',
    };

    setTasks((prev) => [newTask, ...prev]);
    setNaturalInput('');
    showToast('Plan added to your LifeOS Day Schedule!', 'success');
  };

  const handleDeleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
    showToast('Task removed', 'info');
  };

  const handleToggleHabit = (id: string) => {
    setHabits((prev) =>
      prev.map((h) => {
        if (h.id === id) {
          const next = !h.completedToday;
          if (next) showToast(`Streak preserved: ${h.streak + 1} days! 🔥`, 'success');
          return {
            ...h,
            completedToday: next,
            streak: next ? h.streak + 1 : Math.max(0, h.streak - 1),
          };
        }
        return h;
      })
    );
  };

  const pendingCount = tasks.filter((t) => !t.isCompleted).length;
  const completedCount = tasks.filter((t) => t.isCompleted).length;

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* 1. LifeOS Daily Briefing Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 border border-indigo-500/20 p-5 sm:p-6 text-white shadow-xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-indigo-300 text-xs font-bold uppercase tracking-wider mb-1">
              <SunMedium className="w-4 h-4 text-amber-400" />
              <span>LifeOS Daily Intelligent Brief • {new Date().toLocaleDateString('en-IN', { weekday: 'long', month: 'short', day: 'numeric' })}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Good day, Alex. You have {pendingCount} priorities today.
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed">
              Your local delivery of organic spices is scheduled for 2:30 PM. Weather in Hyderabad is clear (29°C) — great for evening cricket at Jubilee Hills.
            </p>
          </div>

          <div className="flex items-center gap-3 bg-slate-900/80 backdrop-blur-md p-3 rounded-2xl border border-slate-800 self-start md:self-auto">
            <div className="text-center px-2">
              <span className="text-[10px] text-slate-400 font-bold block uppercase">Pending</span>
              <span className="text-xl font-extrabold text-amber-400">{pendingCount}</span>
            </div>
            <div className="h-7 w-px bg-slate-800" />
            <div className="text-center px-2">
              <span className="text-[10px] text-slate-400 font-bold block uppercase">Done</span>
              <span className="text-xl font-extrabold text-emerald-400">{completedCount}</span>
            </div>
            <div className="h-7 w-px bg-slate-800" />
            <div className="text-center px-2">
              <span className="text-[10px] text-slate-400 font-bold block uppercase">Streak</span>
              <span className="text-xl font-extrabold text-orange-400 flex items-center justify-center gap-0.5">
                <Flame className="w-4 h-4 text-orange-500 fill-orange-500" />
                14d
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Natural Language AI Input Bar */}
      <form
        onSubmit={handleAddNaturalTask}
        className="relative bg-slate-900/90 rounded-2xl border border-slate-800 p-2 sm:p-3 shadow-lg flex items-center gap-2 focus-within:border-cyan-500/50 transition-colors"
      >
        <Sparkles className="w-5 h-5 text-cyan-400 shrink-0 ml-2 animate-pulse" />
        <input
          type="text"
          value={naturalInput}
          onChange={(e) => setNaturalInput(e.target.value)}
          placeholder="Ask LifeOS to plan: 'Remind me at 4 PM to check out handmade silk dupatta from Priya Crafts'..."
          className="w-full bg-transparent text-sm text-slate-100 placeholder-slate-500 focus:outline-none px-2"
        />
        <button
          type="submit"
          disabled={!naturalInput.trim()}
          className="bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-slate-800 px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Plan</span>
        </button>
      </form>

      {/* 3. Main Grid: Active Plans & Daily Habit Streaks */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Structured Daily Agenda */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-cyan-400" />
              <span>Today's Intelligent Action Matrix</span>
            </h3>
            <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
              <button
                onClick={() => setActiveFilter('all')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                  activeFilter === 'all' ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All ({tasks.length})
              </button>
              <button
                onClick={() => setActiveFilter('shopping')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                  activeFilter === 'shopping' ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Shopping
              </button>
            </div>
          </div>

          <div className="space-y-2.5">
            {tasks
              .filter((t) => (activeFilter === 'shopping' ? t.category === 'shopping' : true))
              .map((task) => (
                <div
                  key={task.id}
                  className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 group ${
                    task.isCompleted
                      ? 'bg-slate-900/40 border-slate-800/60 opacity-60'
                      : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <button
                      onClick={() => handleToggleTask(task.id)}
                      className="text-slate-400 hover:text-cyan-400 transition-colors shrink-0"
                    >
                      {task.isCompleted ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-400 fill-emerald-400/20" />
                      ) : (
                        <Circle className="w-5 h-5 text-slate-500 hover:text-cyan-400" />
                      )}
                    </button>

                    <div className="min-w-0">
                      <p
                        className={`text-sm font-medium text-slate-100 truncate ${
                          task.isCompleted ? 'line-through text-slate-400' : ''
                        }`}
                      >
                        {task.title}
                      </p>
                      <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400 flex-wrap">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-slate-500" />
                          {task.dueTime}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${
                            task.category === 'shopping'
                              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                              : task.category === 'social'
                              ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                              : task.category === 'health'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                          }`}
                        >
                          {task.category}
                        </span>
                        {task.source === 'ai_nlp' && (
                          <span className="text-[10px] text-indigo-400 flex items-center gap-0.5">
                            <Sparkles className="w-2.5 h-2.5" />
                            AI Parsed
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {task.actionLabel && (
                      <button
                        onClick={() => setDeviceMode('website')}
                        className="text-xs font-bold text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 px-2.5 py-1.5 rounded-xl border border-amber-500/20 transition-all flex items-center gap-1"
                      >
                        <ShoppingBag className="w-3 h-3" />
                        <span>{task.actionLabel}</span>
                      </button>
                    )}
                    <button
                      onClick={() => handleDeleteTask(task.id)}
                      className="p-1.5 text-slate-600 hover:text-rose-400 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* Right Col: Daily Habit Streaks & Quick Shopping Triggers */}
        <div className="space-y-4">
          <div className="bg-slate-900/80 rounded-3xl border border-slate-800 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Flame className="w-4 h-4 text-orange-500" />
                <span>Habit Streaks</span>
              </h4>
              <span className="text-[11px] font-bold text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded-full">
                Active Streak
              </span>
            </div>

            <div className="space-y-2">
              {habits.map((habit) => (
                <div
                  key={habit.id}
                  onClick={() => handleToggleHabit(habit.id)}
                  className="p-3 bg-white/60 rounded-2xl border border-slate-800/80 flex items-center justify-between cursor-pointer hover:border-slate-700 transition-all"
                >
                  <div className="flex items-center gap-2.5">
                    {habit.completedToday ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 fill-emerald-400/20" />
                    ) : (
                      <Circle className="w-4 h-4 text-slate-600" />
                    )}
                    <span
                      className={`text-xs font-medium ${
                        habit.completedToday ? 'text-slate-200 font-semibold' : 'text-slate-400'
                      }`}
                    >
                      {habit.title}
                    </span>
                  </div>
                  <span className="text-xs font-bold text-orange-400 flex items-center gap-1 font-mono">
                    <Flame className="w-3 h-3 text-orange-500 fill-orange-500" />
                    {habit.streak}d
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Local Commerce Bridge */}
          <div className="bg-gradient-to-br from-slate-900 to-indigo-950/60 rounded-3xl border border-indigo-900/30 p-5 space-y-3">
            <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider">
              <ShoppingBag className="w-4 h-4 text-amber-400" />
              <span>Hyperlocal Shopping Intent</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Discovered 3 verified artisan sellers delivering in your area (Hitech City, Hyderabad) in &lt;30 mins with zero delivery fee.
            </p>
            <button
              onClick={() => setDeviceMode('website')}
              className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-800 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 shadow-md"
            >
              <span>Explore Local Ventures</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
