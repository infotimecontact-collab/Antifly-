import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Target,
  Trophy,
  Flame,
  Plus,
  CheckCircle2,
  Circle,
  TrendingUp,
  Users,
  Sparkles,
  ArrowRight,
  Shield,
  Clock,
  Calendar,
} from 'lucide-react';

interface LifeGoal {
  id: string;
  title: string;
  category: 'career' | 'health' | 'business' | 'personal' | 'learning';
  progressPercentage: number;
  streakDays: number;
  targetDate: string;
  milestones: { id: string; title: string; completed: boolean }[];
  accountabilityBuddy?: string;
  rewardDiamonds?: number;
}

export const LifeOSGoalsView: React.FC = () => {
  const { showToast, setIsTimeShiftCameraOpen } = useApp();
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const [goals, setGoals] = useState<LifeGoal[]>([
    {
      id: 'g-1',
      title: 'Scale Begumpet Artisan Venture to ₹50,000 monthly sales',
      category: 'business',
      progressPercentage: 65,
      streakDays: 18,
      targetDate: 'Oct 2026',
      milestones: [
        { id: 'm1', title: 'Upload 15 handcrafted product SKUs with 3D reels', completed: true },
        { id: 'm2', title: 'Enable sub-30min Buddy delivery in Hyderabad cluster', completed: true },
        { id: 'm3', title: 'Attain 100 positive 5-star customer reviews', completed: false },
        { id: 'm4', title: 'Reach ₹50,000 GMV threshold', completed: false },
      ],
      accountabilityBuddy: 'Priya Crafts Community (140 members)',
      rewardDiamonds: 500,
    },
    {
      id: 'g-2',
      title: 'Run 10K Marathon & Maintain Vital Energy Flow',
      category: 'health',
      progressPercentage: 80,
      streakDays: 24,
      targetDate: 'Nov 2026',
      milestones: [
        { id: 'm2-1', title: 'Run 5K at KBR Park without stopping', completed: true },
        { id: 'm2-2', title: 'Complete weekly interval training', completed: true },
        { id: 'm2-3', title: 'Sub-55min 10K trial run', completed: false },
      ],
      accountabilityBuddy: 'Hyderabad Fitness Circle',
      rewardDiamonds: 250,
    },
    {
      id: 'g-3',
      title: 'Master Full-Stack TypeScript & AI Agent Architecture',
      category: 'learning',
      progressPercentage: 45,
      streakDays: 9,
      targetDate: 'Dec 2026',
      milestones: [
        { id: 'm3-1', title: 'Deploy autonomous agent swarms in LifeOS', completed: true },
        { id: 'm3-2', title: 'Build real-time vector memory pipelines', completed: false },
      ],
      rewardDiamonds: 300,
    },
  ]);

  const handleToggleMilestone = (goalId: string, milestoneId: string) => {
    setGoals((prev) =>
      prev.map((g) => {
        if (g.id === goalId) {
          const updated = g.milestones.map((m) =>
            m.id === milestoneId ? { ...m, completed: !m.completed } : m
          );
          const completedCount = updated.filter((m) => m.completed).length;
          const pct = Math.round((completedCount / updated.length) * 100);
          showToast(`Milestone updated! Progress: ${pct}%`, 'success');
          return {
            ...g,
            milestones: updated,
            progressPercentage: pct,
          };
        }
        return g;
      })
    );
  };

  const filteredGoals =
    activeCategory === 'all'
      ? goals
      : goals.filter((g) => g.category === activeCategory);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-950 border border-emerald-500/20 p-5 sm:p-6 text-white flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-emerald-300 text-xs font-bold uppercase tracking-wider mb-1">
            <Target className="w-4 h-4 text-emerald-400" />
            <span>LifeOS Sovereign Goals &amp; Habit Sprints</span>
          </div>
          <h2 className="text-2xl font-black text-white">Turn Aspirations into Measured Momentum</h2>
          <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-xl">
            Set ambitious life targets, break them into daily sprint milestones, and earn Diamond rewards as you progress with your circles.
          </p>
        </div>

        <div className="flex items-center gap-3 bg-slate-900/80 p-3 rounded-2xl border border-slate-800 self-start md:self-auto">
          <div className="text-center px-2">
            <span className="text-[10px] text-slate-400 font-bold block uppercase">Active Goals</span>
            <span className="text-xl font-extrabold text-emerald-400">{goals.length}</span>
          </div>
          <div className="h-7 w-px bg-slate-800" />
          <div className="text-center px-2">
            <span className="text-[10px] text-slate-400 font-bold block uppercase">Earnable 💎</span>
            <span className="text-xl font-extrabold text-cyan-400">1,050</span>
          </div>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-none pb-1 text-xs">
        {['all', 'business', 'health', 'learning', 'career'].map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-3 py-1.5 rounded-xl font-semibold capitalize transition-all ${
              activeCategory === cat
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Goals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredGoals.map((goal) => (
          <div
            key={goal.id}
            className="bg-slate-900/90 rounded-3xl border border-slate-800 p-5 space-y-4 hover:border-slate-700 transition-all shadow-md flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <span
                    className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                      goal.category === 'business'
                        ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20'
                        : goal.category === 'health'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                    }`}
                  >
                    {goal.category}
                  </span>
                  <h3 className="text-base font-bold text-white mt-1.5">{goal.title}</h3>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs font-bold text-orange-400 flex items-center gap-1 font-mono">
                    <Flame className="w-3.5 h-3.5 text-orange-500 fill-orange-500" />
                    {goal.streakDays}d streak
                  </span>
                  <span className="text-[10px] text-slate-500 block mt-0.5">Target: {goal.targetDate}</span>
                </div>
              </div>

              {/* Progress Bar */}
              <div>
                <div className="flex items-center justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-400">Completion</span>
                  <span className="text-emerald-400 font-mono font-bold">{goal.progressPercentage}%</span>
                </div>
                <div className="w-full h-2 bg-white rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-cyan-400 transition-all duration-500 rounded-full"
                    style={{ width: `${goal.progressPercentage}%` }}
                  />
                </div>
              </div>

              {/* Milestones Checklist */}
              <div className="space-y-2 pt-1">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  Key Sprint Milestones
                </span>
                {goal.milestones.map((m) => (
                  <div
                    key={m.id}
                    onClick={() => handleToggleMilestone(goal.id, m.id)}
                    className="flex items-center gap-2.5 p-2 bg-white/60 rounded-xl border border-slate-800/80 cursor-pointer hover:border-slate-700 transition-all"
                  >
                    {m.completed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 fill-emerald-400/20 shrink-0" />
                    ) : (
                      <Circle className="w-4 h-4 text-slate-600 shrink-0" />
                    )}
                    <span
                      className={`text-xs ${
                        m.completed ? 'line-through text-slate-500' : 'text-slate-200'
                      }`}
                    >
                      {m.title}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Footer Accountability & Reward */}
            <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
              {goal.accountabilityBuddy ? (
                <div className="flex items-center gap-1.5 text-slate-400">
                  <Users className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="text-[11px] truncate max-w-[180px]">{goal.accountabilityBuddy}</span>
                </div>
              ) : (
                <span className="text-[11px] text-slate-500">Private Goal</span>
              )}

              {goal.rewardDiamonds && (
                <span className="text-cyan-400 font-bold font-mono text-[11px]">
                  +{goal.rewardDiamonds} 💎 on 100%
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
