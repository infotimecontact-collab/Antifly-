import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  Plus,
  Radio,
  Eye,
  Users,
  Target,
  Flame,
  Award,
  Zap,
  Globe,
  Camera,
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  Clock,
  MessageCircle,
  TrendingUp,
} from 'lucide-react';
import { TimeShiftStoryItem } from '../../types';

interface LifeOSLivingStoriesBarProps {
  variant?: 'compact' | 'full' | 'social_feed';
  filterCommunityId?: string;
  onSelectCommunity?: (communityId: string) => void;
}

export const LifeOSLivingStoriesBar: React.FC<LifeOSLivingStoriesBarProps> = ({
  variant = 'full',
  filterCommunityId,
  onSelectCommunity,
}) => {
  const {
    timeShiftStories,
    setIsTimeShiftStoryViewerOpen,
    setActiveTimeShiftStory,
    setIsTimeShiftCameraOpen,
    livingUserProfile,
    goalCommunities,
    temporaryCommunities,
    socialWorlds,
    showToast,
  } = useApp();

  const [activeStoryFilter, setActiveStoryFilter] = useState<'all' | 'joined' | 'sprints' | 'temporary' | 'profiles'>('all');
  const [hoveredStoryId, setHoveredStoryId] = useState<string | null>(null);

  // Get joined community IDs across all modules
  const joinedGoalCommunityIds = useMemo(() => {
    return new Set(goalCommunities.filter((c) => c.isJoined).map((c) => c.id));
  }, [goalCommunities]);

  const joinedTempCommunityIds = useMemo(() => {
    return new Set(temporaryCommunities.filter((c) => c.isJoined).map((c) => c.id));
  }, [temporaryCommunities]);

  const joinedWorldIds = useMemo(() => {
    return new Set(socialWorlds.filter((w) => w.isJoined).map((w) => w.id));
  }, [socialWorlds]);

  // Check if a story belongs to a joined community
  const isStoryInJoinedCommunity = (story: TimeShiftStoryItem): boolean => {
    if (!story.communityId) return false;
    return (
      joinedGoalCommunityIds.has(story.communityId) ||
      joinedTempCommunityIds.has(story.communityId) ||
      joinedWorldIds.has(story.communityId) ||
      story.authorId === 'living-user-alex' ||
      story.isPersonalStory === true
    );
  };

  // Find the logged-in user's personal active story
  const myActiveStory = useMemo(() => {
    return timeShiftStories.find(
      (s) => s.isPersonalStory || s.authorId === 'living-user-alex' || s.authorHandle === livingUserProfile.handle
    );
  }, [timeShiftStories, livingUserProfile.handle]);

  // Filter stories based on selected filter
  const filteredStories = useMemo(() => {
    let list = timeShiftStories.filter((s) => s.status !== 'expired');

    if (filterCommunityId) {
      return list.filter((s) => s.communityId === filterCommunityId);
    }

    if (activeStoryFilter === 'joined') {
      return list.filter((s) => isStoryInJoinedCommunity(s));
    }

    if (activeStoryFilter === 'sprints') {
      return list.filter((s) => s.communityType === 'goal_community' || s.milestoneTag);
    }

    if (activeStoryFilter === 'temporary') {
      return list.filter((s) => s.communityType === 'temporary_community');
    }

    if (activeStoryFilter === 'profiles') {
      return list.filter((s) => s.isProfileStory || s.isPersonalStory);
    }

    return list;
  }, [timeShiftStories, filterCommunityId, activeStoryFilter, joinedGoalCommunityIds, joinedTempCommunityIds, joinedWorldIds]);

  const handleOpenStory = (storyItem: TimeShiftStoryItem) => {
    setActiveTimeShiftStory(storyItem);
    setIsTimeShiftStoryViewerOpen(true);
  };

  const handleOpenMyStoryOrCamera = () => {
    if (myActiveStory) {
      setActiveTimeShiftStory(myActiveStory);
      setIsTimeShiftStoryViewerOpen(true);
    } else {
      setIsTimeShiftCameraOpen(true);
    }
  };

  const joinedCount = useMemo(() => {
    return timeShiftStories.filter((s) => isStoryInJoinedCommunity(s) && s.status !== 'expired').length;
  }, [timeShiftStories, joinedGoalCommunityIds, joinedTempCommunityIds, joinedWorldIds]);

  const sprintCount = useMemo(() => {
    return timeShiftStories.filter((s) => (s.communityType === 'goal_community' || s.milestoneTag) && s.status !== 'expired').length;
  }, [timeShiftStories]);

  return (
    <div
      id="lifeos-living-stories-bar"
      className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-4 sm:p-5 transition-all overflow-hidden"
    >
      {/* Top Header & Context Filters */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-3.5">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-violet-600 via-fuchsia-600 to-amber-500 p-0.5 shadow-md shadow-violet-500/20">
            <div className="w-full h-full bg-white rounded-[10px] flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-black text-slate-900 tracking-tight flex items-center gap-1.5">
                Living Community Stories
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-100 text-amber-800 border border-amber-200/80">
                TIME-SHIFT 3D
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium">
              Interconnected stories from your living profile & joined communities
            </p>
          </div>
        </div>

        {/* Action Controls & Story Creator Trigger */}
        <div className="flex items-center gap-2 self-end sm:self-auto">
          <button
            id="btn-post-community-story"
            type="button"
            onClick={() => setIsTimeShiftCameraOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white text-xs font-bold shadow-xs hover:shadow-md transition-all cursor-pointer"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Post 3D Story</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs for Interconnected Community Context */}
      {!filterCommunityId && (
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-3.5 no-scrollbar text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveStoryFilter('all')}
            className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeStoryFilter === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>All Stories</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
              activeStoryFilter === 'all' ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
            }`}>
              {timeShiftStories.filter((s) => s.status !== 'expired').length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveStoryFilter('joined')}
            className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeStoryFilter === 'joined'
                ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-xs'
                : 'bg-violet-50 text-violet-700 hover:bg-violet-100 border border-violet-200/60'
            }`}
          >
            <Users className="w-3 h-3" />
            <span>Joined Communities</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
              activeStoryFilter === 'joined' ? 'bg-white/20 text-white' : 'bg-violet-200 text-violet-800'
            }`}>
              {joinedCount}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveStoryFilter('sprints')}
            className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeStoryFilter === 'sprints'
                ? 'bg-gradient-to-r from-rose-600 to-amber-600 text-white shadow-xs'
                : 'bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200/60'
            }`}
          >
            <Target className="w-3 h-3" />
            <span>Goal Sprints</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
              activeStoryFilter === 'sprints' ? 'bg-white/20 text-white' : 'bg-rose-200 text-rose-800'
            }`}>
              {sprintCount}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveStoryFilter('temporary')}
            className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeStoryFilter === 'temporary'
                ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Zap className="w-3 h-3 text-amber-500" />
            <span>Ephemeral Rooms</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveStoryFilter('profiles')}
            className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeStoryFilter === 'profiles'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Award className="w-3 h-3 text-emerald-500" />
            <span>Living Profiles</span>
          </button>
        </div>
      )}

      {/* Horizontal Scrollable Stories Carousel */}
      <div className="relative group/reel">
        <div className="flex items-start gap-4 overflow-x-auto pb-2 pt-1 no-scrollbar scroll-smooth">
          {/* 1. YOUR LIVING PROFILE STORY CARD / ADD STORY */}
          <div className="shrink-0 flex flex-col items-center text-center w-[86px]">
            <div className="relative group/mystory cursor-pointer" onClick={handleOpenMyStoryOrCamera}>
              {/* Outer Glowing Story Ring */}
              <div
                className={`w-[70px] h-[70px] rounded-full p-[3px] transition-all transform group-hover/mystory:scale-105 ${
                  myActiveStory
                    ? 'bg-gradient-to-tr from-amber-400 via-rose-500 to-violet-600 shadow-md shadow-rose-500/25 ring-2 ring-amber-400/40 animate-pulse'
                    : 'border-2 border-dashed border-slate-300 hover:border-violet-500 bg-slate-50'
                }`}
              >
                <img
                  src={livingUserProfile.avatar}
                  alt={livingUserProfile.name}
                  className="w-full h-full rounded-full object-cover border-2 border-white"
                />
              </div>

              {/* Status Badge */}
              {myActiveStory ? (
                <span
                  className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-800 p-1 rounded-full text-[10px] font-black shadow-md border-2 border-white"
                  title="Your Living Story is Active"
                >
                  <Eye className="w-3 h-3" />
                </span>
              ) : (
                <span
                  className="absolute -bottom-1 -right-1 bg-violet-600 text-white p-1 rounded-full text-[10px] font-black shadow-md border-2 border-white hover:bg-violet-700 transition-colors"
                  title="Create a new Time-Shift Story"
                >
                  <Plus className="w-3 h-3" />
                </span>
              )}
            </div>

            {/* Label */}
            <span className="mt-1.5 text-xs font-bold text-slate-900 truncate max-w-[84px]">
              {myActiveStory ? 'Your Story' : 'Add Story'}
            </span>
            <span className="text-[10px] font-semibold text-violet-600 font-mono">
              {myActiveStory ? `${myActiveStory.livePulse?.reactionsCount || 96} views` : '+ New'}
            </span>
          </div>

          {/* 2. COMMUNITY & PEER STORIES BUBBLES */}
          {filteredStories
            .filter((s) => s.id !== myActiveStory?.id)
            .map((story) => {
              const isJoined = isStoryInJoinedCommunity(story);
              const isGoalStory = story.communityType === 'goal_community';
              const isTempStory = story.communityType === 'temporary_community';
              const isWorldStory = story.communityType === 'world';

              return (
                <div
                  key={story.id}
                  id={`story-bubble-${story.id}`}
                  onClick={() => handleOpenStory(story)}
                  onMouseEnter={() => setHoveredStoryId(story.id)}
                  onMouseLeave={() => setHoveredStoryId(null)}
                  className="shrink-0 flex flex-col items-center text-center w-[88px] cursor-pointer group/bubble"
                >
                  {/* Story Avatar Frame with Thematic Gradient Ring */}
                  <div className="relative">
                    <div
                      className={`w-[70px] h-[70px] rounded-full p-[3px] transition-all transform group-hover/bubble:scale-108 group-hover/bubble:shadow-lg ${
                        isGoalStory
                          ? 'bg-gradient-to-tr from-rose-500 via-amber-500 to-orange-500 shadow-sm shadow-rose-500/20'
                          : isTempStory
                          ? 'bg-gradient-to-tr from-violet-600 via-indigo-600 to-blue-500 shadow-sm shadow-violet-500/20'
                          : isWorldStory
                          ? 'bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 shadow-sm shadow-cyan-500/20'
                          : 'bg-gradient-to-tr from-amber-400 to-rose-500'
                      }`}
                    >
                      <img
                        src={story.authorAvatar}
                        alt={story.authorName}
                        className="w-full h-full rounded-full object-cover border-2 border-white"
                      />
                    </div>

                    {/* Community Type Pill on Story */}
                    {story.communityName && (
                      <span
                        className="absolute -bottom-1 inset-x-0 mx-auto w-max max-w-[80px] px-1.5 py-0.2 rounded-full text-[8px] font-black uppercase tracking-tight text-white bg-slate-900/90 backdrop-blur-md border border-white/30 truncate shadow-xs"
                        title={`Connected Community: ${story.communityName}`}
                      >
                        {isGoalStory ? '🎯 ' : isTempStory ? '⚡ ' : '🌐 '}
                        {story.communityName.split(' ')[0]}
                      </span>
                    )}

                    {/* Live Pulse Indicator if Story is Trending / Has Active Viewers */}
                    {story.livePulse?.currentViewers > 0 && (
                      <span className="absolute top-0 right-0 flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500 border border-white" />
                      </span>
                    )}
                  </div>

                  {/* Author Name */}
                  <span className="mt-2 text-xs font-bold text-slate-800 group-hover/bubble:text-violet-600 transition-colors truncate max-w-[86px]">
                    {story.authorName.split(' ')[0]}
                  </span>

                  {/* Interconnected Milestone / Time Left Tag */}
                  <span className="text-[10px] text-slate-500 font-medium truncate max-w-[86px]">
                    {story.milestoneTag ? (
                      <span className="text-amber-600 font-bold">★ {story.milestoneTag.split(' ')[0]}</span>
                    ) : (
                      story.authorHandle
                    )}
                  </span>
                </div>
              );
            })}
        </div>
      </div>

      {/* Interconnected Community Highlight Banner if filtered */}
      {activeStoryFilter === 'joined' && (
        <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
          <div className="flex items-center gap-1.5 text-violet-700 font-semibold">
            <CheckCircle2 className="w-3.5 h-3.5 text-violet-600" />
            <span>Showing stories from your <strong>{goalCommunities.filter((c) => c.isJoined).length} Goal Sprints</strong> & <strong>{temporaryCommunities.filter((c) => c.isJoined).length} Temporary Rooms</strong></span>
          </div>
          <button
            type="button"
            onClick={() => showToast('🔗 Communities automatically sync active peer moments & milestone logs')}
            className="text-slate-400 hover:text-slate-700 text-[11px] underline"
          >
            How it works
          </button>
        </div>
      )}
    </div>
  );
};
