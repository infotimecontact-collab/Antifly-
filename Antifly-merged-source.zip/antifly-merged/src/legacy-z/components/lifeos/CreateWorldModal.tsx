import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Globe,
  Sparkles,
  MapPin,
  Clock,
  Lock,
  Layers,
  Image as ImageIcon,
} from 'lucide-react';
import { SocialWorld } from '../../types';

export const CreateWorldModal: React.FC = () => {
  const { isCreateWorldModalOpen, setIsCreateWorldModalOpen, createSocialWorld } = useApp();

  const [title, setTitle] = useState('');
  const [type, setType] = useState<SocialWorld['type']>('project');
  const [subtitle, setSubtitle] = useState('');
  const [description, setDescription] = useState('');
  const [locationZone, setLocationZone] = useState('San Francisco, CA');
  const [remainingDuration, setRemainingDuration] = useState('Active for 30 days');
  const [bannerImage, setBannerImage] = useState(
    'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1200&auto=format&fit=crop&q=80'
  );
  const [tags, setTags] = useState('AI, Founders, Sprint, SF');

  if (!isCreateWorldModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    createSocialWorld({
      title: title.trim(),
      type,
      subtitle: subtitle.trim() || 'Ephemeral collaborative space',
      description: description.trim(),
      locationZone,
      remainingDuration,
      bannerImage,
      tags: tags
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean),
    });

    setIsCreateWorldModalOpen(false);
    setTitle('');
    setDescription('');
  };

  const sampleBanners = [
    { label: 'Startup Tech', url: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1200&auto=format&fit=crop&q=80' },
    { label: 'Tokyo Urban', url: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=1200&auto=format&fit=crop&q=80' },
    { label: 'Studio & Art', url: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=1200&auto=format&fit=crop&q=80' },
    { label: 'Nature & Trek', url: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1200&auto=format&fit=crop&q=80' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 my-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold text-white">Create a Temporary Social World</h2>
              <p className="text-xs text-slate-400">
                Form an ephemeral realm around your upcoming trip, startup sprint, project, or event.
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsCreateWorldModalOpen(false)}
            className="p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Type Selector */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
              World Type
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {[
                { id: 'startup', label: '🚀 Startup' },
                { id: 'travel', label: '✈️ Travel' },
                { id: 'project', label: '🛠️ Project' },
                { id: 'event', label: '🎉 Event' },
                { id: 'learning', label: '📚 Learning' },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setType(t.id as any)}
                  className={`p-2 rounded-xl text-xs font-semibold border transition-all ${
                    type === t.id
                      ? 'bg-indigo-600 border-indigo-500 text-white shadow'
                      : 'bg-white border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Title */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
              World Title
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Tokyo AI Founders & Creatives Summit..."
              className="w-full bg-white border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 outline-none"
            />
          </div>

          {/* Description */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
              World Purpose & Goals
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Explain the mission of this temporary world, who should join, and what milestones you plan to achieve together..."
              className="w-full bg-white border border-slate-800 focus:border-indigo-500 rounded-xl p-3 text-xs text-white placeholder-slate-500 outline-none resize-none"
            />
          </div>

          {/* Location Zone & Duration */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Location Zone
              </label>
              <input
                type="text"
                value={locationZone}
                onChange={(e) => setLocationZone(e.target.value)}
                placeholder="e.g., San Francisco, CA or Tokyo, Japan"
                className="w-full bg-white border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 outline-none"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Lifespan / Duration
              </label>
              <input
                type="text"
                value={remainingDuration}
                onChange={(e) => setRemainingDuration(e.target.value)}
                placeholder="e.g., Active for 14 days"
                className="w-full bg-white border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 outline-none"
              />
            </div>
          </div>

          {/* Banner Image selector */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Banner Style
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {sampleBanners.map((sb, idx) => (
                <div
                  key={idx}
                  onClick={() => setBannerImage(sb.url)}
                  className={`relative rounded-xl overflow-hidden h-14 cursor-pointer border-2 transition-all ${
                    bannerImage === sb.url ? 'border-indigo-400 scale-105' : 'border-transparent opacity-60 hover:opacity-100'
                  }`}
                >
                  <img src={sb.url} alt={sb.label} className="w-full h-full object-cover" />
                  <span className="absolute bottom-1 left-1.5 text-[9px] font-bold text-white bg-white/80 px-1 py-0.2 rounded">
                    {sb.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Tags */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Tags / Keywords
            </label>
            <input
              type="text"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="Comma separated tags"
              className="w-full bg-white border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 outline-none"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsCreateWorldModalOpen(false)}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 hover:opacity-90 text-white text-xs sm:text-sm font-bold px-6 py-2.5 rounded-2xl shadow-xl active:scale-95 transition-all"
            >
              <Sparkles className="w-4 h-4" />
              <span>Launch Social World</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
