import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  MessageSquare,
  Send,
  Sparkles,
  Zap,
  ShieldCheck,
  Bot,
  X,
  CheckCircle2,
} from 'lucide-react';

export const ContextAwareChatModal: React.FC = () => {
  const {
    isContextAwareChatOpen,
    setIsContextAwareChatOpen,
    contextAwareChatPeer,
    setContextAwareChatPeer,
  } = useApp();

  const [message, setMessage] = useState<string>('');
  const [chatHistory, setChatHistory] = useState<
    Array<{ sender: 'user' | 'peer' | 'system'; text: string; time: string }>
  >([
    {
      sender: 'system',
      text: 'Synchronicity handshake verified. Both sovereign identities connected on mutual real-world intent.',
      time: 'Just now',
    },
  ]);

  if (!isContextAwareChatOpen || !contextAwareChatPeer) return null;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    const userMsg = message.trim();
    setChatHistory((prev) => [
      ...prev,
      { sender: 'user', text: userMsg, time: 'Just now' },
    ]);
    setMessage('');

    // Simulate intelligent peer response
    setTimeout(() => {
      setChatHistory((prev) => [
        ...prev,
        {
          sender: 'peer',
          text: `Great to connect! I saw your intent on LIFEOS regarding "${contextAwareChatPeer.sharedContext}". Let's sync this week.`,
          time: 'Just now',
        },
      ]);
    }, 1200);
  };

  const insertIcebreaker = (prompt: string) => {
    setMessage(prompt);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-100/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full p-6 space-y-5 shadow-2xl animate-scaleIn flex flex-col max-h-[85vh]">
        {/* Header with Peer Profile */}
        <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <img
              src={contextAwareChatPeer.avatar}
              alt={contextAwareChatPeer.name}
              className="w-12 h-12 rounded-2xl object-cover border border-slate-700 shadow"
            />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base text-white">{contextAwareChatPeer.name}</h3>
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
              </div>
              <p className="text-xs text-cyan-400 mt-0.5">{contextAwareChatPeer.sharedContext}</p>
            </div>
          </div>

          <button
            onClick={() => {
              setIsContextAwareChatOpen(false);
              setContextAwareChatPeer(null);
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Match Rationale / Why You Were Connected Banner */}
        <div className="bg-white/80 border border-slate-800/80 rounded-2xl p-3.5 space-y-1">
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-indigo-400">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Context Handshake Rationale</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            {contextAwareChatPeer.matchRationale}
          </p>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-1 min-h-[220px]">
          {chatHistory.map((item, idx) => (
            <div
              key={idx}
              className={`flex flex-col ${
                item.sender === 'user'
                  ? 'items-end'
                  : item.sender === 'peer'
                  ? 'items-start'
                  : 'items-center'
              }`}
            >
              {item.sender === 'system' ? (
                <div className="bg-white border border-slate-800/80 rounded-xl px-3 py-1 text-[11px] text-slate-400 text-center max-w-sm">
                  {item.text}
                </div>
              ) : (
                <div
                  className={`max-w-[80%] rounded-2xl p-3 text-xs leading-relaxed ${
                    item.sender === 'user'
                      ? 'bg-cyan-500 text-slate-800 font-medium'
                      : 'bg-slate-800 border border-slate-700 text-slate-100'
                  }`}
                >
                  <p>{item.text}</p>
                  <span
                    className={`text-[9px] block mt-1 ${
                      item.sender === 'user' ? 'text-cyan-950 font-bold text-right' : 'text-slate-400'
                    }`}
                  >
                    {item.time}
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* One-Tap Icebreakers */}
        <div className="space-y-1.5 pt-2 border-t border-slate-800">
          <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider">
            One-Tap Context Icebreakers
          </span>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() =>
                insertIcebreaker(
                  `Hi ${contextAwareChatPeer.name}, saw your work on ${contextAwareChatPeer.sharedContext}. Would love to collaborate!`
                )
              }
              className="text-[11px] px-2.5 py-1 rounded-xl bg-white border border-slate-800 text-slate-300 hover:text-cyan-300 hover:border-cyan-500/50 transition-all"
            >
              "Saw your work on {contextAwareChatPeer.sharedContext.slice(0, 20)}..."
            </button>
            <button
              onClick={() =>
                insertIcebreaker(
                  `Hey ${contextAwareChatPeer.name}! Are you free for a quick 15-min call this Thursday?`
                )
              }
              className="text-[11px] px-2.5 py-1 rounded-xl bg-white border border-slate-800 text-slate-300 hover:text-cyan-300 hover:border-cyan-500/50 transition-all"
            >
              "Quick 15-min sync this week?"
            </button>
          </div>
        </div>

        {/* Message Input Form */}
        <form onSubmit={handleSend} className="flex gap-2 pt-1">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder={`Message ${contextAwareChatPeer.name}...`}
            className="flex-1 bg-white border border-slate-800 text-xs text-slate-100 placeholder-slate-500 rounded-2xl px-4 py-2.5 outline-none focus:border-cyan-500"
          />
          <button
            type="submit"
            disabled={!message.trim()}
            className="p-2.5 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-slate-800 rounded-2xl transition-all shadow-md shadow-cyan-500/20 active:scale-95"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
