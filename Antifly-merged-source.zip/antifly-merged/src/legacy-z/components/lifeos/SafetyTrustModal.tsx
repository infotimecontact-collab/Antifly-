import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  ShieldCheck,
  Lock,
  EyeOff,
  UserCheck,
  KeyRound,
  CheckCircle2,
  AlertTriangle,
  Fingerprint,
} from 'lucide-react';

export const SafetyTrustModal: React.FC = () => {
  const { isSafetyTrustModalOpen, setIsSafetyTrustModalOpen, showToast } = useApp();

  if (!isSafetyTrustModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 my-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-extrabold text-white">Safety, Privacy & Trust Architecture</h2>
              <p className="text-xs text-slate-400">
                LIFEOS operates under strict sovereign human-first privacy standards.
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsSafetyTrustModalOpen(false)}
            className="p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Pillars Grid */}
        <div className="space-y-3">
          {[
            {
              title: 'Zero Exact GPS Tracking (Centroid Fuzzy Radar)',
              desc: 'Your precise location is never transmitted or stored. Centroid calculations round coordinates to broad 500m-2km fuzzy grid zones.',
              icon: EyeOff,
              status: 'Active & Enforced',
            },
            {
              title: 'Triple-Handshake Mutual Verification',
              desc: 'Connections occur only when both parties express mutual or complementary intent and approve via their private AI Twin.',
              icon: UserCheck,
              status: 'Guaranteed',
            },
            {
              title: 'Anti-Scam & Sybil Resistance',
              desc: 'Autonomous AI honeypots identify impersonation attempts, fake reviews, and cold automated outreach bots in real time.',
              icon: ShieldCheck,
              status: 'Real-time Guard',
            },
            {
              title: 'Zero Algorithmic Engagement Farming',
              desc: 'No endless outrage feeds, no follower vanity counts, and zero advertising broker data pipelines.',
              icon: Lock,
              status: 'Constitutionally Enforced',
            },
          ].map((pillar, idx) => {
            const Icon = pillar.icon;
            return (
              <div
                key={idx}
                className="p-4 rounded-2xl bg-white/70 border border-slate-800 flex items-start gap-3.5"
              >
                <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shrink-0">
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-white">{pillar.title}</h4>
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                      {pillar.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">{pillar.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Action button */}
        <div className="pt-2 flex justify-end">
          <button
            onClick={() => {
              showToast('🛡️ Privacy audit passed! Zero third-party trackers detected.');
              setIsSafetyTrustModalOpen(false);
            }}
            className="bg-emerald-500 hover:bg-emerald-400 text-slate-800 font-bold text-xs px-5 py-2.5 rounded-xl shadow transition-all"
          >
            Run Sovereign Privacy Audit
          </button>
        </div>
      </div>
    </div>
  );
};
