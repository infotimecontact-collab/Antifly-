import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  MessageSquareQuote,
  Sparkles,
  Heart,
  GitBranch,
  Share2,
  Plus,
  Send,
  Image as ImageIcon,
  MapPin,
  ShieldCheck,
  CheckCircle2,
  Users,
} from 'lucide-react';
import { ExperiencePostItem } from '../../types';

export const ExperienceContentFeed: React.FC = () => {
  const { experiencePosts, addExperiencePost, reactToExperiencePost, showToast } = useApp();

  const [newContent, setNewContent] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<'doing' | 'feeling' | 'learning' | 'building' | 'experiencing'>('experiencing');

  const handlePublishExperience = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContent.trim()) return;

    addExperiencePost({
      title: newTitle.trim() || undefined,
      content: newContent.trim(),
      contentType: 'moment',
      intent: {
        category: newCategory,
        statement: `Active moment in ${newCategory}`,
      },
    });

    setNewContent('');
    setNewTitle('');
  };

  return (
    <div className="space-y-6 pb-16 max-w-3xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950/40 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 space-y-2 shadow-2xl">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-bold">
          <MessageSquareQuote className="w-3.5 h-3.5" />
          <span>Intent-Driven Experience Stream • Human-First & Branchable</span>
        </div>
        <h1 className="text-2xl font-extrabold text-white">
          Real Experiences, Real Growth
        </h1>
        <p className="text-xs sm:text-sm text-slate-300">
          No algorithmic outrage or vanity follower chasing. Every post represents authentic intent and lived reality.
        </p>
      </div>

      {/* Share Box */}
      <form onSubmit={handlePublishExperience} className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-xl">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-400">Expressing:</span>
          {(['experiencing', 'building', 'learning', 'doing'] as const).map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setNewCategory(cat)}
              className={`px-3 py-1 rounded-xl text-xs font-bold capitalize transition-all ${
                newCategory === cat
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-white text-slate-400 border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <input
          type="text"
          value={newTitle}
          onChange={(e) => setNewTitle(e.target.value)}
          placeholder="Experience headline (optional)..."
          className="w-full bg-white border border-slate-800 rounded-xl px-4 py-2 text-xs text-white placeholder-slate-500 outline-none"
        />

        <textarea
          rows={3}
          required
          value={newContent}
          onChange={(e) => setNewContent(e.target.value)}
          placeholder="Share what you experienced, what worked, what failed, or what you learned..."
          className="w-full bg-white border border-slate-800 rounded-2xl p-4 text-xs sm:text-sm text-white placeholder-slate-500 outline-none resize-none"
        />

        <div className="flex items-center justify-between pt-1">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <MapPin className="w-3.5 h-3.5 text-cyan-400" />
            <span>SOMA, San Francisco</span>
          </div>

          <button
            type="submit"
            className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-400 hover:to-indigo-500 text-white text-xs sm:text-sm font-bold px-5 py-2 rounded-2xl shadow-lg active:scale-95 transition-all"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Publish Moment</span>
          </button>
        </div>
      </form>

      {/* Experience Posts Stream */}
      <div className="space-y-6">
        {experiencePosts.map((post) => (
          <div
            key={post.id}
            className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl hover:border-slate-700 transition-all"
          >
            {/* Author Bar */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={post.author.avatar}
                  alt={post.author.name}
                  className="w-10 h-10 rounded-2xl object-cover border border-slate-700"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-sm text-white">{post.author.name}</h4>
                    <span className="text-xs text-slate-400">{post.author.handle}</span>
                  </div>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    {post.author.verifiedProof.map((vp, idx) => (
                      <span
                        key={idx}
                        className="text-[9px] font-bold bg-white text-cyan-400 border border-slate-800 px-1.5 py-0.2 rounded"
                      >
                        ✓ {vp}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <span className="text-xs text-slate-500">{post.timestamp}</span>
            </div>

            {/* Intent Badge */}
            <div className="bg-white/80 p-2.5 rounded-xl border border-slate-800 text-xs text-slate-300 flex items-center justify-between">
              <span className="flex items-center gap-1.5 font-semibold text-blue-300">
                <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                Intent: {post.intent.statement}
              </span>
              <span className="text-[10px] uppercase font-bold text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                {post.intent.category}
              </span>
            </div>

            {/* Post Title & Content */}
            {post.title && <h3 className="font-extrabold text-base text-white">{post.title}</h3>}
            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-line">
              {post.content}
            </p>

            {/* Post Media */}
            {post.mediaUrl && (
              <div className="rounded-2xl overflow-hidden max-h-80 border border-slate-800">
                <img src={post.mediaUrl} alt="Experience Media" className="w-full h-full object-cover" />
              </div>
            )}

            {/* Tags */}
            <div className="flex flex-wrap gap-1">
              {post.tags.map((t, idx) => (
                <span
                  key={idx}
                  className="text-[10px] font-medium bg-white text-slate-400 border border-slate-800 px-2 py-0.5 rounded-md"
                >
                  #{t}
                </span>
              ))}
            </div>

            {/* Meaningful Reactions Strip & Branching */}
            <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                {[
                  { key: 'relate', label: 'Relate', icon: '🤝', count: post.reactions.relate },
                  { key: 'understand', label: 'Understand', icon: '💡', count: post.reactions.understand },
                  { key: 'collaborate', label: 'Collaborate', icon: '⚡', count: post.reactions.collaborate },
                  { key: 'insightful', label: 'Insightful', icon: '✨', count: post.reactions.insightful },
                ].map((r) => {
                  const isSelected = post.userReaction === r.key;
                  return (
                    <button
                      key={r.key}
                      onClick={() => reactToExperiencePost(post.id, r.key as any)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition-all ${
                        isSelected
                          ? 'bg-blue-600/30 border-blue-500 text-blue-300 font-bold'
                          : 'bg-white border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-white'
                      }`}
                    >
                      <span>{r.icon}</span>
                      <span>{r.label}</span>
                      <span className="text-[10px] font-bold text-slate-300 ml-0.5">{r.count}</span>
                    </button>
                  );
                })}
              </div>

              {/* Collaborative Branch */}
              <button
                onClick={() => showToast('🌿 Forked collaborative branch! You can now add your perspective.')}
                className="flex items-center gap-1.5 text-xs font-bold text-indigo-400 hover:text-indigo-300 bg-indigo-950/40 border border-indigo-900 px-3 py-1.5 rounded-xl transition-colors"
              >
                <GitBranch className="w-3.5 h-3.5" />
                <span>Branch ({post.branchesCount})</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
