import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Flame,
  Users,
  Sparkles,
  ArrowRight,
  Plus,
  MapPin,
  TrendingUp,
} from 'lucide-react';

export const CommunityEmergenceModal: React.FC = () => {
  const {
    isEmergentCommunityModalOpen,
    setIsEmergentCommunityModalOpen,
    createSocialWorld,
    setActiveLifeOSTab,
    showToast,
  } = useApp();

  if (!isEmergentCommunityModalOpen) return null;

  const emergentClusters = [
    {
      id: 'cluster_spatial',
      title: 'Spatial Robotics & Embodied AI Builders',
      detectedCount: 1420,
      zone: 'San Francisco & Bay Area',
      growth: '+42% this week',
      description: 'High concentration of developers, hardware engineers, and founders seeking weekly prototyping co-working.',
      suggestedType: 'startup',
    },
    {
      id: 'cluster_tokyo',
      title: 'Autumn Tokyo Urban Photographers & Solo Explorers',
      detectedCount: 890,
      zone: 'Tokyo & Kyoto (Sept-Oct)',
      growth: '+68% this week',
      description: 'Travelers arriving in Japan seeking photo walks, izakaya meetups, and local architectural guides.',
      suggestedType: 'travel',
    },
    {
      id: 'cluster_rust',
      title: 'High-Performance Rust Systems & WebAssembly',
      detectedCount: 650,
      zone: 'Global Remote',
      growth: '+28% this week',
      description: 'Engineers building kernel-level async runtimes and distributed GPU schedulers.',
      suggestedType: 'project',
    },
  ];

  const handleLaunchEmergentWorld = (cluster: typeof emergentClusters[0]) => {
    createSocialWorld({
      title: cluster.title,
      type: cluster.suggestedType as any,
      subtitle: `Emergent Community automatically formed by LIFEOS (${cluster.detectedCount} matching minds)`,
      description: cluster.description,
      locationZone: cluster.zone,
      tags: ['Emergent', 'Autonomous', 'LIFEOS'],
    });
    setIsEmergentCommunityModalOpen(false);
    setActiveLifeOSTab('worlds');
    showToast(`🔥 Emergent World "${cluster.title}" created with 1-click!`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 my-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Flame className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-extrabold text-white">Emergent AI Communities</h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-950 text-amber-400 border border-amber-800 text-[10px] font-extrabold uppercase">
                  Autonomous Clusters
                </span>
              </div>
              <p className="text-xs text-slate-400">
                LIFEOS detected dense clusters of matching intentions ready to self-organize.
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsEmergentCommunityModalOpen(false)}
            className="p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3.5">
          {emergentClusters.map((cluster) => (
            <div
              key={cluster.id}
              className="p-5 rounded-3xl bg-white/80 border border-slate-800 hover:border-amber-500/50 space-y-3 transition-all"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-extrabold text-amber-400 flex items-center gap-1">
                      <Users className="w-3.5 h-3.5" /> {cluster.detectedCount.toLocaleString()} Intent Overlaps
                    </span>
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950 px-1.5 py-0.2 rounded border border-emerald-800">
                      {cluster.growth}
                    </span>
                  </div>
                  <h4 className="text-base font-bold text-white">{cluster.title}</h4>
                </div>
                <span className="text-xs text-slate-400 font-medium flex items-center gap-1 bg-slate-900 px-2.5 py-1 rounded-xl border border-slate-800 shrink-0">
                  <MapPin className="w-3 h-3 text-cyan-400" /> {cluster.zone}
                </span>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                {cluster.description}
              </p>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  Ready to spawn as an ephemeral Social World
                </span>
                <button
                  onClick={() => handleLaunchEmergentWorld(cluster)}
                  className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-md flex items-center gap-1.5 active:scale-95 transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Spawn Social World</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
