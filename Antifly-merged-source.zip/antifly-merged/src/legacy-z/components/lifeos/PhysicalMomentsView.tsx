import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  MapPin,
  Sparkles,
  Users,
  Clock,
  Archive,
  MessageSquare,
  ShieldCheck,
  CheckCircle2,
  Share2,
  Compass,
  Radio,
  PlusCircle,
} from 'lucide-react';
import { LifeOSMoment } from '../../types';

export const PhysicalMomentsView: React.FC = () => {
  const { lifeOSMoments, archiveMomentToMemory, setContextAwareChatPeer, setIsContextAwareChatOpen } = useApp();

  const [activeVenueType, setActiveVenueType] = useState<string>('all');

  const venues = [
    { id: 'all', label: 'All Live Moments' },
    { id: 'conference', label: 'Conferences & Summits' },
    { id: 'hackathon', label: 'Hackathons & Dens' },
    { id: 'cafe', label: 'Cafes & Co-Working' },
    { id: 'airport', label: 'Airports & Lounges' },
  ];

  const filteredMoments = lifeOSMoments.filter((moment) => {
    if (activeVenueType !== 'all' && moment.venueType !== activeVenueType) return false;
    return true;
  });

  const handleAttendeeChat = (
    moment: LifeOSMoment,
    attendee: { name: string; avatar: string; headline: string; intentHere: string }
  ) => {
    setContextAwareChatPeer({
      name: attendee.name,
      avatar: attendee.avatar,
      sharedContext: `Co-located at "${moment.venueName}" (${moment.city})`,
      matchRationale: `Intent at venue: "${attendee.intentHere}"`,
    });
    setIsContextAwareChatOpen(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8 animate-fadeIn">
      {/* Hero Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-amber-950/40 to-slate-950 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute -right-16 -top-16 w-80 h-80 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-950/80 border border-amber-800 text-amber-400 text-xs font-semibold">
              <MapPin className="w-3.5 h-3.5" />
              <span>Contextual Physical Presence Layer</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Physical Moments & Venue Synchronicities
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              When you step into a physical venue—hackathon, airport lounge, cafe, or conference hall—LIFEOS dynamically connects you with people whose active intentions intersect yours in that exact room.
            </p>
          </div>

          <div className="bg-white/80 border border-slate-800 p-4 rounded-2xl text-xs space-y-1.5 max-w-xs">
            <div className="flex items-center gap-2 text-emerald-400 font-bold">
              <Radio className="w-4 h-4 animate-pulse" />
              <span>Location Fuzzing Active</span>
            </div>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Precise coordinates are never broadcast. Geofences operate within a protected ±500m privacy halo.
            </p>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-none pb-1">
        {venues.map((v) => (
          <button
            key={v.id}
            onClick={() => setActiveVenueType(v.id)}
            className={`px-4 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all ${
              activeVenueType === v.id
                ? 'bg-amber-500 text-slate-800 shadow-lg shadow-amber-500/25'
                : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800'
            }`}
          >
            {v.label}
          </button>
        ))}
      </div>

      {/* Moments List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredMoments.map((moment) => (
          <div
            key={moment.id}
            className="bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-3xl p-6 space-y-5 shadow-2xl flex flex-col justify-between group transition-all"
          >
            <div className="space-y-4">
              {/* Top Venue Bar */}
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-amber-950/80 border border-amber-800 text-amber-400 text-[10px] font-bold uppercase tracking-wider">
                      {moment.venueType}
                    </span>
                    <span className="text-xs text-slate-400 flex items-center gap-1 font-medium">
                      <Clock className="w-3.5 h-3.5 text-slate-500" />
                      {moment.timeWindow}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-white mt-1 group-hover:text-amber-300 transition-colors">
                    {moment.venueName}
                  </h3>
                  <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-amber-400" />
                    {moment.city} • Radius {moment.radiusMeters}m
                  </p>
                </div>

                <div className="text-right">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-800 text-emerald-400 text-xs font-bold">
                    <Users className="w-3.5 h-3.5" />
                    <span>{moment.attendeesCount} Present</span>
                  </span>
                </div>
              </div>

              {/* Shared Intent in the Space */}
              <div className="bg-white/70 border border-slate-800/80 rounded-2xl p-3.5 space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block">
                  Collective Energy & Intent
                </span>
                <p className="text-xs text-slate-300 italic">
                  "{moment.sharedIntent}"
                </p>
              </div>

              {/* Verified Co-Located Attendees */}
              <div className="space-y-2.5">
                <span className="text-xs font-bold text-slate-300 block">
                  Present Builders With Intersecting Goals
                </span>
                <div className="space-y-2">
                  {moment.verifiedAttendees.map((att, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-2xl bg-white/90 border border-slate-800 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-2.5">
                        <img
                          src={att.avatar}
                          alt={att.name}
                          className="w-10 h-10 rounded-xl object-cover border border-slate-700"
                        />
                        <div>
                          <div className="flex items-center gap-1">
                            <span className="font-bold text-xs text-white">{att.name}</span>
                            <span className="text-[10px] text-amber-400 font-semibold">• {att.headline}</span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-0.5">
                            Intent: <span className="text-slate-300">"{att.intentHere}"</span>
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => handleAttendeeChat(moment, att)}
                        className="p-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-800 transition-colors shadow-md shadow-amber-500/20"
                        title="Say Hello via Context Chat"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between gap-3">
              <button
                onClick={() => archiveMomentToMemory(moment.id)}
                className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl border transition-all ${
                  moment.isArchived
                    ? 'bg-white border-slate-800 text-emerald-400'
                    : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Archive className="w-3.5 h-3.5" />
                <span>{moment.isArchived ? 'Saved to Memory' : 'Save Moment to AI Memory'}</span>
              </button>

              <span className="text-[11px] text-slate-500">
                Auto-dissolves at window end
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
