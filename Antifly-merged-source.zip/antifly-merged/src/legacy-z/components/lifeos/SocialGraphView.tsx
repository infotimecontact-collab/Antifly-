import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Network,
  Users,
  Building2,
  Calendar,
  BookOpen,
  Briefcase,
  MapPin,
  Sparkles,
  Info,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { RelationshipGraphNode } from '../../types';

export const SocialGraphView: React.FC = () => {
  const { relationshipNodes, showToast } = useApp();
  const [selectedNode, setSelectedNode] = useState<RelationshipGraphNode>(relationshipNodes[0]);
  const [filterType, setFilterType] = useState<string>('all');

  const filteredNodes = relationshipNodes.filter((n) => {
    if (filterType !== 'all' && n.type !== filterType) return false;
    return true;
  });

  const nodeIcons: Record<string, any> = {
    person: Users,
    community: Users,
    business: Building2,
    event: Calendar,
    knowledge: BookOpen,
    opportunity: Briefcase,
    place: MapPin,
  };

  const nodeColors: Record<string, { bg: string; text: string; border: string }> = {
    person: { bg: 'bg-cyan-500/20', text: 'text-cyan-400', border: 'border-cyan-500/50' },
    community: { bg: 'bg-indigo-500/20', text: 'text-indigo-400', border: 'border-indigo-500/50' },
    business: { bg: 'bg-purple-500/20', text: 'text-purple-400', border: 'border-purple-500/50' },
    event: { bg: 'bg-amber-500/20', text: 'text-amber-400', border: 'border-amber-500/50' },
    knowledge: { bg: 'bg-emerald-500/20', text: 'text-emerald-400', border: 'border-emerald-500/50' },
    opportunity: { bg: 'bg-rose-500/20', text: 'text-rose-400', border: 'border-rose-500/50' },
    place: { bg: 'bg-teal-500/20', text: 'text-teal-400', border: 'border-teal-500/50' },
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-purple-950/40 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-2xl">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-400 text-xs font-bold">
            <Network className="w-3.5 h-3.5" />
            <span>Universal Relationship Graph • Multi-Dimensional Social Topology</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Living Social & Intent Graph
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
            Unlike follower counts, the LIFEOS graph maps multidirectional affinities: People ↔ Communities ↔ Businesses ↔ Events ↔ Knowledge ↔ Opportunities ↔ Places.
          </p>
        </div>

        {/* Total Nodes Badge */}
        <div className="bg-white/80 border border-slate-800 p-4 rounded-2xl space-y-1 text-xs shrink-0">
          <p className="text-slate-400 font-medium">ACTIVE TOPOLOGY</p>
          <p className="font-extrabold text-purple-300 text-base">{relationshipNodes.length} Linked Nodes</p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1">
        {['all', 'person', 'community', 'business', 'event', 'knowledge', 'opportunity', 'place'].map((t) => (
          <button
            key={t}
            onClick={() => setFilterType(t)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize whitespace-nowrap transition-all ${
              filterType === t
                ? 'bg-purple-600 text-white shadow'
                : 'bg-slate-900/80 text-slate-400 border border-slate-800 hover:text-white'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Graph Visualizer & Node Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Interactive Graph Canvas */}
        <div className="lg:col-span-2 bg-white border border-slate-800 rounded-3xl p-6 min-h-[460px] relative overflow-hidden flex items-center justify-center shadow-2xl">
          {/* Subtle Grid Canvas */}
          <div className="absolute inset-0 bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:24px_24px] opacity-20 pointer-events-none" />

          {/* SVG Connecting Lines between Nodes */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            {filteredNodes.map((n, i) => {
              const angle1 = (i * 360) / filteredNodes.length;
              const rad1 = (angle1 * Math.PI) / 180;
              const x1 = 300 + Math.cos(rad1) * 160;
              const y1 = 230 + Math.sin(rad1) * 150;

              return (
                <line
                  key={i}
                  x1={300}
                  y1={230}
                  x2={x1}
                  y2={y1}
                  stroke="rgba(168, 85, 247, 0.25)"
                  strokeWidth="1.5"
                  strokeDasharray="4 4"
                />
              );
            })}
          </svg>

          {/* Center User Hub Node */}
          <div className="relative z-10 flex flex-col items-center">
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-purple-500 via-indigo-500 to-cyan-500 p-0.5 shadow-xl shadow-purple-500/30">
              <div className="w-full h-full bg-white rounded-[22px] flex items-center justify-center">
                <Sparkles className="w-7 h-7 text-purple-400" />
              </div>
            </div>
            <span className="text-xs font-extrabold text-white mt-2 bg-slate-900/90 px-3 py-1 rounded-full border border-slate-700">
              Alex Rivera (You)
            </span>
          </div>

          {/* Orbiting Graph Nodes */}
          {filteredNodes.map((node, idx) => {
            const angle = (idx * 360) / filteredNodes.length;
            const rad = (angle * Math.PI) / 180;
            const x = Math.cos(rad) * 160;
            const y = Math.sin(rad) * 150;

            const isSelected = selectedNode?.id === node.id;
            const Icon = nodeIcons[node.type] || Users;
            const col = nodeColors[node.type] || nodeColors.person;

            return (
              <div
                key={node.id}
                style={{
                  transform: `translate(${x}px, ${y}px)`,
                }}
                onClick={() => setSelectedNode(node)}
                className={`absolute z-20 cursor-pointer transition-all duration-300 ${
                  isSelected ? 'scale-125 z-30 ring-2 ring-purple-400' : 'hover:scale-110'
                }`}
              >
                <div
                  className={`flex items-center gap-1.5 p-2 rounded-2xl bg-slate-900/95 border backdrop-blur-md shadow-xl ${col.border}`}
                >
                  <div className={`p-1.5 rounded-xl ${col.bg} ${col.text}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="text-left pr-1">
                    <p className="text-[10px] font-extrabold text-white truncate max-w-[90px]">
                      {node.name}
                    </p>
                    <p className="text-[8px] text-slate-400 capitalize">{node.type}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Node Detailed Inspector */}
        <div className="space-y-4">
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-2xl">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div
                  className={`p-3 rounded-2xl border ${nodeColors[selectedNode.type]?.bg} ${nodeColors[selectedNode.type]?.border}`}
                >
                  {React.createElement(nodeIcons[selectedNode.type] || Users, {
                    className: `w-6 h-6 ${nodeColors[selectedNode.type]?.text}`,
                  })}
                </div>
                <div>
                  <span className="text-[10px] uppercase font-extrabold text-purple-400 tracking-wider">
                    {selectedNode.type} Node
                  </span>
                  <h3 className="text-lg font-bold text-white">{selectedNode.name}</h3>
                  <p className="text-xs text-slate-400">{selectedNode.headline}</p>
                </div>
              </div>
            </div>

            {/* Affinity Strength Meter */}
            <div className="space-y-1.5 bg-white/80 p-3 rounded-2xl border border-slate-800">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-semibold">Graph Affinity Score:</span>
                <span className="text-emerald-400 font-extrabold">{selectedNode.affinityScore}%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-purple-500 to-emerald-400 rounded-full"
                  style={{ width: `${selectedNode.affinityScore}%` }}
                />
              </div>
            </div>

            {/* Mutual Intent Intersections */}
            <div className="space-y-2">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Mutual Intent Overlaps:
              </p>
              <div className="flex flex-wrap gap-1.5">
                {selectedNode.mutualIntents.map((intent, idx) => (
                  <span
                    key={idx}
                    className="text-xs bg-purple-950/70 border border-purple-800 text-purple-300 px-2.5 py-1 rounded-xl font-medium"
                  >
                    ✨ {intent}
                  </span>
                ))}
              </div>
            </div>

            {/* Connections In Common */}
            <div className="space-y-1.5">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Topology Relationships:
              </p>
              <p className="text-xs text-slate-400">
                Connected with <strong className="text-slate-200">{selectedNode.connectedNodesCount}</strong> other nodes in San Francisco & Tokyo clusters.
              </p>
            </div>

            {/* Actions */}
            <button
              onClick={() => showToast(`🤝 Dispatched introduction through relationship graph with ${selectedNode.name}!`)}
              className="w-full bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold py-3 rounded-2xl shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              <span>Explore Direct Edge</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
