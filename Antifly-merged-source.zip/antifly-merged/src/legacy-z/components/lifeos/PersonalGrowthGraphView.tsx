import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  TrendingUp,
  Sparkles,
  Zap,
  Award,
  CheckCircle2,
  Calendar,
  Layers,
  ShieldCheck,
  PlusCircle,
  ArrowRight,
  Filter,
} from 'lucide-react';
import { PersonalGrowthNode } from '../../types';

export const PersonalGrowthGraphView: React.FC = () => {
  const { personalGrowthNodes, addPersonalGrowthNode, contributionReputation } = useApp();

  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);

  const [newTitle, setNewTitle] = useState<string>('');
  const [newDescription, setNewDescription] = useState<string>('');
  const [newCategory, setNewCategory] = useState<any>('project_shipped');
  const [newSkills, setNewSkills] = useState<string>('');
  const [newImpact, setNewImpact] = useState<string>('');

  const categories = [
    { id: 'all', label: 'Complete Timeline' },
    { id: 'project_shipped', label: 'Projects Shipped' },
    { id: 'skill_mastered', label: 'Skills Mastered' },
    { id: 'relationship_formed', label: 'Key Relationships' },
    { id: 'community_led', label: 'Community Leadership' },
  ];

  const filteredNodes = personalGrowthNodes.filter((node) => {
    if (activeCategory !== 'all' && node.category !== activeCategory) return false;
    return true;
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    addPersonalGrowthNode({
      category: newCategory,
      title: newTitle,
      description: newDescription,
      date: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
      skillsGained: newSkills.split(',').map((s) => s.trim()).filter(Boolean),
      peopleInvolved: ['Collaborative Network'],
      verifiedByEvidence: true,
      impactMetrics: newImpact || 'High velocity milestone',
    });

    setNewTitle('');
    setNewDescription('');
    setNewSkills('');
    setNewImpact('');
    setShowAddModal(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8 animate-fadeIn">
      {/* Hero Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-teal-950/40 to-slate-950 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute -right-16 -top-16 w-80 h-80 rounded-full bg-teal-500/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-950/80 border border-teal-800 text-teal-400 text-xs font-semibold">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>Living Evolutionary Journey</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Personal Growth & Evolution Graph
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              A private, cryptographic record of your human and technical evolution. Reflect on breakthroughs, shipped systems, mentors who believed in you, and your lifelong compound momentum.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="bg-white/80 border border-slate-800 p-4 rounded-2xl text-xs space-y-1 text-center min-w-[130px]">
              <span className="text-slate-400 block">Reputation Score</span>
              <span className="text-xl font-bold text-amber-400 block flex items-center justify-center gap-1">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                {contributionReputation.score} pts
              </span>
              <span className="text-[10px] text-slate-500 block uppercase tracking-wider">
                {contributionReputation.tier}
              </span>
            </div>

            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 bg-gradient-to-r from-teal-500 to-cyan-600 hover:from-teal-400 hover:to-cyan-500 text-slate-800 text-xs font-extrabold px-5 py-3 rounded-2xl shadow-lg shadow-teal-500/20 active:scale-95 transition-all whitespace-nowrap"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Log Milestone</span>
            </button>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-none pb-1">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-4 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all ${
              activeCategory === cat.id
                ? 'bg-teal-600 text-white shadow-lg shadow-teal-600/25'
                : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Timeline Visualization */}
      <div className="relative pl-6 sm:pl-8 border-l border-slate-800 space-y-8 max-w-4xl mx-auto">
        {filteredNodes.map((node) => (
          <div key={node.id} className="relative group">
            {/* Timeline Dot */}
            <div className="absolute -left-[31px] sm:-left-[39px] top-1.5 w-4 h-4 rounded-full bg-teal-500 border-4 border-slate-200 group-hover:scale-125 transition-transform" />

            <div className="bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-3xl p-5 sm:p-6 space-y-3 shadow-xl transition-all">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-teal-950/80 border border-teal-800 text-teal-400 text-[10px] font-bold uppercase tracking-wider">
                    {node.category.replace('_', ' ')}
                  </span>
                  {node.verifiedByEvidence && (
                    <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 font-semibold bg-emerald-950/60 border border-emerald-800/80 px-2 py-0.5 rounded-md">
                      <ShieldCheck className="w-3 h-3" />
                      Verified Proof
                    </span>
                  )}
                </div>

                <span className="text-xs text-slate-400 font-medium flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-500" />
                  {node.date}
                </span>
              </div>

              <div>
                <h3 className="font-bold text-base text-white">{node.title}</h3>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">{node.description}</p>
              </div>

              {node.impactMetrics && (
                <div className="bg-white/70 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-300 flex items-center gap-2">
                  <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Impact: {node.impactMetrics}</span>
                </div>
              )}

              {/* Skills Gained Tags */}
              {node.skillsGained && node.skillsGained.length > 0 && (
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {node.skillsGained.map((skill, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded-md bg-white text-teal-300 text-[10px] border border-slate-800 font-medium"
                    >
                      +{skill}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Log Milestone Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-100/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl animate-scaleIn">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-teal-400" />
                <h3 className="text-lg font-bold text-white">Log Growth Milestone</h3>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-4">
              <div>
                <label className="text-xs text-slate-300 font-semibold block mb-1">
                  Category
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="w-full bg-white border border-slate-800 text-xs text-slate-200 rounded-xl px-3 py-2.5 outline-none"
                >
                  <option value="project_shipped">Project Shipped</option>
                  <option value="skill_mastered">Skill Mastered</option>
                  <option value="relationship_formed">Key Relationship Formed</option>
                  <option value="community_led">Community Leadership</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-slate-300 font-semibold block mb-1">
                  Milestone Title
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Deployed Multimodal Edge Agent to 5,000 active nodes"
                  className="w-full bg-white border border-slate-800 text-xs text-slate-100 rounded-xl px-3 py-2.5 outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 font-semibold block mb-1">
                  Description & Context
                </label>
                <textarea
                  rows={3}
                  required
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder="What was difficult? What breakthrough did you experience? What did you learn?"
                  className="w-full bg-white border border-slate-800 text-xs text-slate-100 rounded-xl p-3 outline-none focus:border-teal-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-300 font-semibold block mb-1">
                    Skills Gained (comma separated)
                  </label>
                  <input
                    type="text"
                    value={newSkills}
                    onChange={(e) => setNewSkills(e.target.value)}
                    placeholder="WebAssembly, C++, PyTorch"
                    className="w-full bg-white border border-slate-800 text-xs text-slate-100 rounded-xl px-3 py-2 outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-300 font-semibold block mb-1">
                    Measurable Impact
                  </label>
                  <input
                    type="text"
                    value={newImpact}
                    onChange={(e) => setNewImpact(e.target.value)}
                    placeholder="e.g. 5,000 active nodes, 10x latency drop"
                    className="w-full bg-white border border-slate-800 text-xs text-slate-100 rounded-xl px-3 py-2 outline-none"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-800 text-xs font-bold shadow-lg shadow-teal-500/20"
                >
                  Save to Growth Graph
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
