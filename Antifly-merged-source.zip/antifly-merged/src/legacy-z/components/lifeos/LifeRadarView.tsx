import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Radar,
  Sparkles,
  Zap,
  UserCheck,
  Building,
  GraduationCap,
  Users,
  Calendar,
  Briefcase,
  Layers,
  MapPin,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Filter,
  ArrowUpRight,
  Bot,
  Flame,
  Search,
  SlidersHorizontal,
} from 'lucide-react';
import { LifeRadarOpportunity } from '../../types';

export const LifeRadarView: React.FC = () => {
  const {
    lifeRadarOpportunities,
    updateRadarOpportunityStatus,
    setContextAwareChatPeer,
    setIsContextAwareChatOpen,
    setIsLifeIntentModalOpen,
    setIsLifeOSAgentModalOpen,
  } = useApp();

  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [minMatchScore, setMinMatchScore] = useState<number>(85);
  const [searchFilter, setSearchFilter] = useState<string>('');

  const categories = [
    { id: 'all', label: 'All Opportunities', count: lifeRadarOpportunities.filter((r) => !r.isIgnored).length },
    { id: 'co_founder', label: 'Co-Founders', icon: Users },
    { id: 'developer', label: 'Developers & Systems', icon: Zap },
    { id: 'investor', label: 'Investors & Angels', icon: Briefcase },
    { id: 'mentor', label: 'Mentors & Advisors', icon: GraduationCap },
    { id: 'customer', label: 'Beta Customers & Labs', icon: Building },
    { id: 'community', label: 'Goal Communities', icon: Users },
    { id: 'event', label: 'Physical Events', icon: Calendar },
  ];

  const filteredOpportunities = lifeRadarOpportunities.filter((item) => {
    if (item.isIgnored) return false;
    if (activeCategory !== 'all' && item.category !== activeCategory) return false;
    if (item.matchScore < minMatchScore) return false;
    if (searchFilter.trim()) {
      const q = searchFilter.toLowerCase();
      const matchText = (item.title + ' ' + (item.name || '') + ' ' + (item.whyItMatters || '') + ' ' + (item.locationZone || '')).toLowerCase();
      if (!matchText.includes(q)) return false;
    }
    return true;
  });

  const handleAction = (item: LifeRadarOpportunity) => {
    if (item.status === 'available') {
      updateRadarOpportunityStatus(item.id, 'requested');
    } else if (item.status === 'requested') {
      updateRadarOpportunityStatus(item.id, 'connected');
      if (item.name) {
        setContextAwareChatPeer({
          name: item.name,
          avatar: item.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
          sharedContext: item.whyItMatters,
          matchRationale: item.purposeCompatibility.rationale,
        });
        setIsContextAwareChatOpen(true);
      }
    } else if (item.status === 'connected' && item.name) {
      setContextAwareChatPeer({
        name: item.name,
        avatar: item.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
        sharedContext: item.whyItMatters,
        matchRationale: item.purposeCompatibility.rationale,
      });
      setIsContextAwareChatOpen(true);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8 animate-fadeIn">
      {/* Radar Hero Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/60 to-slate-950 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute -right-16 -top-16 w-80 h-80 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />
        <div className="absolute right-32 bottom-0 w-64 h-64 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-800 text-cyan-400 text-xs font-semibold">
              <Radar className="w-3.5 h-3.5 animate-spin text-cyan-400" />
              <span>Real-Time Autonomous Signal Scanner</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Life Radar & Synchronicity Field
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              Continuously cross-referencing your active goals, skills, availability, and geographic context to surface highest-probability human connections, collaborators, capital, and real-world moments.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setIsLifeOSAgentModalOpen(true)}
              className="flex items-center gap-2 bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold px-4 py-2.5 rounded-xl shadow-lg transition-all"
            >
              <Bot className="w-4 h-4 text-indigo-400" />
              <span>Configure Radar Agent</span>
            </button>
            <button
              onClick={() => setIsLifeIntentModalOpen(true)}
              className="flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-cyan-500/25 active:scale-95 transition-all"
            >
              <Sparkles className="w-4 h-4" />
              <span>Broadcast New Intent</span>
            </button>
          </div>
        </div>

        {/* Live Signal Telemetry Bar */}
        <div className="mt-6 pt-5 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div className="bg-white/60 border border-slate-800/80 rounded-2xl p-3">
            <span className="text-slate-400 block text-[11px]">Active Signals Analyzed</span>
            <span className="text-base font-bold text-white mt-0.5 block">14 Approved Signals</span>
          </div>
          <div className="bg-white/60 border border-slate-800/80 rounded-2xl p-3">
            <span className="text-slate-400 block text-[11px]">Location Centroid</span>
            <span className="text-base font-bold text-cyan-400 mt-0.5 block">SOMA, San Francisco (±500m)</span>
          </div>
          <div className="bg-white/60 border border-slate-800/80 rounded-2xl p-3">
            <span className="text-slate-400 block text-[11px]">Ecosystem Compatibility</span>
            <span className="text-base font-bold text-emerald-400 mt-0.5 block">94.8% Average Fit</span>
          </div>
          <div className="bg-white/60 border border-slate-800/80 rounded-2xl p-3">
            <span className="text-slate-400 block text-[11px]">Twin Negotiation Status</span>
            <span className="text-base font-bold text-indigo-400 mt-0.5 block">Autonomous Listening ON</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none w-full md:w-auto pb-1">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                activeCategory === cat.id
                  ? 'bg-cyan-500 text-slate-800 shadow-md shadow-cyan-500/20'
                  : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800'
              }`}
            >
              <span>{cat.label}</span>
            </button>
          ))}
        </div>

        {/* Search & Min Score Slider */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-end">
          <div className="relative flex-1 md:w-48">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              placeholder="Search radar..."
              className="w-full bg-slate-900 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 rounded-xl pl-8 pr-3 py-1.5 outline-none focus:border-cyan-500"
            />
          </div>

          <div className="hidden sm:flex items-center gap-2 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-xl text-xs text-slate-300">
            <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-400" />
            <span>Score ≥ {minMatchScore}%</span>
            <input
              type="range"
              min={70}
              max={95}
              value={minMatchScore}
              onChange={(e) => setMinMatchScore(Number(e.target.value))}
              className="w-16 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
          </div>
        </div>
      </div>

      {/* Radar Opportunities Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredOpportunities.length === 0 ? (
          <div className="col-span-full py-16 text-center bg-slate-900/40 rounded-3xl border border-slate-800 space-y-3">
            <Radar className="w-10 h-10 text-slate-600 mx-auto animate-pulse" />
            <h3 className="text-base font-semibold text-slate-300">No radar matches at this threshold</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Try adjusting your filter score or broadcasting a new Life Intent to expand the synchronicity radius.
            </p>
          </div>
        ) : (
          filteredOpportunities.map((item) => (
            <div
              key={item.id}
              className="bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-3xl p-5 sm:p-6 transition-all shadow-xl hover:shadow-cyan-500/5 space-y-4 flex flex-col justify-between group"
            >
              <div className="space-y-3.5">
                {/* Card Top: Match Score & Category */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    {item.avatar ? (
                      <img
                        src={item.avatar}
                        alt={item.name || item.title}
                        className="w-12 h-12 rounded-2xl object-cover border border-slate-700 shadow-md"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-2xl bg-cyan-950/80 border border-cyan-800 flex items-center justify-center text-cyan-400 font-bold">
                        <Sparkles className="w-6 h-6" />
                      </div>
                    )}
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-base text-white group-hover:text-cyan-300 transition-colors">
                          {item.name || item.title}
                        </h3>
                        {item.contributionReputation && (
                          <span
                            title={`Contribution Tier: ${item.contributionReputation.tier}`}
                            className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md bg-amber-950/60 border border-amber-800 text-amber-300 text-[10px] font-semibold"
                          >
                            <ShieldCheck className="w-3 h-3 text-amber-400" />
                            <span>{item.contributionReputation.score} pts</span>
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">
                        {item.role || item.title}
                      </p>
                    </div>
                  </div>

                  <div className="text-right flex flex-col items-end">
                    <div className="flex items-center gap-1 bg-cyan-950/80 border border-cyan-800/80 text-cyan-300 px-2.5 py-1 rounded-full text-xs font-extrabold shadow-inner">
                      <Zap className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400" />
                      <span>{item.matchScore}% Match</span>
                    </div>
                    <span className="text-[10px] text-slate-500 mt-1 flex items-center gap-1">
                      <MapPin className="w-2.5 h-2.5 text-slate-400" /> {item.locationZone}
                    </span>
                  </div>
                </div>

                {/* Why It Matters (AI Explanation) */}
                <div className="bg-white/70 border border-slate-800/80 rounded-2xl p-3.5 space-y-1.5">
                  <div className="flex items-center gap-1.5 text-[11px] font-bold text-cyan-400">
                    <Bot className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Why This Matters to You Now</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {item.whyItMatters}
                  </p>
                </div>

                {/* Purpose Compatibility Rationale */}
                <div className="text-xs text-slate-400 space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-slate-300">Purpose Synergy: {item.purposeCompatibility.purpose}</span>
                    <span className="text-emerald-400 font-bold">{item.purposeCompatibility.score}%</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    {item.purposeCompatibility.rationale}
                  </p>
                </div>

                {/* Signals Matched Badges */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {item.signalsMatched.map((sig, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded-lg bg-slate-800/80 border border-slate-700/60 text-slate-300 text-[10px] font-medium"
                    >
                      {sig}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Bar */}
              <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between gap-3">
                <button
                  onClick={() => updateRadarOpportunityStatus(item.id, 'available', true)}
                  className="text-xs text-slate-500 hover:text-slate-400 flex items-center gap-1 transition-colors"
                >
                  <XCircle className="w-3.5 h-3.5" />
                  <span>Not relevant</span>
                </button>

                <button
                  onClick={() => handleAction(item)}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md active:scale-95 ${
                    item.status === 'connected'
                      ? 'bg-emerald-600 text-white shadow-emerald-600/20'
                      : item.status === 'requested'
                      ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/20'
                      : 'bg-cyan-500 hover:bg-cyan-400 text-slate-800 shadow-cyan-500/20'
                  }`}
                >
                  {item.status === 'connected' ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Open Context Chat</span>
                    </>
                  ) : item.status === 'requested' ? (
                    <>
                      <Bot className="w-3.5 h-3.5 text-white animate-spin" />
                      <span>Twin Handshake Pending (Click to Connect)</span>
                    </>
                  ) : (
                    <>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                      <span>{item.actionLabel}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
