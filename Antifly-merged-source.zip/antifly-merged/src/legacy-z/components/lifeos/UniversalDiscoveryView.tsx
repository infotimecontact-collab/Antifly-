import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Compass,
  Search,
  Filter,
  Users,
  BookOpen,
  Building2,
  Briefcase,
  MapPin,
  Sparkles,
  ExternalLink,
  Plus,
  Share2,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  Star,
} from 'lucide-react';
import { UniversalDiscoveryItem } from '../../types';

export const UniversalDiscoveryView: React.FC = () => {
  const {
    universalDiscoveryItems,
    showToast,
    addLifeMemory,
  } = useApp();

  const [selectedType, setSelectedType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [minMatchPercent, setMinMatchPercent] = useState(70);

  const typeTabs = [
    { id: 'all', label: 'All Everything', icon: Compass },
    { id: 'people', label: 'People & Co-creators', icon: Users },
    { id: 'knowledge', label: 'Knowledge & Guides', icon: BookOpen },
    { id: 'business', label: 'Verified Businesses', icon: Building2 },
    { id: 'opportunity', label: 'Opportunities', icon: Briefcase },
    { id: 'place', label: 'Places & Hubs', icon: MapPin },
  ];

  const filteredItems = universalDiscoveryItems.filter((item) => {
    if (selectedType !== 'all' && item.entityType !== selectedType) return false;
    if (item.matchRelevancePercent < minMatchPercent) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        item.title.toLowerCase().includes(q) ||
        item.subtitle.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.intentAlignment.toLowerCase().includes(q) ||
        item.tags.some((t) => t.toLowerCase().includes(q))
      );
    }
    return true;
  });

  return (
    <div className="space-y-6 pb-16">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950/40 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-2xl">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/10 border border-teal-500/30 text-teal-400 text-xs font-bold">
            <Compass className="w-3.5 h-3.5" />
            <span>Universal Discovery • Intent-First Global Search</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Everything That Matches Your Life Context
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
            Discover verified people, specialized knowledge, local businesses, real-life opportunities, and inspiring spaces mapped directly to your active intentions.
          </p>
        </div>

        {/* Search Bar */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search across all entities..."
            className="w-full bg-white border border-slate-800 focus:border-teal-500 rounded-2xl pl-10 pr-4 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 outline-none shadow-inner"
          />
        </div>
      </div>

      {/* Category Selection Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-none py-1">
        {typeTabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setSelectedType(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                selectedType === tab.id
                  ? 'bg-teal-500 text-slate-800 shadow-md font-extrabold'
                  : 'bg-slate-900/80 text-slate-400 border border-slate-800 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Discovery Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map((item) => {
          const typeBadges: Record<string, { bg: string; text: string }> = {
            people: { bg: 'bg-cyan-950/80 border-cyan-800', text: 'text-cyan-400' },
            knowledge: { bg: 'bg-amber-950/80 border-amber-800', text: 'text-amber-400' },
            business: { bg: 'bg-purple-950/80 border-purple-800', text: 'text-purple-400' },
            opportunity: { bg: 'bg-emerald-950/80 border-emerald-800', text: 'text-emerald-400' },
            place: { bg: 'bg-rose-950/80 border-rose-800', text: 'text-rose-400' },
          };
          const badge = typeBadges[item.entityType] || typeBadges.people;

          return (
            <div
              key={item.id}
              className="bg-slate-900/90 border border-slate-800 hover:border-teal-500/50 rounded-3xl overflow-hidden flex flex-col justify-between group transition-all shadow-xl"
            >
              <div className="relative h-44 overflow-hidden">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

                <div className="absolute top-3 left-3 flex items-center gap-1.5">
                  <span
                    className={`px-2.5 py-0.5 rounded-lg border text-[10px] font-extrabold uppercase tracking-wider backdrop-blur-md ${badge.bg} ${badge.text}`}
                  >
                    {item.entityType}
                  </span>
                  {item.verified && (
                    <span className="px-2 py-0.5 rounded-lg bg-emerald-950/80 border border-emerald-800 text-[10px] font-bold text-emerald-400 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" /> Verified
                    </span>
                  )}
                </div>

                <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-xs">
                  {item.locationDistance && (
                    <span className="text-slate-300 font-semibold flex items-center gap-1 bg-white/70 backdrop-blur px-2 py-0.5 rounded-md border border-slate-800">
                      <MapPin className="w-3 h-3 text-cyan-400" /> {item.locationDistance}
                    </span>
                  )}
                  <span className="text-emerald-400 font-extrabold flex items-center gap-1 bg-white/80 backdrop-blur px-2 py-0.5 rounded-md border border-slate-700">
                    <Sparkles className="w-3 h-3" /> {item.matchRelevancePercent}% Match
                  </span>
                </div>
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="font-bold text-base text-slate-100 group-hover:text-teal-300 transition-colors line-clamp-1">
                    {item.title}
                  </h3>
                  <p className="text-xs text-indigo-300 font-medium mt-0.5 line-clamp-1">
                    {item.subtitle}
                  </p>
                  <p className="text-xs text-slate-400 line-clamp-2 mt-2 leading-relaxed">
                    {item.description}
                  </p>

                  <div className="mt-3 bg-white/80 p-2.5 rounded-xl border border-slate-800/80 text-[11px] text-slate-300">
                    🎯 <strong className="text-slate-200">Alignment:</strong> {item.intentAlignment}
                  </div>
                </div>

                <div className="space-y-3 pt-3 border-t border-slate-800">
                  <div className="flex flex-wrap gap-1">
                    {item.tags.map((t, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] font-medium bg-white text-slate-400 border border-slate-800 px-2 py-0.5 rounded-md"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-1">
                    <button
                      onClick={() => {
                        addLifeMemory({
                          title: `Saved: ${item.title}`,
                          category: 'moment',
                          description: item.description,
                          location: item.locationDistance || 'Global',
                          tags: item.tags,
                        });
                      }}
                      className="text-xs font-semibold text-slate-400 hover:text-white"
                    >
                      Save to Memory
                    </button>

                    <button
                      onClick={() => showToast(`✨ Connected with ${item.title}!`)}
                      className="bg-teal-500 hover:bg-teal-400 text-slate-800 text-xs font-extrabold px-4 py-2 rounded-xl shadow-md transition-all active:scale-95 flex items-center gap-1"
                    >
                      <span>{item.entityType === 'people' ? 'Introduce Me' : 'Connect'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
