import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Workflow,
  Sparkles,
  Zap,
  ShieldCheck,
  Eye,
  EyeOff,
  Users,
  Briefcase,
  BookOpen,
  PlusCircle,
  CheckCircle2,
  TrendingUp,
  Award,
  Layers,
} from 'lucide-react';
import { SkillGraphNode } from '../../types';

export const DynamicSkillGraphView: React.FC = () => {
  const { skillGraphNodes, toggleSkillVisibility, setContextAwareChatPeer, setIsContextAwareChatOpen } = useApp();

  const [selectedNodeId, setSelectedNodeId] = useState<string>(skillGraphNodes[0]?.id || '');
  const [activeDomain, setActiveDomain] = useState<string>('all');

  const domains = [
    { id: 'all', label: 'All Competencies' },
    { id: 'AI / Machine Learning', label: 'AI & Intelligence' },
    { id: 'Systems & Architecture', label: 'Systems & Runtime' },
    { id: 'Hardware & Perception', label: 'Hardware & Spatial' },
    { id: 'Spatial Computing & UX', label: 'Human Interfaces' },
  ];

  const filteredNodes = skillGraphNodes.filter((node) => {
    if (activeDomain !== 'all' && node.domain !== activeDomain) return false;
    return true;
  });

  const selectedNode = skillGraphNodes.find((n) => n.id === selectedNodeId) || skillGraphNodes[0];

  const handleMentorConnect = (mentor: { name: string; avatar: string; endorsementText: string }) => {
    setContextAwareChatPeer({
      name: mentor.name,
      avatar: mentor.avatar,
      sharedContext: `Dynamic Skill Graph Mentor: ${selectedNode?.skillName}`,
      matchRationale: mentor.endorsementText,
    });
    setIsContextAwareChatOpen(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8 animate-fadeIn">
      {/* Hero Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-purple-950/50 to-slate-950 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute -right-16 -top-16 w-80 h-80 rounded-full bg-purple-500/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-950/80 border border-purple-800 text-purple-400 text-xs font-semibold">
              <Workflow className="w-3.5 h-3.5" />
              <span>Living Knowledge & Competency Architecture</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Dynamic Skill Graph
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              Real-time map of your mastery, growth velocity, verified project artifacts, connected peer mentors, and live market opportunities mapped to your exact technical strengths.
            </p>
          </div>

          <div className="bg-white/80 border border-slate-800 p-4 rounded-2xl text-xs space-y-1.5 max-w-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Total Verified Nodes</span>
              <span className="text-purple-300 font-bold">{skillGraphNodes.length} Competencies</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Public Visibility</span>
              <span className="text-emerald-400 font-bold">
                {skillGraphNodes.filter((n) => n.isPublic).length} of {skillGraphNodes.length} Public
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Domain Filters */}
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-none pb-1">
        {domains.map((dom) => (
          <button
            key={dom.id}
            onClick={() => setActiveDomain(dom.id)}
            className={`px-4 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all ${
              activeDomain === dom.id
                ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/25'
                : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800'
            }`}
          >
            {dom.label}
          </button>
        ))}
      </div>

      {/* Main Skill Graph Interactive Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Skill Nodes List */}
        <div className="space-y-3">
          <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Verified Competency Nodes
          </h2>
          <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
            {filteredNodes.map((node) => {
              const isSelected = node.id === selectedNodeId;
              return (
                <div
                  key={node.id}
                  onClick={() => setSelectedNodeId(node.id)}
                  className={`cursor-pointer rounded-2xl p-4 border transition-all ${
                    isSelected
                      ? 'bg-purple-950/40 border-purple-500/60 shadow-lg shadow-purple-500/10'
                      : 'bg-slate-900/80 hover:bg-slate-900 border-slate-800/80'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-sm text-white">{node.skillName}</h3>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-purple-300 font-semibold">
                          {node.proficiencyLevel}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400 mt-0.5 block">{node.domain}</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-purple-400">{node.masteryPercent}%</span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleSkillVisibility(node.id);
                        }}
                        title={node.isPublic ? 'Publicly Visible' : 'Private Skill Node'}
                        className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
                      >
                        {node.isPublic ? (
                          <Eye className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <EyeOff className="w-3.5 h-3.5 text-slate-500" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full bg-white rounded-full h-1.5 mt-3 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-purple-500 to-cyan-400 h-1.5 rounded-full transition-all duration-500"
                      style={{ width: `${node.masteryPercent}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 2 Columns: Detailed Selected Node Hub */}
        {selectedNode && (
          <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
            {/* Selected Node Top */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-purple-400 font-bold uppercase tracking-wider">
                    {selectedNode.domain}
                  </span>
                  <span className="text-slate-500">•</span>
                  <span className="text-xs text-slate-300 font-semibold">{selectedNode.proficiencyLevel}</span>
                </div>
                <h2 className="text-2xl font-extrabold text-white">{selectedNode.skillName}</h2>
              </div>

              <div className="flex items-center gap-3">
                <div className="text-right">
                  <span className="text-xs text-slate-400 block">Mastery Index</span>
                  <span className="text-xl font-extrabold text-purple-400">
                    {selectedNode.masteryPercent}%
                  </span>
                </div>
                <button
                  onClick={() => toggleSkillVisibility(selectedNode.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border ${
                    selectedNode.isPublic
                      ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                      : 'bg-white border-slate-800 text-slate-400'
                  }`}
                >
                  {selectedNode.isPublic ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                  <span>{selectedNode.isPublic ? 'Public to Radar' : 'Private to You'}</span>
                </button>
              </div>
            </div>

            {/* Proof Artifacts & Shipped Projects */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Verified Project Proof & Artifacts</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {selectedNode.linkedProjects.map((proj, idx) => (
                  <div
                    key={idx}
                    className="bg-white/80 border border-slate-800 rounded-2xl p-3.5 space-y-1"
                  >
                    <span className="font-bold text-xs text-slate-200 block">{proj.title}</span>
                    <span className="text-[11px] text-cyan-400 font-semibold block">{proj.role}</span>
                    <p className="text-[11px] text-slate-400">{proj.outcome}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Verified Mentors & Endorsements */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Users className="w-4 h-4 text-purple-400" />
                <span>Peer Mentors & Verified Endorsements</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {selectedNode.verifiedMentors.map((mentor, idx) => (
                  <div
                    key={idx}
                    className="bg-white/80 border border-slate-800 rounded-2xl p-3.5 flex items-start justify-between gap-3"
                  >
                    <div className="flex items-center gap-2.5">
                      <img
                        src={mentor.avatar}
                        alt={mentor.name}
                        className="w-10 h-10 rounded-xl object-cover border border-slate-700"
                      />
                      <div>
                        <span className="font-bold text-xs text-white block">{mentor.name}</span>
                        <p className="text-[11px] text-slate-400 italic mt-0.5">
                          "{mentor.endorsementText}"
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => handleMentorConnect(mentor)}
                      className="px-2.5 py-1 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-[11px] font-semibold whitespace-nowrap"
                    >
                      Connect
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Linked Opportunities & Learning */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-800">
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-300 block flex items-center gap-1.5">
                  <Briefcase className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Linked High-Fit Opportunities</span>
                </span>
                <div className="space-y-1.5">
                  {selectedNode.linkedOpportunities.map((opp, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-xl bg-white border border-slate-800 text-xs text-slate-300 flex items-center justify-between"
                    >
                      <span>{opp}</span>
                      <Zap className="w-3 h-3 text-cyan-400" />
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-300 block flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-amber-400" />
                  <span>Next Level Learning Resources</span>
                </span>
                <div className="space-y-1.5">
                  {selectedNode.learningResources.map((res, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-xl bg-white border border-slate-800 text-xs text-slate-300 flex items-center justify-between"
                    >
                      <span>{res}</span>
                      <Sparkles className="w-3 h-3 text-amber-400" />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
