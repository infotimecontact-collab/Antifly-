import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ArrowLeftRight,
  PlusCircle,
  Sparkles,
  Zap,
  ShieldCheck,
  MapPin,
  Clock,
  CheckCircle2,
  Filter,
  UserCheck,
  Send,
  MessageSquare,
  Search,
  Briefcase,
  Share2,
} from 'lucide-react';
import { OpportunityExchangeItem } from '../../types';

export const OpportunityExchangeView: React.FC = () => {
  const {
    opportunityExchangeItems,
    addOpportunityExchangeItem,
    setContextAwareChatPeer,
    setIsContextAwareChatOpen,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'need' | 'offer'>('all');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Create form state
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [newType, setNewType] = useState<'need' | 'offer'>('need');
  const [newCategory, setNewCategory] = useState<any>('developer');
  const [newTitle, setNewTitle] = useState<string>('');
  const [newDescription, setNewDescription] = useState<string>('');
  const [newSkills, setNewSkills] = useState<string>('');
  const [newExchangeType, setNewExchangeType] = useState<any>('mutual_barter');
  const [newUrgency, setNewUrgency] = useState<any>('this_week');

  const filteredItems = opportunityExchangeItems.filter((item) => {
    if (activeTab !== 'all' && item.type !== activeTab) return false;
    if (activeCategory !== 'all' && item.category !== activeCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match = (item.title + ' ' + item.description + ' ' + item.author.name + ' ' + item.skillsTags.join(' ')).toLowerCase();
      if (!match.includes(q)) return false;
    }
    return true;
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    addOpportunityExchangeItem({
      type: newType,
      category: newCategory,
      title: newTitle,
      description: newDescription,
      skillsTags: newSkills.split(',').map((s) => s.trim()).filter(Boolean),
      exchangeType: newExchangeType,
      urgency: newUrgency,
      locationZone: 'San Francisco & Remote',
    });

    setNewTitle('');
    setNewDescription('');
    setNewSkills('');
    setShowCreateModal(false);
  };

  const handleInitiateExchange = (item: OpportunityExchangeItem) => {
    setContextAwareChatPeer({
      name: item.author.name,
      avatar: item.author.avatar,
      sharedContext: `Opportunity Exchange: ${item.type === 'need' ? 'I Need' : 'I Can Offer'} — "${item.title}"`,
      matchRationale: `Skills: ${item.skillsTags.join(', ')} • Terms: ${item.exchangeType.replace('_', ' ')}`,
    });
    setIsContextAwareChatOpen(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8 animate-fadeIn">
      {/* Hero Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-emerald-950/50 to-slate-950 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute -right-16 -top-16 w-80 h-80 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-800 text-emerald-400 text-xs font-semibold">
              <ArrowLeftRight className="w-3.5 h-3.5" />
              <span>Peer-to-Peer Collaborative Market</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Opportunity Exchange & Barter Network
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              Direct value exchange without middlemen. Post what you need and what you can offer—from engineering, design, and mentorship to angel capital and equipment sharing.
            </p>
          </div>

          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-800 text-xs font-extrabold px-5 py-3 rounded-2xl shadow-lg shadow-emerald-500/20 active:scale-95 transition-all whitespace-nowrap"
          >
            <PlusCircle className="w-4 h-4 text-slate-800" />
            <span>Publish Need / Offer</span>
          </button>
        </div>
      </div>

      {/* Tabs & Search Filter */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        {/* Need / Offer Toggle */}
        <div className="flex items-center gap-1.5 bg-slate-900 p-1.5 rounded-2xl border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-4 py-1.5 rounded-xl font-bold transition-all ${
              activeTab === 'all' ? 'bg-cyan-500 text-slate-800' : 'text-slate-400 hover:text-white'
            }`}
          >
            All Listings ({opportunityExchangeItems.length})
          </button>
          <button
            onClick={() => setActiveTab('need')}
            className={`px-4 py-1.5 rounded-xl font-bold transition-all ${
              activeTab === 'need' ? 'bg-rose-500 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            I Need ({opportunityExchangeItems.filter((i) => i.type === 'need').length})
          </button>
          <button
            onClick={() => setActiveTab('offer')}
            className={`px-4 py-1.5 rounded-xl font-bold transition-all ${
              activeTab === 'offer' ? 'bg-emerald-500 text-slate-800' : 'text-slate-400 hover:text-white'
            }`}
          >
            I Can Offer ({opportunityExchangeItems.filter((i) => i.type === 'offer').length})
          </button>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search skills, terms, people..."
            className="w-full bg-slate-900 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 rounded-xl pl-8 pr-3 py-1.5 outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Opportunity Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            className="bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-3xl p-6 space-y-4 shadow-xl flex flex-col justify-between group transition-all"
          >
            <div className="space-y-3">
              {/* Header Badges & Type */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2.5 py-1 rounded-full text-[11px] font-extrabold uppercase tracking-wider ${
                      item.type === 'need'
                        ? 'bg-rose-950/80 border border-rose-800 text-rose-400'
                        : 'bg-emerald-950/80 border border-emerald-800 text-emerald-400'
                    }`}
                  >
                    {item.type === 'need' ? '⚡ Seeking / Need' : '🎁 Offering'}
                  </span>
                  <span className="px-2 py-0.5 rounded-lg bg-slate-800 text-slate-300 text-[10px] font-semibold">
                    {item.exchangeType.replace('_', ' ')}
                  </span>
                </div>

                <span className="text-[10px] text-slate-500 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-500" />
                  {item.createdAt}
                </span>
              </div>

              {/* Title & Description */}
              <div>
                <h3 className="font-bold text-base text-white group-hover:text-cyan-300 transition-colors">
                  {item.title}
                </h3>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed line-clamp-3">
                  {item.description}
                </p>
              </div>

              {/* Skill Tags */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {item.skillsTags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded-md bg-white border border-slate-800 text-cyan-300 text-[10px] font-medium"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Author & Action Bottom Bar */}
            <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <img
                  src={item.author.avatar}
                  alt={item.author.name}
                  className="w-9 h-9 rounded-xl object-cover border border-slate-700 shadow"
                />
                <div>
                  <div className="flex items-center gap-1">
                    <span className="font-bold text-xs text-slate-200">{item.author.name}</span>
                    <span
                      title={`Reputation: ${item.author.contributionScore}`}
                      className="inline-flex items-center gap-0.5 text-[10px] text-amber-400 font-semibold"
                    >
                      <ShieldCheck className="w-3 h-3 text-amber-400" />
                      {item.author.contributionScore}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 truncate max-w-[160px]">
                    {item.author.headline}
                  </p>
                </div>
              </div>

              <button
                onClick={() => handleInitiateExchange(item)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-800 text-xs font-bold transition-all shadow-md shadow-cyan-500/20 active:scale-95"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Initiate Barter</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Publish Opportunity Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-slate-100/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl animate-scaleIn">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ArrowLeftRight className="w-5 h-5 text-emerald-400" />
                <h3 className="text-lg font-bold text-white">Publish to Opportunity Exchange</h3>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              {/* Type Switch */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setNewType('need')}
                  className={`py-2 rounded-xl text-xs font-bold transition-all ${
                    newType === 'need'
                      ? 'bg-rose-500 text-white'
                      : 'bg-white text-slate-400 border border-slate-800'
                  }`}
                >
                  ⚡ I Need Something
                </button>
                <button
                  type="button"
                  onClick={() => setNewType('offer')}
                  className={`py-2 rounded-xl text-xs font-bold transition-all ${
                    newType === 'offer'
                      ? 'bg-emerald-500 text-slate-800'
                      : 'bg-white text-slate-400 border border-slate-800'
                  }`}
                >
                  🎁 I Can Offer Value
                </button>
              </div>

              <div>
                <label className="text-xs text-slate-300 font-semibold block mb-1">
                  Title of Opportunity
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Seeking Rust & Wasm engineer for spatial PCB copilot"
                  className="w-full bg-white border border-slate-800 text-xs text-slate-100 rounded-xl px-3 py-2.5 outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 font-semibold block mb-1">
                  Details & Context
                </label>
                <textarea
                  rows={3}
                  required
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder="Explain what is involved, project stage, timeline, and collaboration expectations..."
                  className="w-full bg-white border border-slate-800 text-xs text-slate-100 rounded-xl p-3 outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-300 font-semibold block mb-1">
                    Exchange Model
                  </label>
                  <select
                    value={newExchangeType}
                    onChange={(e) => setNewExchangeType(e.target.value)}
                    className="w-full bg-white border border-slate-800 text-xs text-slate-200 rounded-xl px-3 py-2.5 outline-none"
                  >
                    <option value="mutual_barter">Mutual Skill Barter</option>
                    <option value="equity">Equity / Co-founding</option>
                    <option value="revenue_share">Revenue Share</option>
                    <option value="pro_bono">Pro-Bono Mentorship</option>
                    <option value="paid_service">Standard Service</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs text-slate-300 font-semibold block mb-1">
                    Urgency
                  </label>
                  <select
                    value={newUrgency}
                    onChange={(e) => setNewUrgency(e.target.value)}
                    className="w-full bg-white border border-slate-800 text-xs text-slate-200 rounded-xl px-3 py-2.5 outline-none"
                  >
                    <option value="immediate">Immediate (This week)</option>
                    <option value="this_week">Next 14 Days</option>
                    <option value="flexible">Flexible Timing</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-300 font-semibold block mb-1">
                  Relevant Skills Tags (comma separated)
                </label>
                <input
                  type="text"
                  value={newSkills}
                  onChange={(e) => setNewSkills(e.target.value)}
                  placeholder="Rust, WebAssembly, Computer Vision, PyTorch"
                  className="w-full bg-white border border-slate-800 text-xs text-slate-100 rounded-xl px-3 py-2.5 outline-none focus:border-cyan-500"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-800 text-xs font-bold shadow-lg shadow-emerald-500/20"
                >
                  Publish to Exchange
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
