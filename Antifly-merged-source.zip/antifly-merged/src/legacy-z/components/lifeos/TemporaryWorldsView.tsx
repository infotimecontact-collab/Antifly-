import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Globe,
  Plus,
  Users,
  MapPin,
  Clock,
  ArrowRight,
  Sparkles,
  Share2,
  Calendar,
  Lock,
  Layers,
  Send,
  FileText,
  ExternalLink,
  Shield,
  MessageSquare,
  CheckCircle2,
  ArrowLeft,
} from 'lucide-react';
import { SocialWorld } from '../../types';

export const TemporaryWorldsView: React.FC = () => {
  const {
    socialWorlds,
    joinSocialWorld,
    leaveSocialWorld,
    createSocialWorld,
    activeWorldDetail,
    setActiveWorldDetail,
    setIsCreateWorldModalOpen,
    showToast,
  } = useApp();

  const [filterType, setFilterType] = useState<string>('all');
  const [newActivityText, setNewActivityText] = useState('');

  const worldTypes = [
    { id: 'all', label: 'All Worlds' },
    { id: 'travel', label: 'Travel Worlds' },
    { id: 'startup', label: 'Startup Worlds' },
    { id: 'project', label: 'Project Worlds' },
    { id: 'event', label: 'Event Worlds' },
    { id: 'learning', label: 'Learning Worlds' },
  ];

  const filteredWorlds = socialWorlds.filter((w) => {
    if (filterType !== 'all' && w.type !== filterType) return false;
    return true;
  });

  const handlePostActivity = (worldId: string) => {
    if (!newActivityText.trim()) return;
    showToast('💬 Broadcasted note to the Social World collaboration board!');
    setNewActivityText('');
  };

  // If a specific world is opened in detail view
  if (activeWorldDetail) {
    const world = socialWorlds.find((w) => w.id === activeWorldDetail.id) || activeWorldDetail;
    return (
      <div className="space-y-6 pb-16">
        {/* Back Navigation Bar */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => setActiveWorldDetail(null)}
            className="flex items-center gap-2 text-xs font-bold text-slate-400 hover:text-white bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to All Social Worlds</span>
          </button>

          <div className="flex items-center gap-2">
            <span className="text-xs text-amber-400 bg-amber-950/80 border border-amber-800 px-3 py-1 rounded-xl font-bold flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" />
              {world.remainingDuration}
            </span>
            <button
              onClick={() => joinSocialWorld(world.id)}
              className={`text-xs font-bold px-4 py-1.5 rounded-xl transition-all ${
                world.isJoined
                  ? 'bg-emerald-950 border border-emerald-800 text-emerald-300'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md'
              }`}
            >
              {world.isJoined ? 'Joined ✓' : 'Join World'}
            </button>
          </div>
        </div>

        {/* Hero Banner */}
        <div className="relative rounded-3xl overflow-hidden border border-slate-800 shadow-2xl h-64 sm:h-80">
          <img
            src={world.bannerImage}
            alt={world.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />

          <div className="absolute bottom-6 left-6 right-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-lg bg-indigo-600 text-white text-[10px] uppercase font-bold tracking-wider">
                  {world.type} World
                </span>
                <span className="text-xs text-slate-300 flex items-center gap-1 bg-white/80 backdrop-blur px-2.5 py-0.5 rounded-lg border border-slate-700">
                  <MapPin className="w-3 h-3 text-cyan-400" /> {world.locationZone}
                </span>
                <span className="text-xs text-slate-300 flex items-center gap-1 bg-white/80 backdrop-blur px-2.5 py-0.5 rounded-lg border border-slate-700">
                  <Users className="w-3 h-3 text-emerald-400" /> {world.participantsCount} Co-creators
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white">{world.title}</h1>
              <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">{world.description}</p>
            </div>
          </div>
        </div>

        {/* World Room Content: Members, Board, Resources */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Activity & Collab Stream */}
          <div className="lg:col-span-2 space-y-5">
            {/* Input Share Box */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
              <p className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                Collaborative World Stream
              </p>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={newActivityText}
                  onChange={(e) => setNewActivityText(e.target.value)}
                  placeholder="Share a milestone, question, or discovery with this World..."
                  className="flex-1 bg-white border border-slate-800 rounded-xl px-4 py-2 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500"
                />
                <button
                  onClick={() => handlePostActivity(world.id)}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-1 shrink-0"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Post</span>
                </button>
              </div>
            </div>

            {/* Activities List */}
            <div className="space-y-3">
              {world.activities.map((act) => (
                <div
                  key={act.id}
                  className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <img
                        src={act.avatar}
                        alt={act.user}
                        className="w-8 h-8 rounded-full object-cover border border-slate-700"
                      />
                      <div>
                        <span className="text-xs font-bold text-slate-200">{act.user}</span>
                        <span className="text-[10px] text-slate-500 block">{act.time}</span>
                      </div>
                    </div>
                    {act.intentType && (
                      <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-white text-indigo-400 border border-slate-800">
                        {act.intentType}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed pl-10">
                    {act.text}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Right Sidebar: Members & Resources */}
          <div className="space-y-6">
            {/* Active Members */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-indigo-400" />
                  Co-Creators ({world.memberList.length})
                </h3>
              </div>

              <div className="space-y-2.5">
                {world.memberList.map((m) => (
                  <div
                    key={m.id}
                    className="flex items-center gap-2.5 p-2 rounded-xl bg-white/60 border border-slate-800/80"
                  >
                    <img
                      src={m.avatar}
                      alt={m.name}
                      className="w-9 h-9 rounded-full object-cover border border-slate-700 shrink-0"
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-slate-200 truncate">{m.name}</p>
                      <p className="text-[10px] text-slate-400 truncate">{m.role}</p>
                      <p className="text-[10px] text-indigo-400 truncate">{m.headline}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Shared Resources */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-cyan-400" />
                Shared World Resources ({world.resources.length})
              </h3>

              <div className="space-y-2">
                {world.resources.map((res, idx) => (
                  <a
                    key={idx}
                    href={res.url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-between p-2.5 rounded-xl bg-white/60 hover:bg-white border border-slate-800 text-xs transition-colors group"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <FileText className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span className="text-slate-300 group-hover:text-cyan-300 font-medium truncate">
                        {res.title}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-500 uppercase font-bold shrink-0">
                      {res.type}
                    </span>
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-16">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-2xl">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-xs font-bold">
            <Globe className="w-3.5 h-3.5" />
            <span>Situational Social Worlds • Ephemeral Collaboration</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Temporary Real-Life Social Worlds
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
            Spaces created dynamically for trips, events, startup sprints, and learning cohorts. When the experience finishes, achievements auto-archive cleanly into your personal Life Memory.
          </p>
        </div>

        <button
          onClick={() => setIsCreateWorldModalOpen(true)}
          className="flex items-center gap-2 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 hover:opacity-90 text-white font-bold text-sm px-5 py-3 rounded-2xl shadow-xl shadow-indigo-500/20 active:scale-95 transition-all shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Create New Social World</span>
        </button>
      </div>

      {/* Filter Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-none py-1">
        {worldTypes.map((t) => (
          <button
            key={t.id}
            onClick={() => setFilterType(t.id)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              filterType === t.id
                ? 'bg-indigo-600 text-white shadow'
                : 'bg-slate-900/80 text-slate-400 border border-slate-800 hover:bg-slate-800 hover:text-white'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Worlds Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredWorlds.map((world) => (
          <div
            key={world.id}
            className="bg-slate-900/90 border border-slate-800 hover:border-indigo-500/50 rounded-3xl overflow-hidden flex flex-col justify-between group transition-all shadow-xl"
          >
            <div className="relative h-44 overflow-hidden">
              <img
                src={world.bannerImage}
                alt={world.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
              <div className="absolute top-3 left-3 flex items-center gap-1.5">
                <span className="px-2.5 py-0.5 rounded-md bg-white/80 backdrop-blur-md border border-slate-700 text-[10px] font-bold text-indigo-300 uppercase">
                  {world.type} World
                </span>
                <span className="px-2 py-0.5 rounded-md bg-white/80 backdrop-blur-md border border-slate-700 text-[10px] font-bold text-slate-300 flex items-center gap-1">
                  <Users className="w-3 h-3 text-cyan-400" />
                  {world.participantsCount}
                </span>
              </div>
              <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-xs">
                <span className="text-cyan-300 font-semibold flex items-center gap-1">
                  <MapPin className="w-3 h-3" /> {world.locationZone}
                </span>
                <span className="text-amber-400 font-bold flex items-center gap-1 bg-white/80 px-2 py-0.5 rounded-md border border-slate-700 text-[10px]">
                  <Clock className="w-3 h-3" /> {world.remainingDuration}
                </span>
              </div>
            </div>

            <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
              <div>
                <h3 className="font-bold text-base text-slate-100 group-hover:text-indigo-300 transition-colors line-clamp-1">
                  {world.title}
                </h3>
                <p className="text-xs text-slate-400 line-clamp-2 mt-1 leading-relaxed">
                  {world.description}
                </p>
              </div>

              <div className="space-y-3 pt-3 border-t border-slate-800">
                <div className="flex flex-wrap gap-1">
                  {world.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] font-medium bg-white text-slate-400 border border-slate-800 px-2 py-0.5 rounded-md"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between gap-2 pt-1">
                  <button
                    onClick={() => setActiveWorldDetail(world)}
                    className="text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1"
                  >
                    Enter Room <ArrowRight className="w-3.5 h-3.5 text-indigo-400" />
                  </button>
                  <button
                    onClick={() => joinSocialWorld(world.id)}
                    className={`text-xs font-bold px-4 py-2 rounded-xl transition-all ${
                      world.isJoined
                        ? 'bg-emerald-950/80 border border-emerald-800 text-emerald-400'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md'
                    }`}
                  >
                    {world.isJoined ? 'Joined ✓' : 'Join World'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
