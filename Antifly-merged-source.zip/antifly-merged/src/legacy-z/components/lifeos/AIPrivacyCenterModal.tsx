import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Lock,
  Shield,
  ShieldCheck,
  Eye,
  EyeOff,
  Radio,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Bot,
  Layers,
  History,
  X,
} from 'lucide-react';

export const AIPrivacyCenterModal: React.FC = () => {
  const { isAIPrivacyCenterOpen, setIsAIPrivacyCenterOpen, aiPrivacyState, updateAIPrivacyState } =
    useApp();

  if (!isAIPrivacyCenterOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-100/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl animate-scaleIn my-8">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-950/80 border border-emerald-800 flex items-center justify-center text-emerald-400">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold text-white">
                Sovereign Privacy & AI Transparency Center
              </h2>
              <p className="text-xs text-slate-400">
                You own 100% of your data, memory embeddings, and agent reasoning.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAIPrivacyCenterOpen(false)}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Master AI System Switch */}
        <div className="bg-white/80 border border-slate-800 rounded-2xl p-4 flex items-center justify-between gap-4">
          <div className="space-y-0.5">
            <span className="font-bold text-sm text-white block">Master AI Intelligence Engine</span>
            <p className="text-xs text-slate-400">
              Enables autonomous intent matching, Life Radar signal processing, and future forecasting.
            </p>
          </div>

          <button
            onClick={() => updateAIPrivacyState({ isAIActive: !aiPrivacyState.isAIActive })}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              aiPrivacyState.isAIActive
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                : 'bg-slate-800 text-slate-400'
            }`}
          >
            {aiPrivacyState.isAIActive ? 'AI Enabled' : 'AI Paused'}
          </button>
        </div>

        {/* Granular Feature Permissions */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Signal Permissions & Context Sharing
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Context Engine */}
            <div className="bg-white/60 border border-slate-800 rounded-2xl p-3.5 flex items-center justify-between gap-2">
              <div>
                <span className="text-xs font-bold text-slate-200 block">Context Engine</span>
                <span className="text-[11px] text-slate-500">Read active goals & skills</span>
              </div>
              <input
                type="checkbox"
                checked={aiPrivacyState.isContextEngineActive}
                onChange={(e) => updateAIPrivacyState({ isContextEngineActive: e.target.checked })}
                className="w-4 h-4 rounded text-cyan-500 bg-slate-900 border-slate-700 cursor-pointer"
              />
            </div>

            {/* Autonomous Twin Negotiation */}
            <div className="bg-white/60 border border-slate-800 rounded-2xl p-3.5 flex items-center justify-between gap-2">
              <div>
                <span className="text-xs font-bold text-slate-200 block">Twin Pre-Screening</span>
                <span className="text-[11px] text-slate-500">Allow AI Twin to screen intros</span>
              </div>
              <input
                type="checkbox"
                checked={aiPrivacyState.allowAutonomousTwinNegotiation}
                onChange={(e) =>
                  updateAIPrivacyState({ allowAutonomousTwinNegotiation: e.target.checked })
                }
                className="w-4 h-4 rounded text-cyan-500 bg-slate-900 border-slate-700 cursor-pointer"
              />
            </div>

            {/* Travel / Availability Sync */}
            <div className="bg-white/60 border border-slate-800 rounded-2xl p-3.5 flex items-center justify-between gap-2">
              <div>
                <span className="text-xs font-bold text-slate-200 block">Travel & Availability</span>
                <span className="text-[11px] text-slate-500">Sync trips for radar matching</span>
              </div>
              <input
                type="checkbox"
                checked={aiPrivacyState.allowTravelSync}
                onChange={(e) => updateAIPrivacyState({ allowTravelSync: e.target.checked })}
                className="w-4 h-4 rounded text-cyan-500 bg-slate-900 border-slate-700 cursor-pointer"
              />
            </div>

            {/* Anonymous Discovery Worlds */}
            <div className="bg-white/60 border border-slate-800 rounded-2xl p-3.5 flex items-center justify-between gap-2">
              <div>
                <span className="text-xs font-bold text-slate-200 block">Anonymous Mode</span>
                <span className="text-[11px] text-slate-500">Pseudonymous avatars in worlds</span>
              </div>
              <input
                type="checkbox"
                checked={aiPrivacyState.allowAnonymousWorlds}
                onChange={(e) => updateAIPrivacyState({ allowAnonymousWorlds: e.target.checked })}
                className="w-4 h-4 rounded text-cyan-500 bg-slate-900 border-slate-700 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Location Fuzzing Precision */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5 text-cyan-400" />
              <span>Location Fuzzing & Radius Halo</span>
            </h3>
            <span className="text-[11px] text-cyan-400 font-bold capitalize">
              {aiPrivacyState.locationFuzzingRadius.replace('_', ' ')}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { id: 'venue_only', label: 'Venue Only' },
              { id: '500m', label: '500m Halo' },
              { id: '2km', label: '2km District' },
              { id: 'city_level', label: 'City Level' },
            ].map((fuzz) => (
              <button
                key={fuzz.id}
                onClick={() => updateAIPrivacyState({ locationFuzzingRadius: fuzz.id as any })}
                className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                  aiPrivacyState.locationFuzzingRadius === fuzz.id
                    ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300'
                    : 'bg-white border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {fuzz.label}
              </button>
            ))}
          </div>
        </div>

        {/* Transparent AI Audit Logs */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <History className="w-3.5 h-3.5 text-amber-400" />
            <span>Transparent Signal Audit Log</span>
          </h3>

          <div className="bg-white/90 border border-slate-800 rounded-2xl p-3.5 space-y-2.5 max-h-48 overflow-y-auto pr-1">
            {aiPrivacyState.auditLogs.map((log) => (
              <div
                key={log.id}
                className="text-xs p-2.5 rounded-xl bg-slate-900/70 border border-slate-800/80 space-y-1"
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-cyan-400">{log.action}</span>
                  <span className="text-slate-500">{log.timestamp}</span>
                </div>
                <p className="text-slate-300">{log.reasoning}</p>
                <div className="flex flex-wrap gap-1 pt-0.5">
                  {log.signalsUsed.map((s, idx) => (
                    <span
                      key={idx}
                      className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-3">
          <span className="text-[11px] text-slate-500 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Zero ad-tracking or data brokering guaranteed.</span>
          </span>

          <button
            onClick={() => setIsAIPrivacyCenterOpen(false)}
            className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-800 text-xs font-bold transition-all shadow-md shadow-cyan-500/20"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
