import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  HeartHandshake,
  Sparkles,
  CheckCircle2,
  XCircle,
  MessageSquare,
  Users,
  MapPin,
  Calendar,
  Share2,
  ShieldCheck,
  Zap,
  ArrowRight,
  TrendingUp,
  Radio,
  Clock,
  Layers,
  Lock,
} from 'lucide-react';
import { SocialSynchronicity } from '../../types';

export const SynchronicityHubView: React.FC = () => {
  const { synchronicities, respondToSynchronicity, showToast } = useApp();
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved'>('all');

  const filteredSynchronicities = synchronicities.filter((s) => {
    if (filter === 'pending' && s.status !== 'pending') return false;
    if (filter === 'approved' && s.status !== 'approved' && s.status !== 'connected') return false;
    return true;
  });

  return (
    <div className="space-y-6 pb-16">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-rose-950/40 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-2xl">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-bold">
            <HeartHandshake className="w-3.5 h-3.5" />
            <span>Social Synchronicity Engine • Multi-Intent Intersection Engine</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Mutual Desires, Discovered Without Noise
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
            LIFEOS replaces cold DMs with mathematical synchronicity. When multiple people in the network have complementary desires, skills, and timing, a private intersection room is forged.
          </p>
        </div>

        {/* Live Engine Status */}
        <div className="bg-white/80 border border-slate-800 p-4 rounded-2xl space-y-1.5 shrink-0 text-xs">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            Synchronicity Radar: ACTIVE
          </div>
          <p className="text-slate-400 text-[11px]">
            Checking 1,240 nodes in SF & Tokyo
          </p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 bg-slate-900/60 p-1.5 rounded-2xl border border-slate-800 w-fit text-xs font-bold">
        <button
          onClick={() => setFilter('all')}
          className={`px-4 py-1.5 rounded-xl transition-all ${
            filter === 'all' ? 'bg-rose-500 text-white shadow' : 'text-slate-400 hover:text-white'
          }`}
        >
          All Detected ({synchronicities.length})
        </button>
        <button
          onClick={() => setFilter('pending')}
          className={`px-4 py-1.5 rounded-xl transition-all ${
            filter === 'pending' ? 'bg-rose-500 text-white shadow' : 'text-slate-400 hover:text-white'
          }`}
        >
          Pending Review ({synchronicities.filter((s) => s.status === 'pending').length})
        </button>
        <button
          onClick={() => setFilter('approved')}
          className={`px-4 py-1.5 rounded-xl transition-all ${
            filter === 'approved' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'
          }`}
        >
          Connected ({synchronicities.filter((s) => s.status === 'approved' || s.status === 'connected').length})
        </button>
      </div>

      {/* Synchronicity Cards List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredSynchronicities.map((sync) => {
          const isApproved = sync.status === 'approved' || sync.status === 'connected';
          return (
            <div
              key={sync.id}
              className={`bg-slate-900/90 border ${
                isApproved ? 'border-emerald-800/60 bg-emerald-950/10' : 'border-slate-800 hover:border-rose-500/50'
              } rounded-3xl p-6 flex flex-col justify-between space-y-5 shadow-2xl transition-all`}
            >
              {/* Header */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-md bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-extrabold uppercase tracking-wider">
                      {sync.matchType.replace(/_/g, ' ')}
                    </span>
                    <span className="text-xs font-extrabold text-emerald-400 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-emerald-400" />
                      {sync.compatibilityScore}% Compatibility
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500">{sync.discoveredAt}</span>
                </div>

                <h3 className="font-extrabold text-lg text-white">{sync.title}</h3>

                {/* Rationale */}
                <p className="text-xs text-slate-300 bg-white/70 p-3.5 rounded-2xl border border-slate-800 leading-relaxed">
                  💡 <strong className="text-slate-100">Why this synchronicity formed:</strong> {sync.rationale}
                </p>
              </div>

              {/* Intersecting Participants */}
              <div className="space-y-2.5">
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-rose-400" />
                  Intersecting Nodes ({sync.participants.length} People):
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {sync.participants.map((p) => (
                    <div
                      key={p.id}
                      className="flex items-center gap-3 bg-white/80 p-2.5 rounded-2xl border border-slate-800"
                    >
                      <img
                        src={p.avatar}
                        alt={p.name}
                        className="w-10 h-10 rounded-xl object-cover border border-slate-700 shrink-0"
                      />
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-200 truncate">{p.name}</p>
                        <p className="text-[10px] text-slate-400 truncate">{p.role}</p>
                        <p className="text-[10px] text-rose-300 font-medium truncate mt-0.5">
                          Intent: {p.matchedIntent}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Suggested Icebreaker */}
              {sync.suggestedIcebreaker && (
                <div className="bg-rose-950/20 border border-rose-900/50 p-3 rounded-2xl space-y-1">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1">
                    <MessageSquare className="w-3 h-3" /> AI Crafted Icebreaker
                  </p>
                  <p className="text-xs text-slate-200 italic">
                    "{sync.suggestedIcebreaker}"
                  </p>
                </div>
              )}

              {/* Action Buttons */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-3">
                {!isApproved ? (
                  <>
                    <button
                      onClick={() => respondToSynchronicity(sync.id, 'approved')}
                      className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white text-xs sm:text-sm font-bold py-2.5 px-4 rounded-2xl shadow-lg active:scale-95 transition-all text-center"
                    >
                      ✓ Approve Triple-Handshake Intro
                    </button>
                    <button
                      onClick={() => respondToSynchronicity(sync.id, 'declined')}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs font-semibold py-2.5 px-4 rounded-2xl transition-colors"
                    >
                      Decline
                    </button>
                  </>
                ) : (
                  <div className="w-full flex flex-col sm:flex-row items-center justify-between gap-3 bg-emerald-950/60 border border-emerald-800 p-3 rounded-2xl">
                    <div className="flex items-center gap-2 text-xs text-emerald-300 font-bold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      Triple-Handshake Introduction Dispatched!
                    </div>
                    <button
                      onClick={() => showToast('🎙️ Launching Synchronous Audio Session with participants...')}
                      className="bg-emerald-500 hover:bg-emerald-400 text-slate-800 text-xs font-extrabold px-4 py-2 rounded-xl shadow transition-all active:scale-95"
                    >
                      Launch Synchronous Chat & Audio Room →
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
