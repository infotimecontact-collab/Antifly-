import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Compass,
  GitBranch,
  Sparkles,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  Plus,
  Sliders,
  DollarSign,
  Globe,
  Layers,
  Award,
  Heart,
  Eye,
  Zap,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import { QuantumBranchScenario } from '../../types';

export const QuantumDecisionView: React.FC = () => {
  const {
    quantumDecisions,
    activeQuantumDecisionId,
    setActiveQuantumDecisionId,
    selectQuantumBranch,
    addQuantumDecision,
  } = useApp();

  const [isNewDecisionModalOpen, setIsNewDecisionModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newQuestion, setNewQuestion] = useState('');
  const [newCategory, setNewCategory] = useState<'career_venture' | 'geography_relocation' | 'creative_calling'>('career_venture');
  const [newRiskTolerance, setNewRiskTolerance] = useState(7);

  const activeDecision = quantumDecisions.find((d) => d.id === activeQuantumDecisionId) || quantumDecisions[0];

  const handleCreateDecision = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newQuestion.trim()) return;

    addQuantumDecision({
      title: newTitle,
      coreQuestion: newQuestion,
      category: newCategory,
      userRiskTolerance: newRiskTolerance,
      capitalRunwayMonths: 18,
      geographicFlexibility: 'hybrid_hub',
      aiSynthesisVerdict: 'Initial trajectory analysis indicates that focusing on open-source compounding provides maximum asymmetric upside.',
      branches: [
        {
          id: `branch_${Date.now()}_a`,
          branchTitle: 'Path A: Sovereign High-Conviction Build',
          horizon: '2_years',
          pathDescription: `Pursue primary hypothesis: ${newQuestion.slice(0, 80)}... with full independent execution.`,
          probabilityOfFulfillment: 85,
          regretMinimizationScore: 92,
          serendipityMultiplier: 3.1,
          dimensions: {
            skillMastery: 92,
            financialAutonomy: 84,
            socialCapital: 94,
            mentalWellbeing: 82,
            creativeFreedom: 96,
            globalImpact: 90,
          },
          keyMilestones: [
            'Month 3: Ship MVP with early feedback loops',
            'Month 9: Onboard first 100 passionate supporters',
            'Month 24: Industry benchmark achievement',
          ],
          devilsAdvocateCritique: 'Requires rigorous focus and emotional resilience during the early ramp-up phase.',
          optimistTrajectory: 'Maximized sovereign equity, creative autonomy, and generational network reputation.',
          recommendedPreRequisites: ['Build core ally syndicate in Goal Communities', 'Establish 12-month runway'],
        },
        {
          id: `branch_${Date.now()}_b`,
          branchTitle: 'Path B: Established Alliance & Co-Development',
          horizon: '2_years',
          pathDescription: 'Partner with established institution or venture lab for guaranteed resource backing.',
          probabilityOfFulfillment: 88,
          regretMinimizationScore: 74,
          serendipityMultiplier: 2.0,
          dimensions: {
            skillMastery: 86,
            financialAutonomy: 90,
            socialCapital: 80,
            mentalWellbeing: 86,
            creativeFreedom: 70,
            globalImpact: 84,
          },
          keyMilestones: [
            'Month 4: Strategic integration agreement signed',
            'Month 12: Joint prototype showcase',
            'Month 24: Core executive milestone',
          ],
          devilsAdvocateCritique: 'Potential dilution of creative vision and corporate roadmap dependencies.',
          optimistTrajectory: 'Immediate access to capital, distribution scale, and reduced downside volatility.',
          recommendedPreRequisites: ['Negotiate clear IP boundaries and governance veto rights'],
        },
      ],
    });

    setNewTitle('');
    setNewQuestion('');
    setIsNewDecisionModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Header & Selector Bar */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/60 to-slate-950 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
                <GitBranch className="w-5 h-5 animate-pulse" />
              </span>
              <span className="text-xs font-black uppercase tracking-widest text-purple-400">
                Quantum Multiverse Life Simulator
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                Probabilistic Modeling v3.4
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Life Crossroads &amp; Destiny Simulator
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Model high-stakes inflection points across 6 dimensions of fulfillment: Mastery, Autonomy, Social Capital, Wellbeing, Creative Freedom, and Global Impact.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setIsNewDecisionModalOpen(true)}
            className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-extrabold flex items-center gap-2 shadow-xl shadow-purple-500/20 active:scale-95 transition-all shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Simulate New Crossroad</span>
          </button>
        </div>

        {/* Decision Selectors */}
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none mt-6 pt-4 border-t border-slate-800/80">
          {quantumDecisions.map((decision) => (
            <button
              key={decision.id}
              type="button"
              onClick={() => setActiveQuantumDecisionId(decision.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-2 ${
                activeQuantumDecisionId === decision.id
                  ? 'bg-purple-500/30 text-purple-200 border border-purple-500/50 shadow-md'
                  : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-slate-800'
              }`}
            >
              <Compass className="w-3.5 h-3.5 text-purple-400" />
              <span className="truncate max-w-[240px]">{decision.title}</span>
            </button>
          ))}
        </div>
      </div>

      {activeDecision && (
        <div className="space-y-6">
          {/* Active Decision Overview Banner */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                  Core Inflection Query
                </span>
                <h2 className="text-lg sm:text-xl font-black text-white mt-0.5">
                  "{activeDecision.coreQuestion}"
                </h2>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-slate-800 text-purple-300 border border-slate-700">
                  Risk Dial: {activeDecision.userRiskTolerance}/10
                </span>
                <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-slate-800 text-cyan-300 border border-slate-700">
                  Runway: {activeDecision.capitalRunwayMonths} mos
                </span>
              </div>
            </div>

            <div className="bg-purple-950/40 border border-purple-800/40 rounded-xl p-4 flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
              <div>
                <div className="text-[11px] font-extrabold uppercase text-purple-300">
                  AI Multiverse Synthesis
                </div>
                <p className="text-xs text-slate-200 mt-0.5 leading-relaxed">
                  {activeDecision.aiSynthesisVerdict}
                </p>
              </div>
            </div>
          </div>

          {/* Multiverse Branch Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {activeDecision.branches.map((branch) => {
              const isSelected = activeDecision.activeSelectedBranchId === branch.id;

              return (
                <div
                  key={branch.id}
                  onClick={() => selectQuantumBranch(activeDecision.id, branch.id)}
                  className={`rounded-2xl p-6 border transition-all flex flex-col justify-between space-y-5 cursor-pointer ${
                    isSelected
                      ? 'bg-slate-900 border-purple-500 ring-2 ring-purple-500/30 shadow-2xl shadow-purple-500/10'
                      : 'bg-white border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                        {branch.horizon.replace('_', ' ')}
                      </span>
                      {isSelected ? (
                        <span className="flex items-center gap-1 text-[10px] font-black uppercase text-purple-400 bg-purple-500/20 px-2 py-0.5 rounded-full border border-purple-500/40">
                          <CheckCircle2 className="w-3 h-3" /> Selected Trajectory
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-500 font-bold">Click to Select</span>
                      )}
                    </div>

                    <h3 className="font-extrabold text-white text-base leading-snug">
                      {branch.branchTitle}
                    </h3>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {branch.pathDescription}
                    </p>

                    {/* Key Metrics */}
                    <div className="grid grid-cols-3 gap-2 pt-2 text-center">
                      <div className="bg-slate-900/90 rounded-xl p-2 border border-slate-800">
                        <div className="text-[9px] text-slate-400 uppercase font-bold">Fulfillment</div>
                        <div className="text-sm font-black text-emerald-400 mt-0.5">{branch.probabilityOfFulfillment}%</div>
                      </div>
                      <div className="bg-slate-900/90 rounded-xl p-2 border border-slate-800">
                        <div className="text-[9px] text-slate-400 uppercase font-bold">Regret Min.</div>
                        <div className="text-sm font-black text-purple-300 mt-0.5">{branch.regretMinimizationScore}/100</div>
                      </div>
                      <div className="bg-slate-900/90 rounded-xl p-2 border border-slate-800">
                        <div className="text-[9px] text-slate-400 uppercase font-bold">Serendipity</div>
                        <div className="text-sm font-black text-cyan-400 mt-0.5">{branch.serendipityMultiplier}x</div>
                      </div>
                    </div>

                    {/* 6 Dimensions Radar Bars */}
                    <div className="space-y-1.5 pt-3 border-t border-slate-800/80">
                      <div className="text-[10px] font-bold uppercase text-slate-400 mb-1">
                        Multidimensional Impact Score
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-[10px] text-slate-300">
                          <span>Mastery &amp; Skills</span>
                          <span className="text-cyan-400 font-bold">{branch.dimensions.skillMastery}%</span>
                        </div>
                        <div className="w-full bg-slate-800 rounded-full h-1">
                          <div className="bg-cyan-400 h-full rounded-full" style={{ width: `${branch.dimensions.skillMastery}%` }} />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-[10px] text-slate-300">
                          <span>Financial Autonomy</span>
                          <span className="text-emerald-400 font-bold">{branch.dimensions.financialAutonomy}%</span>
                        </div>
                        <div className="w-full bg-slate-800 rounded-full h-1">
                          <div className="bg-emerald-400 h-full rounded-full" style={{ width: `${branch.dimensions.financialAutonomy}%` }} />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-[10px] text-slate-300">
                          <span>Social Capital &amp; Network</span>
                          <span className="text-purple-400 font-bold">{branch.dimensions.socialCapital}%</span>
                        </div>
                        <div className="w-full bg-slate-800 rounded-full h-1">
                          <div className="bg-purple-400 h-full rounded-full" style={{ width: `${branch.dimensions.socialCapital}%` }} />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-[10px] text-slate-300">
                          <span>Creative Freedom</span>
                          <span className="text-amber-400 font-bold">{branch.dimensions.creativeFreedom}%</span>
                        </div>
                        <div className="w-full bg-slate-800 rounded-full h-1">
                          <div className="bg-amber-400 h-full rounded-full" style={{ width: `${branch.dimensions.creativeFreedom}%` }} />
                        </div>
                      </div>
                    </div>

                    {/* Milestones */}
                    <div className="pt-2">
                      <div className="text-[10px] font-bold uppercase text-slate-400 mb-1.5">
                        Key Milestones
                      </div>
                      <div className="space-y-1">
                        {branch.keyMilestones.map((m, idx) => (
                          <div key={idx} className="text-xs text-slate-300 flex items-start gap-1.5">
                            <span className="text-purple-400 font-bold">›</span>
                            <span>{m}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Devil's Advocate & Optimist Box */}
                    <div className="space-y-2 pt-2">
                      <div className="bg-rose-950/30 border border-rose-900/40 rounded-xl p-2.5 text-xs text-rose-200">
                        <span className="font-bold flex items-center gap-1 text-rose-400 text-[10px] uppercase mb-0.5">
                          <AlertTriangle className="w-3 h-3" /> Devil's Advocate
                        </span>
                        {branch.devilsAdvocateCritique}
                      </div>

                      <div className="bg-emerald-950/30 border border-emerald-900/40 rounded-xl p-2.5 text-xs text-emerald-200">
                        <span className="font-bold flex items-center gap-1 text-emerald-400 text-[10px] uppercase mb-0.5">
                          <Sparkles className="w-3 h-3" /> Optimist Trajectory
                        </span>
                        {branch.optimistTrajectory}
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      selectQuantumBranch(activeDecision.id, branch.id);
                    }}
                    className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      isSelected
                        ? 'bg-purple-600 text-white shadow-lg'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                    }`}
                  >
                    <span>{isSelected ? 'Active Trajectory' : 'Choose This Path'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Modal: Simulate New Decision */}
      {isNewDecisionModalOpen && (
        <div className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-white text-lg flex items-center gap-2">
                <GitBranch className="w-5 h-5 text-purple-400" />
                <span>Simulate Quantum Crossroads</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsNewDecisionModalOpen(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateDecision} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Crossroad Title
                </label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Move to Tokyo vs. Stay in SF"
                  className="w-full bg-white border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 outline-none focus:border-purple-500"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Core Inflection Question
                </label>
                <textarea
                  value={newQuestion}
                  onChange={(e) => setNewQuestion(e.target.value)}
                  placeholder="What is the deepest trade-off or hypothesis you want to stress-test?"
                  rows={3}
                  className="w-full bg-white border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 outline-none focus:border-purple-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full bg-white border border-slate-800 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-purple-500"
                  >
                    <option value="career_venture">Career &amp; Venture</option>
                    <option value="geography_relocation">Geography &amp; Relocation</option>
                    <option value="creative_calling">Creative Calling</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    Risk Tolerance (1-10): {newRiskTolerance}
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={newRiskTolerance}
                    onChange={(e) => setNewRiskTolerance(Number(e.target.value))}
                    className="w-full mt-2 accent-purple-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsNewDecisionModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-extrabold shadow-lg cursor-pointer"
                >
                  Generate Quantum Multiverse
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
