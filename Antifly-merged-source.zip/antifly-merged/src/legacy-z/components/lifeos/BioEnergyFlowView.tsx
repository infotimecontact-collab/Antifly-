import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Zap,
  Shield,
  ShieldAlert,
  Headphones,
  Volume2,
  VolumeX,
  Sparkles,
  Activity,
  BatteryCharging,
  Clock,
  Flame,
  Sun,
  Moon,
  Brain,
  Waves,
  RefreshCw,
  CheckCircle2,
  Radio,
  Sliders,
  BellOff,
  Compass,
  Smile,
} from 'lucide-react';
import { motion } from 'motion/react';

export const BioEnergyFlowView: React.FC = () => {
  const {
    bioEnergyProfile,
    toggleFlowShield,
    toggleSoundscapePlay,
    selectSoundscape,
    setActiveLifeOSTab,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'matrix' | 'soundscapes' | 'rhythm'>('matrix');
  const [binauralFreq, setBinauralFreq] = useState<number>(40); // 40Hz Gamma Focus

  const soundscapesList = [
    {
      id: 'cyber_focus_alpha',
      title: 'Deep Alpha Binaural (40Hz Gamma Pulse)',
      category: 'Deep Focus & Neural Code',
      frequency: '40 Hz Gamma',
      ambientType: 'Binaural Synth + White Pink Noise',
      gradient: 'from-cyan-500/20 to-indigo-500/20 border-cyan-500/40',
      icon: Brain,
    },
    {
      id: 'solar_wind_theta',
      title: 'Lo-Fi Solar Wind Resonance',
      category: 'Creative Synthesis & Brainstorming',
      frequency: '7.83 Hz Schumann Resonance',
      ambientType: 'Solar Winds + Analog Warmth',
      gradient: 'from-amber-500/20 to-orange-500/20 border-amber-500/40',
      icon: Sun,
    },
    {
      id: 'shibuya_rain_spatial',
      title: 'Ambient Rain in Shibuya Corridor',
      category: 'Spatial Radar & Serendipity Walk',
      frequency: 'Wide Spatial Stereo',
      ambientType: 'Binaural Tokyo Raindrops + Distant Cafe Hub',
      gradient: 'from-blue-500/20 to-emerald-500/20 border-blue-500/40',
      icon: Waves,
    },
    {
      id: 'delta_sleep_recharge',
      title: 'Delta Wave Deep Parasympathetic Recharge',
      category: 'Restorative Sleep & Bio-Recovery',
      frequency: '2.5 Hz Delta Harmony',
      ambientType: 'Sub-bass Harmonic Drone + Tibetan Singing Bowl',
      gradient: 'from-purple-500/20 to-rose-500/20 border-purple-500/40',
      icon: Moon,
    },
  ];

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Hero Header & Flow Shield Command Bar */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/60 to-slate-950 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                <Activity className="w-5 h-5 animate-pulse" />
              </span>
              <span className="text-xs font-black uppercase tracking-widest text-cyan-400">
                Biological &amp; Cognitive Flow Matrix
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                {bioEnergyProfile.heartRateVariabilityState}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Circadian Rhythm &amp; Focus Resonance
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Harmonizes your daily schedule with real-time biological energy peaks, automated Flow Shield protection, and neuro-acoustic resonance soundscapes.
            </p>
          </div>

          {/* Interactive Flow Shield Quick Toggle */}
          <div className="flex flex-col items-start sm:items-end gap-3 shrink-0">
            <div className="flex items-center gap-3 bg-white/80 border border-slate-800 p-2 rounded-2xl backdrop-blur-md">
              <div className="text-left sm:text-right px-2">
                <div className="text-[10px] uppercase font-bold text-slate-400">LifeOS Flow Shield</div>
                <div className="text-xs font-black text-white flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${bioEnergyProfile.flowShieldActive ? 'bg-cyan-400 animate-ping' : 'bg-slate-500'}`} />
                  {bioEnergyProfile.flowShieldActive ? 'ARMED & BATCHING' : 'OPEN RADAR'}
                </div>
              </div>

              <button
                type="button"
                onClick={toggleFlowShield}
                className={`px-4 py-2 rounded-xl text-xs font-extrabold transition-all shadow-lg flex items-center gap-2 cursor-pointer active:scale-95 ${
                  bioEnergyProfile.flowShieldActive
                    ? 'bg-gradient-to-r from-cyan-500 to-indigo-600 text-white shadow-cyan-500/30'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                }`}
              >
                {bioEnergyProfile.flowShieldActive ? (
                  <>
                    <Shield className="w-4 h-4 text-cyan-300" />
                    <span>Disengage Shield</span>
                  </>
                ) : (
                  <>
                    <BellOff className="w-4 h-4 text-slate-400" />
                    <span>Engage Flow Shield</span>
                  </>
                )}
              </button>
            </div>

            <div className="text-[11px] text-slate-400 flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              <span>Circadian Peak: <strong className="text-slate-200">{bioEnergyProfile.circadianPeakHour}</strong></span>
            </div>
          </div>
        </div>

        {/* 4 Real-time Biometric Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800/80">
          <div className="bg-white/60 rounded-2xl p-3 border border-slate-800/60">
            <div className="text-[10px] text-slate-400 font-bold uppercase flex items-center justify-between">
              <span>Bio-Readiness</span>
              <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="text-xl sm:text-2xl font-black text-white mt-1">
              {bioEnergyProfile.currentEnergyScore}%
            </div>
            <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2 overflow-hidden">
              <div className="bg-gradient-to-r from-emerald-500 to-cyan-400 h-full rounded-full" style={{ width: `${bioEnergyProfile.currentEnergyScore}%` }} />
            </div>
          </div>

          <div className="bg-white/60 rounded-2xl p-3 border border-slate-800/60">
            <div className="text-[10px] text-slate-400 font-bold uppercase flex items-center justify-between">
              <span>Current Resonance</span>
              <Brain className="w-3.5 h-3.5 text-cyan-400" />
            </div>
            <div className="text-sm sm:text-base font-extrabold text-cyan-300 mt-1 truncate">
              {bioEnergyProfile.focusResonanceState}
            </div>
            <div className="text-[10px] text-slate-400 mt-1">
              Gamma 40Hz optimal
            </div>
          </div>

          <div className="bg-white/60 rounded-2xl p-3 border border-slate-800/60">
            <div className="text-[10px] text-slate-400 font-bold uppercase flex items-center justify-between">
              <span>Cognitive Surplus</span>
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <div className="text-xl sm:text-2xl font-black text-white mt-1">
              {bioEnergyProfile.cognitiveSurplusRemaining}h
            </div>
            <div className="text-[10px] text-slate-400 mt-1">
              High-load capacity remaining
            </div>
          </div>

          <div className="bg-white/60 rounded-2xl p-3 border border-slate-800/60">
            <div className="text-[10px] text-slate-400 font-bold uppercase flex items-center justify-between">
              <span>Daily Flow Logged</span>
              <Flame className="w-3.5 h-3.5 text-rose-400" />
            </div>
            <div className="text-xl sm:text-2xl font-black text-rose-300 mt-1">
              {bioEnergyProfile.dailyFlowHoursLogged} hrs
            </div>
            <div className="text-[10px] text-emerald-400 font-bold mt-1">
              +1.2h vs weekly avg
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          type="button"
          onClick={() => setActiveTab('matrix')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'matrix'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          Daily Flow Windows ({bioEnergyProfile.flowWindows.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('soundscapes')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
            activeTab === 'soundscapes'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Headphones className="w-3.5 h-3.5 text-indigo-400" />
          <span>Binaural Soundscapes</span>
          {bioEnergyProfile.isSoundscapePlaying && (
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          )}
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('rhythm')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'rhythm'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          AI Bio Recommendations ({bioEnergyProfile.aiBioRecommendations.length})
        </button>
      </div>

      {/* TAB 1: FLOW WINDOWS MATRIX */}
      {activeTab === 'matrix' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              <span>Personalized Chronotype Schedule</span>
            </h3>
            <span className="text-xs text-slate-400">Auto-synchronized with Google Calendar &amp; Oura/Apple Health Signals</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {bioEnergyProfile.flowWindows.map((window) => (
              <div
                key={window.id}
                className={`rounded-2xl p-5 border transition-all flex flex-col justify-between space-y-4 ${
                  window.isActiveNow
                    ? 'bg-slate-900/90 border-cyan-500 ring-2 ring-cyan-500/20 shadow-xl shadow-cyan-500/10'
                    : 'bg-white/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black text-slate-300 px-2 py-0.5 rounded-md bg-slate-800 border border-slate-700">
                        {window.startTime} - {window.endTime}
                      </span>
                      {window.isActiveNow && (
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-cyan-500 text-slate-800 flex items-center gap-1 animate-pulse">
                          <span className="w-1.5 h-1.5 rounded-full bg-white" />
                          ACTIVE NOW
                        </span>
                      )}
                    </div>

                    <span className="text-[10px] font-bold text-slate-400 uppercase">
                      {window.windowType.replace('_', ' ')}
                    </span>
                  </div>

                  <h4 className="font-extrabold text-white text-sm mb-1.5">
                    {window.title}
                  </h4>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {window.suggestedAction}
                  </p>
                </div>

                {/* Capacity Dials */}
                <div className="space-y-2 pt-2 border-t border-slate-800/80">
                  <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold">
                    <span>Cognitive Capacity</span>
                    <span className="text-cyan-400">{window.cognitiveLoadCapacity}%</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                    <div className="bg-cyan-400 h-full rounded-full" style={{ width: `${window.cognitiveLoadCapacity}%` }} />
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold pt-1">
                    <span>Serendipity Readiness</span>
                    <span className="text-amber-400">{window.serendipityReadiness}%</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                    <div className="bg-amber-400 h-full rounded-full" style={{ width: `${window.serendipityReadiness}%` }} />
                  </div>
                </div>

                {/* Soundscape Recommendation */}
                <div className="flex items-center justify-between pt-2 text-[11px] bg-slate-900/60 rounded-xl p-2.5 border border-slate-800">
                  <div className="flex items-center gap-2 truncate">
                    <Headphones className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                    <span className="text-slate-300 truncate">{window.recommendedSoundscape}</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => toggleSoundscapePlay(window.recommendedSoundscape)}
                    className="p-1.5 rounded-lg bg-indigo-600/30 hover:bg-indigo-600 text-indigo-300 hover:text-white transition-all shrink-0 cursor-pointer"
                    title="Play Soundscape"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: NEURO SOUNDSCAPES & BINAURAL GENERATOR */}
      {activeTab === 'soundscapes' && (
        <div className="space-y-6">
          <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
                <Headphones className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <h3 className="font-extrabold text-white text-base">Binaural Neuro-Acoustic Synthesizer</h3>
                <p className="text-xs text-slate-400">
                  Active Frequency Modulation: <strong className="text-cyan-400">{binauralFreq} Hz (Gamma Hyper-Focus)</strong>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto">
              <input
                type="range"
                min="1"
                max="60"
                value={binauralFreq}
                onChange={(e) => setBinauralFreq(Number(e.target.value))}
                className="w-full sm:w-40 accent-cyan-400"
              />
              <button
                type="button"
                onClick={() => toggleSoundscapePlay()}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg cursor-pointer shrink-0"
              >
                {bioEnergyProfile.isSoundscapePlaying ? (
                  <>
                    <VolumeX className="w-4 h-4" />
                    <span>Pause Audio</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-4 h-4" />
                    <span>Start Audio Loop</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {soundscapesList.map((sound) => {
              const Icon = sound.icon;
              const isSelected = bioEnergyProfile.activeSoundscapeId === sound.id;

              return (
                <div
                  key={sound.id}
                  onClick={() => selectSoundscape(sound.id)}
                  className={`rounded-2xl p-5 border transition-all cursor-pointer flex items-start gap-4 ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-500 ring-2 ring-cyan-500/30'
                      : 'bg-white border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center text-cyan-400 shrink-0">
                    <Icon className="w-5 h-5" />
                  </div>

                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-slate-400 uppercase">{sound.category}</span>
                      <span className="text-[10px] font-mono text-cyan-400">{sound.frequency}</span>
                    </div>
                    <h4 className="font-extrabold text-white text-sm truncate">{sound.title}</h4>
                    <p className="text-xs text-slate-400">{sound.ambientType}</p>

                    <div className="pt-2 flex items-center justify-between">
                      <span className="text-[11px] text-emerald-400 font-bold">
                        {isSelected && bioEnergyProfile.isSoundscapePlaying ? '● Playing Live' : 'Select Preset'}
                      </span>
                      <Volume2 className={`w-4 h-4 ${isSelected ? 'text-cyan-400' : 'text-slate-600'}`} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: AI BIO RECOMMENDATIONS */}
      {activeTab === 'rhythm' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {bioEnergyProfile.aiBioRecommendations.map((rec) => (
              <div
                key={rec.id}
                className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-3 flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-slate-800 text-slate-300">
                      {rec.category.replace('_', ' ')}
                    </span>
                    <span className={`text-[10px] font-extrabold uppercase ${
                      rec.priority === 'high' ? 'text-rose-400' : rec.priority === 'medium' ? 'text-amber-400' : 'text-slate-400'
                    }`}>
                      {rec.priority} priority
                    </span>
                  </div>

                  <p className="text-xs font-bold text-white leading-relaxed">
                    {rec.insight}
                  </p>
                </div>

                <div className="bg-white/80 rounded-xl p-3 border border-slate-800/80">
                  <div className="text-[10px] text-slate-400 uppercase font-bold mb-1">Prescribed Action</div>
                  <div className="text-xs text-cyan-300 font-medium">
                    {rec.suggestedAction}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
