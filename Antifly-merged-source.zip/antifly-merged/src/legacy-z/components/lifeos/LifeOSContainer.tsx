import React from 'react';
import { useApp } from '../../context/AppContext';
import { LifeOSHeader } from './LifeOSHeader';
import { MyWorldDashboard } from './MyWorldDashboard';
import { IntentManager } from './IntentManager';
import { TemporaryWorldsView } from './TemporaryWorldsView';
import { SynchronicityHubView } from './SynchronicityHubView';
import { UniversalDiscoveryView } from './UniversalDiscoveryView';
import { SocialMapView } from './SocialMapView';
import { SocialGraphView } from './SocialGraphView';
import { LifeMemoryView } from './LifeMemoryView';
import { ExperienceContentFeed } from './ExperienceContentFeed';

// Next-Gen LifeOS & Social Integration Views
import { LifeRadarView } from './LifeRadarView';
import { FutureYouView } from './FutureYouView';
import { OpportunityExchangeView } from './OpportunityExchangeView';
import { DynamicSkillGraphView } from './DynamicSkillGraphView';
import { GoalCommunitiesView } from './GoalCommunitiesView';
import { PersonalGrowthGraphView } from './PersonalGrowthGraphView';
import { PhysicalMomentsView } from './PhysicalMomentsView';
import { BioEnergyFlowView } from './BioEnergyFlowView';
import { QuantumDecisionView } from './QuantumDecisionView';
import { AutonomousAgentSwarmView } from './AutonomousAgentSwarmView';
import { LifeOSPlannerView } from './LifeOSPlannerView';
import { LifeOSJournalView } from './LifeOSJournalView';
import { LifeOSGoalsView } from './LifeOSGoalsView';
import { SocialFeedView } from '../social/SocialFeedView';
import { MomentsRadarView } from '../social/MomentsRadarView';
import { OpportunityRadarView } from '../social/OpportunityRadarView';

// Modals & Living Engines
import { IntentStudioModal } from './IntentStudioModal';
import { CreateWorldModal } from './CreateWorldModal';
import { AISocialTwinModal } from './AISocialTwinModal';
import { VoiceAssistantModal } from './VoiceAssistantModal';
import { SafetyTrustModal } from './SafetyTrustModal';
import { CommunityEmergenceModal } from './CommunityEmergenceModal';
import { AIPrivacyCenterModal } from './AIPrivacyCenterModal';
import { SocialDataPortabilityModal } from './SocialDataPortabilityModal';
import { IdeaCollisionModal } from './IdeaCollisionModal';
import { ContextAwareChatModal } from './ContextAwareChatModal';
import { LifeOSAgentModal } from './LifeOSAgentModal';
import { SerendipityModal } from './SerendipityModal';
import { AITwinDashboardModal } from '../social/AITwinDashboardModal';
import { IntroduceMeModal } from '../social/IntroduceMeModal';
import { CreateSocialEntityModal } from '../social/CreateSocialEntityModal';

export const LifeOSContainer: React.FC = () => {
  const { activeLifeOSTab, setActiveLifeOSTab } = useApp();

  return (
    <div className="min-h-screen bg-white text-slate-100 selection:bg-cyan-500 selection:text-slate-900 antialiased font-sans pb-16">
      {/* Universal LifeOS Sticky Header */}
      <LifeOSHeader />

      {/* Main Dynamic Viewport */}
      <main className="max-w-7xl mx-auto px-2 sm:px-4 pt-4">
        {activeLifeOSTab === 'my_world' && <MyWorldDashboard />}
        {activeLifeOSTab === 'planner' && <LifeOSPlannerView />}
        {activeLifeOSTab === 'feed' && <SocialFeedView />}
        {activeLifeOSTab === 'journal' && <LifeOSJournalView />}
        {activeLifeOSTab === 'goals' && <LifeOSGoalsView />}
        {activeLifeOSTab === 'bio_energy' && <BioEnergyFlowView />}
        {activeLifeOSTab === 'quantum_decision' && <QuantumDecisionView />}
        {activeLifeOSTab === 'agent_swarm' && <AutonomousAgentSwarmView />}
        {activeLifeOSTab === 'radar' && <LifeRadarView />}
        {activeLifeOSTab === 'future_you' && <FutureYouView />}
        {activeLifeOSTab === 'opportunity_exchange' && <OpportunityExchangeView />}
        {activeLifeOSTab === 'skill_graph' && <DynamicSkillGraphView />}
        {activeLifeOSTab === 'goal_communities' && <GoalCommunitiesView />}
        {activeLifeOSTab === 'growth_graph' && <PersonalGrowthGraphView />}
        {activeLifeOSTab === 'moments' && <PhysicalMomentsView />}
        {activeLifeOSTab === 'intents' && <IntentManager />}
        {activeLifeOSTab === 'worlds' && <TemporaryWorldsView />}
        {activeLifeOSTab === 'synchronicity' && <SynchronicityHubView />}
        {activeLifeOSTab === 'discovery' && <UniversalDiscoveryView />}
        {activeLifeOSTab === 'map' && <SocialMapView />}
        {activeLifeOSTab === 'graph' && <SocialGraphView />}
        {activeLifeOSTab === 'memory' && <LifeMemoryView />}
      </main>

      {/* Modals & Living Engines */}
      <IntentStudioModal />
      <CreateWorldModal />
      <AISocialTwinModal />
      <VoiceAssistantModal />
      <SafetyTrustModal />
      <CommunityEmergenceModal />
      <AIPrivacyCenterModal />
      <SocialDataPortabilityModal />
      <IdeaCollisionModal />
      <ContextAwareChatModal />
      <LifeOSAgentModal />
      <SerendipityModal />
      <AITwinDashboardModal />
      <IntroduceMeModal />
      <CreateSocialEntityModal />
    </div>
  );
};

