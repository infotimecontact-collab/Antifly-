import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Target,
  Users,
  Calendar,
  CheckCircle2,
  Circle,
  PlusCircle,
  Sparkles,
  Flame,
  Award,
  ArrowRight,
  ShieldCheck,
  UserCheck,
  TrendingUp,
} from 'lucide-react';
import { GoalCommunity } from '../../types';

export const GoalCommunitiesView: React.FC = () => {
  const { goalCommunities, toggleJoinGoalCommunity, addGoalCommunitySprintTask, setContextAwareChatPeer, setIsContextAwareChatOpen } = useApp();

  const [selectedCommunityId, setSelectedCommunityId] = useState<string>(
    goalCommunities[0]?.id || ''
  );
  const [newTaskTitle, setNewTaskTitle] = useState<string>('');

  const selectedCommunity =
    goalCommunities.find((g) => g.id === selectedCommunityId) || goalCommunities[0];

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim() || !selectedCommunity) return;
    addGoalCommunitySprintTask(selectedCommunity.id, newTaskTitle.trim());
    setNewTaskTitle('');
  };

  const handleMentorConnect = (mentor: { name: string; avatar: string; role: string }) => {
    setContextAwareChatPeer({
      name: mentor.name,
      avatar: mentor.avatar,
      sharedContext: `Goal Community Lead Mentor: ${selectedCommunity?.title}`,
      matchRationale: mentor.role,
    });
    setIsContextAwareChatOpen(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8 animate-fadeIn">
      {/* Hero Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-rose-950/40 to-slate-950 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute -right-16 -top-16 w-80 h-80 rounded-full bg-rose-500/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/80 border border-rose-800 text-rose-400 text-xs font-semibold">
              <Target className="w-3.5 h-3.5" />
              <span>Sprint-Based Collective Momentum</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Goal Communities & Sprints
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              Join focused cohorts designed around shared milestones and real outcomes. No aimless scrolling—pure collective accountability, live sprint boards, and mentor guidance.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-white/80 border border-slate-800 p-4 rounded-2xl text-xs space-y-1 text-center">
              <span className="text-slate-400 block">Active Sprints</span>
              <span className="text-xl font-bold text-rose-400 block">{goalCommunities.length} Cohorts</span>
            </div>
          </div>
        </div>
      </div>

      {/* Cohort Selector Tabs */}
      <div className="flex items-center gap-3 overflow-x-auto scrollbar-none pb-1">
        {goalCommunities.map((comm) => (
          <button
            key={comm.id}
            onClick={() => setSelectedCommunityId(comm.id)}
            className={`px-4 py-3 rounded-2xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-2 ${
              selectedCommunity?.id === comm.id
                ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/25'
                : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800'
            }`}
          >
            <Target className="w-3.5 h-3.5" />
            <span>{comm.title}</span>
            {comm.isJoined && (
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-white text-emerald-400 font-bold">
                Joined
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Selected Goal Community Deep-Dive */}
      {selectedCommunity && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-8 shadow-2xl">
          {/* Header Bar */}
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-6 border-b border-slate-800 pb-6">
            <div className="space-y-2 max-w-3xl">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-rose-950/80 border border-rose-800 text-rose-400 text-xs font-bold uppercase tracking-wider">
                  {selectedCommunity.category.replace('_', ' ')}
                </span>
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  {selectedCommunity.sprintDuration}
                </span>
              </div>
              <h2 className="text-2xl font-extrabold text-white">{selectedCommunity.title}</h2>
              <p className="text-sm text-slate-300 leading-relaxed">
                {selectedCommunity.description}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-end sm:items-center gap-3">
              <div className="text-right">
                <span className="text-xs text-slate-400 block">Members on Sprint</span>
                <span className="text-lg font-bold text-white">
                  {selectedCommunity.memberCount.toLocaleString()} Builders
                </span>
              </div>

              <button
                onClick={() => toggleJoinGoalCommunity(selectedCommunity.id)}
                className={`px-5 py-2.5 rounded-2xl text-xs font-bold transition-all shadow-lg active:scale-95 whitespace-nowrap ${
                  selectedCommunity.isJoined
                    ? 'bg-slate-800 hover:bg-rose-950/80 border border-slate-700 text-slate-200 hover:text-rose-300'
                    : 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/20'
                }`}
              >
                {selectedCommunity.isJoined ? 'Joined Sprint (Leave)' : 'Join This Sprint Cohort'}
              </button>
            </div>
          </div>

          {/* Current Sprint Progress Bar */}
          <div className="bg-white/70 border border-slate-800 rounded-2xl p-4 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-semibold flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-rose-400" />
                {selectedCommunity.currentWeek} Sprint Window
              </span>
              <span className="text-rose-400 font-bold">
                {selectedCommunity.milestones.filter((m) => m.completed).length} of{' '}
                {selectedCommunity.milestones.length} Cohort Milestones Complete
              </span>
            </div>
            <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden">
              <div
                className="bg-gradient-to-r from-rose-500 to-amber-400 h-2 rounded-full transition-all duration-500"
                style={{
                  width: `${
                    (selectedCommunity.milestones.filter((m) => m.completed).length /
                      selectedCommunity.milestones.length) *
                    100
                  }%`,
                }}
              />
            </div>
          </div>

          {/* 2-Column Grid: Milestones vs Sprint Task Board */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Left: Milestone Schedule */}
            <div className="bg-white/70 border border-slate-800/80 rounded-2xl p-5 space-y-4">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400" />
                <span>Cohort Roadmap Milestones</span>
              </h3>

              <div className="space-y-3">
                {selectedCommunity.milestones.map((m) => (
                  <div
                    key={m.id}
                    className={`p-3.5 rounded-2xl border flex items-start justify-between gap-3 ${
                      m.completed
                        ? 'bg-slate-900/60 border-emerald-500/30'
                        : 'bg-slate-900/40 border-slate-800'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      {m.completed ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <Circle className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <span
                          className={`text-xs font-bold block ${
                            m.completed ? 'text-slate-200' : 'text-slate-300'
                          }`}
                        >
                          {m.title}
                        </span>
                        <span className="text-[11px] text-slate-500">{m.targetWeek}</span>
                      </div>
                    </div>

                    <span className="text-[10px] px-2 py-0.5 rounded-md bg-white text-slate-400">
                      {m.deliverableType}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Active Member Sprint Tasks */}
            <div className="bg-white/70 border border-slate-800/80 rounded-2xl p-5 space-y-4">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-cyan-400" />
                <span>Live Member Sprint Board</span>
              </h3>

              {/* Add task form */}
              <form onSubmit={handleAddTask} className="flex gap-2">
                <input
                  type="text"
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  placeholder="Add your sprint commit for this week..."
                  className="flex-1 bg-slate-900 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 rounded-xl px-3 py-2 outline-none focus:border-rose-500"
                />
                <button
                  type="submit"
                  className="px-3.5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold"
                >
                  Commit
                </button>
              </form>

              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {selectedCommunity.activeSprintTasks.map((t) => (
                  <div
                    key={t.id}
                    className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-rose-400" />
                      <span className="text-slate-200">{t.task}</span>
                    </div>
                    <span className="text-[10px] text-slate-500 shrink-0">by {t.authorName}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Lead Mentors */}
          <div className="space-y-3 pt-2 border-t border-slate-800">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Users className="w-4 h-4 text-indigo-400" />
              <span>Sprint Lead Mentors & Office Hours</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {selectedCommunity.leadMentors.map((mentor, idx) => (
                <div
                  key={idx}
                  className="bg-white/80 border border-slate-800 rounded-2xl p-4 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={mentor.avatar}
                      alt={mentor.name}
                      className="w-10 h-10 rounded-xl object-cover border border-slate-700"
                    />
                    <div>
                      <span className="font-bold text-xs text-white block">{mentor.name}</span>
                      <p className="text-[11px] text-slate-400">{mentor.role}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleMentorConnect(mentor)}
                    className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold"
                  >
                    Office Hours
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
