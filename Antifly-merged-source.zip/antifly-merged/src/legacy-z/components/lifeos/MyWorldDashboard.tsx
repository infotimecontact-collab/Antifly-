import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  Zap,
  Globe,
  HeartHandshake,
  MapPin,
  Clock,
  ArrowRight,
  Plus,
  Users,
  Compass,
  Bot,
  ShieldCheck,
  CheckCircle2,
  Share2,
  Calendar,
  Layers,
  ChevronRight,
  TrendingUp,
  MessageCircle,
  ExternalLink,
} from 'lucide-react';
import { LifeIntent, SocialWorld, SocialSynchronicity } from '../../types';

export const MyWorldDashboard: React.FC = () => {
  const {
    lifeIntents,
    socialWorlds,
    synchronicities,
    universalDiscoveryItems,
    lifeMemories,
    mapNodes,
    setActiveLifeOSTab,
    setIsLifeIntentModalOpen,
    setIsCreateWorldModalOpen,
    respondToSynchronicity,
    joinSocialWorld,
    setActiveWorldDetail,
    setIsAITwinDashboardOpen,
    showToast,
  } = useApp();

  const activeIntents = lifeIntents.filter((i) => i.status === 'active');
  const pendingSynchronicities = synchronicities.filter((s) => s.status === 'pending');
  const joinedWorlds = socialWorlds.filter((w) => w.isJoined);
  const peopleDiscovery = universalDiscoveryItems.filter((d) => d.entityType === 'people').slice(0, 3);
  const opportunitiesDiscovery = universalDiscoveryItems.filter((d) => d.entityType === 'opportunity' || d.entityType === 'business').slice(0, 2);
  const recentMemories = lifeMemories.slice(0, 2);

  return (
    <div className="space-y-8 pb-16">
      {/* 1. RIGHT NOW: Real-Time Life Context Banner */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/70 to-slate-900 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-8 w-64 h-64 bg-fuchsia-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              <span>Right Now • Context Engine Synchronized</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Good morning, <span className="bg-gradient-to-r from-cyan-400 to-indigo-400 bg-clip-text text-transparent">Alex Rivera</span>
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Your AI Social Twin is actively cross-referencing <strong className="text-white">{activeIntents.length} active intentions</strong> across <strong className="text-white">San Francisco, Tokyo & Global Remote</strong>. 3 high-signal synchronicities detected today.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setIsLifeIntentModalOpen(true)}
              className="flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white text-xs sm:text-sm font-semibold px-4 py-2.5 rounded-2xl shadow-lg shadow-cyan-500/25 active:scale-95 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Express What You Need</span>
            </button>
            <button
              onClick={() => setIsAITwinDashboardOpen(true)}
              className="flex items-center gap-2 bg-slate-800/80 hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs sm:text-sm font-medium px-4 py-2.5 rounded-2xl transition-all"
            >
              <Bot className="w-4 h-4 text-indigo-400" />
              <span>Twin Permissions</span>
            </button>
          </div>
        </div>

        {/* Live Context Signals Bar */}
        <div className="mt-6 pt-6 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div className="flex items-center gap-2.5 text-slate-300">
            <div className="w-7 h-7 rounded-lg bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400 shrink-0">
              <MapPin className="w-3.5 h-3.5" />
            </div>
            <div>
              <p className="text-[10px] text-slate-500 font-medium">LOCATION ZONE</p>
              <p className="font-semibold text-slate-200">SOMA, San Francisco</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 text-slate-300">
            <div className="w-7 h-7 rounded-lg bg-amber-950 border border-amber-800 flex items-center justify-center text-amber-400 shrink-0">
              <Zap className="w-3.5 h-3.5" />
            </div>
            <div>
              <p className="text-[10px] text-slate-500 font-medium">PRIMARY SEEKING</p>
              <p className="font-semibold text-slate-200">Spatial AI Co-Founder</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 text-slate-300">
            <div className="w-7 h-7 rounded-lg bg-indigo-950 border border-indigo-800 flex items-center justify-center text-indigo-400 shrink-0">
              <Calendar className="w-3.5 h-3.5" />
            </div>
            <div>
              <p className="text-[10px] text-slate-500 font-medium">UPCOMING TRAVEL</p>
              <p className="font-semibold text-slate-200">Tokyo & Kyoto (Sept)</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 text-slate-300">
            <div className="w-7 h-7 rounded-lg bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400 shrink-0">
              <ShieldCheck className="w-3.5 h-3.5" />
            </div>
            <div>
              <p className="text-[10px] text-slate-500 font-medium">PRIVACY LAYER</p>
              <p className="font-semibold text-emerald-400">Zero-Tracking Shield Active</p>
            </div>
          </div>
        </div>
      </section>

      {/* Next-Gen Pillars Quick-Access Bento */}
      <section className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        <button
          onClick={() => setActiveLifeOSTab('radar')}
          className="bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-cyan-500/50 rounded-2xl p-4 text-left transition-all group shadow-md"
        >
          <div className="w-8 h-8 rounded-xl bg-cyan-950/80 border border-cyan-800 text-cyan-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <Sparkles className="w-4 h-4 text-cyan-400" />
          </div>
          <span className="font-bold text-xs text-white block">Life Radar</span>
          <span className="text-[10px] text-slate-400 mt-0.5 block">AI Signal Matcher</span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('future_you')}
          className="bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-indigo-500/50 rounded-2xl p-4 text-left transition-all group shadow-md"
        >
          <div className="w-8 h-8 rounded-xl bg-indigo-950/80 border border-indigo-800 text-indigo-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <TrendingUp className="w-4 h-4 text-indigo-400" />
          </div>
          <span className="font-bold text-xs text-white block">Future You</span>
          <span className="text-[10px] text-slate-400 mt-0.5 block">Trajectory Sandbox</span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('opportunity_exchange')}
          className="bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-4 text-left transition-all group shadow-md"
        >
          <div className="w-8 h-8 rounded-xl bg-emerald-950/80 border border-emerald-800 text-emerald-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <Zap className="w-4 h-4 text-emerald-400" />
          </div>
          <span className="font-bold text-xs text-white block">Exchange</span>
          <span className="text-[10px] text-slate-400 mt-0.5 block">Peer Barter Market</span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('skill_graph')}
          className="bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-purple-500/50 rounded-2xl p-4 text-left transition-all group shadow-md"
        >
          <div className="w-8 h-8 rounded-xl bg-purple-950/80 border border-purple-800 text-purple-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <Layers className="w-4 h-4 text-purple-400" />
          </div>
          <span className="font-bold text-xs text-white block">Skill Graph</span>
          <span className="text-[10px] text-slate-400 mt-0.5 block">Dynamic Competency</span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('goal_communities')}
          className="bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-rose-500/50 rounded-2xl p-4 text-left transition-all group shadow-md"
        >
          <div className="w-8 h-8 rounded-xl bg-rose-950/80 border border-rose-800 text-rose-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <Users className="w-4 h-4 text-rose-400" />
          </div>
          <span className="font-bold text-xs text-white block">Goal Cohorts</span>
          <span className="text-[10px] text-slate-400 mt-0.5 block">Sprint Momentum</span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('moments')}
          className="bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-amber-500/50 rounded-2xl p-4 text-left transition-all group shadow-md"
        >
          <div className="w-8 h-8 rounded-xl bg-amber-950/80 border border-amber-800 text-amber-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <MapPin className="w-4 h-4 text-amber-400" />
          </div>
          <span className="font-bold text-xs text-white block">Moments</span>
          <span className="text-[10px] text-slate-400 mt-0.5 block">Physical Venues</span>
        </button>
      </section>

      {/* 2. MY INTENTIONS: What is Happening In Your Life */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">My Active Intentions</h2>
              <p className="text-xs text-slate-400">
                LIFEOS connects you based on what you are doing, seeking, building, or experiencing.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsLifeIntentModalOpen(true)}
              className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-xl hover:bg-slate-800 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" /> Add Intent
            </button>
            <button
              onClick={() => setActiveLifeOSTab('intents')}
              className="text-xs font-semibold text-slate-400 hover:text-slate-200 flex items-center gap-1 hover:underline"
            >
              View All ({lifeIntents.length}) <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {activeIntents.slice(0, 3).map((intent) => {
            const categoryColors: Record<string, { bg: string; text: string; border: string }> = {
              building: { bg: 'bg-indigo-950/80', text: 'text-indigo-400', border: 'border-indigo-800/60' },
              planning: { bg: 'bg-emerald-950/80', text: 'text-emerald-400', border: 'border-emerald-800/60' },
              looking_for: { bg: 'bg-cyan-950/80', text: 'text-cyan-400', border: 'border-cyan-800/60' },
              learning: { bg: 'bg-amber-950/80', text: 'text-amber-400', border: 'border-amber-800/60' },
              offering: { bg: 'bg-purple-950/80', text: 'text-purple-400', border: 'border-purple-800/60' },
              interested_in: { bg: 'bg-rose-950/80', text: 'text-rose-400', border: 'border-rose-800/60' },
            };
            const col = categoryColors[intent.category] || categoryColors.building;

            return (
              <div
                key={intent.id}
                className="bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 sm:p-5 flex flex-col justify-between space-y-4 hover:shadow-xl transition-all group"
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full border ${col.bg} ${col.text} ${col.border}`}
                    >
                      {intent.category.replace('_', ' ')}
                    </span>
                    <span className="text-[11px] text-slate-500 font-medium">
                      Privacy: <strong className="text-slate-400 capitalize">{intent.privacy}</strong>
                    </span>
                  </div>

                  <h3 className="font-bold text-sm sm:text-base text-slate-100 group-hover:text-cyan-300 transition-colors line-clamp-2">
                    {intent.title}
                  </h3>
                  <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                    {intent.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800/80 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-emerald-400 font-semibold flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-emerald-400" />
                      {intent.matchedConnectionsCount} Connections Found
                    </span>
                    <button
                      onClick={() => setActiveLifeOSTab('discovery')}
                      className="text-cyan-400 hover:text-cyan-300 font-semibold text-[11px] flex items-center gap-0.5"
                    >
                      Inspect Matches <ChevronRight className="w-3 h-3" />
                    </button>
                  </div>
                  {intent.aiSuggestedMatchSummary && (
                    <p className="text-[11px] text-slate-400 bg-white/70 p-2 rounded-xl border border-slate-800/80">
                      💡 {intent.aiSuggestedMatchSummary}
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. SOCIAL SYNCHRONICITY: AI Intersections Detected */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
              <HeartHandshake className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white">Social Synchronicity Detected</h2>
                <span className="px-2 py-0.5 rounded-full bg-rose-500/20 border border-rose-500/30 text-rose-300 text-[10px] font-extrabold uppercase animate-pulse">
                  AI Mutual Intersections
                </span>
              </div>
              <p className="text-xs text-slate-400">
                LIFEOS detected complementary intentions. No cold outreach—connect with pre-aligned co-creators.
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveLifeOSTab('synchronicity')}
            className="text-xs font-semibold text-slate-400 hover:text-slate-200 flex items-center gap-1 hover:underline"
          >
            Hub ({synchronicities.length}) <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {synchronicities.slice(0, 2).map((sync) => (
            <div
              key={sync.id}
              className="bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800 hover:border-slate-700 rounded-3xl p-5 sm:p-6 space-y-4 shadow-xl relative overflow-hidden"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2.5 py-0.5 rounded-md bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 font-bold text-[10px] uppercase">
                      {sync.matchType.replace(/_/g, ' ')}
                    </span>
                    <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-emerald-400" />
                      {sync.compatibilityScore}% Compatibility
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-slate-100">{sync.title}</h3>
                </div>
                <span className="text-[10px] text-slate-500 shrink-0">{sync.discoveredAt}</span>
              </div>

              {/* Rationale */}
              <p className="text-xs text-slate-300 bg-white/70 p-3 rounded-2xl border border-slate-800 leading-relaxed">
                🎯 <strong className="text-slate-100">Why this matters right now:</strong> {sync.rationale}
              </p>

              {/* Participants Matrix */}
              <div className="space-y-2">
                <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  Intersecting Minds ({sync.participants.length}):
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {sync.participants.map((p) => (
                    <div
                      key={p.id}
                      className="flex items-center gap-2.5 bg-white/50 p-2 rounded-xl border border-slate-800/80"
                    >
                      <img
                        src={p.avatar}
                        alt={p.name}
                        className="w-8 h-8 rounded-full object-cover border border-slate-700 shrink-0"
                      />
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-200 truncate">{p.name}</p>
                        <p className="text-[10px] text-slate-400 truncate">{p.role}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions: Approve / Chat / Decline */}
              <div className="pt-2 flex flex-wrap items-center justify-between gap-2">
                {sync.status === 'pending' ? (
                  <>
                    <button
                      onClick={() => respondToSynchronicity(sync.id, 'approved')}
                      className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white text-xs font-bold py-2 px-3 rounded-xl shadow-md transition-all active:scale-95 text-center"
                    >
                      ✓ Approve Synchronicity
                    </button>
                    <button
                      onClick={() => respondToSynchronicity(sync.id, 'declined')}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs font-semibold py-2 px-3 rounded-xl transition-colors"
                    >
                      Decline
                    </button>
                  </>
                ) : (
                  <div className="w-full flex items-center justify-between bg-emerald-950/60 border border-emerald-800/60 px-3 py-2 rounded-xl text-xs text-emerald-300">
                    <span className="flex items-center gap-1.5 font-bold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      Synchronicity Approved & Connected!
                    </span>
                    <button
                      onClick={() => showToast('💬 Launching Synchronous Audio & Chat Room...')}
                      className="font-bold underline hover:text-white"
                    >
                      Open Room →
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. TEMPORARY SOCIAL WORLDS: Situational Realms */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Active Social Worlds</h2>
              <p className="text-xs text-slate-400">
                Ephemeral & goal-driven worlds formed around trips, events, projects, and startup sprints.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsCreateWorldModalOpen(true)}
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-xl hover:bg-slate-800 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" /> Create World
            </button>
            <button
              onClick={() => setActiveLifeOSTab('worlds')}
              className="text-xs font-semibold text-slate-400 hover:text-slate-200 flex items-center gap-1 hover:underline"
            >
              Explore Worlds ({socialWorlds.length}) <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {socialWorlds.slice(0, 3).map((world) => (
            <div
              key={world.id}
              className="bg-slate-900/90 border border-slate-800 hover:border-indigo-500/50 rounded-2xl overflow-hidden flex flex-col justify-between group transition-all shadow-xl"
            >
              <div className="relative h-36 overflow-hidden">
                <img
                  src={world.bannerImage}
                  alt={world.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                <div className="absolute top-3 left-3 flex items-center gap-1.5">
                  <span className="px-2 py-0.5 rounded-md bg-white/80 backdrop-blur-md border border-slate-700 text-[10px] font-bold text-indigo-300 uppercase">
                    {world.type} World
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-white/80 backdrop-blur-md border border-slate-700 text-[10px] font-bold text-slate-300 flex items-center gap-1">
                    <Users className="w-3 h-3 text-cyan-400" />
                    {world.participantsCount}
                  </span>
                </div>
                <div className="absolute bottom-2 left-3 right-3">
                  <p className="text-[11px] text-cyan-300 font-semibold flex items-center gap-1">
                    <MapPin className="w-3 h-3" /> {world.locationZone}
                  </p>
                </div>
              </div>

              <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-slate-100 group-hover:text-indigo-300 transition-colors line-clamp-1">
                    {world.title}
                  </h3>
                  <p className="text-xs text-slate-400 line-clamp-2 mt-1 leading-relaxed">
                    {world.description}
                  </p>
                </div>

                <div className="space-y-3 pt-3 border-t border-slate-800">
                  <div className="flex flex-wrap gap-1">
                    {world.tags.slice(0, 3).map((tag, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] font-medium bg-white text-slate-400 border border-slate-800 px-2 py-0.5 rounded-md"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <button
                      onClick={() => {
                        setActiveWorldDetail(world);
                        setActiveLifeOSTab('worlds');
                      }}
                      className="text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1"
                    >
                      Enter Room <ArrowRight className="w-3.5 h-3.5 text-indigo-400" />
                    </button>
                    <button
                      onClick={() => joinSocialWorld(world.id)}
                      className={`text-xs font-bold px-3 py-1.5 rounded-xl transition-all ${
                        world.isJoined
                          ? 'bg-emerald-950/80 border border-emerald-800 text-emerald-400'
                          : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md'
                      }`}
                    >
                      {world.isJoined ? 'Joined ✓' : 'Join World'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. CONNECTIONS THAT COULD MATTER RIGHT NOW & NEARBY RADAR */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Connections Column */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-cyan-400" />
              <h2 className="text-base font-bold text-white">Connections That Could Matter Right Now</h2>
            </div>
            <button
              onClick={() => setActiveLifeOSTab('discovery')}
              className="text-xs text-slate-400 hover:text-slate-200 hover:underline"
            >
              See All →
            </button>
          </div>

          <div className="space-y-3">
            {peopleDiscovery.map((person) => (
              <div
                key={person.id}
                className="bg-slate-900/80 border border-slate-800 hover:border-slate-700 p-4 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all"
              >
                <div className="flex items-start gap-3.5">
                  <img
                    src={person.image}
                    alt={person.title}
                    className="w-12 h-12 rounded-2xl object-cover border border-slate-700 shrink-0"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-sm text-slate-100">{person.title}</h4>
                      <span className="text-[10px] font-bold text-cyan-400 bg-cyan-950 border border-cyan-800 px-1.5 py-0.2 rounded">
                        {person.matchRelevancePercent}% Match
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">{person.subtitle}</p>
                    <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-amber-400" /> {person.intentAlignment}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => {
                      showToast(`🤝 Initiated AI Triple-Handshake introduction with ${person.title}!`);
                    }}
                    className="bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white text-xs font-bold px-3 py-2 rounded-xl transition-all shadow-md active:scale-95"
                  >
                    Introduce Me
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Nearby Pulse / Map Snapshot */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-emerald-400" />
              <h2 className="text-base font-bold text-white">Nearby Radar (Privacy Zone)</h2>
            </div>
            <button
              onClick={() => setActiveLifeOSTab('map')}
              className="text-xs text-slate-400 hover:text-slate-200 hover:underline"
            >
              Full Map →
            </button>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3.5">
            <div className="flex items-center justify-between text-xs text-slate-400 pb-2 border-b border-slate-800">
              <span className="flex items-center gap-1 text-emerald-400 font-semibold">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                Active Local Radius: 5 km
              </span>
              <span className="text-[10px]">Privacy Preserved</span>
            </div>

            <div className="space-y-2.5">
              {mapNodes.slice(0, 3).map((node) => (
                <div
                  key={node.id}
                  onClick={() => setActiveLifeOSTab('map')}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-white/70 hover:bg-white border border-slate-800/80 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center text-cyan-400 shrink-0">
                      <Compass className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-200">{node.title}</p>
                      <p className="text-[10px] text-slate-400">{node.description}</p>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-cyan-400 shrink-0">
                    {node.distanceKm} km
                  </span>
                </div>
              ))}
            </div>

            <button
              onClick={() => setActiveLifeOSTab('map')}
              className="w-full text-center text-xs font-bold text-indigo-400 hover:text-indigo-300 py-1.5 rounded-xl bg-indigo-950/40 border border-indigo-900/60 block"
            >
              Open Interactive Privacy Map →
            </button>
          </div>
        </div>
      </div>

      {/* 6. LIFE MEMORIES: Meaningful Timelines */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Meaningful Life Memories</h2>
              <p className="text-xs text-slate-400">
                Your private personal life memory timeline, automatically synthesized from achieved intents and moments.
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveLifeOSTab('memory')}
            className="text-xs font-semibold text-slate-400 hover:text-slate-200 flex items-center gap-1 hover:underline"
          >
            Timeline ({lifeMemories.length}) <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {recentMemories.map((mem) => (
            <div
              key={mem.id}
              onClick={() => setActiveLifeOSTab('memory')}
              className="bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 rounded-2xl p-4 sm:p-5 flex items-start gap-4 cursor-pointer transition-all group"
            >
              {mem.photos[0] && (
                <img
                  src={mem.photos[0]}
                  alt={mem.title}
                  className="w-20 h-20 rounded-xl object-cover border border-slate-800 shrink-0 group-hover:scale-105 transition-transform"
                />
              )}
              <div className="space-y-1.5 flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">
                    {mem.category.replace('_', ' ')}
                  </span>
                  <span className="text-[10px] text-slate-500">{mem.date}</span>
                </div>
                <h4 className="font-bold text-sm text-slate-100 group-hover:text-amber-300 transition-colors truncate">
                  {mem.title}
                </h4>
                <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                  {mem.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
