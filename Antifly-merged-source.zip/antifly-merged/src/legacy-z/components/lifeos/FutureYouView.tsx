import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Eye,
  Sparkles,
  Zap,
  TrendingUp,
  Clock,
  CheckCircle2,
  Users,
  Compass,
  ArrowRight,
  Send,
  Bot,
  AlertTriangle,
  Flame,
  ShieldCheck,
  Calendar,
} from 'lucide-react';
import { FutureYouScenario } from '../../types';

export const FutureYouView: React.FC = () => {
  const {
    futureYouScenarios,
    runFutureYouSimulation,
    setContextAwareChatPeer,
    setIsContextAwareChatOpen,
    setActiveLifeOSTab,
  } = useApp();

  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(
    futureYouScenarios[0]?.id || ''
  );
  const [customHypothesis, setCustomHypothesis] = useState<string>('');
  const [customHorizon, setCustomHorizon] = useState<'6_months' | '1_year' | '3_years'>('1_year');
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  const selectedScenario =
    futureYouScenarios.find((s) => s.id === selectedScenarioId) || futureYouScenarios[0];

  const handleSimulate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customHypothesis.trim()) return;
    setIsSimulating(true);
    setTimeout(() => {
      runFutureYouSimulation(customHypothesis, customHorizon);
      setCustomHypothesis('');
      setIsSimulating(false);
    }, 900);
  };

  const handlePersonConnect = (person: { name: string; avatar: string; role: string; reason: string }) => {
    setContextAwareChatPeer({
      name: person.name,
      avatar: person.avatar,
      sharedContext: `Future You trajectory match: ${selectedScenario?.scenarioTitle}`,
      matchRationale: person.reason,
    });
    setIsContextAwareChatOpen(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8 animate-fadeIn">
      {/* Hero Simulation Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/70 to-slate-950 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute -right-16 -top-16 w-80 h-80 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />
        <div className="absolute left-1/2 bottom-0 w-64 h-64 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-950/80 border border-indigo-800 text-indigo-400 text-xs font-semibold">
              <Eye className="w-3.5 h-3.5 text-indigo-400" />
              <span>Predictive Growth Sandbox & Foresight Engine</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Future You — Trajectory Simulator
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              Explore what your life, skills, ventures, and human relationships could look like across 6-month, 1-year, and 3-year horizons. Modeled possibilities to help you make deliberate, proactive choices today.
            </p>
          </div>

          <div className="bg-white/80 border border-slate-800 p-4 rounded-2xl text-xs space-y-2 max-w-xs">
            <div className="flex items-center gap-1.5 text-amber-400 font-bold">
              <AlertTriangle className="w-4 h-4" />
              <span>Agency First</span>
            </div>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Trajectories are statistical pattern simulations derived from 12,000+ builder journeys. You are the sole author of your life.
            </p>
          </div>
        </div>
      </div>

      {/* Trajectory Hypothesis Simulator Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <h2 className="text-sm font-bold text-white uppercase tracking-wider">
            Synthesize a Custom Life Hypothesis
          </h2>
        </div>

        <form onSubmit={handleSimulate} className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={customHypothesis}
            onChange={(e) => setCustomHypothesis(e.target.value)}
            placeholder="e.g., 'Dedicate 12 months to building a spatial AI co-founder team in San Francisco'..."
            className="flex-1 bg-white border border-slate-800 focus:border-cyan-500 text-xs sm:text-sm text-slate-100 placeholder-slate-500 rounded-2xl px-4 py-3 outline-none transition-all"
          />

          <div className="flex items-center gap-2">
            <select
              value={customHorizon}
              onChange={(e) => setCustomHorizon(e.target.value as any)}
              className="bg-white border border-slate-800 text-xs text-slate-300 rounded-2xl px-3 py-3 outline-none cursor-pointer focus:border-cyan-500"
            >
              <option value="6_months">6-Month Horizon</option>
              <option value="1_year">1-Year Horizon</option>
              <option value="3_years">3-Year Horizon</option>
            </select>

            <button
              type="submit"
              disabled={isSimulating || !customHypothesis.trim()}
              className="flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 disabled:opacity-50 text-white text-xs font-bold px-5 py-3 rounded-2xl shadow-lg shadow-cyan-500/20 active:scale-95 transition-all whitespace-nowrap"
            >
              {isSimulating ? (
                <>
                  <Bot className="w-4 h-4 animate-spin" />
                  <span>Simulating...</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>Run Simulation</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Scenario Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-none pb-1">
        {futureYouScenarios.map((scenario) => (
          <button
            key={scenario.id}
            onClick={() => setSelectedScenarioId(scenario.id)}
            className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-2 ${
              selectedScenario?.id === scenario.id
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25'
                : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800'
            }`}
          >
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span>
              {scenario.horizon === '6_months'
                ? '6M: '
                : scenario.horizon === '1_year'
                ? '1Y: '
                : '3Y: '}
              {scenario.scenarioTitle.slice(0, 32)}...
            </span>
          </button>
        ))}
      </div>

      {/* Selected Scenario Deep-Dive Card */}
      {selectedScenario && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-8 shadow-2xl">
          {/* Top Trajectory Header */}
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 border-b border-slate-800 pb-6">
            <div className="space-y-2 max-w-3xl">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-full bg-cyan-950/80 border border-cyan-800 text-cyan-400 text-xs font-bold uppercase tracking-wider">
                  {selectedScenario.horizon.replace('_', ' ')}
                </span>
                <span className="px-2.5 py-1 rounded-full bg-indigo-950/80 border border-indigo-800 text-indigo-400 text-xs font-semibold flex items-center gap-1">
                  <TrendingUp className="w-3 h-3 text-indigo-400" />
                  {selectedScenario.likelihoodTrajectory}
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white">
                {selectedScenario.scenarioTitle}
              </h2>
              <p className="text-sm text-slate-300 leading-relaxed">
                {selectedScenario.summary}
              </p>
            </div>

            <div className="bg-white border border-slate-800/80 p-4 rounded-2xl text-xs space-y-1 text-right">
              <span className="text-slate-500 block">Tested Hypothesis</span>
              <p className="text-slate-300 italic font-medium">"{selectedScenario.hypothesis}"</p>
            </div>
          </div>

          {/* 3-Column Bento of Future Growth Elements */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Column 1: Potential Skills & Growth */}
            <div className="bg-white/70 border border-slate-800/80 rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs uppercase tracking-wider">
                <Zap className="w-4 h-4" />
                <span>Skills You Will Master</span>
              </div>
              <div className="space-y-2">
                {selectedScenario.potentialSkills.map((skill, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-200"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span>{skill}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Column 2: Communities & Network */}
            <div className="bg-white/70 border border-slate-800/80 rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2 text-indigo-400 font-bold text-xs uppercase tracking-wider">
                <Users className="w-4 h-4" />
                <span>Ecosystems & Communities</span>
              </div>
              <div className="space-y-2">
                {selectedScenario.possibleCommunities.map((comm, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-200"
                  >
                    <Compass className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                    <span>{comm}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Column 3: High-Impact Opportunities */}
            <div className="bg-white/70 border border-slate-800/80 rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase tracking-wider">
                <Sparkles className="w-4 h-4" />
                <span>Potential Opportunities</span>
              </div>
              <div className="space-y-2">
                {selectedScenario.potentialOpportunities.map((opp, idx) => (
                  <div
                    key={idx}
                    className="flex items-start gap-2 p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-200"
                  >
                    <ArrowRight className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{opp}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Key Catalysts: Suggested People */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Users className="w-4 h-4 text-cyan-400" />
              <span>Suggested People Who Could Catalyze This Horizon</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {selectedScenario.suggestedPeople.map((person, idx) => (
                <div
                  key={idx}
                  className="bg-white/80 border border-slate-800 rounded-2xl p-4 flex items-start justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={person.avatar}
                      alt={person.name}
                      className="w-11 h-11 rounded-xl object-cover border border-slate-700 shadow"
                    />
                    <div>
                      <h4 className="font-bold text-sm text-white">{person.name}</h4>
                      <p className="text-xs text-slate-400">{person.role}</p>
                      <p className="text-[11px] text-indigo-300 mt-1 leading-tight">{person.reason}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => handlePersonConnect(person)}
                    className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold whitespace-nowrap transition-colors"
                  >
                    Connect
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Immediate Actionable Next Steps */}
          <div className="space-y-4 pt-4 border-t border-slate-800">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Calendar className="w-4 h-4 text-amber-400" />
              <span>Immediate Next Steps to Unlock This Horizon</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {selectedScenario.recommendedNextSteps.map((step, idx) => (
                <div
                  key={idx}
                  className="bg-white/80 border border-slate-800 rounded-2xl p-4 space-y-2 flex flex-col justify-between"
                >
                  <div className="space-y-1.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-950/80 text-amber-400 border border-amber-800">
                      {step.timeline}
                    </span>
                    <p className="text-xs font-medium text-slate-200">{step.step}</p>
                  </div>
                  <div className="text-[11px] text-slate-400 pt-2 border-t border-slate-900 flex items-center gap-1">
                    <Zap className="w-3 h-3 text-cyan-400" />
                    <span>Impact: {step.impact}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Legal / Ethics Disclaimer Footer */}
          <div className="text-[11px] text-slate-500 italic pt-2 text-center">
            {selectedScenario.disclaimer}
          </div>
        </div>
      )}
    </div>
  );
};
