import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Share2,
  Download,
  Upload,
  CheckCircle2,
  Lock,
  FileCode,
  ShieldCheck,
  X,
  Copy,
} from 'lucide-react';

export const SocialDataPortabilityModal: React.FC = () => {
  const {
    isDataPortabilityModalOpen,
    setIsDataPortabilityModalOpen,
    lifeIntents,
    skillGraphNodes,
    personalGrowthNodes,
    lifeMemories,
    contributionReputation,
    socialWorlds,
  } = useApp();

  const [copied, setCopied] = useState<boolean>(false);

  if (!isDataPortabilityModalOpen) return null;

  const exportPayload = {
    standard: 'LIFEOS-Sovereign-Social-Graph-v1',
    exportedAt: new Date().toISOString(),
    reputation: contributionReputation,
    intents: lifeIntents,
    skillGraph: skillGraphNodes,
    growthGraph: personalGrowthNodes,
    memoriesCount: lifeMemories.length,
    activeWorlds: socialWorlds.map((w) => ({ title: w.title, category: w.category })),
  };

  const jsonString = JSON.stringify(exportPayload, null, 2);

  const handleDownload = () => {
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lifeos-sovereign-passport-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(jsonString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-100/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl animate-scaleIn">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-950/80 border border-cyan-800 flex items-center justify-center text-cyan-400">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-white">
                Sovereign Social Data Portability
              </h2>
              <p className="text-xs text-slate-400">
                Export and move your reputation, goals, skills, and memory anywhere.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsDataPortabilityModalOpen(false)}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Feature Summary */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div className="bg-white p-3 rounded-2xl border border-slate-800">
            <span className="text-[11px] text-slate-500 block">Intents</span>
            <span className="text-base font-bold text-white mt-0.5 block">{lifeIntents.length}</span>
          </div>
          <div className="bg-white p-3 rounded-2xl border border-slate-800">
            <span className="text-[11px] text-slate-500 block">Skill Nodes</span>
            <span className="text-base font-bold text-purple-400 mt-0.5 block">
              {skillGraphNodes.length}
            </span>
          </div>
          <div className="bg-white p-3 rounded-2xl border border-slate-800">
            <span className="text-[11px] text-slate-500 block">Growth Events</span>
            <span className="text-base font-bold text-teal-400 mt-0.5 block">
              {personalGrowthNodes.length}
            </span>
          </div>
          <div className="bg-white p-3 rounded-2xl border border-slate-800">
            <span className="text-[11px] text-slate-500 block">Karma Tier</span>
            <span className="text-base font-bold text-amber-400 mt-0.5 block">
              {contributionReputation.tier}
            </span>
          </div>
        </div>

        {/* Code Preview */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <FileCode className="w-4 h-4 text-cyan-400" />
              <span>Cryptographic Graph Manifest</span>
            </span>
            <button
              onClick={handleCopy}
              className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copied ? 'Copied to Clipboard' : 'Copy JSON'}</span>
            </button>
          </div>

          <pre className="bg-white border border-slate-800 rounded-2xl p-4 text-[11px] text-slate-300 font-mono max-h-48 overflow-y-auto">
            {jsonString}
          </pre>
        </div>

        {/* Action Buttons */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-400">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Encrypted Self-Sovereign Schema</span>
          </div>

          <button
            onClick={handleDownload}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-800 text-xs font-bold transition-all shadow-md shadow-cyan-500/20"
          >
            <Download className="w-4 h-4" />
            <span>Download Passport (.JSON)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
