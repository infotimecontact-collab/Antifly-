import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  Search,
  Mic,
  Shield,
  Bot,
  PlusCircle,
  Globe,
  Compass,
  Zap,
  Layers,
  MapPin,
  HeartHandshake,
  Network,
  BookOpen,
  MessageSquareQuote,
  ShieldCheck,
  Flame,
  Radio,
  Radar,
  Eye,
  ArrowLeftRight,
  Target,
  Share2,
  Lock,
  Workflow,
  Sparkle,
  Shuffle,
  TrendingUp,
  Map,
  Activity,
  GitBranch,
  Cpu,
  BatteryCharging,
  Calendar,
} from 'lucide-react';
import { SUPPORTED_LANGUAGES } from '../../utils/i18n';
import { LanguageCode } from '../../types';

export const LifeOSHeader: React.FC = () => {
  const {
    activeLifeOSTab,
    setActiveLifeOSTab,
    lifeIntents,
    synchronicities,
    socialWorlds,
    lifeRadarOpportunities,
    opportunityExchangeItems,
    goalCommunities,
    lifeOSMoments,
    setIsLifeIntentModalOpen,
    setIsLifeVoiceModalOpen,
    setIsAITwinDashboardOpen,
    setIsSafetyTrustModalOpen,
    setIsEmergentCommunityModalOpen,
    setIsAIPrivacyCenterOpen,
    setIsDataPortabilityModalOpen,
    setIsIdeaCollisionModalOpen,
    setIsLifeOSAgentModalOpen,
    setIsSerendipityModalOpen,
    language,
    setLanguage,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');

  const activeIntentsCount = lifeIntents.filter((i) => i.status === 'active').length;
  const pendingSynchronicities = synchronicities.filter((s) => s.status === 'pending').length;
  const radarAvailableCount = lifeRadarOpportunities.filter((r) => r.status === 'available' && !r.isIgnored).length;
  const activeMomentsCount = lifeOSMoments.filter((m) => !m.isArchived).length;
  const activeExchangesCount = opportunityExchangeItems.filter((e) => e.status === 'active').length;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setActiveLifeOSTab('radar');
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 text-white backdrop-blur-xl border-b border-slate-800 shadow-2xl transition-all">
      {/* Top Status & Brand Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-2.5">
        {/* Brand & Living Pulse */}
        <div className="flex items-center gap-3">
          <div
            onClick={() => setActiveLifeOSTab('my_world')}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 via-indigo-500 to-fuchsia-500 p-0.5 shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-white rounded-[10px] flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold tracking-wider text-base bg-gradient-to-r from-cyan-400 via-indigo-300 to-fuchsia-400 bg-clip-text text-transparent">
                  LIFEOS
                </span>
                <span className="text-[9px] font-bold uppercase tracking-widest px-1.5 py-0.5 rounded bg-cyan-950/80 text-cyan-400 border border-cyan-800/60">
                  Next-Gen OS
                </span>
              </div>
              <p className="text-[10px] text-slate-400 hidden sm:block">
                AI-Native Social Operating System
              </p>
            </div>
          </div>

          {/* Real-time Context Signal Pill */}
          <div className="hidden lg:flex items-center gap-2 bg-slate-900/90 border border-slate-800 px-2.5 py-1 rounded-full text-xs text-slate-300 shadow-inner">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-slate-400">Context:</span>
            <span className="text-cyan-300 font-medium flex items-center gap-1">
              <MapPin className="w-3 h-3 text-cyan-400" /> SOMA, SF • Spatial Copilot
            </span>
          </div>
        </div>

        {/* Conversational Natural Language Search Bar */}
        <form
          onSubmit={handleSearchSubmit}
          className="flex-1 max-w-sm sm:max-w-md mx-1 relative order-3 sm:order-2 w-full sm:w-auto"
        >
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Ask LIFEOS: 'Find co-founders in SF' or 'Simulate 1-yr future'..."
              className="w-full bg-slate-900/90 hover:bg-slate-900 focus:bg-slate-900 border border-slate-800 focus:border-cyan-500/80 text-xs text-slate-100 placeholder-slate-500 rounded-full pl-9 pr-14 py-1.5 transition-all outline-none shadow-inner"
            />
            <div className="absolute right-1 flex items-center gap-1">
              <button
                type="button"
                onClick={() => setIsLifeVoiceModalOpen(true)}
                title="Voice-First Natural Search"
                className="p-1 rounded-full hover:bg-slate-800 text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                <Mic className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </form>

        {/* Quick Actions, Agents & Privacy Controls */}
        <div className="flex items-center gap-1.5 order-2 sm:order-3">
          {/* Express Intent CTA */}
          <button
            onClick={() => setIsLifeIntentModalOpen(true)}
            className="flex items-center gap-1 bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white text-xs font-semibold px-2.5 py-1.5 rounded-full shadow-md shadow-cyan-500/20 active:scale-95 transition-all"
            title="Express a new Life Intent"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">Express Intent</span>
          </button>

          {/* Personal Social Agent */}
          <button
            onClick={() => setIsLifeOSAgentModalOpen(true)}
            className="flex items-center gap-1 bg-slate-900 hover:bg-slate-800 border border-indigo-500/40 text-indigo-300 text-xs font-medium px-2 py-1.5 rounded-full transition-all"
            title="Personal Social Agent"
          >
            <Bot className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden md:inline">Agent</span>
          </button>

          {/* Serendipity Mode */}
          <button
            onClick={() => setIsSerendipityModalOpen(true)}
            className="p-1.5 rounded-full bg-slate-900 hover:bg-slate-800 border border-purple-500/40 text-purple-300 hover:text-purple-200 transition-all"
            title="Serendipity Mode & Creative Collisions"
          >
            <Shuffle className="w-3.5 h-3.5" />
          </button>

          {/* Idea Collision Engine */}
          <button
            onClick={() => setIsIdeaCollisionModalOpen(true)}
            className="p-1.5 rounded-full bg-slate-900 hover:bg-slate-800 border border-amber-500/40 text-amber-300 hover:text-amber-200 transition-all"
            title="Idea Collision Engine"
          >
            <Sparkle className="w-3.5 h-3.5" />
          </button>

          {/* AI Privacy & Sovereign Data Center */}
          <button
            onClick={() => setIsAIPrivacyCenterOpen(true)}
            className="p-1.5 rounded-full bg-slate-900 hover:bg-slate-800 border border-emerald-500/40 text-emerald-400 hover:text-emerald-300 transition-all"
            title="AI Privacy & Sovereign Control Center"
          >
            <Lock className="w-3.5 h-3.5" />
          </button>

          {/* Social Data Portability */}
          <button
            onClick={() => setIsDataPortabilityModalOpen(true)}
            className="p-1.5 rounded-full bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-cyan-300 transition-all"
            title="Export Sovereign Social Data (JSON / Graph)"
          >
            <Share2 className="w-3.5 h-3.5" />
          </button>

          {/* Global Language Switcher */}
          <div className="relative group">
            <button className="flex items-center gap-1 text-xs text-slate-400 hover:text-slate-200 bg-slate-900 px-2 py-1.5 rounded-full border border-slate-800">
              <Globe className="w-3.5 h-3.5 text-slate-400" />
              <span className="uppercase text-[10px] font-bold">{language}</span>
            </button>
            <div className="absolute right-0 top-full mt-1 hidden group-hover:block bg-slate-900 border border-slate-800 rounded-xl p-1.5 shadow-2xl z-50 min-w-[140px]">
              {SUPPORTED_LANGUAGES.slice(0, 8).map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => setLanguage(lang.code as LanguageCode)}
                  className={`w-full text-left px-2.5 py-1 text-xs rounded-lg flex items-center justify-between ${
                    language === lang.code ? 'bg-cyan-950 text-cyan-400 font-bold' : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span>{lang.name}</span>
                  <span className="text-[10px] text-slate-500">{lang.flag}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tab Bar across all Next-Gen Pillars */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 flex items-center gap-1 overflow-x-auto scrollbar-none py-1 border-t border-slate-900 text-xs">
        <button
          id="btn-lifeos-tab-myworld"
          onClick={() => setActiveLifeOSTab('my_world')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'my_world'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm font-bold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>My World</span>
        </button>

        <button
          id="btn-lifeos-tab-planner"
          onClick={() => setActiveLifeOSTab('planner')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'planner'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm font-bold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Calendar className="w-3.5 h-3.5 text-amber-400" />
          <span>Today &amp; Planner</span>
          <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
            Daily AI
          </span>
        </button>

        <button
          id="btn-lifeos-tab-feed"
          onClick={() => setActiveLifeOSTab('feed')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'feed'
              ? 'bg-violet-500/20 text-violet-300 border border-violet-500/40 shadow-sm font-bold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <MessageSquareQuote className="w-3.5 h-3.5 text-violet-400" />
          <span>Living Feed &amp; Radar</span>
          <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-violet-500/20 text-violet-300 font-bold border border-violet-500/30">
            Social OS
          </span>
        </button>

        <button
          id="btn-lifeos-tab-journal"
          onClick={() => setActiveLifeOSTab('journal')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'journal'
              ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-sm font-bold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5 text-purple-400" />
          <span>Moments &amp; Journal</span>
        </button>

        <button
          id="btn-lifeos-tab-goals"
          onClick={() => setActiveLifeOSTab('goals')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'goals'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm font-bold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Target className="w-3.5 h-3.5 text-emerald-400" />
          <span>Goals &amp; Sprints</span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('bio_energy')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'bio_energy'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Activity className="w-3.5 h-3.5 text-emerald-400" />
          <span>BioEnergy &amp; Flow</span>
          <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
            Peak
          </span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('quantum_decision')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'quantum_decision'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <GitBranch className="w-3.5 h-3.5 text-purple-400" />
          <span>Quantum Decisions</span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('agent_swarm')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'agent_swarm'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Cpu className="w-3.5 h-3.5 text-teal-400" />
          <span>Agent Swarm</span>
          <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-teal-500/20 text-teal-300 font-bold border border-teal-500/30">
            4 Active
          </span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('radar')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'radar'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Radar className="w-3.5 h-3.5 text-cyan-400" />
          <span>Life Radar</span>
          {radarAvailableCount > 0 && (
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-cyan-500/30 text-cyan-300 font-bold">
              {radarAvailableCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveLifeOSTab('future_you')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'future_you'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Eye className="w-3.5 h-3.5 text-indigo-400" />
          <span>Future You</span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('opportunity_exchange')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'opportunity_exchange'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <ArrowLeftRight className="w-3.5 h-3.5 text-emerald-400" />
          <span>Opportunity Exchange</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-800 text-slate-300 font-bold">
            {activeExchangesCount}
          </span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('skill_graph')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'skill_graph'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Workflow className="w-3.5 h-3.5 text-purple-400" />
          <span>Dynamic Skill Graph</span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('goal_communities')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'goal_communities'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Target className="w-3.5 h-3.5 text-rose-400" />
          <span>Goal Communities</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-800 text-slate-300 font-bold">
            {goalCommunities.length}
          </span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('moments')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'moments'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <MapPin className="w-3.5 h-3.5 text-amber-400" />
          <span>Physical Moments</span>
          {activeMomentsCount > 0 && (
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-500/30 text-amber-300 font-bold">
              {activeMomentsCount} live
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveLifeOSTab('growth_graph')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'growth_graph'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5 text-teal-400" />
          <span>Growth Graph</span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('synchronicity')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'synchronicity'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <HeartHandshake className="w-3.5 h-3.5 text-rose-400" />
          <span>AI Synchronicity</span>
          {pendingSynchronicities > 0 && (
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold animate-pulse">
              {pendingSynchronicities}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveLifeOSTab('worlds')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'worlds'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Globe className="w-3.5 h-3.5 text-indigo-400" />
          <span>Social Worlds</span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('intents')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'intents'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Zap className="w-3.5 h-3.5 text-amber-400" />
          <span>Intents</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-800 text-slate-300 font-bold">
            {activeIntentsCount}
          </span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('map')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'map'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Map className="w-3.5 h-3.5 text-emerald-400" />
          <span>Live World Map</span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('memory')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'memory'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5 text-amber-400" />
          <span>AI Memory</span>
        </button>

        <button
          onClick={() => setActiveLifeOSTab('feed')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
            activeLifeOSTab === 'feed'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <MessageSquareQuote className="w-3.5 h-3.5 text-blue-400" />
          <span>Future Feed</span>
        </button>
      </div>
    </header>
  );
};

