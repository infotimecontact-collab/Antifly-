import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Bot,
  Sparkles,
  Zap,
  Shield,
  Calendar,
  Filter,
  CheckCircle2,
  X,
  Sliders,
  Send,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';

export const LifeOSAgentModal: React.FC = () => {
  const { isLifeOSAgentModalOpen, setIsLifeOSAgentModalOpen, aiTwinConfig, updateAITwinConfig } =
    useApp();

  const [scoutingFrequency, setScoutingFrequency] = useState<'hourly' | 'daily' | 'weekly'>('daily');
  const [minMatchThreshold, setMinMatchThreshold] = useState<number>(85);
  const [autoHandshakeEnabled, setAutoHandshakeEnabled] = useState<boolean>(true);

  if (!isLifeOSAgentModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-100/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl animate-scaleIn my-8">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-950/80 border border-indigo-800 flex items-center justify-center text-indigo-400">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold text-white">
                Personal Social Agent & Radar Copilot
              </h2>
              <p className="text-xs text-slate-400">
                Your dedicated AI agent that scouts opportunities, schedules warm handshakes, and shields your attention.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsLifeOSAgentModalOpen(false)}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Autonomous Scouting Rules */}
        <div className="space-y-4">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Autonomous Discovery & Scouting Behaviors
          </h3>

          <div className="space-y-3">
            <div className="bg-white/80 border border-slate-800 rounded-2xl p-4 flex items-center justify-between gap-4">
              <div>
                <span className="font-bold text-xs text-slate-200 block">
                  Autonomous Pre-Screening
                </span>
                <span className="text-[11px] text-slate-400">
                  Allow your agent to negotiate preliminary context with peer agents before notifying you.
                </span>
              </div>
              <input
                type="checkbox"
                checked={autoHandshakeEnabled}
                onChange={(e) => setAutoHandshakeEnabled(e.target.checked)}
                className="w-4 h-4 rounded text-indigo-500 bg-slate-900 border-slate-700 cursor-pointer"
              />
            </div>

            <div className="bg-white/80 border border-slate-800 rounded-2xl p-4 flex items-center justify-between gap-4">
              <div>
                <span className="font-bold text-xs text-slate-200 block">
                  Noise & Spam Firewall
                </span>
                <span className="text-[11px] text-slate-400">
                  Strictly discard unsolicited promotional spam, untargeted pitches, and cold mass-mail.
                </span>
              </div>
              <span className="text-xs font-bold text-emerald-400">Active (100% Shield)</span>
            </div>
          </div>
        </div>

        {/* Scouting Frequency & Match Threshold */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-white/80 border border-slate-800 rounded-2xl p-4 space-y-2">
            <span className="text-xs font-bold text-slate-300 block">Radar Scan Frequency</span>
            <div className="grid grid-cols-3 gap-1.5">
              {(['hourly', 'daily', 'weekly'] as const).map((freq) => (
                <button
                  key={freq}
                  onClick={() => setScoutingFrequency(freq)}
                  className={`py-1.5 rounded-xl text-[11px] font-bold capitalize transition-all border ${
                    scoutingFrequency === freq
                      ? 'bg-indigo-600 border-indigo-500 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {freq}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-white/80 border border-slate-800 rounded-2xl p-4 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300">Minimum Fit Threshold</span>
              <span className="text-indigo-400 font-bold">{minMatchThreshold}%</span>
            </div>
            <input
              type="range"
              min={75}
              max={98}
              value={minMatchThreshold}
              onChange={(e) => setMinMatchThreshold(Number(e.target.value))}
              className="w-full h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-400"
            />
            <span className="text-[10px] text-slate-500 block">
              Only notify you for opportunities above this score.
            </span>
          </div>
        </div>

        {/* Recent Agent Actions Log */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Agent Actions (Past 24 Hours)
          </h3>
          <div className="space-y-1.5 text-xs text-slate-300">
            <div className="bg-white p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Pre-screened 4 inbound synchronicity requests</span>
              </span>
              <span className="text-[10px] text-slate-500">2h ago</span>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Scouted 2 co-founder candidates in SF SOMA area</span>
              </span>
              <span className="text-[10px] text-slate-500">5h ago</span>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" />
                <span>Synchronized calendar availability for upcoming sprint cohort</span>
              </span>
              <span className="text-[10px] text-slate-500">12h ago</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
          <button
            onClick={() => setIsLifeOSAgentModalOpen(false)}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-md shadow-indigo-600/20"
          >
            Save Agent Policies
          </button>
        </div>
      </div>
    </div>
  );
};
