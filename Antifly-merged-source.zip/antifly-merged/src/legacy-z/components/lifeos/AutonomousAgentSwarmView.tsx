import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Bot,
  Cpu,
  Zap,
  Shield,
  CheckCircle2,
  XCircle,
  Clock,
  Play,
  Sliders,
  Sparkles,
  Search,
  Users,
  Compass,
  AlertCircle,
  Eye,
  RefreshCw,
  TrendingUp,
  Terminal,
} from 'lucide-react';
import { AutonomousLifeAgent } from '../../types';

export const AutonomousAgentSwarmView: React.FC = () => {
  const {
    autonomousAgents,
    approveAgentTask,
    rejectAgentTask,
    setAgentAutonomyLevel,
    triggerManualAgentSweep,
  } = useApp();

  const [selectedAgentId, setSelectedAgentId] = useState<string>(autonomousAgents[0]?.id || 'agent_radar_scout');
  const [filterMode, setFilterMode] = useState<'all' | 'pending' | 'executed'>('all');

  const selectedAgent = autonomousAgents.find((a) => a.id === selectedAgentId) || autonomousAgents[0];

  const totalPending = autonomousAgents.reduce((acc, a) => acc + a.pendingApprovalsCount, 0);
  const totalCompletedToday = autonomousAgents.reduce((acc, a) => acc + a.actionsCompletedToday, 0);

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Header & Swarm Command Matrix */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/60 to-slate-950 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <Bot className="w-5 h-5 animate-pulse" />
              </span>
              <span className="text-xs font-black uppercase tracking-widest text-emerald-400">
                Autonomous Life Agent Syndicate
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                4 Active Synthetic Twins
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              AI Agent Swarm &amp; Delegation Engine
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Your personal syndicate of autonomous AI agents executing real-time spatial scouting, peer handshake handoffs, skill-gap analysis, and micro-opportunity brokering 24/7.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => triggerManualAgentSweep(selectedAgentId)}
              className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-extrabold flex items-center gap-2 shadow-xl shadow-emerald-500/20 active:scale-95 transition-all shrink-0 cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Trigger Syndicate Sweep</span>
            </button>
          </div>
        </div>

        {/* Global Swarm Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800/80">
          <div className="bg-white/60 rounded-2xl p-3 border border-slate-800/60">
            <div className="text-[10px] text-slate-400 font-bold uppercase">Pending Approvals</div>
            <div className="text-xl sm:text-2xl font-black text-amber-400 mt-1 flex items-center gap-2">
              <span>{totalPending}</span>
              {totalPending > 0 && <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />}
            </div>
            <div className="text-[10px] text-slate-400 mt-1">Requiring cryptographic sign-off</div>
          </div>

          <div className="bg-white/60 rounded-2xl p-3 border border-slate-800/60">
            <div className="text-[10px] text-slate-400 font-bold uppercase">Executed Today</div>
            <div className="text-xl sm:text-2xl font-black text-emerald-400 mt-1">
              {totalCompletedToday}
            </div>
            <div className="text-[10px] text-slate-400 mt-1">Autonomous actions logged</div>
          </div>

          <div className="bg-white/60 rounded-2xl p-3 border border-slate-800/60">
            <div className="text-[10px] text-slate-400 font-bold uppercase">Avg Task Success</div>
            <div className="text-xl sm:text-2xl font-black text-cyan-400 mt-1">
              98.4%
            </div>
            <div className="text-[10px] text-emerald-400 font-bold mt-1">+2.1% safety score</div>
          </div>

          <div className="bg-white/60 rounded-2xl p-3 border border-slate-800/60">
            <div className="text-[10px] text-slate-400 font-bold uppercase">Privacy Guard</div>
            <div className="text-xl sm:text-2xl font-black text-purple-300 mt-1 flex items-center gap-1.5">
              <Shield className="w-5 h-5 text-purple-400" />
              <span>Zero-Knowledge</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">ZK-Proofs on all handshakes</div>
          </div>
        </div>
      </div>

      {/* Agent Selector Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {autonomousAgents.map((agent) => {
          const isSelected = agent.id === selectedAgentId;

          return (
            <div
              key={agent.id}
              onClick={() => setSelectedAgentId(agent.id)}
              className={`rounded-2xl p-5 border transition-all cursor-pointer flex flex-col justify-between space-y-4 ${
                isSelected
                  ? 'bg-slate-900 border-emerald-500 ring-2 ring-emerald-500/30 shadow-xl shadow-emerald-500/10'
                  : 'bg-white/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-emerald-400">
                    {agent.codeName}
                  </span>
                  <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                    agent.status === 'active_scanning' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 animate-pulse' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {agent.status.replace('_', ' ')}
                  </span>
                </div>

                <h3 className="font-extrabold text-white text-sm">
                  {agent.role}
                </h3>
                <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                  {agent.specialization}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-800/80 space-y-2">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">Autonomy Dial</span>
                  <span className="text-white font-bold capitalize">{agent.autonomyLevel.replace('_', ' ')}</span>
                </div>

                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">Pending Actions</span>
                  <span className={`font-black ${agent.pendingApprovalsCount > 0 ? 'text-amber-400' : 'text-slate-400'}`}>
                    {agent.pendingApprovalsCount}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Agent Control & Task Feed */}
      {selectedAgent && (
        <div className="space-y-6">
          {/* Agent Configuration & Autonomy Level Banner */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono text-emerald-400 font-black">
                    {selectedAgent.codeName}
                  </span>
                  <span className="text-xs text-slate-400">·</span>
                  <span className="text-xs text-slate-300 font-bold">{selectedAgent.role}</span>
                </div>
                <h2 className="text-lg font-black text-white mt-1">
                  Active Mission: {selectedAgent.specialization}
                </h2>
              </div>

              {/* Autonomy Level Picker */}
              <div className="flex items-center gap-2 bg-white p-1.5 rounded-xl border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-slate-400 px-2">Autonomy:</span>
                {(['conservative', 'collaborative', 'high_agency'] as const).map((level) => (
                  <button
                    key={level}
                    type="button"
                    onClick={() => setAgentAutonomyLevel(selectedAgent.id, level)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold capitalize transition-all cursor-pointer ${
                      selectedAgent.autonomyLevel === level
                        ? 'bg-emerald-500 text-slate-800 shadow-md font-black'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {level.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>

            {/* Signals Inspected */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase">Signals Ingested:</span>
              {selectedAgent.signalsInspected.map((signal, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 rounded-lg text-[11px] font-medium bg-white text-cyan-300 border border-slate-800"
                >
                  {signal}
                </span>
              ))}
            </div>
          </div>

          {/* Task Feed & Approvals */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold text-slate-200">
                  Autonomous Execution Log ({selectedAgent.recentTasks.length})
                </h3>
              </div>

              {/* Filter Tabs */}
              <div className="flex items-center gap-1.5 bg-white p-1 rounded-xl border border-slate-800">
                <button
                  type="button"
                  onClick={() => setFilterMode('all')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold ${
                    filterMode === 'all' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  All Logs
                </button>
                <button
                  type="button"
                  onClick={() => setFilterMode('pending')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold ${
                    filterMode === 'pending' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Pending Approval
                </button>
                <button
                  type="button"
                  onClick={() => setFilterMode('executed')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold ${
                    filterMode === 'executed' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Executed
                </button>
              </div>
            </div>

            <div className="space-y-3">
              {selectedAgent.recentTasks
                .filter((t) => {
                  if (filterMode === 'pending') return t.status === 'pending_user_approval';
                  if (filterMode === 'executed') return t.status === 'executed';
                  return true;
                })
                .map((task) => (
                  <div
                    key={task.id}
                    className={`rounded-2xl p-5 border transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                      task.status === 'pending_user_approval'
                        ? 'bg-amber-950/20 border-amber-500/40 ring-1 ring-amber-500/20'
                        : 'bg-slate-900/70 border-slate-800'
                    }`}
                  >
                    <div className="space-y-1.5 flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono text-slate-400">{task.timestamp}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                          task.status === 'pending_user_approval'
                            ? 'bg-amber-500 text-slate-800 animate-pulse'
                            : task.status === 'executed'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : 'bg-rose-500/20 text-rose-400'
                        }`}>
                          {task.status.replace(/_/g, ' ')}
                        </span>
                        <span className="text-[10px] uppercase font-bold text-slate-500">
                          {task.impactCategory.replace(/_/g, ' ')}
                        </span>
                      </div>

                      <h4 className="font-extrabold text-white text-sm">{task.actionTitle}</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">{task.description}</p>

                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                        <span className="text-[10px] text-slate-400">Context used:</span>
                        {task.contextSignalsUsed.map((sig, idx) => (
                          <span key={idx} className="text-[10px] text-cyan-400 bg-white px-2 py-0.5 rounded border border-slate-800">
                            {sig}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Action Buttons for Pending Tasks */}
                    {task.status === 'pending_user_approval' ? (
                      <div className="flex items-center gap-2 shrink-0 pt-2 md:pt-0">
                        <button
                          type="button"
                          onClick={() => approveAgentTask(selectedAgent.id, task.id)}
                          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 cursor-pointer active:scale-95 transition-all"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Approve &amp; Dispatch</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => rejectAgentTask(selectedAgent.id, task.id)}
                          className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Reject</span>
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-bold shrink-0">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Verified on Ledger</span>
                      </div>
                    )}
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
