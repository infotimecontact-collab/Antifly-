import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Zap,
  Plus,
  Sparkles,
  CheckCircle2,
  Trash2,
  Lock,
  Globe,
  Users,
  MapPin,
  Clock,
  Search,
  Filter,
  ArrowRight,
  Shield,
  Bot,
} from 'lucide-react';
import { LifeIntent, LifeIntentCategory, LifePrivacyScope } from '../../types';

export const IntentManager: React.FC = () => {
  const {
    lifeIntents,
    addLifeIntent,
    toggleIntentStatus,
    deleteLifeIntent,
    setIsLifeIntentModalOpen,
    setActiveLifeOSTab,
  } = useApp();

  const [selectedFilter, setSelectedFilter] = useState<'all' | 'active' | 'fulfilled'>('active');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const categories: { id: LifeIntentCategory | 'all'; label: string; emoji: string }[] = [
    { id: 'all', label: 'All Intents', emoji: '✨' },
    { id: 'doing', label: 'Doing', emoji: '⚡' },
    { id: 'feeling', label: 'Feeling', emoji: '🌊' },
    { id: 'looking_for', label: 'Looking For', emoji: '🔍' },
    { id: 'learning', label: 'Learning', emoji: '📚' },
    { id: 'building', label: 'Building', emoji: '🛠️' },
    { id: 'planning', label: 'Planning', emoji: '🗓️' },
    { id: 'experiencing', label: 'Experiencing', emoji: '🌌' },
    { id: 'offering', label: 'Offering', emoji: '🎁' },
    { id: 'needing', label: 'Needing', emoji: '🤝' },
    { id: 'interested_in', label: 'Interested In', emoji: '💡' },
  ];

  const filteredIntents = lifeIntents.filter((intent) => {
    if (selectedFilter === 'active' && intent.status !== 'active') return false;
    if (selectedFilter === 'fulfilled' && intent.status !== 'fulfilled') return false;
    if (selectedCategory !== 'all' && intent.category !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        intent.title.toLowerCase().includes(q) ||
        intent.description.toLowerCase().includes(q) ||
        intent.keywords.some((k) => k.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const getPrivacyIcon = (privacy: LifePrivacyScope) => {
    switch (privacy) {
      case 'private':
        return <Lock className="w-3.5 h-3.5 text-rose-400" />;
      case 'friends':
        return <Users className="w-3.5 h-3.5 text-amber-400" />;
      case 'community':
        return <Users className="w-3.5 h-3.5 text-indigo-400" />;
      case 'nearby':
        return <MapPin className="w-3.5 h-3.5 text-emerald-400" />;
      case 'public':
        return <Globe className="w-3.5 h-3.5 text-cyan-400" />;
    }
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/50 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-2xl">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold">
            <Zap className="w-3.5 h-3.5" />
            <span>Intent Engine • Replace Feeds with Real-Life Desires</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            What is Happening in Your Life?
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
            Express what you are building, learning, planning, feeling, or needing. LIFEOS will continuously cross-match with people, knowledge, places, and opportunities in real time.
          </p>
        </div>

        <button
          onClick={() => setIsLifeIntentModalOpen(true)}
          className="flex items-center gap-2 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 hover:opacity-90 text-white font-bold text-sm px-5 py-3 rounded-2xl shadow-xl shadow-amber-500/20 active:scale-95 transition-all shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Express New Life Intent</span>
        </button>
      </div>

      {/* Category Pills Strip */}
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-none py-1">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              selectedCategory === cat.id
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'bg-slate-900/80 text-slate-400 border border-slate-800 hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            <span>{cat.emoji}</span>
            <span>{cat.label}</span>
          </button>
        ))}
      </div>

      {/* Filter and Search Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/70 border border-slate-800 p-3 rounded-2xl">
        {/* Status Toggle */}
        <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setSelectedFilter('active')}
            className={`px-3 py-1 rounded-lg font-bold transition-all ${
              selectedFilter === 'active'
                ? 'bg-cyan-500 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Active ({lifeIntents.filter((i) => i.status === 'active').length})
          </button>
          <button
            onClick={() => setSelectedFilter('fulfilled')}
            className={`px-3 py-1 rounded-lg font-bold transition-all ${
              selectedFilter === 'fulfilled'
                ? 'bg-emerald-500 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Fulfilled ({lifeIntents.filter((i) => i.status === 'fulfilled').length})
          </button>
          <button
            onClick={() => setSelectedFilter('all')}
            className={`px-3 py-1 rounded-lg font-bold transition-all ${
              selectedFilter === 'all'
                ? 'bg-slate-800 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            All ({lifeIntents.length})
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative flex-1 max-w-xs">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search keywords, topics..."
            className="w-full bg-white border border-slate-800 focus:border-amber-500/80 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 outline-none"
          />
        </div>
      </div>

      {/* Intents Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredIntents.map((intent) => {
          const isFulfilled = intent.status === 'fulfilled';
          return (
            <div
              key={intent.id}
              className={`bg-slate-900/90 border ${
                isFulfilled ? 'border-emerald-800/40 bg-emerald-950/10 opacity-80' : 'border-slate-800 hover:border-slate-700'
              } rounded-3xl p-5 flex flex-col justify-between space-y-4 shadow-xl transition-all group`}
            >
              <div className="space-y-3">
                {/* Category & Privacy Header */}
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-extrabold uppercase tracking-wider px-2.5 py-0.5 rounded-lg bg-white border border-slate-800 text-amber-400">
                    {intent.category.replace('_', ' ')}
                  </span>
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-400 bg-white px-2 py-0.5 rounded-md border border-slate-800">
                    {getPrivacyIcon(intent.privacy)}
                    <span className="capitalize">{intent.privacy}</span>
                  </div>
                </div>

                <h3 className={`font-bold text-base ${isFulfilled ? 'line-through text-slate-400' : 'text-slate-100 group-hover:text-amber-300'} transition-colors`}>
                  {intent.title}
                </h3>

                <p className="text-xs text-slate-400 leading-relaxed">
                  {intent.description}
                </p>

                {/* Keywords */}
                <div className="flex flex-wrap gap-1">
                  {intent.keywords.map((kw, i) => (
                    <span
                      key={i}
                      className="text-[10px] bg-white text-slate-400 border border-slate-800/80 px-2 py-0.5 rounded-md"
                    >
                      #{kw}
                    </span>
                  ))}
                </div>
              </div>

              {/* Bottom Meta & Actions */}
              <div className="space-y-3 pt-3 border-t border-slate-800">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> {intent.matchedConnectionsCount} matches active
                  </span>
                  <span className="text-[10px] text-slate-500 uppercase font-semibold">
                    {intent.urgency.replace('_', ' ')}
                  </span>
                </div>

                {intent.aiSuggestedMatchSummary && (
                  <div className="text-[11px] text-slate-300 bg-white/80 p-2.5 rounded-xl border border-slate-800 leading-normal">
                    💡 {intent.aiSuggestedMatchSummary}
                  </div>
                )}

                <div className="flex items-center justify-between gap-2 pt-1">
                  <button
                    onClick={() => toggleIntentStatus(intent.id)}
                    className={`flex items-center gap-1 text-xs font-semibold px-3 py-1.5 rounded-xl transition-all ${
                      isFulfilled
                        ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                        : 'bg-emerald-950 border border-emerald-800 text-emerald-300 hover:bg-emerald-900'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{isFulfilled ? 'Reactivate' : 'Mark Fulfilled'}</span>
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setActiveLifeOSTab('discovery')}
                      className="text-xs font-bold text-cyan-400 hover:text-cyan-300 px-2.5 py-1.5 rounded-xl bg-cyan-950/40 border border-cyan-900/60 transition-colors"
                    >
                      Matches →
                    </button>
                    <button
                      onClick={() => deleteLifeIntent(intent.id)}
                      className="p-1.5 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-rose-950/40 transition-colors"
                      title="Delete Intent"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
