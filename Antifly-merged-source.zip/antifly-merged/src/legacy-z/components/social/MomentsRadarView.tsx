import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Radio,
  Clock,
  MapPin,
  Users,
  Plus,
  Flame,
  Sparkles,
  Compass,
  ArrowUpRight,
  ShieldCheck,
  Check,
} from 'lucide-react';
import { NextGenMomentItem } from '../../types';

export const MomentsRadarView: React.FC = () => {
  const {
    temporaryMoments,
    livingUserProfile,
    openCreateSocialModal,
    showToast,
  } = useApp();

  const [selectedFilter, setSelectedFilter] = useState<'all' | 'nearby' | 'urgent' | 'collab'>('all');
  const [joinedMomentIds, setJoinedMomentIds] = useState<Record<string, boolean>>({});

  const toggleJoinMoment = (momentId: string, headline: string) => {
    setJoinedMomentIds((prev) => {
      const isJoined = !prev[momentId];
      showToast(isJoined ? `📍 Joined live moment: "${headline}"!` : `Left moment: "${headline}"`);
      return { ...prev, [momentId]: isJoined };
    });
  };

  const filteredMoments = temporaryMoments.filter((m) => {
    if (selectedFilter === 'nearby') return m.isNearby;
    if (selectedFilter === 'urgent') return m.remainingMinutes <= 60;
    if (selectedFilter === 'collab') return m.tags.includes('Collaboration') || m.purpose.includes('project');
    return true;
  });

  return (
    <div id="moments-radar-view" className="space-y-6">
      {/* Radar Pulse Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-5 sm:p-6 shadow-md relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="flex h-3 w-3 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500" />
              </span>
              <span className="text-xs font-mono uppercase tracking-widest text-indigo-300 font-bold">
                Live Temporary Moments Radar
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight">
              Ephemeral Opportunities & Happenings
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl mt-1">
              Real-time micro-events, local studio jams, flash gear deals, and spontaneous co-working sessions that vanish after their countdown expires.
            </p>
          </div>

          <button
            onClick={() => openCreateSocialModal('moment')}
            className="bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-800 font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-xs flex items-center gap-1.5 shrink-0 cursor-pointer transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Drop a Moment</span>
          </button>
        </div>

        {/* Filter Chips */}
        <div className="flex flex-wrap items-center gap-2 mt-4 pt-4 border-t border-slate-800">
          {[
            { id: 'all', label: 'All Live Moments' },
            { id: 'nearby', label: 'Within 5km (Local Radar)' },
            { id: 'urgent', label: 'Ending Soon (<1 hr)' },
            { id: 'collab', label: 'Creative & Projects' },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setSelectedFilter(f.id as any)}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                selectedFilter === f.id
                  ? 'bg-white text-slate-800 shadow-xs'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Moments Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredMoments.map((moment) => {
          const isJoined = joinedMomentIds[moment.id];
          const isEndingSoon = moment.remainingMinutes <= 30;

          return (
            <div
              key={moment.id}
              className="bg-white rounded-2xl border border-slate-200/90 shadow-xs hover:shadow-md transition-all p-5 flex flex-col justify-between"
            >
              <div>
                {/* Header info */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2.5">
                    <img
                      src={moment.author.avatar}
                      alt={moment.author.name}
                      className="w-9 h-9 rounded-xl object-cover border border-slate-200"
                    />
                    <div>
                      <h4 className="font-bold text-slate-900 text-xs sm:text-sm">
                        {moment.author.name}
                      </h4>
                      <span className="text-[11px] text-slate-500 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        {moment.locationName} ({moment.distanceKm} km away)
                      </span>
                    </div>
                  </div>

                  {/* Countdown Pill */}
                  <div
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold font-mono ${
                      isEndingSoon
                        ? 'bg-rose-50 text-rose-700 border border-rose-200 animate-pulse'
                        : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                    }`}
                  >
                    <Clock className="w-3 h-3" />
                    <span>{moment.expiresAt}</span>
                  </div>
                </div>

                {/* Content */}
                <h3 className="font-black text-slate-900 text-base mb-1.5">
                  {moment.headline}
                </h3>
                <p className="text-slate-600 text-xs sm:text-sm leading-relaxed mb-3">
                  {moment.content}
                </p>

                {/* Media if present */}
                {moment.mediaUrl && (
                  <img
                    src={moment.mediaUrl}
                    alt={moment.headline}
                    className="w-full h-40 object-cover rounded-xl mb-3 border border-slate-100"
                  />
                )}

                {/* Tags & Intent match badge */}
                <div className="flex flex-wrap items-center gap-1.5 mb-4">
                  {moment.tags.map((tag, i) => (
                    <span
                      key={i}
                      className="text-[10px] font-semibold bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md"
                    >
                      #{tag}
                    </span>
                  ))}
                  {moment.intentMatches.map((im, i) => (
                    <span
                      key={i}
                      className="text-[10px] font-bold bg-amber-50 text-amber-800 px-2 py-0.5 rounded-md border border-amber-200 flex items-center gap-0.5"
                    >
                      <Sparkles className="w-2.5 h-2.5 text-amber-600" />
                      {im}
                    </span>
                  ))}
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
                <div className="flex items-center gap-1.5 text-xs text-slate-600 font-semibold">
                  <Users className="w-4 h-4 text-slate-500" />
                  <span>
                    {(moment.participantsCount || 1) + (isJoined ? 1 : 0)} Attending
                  </span>
                </div>

                <button
                  onClick={() => toggleJoinMoment(moment.id, moment.headline)}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    isJoined
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-slate-900 hover:bg-slate-800 text-white'
                  }`}
                >
                  {isJoined ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                  <span>{isJoined ? "I'm In (Joined)" : "Join Moment"}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
