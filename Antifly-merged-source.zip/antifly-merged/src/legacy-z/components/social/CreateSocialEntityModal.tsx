import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Plus,
  Image,
  GitFork,
  EyeOff,
  ShoppingBag,
  Clock,
  Radio,
  Users,
  Target,
  Sparkles,
} from 'lucide-react';
import { UserIntentType } from '../../types';

export const CreateSocialEntityModal: React.FC = () => {
  const {
    isCreateSocialEntityModalOpen,
    setIsCreateSocialEntityModalOpen,
    createSocialEntityType,
    setCreateSocialEntityType,
    addSocialPost,
    addTemporaryMoment,
    livingUserProfile,
    showToast,
  } = useApp();

  // Form states
  const [postContent, setPostContent] = useState('');
  const [postMediaUrl, setPostMediaUrl] = useState('');
  const [isCollaborative, setIsCollaborative] = useState(false);
  const [isAnonymous, setIsAnonymous] = useState(livingUserProfile.activePersona === 'anonymous');
  const [intentTag, setIntentTag] = useState<UserIntentType>(livingUserProfile.currentIntent);

  // Moment states
  const [momentHeadline, setMomentHeadline] = useState('');
  const [momentContent, setMomentContent] = useState('');
  const [momentLifetime, setMomentLifetime] = useState<'30m' | '2h' | '12h' | '24h'>('2h');
  const [momentLocation, setMomentLocation] = useState(`${livingUserProfile.location.neighborhood}, ${livingUserProfile.location.city}`);

  // Product states
  const [prodTitle, setProdTitle] = useState('');
  const [prodPrice, setProdPrice] = useState(1499);
  const [prodImage, setProdImage] = useState('https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=600&auto=format&fit=crop&q=80');

  if (!isCreateSocialEntityModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (createSocialEntityType === 'post') {
      if (!postContent.trim()) return;
      addSocialPost({
        content: postContent.trim(),
        mediaUrl: postMediaUrl.trim() || undefined,
        isCollaborative,
        isAnonymous,
        anonymousAlias: isAnonymous ? 'Ghost Creator #812' : undefined,
        intentTag,
        provenance: 'human_created',
      });
    } else if (createSocialEntityType === 'moment') {
      if (!momentHeadline.trim()) return;
      const mins = momentLifetime === '30m' ? 30 : momentLifetime === '2h' ? 120 : momentLifetime === '12h' ? 720 : 1440;
      addTemporaryMoment({
        headline: momentHeadline.trim(),
        content: momentContent.trim(),
        lifetime: momentLifetime,
        remainingMinutes: mins,
        expiresAt: `In ${momentLifetime}`,
        locationName: momentLocation,
      });
    } else if (createSocialEntityType === 'product') {
      if (!prodTitle.trim()) return;
      addSocialPost({
        content: `🛍️ New verified artisan creation available: ${prodTitle}`,
        mediaUrl: prodImage,
        provenance: 'verified_business',
        intentTag: 'sell',
        commerceProduct: {
          id: `prod_${Date.now()}`,
          title: prodTitle,
          price: Number(prodPrice),
          currency: 'INR',
          image: prodImage,
          category: 'Artisan Goods',
          sellerId: livingUserProfile.id,
          sellerName: livingUserProfile.name,
          inStock: true,
          rating: 5.0,
          deliveryEstimate: 'Fast Local 2-3 Days',
        },
      });
    }

    setIsCreateSocialEntityModalOpen(false);
  };

  return (
    <div
      id="create-social-entity-modal-backdrop"
      className="fixed inset-0 z-50 bg-white/70 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200"
    >
      <div
        id="create-social-entity-modal"
        className="bg-white rounded-3xl border border-slate-200 shadow-2xl w-full max-w-xl flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Plus className="w-5 h-5 text-amber-400" />
            <h3 className="text-lg font-black tracking-tight">Create & Broadcast</h3>
          </div>
          <button
            onClick={() => setIsCreateSocialEntityModalOpen(false)}
            className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Type Switcher */}
        <div className="flex items-center gap-1 p-3 bg-slate-50 border-b border-slate-200">
          {[
            { id: 'post', label: 'Post / Idea', icon: <Plus className="w-3.5 h-3.5" /> },
            { id: 'moment', label: 'Ephemeral Moment', icon: <Clock className="w-3.5 h-3.5" /> },
            { id: 'product', label: 'Artisan Product', icon: <ShoppingBag className="w-3.5 h-3.5" /> },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setCreateSocialEntityType(tab.id as any)}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                createSocialEntityType === tab.id
                  ? 'bg-white text-slate-900 shadow-xs border border-slate-200/80'
                  : 'text-slate-600 hover:bg-slate-200/60'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          {createSocialEntityType === 'post' && (
            <>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">What would you like to share?</label>
                <textarea
                  value={postContent}
                  onChange={(e) => setPostContent(e.target.value)}
                  placeholder="Share a milestone, request design feedback, ask for a barter partner..."
                  rows={3}
                  className="w-full text-xs sm:text-sm p-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-violet-500 resize-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Media URL (Optional)</label>
                <input
                  type="url"
                  value={postMediaUrl}
                  onChange={(e) => setPostMediaUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  <input
                    type="checkbox"
                    checked={isCollaborative}
                    onChange={(e) => setIsCollaborative(e.target.checked)}
                    className="rounded text-violet-600"
                  />
                  <span>Enable Collaborative Branching</span>
                </label>

                <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  <input
                    type="checkbox"
                    checked={isAnonymous}
                    onChange={(e) => setIsAnonymous(e.target.checked)}
                    className="rounded text-slate-900"
                  />
                  <span>Ghost / Anonymous Mode</span>
                </label>
              </div>
            </>
          )}

          {createSocialEntityType === 'moment' && (
            <>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Moment Headline</label>
                <input
                  type="text"
                  value={momentHeadline}
                  onChange={(e) => setMomentHeadline(e.target.value)}
                  placeholder="e.g. Spontaneous Pottery Jam at Indiranagar"
                  className="w-full text-xs sm:text-sm p-2.5 rounded-xl border border-slate-200 bg-slate-50"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Details & Agenda</label>
                <textarea
                  value={momentContent}
                  onChange={(e) => setMomentContent(e.target.value)}
                  placeholder="What's happening? Bring your laptop / sketchbook..."
                  rows={2}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50 resize-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Auto-Expires After</label>
                  <select
                    value={momentLifetime}
                    onChange={(e) => setMomentLifetime(e.target.value as any)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50"
                  >
                    <option value="30m">30 Minutes (Flash)</option>
                    <option value="2h">2 Hours (Standard)</option>
                    <option value="12h">12 Hours (Half-Day)</option>
                    <option value="24h">24 Hours (Full Day)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Neighborhood / Spot</label>
                  <input
                    type="text"
                    value={momentLocation}
                    onChange={(e) => setMomentLocation(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50"
                  />
                </div>
              </div>
            </>
          )}

          {createSocialEntityType === 'product' && (
            <>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Product Title</label>
                <input
                  type="text"
                  value={prodTitle}
                  onChange={(e) => setProdTitle(e.target.value)}
                  placeholder="e.g. Hand-Dyed Indigo Silk Scarf"
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Price (₹)</label>
                  <input
                    type="number"
                    value={prodPrice}
                    onChange={(e) => setProdPrice(Number(e.target.value))}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Image URL</label>
                  <input
                    type="url"
                    value={prodImage}
                    onChange={(e) => setProdImage(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50"
                  />
                </div>
              </div>
            </>
          )}

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsCreateSocialEntityModalOpen(false)}
              className="text-xs text-slate-600 px-4 py-2 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm px-5 py-2.5 rounded-xl cursor-pointer"
            >
              Publish Now
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
