import React, { useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  Bot,
  Brain,
  ShieldCheck,
  Zap,
  Eye,
  EyeOff,
  Briefcase,
  Palette,
  Coffee,
  Compass,
  Plus,
  Clock,
  Award,
  ChevronDown,
  Target,
  Flame,
  ArrowUpRight,
  Camera,
  Radio,
} from 'lucide-react';
import { SocialAccountPersona, UserIntentType } from '../../types';

export const LivingProfileHeader: React.FC = () => {
  const {
    livingUserProfile,
    updateLivingProfile,
    switchActivePersona,
    setUserIntent,
    userAttentionBudget,
    setIsAITwinDashboardOpen,
    openCreateSocialModal,
    timeShiftStories,
    setActiveTimeShiftStory,
    setIsTimeShiftStoryViewerOpen,
    setIsTimeShiftCameraOpen,
    showToast,
  } = useApp();

  // Check if current user has an active Living Profile Story
  const myActiveStory = useMemo(() => {
    return timeShiftStories.find(
      (s) => (s.isPersonalStory || s.authorId === 'living-user-alex' || s.authorHandle === livingUserProfile.handle) && s.status !== 'expired'
    );
  }, [timeShiftStories, livingUserProfile.handle]);

  const handleOpenMyStory = () => {
    if (myActiveStory) {
      setActiveTimeShiftStory(myActiveStory);
      setIsTimeShiftStoryViewerOpen(true);
    } else {
      setIsTimeShiftCameraOpen(true);
    }
  };

  const personas: { id: SocialAccountPersona; label: string; icon: React.ReactNode; color: string }[] = [
    { id: 'professional', label: 'Professional', icon: <Briefcase className="w-3.5 h-3.5" />, color: 'from-blue-600 to-indigo-600' },
    { id: 'creative', label: 'Creative', icon: <Palette className="w-3.5 h-3.5" />, color: 'from-purple-600 to-pink-600' },
    { id: 'casual', label: 'Casual', icon: <Coffee className="w-3.5 h-3.5" />, color: 'from-emerald-600 to-teal-600' },
    { id: 'anonymous', label: 'Ghost Persona', icon: <EyeOff className="w-3.5 h-3.5" />, color: 'from-slate-700 to-slate-900' },
  ];

  const intents: { id: UserIntentType; label: string; emoji: string }[] = [
    { id: 'explore', label: 'Exploring', emoji: '🧭' },
    { id: 'learn', label: 'Learning New Skills', emoji: '📚' },
    { id: 'collaborate', label: 'Looking to Collaborate', emoji: '🤝' },
    { id: 'connect', label: 'Connecting & Networking', emoji: '🌐' },
    { id: 'buy', label: 'Shopping & Buying', emoji: '🛍️' },
    { id: 'sell', label: 'Showcasing & Selling', emoji: '🏷️' },
    { id: 'meet', label: 'Meet IRL Nearby', emoji: '📍' },
    { id: 'discover_nearby', label: 'Discovering Local', emoji: '🏙️' },
  ];

  const currentPersona = personas.find((p) => p.id === livingUserProfile.activePersona) || personas[0];
  const activeIntentObj = intents.find((i) => i.id === livingUserProfile.currentIntent) || intents[0];

  return (
    <div
      id="living-profile-header"
      className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-4 sm:p-6 mb-6 relative overflow-hidden"
    >
      {/* Dynamic Ambient Background Glow based on active persona */}
      <div
        className={`absolute -top-24 -right-24 w-72 h-72 rounded-full opacity-10 blur-3xl pointer-events-none bg-gradient-to-br ${currentPersona.color}`}
      />

      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
        {/* Left: Avatar with Story Ring, Living Name & Personas */}
        <div className="flex items-start sm:items-center gap-4">
          <div
            className="relative shrink-0 cursor-pointer group/avatar"
            onClick={handleOpenMyStory}
            title={myActiveStory ? 'View your active 3D Living Story' : 'Record a new Living Profile Story'}
          >
            {/* Story Active Glowing Ring */}
            <div
              className={`p-1 rounded-2xl transition-all duration-300 ${
                myActiveStory
                  ? 'bg-gradient-to-tr from-amber-400 via-rose-500 to-violet-600 shadow-md shadow-rose-500/30 ring-2 ring-amber-400/50 animate-pulse'
                  : 'bg-transparent ring-2 ring-violet-500/20 hover:ring-violet-500/50'
              }`}
            >
              <img
                src={livingUserProfile.activePersona === 'anonymous' ? 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300&auto=format&fit=crop&q=80' : livingUserProfile.avatar}
                alt={livingUserProfile.name}
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl object-cover border-2 border-white shadow-md group-hover/avatar:scale-105 transition-transform"
              />
            </div>

            {/* Story Indicator Badge on Avatar */}
            {myActiveStory ? (
              <span
                className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-800 p-1 rounded-full text-xs font-black shadow-xs border-2 border-white"
                title="Active Living Story"
              >
                <Sparkles className="w-3.5 h-3.5" />
              </span>
            ) : livingUserProfile.activePersona === 'anonymous' ? (
              <span className="absolute -bottom-1 -right-1 bg-slate-900 text-white p-1 rounded-full text-xs shadow-xs" title="Ghost Persona Active">
                <EyeOff className="w-3.5 h-3.5" />
              </span>
            ) : (
              <span className="absolute -bottom-1 -right-1 bg-emerald-500 text-white p-1 rounded-full text-xs shadow-xs" title="Verified Proof of Experience">
                <ShieldCheck className="w-3.5 h-3.5" />
              </span>
            )}
          </div>

          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                {livingUserProfile.activePersona === 'anonymous' ? 'Ghost Explorer #4092' : livingUserProfile.name}
              </h2>
              <span className="text-xs text-slate-500 font-mono">
                {livingUserProfile.activePersona === 'anonymous' ? '@anon_4092' : livingUserProfile.handle}
              </span>
              <div className="flex items-center gap-1 bg-violet-50 text-violet-700 px-2 py-0.5 rounded-full text-xs font-bold border border-violet-200">
                <Sparkles className="w-3 h-3 text-violet-600" />
                <span>Karma {livingUserProfile.karmaScore}</span>
              </div>
            </div>

            <p className="text-sm text-slate-600 mt-1 max-w-xl line-clamp-2">
              {livingUserProfile.activePersona === 'anonymous'
                ? 'Incognito browsing mode. Identity is obscured until mutual reveal consent is given.'
                : livingUserProfile.dynamicBio}
            </p>

            {/* Badges / Proof of Experience */}
            <div className="flex flex-wrap items-center gap-1.5 mt-2.5">
              {livingUserProfile.proofOfExperienceBadges.map((badge) => (
                <span
                  key={badge.id}
                  className="inline-flex items-center gap-1 text-[11px] font-semibold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md border border-slate-200"
                >
                  <Award className="w-3 h-3 text-amber-500" />
                  {badge.title}
                </span>
              ))}
              <span className="text-xs text-slate-400 font-medium ml-1">
                📍 {livingUserProfile.location.neighborhood}, {livingUserProfile.location.city}
              </span>
            </div>
          </div>
        </div>

        {/* Right: Quick Action Buttons, Living Story Pill & AI Twin Pill */}
        <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
          {/* Living Story Action Button */}
          <button
            id="btn-living-profile-story"
            type="button"
            onClick={handleOpenMyStory}
            className={`flex-1 sm:flex-initial flex items-center justify-center gap-2 font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-xs transition-all cursor-pointer ${
              myActiveStory
                ? 'bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-slate-800 font-black ring-2 ring-amber-400/40 hover:brightness-105'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300'
            }`}
          >
            {myActiveStory ? (
              <>
                <Sparkles className="w-4 h-4 text-slate-800 animate-spin" />
                <span>Profile Story Active (23h)</span>
              </>
            ) : (
              <>
                <Camera className="w-4 h-4 text-violet-600" />
                <span>Add Living Story</span>
              </>
            )}
          </button>

          <button
            id="open-ai-twin-brain-btn"
            onClick={() => setIsAITwinDashboardOpen(true)}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-2 bg-gradient-to-r from-violet-600 to-indigo-600 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-xs hover:shadow-md hover:from-violet-700 hover:to-indigo-700 transition-all cursor-pointer"
          >
            <Brain className="w-4 h-4 text-violet-200 animate-pulse" />
            <span>AI Social Twin Brain</span>
          </button>

          <button
            id="open-create-social-entity-btn"
            onClick={() => openCreateSocialModal('post')}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-2 bg-slate-900 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl hover:bg-slate-800 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>Create</span>
          </button>
        </div>
      </div>

      {/* Persona Switcher & Live Intent Controls Bar */}
      <div className="mt-5 pt-4 border-t border-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        {/* Persona Selectors */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-xs font-bold text-slate-500 mr-1 uppercase tracking-wider">Persona:</span>
          {personas.map((persona) => {
            const isActive = livingUserProfile.activePersona === persona.id;
            return (
              <button
                key={persona.id}
                id={`persona-btn-${persona.id}`}
                onClick={() => switchActivePersona(persona.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200/80'
                }`}
              >
                {persona.icon}
                <span>{persona.label}</span>
              </button>
            );
          })}
        </div>

        {/* Dynamic Intent Selector */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <div className="flex items-center gap-1.5 bg-amber-50 text-amber-900 border border-amber-200/70 px-3 py-1.5 rounded-xl text-xs font-semibold">
            <Target className="w-3.5 h-3.5 text-amber-600" />
            <span>Intent:</span>
            <select
              id="user-intent-selector"
              value={livingUserProfile.currentIntent}
              onChange={(e) => setUserIntent(e.target.value as UserIntentType)}
              className="bg-transparent font-bold text-amber-950 focus:outline-none cursor-pointer"
            >
              {intents.map((intent) => (
                <option key={intent.id} value={intent.id}>
                  {intent.emoji} {intent.label}
                </option>
              ))}
            </select>
          </div>

          {/* Attention Budget Pill */}
          <div
            className="flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 border border-slate-200"
            title="AI Attention Shield: Prevents dopamine traps by prioritizing high-signal matchmaker posts"
          >
            <Clock className="w-3.5 h-3.5 text-indigo-600" />
            <span>Budget: <strong className="text-slate-900">{userAttentionBudget.dailyLimitMinutes - userAttentionBudget.usedMinutesToday}m left</strong></span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            <span className="text-[10px] text-indigo-600 font-bold">Signal {userAttentionBudget.signalToNoiseRatio}x</span>
          </div>
        </div>
      </div>
    </div>
  );
};
