import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  Bot,
  Brain,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Users,
  Target,
  Zap,
  Clock,
  Compass,
  MessageSquare,
  Award,
} from 'lucide-react';
import { AIOpportunityMatch, PersonRecommendationItem } from '../../types';

export const OpportunityRadarView: React.FC = () => {
  const {
    opportunityMatches,
    peopleRecommendations,
    initiateIntroduceMe,
    openDirectChatWithPeer,
    showToast,
  } = useApp();

  const [filterType, setFilterType] = useState<string>('all');

  const filteredMatches = opportunityMatches.filter((match) => {
    if (filterType === 'all') return true;
    return match.matchType === filterType;
  });

  return (
    <div id="opportunity-radar-view" className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-violet-900 via-indigo-900 to-slate-900 text-white rounded-2xl p-5 sm:p-6 shadow-md relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
              <span className="text-xs font-mono uppercase tracking-widest text-indigo-200 font-bold">
                AI Proactive Opportunity Engine
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight">
              Autonomous Value & Skill Matchmaker
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl mt-1">
              Instead of endless scrolling, our AI background agent actively monitors skills, buyer needs, project goals, and local inventories to broker high-value serendipitous introductions.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/15 text-center shrink-0">
            <span className="text-2xl font-black text-amber-300 block">
              {opportunityMatches.length}
            </span>
            <span className="text-[11px] text-indigo-200 font-semibold uppercase tracking-wider">
              High-Signal Matches
            </span>
          </div>
        </div>

        {/* Filter Types */}
        <div className="flex flex-wrap items-center gap-2 mt-5 pt-4 border-t border-indigo-800/80">
          {[
            { id: 'all', label: 'All Opportunities' },
            { id: 'creative_collab', label: '🎨 Creative Collaboration' },
            { id: 'local_commerce', label: '🛍️ Direct Artisan Commerce' },
            { id: 'skill_barter', label: '⚡ Skill Barter' },
            { id: 'mentorship', label: '🧭 Mentorship & Guidance' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id)}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                filterType === tab.id
                  ? 'bg-amber-400 text-slate-800 shadow-xs'
                  : 'bg-indigo-950/60 text-slate-200 hover:bg-indigo-900/80'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Opportunity Match Cards */}
      <div className="space-y-4">
        {filteredMatches.map((match) => (
          <div
            key={match.id}
            className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition-all p-5 overflow-hidden"
          >
            {/* Header: Score and Type */}
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                <span className="bg-violet-100 text-violet-800 text-xs font-black px-2.5 py-1 rounded-full border border-violet-200 flex items-center gap-1">
                  <Zap className="w-3 h-3 text-violet-600" />
                  {match.compatibilityScore}% Compatibility
                </span>
                <span className="text-xs font-semibold text-slate-500 capitalize">
                  {match.matchType.replace(/_/g, ' ')}
                </span>
              </div>

              <span className="text-xs font-mono text-slate-400">
                Found {match.discoveredAt}
              </span>
            </div>

            {/* Match Title & AI Rationale */}
            <h3 className="text-base sm:text-lg font-black text-slate-900 mb-1.5">
              {match.title}
            </h3>

            <div className="bg-slate-50 border border-slate-200/90 rounded-xl p-3.5 mb-4">
              <div className="flex items-start gap-2">
                <Bot className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide mb-0.5">
                    Why AI Brokered This Connection:
                  </h4>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    {match.explanation}
                  </p>
                </div>
              </div>

              {/* Shared Goals / Synergies */}
              <div className="flex flex-wrap items-center gap-1.5 mt-3 pt-2.5 border-t border-slate-200/60">
                <span className="text-[11px] font-bold text-slate-500 mr-1">Synergies:</span>
                {match.mutualGoals.map((goal, i) => (
                  <span
                    key={i}
                    className="text-[10px] font-bold bg-white text-indigo-800 border border-indigo-200 px-2 py-0.5 rounded-md"
                  >
                    ✓ {goal}
                  </span>
                ))}
              </div>
            </div>

            {/* Target Profile Snippet */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-2 border-t border-slate-100">
              <div className="flex items-center gap-3">
                <img
                  src={match.targetProfile.avatar}
                  alt={match.targetProfile.name}
                  className="w-11 h-11 rounded-xl object-cover border border-slate-200 shrink-0"
                />
                <div>
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-bold text-slate-900 text-sm">
                      {match.targetProfile.name}
                    </h4>
                    <span className="text-xs text-slate-500 font-mono">
                      {match.targetProfile.handle}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 line-clamp-1">
                    {match.targetProfile.dynamicBio}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  onClick={() => {
                    const personRec: PersonRecommendationItem = {
                      id: match.targetProfile.id,
                      name: match.targetProfile.name,
                      handle: match.targetProfile.handle,
                      avatar: match.targetProfile.avatar,
                      headline: match.targetProfile.dynamicBio,
                      location: `${match.targetProfile.location.neighborhood}, ${match.targetProfile.location.city}`,
                      compatibilityScore: match.compatibilityScore,
                      commonGoals: match.mutualGoals,
                      proofBadges: match.targetProfile.proofOfExperienceBadges.map((b) => b.title),
                      reason: match.explanation,
                    };
                    initiateIntroduceMe(personRec, match.suggestedIntroMessage);
                  }}
                  className="flex-1 sm:flex-initial bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>AI Introduce Us</span>
                </button>

                <button
                  onClick={() => {
                    openDirectChatWithPeer('customer', match.targetProfile.name, `AI Opportunity Match: ${match.title}`);
                  }}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs px-3 py-2.5 rounded-xl flex items-center justify-center gap-1 cursor-pointer transition-colors"
                  title="Direct Message"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-slate-600" />
                  <span className="hidden md:inline">Message</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Suggested People Network Section */}
      <div className="mt-8 bg-white rounded-2xl border border-slate-200 p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-black text-slate-900 text-base">
              Recommended Creators & Domain Experts
            </h3>
            <p className="text-xs text-slate-500">
              Ranked by verified experience and complementary goals
            </p>
          </div>
          <span className="text-xs font-bold text-indigo-600 flex items-center gap-1">
            <Users className="w-3.5 h-3.5" />
            <span>{peopleRecommendations.length} Curated</span>
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {peopleRecommendations.map((person) => (
            <div
              key={person.id}
              className="p-3.5 rounded-xl border border-slate-200/80 bg-slate-50/60 hover:bg-slate-50 transition-colors flex items-start justify-between gap-3"
            >
              <div className="flex items-start gap-3">
                <img
                  src={person.avatar}
                  alt={person.name}
                  className="w-10 h-10 rounded-xl object-cover border border-slate-200 shrink-0"
                />
                <div>
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-bold text-slate-900 text-xs sm:text-sm">{person.name}</h4>
                    <span className="text-[11px] text-slate-500">{person.handle}</span>
                  </div>
                  <p className="text-xs text-slate-600 line-clamp-1 mt-0.5">{person.headline}</p>
                  <div className="flex flex-wrap items-center gap-1 mt-1.5">
                    {person.proofBadges.map((b, idx) => (
                      <span key={idx} className="text-[10px] font-semibold bg-white border border-slate-200 text-slate-700 px-1.5 py-0.2 rounded">
                        {b}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <button
                onClick={() => initiateIntroduceMe(person)}
                className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-3 py-1.5 rounded-lg shrink-0 flex items-center gap-1 cursor-pointer transition-colors"
              >
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>Intro</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
