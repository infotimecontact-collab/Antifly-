import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  NextGenSocialPost,
  ContextReactionType,
  CollaborativeContribution,
} from '../../types';
import {
  Sparkles,
  Bot,
  ShieldCheck,
  Eye,
  EyeOff,
  ShoppingBag,
  GitFork,
  MessageSquare,
  Share2,
  Check,
  Plus,
  ArrowRight,
  TrendingUp,
  Tag,
  Clock,
  ThumbsUp,
  Layers,
  Sparkle,
} from 'lucide-react';

interface SocialPostCardProps {
  post: NextGenSocialPost;
}

export const SocialPostCard: React.FC<SocialPostCardProps> = ({ post }) => {
  const {
    toggleContextReaction,
    addCollaborativeContribution,
    convertPostToProduct,
    requestIdentityReveal,
    addToCart,
    openDirectChatWithPeer,
    showToast,
  } = useApp();

  const [isContributing, setIsContributing] = useState(false);
  const [contributionText, setContributionText] = useState('');
  const [contributionType, setContributionType] = useState<CollaborativeContribution['type']>('idea');
  const [isConvertingToProduct, setIsConvertingToProduct] = useState(false);
  const [productPrice, setProductPrice] = useState(post.commerceProduct?.price || 1499);
  const [productTitle, setProductTitle] = useState(post.commerceProduct?.title || 'Collaborative Creator Piece');

  const handleAddContribution = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contributionText.trim()) return;

    addCollaborativeContribution(post.id, {
      type: contributionType,
      content: contributionText.trim(),
    });
    setContributionText('');
    setIsContributing(false);
  };

  const handleConvertProduct = (e: React.FormEvent) => {
    e.preventDefault();
    convertPostToProduct(post.id, {
      title: productTitle,
      price: Number(productPrice),
      image: post.mediaUrl,
    });
    setIsConvertingToProduct(false);
  };

  // Reactions definition
  const reactionOptions: { type: ContextReactionType; label: string; emoji: string }[] = [
    { type: 'relate', label: 'Relate', emoji: '🌱' },
    { type: 'understand', label: 'Understand', emoji: '💡' },
    { type: 'agree', label: 'Agree', emoji: '🤝' },
    { type: 'needThis', label: 'Need This', emoji: '🔥' },
    { type: 'helpedMe', label: 'Helped Me', emoji: '⭐' },
    { type: 'discuss', label: 'Discuss', emoji: '💬' },
  ];

  const provenanceBadges = {
    human_created: { label: 'Human Verified', bg: 'bg-emerald-50 text-emerald-700 border-emerald-200', icon: <ShieldCheck className="w-3 h-3 text-emerald-600" /> },
    ai_generated: { label: 'AI Generated', bg: 'bg-purple-50 text-purple-700 border-purple-200', icon: <Bot className="w-3 h-3 text-purple-600" /> },
    ai_augmented: { label: 'AI Augmented', bg: 'bg-indigo-50 text-indigo-700 border-indigo-200', icon: <Sparkles className="w-3 h-3 text-indigo-600" /> },
    verified_business: { label: 'Verified Creator Merchant', bg: 'bg-amber-50 text-amber-800 border-amber-200', icon: <ShoppingBag className="w-3 h-3 text-amber-600" /> },
  };

  const currentProvenance = provenanceBadges[post.provenance] || provenanceBadges.human_created;

  return (
    <article
      id={`social-post-${post.id}`}
      className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition-all p-5 mb-5 overflow-hidden"
    >
      {/* Top Bar: Author, Persona, Provenance Badge, Intent */}
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-3">
          <img
            src={post.isAnonymous && post.identityRevealState !== 'revealed' ? 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300&auto=format&fit=crop&q=80' : post.author.avatar}
            alt={post.author.name}
            className="w-11 h-11 rounded-xl object-cover border border-slate-200 shadow-xs shrink-0"
          />
          <div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <h3 className="font-bold text-slate-900 text-sm">
                {post.isAnonymous && post.identityRevealState !== 'revealed'
                  ? post.anonymousAlias || 'Ghost Creator'
                  : post.author.name}
              </h3>
              {post.author.proofOfExperienceBadges.length > 0 && post.identityRevealState === 'revealed' && (
                <span className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.2 rounded font-semibold">
                  {post.author.proofOfExperienceBadges[0].title}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
              <span>{post.createdAt}</span>
              <span>•</span>
              <span className="capitalize font-medium text-slate-600">
                {post.intentTag.replace(/_/g, ' ')}
              </span>
            </div>
          </div>
        </div>

        {/* Provenance Badge & Ghost Mode Tag */}
        <div className="flex items-center gap-1.5">
          <div className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold border ${currentProvenance.bg}`}>
            {currentProvenance.icon}
            <span>{currentProvenance.label}</span>
          </div>

          {post.isAnonymous && (
            <div className="flex items-center gap-1 bg-slate-900 text-white px-2 py-1 rounded-full text-xs font-bold">
              <EyeOff className="w-3 h-3 text-slate-300" />
              <span>Ghost Post</span>
            </div>
          )}
        </div>
      </div>

      {/* Post Text Content */}
      <p className="text-slate-800 text-sm sm:text-base leading-relaxed mb-3 whitespace-pre-line">
        {post.content}
      </p>

      {/* Media Attachment */}
      {post.mediaUrl && (
        <div className="rounded-xl overflow-hidden mb-4 border border-slate-100 bg-white/5 relative">
          <img
            src={post.mediaUrl}
            alt="Post media"
            className="w-full max-h-96 object-cover hover:scale-[1.01] transition-transform duration-300"
          />
          {post.isCollaborative && (
            <div className="absolute top-3 left-3 bg-slate-900/80 backdrop-blur-md text-white px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md">
              <GitFork className="w-3.5 h-3.5 text-amber-400" />
              <span>Living Collaborative Object</span>
            </div>
          )}
        </div>
      )}

      {/* Attached Social Commerce Product Card */}
      {post.commerceProduct && (
        <div className="mb-4 bg-gradient-to-r from-amber-500/10 via-orange-500/5 to-transparent border border-amber-200/80 rounded-xl p-3 sm:p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img
              src={post.commerceProduct.image}
              alt={post.commerceProduct.title}
              className="w-14 h-14 rounded-lg object-cover border border-amber-200 shadow-xs shrink-0"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <span className="bg-amber-500 text-slate-800 text-[10px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded">
                  Direct Buy
                </span>
                <h4 className="font-bold text-slate-900 text-sm">
                  {post.commerceProduct.title}
                </h4>
              </div>
              <p className="text-xs text-slate-600 mt-0.5 font-medium">
                {post.commerceProduct.deliveryEstimate}
              </p>
              <div className="text-sm font-black text-slate-900 mt-1">
                ₹{post.commerceProduct.price.toLocaleString('en-IN')}
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              addToCart({
                productId: post.commerceProduct!.id,
                title: post.commerceProduct!.title,
                price: post.commerceProduct!.price,
                quantity: 1,
                image: post.commerceProduct!.image,
                category: post.commerceProduct!.category,
                sku: `SKU-${post.id}`,
                brand: post.commerceProduct!.sellerName,
                inStock: true,
              });
              showToast(`🛍️ Added "${post.commerceProduct!.title}" to shopping cart!`);
            }}
            className="w-full sm:w-auto bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-amber-400" />
            <span>Buy Now / Add to Cart</span>
          </button>
        </div>
      )}

      {/* Anonymous Identity Reveal Request Bar */}
      {post.isAnonymous && (
        <div className="mb-4 bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-700 font-medium">
            <EyeOff className="w-4 h-4 text-slate-500 shrink-0" />
            <span>
              {post.identityRevealState === 'revealed'
                ? '✅ Real identities mutually revealed for high-trust collaboration.'
                : '🔒 Author is in Ghost Mode. Request mutual handshake to exchange identities.'}
            </span>
          </div>

          {post.identityRevealState !== 'revealed' && (
            <button
              onClick={() => requestIdentityReveal(post.id)}
              className="bg-slate-900 hover:bg-slate-800 text-white font-bold px-3 py-1.5 rounded-lg shrink-0 cursor-pointer"
            >
              Request Reveal
            </button>
          )}
        </div>
      )}

      {/* Collaborative Branches / Contribution Tree */}
      {post.isCollaborative && (
        <div className="mb-4 bg-slate-50/80 rounded-xl p-3.5 border border-slate-200/80">
          <div className="flex items-center justify-between mb-2.5">
            <div className="flex items-center gap-2">
              <GitFork className="w-4 h-4 text-indigo-600" />
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                Collaborative Tree ({post.collaborativeContributions.length} contributions)
              </span>
            </div>

            <button
              onClick={() => setIsContributing(!isContributing)}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isContributing ? 'Cancel' : 'Add Idea / Remix'}</span>
            </button>
          </div>

          {/* Form to add contribution */}
          {isContributing && (
            <form onSubmit={handleAddContribution} className="mb-3 bg-white p-3 rounded-xl border border-indigo-200 shadow-xs">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-bold text-slate-600">Type:</span>
                {(['idea', 'design', 'code', 'solution'] as const).map((t) => (
                  <button
                    type="button"
                    key={t}
                    onClick={() => setContributionType(t)}
                    className={`text-[11px] font-bold px-2 py-0.5 rounded-md capitalize cursor-pointer ${
                      contributionType === t
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>

              <textarea
                value={contributionText}
                onChange={(e) => setContributionText(e.target.value)}
                placeholder="Write your constructive contribution, remix angle, or solution..."
                rows={2}
                className="w-full text-xs p-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 resize-none mb-2"
                required
              />

              <div className="flex justify-end">
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-3 py-1.5 rounded-lg cursor-pointer flex items-center gap-1"
                >
                  <span>Publish Branch</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </form>
          )}

          {/* Contributions List */}
          <div className="space-y-2">
            {post.collaborativeContributions.map((contrib) => (
              <div
                key={contrib.id}
                className="bg-white p-2.5 rounded-lg border border-slate-200/70 text-xs flex items-start justify-between gap-2"
              >
                <div className="flex items-start gap-2">
                  <img
                    src={contrib.authorAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                    alt={contrib.authorName}
                    className="w-6 h-6 rounded-full object-cover shrink-0 mt-0.5"
                  />
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-slate-900">{contrib.authorName}</span>
                      <span className="text-[10px] bg-slate-100 text-indigo-700 font-bold px-1.5 py-0.2 rounded uppercase">
                        {contrib.type}
                      </span>
                      <span className="text-[10px] text-slate-400">{contrib.createdAt}</span>
                    </div>
                    <p className="text-slate-700 mt-0.5">{contrib.content}</p>
                  </div>
                </div>

                <div className="flex items-center gap-1 text-[11px] font-bold text-slate-600 bg-slate-50 px-2 py-1 rounded border border-slate-100">
                  <ThumbsUp className="w-3 h-3 text-indigo-500" />
                  <span>{contrib.upvotes}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Convert to Product Flow */}
      {isConvertingToProduct && (
        <form onSubmit={handleConvertProduct} className="mb-4 bg-amber-50/70 border border-amber-200 rounded-xl p-3.5">
          <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wide mb-2 flex items-center gap-1.5">
            <ShoppingBag className="w-3.5 h-3.5 text-amber-700" />
            <span>Turn this creation into a buyable product</span>
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-2">
            <input
              type="text"
              value={productTitle}
              onChange={(e) => setProductTitle(e.target.value)}
              placeholder="Product Title"
              className="text-xs p-2 rounded-lg border border-amber-200 bg-white"
              required
            />
            <input
              type="number"
              value={productPrice}
              onChange={(e) => setProductPrice(Number(e.target.value))}
              placeholder="Price (₹)"
              className="text-xs p-2 rounded-lg border border-amber-200 bg-white"
              required
            />
          </div>

          <div className="flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsConvertingToProduct(false)}
              className="text-xs text-slate-600 px-3 py-1 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-amber-500 hover:bg-amber-600 text-slate-800 font-bold text-xs px-3 py-1.5 rounded-lg cursor-pointer"
            >
              Publish Listing
            </button>
          </div>
        </form>
      )}

      {/* Context Reactions Grid (Instead of mindless dopamine likes) */}
      <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
        {/* Context Reactions */}
        <div className="flex flex-wrap items-center gap-1 sm:gap-1.5">
          {reactionOptions.map((opt) => {
            const count = post.contextReactions[opt.type] || 0;
            const isSelected = post.userReaction === opt.type;

            return (
              <button
                key={opt.type}
                id={`reaction-btn-${post.id}-${opt.type}`}
                onClick={() => toggleContextReaction(post.id, opt.type)}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-violet-600 text-white shadow-xs scale-105'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200/80'
                }`}
                title={`${opt.label}: ${count} people`}
              >
                <span>{opt.emoji}</span>
                <span className="hidden sm:inline">{opt.label}</span>
                {count > 0 && <span className="font-bold text-[11px] ml-0.5">{count}</span>}
              </button>
            );
          })}
        </div>

        {/* Secondary Creator Actions */}
        <div className="flex items-center gap-1.5">
          {!post.commerceProduct && (
            <button
              onClick={() => setIsConvertingToProduct(!isConvertingToProduct)}
              className="text-xs font-bold text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 px-2.5 py-1 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
              title="Monetize as direct social product"
            >
              <ShoppingBag className="w-3 h-3 text-amber-600" />
              <span className="hidden md:inline">Turn to Product</span>
            </button>
          )}

          <button
            onClick={() => {
              openDirectChatWithPeer('customer', post.author.name, `Re: ${post.content.slice(0, 30)}...`);
            }}
            className="text-xs font-bold text-slate-700 hover:bg-slate-100 border border-slate-200 px-2.5 py-1 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
            title="Start direct conversation"
          >
            <MessageSquare className="w-3 h-3 text-slate-500" />
            <span className="hidden sm:inline">Connect</span>
          </button>
        </div>
      </div>
    </article>
  );
};
