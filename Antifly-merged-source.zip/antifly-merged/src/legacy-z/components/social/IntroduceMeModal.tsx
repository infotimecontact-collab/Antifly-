import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  Bot,
  ShieldCheck,
  CheckCircle2,
  X,
  Send,
  MessageSquare,
  ArrowRight,
  Target,
  Zap,
} from 'lucide-react';

export const IntroduceMeModal: React.FC = () => {
  const {
    isIntroduceMeModalOpen,
    setIsIntroduceMeModalOpen,
    activeIntroduceMeTarget,
    livingUserProfile,
    openDirectChatWithPeer,
    showToast,
  } = useApp();

  const [customMessage, setCustomMessage] = useState('');
  const [includePortfolio, setIncludePortfolio] = useState(true);
  const [sharePersona, setSharePersona] = useState(livingUserProfile.activePersona);

  if (!isIntroduceMeModalOpen || !activeIntroduceMeTarget) return null;

  const targetName = activeIntroduceMeTarget.name || activeIntroduceMeTarget.profile?.name || 'Fellow Creator';
  const targetAvatar = activeIntroduceMeTarget.avatar || activeIntroduceMeTarget.profile?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100';
  const targetHeadline = activeIntroduceMeTarget.headline || activeIntroduceMeTarget.profile?.dynamicBio || 'Creative & Builder';
  const targetScore = activeIntroduceMeTarget.compatibilityScore || 94;
  const targetBadges = activeIntroduceMeTarget.proofBadges || activeIntroduceMeTarget.profile?.proofOfExperienceBadges?.map(b => b.title) || ['Verified Contributor'];
  const commonGoals = activeIntroduceMeTarget.commonGoals || ['collaborative design'];

  const defaultIntroText =
    customMessage ||
    `Hi ${targetName.split(' ')[0]}! I noticed your work on ${targetHeadline}. I am currently exploring ${livingUserProfile.dynamicBio} and would love to connect around ${commonGoals[0] || 'collaborative projects'}.`;

  const handleSendIntroduction = (e: React.FormEvent) => {
    e.preventDefault();
    setIsIntroduceMeModalOpen(false);
    showToast(`✨ AI Triple-Handshake Intro sent to ${targetName}!`);
    openDirectChatWithPeer('customer', targetName, `AI Intro: ${defaultIntroText}`);
  };

  return (
    <div
      id="introduce-me-modal-backdrop"
      className="fixed inset-0 z-50 bg-white/70 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200"
    >
      <div
        id="introduce-me-modal"
        className="bg-white rounded-3xl border border-slate-200 shadow-2xl w-full max-w-xl flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-violet-900 via-indigo-900 to-slate-900 text-white p-5 sm:p-6 flex items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center shrink-0">
              <Sparkles className="w-5 h-5 text-amber-300 animate-pulse" />
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-black tracking-tight">
                AI Matchmaker Handshake
              </h3>
              <p className="text-xs text-indigo-200 mt-0.5">
                High-trust introductory protocol tailored to mutual goals
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsIntroduceMeModalOpen(false)}
            className="text-slate-300 hover:text-white p-1.5 rounded-lg hover:bg-white/10 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSendIntroduction} className="p-5 sm:p-6 space-y-5">
          {/* Target Profile Box */}
          <div className="flex items-start gap-3.5 bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <img
              src={targetAvatar}
              alt={targetName}
              className="w-12 h-12 rounded-xl object-cover border border-slate-200 shrink-0"
            />
            <div className="flex-1">
              <div className="flex items-center justify-between gap-2">
                <h4 className="font-bold text-slate-900 text-sm">{targetName}</h4>
                <span className="text-xs font-bold text-violet-700 bg-violet-50 border border-violet-200 px-2 py-0.5 rounded-md flex items-center gap-1">
                  <Zap className="w-3 h-3 text-violet-600" />
                  {targetScore}% Match
                </span>
              </div>
              <p className="text-xs text-slate-600 line-clamp-1 mt-0.5">{targetHeadline}</p>
              <div className="flex flex-wrap items-center gap-1 mt-2">
                {targetBadges.map((b, i) => (
                  <span key={i} className="text-[10px] font-semibold bg-white border border-slate-200 text-slate-700 px-1.5 py-0.2 rounded">
                    {b}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* AI Tailored Intro Note */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Bot className="w-3.5 h-3.5 text-indigo-600" />
                <span>AI-Crafted Contextual Icebreaker</span>
              </label>
              <span className="text-[11px] text-slate-400">Editable</span>
            </div>

            <textarea
              value={customMessage || defaultIntroText}
              onChange={(e) => setCustomMessage(e.target.value)}
              rows={4}
              className="w-full text-xs sm:text-sm p-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-violet-500 bg-slate-50 focus:bg-white resize-none"
              required
            />
          </div>

          {/* Options */}
          <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
            <label className="flex items-center gap-2 text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={includePortfolio}
                onChange={(e) => setIncludePortfolio(e.target.checked)}
                className="rounded text-violet-600 focus:ring-violet-500"
              />
              <span>Attach my verified Proof-of-Experience badges and portfolio</span>
            </label>
          </div>

          {/* Buttons */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsIntroduceMeModalOpen(false)}
              className="text-xs text-slate-600 font-semibold px-4 py-2 hover:bg-slate-100 rounded-xl cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              className="bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white font-bold text-xs sm:text-sm px-5 py-2.5 rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send AI Introduction</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
