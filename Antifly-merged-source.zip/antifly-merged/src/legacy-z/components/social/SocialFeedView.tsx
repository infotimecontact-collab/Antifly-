import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SocialPostCard } from './SocialPostCard';
import { LifeOSLivingStoriesBar } from '../lifeos/LifeOSLivingStoriesBar';
import {
  Sparkles,
  Target,
  GitFork,
  BookOpen,
  ShoppingBag,
  MapPin,
  EyeOff,
  Image,
  Send,
  Plus,
  Compass,
  CheckCircle2,
  Users,
  Award,
  Zap,
} from 'lucide-react';
import { SocialFeedMode, UserIntentType } from '../../types';

export const SocialFeedView: React.FC = () => {
  const {
    socialFeedMode,
    setSocialFeedMode,
    socialPosts,
    addSocialPost,
    livingUserProfile,
    temporaryCommunities,
    joinTemporaryCommunity,
    socialMissions,
    completeSocialMission,
    openCreateSocialModal,
    showToast,
  } = useApp();

  const [newPostContent, setNewPostContent] = useState('');
  const [isCollaborativePost, setIsCollaborativePost] = useState(false);
  const [isAnonymousPost, setIsAnonymousPost] = useState(livingUserProfile.activePersona === 'anonymous');
  const [postMediaUrl, setPostMediaUrl] = useState('');
  const [showMediaInput, setShowMediaInput] = useState(false);

  const feedModes: { id: SocialFeedMode; label: string; icon: React.ReactNode }[] = [
    { id: 'personalized', label: 'AI Radar', icon: <Sparkles className="w-3.5 h-3.5" /> },
    { id: 'intent_matched', label: 'Intent Matched', icon: <Target className="w-3.5 h-3.5" /> },
    { id: 'collaborate', label: 'Collaborative Tree', icon: <GitFork className="w-3.5 h-3.5" /> },
    { id: 'learn', label: 'Knowledge & How-To', icon: <BookOpen className="w-3.5 h-3.5" /> },
    { id: 'commerce', label: 'Artisan Commerce', icon: <ShoppingBag className="w-3.5 h-3.5" /> },
    { id: 'nearby', label: 'Local Radar', icon: <MapPin className="w-3.5 h-3.5" /> },
    { id: 'anonymous', label: 'Ghost Space', icon: <EyeOff className="w-3.5 h-3.5" /> },
  ];

  const handleQuickPublish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostContent.trim()) return;

    addSocialPost({
      content: newPostContent.trim(),
      mediaUrl: postMediaUrl.trim() || undefined,
      isCollaborative: isCollaborativePost,
      isAnonymous: isAnonymousPost,
      anonymousAlias: isAnonymousPost ? 'Ghost Creator #912' : undefined,
      provenance: 'human_created',
      intentTag: livingUserProfile.currentIntent,
    });

    setNewPostContent('');
    setPostMediaUrl('');
    setShowMediaInput(false);
    setIsCollaborativePost(false);
  };

  // Filter posts according to feedMode
  const filteredPosts = socialPosts.filter((post) => {
    if (socialFeedMode === 'collaborate') return post.isCollaborative;
    if (socialFeedMode === 'commerce') return Boolean(post.commerceProduct);
    if (socialFeedMode === 'anonymous') return post.isAnonymous;
    if (socialFeedMode === 'learn') return post.intentTag === 'learn' || post.content.toLowerCase().includes('how') || post.content.toLowerCase().includes('guide');
    if (socialFeedMode === 'nearby') return post.intentTag === 'discover_nearby' || post.intentTag === 'meet' || post.content.toLowerCase().includes('bengaluru') || post.content.toLowerCase().includes('local');
    if (socialFeedMode === 'intent_matched') return post.intentTag === livingUserProfile.currentIntent;
    return true; // personalized
  });

  return (
    <div id="social-feed-view" className="space-y-6">
      {/* 3D Living Community & Profile Stories Carousel Bar */}
      <LifeOSLivingStoriesBar variant="social_feed" />

      {/* Ephemeral Communities Carousel Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-violet-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-violet-600" />
            </span>
            <h3 className="font-black text-slate-900 text-xs sm:text-sm uppercase tracking-wide">
              Live Temporary Communities
            </h3>
          </div>
          <span className="text-[11px] text-slate-500">Auto-expires when inactive</span>
        </div>

        <div className="flex items-center gap-3 overflow-x-auto pb-1 no-scrollbar">
          {temporaryCommunities.map((comm) => (
            <div
              key={comm.id}
              className={`shrink-0 w-60 p-3 rounded-xl border transition-all ${
                comm.isJoined
                  ? 'bg-violet-50/60 border-violet-300'
                  : 'bg-slate-50 border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-start justify-between gap-1 mb-1">
                <h4 className="font-bold text-slate-900 text-xs line-clamp-1">{comm.name}</h4>
                <span className="text-[10px] font-mono text-slate-500 shrink-0">{comm.lifetime}</span>
              </div>
              <p className="text-[11px] text-slate-600 line-clamp-1 mb-2">{comm.topic}</p>
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-slate-500 font-semibold flex items-center gap-1">
                  <Users className="w-3 h-3 text-slate-400" />
                  {comm.membersCount} active
                </span>
                <button
                  onClick={() => joinTemporaryCommunity(comm.id)}
                  className={`text-[11px] font-bold px-2 py-0.5 rounded-md cursor-pointer transition-colors ${
                    comm.isJoined
                      ? 'bg-violet-600 text-white'
                      : 'bg-slate-900 text-white hover:bg-slate-800'
                  }`}
                >
                  {comm.isJoined ? 'Joined' : 'Join Room'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Post Publishing Composer */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs">
        <form onSubmit={handleQuickPublish}>
          <div className="flex items-start gap-3 mb-3">
            <img
              src={isAnonymousPost ? 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100' : livingUserProfile.avatar}
              alt={livingUserProfile.name}
              className="w-10 h-10 rounded-xl object-cover border border-slate-200 shrink-0"
            />
            <div className="flex-1">
              <textarea
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
                placeholder={
                  isAnonymousPost
                    ? "Share an unfiltered insight or question in Ghost Mode..."
                    : `What are you building, seeking, or collaborating on, ${livingUserProfile.name.split(' ')[0]}?`
                }
                rows={2}
                className="w-full text-xs sm:text-sm p-3 bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-violet-500 focus:bg-white resize-none transition-all"
                required
              />

              {showMediaInput && (
                <div className="mt-2">
                  <input
                    type="url"
                    value={postMediaUrl}
                    onChange={(e) => setPostMediaUrl(e.target.value)}
                    placeholder="Enter image / video URL (e.g. https://images.unsplash.com/...)"
                    className="w-full text-xs p-2.5 bg-slate-50 rounded-lg border border-slate-200 focus:outline-none focus:ring-1 focus:ring-violet-500"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Composer Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100">
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
              <button
                type="button"
                onClick={() => setShowMediaInput(!showMediaInput)}
                className={`flex items-center gap-1 text-xs font-semibold px-2.5 py-1.5 rounded-lg border cursor-pointer transition-colors ${
                  showMediaInput ? 'bg-indigo-50 text-indigo-700 border-indigo-200' : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <Image className="w-3.5 h-3.5 text-indigo-600" />
                <span>Media</span>
              </button>

              <button
                type="button"
                onClick={() => setIsCollaborativePost(!isCollaborativePost)}
                className={`flex items-center gap-1 text-xs font-semibold px-2.5 py-1.5 rounded-lg border cursor-pointer transition-colors ${
                  isCollaborativePost
                    ? 'bg-amber-50 text-amber-900 border-amber-300 font-bold'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
                title="Allows any member of the network to branch, contribute ideas, and remix this object"
              >
                <GitFork className="w-3.5 h-3.5 text-amber-600" />
                <span>Collaborative Tree</span>
              </button>

              <button
                type="button"
                onClick={() => setIsAnonymousPost(!isAnonymousPost)}
                className={`flex items-center gap-1 text-xs font-semibold px-2.5 py-1.5 rounded-lg border cursor-pointer transition-colors ${
                  isAnonymousPost
                    ? 'bg-slate-900 text-white border-slate-900 font-bold'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
                title="Post in Ghost Mode with anonymous handle and mutual identity reveal"
              >
                <EyeOff className="w-3.5 h-3.5 text-slate-400" />
                <span>Ghost Mode</span>
              </button>
            </div>

            <button
              type="submit"
              className="bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white font-bold text-xs sm:text-sm px-4 py-2 rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Broadcast</span>
            </button>
          </div>
        </form>
      </div>

      {/* Feed Mode Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        {feedModes.map((mode) => (
          <button
            key={mode.id}
            id={`feed-mode-tab-${mode.id}`}
            onClick={() => setSocialFeedMode(mode.id)}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              socialFeedMode === mode.id
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            {mode.icon}
            <span>{mode.label}</span>
          </button>
        ))}
      </div>

      {/* Proof-of-Experience Missions Banner */}
      <div className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-200/80 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-800 flex items-center justify-center font-black shrink-0 shadow-xs">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-black uppercase tracking-wider bg-amber-500 text-slate-800 px-1.5 py-0.2 rounded">
                Active Mission
              </span>
              <h4 className="font-bold text-slate-900 text-xs sm:text-sm">
                {socialMissions[0]?.title || 'Verify 3 Collaborative Designs'}
              </h4>
            </div>
            <p className="text-xs text-slate-600 mt-0.5">
              {socialMissions[0]?.rewardDescription} • Boosts your Proof-of-Experience score to {livingUserProfile.karmaScore + 50}
            </p>
          </div>
        </div>

        <button
          onClick={() => completeSocialMission(socialMissions[0]?.id || 'mission_1')}
          className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-3.5 py-2 rounded-xl shrink-0 cursor-pointer transition-colors"
        >
          Complete Mission
        </button>
      </div>

      {/* Posts List */}
      <div className="space-y-4">
        {filteredPosts.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
            <p className="text-sm font-semibold text-slate-600 mb-2">
              No posts found in this feed mode.
            </p>
            <button
              onClick={() => setSocialFeedMode('personalized')}
              className="text-xs font-bold text-violet-600 hover:underline cursor-pointer"
            >
              Reset to AI Radar feed
            </button>
          </div>
        ) : (
          filteredPosts.map((post) => <SocialPostCard key={post.id} post={post} />)
        )}
      </div>
    </div>
  );
};
