import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Brain,
  Bot,
  ShieldCheck,
  ShieldAlert,
  Trash2,
  Plus,
  Search,
  CheckCircle2,
  XCircle,
  X,
  Sparkles,
  Lock,
  Unlock,
  RefreshCw,
  Sliders,
  Eye,
  Database,
  ArrowRight,
} from 'lucide-react';
import { AISocialTwinMemoryRecord } from '../../types';

export const AITwinDashboardModal: React.FC = () => {
  const {
    isAITwinDashboardOpen,
    setIsAITwinDashboardOpen,
    aiTwinMemories,
    updateTwinMemory,
    deleteTwinMemory,
    resetAllTwinMemory,
    addTwinMemory,
    conversationMemories,
    searchConversationMemories,
    specializedAgents,
    toggleSpecializedAgent,
    livingUserProfile,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'memories' | 'agents' | 'conversations' | 'transparency'>('memories');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [newMemoryCategory, setNewMemoryCategory] = useState<AISocialTwinMemoryRecord['category']>('interest');
  const [newMemoryTitle, setNewMemoryTitle] = useState('');
  const [newMemoryDetails, setNewMemoryDetails] = useState('');
  const [isAddingMemory, setIsAddingMemory] = useState(false);

  if (!isAITwinDashboardOpen) return null;

  const filteredMemories = aiTwinMemories.filter((mem) => {
    const matchesCat = selectedCategory === 'all' || mem.category === selectedCategory;
    const matchesQuery =
      !searchQuery.trim() ||
      mem.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      mem.details.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesQuery;
  });

  const handleCreateMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemoryTitle.trim()) return;

    addTwinMemory({
      category: newMemoryCategory,
      title: newMemoryTitle.trim(),
      details: newMemoryDetails.trim(),
    });

    setNewMemoryTitle('');
    setNewMemoryDetails('');
    setIsAddingMemory(false);
  };

  const filteredConversations = searchConversationMemories(searchQuery);

  return (
    <div
      id="ai-twin-dashboard-modal-backdrop"
      className="fixed inset-0 z-50 bg-white/70 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200"
    >
      <div
        id="ai-twin-dashboard-modal"
        className="bg-white rounded-3xl border border-slate-200 shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden"
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-violet-900 via-indigo-900 to-slate-900 text-white p-5 sm:p-6 flex items-start justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center shrink-0">
              <Brain className="w-6 h-6 text-amber-300 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black tracking-tight">
                  AI Social Twin & Memory Control Center
                </h2>
                <span className="bg-amber-400 text-slate-800 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
                  100% User Owned
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
                Inspect, modify, grant, or revoke every piece of knowledge the AI system retains about you. No dark patterns, no hidden profiling.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAITwinDashboardOpen(false)}
            className="text-slate-300 hover:text-white p-2 rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 pt-4 pb-2 border-b border-slate-200 bg-slate-50/50 overflow-x-auto">
          {[
            { id: 'memories', label: 'Explicit Memories', icon: <Database className="w-4 h-4" />, count: aiTwinMemories.length },
            { id: 'agents', label: 'Autonomous Agents', icon: <Bot className="w-4 h-4" />, count: specializedAgents.length },
            { id: 'conversations', label: 'Chat Semantic Memory', icon: <Sparkles className="w-4 h-4" />, count: conversationMemories.length },
            { id: 'transparency', label: 'Privacy & Data Export', icon: <ShieldCheck className="w-4 h-4" /> },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-200/70 hover:text-slate-900'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    activeTab === tab.id ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          {/* TAB 1: MEMORIES */}
          {activeTab === 'memories' && (
            <div className="space-y-4">
              {/* Controls bar */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search explicit memory facts..."
                    className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-violet-500 focus:bg-white"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="text-xs font-bold p-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-700 cursor-pointer"
                  >
                    <option value="all">All Categories</option>
                    <option value="interest">Interests</option>
                    <option value="skill">Skills</option>
                    <option value="preference">Preferences</option>
                    <option value="intent">Purchase & Search Intent</option>
                    <option value="habit">Habits & Patterns</option>
                  </select>

                  <button
                    onClick={() => setIsAddingMemory(!isAddingMemory)}
                    className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 shrink-0 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 text-amber-400" />
                    <span>Teach Memory</span>
                  </button>
                </div>
              </div>

              {/* Add Memory Inline Form */}
              {isAddingMemory && (
                <form onSubmit={handleCreateMemory} className="bg-violet-50/70 border border-violet-200 rounded-2xl p-4 shadow-xs">
                  <h4 className="text-xs font-bold text-violet-900 uppercase tracking-wide mb-3 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-violet-600" />
                    <span>Explicitly Teach Your AI Twin</span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">Category</label>
                      <select
                        value={newMemoryCategory}
                        onChange={(e) => setNewMemoryCategory(e.target.value as any)}
                        className="w-full text-xs p-2 rounded-lg border border-violet-200 bg-white"
                      >
                        <option value="interest">Interest / Passion</option>
                        <option value="skill">Verified Skill / Domain</option>
                        <option value="preference">Privacy / Buying Preference</option>
                        <option value="intent">Current Goal / Intent</option>
                        <option value="habit">Work Style / Habit</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">Memory Title</label>
                      <input
                        type="text"
                        value={newMemoryTitle}
                        onChange={(e) => setNewMemoryTitle(e.target.value)}
                        placeholder="e.g. Loves Minimalist Ceramic Art"
                        className="w-full text-xs p-2 rounded-lg border border-violet-200 bg-white"
                        required
                      />
                    </div>
                  </div>

                  <div className="mb-3">
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Details & Rationale</label>
                    <textarea
                      value={newMemoryDetails}
                      onChange={(e) => setNewMemoryDetails(e.target.value)}
                      placeholder="Explain the context so the AI twin uses it for high-signal matching..."
                      rows={2}
                      className="w-full text-xs p-2 rounded-lg border border-violet-200 bg-white resize-none"
                    />
                  </div>

                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setIsAddingMemory(false)}
                      className="text-xs text-slate-600 px-3 py-1 font-semibold cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs px-4 py-1.5 rounded-lg cursor-pointer"
                    >
                      Save to Twin Memory
                    </button>
                  </div>
                </form>
              )}

              {/* Memory Items List */}
              <div className="space-y-3">
                {filteredMemories.map((mem) => (
                  <div
                    key={mem.id}
                    className="p-4 rounded-2xl border border-slate-200/90 bg-white hover:border-slate-300 shadow-2xs transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                          mem.permitted ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'
                        }`}
                      >
                        {mem.permitted ? <CheckCircle2 className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
                      </div>

                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-bold text-slate-900 text-sm">{mem.title}</h4>
                          <span className="text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md">
                            {mem.category}
                          </span>
                          <span className="text-[10px] text-slate-400">Learned: {mem.learnedAt}</span>
                        </div>
                        <p className="text-xs text-slate-600 mt-1">{mem.details}</p>
                        <span className="text-[10px] text-slate-400 font-mono mt-1 block">
                          Source: {mem.source}
                        </span>
                      </div>
                    </div>

                    {/* Permissions and Actions */}
                    <div className="flex items-center gap-2 w-full sm:w-auto justify-end pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                      <button
                        onClick={() => updateTwinMemory(mem.id, !mem.permitted)}
                        className={`text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors ${
                          mem.permitted
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
                            : 'bg-slate-100 text-slate-700 border border-slate-200 hover:bg-slate-200'
                        }`}
                      >
                        {mem.permitted ? <Unlock className="w-3.5 h-3.5 text-emerald-600" /> : <Lock className="w-3.5 h-3.5 text-slate-500" />}
                        <span>{mem.permitted ? 'Active' : 'Locked / Revoked'}</span>
                      </button>

                      <button
                        onClick={() => deleteTwinMemory(mem.id)}
                        className="text-rose-600 hover:bg-rose-50 p-2 rounded-lg transition-colors cursor-pointer"
                        title="Permanently erase this memory"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: AUTONOMOUS AGENTS */}
          {activeTab === 'agents' && (
            <div className="space-y-4">
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-xs text-slate-700">
                <p className="font-bold text-slate-900 mb-1">
                  🤖 Autonomous Specialized Sub-Agents
                </p>
                Configure which background AI bots are authorized to work on your behalf when finding deals, collaborators, or vetting inbound introductions.
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {specializedAgents.map((agent) => (
                  <div
                    key={agent.id}
                    className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                      agent.isActive ? 'bg-white border-violet-300 shadow-xs' : 'bg-slate-50 border-slate-200 opacity-70'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-violet-100 text-violet-700 flex items-center justify-center font-bold">
                            <Bot className="w-4 h-4" />
                          </div>
                          <div>
                            <h4 className="font-bold text-slate-900 text-sm">{agent.name}</h4>
                            <span className="text-[10px] text-slate-500">{agent.role}</span>
                          </div>
                        </div>

                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            agent.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                          }`}
                        >
                          {agent.isActive ? 'Active' : 'Disabled'}
                        </span>
                      </div>

                      <p className="text-xs text-slate-600 mb-3">{agent.description}</p>

                      <div className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-[11px] mb-3">
                        <span className="font-bold text-slate-700 block">Capabilities:</span>
                        {agent.capabilities.map((cap, i) => (
                          <div key={i} className="text-slate-600 flex items-center gap-1">
                            <span className="w-1 h-1 rounded-full bg-violet-500" />
                            <span>{cap}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <button
                      onClick={() => toggleSpecializedAgent(agent.id)}
                      className={`w-full py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        agent.isActive
                          ? 'bg-slate-900 text-white hover:bg-slate-800'
                          : 'bg-violet-600 text-white hover:bg-violet-700'
                      }`}
                    >
                      {agent.isActive ? 'Turn Off Agent' : 'Enable Agent'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: CONVERSATION SEMANTIC MEMORY */}
          {activeTab === 'conversations' && (
            <div className="space-y-4">
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-xs text-slate-700">
                <p className="font-bold text-slate-900 mb-1">
                  💬 Semantic Chat Memory Search
                </p>
                Recall past conversational insights, saved advice, or product discussions across all your social chats and AI sessions.
              </div>

              <div className="space-y-3">
                {filteredConversations.map((conv) => (
                  <div key={conv.id} className="p-4 rounded-2xl border border-slate-200 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[11px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md">
                        {conv.sourceContext}
                      </span>
                      <span className="text-[10px] text-slate-400">{conv.timestamp}</span>
                    </div>
                    <h4 className="font-bold text-slate-900 text-xs sm:text-sm mb-1">Q: {conv.query}</h4>
                    <p className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <strong>AI Summary:</strong> {conv.answer}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: TRANSPARENCY & DATA WIPE */}
          {activeTab === 'transparency' && (
            <div className="space-y-6">
              <div className="bg-emerald-50/80 border border-emerald-200 rounded-2xl p-5">
                <div className="flex items-start gap-3">
                  <ShieldCheck className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">
                      Zero-Shadow-Profiling Promise
                    </h3>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      Unlike legacy ad-tech networks that secretly monitor keystrokes and gaze tracking, the Antifly AI Social Network operates solely on data you can view, edit, and revoke in this exact control center.
                    </p>
                  </div>
                </div>
              </div>

              <div className="p-5 rounded-2xl border border-rose-200 bg-rose-50/50">
                <h4 className="font-bold text-rose-900 text-sm mb-1">
                  Nuclear Data Reset & Memory Erasure
                </h4>
                <p className="text-xs text-slate-600 mb-4">
                  Permanently delete all learned AI memory records and reset your Social Twin to its initial clean state.
                </p>

                <button
                  onClick={() => {
                    if (window.confirm('Are you sure you want to completely erase all AI twin memory records?')) {
                      resetAllTwinMemory();
                    }
                  }}
                  className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl cursor-pointer transition-colors flex items-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Wipe All AI Twin Memories</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-500 font-medium">
            Active Persona: <strong className="text-slate-900 capitalize">{livingUserProfile.activePersona}</strong>
          </span>

          <button
            onClick={() => setIsAITwinDashboardOpen(false)}
            className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-5 py-2.5 rounded-xl cursor-pointer"
          >
            Done & Close
          </button>
        </div>
      </div>
    </div>
  );
};
