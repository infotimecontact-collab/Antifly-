import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { LivingProfileHeader } from './LivingProfileHeader';
import { SocialFeedView } from './SocialFeedView';
import { MomentsRadarView } from './MomentsRadarView';
import { OpportunityRadarView } from './OpportunityRadarView';
import { LifeOSLivingStoriesBar } from '../lifeos/LifeOSLivingStoriesBar';
import { AITwinDashboardModal } from './AITwinDashboardModal';
import { IntroduceMeModal } from './IntroduceMeModal';
import { CreateSocialEntityModal } from './CreateSocialEntityModal';
import {
  Sparkles,
  Target,
  Radio,
  Brain,
  Bot,
  Users,
  Compass,
  Plus,
  ShieldCheck,
  Zap,
  Clock,
  Award,
  TrendingUp,
  MessageSquare,
  Flame,
  ArrowRight,
  Camera,
  Play,
} from 'lucide-react';

export const SocialNetworkContainer: React.FC = () => {
  const {
    livingUserProfile,
    userAttentionBudget,
    opportunityMatches,
    temporaryMoments,
    timeShiftStories,
    setActiveTimeShiftStory,
    setIsTimeShiftStoryViewerOpen,
    setIsTimeShiftCameraOpen,
    initiateIntroduceMe,
    setIsAITwinDashboardOpen,
    openCreateSocialModal,
    openDirectChatWithPeer,
  } = useApp();

  const [activeMainTab, setActiveMainTab] = useState<'feed' | 'stories' | 'moments' | 'opportunities'>('feed');

  const activeStoriesCount = timeShiftStories.filter((s) => s.status !== 'expired').length;

  return (
    <div id="social-network-container" className="min-h-screen bg-slate-100/70 pb-16">
      {/* Top Main Max-Width Wrapper */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 pt-4 sm:pt-6">
        {/* Living Profile Top Banner */}
        <LivingProfileHeader />

        {/* 3-Column Modern Social Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Navigation & Living Context (3 cols) */}
          <aside className="lg:col-span-3 space-y-4">
            {/* Main Social Navigation Panel */}
            <div className="bg-white rounded-2xl border border-slate-200 p-3 shadow-xs space-y-1">
              {[
                { id: 'feed', label: 'Living Feed & Radar', icon: <Sparkles className="w-4 h-4 text-violet-600" /> },
                { id: 'stories', label: 'Community Stories', icon: <Play className="w-4 h-4 text-amber-500 fill-amber-500/20" />, badge: `${activeStoriesCount} 3D` },
                { id: 'moments', label: 'Temporary Moments', icon: <Radio className="w-4 h-4 text-emerald-600" />, badge: `${temporaryMoments.length} Live` },
                { id: 'opportunities', label: 'AI Opportunity Radar', icon: <Target className="w-4 h-4 text-indigo-600" />, badge: `${opportunityMatches.length} New` },
              ].map((nav) => (
                <button
                  key={nav.id}
                  id={`social-nav-${nav.id}`}
                  onClick={() => setActiveMainTab(nav.id as any)}
                  className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                    activeMainTab === nav.id
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    {nav.icon}
                    <span>{nav.label}</span>
                  </div>
                  {nav.badge && (
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                        activeMainTab === nav.id ? 'bg-white/20 text-white' : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {nav.badge}
                    </span>
                  )}
                </button>
              ))}

              <div className="pt-2 border-t border-slate-100 space-y-1">
                <button
                  onClick={() => setIsAITwinDashboardOpen(true)}
                  className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-100 cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    <Brain className="w-4 h-4 text-violet-600" />
                    <span>AI Twin Memory Center</span>
                  </div>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded">
                    100% Owned
                  </span>
                </button>

                <button
                  onClick={() => openDirectChatWithPeer('support_ai', 'AI Social Concierge', 'Assistance')}
                  className="w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-100 cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4 text-indigo-600" />
                  <span>AI Social Concierge Chat</span>
                </button>
              </div>
            </div>

            {/* Mindful Attention Budget Card */}
            <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-indigo-600" />
                  <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide">
                    Attention Shield
                  </h4>
                </div>
                <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md">
                  Active Protect
                </span>
              </div>

              <p className="text-xs text-slate-600 mb-3">
                Daily high-signal allocation: <strong>{userAttentionBudget.dailyLimitMinutes} mins</strong>.
              </p>

              {/* Progress bar */}
              <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden mb-2">
                <div
                  className="h-full bg-gradient-to-r from-violet-600 to-indigo-600 rounded-full"
                  style={{
                    width: `${(userAttentionBudget.usedMinutesToday / userAttentionBudget.dailyLimitMinutes) * 100}%`,
                  }}
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium">
                <span>{userAttentionBudget.usedMinutesToday}m used</span>
                <span>{userAttentionBudget.dailyLimitMinutes - userAttentionBudget.usedMinutesToday}m remaining</span>
              </div>
            </div>

            {/* Proof-of-Experience Badges Panel */}
            <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
              <div className="flex items-center gap-1.5 mb-3">
                <Award className="w-4 h-4 text-amber-500" />
                <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide">
                  Verified Proof Badges
                </h4>
              </div>

              <div className="space-y-2">
                {livingUserProfile.proofOfExperienceBadges.map((badge) => (
                  <div
                    key={badge.id}
                    className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900">{badge.title}</span>
                      <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.2 rounded">
                        ✓ {badge.verifiedBy}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-500 mt-0.5 block font-mono">
                      Issued: {badge.issuedDate}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </aside>

          {/* Center Column: Primary Active View (6 cols) */}
          <main className="lg:col-span-6 space-y-6">
            {activeMainTab === 'feed' && <SocialFeedView />}
            {activeMainTab === 'stories' && (
              <div className="space-y-6">
                <LifeOSLivingStoriesBar variant="full" />
                <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-base font-black text-slate-900">
                        Interconnected Story Circles
                      </h3>
                      <p className="text-xs text-slate-500">
                        Stories synchronizing with your goal sprints, temporary communities, and living profile
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsTimeShiftCameraOpen(true)}
                      className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Camera className="w-3.5 h-3.5 text-amber-400" />
                      <span>Post Story</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    {timeShiftStories
                      .filter((s) => s.status !== 'expired')
                      .map((story) => (
                        <div
                          key={story.id}
                          onClick={() => {
                            setActiveTimeShiftStory(story);
                            setIsTimeShiftStoryViewerOpen(true);
                          }}
                          className="p-3.5 rounded-2xl border border-slate-200/80 bg-slate-50/60 hover:bg-white hover:border-violet-300 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
                        >
                          <div>
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <img
                                  src={story.authorAvatar}
                                  alt={story.authorName}
                                  className="w-8 h-8 rounded-full object-cover border border-amber-400"
                                />
                                <div>
                                  <h4 className="text-xs font-bold text-slate-900 group-hover:text-violet-600 transition-colors">
                                    {story.authorName}
                                  </h4>
                                  <span className="text-[10px] text-slate-500 font-mono">
                                    {story.authorHandle}
                                  </span>
                                </div>
                              </div>
                              <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-violet-100 text-violet-800 border border-violet-200">
                                {story.captureMode} 3D
                              </span>
                            </div>

                            <p className="text-xs text-slate-700 font-medium line-clamp-2 mb-2">
                              {story.caption}
                            </p>

                            {story.communityName && (
                              <div className="flex items-center gap-1 text-[10px] font-bold text-amber-700 bg-amber-50 border border-amber-200/80 px-2 py-0.5 rounded-md mb-2 w-max max-w-full truncate">
                                <span>🎯</span>
                                <span className="truncate">{story.communityName}</span>
                              </div>
                            )}
                          </div>

                          <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 text-[10px] text-slate-500">
                            <span className="font-mono">{story.lifetimeDuration.toUpperCase()} Story</span>
                            <span className="text-violet-600 font-bold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                              <span>Watch in 3D</span>
                              <ArrowRight className="w-3 h-3" />
                            </span>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            )}
            {activeMainTab === 'moments' && <MomentsRadarView />}
            {activeMainTab === 'opportunities' && <OpportunityRadarView />}
          </main>

          {/* Right Column: AI Matchmaker & Radar Insights (3 cols) */}
          <aside className="lg:col-span-3 space-y-4">
            {/* Top Living Stories Mini Bar */}
            <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1.5">
                  <Play className="w-4 h-4 text-amber-500 fill-amber-500" />
                  <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide">
                    Living Stories
                  </h4>
                </div>
                <button
                  onClick={() => setActiveMainTab('stories')}
                  className="text-xs font-bold text-amber-600 hover:underline cursor-pointer"
                >
                  View All
                </button>
              </div>

              <div className="space-y-2">
                {timeShiftStories.slice(0, 3).map((story) => (
                  <div
                    key={story.id}
                    onClick={() => {
                      setActiveTimeShiftStory(story);
                      setIsTimeShiftStoryViewerOpen(true);
                    }}
                    className="p-2.5 rounded-xl border border-slate-200/80 bg-slate-50 hover:bg-white hover:border-amber-400 transition-all cursor-pointer flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-7 h-7 rounded-full p-0.5 bg-gradient-to-tr from-amber-400 to-rose-500 shrink-0">
                        <img
                          src={story.authorAvatar}
                          alt={story.authorName}
                          className="w-full h-full rounded-full object-cover"
                        />
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-900 truncate">
                          {story.authorName}
                        </p>
                        <p className="text-[10px] text-slate-500 truncate">
                          {story.communityName || story.caption}
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-amber-600 font-bold shrink-0">
                      3D Play
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Top AI Proactive Matches Widget */}
            <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-violet-600" />
                  <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide">
                    Live Opportunities
                  </h4>
                </div>
                <button
                  onClick={() => setActiveMainTab('opportunities')}
                  className="text-xs font-bold text-violet-600 hover:underline cursor-pointer"
                >
                  View All
                </button>
              </div>

              <div className="space-y-3">
                {opportunityMatches.slice(0, 3).map((match) => (
                  <div
                    key={match.id}
                    className="p-3 rounded-xl border border-slate-200/80 bg-slate-50/70 hover:bg-white hover:border-violet-300 transition-all text-xs"
                  >
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <span className="font-bold text-slate-900 line-clamp-1">{match.title}</span>
                      <span className="text-[10px] font-black text-violet-700 bg-violet-100 px-1.5 py-0.2 rounded shrink-0">
                        {match.compatibilityScore}%
                      </span>
                    </div>
                    <p className="text-slate-600 text-[11px] line-clamp-2 mb-2">
                      {match.explanation}
                    </p>
                    <button
                      onClick={() => {
                        initiateIntroduceMe({
                          id: match.targetProfile.id,
                          name: match.targetProfile.name,
                          handle: match.targetProfile.handle,
                          avatar: match.targetProfile.avatar,
                          headline: match.targetProfile.dynamicBio,
                          location: `${match.targetProfile.location.neighborhood}, ${match.targetProfile.location.city}`,
                          compatibilityScore: match.compatibilityScore,
                          commonGoals: match.mutualGoals,
                          proofBadges: match.targetProfile.proofOfExperienceBadges.map((b) => b.title),
                          reason: match.explanation,
                        });
                      }}
                      className="w-full py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-bold text-[11px] flex items-center justify-center gap-1 cursor-pointer transition-colors"
                    >
                      <Sparkles className="w-3 h-3 text-amber-300" />
                      <span>Introduce Me</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Ephemeral Moments Radar Mini-Widget */}
            <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1.5">
                  <Radio className="w-4 h-4 text-emerald-600" />
                  <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide">
                    Live Nearby Radar
                  </h4>
                </div>
                <button
                  onClick={() => setActiveMainTab('moments')}
                  className="text-xs font-bold text-emerald-600 hover:underline cursor-pointer"
                >
                  Radar Map
                </button>
              </div>

              <div className="space-y-2">
                {temporaryMoments.slice(0, 3).map((moment) => (
                  <div
                    key={moment.id}
                    onClick={() => setActiveMainTab('moments')}
                    className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-emerald-50/40 transition-colors cursor-pointer text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 line-clamp-1">{moment.headline}</span>
                      <span className="text-[10px] text-rose-600 font-bold font-mono shrink-0">
                        {moment.expiresAt}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-500 mt-0.5 block">
                      📍 {moment.locationName} • {moment.participantsCount} attending
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </div>

      {/* Global Modals for Social Network */}
      <AITwinDashboardModal />
      <IntroduceMeModal />
      <CreateSocialEntityModal />
    </div>
  );
};
