import React, { useState } from 'react';
import { ProductCollection } from '../../types';
import { useApp } from '../../context/AppContext';
import {
  X,
  Copy,
  Check,
  Send,
  Share2,
  QrCode,
  Globe,
  MessageCircle,
  Sparkles,
} from 'lucide-react';

interface ShareCollectionModalProps {
  collection: ProductCollection | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ShareCollectionModal: React.FC<ShareCollectionModalProps> = ({
  collection,
  isOpen,
  onClose,
}) => {
  const { showToast, setIsUniversalChatOpen } = useApp();
  const [hasCopied, setHasCopied] = useState(false);
  const [showQR, setShowQR] = useState(false);

  if (!isOpen || !collection) return null;

  const shareUrl = `https://ecomworld.app/collections/${collection.id}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setHasCopied(true);
    showToast('🔗 Collection link copied to clipboard!');
    setTimeout(() => setHasCopied(false), 2000);
  };

  const handleShareToChat = () => {
    onClose();
    setIsUniversalChatOpen(true);
    showToast(`Shared "${collection.name}" collection preview to Chat!`);
  };

  const handleShareToWhatsApp = () => {
    const text = encodeURIComponent(
      `Check out this curated collection "${collection.name}" (${collection.itemProductIds.length} items) on E-Commerce World: ${shareUrl}`
    );
    window.open(`https://wa.me/?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-100/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden border border-neutral-100 flex flex-col z-10 animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-5 border-b border-neutral-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-neutral-100 flex items-center justify-center text-xl">
              {collection.emoji || '📁'}
            </div>
            <div>
              <h3 className="font-bold text-neutral-900 text-base">Share Collection</h3>
              <p className="text-xs text-neutral-500 truncate max-w-[200px]">
                {collection.name} ({collection.itemProductIds.length} items)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-neutral-100 text-neutral-400 hover:text-neutral-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {/* Cover preview banner */}
          <div className="relative h-28 rounded-2xl overflow-hidden shadow-xs border border-neutral-100 bg-neutral-900">
            {collection.coverImage && (
              <img
                src={collection.coverImage}
                alt={collection.name}
                className="w-full h-full object-cover opacity-70"
                referrerPolicy="no-referrer"
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-100/80 via-slate-100/20 to-transparent p-3 flex flex-col justify-end">
              <span className="text-white font-bold text-sm flex items-center gap-1.5">
                <span>{collection.emoji}</span>
                {collection.name}
              </span>
              <span className="text-neutral-300 text-xs">
                {collection.privacy === 'collaborative'
                  ? '🤝 Collaborative Board'
                  : collection.privacy === 'public'
                  ? '🌐 Public Collection'
                  : '🔒 Private Collection'}
              </span>
            </div>
          </div>

          {/* Quick Copy Link Box */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-neutral-400 mb-1.5">
              Shareable Link
            </label>
            <div className="flex items-center gap-2 p-1.5 bg-neutral-50 rounded-2xl border border-neutral-200">
              <input
                type="text"
                readOnly
                value={shareUrl}
                className="flex-1 px-3 py-1.5 text-xs text-neutral-600 bg-transparent focus:outline-hidden"
              />
              <button
                onClick={handleCopyLink}
                className="px-4 py-2 bg-neutral-900 text-white rounded-xl text-xs font-semibold hover:bg-slate-100 transition flex items-center gap-1.5 shadow-xs"
              >
                {hasCopied ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{hasCopied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Share Channels */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={handleShareToWhatsApp}
              className="flex flex-col items-center justify-center p-3 rounded-2xl border border-neutral-200 hover:bg-emerald-50 hover:border-emerald-200 transition group"
            >
              <div className="w-10 h-10 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition">
                <MessageCircle className="w-5 h-5" />
              </div>
              <span className="text-xs font-medium text-neutral-800 mt-2">WhatsApp</span>
            </button>

            <button
              onClick={handleShareToChat}
              className="flex flex-col items-center justify-center p-3 rounded-2xl border border-neutral-200 hover:bg-blue-50 hover:border-blue-200 transition group"
            >
              <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition">
                <Send className="w-5 h-5" />
              </div>
              <span className="text-xs font-medium text-neutral-800 mt-2">Direct Chat</span>
            </button>

            <button
              onClick={() => setShowQR(!showQR)}
              className="flex flex-col items-center justify-center p-3 rounded-2xl border border-neutral-200 hover:bg-neutral-50 transition group"
            >
              <div className="w-10 h-10 rounded-full bg-neutral-900 text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition">
                <QrCode className="w-5 h-5" />
              </div>
              <span className="text-xs font-medium text-neutral-800 mt-2">QR Code</span>
            </button>
          </div>

          {/* QR Code view toggle */}
          {showQR && (
            <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-200 flex flex-col items-center justify-center space-y-2 animate-in fade-in">
              <div className="w-36 h-36 bg-white p-2 rounded-xl shadow-xs border border-neutral-200 flex items-center justify-center">
                <div className="w-32 h-32 bg-[radial-gradient(#0f172a_2px,transparent_2px)] [background-size:8px_8px] border-2 border-neutral-900 rounded-lg flex items-center justify-center text-center p-2 text-[10px] font-mono font-bold">
                  {collection.name}
                </div>
              </div>
              <p className="text-xs text-neutral-500 text-center">
                Scan with any mobile camera to open this collection
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
