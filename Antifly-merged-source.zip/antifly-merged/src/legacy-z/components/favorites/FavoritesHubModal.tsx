import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Product, ProductCollection } from '../../types';
import {
  Heart,
  Search,
  LayoutGrid,
  List,
  SlidersHorizontal,
  FolderHeart,
  Plus,
  Share2,
  Lock,
  Globe,
  Users,
  Bell,
  BellOff,
  TrendingDown,
  Sparkles,
  ShoppingBag,
  ShoppingCart,
  Zap,
  MoreVertical,
  X,
  Check,
  ChevronRight,
  Flame,
  ArrowRight,
  Trash2,
  ExternalLink,
  Store,
  Film,
  Bookmark,
  Layers,
} from 'lucide-react';
import { ProductContextMenuModal } from './ProductContextMenuModal';
import { CreateOrEditCollectionModal } from './CreateOrEditCollectionModal';
import { ShareCollectionModal } from './ShareCollectionModal';
import { CollaborativeCollectionDetail } from './CollaborativeCollectionDetail';
import { FigmaScreensExplorerModal } from './FigmaScreensExplorerModal';

export const FavoritesHubModal: React.FC = () => {
  const {
    isFavoritesHubOpen,
    setIsFavoritesHubOpen,
    activeFavoritesTab,
    setActiveFavoritesTab,
    savedProductViewMode,
    setSavedProductViewMode,
    savedProductIds,
    savedSellerPostIds,
    savedSellerPortfolioIds,
    userCollections,
    creatorCollections,
    activeCollectionId,
    setActiveCollectionId,
    products,
    sellers,
    communityPosts,
    wishlistDetails,
    togglePriceDropAlert,
    toggleWishlistWithAlert,
    smartCategorySuggestions,
    acceptSmartCategorySuggestion,
    dismissSmartCategorySuggestion,
    quickSaveProductWithSmartFlow,
    setActivePdpId,
    addToCart,
    buyNow,
    openSmartSaveBottomSheet,
    openSellerStorefront,
    setIsCommunityHubOpen,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [contextMenuProduct, setContextMenuProduct] = useState<Product | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [collectionToEdit, setCollectionToEdit] = useState<ProductCollection | null>(null);
  const [shareCollection, setShareCollection] = useState<ProductCollection | null>(null);
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');

  if (!isFavoritesHubOpen) return null;

  // Filter saved products
  const savedProducts = useMemo(() => {
    return savedProductIds
      .map((id) => products.find((p) => p.id === id))
      .filter((p): p is Product => Boolean(p))
      .filter((p) => {
        if (!searchQuery.trim()) return true;
        const q = searchQuery.toLowerCase();
        return (
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.storeName.toLowerCase().includes(q)
        );
      });
  }, [savedProductIds, products, searchQuery]);

  // Wishlist products
  const wishlistProducts = useMemo(() => {
    return Object.keys(wishlistDetails)
      .map((id) => {
        const prod = products.find((p) => p.id === id);
        const details = wishlistDetails[id];
        return { prod, details };
      })
      .filter((item): item is { prod: Product; details: any } => Boolean(item.prod));
  }, [wishlistDetails, products]);

  // Total savings in wishlist
  const totalWishlistSavings = wishlistProducts.reduce((acc, curr) => {
    if (curr.details?.savedAmount) {
      return acc + curr.details.savedAmount;
    }
    if (curr.prod.mrp && curr.prod.mrp > curr.prod.price) {
      return acc + (curr.prod.mrp - curr.prod.price);
    }
    return acc;
  }, 0);

  // Active selected collection object
  const activeCollection = userCollections.find((c) => c.id === activeCollectionId) || null;

  const handleOpenCollection = (colId: string) => {
    setActiveCollectionId(colId);
  };

  const handleBackToCollections = () => {
    setActiveCollectionId(null);
  };

  const handleEditCollection = (col: ProductCollection) => {
    setCollectionToEdit(col);
    setIsCreateModalOpen(true);
  };

  const handleCreateNewCollection = () => {
    setCollectionToEdit(null);
    setIsCreateModalOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-slate-100/50 backdrop-blur-xs transition-opacity animate-in fade-in duration-200">
      {/* Backdrop */}
      <div className="fixed inset-0" onClick={() => setIsFavoritesHubOpen(false)} />

      {/* Main Hub Container */}
      <div className="relative w-full max-w-6xl h-full sm:h-[90vh] bg-white sm:rounded-3xl shadow-2xl overflow-hidden border border-neutral-100 flex flex-col z-10 animate-in zoom-in-95 duration-200">
        {/* Top Header */}
        <div className="p-4 sm:p-5 bg-white border-b border-neutral-100 flex flex-col gap-4 shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-red-50 text-red-500 border border-red-100 flex items-center justify-center text-xl shadow-xs">
                ❤️
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-lg sm:text-xl font-extrabold text-neutral-900 tracking-tight">
                    Favorites & Saved
                  </h1>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-neutral-100 text-neutral-800">
                    {savedProducts.length} items
                  </span>
                </div>
                <p className="text-xs text-neutral-500 hidden sm:block">
                  Your curated wardrobe, wishlists, collaborative shopping boards, and creator drops
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCreateNewCollection}
                className="px-3.5 py-2 bg-neutral-900 text-white rounded-xl text-xs font-semibold hover:bg-slate-100 transition flex items-center gap-1.5 shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">New Collection</span>
              </button>

              <button
                onClick={() => setIsFavoritesHubOpen(false)}
                className="p-2 rounded-full hover:bg-neutral-100 text-neutral-400 hover:text-neutral-700 transition"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Search Bar & View Mode Switcher */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search saved products, collections, stores, or brands..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-neutral-50 rounded-2xl border border-neutral-200 text-xs focus:outline-hidden focus:border-neutral-900 focus:bg-white transition"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* View Mode Switcher */}
            <div className="flex items-center gap-1 bg-neutral-100 p-1 rounded-2xl self-end sm:self-auto">
              <button
                onClick={() => setSavedProductViewMode('grid')}
                className={`p-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition ${
                  savedProductViewMode === 'grid'
                    ? 'bg-white text-neutral-900 shadow-xs'
                    : 'text-neutral-500 hover:text-neutral-900'
                }`}
                title="Grid View"
              >
                <LayoutGrid className="w-4 h-4" />
                <span className="hidden md:inline text-[11px]">Grid</span>
              </button>

              <button
                onClick={() => setSavedProductViewMode('masonry')}
                className={`p-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition ${
                  savedProductViewMode === 'masonry'
                    ? 'bg-white text-neutral-900 shadow-xs'
                    : 'text-neutral-500 hover:text-neutral-900'
                }`}
                title="Masonry View"
              >
                <SlidersHorizontal className="w-4 h-4" />
                <span className="hidden md:inline text-[11px]">Masonry</span>
              </button>

              <button
                onClick={() => setSavedProductViewMode('list')}
                className={`p-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition ${
                  savedProductViewMode === 'list'
                    ? 'bg-white text-neutral-900 shadow-xs'
                    : 'text-neutral-500 hover:text-neutral-900'
                }`}
                title="List View"
              >
                <List className="w-4 h-4" />
                <span className="hidden md:inline text-[11px]">List</span>
              </button>
            </div>
          </div>

          {/* Navigation Filter Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none border-t border-neutral-100 pt-3">
            {[
              { id: 'products', label: 'Products', count: savedProducts.length, icon: ShoppingBag },
              { id: 'collections', label: 'Collections', count: userCollections.length, icon: FolderHeart },
              { id: 'wishlist', label: 'Wishlist', count: wishlistProducts.length, icon: Sparkles },
              { id: 'collaborative', label: 'Collaborative', count: userCollections.filter((c) => c.privacy === 'collaborative').length, icon: Users },
              { id: 'creators', label: 'Creator Picks', count: creatorCollections.length, icon: Flame },
              { id: 'posts', label: 'Posts & Reels', count: savedSellerPostIds.length, icon: Film },
              { id: 'stores', label: 'Stores', count: savedSellerPortfolioIds.length, icon: Store },
              { id: 'figma_screens', label: '🎨 22 Figma Screens', icon: Layers, isSpecial: true },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeFavoritesTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveCollectionId(null);
                    setActiveFavoritesTab(tab.id as any);
                  }}
                  className={`px-3.5 py-2 rounded-2xl text-xs font-semibold whitespace-nowrap transition flex items-center gap-1.5 shrink-0 border ${
                    isActive
                      ? tab.isSpecial
                        ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white border-transparent shadow-xs'
                        : 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
                      : tab.isSpecial
                      ? 'bg-purple-50 hover:bg-purple-100 text-purple-900 border-purple-200'
                      : 'bg-neutral-50 hover:bg-neutral-100 text-neutral-700 border-neutral-100'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                  {tab.count !== undefined && (
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                        isActive ? 'bg-white/20 text-white' : 'bg-neutral-200 text-neutral-700'
                      }`}
                    >
                      {tab.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-neutral-50/50">
          {/* If looking at a specific collaborative or custom collection */}
          {activeCollection ? (
            <CollaborativeCollectionDetail
              collection={activeCollection}
              onBack={handleBackToCollections}
              onOpenShare={(col) => setShareCollection(col)}
              onOpenEdit={(col) => handleEditCollection(col)}
            />
          ) : activeFavoritesTab === 'figma_screens' ? (
            <FigmaScreensExplorerModal />
          ) : activeFavoritesTab === 'collections' ? (
            /* ==========================================
               COLLECTIONS TAB
               ========================================== */
            <div className="space-y-6">
              {/* Header intro */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-3xl border border-neutral-100 shadow-xs">
                <div>
                  <h3 className="font-bold text-neutral-900 text-base">Custom Collections</h3>
                  <p className="text-xs text-neutral-500">
                    Group your saved products by outfit ideas, seasonal drops, rooms, or gift lists
                  </p>
                </div>
                <button
                  onClick={handleCreateNewCollection}
                  className="px-4 py-2 bg-neutral-900 text-white text-xs font-semibold rounded-xl hover:bg-slate-100 transition flex items-center gap-1.5 shadow-xs self-start sm:self-auto"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Create Collection</span>
                </button>
              </div>

              {/* Collections Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {userCollections.map((col) => {
                  const cover = col.coverImage || 'https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?w=800';
                  return (
                    <div
                      key={col.id}
                      className="bg-white rounded-3xl overflow-hidden border border-neutral-100 shadow-xs hover:shadow-md transition flex flex-col group cursor-pointer"
                      onClick={() => handleOpenCollection(col.id)}
                    >
                      {/* Cover Photo */}
                      <div className="relative h-44 bg-neutral-900 overflow-hidden">
                        <img
                          src={cover}
                          alt={col.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition duration-300 opacity-90"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-100/80 via-slate-100/20 to-transparent p-4 flex flex-col justify-between">
                          <div className="flex items-center justify-between">
                            <span className="w-10 h-10 rounded-2xl bg-white/90 backdrop-blur-md flex items-center justify-center text-xl shadow-xs">
                              {col.emoji || '📁'}
                            </span>
                            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-slate-100/60 backdrop-blur-md text-white border border-white/20 flex items-center gap-1">
                              {col.privacy === 'private' && <Lock className="w-2.5 h-2.5" />}
                              {col.privacy === 'followers' && <Users className="w-2.5 h-2.5" />}
                              {col.privacy === 'public' && <Globe className="w-2.5 h-2.5" />}
                              {col.privacy === 'collaborative' && <Sparkles className="w-2.5 h-2.5 text-amber-300" />}
                              <span>{col.privacy}</span>
                            </span>
                          </div>

                          <div>
                            <h4 className="text-white font-bold text-base truncate">{col.name}</h4>
                            <p className="text-neutral-300 text-xs truncate">
                              {col.itemProductIds.length} products • Updated {col.updatedAt || 'Recently'}
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Card Footer Actions */}
                      <div className="p-3.5 bg-white flex items-center justify-between border-t border-neutral-50" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setShareCollection(col)}
                            className="p-2 rounded-xl text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 transition"
                            title="Share Collection"
                          >
                            <Share2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleEditCollection(col)}
                            className="p-2 rounded-xl text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 transition"
                            title="Edit Settings"
                          >
                            <MoreVertical className="w-4 h-4" />
                          </button>
                        </div>

                        <button
                          onClick={() => handleOpenCollection(col.id)}
                          className="text-xs font-bold text-neutral-900 hover:underline flex items-center gap-1"
                        >
                          <span>Open Board</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : activeFavoritesTab === 'wishlist' ? (
            /* ==========================================
               WISHLIST TAB (SMART ALERTS & PRICE DROPS)
               ========================================== */
            <div className="space-y-6">
              {/* Savings & Alert Summary Banner */}
              <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white rounded-3xl p-6 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-bold">
                    <TrendingDown className="w-3.5 h-3.5" />
                    <span>Price Drop Intelligence Engine</span>
                  </div>
                  <h3 className="text-xl font-extrabold">
                    ₹{totalWishlistSavings.toLocaleString('en-IN')} Total Savings in Wishlist
                  </h3>
                  <p className="text-xs text-emerald-100 max-w-md">
                    We track price changes and flash coupons 24/7 across your saved wishlist items.
                  </p>
                </div>

                <div className="flex items-center gap-2 bg-white/10 p-3 rounded-2xl backdrop-blur-md">
                  <Bell className="w-5 h-5 text-amber-300 fill-amber-300" />
                  <div className="text-xs">
                    <div className="font-bold">Instant Notifications Active</div>
                    <div className="text-emerald-100 text-[11px]">Email + Push Alerts</div>
                  </div>
                </div>
              </div>

              {/* Wishlist Items List */}
              {wishlistProducts.length === 0 ? (
                <div className="bg-white rounded-3xl p-12 text-center border border-neutral-100 shadow-xs space-y-3">
                  <div className="w-16 h-16 rounded-3xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto text-3xl">
                    ✨
                  </div>
                  <h4 className="font-bold text-neutral-800 text-base">Your Wishlist is Empty</h4>
                  <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                    Save products to your wishlist to automatically monitor price drops and stock restocks!
                  </p>
                  <button
                    onClick={() => setActiveFavoritesTab('products')}
                    className="px-5 py-2.5 bg-neutral-900 text-white text-xs font-semibold rounded-xl hover:bg-slate-100 transition shadow-xs"
                  >
                    Browse Saved Products
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {wishlistProducts.map(({ prod, details }) => {
                    const isPriceDropped = details?.smartState === 'price_dropped';
                    const isBackInStock = details?.smartState === 'back_in_stock';
                    const isAlertOn = details?.priceDropAlertEnabled ?? true;

                    return (
                      <div
                        key={prod.id}
                        className={`bg-white rounded-3xl p-4 border transition shadow-xs hover:shadow-md flex flex-col justify-between space-y-4 ${
                          isPriceDropped ? 'border-emerald-300 bg-emerald-50/20' : 'border-neutral-100'
                        }`}
                      >
                        <div className="flex gap-3">
                          <img
                            src={prod.images[0]}
                            alt={prod.name}
                            onClick={() => setActivePdpId(prod.id)}
                            className="w-24 h-28 rounded-2xl object-cover cursor-pointer hover:opacity-95 transition border border-neutral-100 shadow-xs"
                            referrerPolicy="no-referrer"
                          />
                          <div className="flex-1 min-w-0 flex flex-col justify-between">
                            <div>
                              <div className="flex items-center gap-1.5 flex-wrap">
                                {isPriceDropped && (
                                  <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100 text-emerald-800 flex items-center gap-1">
                                    <TrendingDown className="w-3 h-3" /> Price Dropped ↓
                                  </span>
                                )}
                                {isBackInStock && (
                                  <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-100 text-blue-800">
                                    Back in Stock
                                  </span>
                                )}
                                <span className="text-[10px] text-neutral-400">
                                  Added {details?.addedAt || 'Recently'}
                                </span>
                              </div>

                              <h4
                                onClick={() => setActivePdpId(prod.id)}
                                className="font-bold text-neutral-900 text-sm truncate mt-1 cursor-pointer hover:underline"
                              >
                                {prod.name}
                              </h4>
                              <p className="text-xs text-neutral-500 truncate">{prod.storeName}</p>
                            </div>

                            <div className="flex items-baseline gap-2">
                              <span className="font-extrabold text-neutral-900 text-base">
                                ₹{prod.price.toLocaleString('en-IN')}
                              </span>
                              {prod.mrp && prod.mrp > prod.price && (
                                <span className="text-xs text-neutral-400 line-through">
                                  ₹{prod.mrp.toLocaleString('en-IN')}
                                </span>
                              )}
                              {details?.savedAmount && (
                                <span className="text-xs font-bold text-emerald-600">
                                  Save ₹{details.savedAmount}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Controls bar */}
                        <div className="pt-2 border-t border-neutral-100 flex items-center justify-between gap-2">
                          <button
                            onClick={() => togglePriceDropAlert(prod.id)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition ${
                              isAlertOn
                                ? 'bg-amber-50 text-amber-800 border border-amber-200'
                                : 'bg-neutral-100 text-neutral-500'
                            }`}
                          >
                            {isAlertOn ? <Bell className="w-3.5 h-3.5 fill-amber-500 text-amber-500" /> : <BellOff className="w-3.5 h-3.5" />}
                            <span>{isAlertOn ? 'Tracking Drops' : 'Alerts Off'}</span>
                          </button>

                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => addToCart(prod)}
                              className="px-3 py-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold rounded-xl transition flex items-center gap-1"
                            >
                              <ShoppingCart className="w-3.5 h-3.5" />
                              <span>Cart</span>
                            </button>
                            <button
                              onClick={() => buyNow(prod)}
                              className="px-4 py-1.5 bg-neutral-900 hover:bg-slate-100 text-white text-xs font-semibold rounded-xl transition flex items-center gap-1 shadow-xs"
                            >
                              <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                              <span>Buy</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ) : activeFavoritesTab === 'collaborative' ? (
            /* ==========================================
               COLLABORATIVE SHOPPING BOARDS
               ========================================== */
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-emerald-900 to-teal-900 text-white rounded-3xl p-6 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-bold text-emerald-200">
                    <Users className="w-3.5 h-3.5" />
                    <span>Social Shopping Boards</span>
                  </div>
                  <h3 className="text-xl font-extrabold">Shop Together with Friends & Family</h3>
                  <p className="text-xs text-emerald-100 max-w-md">
                    Invite friends to vote (👍 ❤️ 🔥), comment on outfits, and build trip shopping lists together in real-time.
                  </p>
                </div>

                <button
                  onClick={handleCreateNewCollection}
                  className="px-5 py-2.5 bg-white text-neutral-900 text-xs font-bold rounded-xl hover:bg-neutral-100 transition shadow-xs self-start sm:self-auto flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>New Shared Board</span>
                </button>
              </div>

              {/* Collaborative Collections List */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {userCollections
                  .filter((c) => c.privacy === 'collaborative')
                  .map((col) => (
                    <div
                      key={col.id}
                      onClick={() => handleOpenCollection(col.id)}
                      className="bg-white rounded-3xl p-5 border border-neutral-100 shadow-xs hover:shadow-md transition cursor-pointer space-y-4"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-900 flex items-center justify-center text-2xl shadow-xs">
                            {col.emoji || '🤝'}
                          </div>
                          <div>
                            <h4 className="font-bold text-neutral-900 text-base">{col.name}</h4>
                            <p className="text-xs text-neutral-500">{col.itemProductIds.length} curated pieces</p>
                          </div>
                        </div>

                        <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full text-xs font-bold flex items-center gap-1">
                          <Users className="w-3 h-3" /> Live
                        </span>
                      </div>

                      <div className="flex items-center justify-between pt-3 border-t border-neutral-100">
                        <div className="flex items-center -space-x-2">
                          {col.collaborators?.map((cl) => (
                            <img
                              key={cl.id}
                              src={cl.avatar}
                              alt={cl.name}
                              className="w-7 h-7 rounded-full border-2 border-white object-cover shadow-xs"
                              referrerPolicy="no-referrer"
                            />
                          ))}
                        </div>

                        <span className="text-xs font-bold text-neutral-900 flex items-center gap-1">
                          <span>Enter Board</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          ) : activeFavoritesTab === 'creators' ? (
            /* ==========================================
               CREATOR CURATED COLLECTIONS
               ========================================== */
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-amber-500 to-orange-600 text-white rounded-3xl p-6 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-bold text-amber-100">
                    <Flame className="w-3.5 h-3.5 fill-current" />
                    <span>Creator Verified Edits</span>
                  </div>
                  <h3 className="text-xl font-extrabold">Discover Wardrobes Curated by Influencers</h3>
                  <p className="text-xs text-amber-100 max-w-md">
                    Explore high-taste capsule collections curated by India's top fashion and lifestyle creators.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {creatorCollections.map((col) => (
                  <div
                    key={col.id}
                    className="bg-white rounded-3xl overflow-hidden border border-neutral-100 shadow-xs hover:shadow-md transition flex flex-col"
                  >
                    <div className="relative h-48 bg-neutral-900">
                      <img
                        src={col.coverImage}
                        alt={col.name}
                        className="w-full h-full object-cover opacity-80"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-100/80 via-slate-100/30 to-transparent p-4 flex flex-col justify-between">
                        <div className="flex items-center justify-between">
                          <span className="px-2.5 py-1 bg-amber-400 text-neutral-900 rounded-full text-xs font-bold flex items-center gap-1 shadow-xs">
                            <Sparkles className="w-3 h-3 fill-current" /> Verified Creator Pick
                          </span>
                          <span className="text-white text-xs font-bold bg-slate-100/50 px-2 py-0.5 rounded-full">
                            {col.itemProductIds.length} items
                          </span>
                        </div>

                        <div>
                          <h4 className="text-white font-bold text-base">{col.name}</h4>
                          <p className="text-neutral-300 text-xs line-clamp-1">{col.description}</p>
                        </div>
                      </div>
                    </div>

                    {/* Creator profile strip */}
                    <div className="p-4 bg-white flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <img
                          src={col.creatorInfo?.avatar}
                          alt={col.creatorInfo?.name}
                          className="w-10 h-10 rounded-full object-cover border border-neutral-200 shadow-xs"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <div className="font-bold text-neutral-900 text-xs flex items-center gap-1">
                            <span>{col.creatorInfo?.name}</span>
                            <span className="text-[10px] text-amber-600 bg-amber-50 px-1.5 py-0.2 rounded-md font-semibold">
                              {col.creatorInfo?.badge}
                            </span>
                          </div>
                          <p className="text-[11px] text-neutral-500">
                            {col.creatorInfo?.handle} • {col.creatorInfo?.followersCount} Followers
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          // Quick clone creator products into favorites
                          col.itemProductIds.forEach((id) => {
                            if (!savedProductIds.includes(id)) {
                              quickSaveProductWithSmartFlow(id);
                            }
                          });
                        }}
                        className="px-3.5 py-2 bg-neutral-900 text-white rounded-xl text-xs font-bold hover:bg-slate-100 transition shadow-xs"
                      >
                        Save All ({col.itemProductIds.length})
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : activeFavoritesTab === 'posts' ? (
            /* ==========================================
               POSTS & REELS TAB
               ========================================== */
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-neutral-100">
                <span className="text-xs font-bold text-neutral-800">Saved Stories & 15s Product Reels</span>
                <button
                  onClick={() => setIsCommunityHubOpen(true)}
                  className="text-xs font-semibold text-neutral-900 hover:underline flex items-center gap-1"
                >
                  <span>Explore Reels Feed</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {savedSellerPostIds.map((postId) => {
                  const post = communityPosts.find((p) => p.id === postId) || {
                    id: postId,
                    imageUrl: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600',
                    content: 'Festive look drop by Kala Sanskriti',
                    likesCount: 142,
                    sellerName: 'Kala Studio',
                  };
                  return (
                    <div
                      key={postId}
                      onClick={() => setIsCommunityHubOpen(true)}
                      className="relative aspect-3/4 rounded-2xl overflow-hidden bg-neutral-900 shadow-xs cursor-pointer group"
                    >
                      <img
                        src={post.imageUrl}
                        alt="Reel"
                        className="w-full h-full object-cover group-hover:scale-105 transition"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-100/80 via-transparent to-transparent p-3 flex flex-col justify-end text-white">
                        <span className="text-xs font-bold truncate">{post.content}</span>
                        <span className="text-[10px] text-neutral-300 flex items-center gap-1">
                          <Heart className="w-3 h-3 fill-red-500 text-red-500" /> {post.likesCount} likes
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : activeFavoritesTab === 'stores' ? (
            /* ==========================================
               STORES TAB
               ========================================== */
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {sellers.slice(0, 4).map((seller) => (
                  <div
                    key={seller.id}
                    onClick={() => openSellerStorefront(seller.id)}
                    className="bg-white p-4 rounded-3xl border border-neutral-100 shadow-xs hover:shadow-md transition cursor-pointer flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={seller.logo}
                        alt={seller.name}
                        className="w-12 h-12 rounded-2xl object-cover border border-neutral-100"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <h4 className="font-bold text-neutral-900 text-sm truncate">{seller.name}</h4>
                        <p className="text-xs text-neutral-500">{seller.category} • ⭐ {seller.rating}</p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-neutral-400" />
                  </div>
                ))}
              </div>
            </div>
          ) : (
            /* ==========================================
               DEFAULT: PRODUCTS FEED
               ========================================== */
            <div className="space-y-6">
              {/* Smart Categories Suggestions Engine Banner */}
              {smartCategorySuggestions.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between px-1">
                    <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-500" /> Smart Collection Suggestions
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {smartCategorySuggestions.map((sug) => (
                      <div
                        key={sug.categoryName}
                        className="bg-white p-4 rounded-2xl border border-neutral-100 shadow-xs flex items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <span className="text-2xl">{sug.suggestedEmoji}</span>
                          <div className="min-w-0">
                            <h4 className="font-bold text-neutral-900 text-xs truncate">
                              {sug.categoryName}
                            </h4>
                            <p className="text-[11px] text-neutral-500 truncate">
                              You saved {sug.count} products
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => acceptSmartCategorySuggestion(sug)}
                            className="px-3 py-1.5 bg-neutral-900 text-white rounded-xl text-xs font-semibold hover:bg-slate-100 transition shadow-xs whitespace-nowrap"
                          >
                            Create
                          </button>
                          <button
                            onClick={() => dismissSmartCategorySuggestion(sug.categoryName)}
                            className="p-1 text-neutral-300 hover:text-neutral-600"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Social Discovery Strip */}
              <div className="flex items-center gap-3 p-3 bg-white rounded-2xl border border-neutral-100 shadow-xs">
                <div className="flex -space-x-2">
                  <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100" alt="u1" className="w-6 h-6 rounded-full border border-white" />
                  <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100" alt="u2" className="w-6 h-6 rounded-full border border-white" />
                  <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100" alt="u3" className="w-6 h-6 rounded-full border border-white" />
                </div>
                <p className="text-xs text-neutral-700 font-medium">
                  <span className="font-bold text-neutral-900">Rahul Varma</span> and <span className="font-bold text-neutral-900">12 others</span> saved items from your favorite stores today.
                </p>
              </div>

              {/* Products View: Grid / Masonry / List */}
              {savedProducts.length === 0 ? (
                <div className="bg-white rounded-3xl p-12 text-center border border-neutral-100 shadow-xs space-y-3">
                  <div className="w-16 h-16 rounded-3xl bg-red-50 text-red-500 flex items-center justify-center mx-auto text-3xl">
                    ❤️
                  </div>
                  <h4 className="font-bold text-neutral-800 text-base">No Saved Products Found</h4>
                  <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                    Tap the heart icon on any product across our feed, categories, or reels to save them here!
                  </p>
                  <button
                    onClick={() => {
                      // Save sample product for demo
                      quickSaveProductWithSmartFlow(products[0]?.id || 'wi-prod-001');
                    }}
                    className="px-5 py-2.5 bg-neutral-900 text-white text-xs font-semibold rounded-xl hover:bg-slate-100 transition shadow-xs"
                  >
                    Save Trending Kurta to Favorites
                  </button>
                </div>
              ) : savedProductViewMode === 'list' ? (
                /* Dense List View */
                <div className="space-y-3">
                  {savedProducts.map((product) => {
                    const priceDropInfo = wishlistDetails[product.id];
                    return (
                      <div
                        key={product.id}
                        className="bg-white rounded-3xl p-4 border border-neutral-100 shadow-xs hover:shadow-md transition flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                      >
                        <div className="flex items-center gap-4 min-w-0">
                          <img
                            src={product.images[0]}
                            alt={product.name}
                            onClick={() => setActivePdpId(product.id)}
                            className="w-20 h-20 rounded-2xl object-cover cursor-pointer hover:opacity-95 transition border border-neutral-100 shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] uppercase font-bold text-neutral-500 bg-neutral-100 px-2 py-0.5 rounded-md">
                                {product.category}
                              </span>
                              {priceDropInfo?.smartState === 'price_dropped' && (
                                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md flex items-center gap-0.5">
                                  <TrendingDown className="w-3 h-3" /> Price Dropped
                                </span>
                              )}
                            </div>
                            <h4
                              onClick={() => setActivePdpId(product.id)}
                              className="font-bold text-neutral-900 text-sm truncate mt-1 cursor-pointer hover:underline"
                            >
                              {product.name}
                            </h4>
                            <p className="text-xs text-neutral-500 truncate">{product.storeName}</p>
                            <div className="flex items-baseline gap-2 mt-1">
                              <span className="font-extrabold text-neutral-900 text-sm">
                                ₹{product.price.toLocaleString('en-IN')}
                              </span>
                              {product.mrp && product.mrp > product.price && (
                                <span className="text-xs text-neutral-400 line-through">
                                  ₹{product.mrp.toLocaleString('en-IN')}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* List Actions */}
                        <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                          <button
                            onClick={() => openSmartSaveBottomSheet(product.id)}
                            className="p-2.5 rounded-xl bg-neutral-50 hover:bg-neutral-100 text-neutral-600 text-xs font-semibold transition flex items-center gap-1 border border-neutral-200"
                            title="Add to collection"
                          >
                            <FolderHeart className="w-4 h-4 text-blue-600" />
                          </button>
                          <button
                            onClick={() => addToCart(product)}
                            className="px-3.5 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold rounded-xl transition flex items-center gap-1.5"
                          >
                            <ShoppingCart className="w-3.5 h-3.5" />
                            <span>Cart</span>
                          </button>
                          <button
                            onClick={() => buyNow(product)}
                            className="px-4 py-2 bg-neutral-900 hover:bg-slate-100 text-white text-xs font-semibold rounded-xl transition flex items-center gap-1.5 shadow-xs"
                          >
                            <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                            <span>Buy</span>
                          </button>
                          <button
                            onClick={() => setContextMenuProduct(product)}
                            className="p-2 rounded-xl text-neutral-400 hover:text-neutral-700"
                          >
                            <MoreVertical className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                /* Grid & Masonry View */
                <div
                  className={`grid gap-4 ${
                    savedProductViewMode === 'masonry'
                      ? 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4'
                      : 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4'
                  }`}
                >
                  {savedProducts.map((product, idx) => {
                    const priceDropInfo = wishlistDetails[product.id];
                    const isMasonryTaller = savedProductViewMode === 'masonry' && idx % 3 === 1;

                    return (
                      <div
                        key={product.id}
                        className="bg-white rounded-3xl overflow-hidden border border-neutral-100 shadow-xs hover:shadow-md transition flex flex-col group relative"
                      >
                        {/* Image Showcase */}
                        <div
                          className={`relative overflow-hidden bg-neutral-100 ${
                            isMasonryTaller ? 'aspect-3/5' : 'aspect-3/4'
                          }`}
                        >
                          <img
                            src={product.images[0]}
                            alt={product.name}
                            onClick={() => setActivePdpId(product.id)}
                            className="w-full h-full object-cover group-hover:scale-105 transition duration-300 cursor-pointer"
                            referrerPolicy="no-referrer"
                          />

                          {/* Heart Button Overlay */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              quickSaveProductWithSmartFlow(product.id, e);
                            }}
                            className="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/90 backdrop-blur-md flex items-center justify-center text-red-500 shadow-xs hover:scale-110 active:scale-95 transition"
                            title="Remove from favorites"
                          >
                            <Heart className="w-5 h-5 fill-red-500 text-red-500" />
                          </button>

                          {/* Price drop badge if present */}
                          {priceDropInfo?.smartState === 'price_dropped' && (
                            <div className="absolute top-3 left-3 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-600 text-white shadow-xs flex items-center gap-1">
                              <TrendingDown className="w-3 h-3" /> ↓ ₹{priceDropInfo.savedAmount || 500}
                            </div>
                          )}

                          {/* 3-dot context menu trigger */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setContextMenuProduct(product);
                            }}
                            className="absolute bottom-3 right-3 w-8 h-8 rounded-full bg-white/90 backdrop-blur-md flex items-center justify-center text-neutral-700 shadow-xs hover:bg-white transition"
                          >
                            <MoreVertical className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Product Info */}
                        <div className="p-3.5 flex flex-col justify-between flex-1 space-y-2">
                          <div>
                            <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">
                              {product.storeName}
                            </span>
                            <h4
                              onClick={() => setActivePdpId(product.id)}
                              className="font-bold text-neutral-900 text-xs sm:text-sm truncate cursor-pointer hover:underline mt-0.5"
                            >
                              {product.name}
                            </h4>
                          </div>

                          <div className="flex items-baseline justify-between pt-1">
                            <div>
                              <span className="font-extrabold text-neutral-900 text-sm sm:text-base">
                                ₹{product.price.toLocaleString('en-IN')}
                              </span>
                              {product.mrp && product.mrp > product.price && (
                                <span className="text-xs text-neutral-400 line-through ml-1">
                                  ₹{product.mrp.toLocaleString('en-IN')}
                                </span>
                              )}
                            </div>

                            <button
                              onClick={() => addToCart(product)}
                              className="p-2 bg-neutral-900 hover:bg-slate-100 text-white rounded-xl shadow-xs transition"
                              title="Add to Cart"
                            >
                              <ShoppingCart className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Sub Modals & Context Actions */}
      <ProductContextMenuModal
        product={contextMenuProduct}
        isOpen={Boolean(contextMenuProduct)}
        onClose={() => setContextMenuProduct(null)}
        onOpenMoveToCollection={(prod) => openSmartSaveBottomSheet(prod.id)}
        onOpenShare={(prod) => {
          // Share single product
          navigator.clipboard.writeText(`https://ecomworld.app/pdp/${prod.id}`);
          alert(`Link to "${prod.name}" copied to clipboard!`);
        }}
      />

      <CreateOrEditCollectionModal
        isOpen={isCreateModalOpen}
        onClose={() => {
          setIsCreateModalOpen(false);
          setCollectionToEdit(null);
        }}
        collectionToEdit={collectionToEdit}
      />

      <ShareCollectionModal
        isOpen={Boolean(shareCollection)}
        collection={shareCollection}
        onClose={() => setShareCollection(null)}
      />
    </div>
  );
};
