import React, { useState } from 'react';
import { ProductCollection, Product } from '../../types';
import { useApp } from '../../context/AppContext';
import {
  Users,
  UserPlus,
  Heart,
  Flame,
  ThumbsUp,
  MessageSquare,
  Share2,
  MoreVertical,
  Plus,
  ShoppingCart,
  Zap,
  ArrowLeft,
  Trash2,
  Sparkles,
  Lock,
  Globe,
  Send,
} from 'lucide-react';

interface CollaborativeCollectionDetailProps {
  collection: ProductCollection;
  onBack: () => void;
  onOpenShare: (collection: ProductCollection) => void;
  onOpenEdit: (collection: ProductCollection) => void;
}

export const CollaborativeCollectionDetail: React.FC<CollaborativeCollectionDetailProps> = ({
  collection,
  onBack,
  onOpenShare,
  onOpenEdit,
}) => {
  const {
    products,
    setActivePdpId,
    addToCart,
    buyNow,
    reactToCollaborativeItem,
    addCollaborativeComment,
    removeProductFromCollection,
  } = useApp();

  const [activeCommentItemId, setActiveCommentItemId] = useState<string | null>(null);
  const [commentInput, setCommentInput] = useState('');

  const collectionProducts = collection.itemProductIds
    .map((id) => products.find((p) => p.id === id))
    .filter((p): p is Product => Boolean(p));

  const handleAddComment = (productId: string) => {
    if (!commentInput.trim()) return;
    addCollaborativeComment(collection.id, productId, commentInput);
    setCommentInput('');
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="bg-white rounded-3xl p-5 border border-neutral-100 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-2xl bg-neutral-50 hover:bg-neutral-100 text-neutral-600 transition"
              aria-label="Back to collections"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-900 border border-emerald-100 flex items-center justify-center text-2xl shadow-xs">
              {collection.emoji || '🤝'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-neutral-900">{collection.name}</h2>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  Collaborative
                </span>
              </div>
              <p className="text-xs text-neutral-500">
                {collection.description || 'Curated together with friends'} • {collectionProducts.length} items
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenShare(collection)}
              className="px-3.5 py-2 bg-neutral-50 hover:bg-neutral-100 text-neutral-700 text-xs font-semibold rounded-xl transition flex items-center gap-1.5 border border-neutral-200"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Share</span>
            </button>
            <button
              onClick={() => onOpenEdit(collection)}
              className="px-3.5 py-2 bg-neutral-900 text-white text-xs font-semibold rounded-xl hover:bg-slate-100 transition flex items-center gap-1.5 shadow-xs"
            >
              <span>Edit & Invite</span>
            </button>
          </div>
        </div>

        {/* Collaborators strip */}
        <div className="pt-3 border-t border-neutral-100 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">
              Board Members:
            </span>
            <div className="flex items-center -space-x-2">
              {collection.collaborators?.map((c) => (
                <img
                  key={c.id}
                  src={c.avatar}
                  alt={c.name}
                  title={`${c.name} (${c.role})`}
                  className="w-8 h-8 rounded-full border-2 border-white object-cover shadow-xs"
                  referrerPolicy="no-referrer"
                />
              )) || (
                <span className="text-xs text-neutral-500">You + 2 friends</span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full font-medium">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Votes & reactions update live for all members</span>
          </div>
        </div>
      </div>

      {/* Collaborative Product Items */}
      {collectionProducts.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-neutral-100 shadow-xs space-y-3">
          <div className="w-16 h-16 rounded-3xl bg-neutral-50 text-neutral-400 flex items-center justify-center mx-auto text-3xl">
            🛍️
          </div>
          <h4 className="font-bold text-neutral-800 text-base">This collaborative board is empty</h4>
          <p className="text-xs text-neutral-500 max-w-sm mx-auto">
            Browse products or search to add inspiring pieces to this shared board!
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {collectionProducts.map((product) => {
            const reactions = collection.itemReactions?.[product.id] || {
              likes: 0,
              loves: 0,
              fires: 0,
              userReactions: [],
            };
            const comments = collection.itemComments?.[product.id] || [];
            const isCommentsOpen = activeCommentItemId === product.id;

            return (
              <div
                key={product.id}
                className="bg-white rounded-3xl p-4 border border-neutral-100 shadow-xs hover:shadow-md transition flex flex-col justify-between space-y-4"
              >
                {/* Product Info Row */}
                <div className="flex gap-3">
                  <img
                    src={product.images[0]}
                    alt={product.name}
                    onClick={() => setActivePdpId(product.id)}
                    className="w-24 h-28 rounded-2xl object-cover cursor-pointer hover:opacity-95 transition border border-neutral-100 shadow-xs"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] uppercase font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                          {product.category || 'Fashion'}
                        </span>
                        <button
                          onClick={() => removeProductFromCollection(collection.id, product.id)}
                          className="text-neutral-300 hover:text-red-500 transition p-1"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <h4
                        onClick={() => setActivePdpId(product.id)}
                        className="font-bold text-neutral-900 text-sm truncate mt-1 cursor-pointer hover:underline"
                      >
                        {product.name}
                      </h4>
                      <p className="text-xs text-neutral-500 truncate">{product.storeName}</p>
                    </div>

                    <div className="flex items-baseline gap-2">
                      <span className="font-extrabold text-neutral-900 text-base">
                        ₹{product.price.toLocaleString('en-IN')}
                      </span>
                      {product.mrp && product.mrp > product.price && (
                        <span className="text-xs text-neutral-400 line-through">
                          ₹{product.mrp.toLocaleString('en-IN')}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Live Social Reactions Bar */}
                <div className="p-2.5 bg-neutral-50 rounded-2xl flex items-center justify-between gap-2 border border-neutral-100">
                  <div className="flex items-center gap-1.5">
                    {/* Like Reaction */}
                    <button
                      onClick={() => reactToCollaborativeItem(collection.id, product.id, 'like')}
                      className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition ${
                        reactions.userReactions.includes('like')
                          ? 'bg-neutral-900 text-white shadow-xs'
                          : 'bg-white hover:bg-neutral-200 text-neutral-700 border border-neutral-200'
                      }`}
                    >
                      <ThumbsUp className="w-3.5 h-3.5" />
                      <span>{reactions.likes}</span>
                    </button>

                    {/* Love Reaction */}
                    <button
                      onClick={() => reactToCollaborativeItem(collection.id, product.id, 'love')}
                      className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition ${
                        reactions.userReactions.includes('love')
                          ? 'bg-red-500 text-white shadow-xs'
                          : 'bg-white hover:bg-red-50 text-red-600 border border-neutral-200'
                      }`}
                    >
                      <Heart className="w-3.5 h-3.5 fill-current" />
                      <span>{reactions.loves}</span>
                    </button>

                    {/* Fire Reaction */}
                    <button
                      onClick={() => reactToCollaborativeItem(collection.id, product.id, 'fire')}
                      className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition ${
                        reactions.userReactions.includes('fire')
                          ? 'bg-amber-500 text-white shadow-xs'
                          : 'bg-white hover:bg-amber-50 text-amber-600 border border-neutral-200'
                      }`}
                    >
                      <Flame className="w-3.5 h-3.5 fill-current" />
                      <span>{reactions.fires}</span>
                    </button>
                  </div>

                  <button
                    onClick={() =>
                      setActiveCommentItemId(isCommentsOpen ? null : product.id)
                    }
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition ${
                      isCommentsOpen
                        ? 'bg-neutral-900 text-white'
                        : 'bg-white text-neutral-700 hover:bg-neutral-200 border border-neutral-200'
                    }`}
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>{comments.length}</span>
                  </button>
                </div>

                {/* Collaborative Comment Thread */}
                {isCommentsOpen && (
                  <div className="p-3 bg-neutral-50 rounded-2xl border border-neutral-200 space-y-2 animate-in fade-in">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 block">
                      Collaborator Notes ({comments.length})
                    </span>

                    <div className="space-y-1.5 max-h-32 overflow-y-auto">
                      {comments.map((c) => (
                        <div key={c.id} className="p-2 bg-white rounded-xl border border-neutral-100 text-xs">
                          <div className="flex items-center justify-between font-semibold text-neutral-900 text-[11px]">
                            <span>{c.userName}</span>
                            <span className="text-neutral-400 font-normal">{c.time}</span>
                          </div>
                          <p className="text-neutral-700 mt-0.5">{c.text}</p>
                        </div>
                      ))}
                    </div>

                    {/* Add note */}
                    <div className="flex gap-1.5 pt-1">
                      <input
                        type="text"
                        placeholder="Add a shopping note..."
                        value={commentInput}
                        onChange={(e) => setCommentInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleAddComment(product.id);
                        }}
                        className="flex-1 px-3 py-1.5 text-xs bg-white rounded-xl border border-neutral-200 focus:outline-hidden focus:border-neutral-900"
                      />
                      <button
                        onClick={() => handleAddComment(product.id)}
                        className="p-1.5 bg-neutral-900 text-white rounded-xl hover:bg-slate-100 transition"
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}

                {/* Purchase Actions */}
                <div className="flex items-center gap-2 pt-1 border-t border-neutral-100">
                  <button
                    onClick={() => addToCart(product)}
                    className="flex-1 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold rounded-xl transition flex items-center justify-center gap-1.5"
                  >
                    <ShoppingCart className="w-3.5 h-3.5" />
                    <span>Add to Cart</span>
                  </button>
                  <button
                    onClick={() => buyNow(product)}
                    className="flex-1 py-2 bg-neutral-900 hover:bg-slate-100 text-white text-xs font-semibold rounded-xl transition flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    <Zap className="w-3.5 h-3.5 fill-current text-amber-400" />
                    <span>Buy Now</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
