import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  LayoutGrid,
  List,
  Heart,
  FolderHeart,
  Plus,
  Share2,
  Lock,
  Globe,
  Users,
  Bell,
  CheckCircle2,
  TrendingDown,
  Layers,
  Smartphone,
  Tablet,
  Monitor,
  ExternalLink,
  ChevronRight,
  Info,
} from 'lucide-react';

interface FigmaScreenSpec {
  id: number;
  title: string;
  category: 'Core Flow' | 'Collection Management' | 'Wishlist & Alerts' | 'Social & Collaborative' | 'Empty States & Edge Cases';
  description: string;
  uiHighlights: string[];
  specs: {
    padding: string;
    borderRadius: string;
    typography: string;
    motion: string;
  };
  componentPreview: React.ReactNode;
}

export const FigmaScreensExplorerModal: React.FC = () => {
  const {
    products,
    userCollections,
    creatorCollections,
    wishlistDetails,
    openSmartSaveBottomSheet,
    triggerFlyingSaveAnimation,
    quickSaveProductWithSmartFlow,
    setActiveFavoritesTab,
  } = useApp();

  const [selectedScreenId, setSelectedScreenId] = useState<number>(1);
  const [deviceFrame, setDeviceFrame] = useState<'mobile' | 'tablet' | 'desktop'>('mobile');

  const sampleProduct = products[0] || {
    id: 'wi-prod-001',
    name: 'Artisan Linen Kurta & Trousers',
    price: 1999,
    mrp: 2499,
    images: ['https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?w=800'],
    storeName: 'Kala Sanskriti Studio',
  };

  const figmaScreens: FigmaScreenSpec[] = [
    {
      id: 1,
      title: '1. Favorites Home (Universal Hub)',
      category: 'Core Flow',
      description: 'The master landing screen featuring high-contrast typography, filter pills (All, Products, Posts, Videos, Stores, Collections, Wishlist), and smart category recommendations.',
      uiHighlights: [
        'White-first premium theme with 0% clutter',
        'Multi-segment tab bar with active state glow',
        'Smart category suggestion cards with 1-tap save',
        'Quick create collection action button',
      ],
      specs: {
        padding: '20px outer / 12px inner',
        borderRadius: '24px standard cards',
        typography: '22px Bold Display + 14px Medium Body',
        motion: 'Spring-damped tab slide (300ms)',
      },
      componentPreview: (
        <div className="p-4 bg-white rounded-2xl border border-neutral-200 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-neutral-900">Favorites & Saved</h3>
            <span className="px-2.5 py-1 bg-red-50 text-red-600 rounded-full text-xs font-bold flex items-center gap-1">
              <Heart className="w-3.5 h-3.5 fill-current" /> 18 Items
            </span>
          </div>
          <div className="flex gap-1.5 overflow-x-auto pb-1 text-xs font-medium">
            <span className="px-3 py-1.5 bg-neutral-900 text-white rounded-xl">All</span>
            <span className="px-3 py-1.5 bg-neutral-100 text-neutral-700 rounded-xl">Products (12)</span>
            <span className="px-3 py-1.5 bg-neutral-100 text-neutral-700 rounded-xl">Collections (6)</span>
            <span className="px-3 py-1.5 bg-neutral-100 text-neutral-700 rounded-xl">Wishlist (5)</span>
          </div>
        </div>
      ),
    },
    {
      id: 2,
      title: '2. Saved Products Grid View',
      category: 'Core Flow',
      description: '2-column responsive grid layout optimized for mobile screens with product thumbnails, store badges, and quick heart reactions.',
      uiHighlights: [
        'Aspect 3:4 product photography showcase',
        'Overlay discount badges & stock pills',
        'Tap to open PDP / 3-dot context menu trigger',
      ],
      specs: {
        padding: '12px grid gap',
        borderRadius: '20px rounded card corners',
        typography: '14px Bold Title + 16px Extrabold Price',
        motion: 'Scale on tap (0.98)',
      },
      componentPreview: (
        <div className="grid grid-cols-2 gap-2 p-3 bg-neutral-50 rounded-2xl border border-neutral-200">
          <div className="bg-white p-2.5 rounded-xl shadow-xs border border-neutral-100">
            <img src={sampleProduct.images[0]} alt="p" className="w-full h-24 object-cover rounded-lg" />
            <h5 className="text-xs font-bold text-neutral-900 truncate mt-1.5">{sampleProduct.name}</h5>
            <p className="text-xs font-extrabold text-neutral-900">₹{sampleProduct.price}</p>
          </div>
          <div className="bg-white p-2.5 rounded-xl shadow-xs border border-neutral-100">
            <img src="https://images.unsplash.com/photo-1549298916-b41d501d3772?w=500" alt="p2" className="w-full h-24 object-cover rounded-lg" />
            <h5 className="text-xs font-bold text-neutral-900 truncate mt-1.5">Handcrafted Leather Kicks</h5>
            <p className="text-xs font-extrabold text-neutral-900">₹3,499</p>
          </div>
        </div>
      ),
    },
    {
      id: 3,
      title: '3. Saved Products List View',
      category: 'Core Flow',
      description: 'Dense list mode showing expanded product details, store name, stock count, and direct Add to Cart buttons.',
      uiHighlights: [
        'Horizontal orientation with large left thumbnail',
        'Direct "Move to Cart" and "Buy Now" CTA buttons',
        'Long-press to multi-select / move',
      ],
      specs: {
        padding: '16px card padding / 8px inner gap',
        borderRadius: '16px card borders',
        typography: '15px SemiBold + 13px Regular store',
        motion: 'Fade-in list stagger (50ms)',
      },
      componentPreview: (
        <div className="space-y-2 p-3 bg-neutral-50 rounded-2xl border border-neutral-200">
          <div className="flex items-center gap-3 bg-white p-2.5 rounded-xl border border-neutral-100">
            <img src={sampleProduct.images[0]} alt="p" className="w-14 h-14 object-cover rounded-lg" />
            <div className="flex-1 min-w-0">
              <h5 className="text-xs font-bold truncate">{sampleProduct.name}</h5>
              <p className="text-xs text-neutral-500 font-bold">₹{sampleProduct.price}</p>
            </div>
            <button className="px-3 py-1 bg-neutral-900 text-white rounded-lg text-xs font-semibold">Buy</button>
          </div>
        </div>
      ),
    },
    {
      id: 4,
      title: '4. Product Saved Animation (Snapchat Fly)',
      category: 'Core Flow',
      description: 'Smooth particle and flying thumbnail physics taking the product from feed into the saved dock with heart sparkle ripples.',
      uiHighlights: [
        'Bézier swoop curve animation (1.2s)',
        'Sparkle particle burst on release',
        'Heart state change ♡ → ♥ with spring bounce',
      ],
      specs: {
        padding: 'Fixed coordinates viewport overlay',
        borderRadius: '24px flying thumbnail',
        typography: 'Micro confirmation badge',
        motion: 'cubic-bezier(0.22, 1, 0.36, 1)',
      },
      componentPreview: (
        <div className="p-4 bg-gradient-to-br from-neutral-900 to-neutral-800 text-white rounded-2xl flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-500/20 border border-red-500/50 flex items-center justify-center">
              <Heart className="w-5 h-5 fill-red-500 text-red-500 animate-bounce" />
            </div>
            <div>
              <div className="text-xs font-bold">Snapchat Flying Save Physics</div>
              <div className="text-[11px] text-neutral-400">Particle explosion + Dock landing</div>
            </div>
          </div>
          <button
            onClick={() => triggerFlyingSaveAnimation(sampleProduct.images[0], sampleProduct.name)}
            className="px-3 py-1.5 bg-white text-neutral-900 text-xs font-bold rounded-xl shadow-xs hover:bg-neutral-100"
          >
            Test Animation
          </button>
        </div>
      ),
    },
    {
      id: 5,
      title: '5. Add-to-Collection Bottom Sheet',
      category: 'Collection Management',
      description: 'Lightweight slide-up tray immediately following a save action, enabling 1-tap organization into collections or quick creation.',
      uiHighlights: [
        'Checkmark toggling without page reload',
        'Inline "+ Create Collection" with emoji picker',
        'Direct deep link to full favorites hub',
      ],
      specs: {
        padding: '24px top / 16px bottom',
        borderRadius: '32px rounded-t top sheet',
        typography: '16px Bold + 12px Subtitles',
        motion: 'Slide-in from bottom (250ms)',
      },
      componentPreview: (
        <div className="p-4 bg-white rounded-2xl border border-neutral-200 space-y-2">
          <div className="text-xs font-bold text-emerald-600 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4" /> Saved to Favorites!
          </div>
          <div className="flex items-center justify-between p-2 bg-neutral-50 rounded-xl">
            <span className="text-xs font-semibold">📁 Add to Collection...</span>
            <button
              onClick={() => openSmartSaveBottomSheet(sampleProduct.id)}
              className="text-xs font-bold text-blue-600 hover:underline"
            >
              Open Sheet
            </button>
          </div>
        </div>
      ),
    },
    {
      id: 6,
      title: '6. Create Collection Modal',
      category: 'Collection Management',
      description: 'Full configuration sheet for naming, assigning an emoji icon, writing a description, and picking privacy settings.',
      uiHighlights: [
        'Emoji carousel with 16 popular categories',
        '4-level privacy switch (Private / Followers / Public / Collaborative)',
        'Collaborator handles invite input with token chips',
      ],
      specs: {
        padding: '20px all sides',
        borderRadius: '28px modal shell',
        typography: '18px Header + 14px Input Fields',
        motion: 'Zoom-in fade (200ms)',
      },
      componentPreview: (
        <div className="p-4 bg-white rounded-2xl border border-neutral-200 space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-xl">🧳</span>
            <div className="font-bold text-xs">New Collection: "Goa Beach Outfits"</div>
          </div>
          <div className="flex gap-1 text-[10px] font-bold text-neutral-500">
            <span className="px-2 py-0.5 bg-neutral-100 rounded-md">🔒 Private</span>
            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-md">🤝 Collaborative</span>
          </div>
        </div>
      ),
    },
    {
      id: 7,
      title: '7. Collection Detail View',
      category: 'Collection Management',
      description: 'Dedicated view for any single collection with banner cover, item count, collaborator chips, and bulk management controls.',
      uiHighlights: [
        'Collapsible hero header with custom cover backdrop',
        'Sort by: Date Added, Price Low-to-High, Most Popular',
        'Select & Move items between collections',
      ],
      specs: {
        padding: '24px header / 16px content',
        borderRadius: '24px hero card',
        typography: '24px Title + 13px Metadata',
        motion: 'Parallax header collapse',
      },
      componentPreview: (
        <div className="relative h-28 rounded-2xl overflow-hidden bg-neutral-900 text-white p-3 flex flex-col justify-end">
          <img src={sampleProduct.images[0]} alt="cover" className="absolute inset-0 w-full h-full object-cover opacity-50" />
          <div className="relative z-10">
            <span className="text-lg">👟</span>
            <h4 className="font-bold text-sm">Sneakers & Kicks (8 items)</h4>
          </div>
        </div>
      ),
    },
    {
      id: 8,
      title: '8. Edit Collection Settings',
      category: 'Collection Management',
      description: 'Modal to rename, change cover photography, manage collaborator roles, or archive/delete an existing collection.',
      uiHighlights: [
        'Destructive delete action with safety prompt',
        'Role switcher for collaborators (Owner, Editor, Viewer)',
        'Change privacy from Private to Public in 1 tap',
      ],
      specs: {
        padding: '20px container',
        borderRadius: '24px cards',
        typography: '14px Standard labels',
        motion: 'Spring popup',
      },
      componentPreview: (
        <div className="p-3 bg-neutral-50 rounded-2xl border border-neutral-200 flex items-center justify-between text-xs">
          <div className="font-semibold">Rename / Change Privacy / Delete</div>
          <span className="px-2 py-1 bg-red-100 text-red-700 rounded-lg font-bold">Manage</span>
        </div>
      ),
    },
    {
      id: 9,
      title: '9. Wishlist with Smart Priority',
      category: 'Wishlist & Alerts',
      description: 'Shopping wishlist equipped with automated intelligence that tags items with price changes, stock urgency, and savings totals.',
      uiHighlights: [
        'Total estimated savings summary pill (e.g. ₹2,400 saved)',
        'Smart badges: "Price dropped ↓", "Back in stock", "Almost sold out"',
        'Quick toggle for push notifications on price fluctuations',
      ],
      specs: {
        padding: '16px card spacing',
        borderRadius: '20px item containers',
        typography: '18px Hero Currency + 12px Badge labels',
        motion: 'Badge pulse on price decrease',
      },
      componentPreview: (
        <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-1.5">
          <div className="flex items-center justify-between text-xs font-bold text-emerald-900">
            <span>✨ Smart Wishlist Watch</span>
            <span>₹800 Saved Today</span>
          </div>
          <div className="p-2 bg-white rounded-xl border border-emerald-100 text-xs flex items-center justify-between">
            <div>
              <span className="px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded-md text-[10px] font-bold">
                ↓ ₹500 Price Drop
              </span>
              <div className="font-bold mt-1">Linen Kurta (₹1,999)</div>
            </div>
            <Bell className="w-4 h-4 text-emerald-600 fill-emerald-600" />
          </div>
        </div>
      ),
    },
    {
      id: 10,
      title: '10. Price-Drop Alert State',
      category: 'Wishlist & Alerts',
      description: 'High-visibility notification and card state showing original price, current discounted price, and amount saved.',
      uiHighlights: [
        'Green highlight border and trending-down icon',
        'Strike-through original MSRP comparison',
        'Instant "Grab at Discount" CTA',
      ],
      specs: {
        padding: '12px card padding',
        borderRadius: '16px corner rounding',
        typography: 'High contrast emerald colors',
        motion: 'Subtle glow cycle',
      },
      componentPreview: (
        <div className="p-3 bg-white rounded-2xl border-2 border-emerald-500 shadow-xs space-y-1">
          <div className="flex items-center gap-1 text-emerald-700 text-xs font-bold">
            <TrendingDown className="w-4 h-4" /> Price Dropped by ₹500!
          </div>
          <div className="text-xs text-neutral-600">
            Now <span className="font-extrabold text-neutral-900">₹1,999</span> (was ₹2,499)
          </div>
        </div>
      ),
    },
    {
      id: 11,
      title: '11. Back-in-Stock Alert State',
      category: 'Wishlist & Alerts',
      description: 'Instant stock replenishment notification alerting shoppers when previously out-of-stock sizes or colors return.',
      uiHighlights: [
        'Blue stock badge with inventory counter',
        'Direct 1-tap fast checkout trigger',
        'Auto-clearing alert state upon purchase',
      ],
      specs: {
        padding: '12px container',
        borderRadius: '16px rounded borders',
        typography: '13px Bold Alert Text',
        motion: 'Bounce in badge',
      },
      componentPreview: (
        <div className="p-3 bg-blue-50 border border-blue-200 rounded-2xl text-xs space-y-1">
          <span className="font-bold text-blue-900">🎉 Back in Stock (120 units available)</span>
          <p className="text-blue-700 text-[11px]">Size L in Obsidian Black is ready to ship.</p>
        </div>
      ),
    },
    {
      id: 12,
      title: '12. Shared Collection Preview',
      category: 'Social & Collaborative',
      description: 'Public or private web preview card designed for instant link opening across Instagram DMs, WhatsApp, and social feeds.',
      uiHighlights: [
        'Curator attribution banner with avatar and follow button',
        'Curated count and verified products checkmark',
        '"Save Entire Collection to My Favorites" 1-click clone CTA',
      ],
      specs: {
        padding: '16px outer / 12px inner',
        borderRadius: '24px responsive shell',
        typography: '16px Title + 12px Curator',
        motion: 'Card flip preview',
      },
      componentPreview: (
        <div className="p-3 bg-neutral-900 text-white rounded-2xl space-y-2">
          <div className="flex items-center gap-2">
            <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100" alt="avatar" className="w-7 h-7 rounded-full border border-white" />
            <div className="text-xs">
              <span className="font-bold">Priya Mehta</span> shared "Summer Picks"
            </div>
          </div>
          <button className="w-full py-1.5 bg-white text-neutral-900 rounded-xl text-xs font-bold">
            Clone to My Favorites
          </button>
        </div>
      ),
    },
    {
      id: 13,
      title: '13. Collaborative Board with Votes & Comments',
      category: 'Social & Collaborative',
      description: 'Shared shopping workspace where groups of friends vote on products using 👍, ❤️, 🔥 and leave real-time shopping notes.',
      uiHighlights: [
        'Multi-avatar header with online status indicators',
        'Live reaction counters with instant visual updates',
        'Collapsible product-specific comment thread',
      ],
      specs: {
        padding: '16px container spacing',
        borderRadius: '24px card rounding',
        typography: '14px Chat Notes + 12px Member tags',
        motion: 'Spring reaction pop (150ms)',
      },
      componentPreview: (
        <div className="p-3 bg-white rounded-2xl border border-neutral-200 space-y-2 text-xs">
          <div className="flex items-center justify-between font-bold">
            <span>Goa Trip Wardrobe (3 Friends)</span>
            <span className="text-emerald-600">👍 4 • ❤️ 3 • 🔥 3</span>
          </div>
          <div className="p-2 bg-neutral-50 rounded-xl text-[11px] text-neutral-700">
            <span className="font-bold">Rahul:</span> Adding size L for beach night!
          </div>
        </div>
      ),
    },
    {
      id: 14,
      title: '14. Public Collection View',
      category: 'Social & Collaborative',
      description: 'Community-discoverable collection index allowing users to explore top trending lists curated by other stylish shoppers.',
      uiHighlights: [
        'Social bookmark counters ("84 people saved this list")',
        'Category tagging (Streetwear, Minimalist, Traditional)',
        'Direct follow creator profile action',
      ],
      specs: {
        padding: '16px grid gap',
        borderRadius: '20px cards',
        typography: '16px Display + 12px Social tags',
        motion: 'Masonry fade-in',
      },
      componentPreview: (
        <div className="p-3 bg-neutral-50 rounded-2xl border border-neutral-200 space-y-1.5 text-xs">
          <div className="flex items-center gap-1 text-blue-600 font-bold">
            <Globe className="w-3.5 h-3.5" /> Public Discovery • 84 Saves
          </div>
          <div className="font-bold text-neutral-900">Top 10 Indian Streetwear Essentials</div>
        </div>
      ),
    },
    {
      id: 15,
      title: '15. Creator Curated Collection',
      category: 'Social & Collaborative',
      description: 'Verified creator storefront showcase with verified creator badge, total follower count, and bespoke editorial notes.',
      uiHighlights: [
        'Golden / Blue verification badge next to creator name',
        'Editorial quotes & styling advice per item',
        'Affiliate / Ambassador collaboration markers',
      ],
      specs: {
        padding: '20px container',
        borderRadius: '24px premium border',
        typography: '20px Editorial Header + 13px Quote',
        motion: 'Smooth scale-up on hover',
      },
      componentPreview: (
        <div className="p-3 bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl border border-amber-200 text-xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="font-bold text-amber-900">⭐ Creator Pick • Kabir Malhotra</span>
            <span className="text-[10px] bg-amber-200 text-amber-900 px-2 py-0.5 rounded-full font-bold">280K Fans</span>
          </div>
          <p className="text-amber-800 text-[11px]">"My under ₹1,000 secret luxury sneaker drops."</p>
        </div>
      ),
    },
    {
      id: 16,
      title: '16. Social Saved-Product Discovery',
      category: 'Social & Collaborative',
      description: 'Social trust proof indicators displaying "Rahul and 12 others saved this product" to drive organic discovery.',
      uiHighlights: [
        'Friend avatar stacks on product thumbnails',
        'Trending in your city / friends network markers',
        'Clickable social proof expanding list of friends who saved it',
      ],
      specs: {
        padding: '8px pill container',
        borderRadius: '9999px full pill',
        typography: '11px Medium Social Proof',
        motion: 'Avatar overlap cascade',
      },
      componentPreview: (
        <div className="flex items-center gap-2 p-2 bg-neutral-50 rounded-full border border-neutral-200 text-xs">
          <div className="flex -space-x-1.5">
            <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80" alt="u1" className="w-5 h-5 rounded-full border border-white" />
            <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=80" alt="u2" className="w-5 h-5 rounded-full border border-white" />
          </div>
          <span className="text-neutral-700 font-medium">Rahul and 12 friends saved this</span>
        </div>
      ),
    },
    {
      id: 17,
      title: '17. Product 3-Dot Context Menu',
      category: 'Core Flow',
      description: 'Fast contextual action sheet on any saved item offering View, Move, Share, Add to Cart, Buy Now, and Price Tracking.',
      uiHighlights: [
        'Clean vertical icon list with high visual affordance',
        'Direct switch for price-drop notifications',
        'Red destructive action for removing saved item',
      ],
      specs: {
        padding: '16px sheet',
        borderRadius: '28px bottom sheet',
        typography: '14px SemiBold actions',
        motion: 'Bottom slide in',
      },
      componentPreview: (
        <div className="p-3 bg-white rounded-2xl border border-neutral-200 space-y-1 text-xs font-medium">
          <div className="p-1.5 hover:bg-neutral-50 rounded-lg">👁️ View Details</div>
          <div className="p-1.5 hover:bg-neutral-50 rounded-lg">📁 Move to Collection...</div>
          <div className="p-1.5 hover:bg-neutral-50 rounded-lg">🛒 Add to Cart / Buy Now</div>
        </div>
      ),
    },
    {
      id: 18,
      title: '18. Empty Favorites State',
      category: 'Empty States & Edge Cases',
      description: 'Delightful empty state with inspirational visual iconography, zero clutter, and high-conversion "Explore Trending Products" CTA.',
      uiHighlights: [
        'Clean off-white illustration container',
        'Encouraging copywriting explaining how saving works',
        'Direct buttons to Explore Feed or Trending Kurtas',
      ],
      specs: {
        padding: '32px central hero',
        borderRadius: '32px container',
        typography: '18px Bold Heading + 14px Explanation',
        motion: 'Fade-in entering animation',
      },
      componentPreview: (
        <div className="p-6 bg-white rounded-2xl border border-neutral-200 text-center space-y-2">
          <div className="w-12 h-12 rounded-full bg-red-50 text-red-500 mx-auto flex items-center justify-center text-xl">
            ❤️
          </div>
          <div className="font-bold text-xs">No favorites saved yet</div>
          <p className="text-[11px] text-neutral-500">Tap the heart icon on any product or reel to save it here.</p>
        </div>
      ),
    },
    {
      id: 19,
      title: '19. Empty Wishlist State',
      category: 'Empty States & Edge Cases',
      description: 'Clean empty wishlist state explaining automated price drop tracking and back-in-stock alerts.',
      uiHighlights: [
        'Highlighting the price drop tracking benefits',
        'Quick button to add trending items to wishlist',
      ],
      specs: {
        padding: '32px padding',
        borderRadius: '28px container',
        typography: '18px Title',
        motion: 'Fade-in',
      },
      componentPreview: (
        <div className="p-6 bg-white rounded-2xl border border-neutral-200 text-center space-y-2">
          <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 mx-auto flex items-center justify-center text-xl">
            ✨
          </div>
          <div className="font-bold text-xs">Your Wishlist is Ready</div>
          <p className="text-[11px] text-neutral-500">Track price drops and restock alerts on products you love.</p>
        </div>
      ),
    },
    {
      id: 20,
      title: '20. Empty Collections State',
      category: 'Empty States & Edge Cases',
      description: 'Friendly invitation to organize saved items into custom thematic boards like "Vacation", "Sneakers", or "Gifts".',
      uiHighlights: [
        'One-click template creation buttons (Vacation, Gifts, Outfits)',
        'Zero intimidating forms',
      ],
      specs: {
        padding: '28px center',
        borderRadius: '28px card',
        typography: '16px Title',
        motion: 'Smooth scale',
      },
      componentPreview: (
        <div className="p-6 bg-white rounded-2xl border border-neutral-200 text-center space-y-2">
          <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-600 mx-auto flex items-center justify-center text-xl">
            📁
          </div>
          <div className="font-bold text-xs">Create your first collection</div>
          <p className="text-[11px] text-neutral-500">Group your favorite fits, sneakers, and room ideas.</p>
        </div>
      ),
    },
    {
      id: 21,
      title: '21. Collection Sharing Sheet & QR',
      category: 'Social & Collaborative',
      description: 'Comprehensive sharing sheet featuring copy link, WhatsApp, Direct Chat, Story/Feed, and high-density QR code.',
      uiHighlights: [
        'Instant copy-to-clipboard feedback pill',
        'Scannable QR code generator for in-person sharing',
        'Direct WhatsApp and Instagram DM integration',
      ],
      specs: {
        padding: '24px container',
        borderRadius: '32px sheet',
        typography: '14px Bold channels',
        motion: 'Slide up',
      },
      componentPreview: (
        <div className="p-3 bg-neutral-50 rounded-2xl border border-neutral-200 space-y-2 text-xs">
          <div className="flex items-center justify-between font-bold">
            <span>Share Collection Link</span>
            <span className="text-blue-600">Copy URL</span>
          </div>
          <div className="flex gap-2">
            <span className="px-3 py-1 bg-emerald-500 text-white rounded-lg font-bold">WhatsApp</span>
            <span className="px-3 py-1 bg-blue-600 text-white rounded-lg font-bold">Direct Chat</span>
            <span className="px-3 py-1 bg-neutral-900 text-white rounded-lg font-bold">QR Code</span>
          </div>
        </div>
      ),
    },
    {
      id: 22,
      title: '22. Collection Privacy Settings',
      category: 'Collection Management',
      description: 'Granular privacy and access management switcher toggling between Private, Followers-only, Public, and Collaborative.',
      uiHighlights: [
        'Interactive toggle chips with icon representation',
        'Clear plain-English explanations of who can view/edit',
        'Collaborator invitation manager',
      ],
      specs: {
        padding: '16px card spacing',
        borderRadius: '20px selector pills',
        typography: '14px Bold + 12px Subtitles',
        motion: 'Border active transition (200ms)',
      },
      componentPreview: (
        <div className="p-3 bg-white rounded-2xl border border-neutral-200 space-y-1.5 text-xs">
          <div className="font-bold">Privacy Selector</div>
          <div className="grid grid-cols-2 gap-1.5 text-[11px]">
            <div className="p-2 bg-neutral-900 text-white rounded-xl font-bold">🔒 Private</div>
            <div className="p-2 bg-neutral-100 rounded-xl font-semibold">👥 Followers</div>
            <div className="p-2 bg-neutral-100 rounded-xl font-semibold">🌐 Public</div>
            <div className="p-2 bg-emerald-100 text-emerald-900 rounded-xl font-bold">🤝 Collaborative</div>
          </div>
        </div>
      ),
    },
  ];

  const currentScreen = figmaScreens.find((s) => s.id === selectedScreenId) || figmaScreens[0];

  return (
    <div className="space-y-6">
      {/* Banner info */}
      <div className="bg-gradient-to-r from-neutral-900 via-neutral-800 to-neutral-900 text-white rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-xs font-semibold text-amber-300">
              <Sparkles className="w-3.5 h-3.5" />
              <span>22 High-Fidelity UI Screens & Component Specs</span>
            </div>
            <h2 className="text-xl font-extrabold tracking-tight">
              Figma Design System & Interaction Explorer
            </h2>
            <p className="text-xs text-neutral-300 max-w-xl">
              Every requested screen, interaction state, motion curve, and responsive variation is engineered with white-first typography and zero slop.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-white/10 p-1.5 rounded-2xl backdrop-blur-md self-start sm:self-auto">
            <button
              onClick={() => setDeviceFrame('mobile')}
              className={`p-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition ${
                deviceFrame === 'mobile' ? 'bg-white text-neutral-900 shadow-xs' : 'text-white/70 hover:text-white'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span className="hidden sm:inline">Mobile</span>
            </button>
            <button
              onClick={() => setDeviceFrame('tablet')}
              className={`p-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition ${
                deviceFrame === 'tablet' ? 'bg-white text-neutral-900 shadow-xs' : 'text-white/70 hover:text-white'
              }`}
            >
              <Tablet className="w-4 h-4" />
              <span className="hidden sm:inline">Tablet</span>
            </button>
            <button
              onClick={() => setDeviceFrame('desktop')}
              className={`p-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition ${
                deviceFrame === 'desktop' ? 'bg-white text-neutral-900 shadow-xs' : 'text-white/70 hover:text-white'
              }`}
            >
              <Monitor className="w-4 h-4" />
              <span className="hidden sm:inline">Desktop</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Screen Selector Sidebar + Interactive Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: 22 Screens List */}
        <div className="lg:col-span-4 bg-white rounded-3xl p-4 border border-neutral-100 shadow-xs space-y-2 max-h-[680px] overflow-y-auto">
          <div className="flex items-center justify-between pb-2 border-b border-neutral-100">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">
              Screen Catalog (22 Specs)
            </span>
            <span className="text-xs font-semibold text-neutral-900 bg-neutral-100 px-2 py-0.5 rounded-full">
              {figmaScreens.length} Total
            </span>
          </div>

          <div className="space-y-1.5">
            {figmaScreens.map((screen) => {
              const isSelected = screen.id === selectedScreenId;
              return (
                <button
                  key={screen.id}
                  onClick={() => setSelectedScreenId(screen.id)}
                  className={`w-full text-left p-3 rounded-2xl transition flex items-center justify-between border ${
                    isSelected
                      ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
                      : 'bg-neutral-50 hover:bg-neutral-100 text-neutral-800 border-transparent'
                  }`}
                >
                  <div className="min-w-0 pr-2">
                    <div className={`text-xs font-bold truncate ${isSelected ? 'text-white' : 'text-neutral-900'}`}>
                      {screen.title}
                    </div>
                    <div className={`text-[11px] truncate ${isSelected ? 'text-neutral-400' : 'text-neutral-500'}`}>
                      {screen.category}
                    </div>
                  </div>
                  <ChevronRight className={`w-4 h-4 shrink-0 ${isSelected ? 'text-white' : 'text-neutral-400'}`} />
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Screen Detail Showcase & Live Interactive Simulator */}
        <div className="lg:col-span-8 bg-white rounded-3xl p-6 border border-neutral-100 shadow-xs space-y-6">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-neutral-100">
            <div>
              <span className="px-2.5 py-0.5 bg-neutral-100 text-neutral-700 rounded-full text-xs font-semibold">
                {currentScreen.category}
              </span>
              <h3 className="text-lg font-bold text-neutral-900 mt-1">
                {currentScreen.title}
              </h3>
              <p className="text-xs text-neutral-500 mt-0.5">
                {currentScreen.description}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  if (currentScreen.id === 9 || currentScreen.id === 10 || currentScreen.id === 11) {
                    setActiveFavoritesTab('wishlist');
                  } else if (currentScreen.id === 6 || currentScreen.id === 7 || currentScreen.id === 8) {
                    setActiveFavoritesTab('collections');
                  } else if (currentScreen.id === 13) {
                    setActiveFavoritesTab('collaborative');
                  } else if (currentScreen.id === 15) {
                    setActiveFavoritesTab('creators');
                  } else {
                    setActiveFavoritesTab('products');
                  }
                }}
                className="px-4 py-2 bg-neutral-900 text-white rounded-xl text-xs font-semibold hover:bg-slate-100 transition flex items-center gap-1.5 shadow-xs"
              >
                <span>Jump to Live Hub View</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Interactive Frame Simulator */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" /> Live Render Preview ({deviceFrame.toUpperCase()})
              </span>
            </div>

            <div
              className={`mx-auto bg-neutral-100 rounded-3xl p-4 sm:p-6 border-4 border-neutral-200 transition-all ${
                deviceFrame === 'mobile'
                  ? 'max-w-sm'
                  : deviceFrame === 'tablet'
                  ? 'max-w-xl'
                  : 'max-w-full'
              }`}
            >
              {currentScreen.componentPreview}
            </div>
          </div>

          {/* Design System & Interaction Specs */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            {/* UI Highlights */}
            <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-100 space-y-2">
              <span className="text-xs font-bold text-neutral-900 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                UI & UX Patterns
              </span>
              <ul className="space-y-1.5 text-xs text-neutral-700">
                {currentScreen.uiHighlights.map((hl, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-neutral-900 mt-1.5 shrink-0" />
                    <span>{hl}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Token & Motion Specs */}
            <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-100 space-y-2">
              <span className="text-xs font-bold text-neutral-900 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-blue-500" />
                Figma Design Tokens
              </span>
              <div className="space-y-1 text-xs text-neutral-700">
                <div>
                  <span className="font-semibold text-neutral-900">Padding Math:</span> {currentScreen.specs.padding}
                </div>
                <div>
                  <span className="font-semibold text-neutral-900">Corner Radius:</span> {currentScreen.specs.borderRadius}
                </div>
                <div>
                  <span className="font-semibold text-neutral-900">Type Scale:</span> {currentScreen.specs.typography}
                </div>
                <div>
                  <span className="font-semibold text-neutral-900">Easing & Physics:</span> {currentScreen.specs.motion}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
