import React, { useState, useEffect } from 'react';
import { ProductCollection, CollectionPrivacy } from '../../types';
import { useApp } from '../../context/AppContext';
import {
  X,
  Lock,
  Globe,
  Users,
  UserPlus,
  Sparkles,
  Check,
  Trash2,
} from 'lucide-react';

interface CreateOrEditCollectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  collectionToEdit?: ProductCollection | null;
  initialProductId?: string;
}

export const CreateOrEditCollectionModal: React.FC<CreateOrEditCollectionModalProps> = ({
  isOpen,
  onClose,
  collectionToEdit,
  initialProductId,
}) => {
  const {
    createCustomCollection,
    updateCollection,
    deleteCollection,
    products,
  } = useApp();

  const isEditing = Boolean(collectionToEdit);

  const [name, setName] = useState('');
  const [emoji, setEmoji] = useState('📁');
  const [description, setDescription] = useState('');
  const [privacy, setPrivacy] = useState<CollectionPrivacy>('private');
  const [invitedHandle, setInvitedHandle] = useState('');
  const [collaboratorsList, setCollaboratorsList] = useState<string[]>([
    'Rahul Varma (@rahul_v)',
    'Ananya Roy (@ananya_r)',
  ]);

  const popularEmojis = [
    '❤️', '👟', '👕', '🏠', '🎁', '🔥', '🧳', '✨', '👜', '💍', '🎧', '🪴', '🕶️', '🏖️', '☕', '💡'
  ];

  useEffect(() => {
    if (collectionToEdit) {
      setName(collectionToEdit.name);
      setEmoji(collectionToEdit.emoji || '📁');
      setDescription(collectionToEdit.description || '');
      setPrivacy(collectionToEdit.privacy);
    } else {
      setName('');
      setEmoji('📁');
      setDescription('');
      setPrivacy('private');
    }
  }, [collectionToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (isEditing && collectionToEdit) {
      updateCollection(collectionToEdit.id, {
        name: name.trim(),
        emoji,
        description: description.trim(),
        privacy,
      });
    } else {
      createCustomCollection(
        name.trim(),
        emoji,
        description.trim(),
        privacy,
        initialProductId ? [initialProductId] : []
      );
    }

    onClose();
  };

  const handleAddCollaborator = () => {
    if (!invitedHandle.trim()) return;
    setCollaboratorsList((prev) => [...prev, invitedHandle.trim()]);
    setInvitedHandle('');
  };

  const handleRemoveCollaborator = (index: number) => {
    setCollaboratorsList((prev) => prev.filter((_, i) => i !== index));
  };

  const handleDelete = () => {
    if (collectionToEdit) {
      deleteCollection(collectionToEdit.id);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-100/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden border border-neutral-100 flex flex-col z-10 animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-5 border-b border-neutral-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-neutral-100 flex items-center justify-center text-xl shadow-inner">
              {emoji}
            </div>
            <div>
              <h3 className="font-bold text-neutral-900 text-base">
                {isEditing ? 'Edit Collection' : 'Create New Collection'}
              </h3>
              <p className="text-xs text-neutral-500">
                Organize and curate your favorite products & looks
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-neutral-100 text-neutral-400 hover:text-neutral-700 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto max-h-[75vh]">
          {/* Collection Name */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-neutral-500 mb-1.5">
              Collection Name *
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Summer Resort Wardrobe"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2.5 bg-neutral-50 rounded-2xl border border-neutral-200 text-sm focus:outline-hidden focus:border-neutral-900 focus:bg-white transition"
            />
          </div>

          {/* Emoji Picker */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-neutral-500 mb-1.5">
              Choose Icon / Emoji
            </label>
            <div className="flex flex-wrap gap-2 p-2 bg-neutral-50 rounded-2xl border border-neutral-100 max-h-24 overflow-y-auto">
              {popularEmojis.map((em) => (
                <button
                  key={em}
                  type="button"
                  onClick={() => setEmoji(em)}
                  className={`text-lg p-2 rounded-xl transition ${
                    emoji === em
                      ? 'bg-white shadow-xs border border-neutral-300 scale-110'
                      : 'hover:bg-white/60 opacity-80 hover:opacity-100'
                  }`}
                >
                  {em}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-neutral-500 mb-1.5">
              Description (Optional)
            </label>
            <textarea
              rows={2}
              placeholder="What is this collection about? (e.g. Vacation shopping inspo)"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-4 py-2.5 bg-neutral-50 rounded-2xl border border-neutral-200 text-sm focus:outline-hidden focus:border-neutral-900 focus:bg-white transition resize-none"
            />
          </div>

          {/* Privacy Level Settings */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-neutral-500 mb-2">
              Privacy & Sharing Settings
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {/* Private */}
              <button
                type="button"
                onClick={() => setPrivacy('private')}
                className={`flex items-start gap-3 p-3 rounded-2xl border text-left transition ${
                  privacy === 'private'
                    ? 'border-neutral-900 bg-neutral-900 text-white shadow-xs'
                    : 'border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-800'
                }`}
              >
                <Lock className={`w-4 h-4 mt-0.5 ${privacy === 'private' ? 'text-white' : 'text-neutral-500'}`} />
                <div>
                  <div className="text-xs font-bold">Private (Only You)</div>
                  <div className={`text-[11px] ${privacy === 'private' ? 'text-neutral-300' : 'text-neutral-500'}`}>
                    Only you can view and edit
                  </div>
                </div>
              </button>

              {/* Followers */}
              <button
                type="button"
                onClick={() => setPrivacy('followers')}
                className={`flex items-start gap-3 p-3 rounded-2xl border text-left transition ${
                  privacy === 'followers'
                    ? 'border-neutral-900 bg-neutral-900 text-white shadow-xs'
                    : 'border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-800'
                }`}
              >
                <Users className={`w-4 h-4 mt-0.5 ${privacy === 'followers' ? 'text-white' : 'text-neutral-500'}`} />
                <div>
                  <div className="text-xs font-bold">Followers Only</div>
                  <div className={`text-[11px] ${privacy === 'followers' ? 'text-neutral-300' : 'text-neutral-500'}`}>
                    Visible on your profile to followers
                  </div>
                </div>
              </button>

              {/* Public */}
              <button
                type="button"
                onClick={() => setPrivacy('public')}
                className={`flex items-start gap-3 p-3 rounded-2xl border text-left transition ${
                  privacy === 'public'
                    ? 'border-neutral-900 bg-neutral-900 text-white shadow-xs'
                    : 'border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-800'
                }`}
              >
                <Globe className={`w-4 h-4 mt-0.5 ${privacy === 'public' ? 'text-blue-300' : 'text-blue-600'}`} />
                <div>
                  <div className="text-xs font-bold">Public (Discoverable)</div>
                  <div className={`text-[11px] ${privacy === 'public' ? 'text-neutral-300' : 'text-neutral-500'}`}>
                    Shown in Explore & Creator feeds
                  </div>
                </div>
              </button>

              {/* Collaborative */}
              <button
                type="button"
                onClick={() => setPrivacy('collaborative')}
                className={`flex items-start gap-3 p-3 rounded-2xl border text-left transition ${
                  privacy === 'collaborative'
                    ? 'border-neutral-900 bg-neutral-900 text-white shadow-xs'
                    : 'border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-800'
                }`}
              >
                <Sparkles className={`w-4 h-4 mt-0.5 ${privacy === 'collaborative' ? 'text-emerald-300' : 'text-emerald-600'}`} />
                <div>
                  <div className="text-xs font-bold">Collaborative Board</div>
                  <div className={`text-[11px] ${privacy === 'collaborative' ? 'text-neutral-300' : 'text-neutral-500'}`}>
                    Invite friends to co-add & vote
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* Collaborator management if collaborative */}
          {privacy === 'collaborative' && (
            <div className="p-3 bg-emerald-50/60 rounded-2xl border border-emerald-200/80 space-y-3 animate-in fade-in">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-900 flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-emerald-700" />
                  Invite Collaborators
                </span>
                <span className="text-[11px] text-emerald-700">
                  {collaboratorsList.length} invited
                </span>
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="@friend_handle or mobile"
                  value={invitedHandle}
                  onChange={(e) => setInvitedHandle(e.target.value)}
                  className="flex-1 px-3 py-2 text-xs bg-white rounded-xl border border-emerald-300 focus:outline-hidden focus:border-emerald-600"
                />
                <button
                  type="button"
                  onClick={handleAddCollaborator}
                  disabled={!invitedHandle.trim()}
                  className="px-3 py-2 bg-emerald-700 text-white rounded-xl text-xs font-semibold hover:bg-emerald-800 transition flex items-center gap-1"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  Invite
                </button>
              </div>

              <div className="flex flex-wrap gap-1.5">
                {collaboratorsList.map((handle, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-emerald-900 border border-emerald-200 rounded-full text-xs font-medium"
                  >
                    <span>{handle}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveCollaborator(idx)}
                      className="hover:text-red-500 ml-1"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="pt-3 border-t border-neutral-100 flex items-center justify-between gap-3">
            {isEditing && collectionToEdit?.id !== 'col-favorites' ? (
              <button
                type="button"
                onClick={handleDelete}
                className="px-4 py-2.5 text-xs font-semibold text-red-600 hover:bg-red-50 rounded-xl transition flex items-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                Delete
              </button>
            ) : (
              <div />
            )}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 text-xs font-semibold text-neutral-600 hover:bg-neutral-100 rounded-xl transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!name.trim()}
                className="px-6 py-2.5 bg-neutral-900 disabled:bg-neutral-300 text-white text-xs font-semibold rounded-xl hover:bg-slate-100 transition shadow-xs flex items-center gap-1.5"
              >
                <Check className="w-4 h-4 stroke-[2.5]" />
                {isEditing ? 'Save Changes' : 'Create Collection'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
