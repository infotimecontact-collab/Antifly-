import React from 'react';
import { useApp } from '../../context/AppContext';
import { Sparkles, Heart } from 'lucide-react';

export const FavoritesFlyingAnimation: React.FC = () => {
  const { flyingSaveAnimation } = useApp();

  if (!flyingSaveAnimation.isActive) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {/* Flying Card Asset */}
      <div
        className="absolute w-20 h-20 rounded-2xl overflow-hidden shadow-2xl border-2 border-white bg-white animate-snapchat-fly"
        style={{
          left: `${flyingSaveAnimation.startX ?? 200}px`,
          top: `${flyingSaveAnimation.startY ?? 300}px`,
          transform: 'translate(-50%, -50%)',
        }}
      >
        <img
          src={flyingSaveAnimation.imageUrl}
          alt={flyingSaveAnimation.productName}
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-red-600/60 to-transparent flex items-end justify-center pb-1">
          <Heart className="w-5 h-5 fill-white text-white animate-ping" />
        </div>
      </div>

      {/* Floating Sparkles & Particles */}
      <div
        className="absolute animate-snapchat-sparkle-1"
        style={{
          left: `${(flyingSaveAnimation.startX ?? 200) - 30}px`,
          top: `${(flyingSaveAnimation.startY ?? 300) - 20}px`,
        }}
      >
        <div className="p-1.5 bg-amber-400 rounded-full text-white shadow-lg">
          <Sparkles className="w-3.5 h-3.5" />
        </div>
      </div>

      <div
        className="absolute animate-snapchat-sparkle-2"
        style={{
          left: `${(flyingSaveAnimation.startX ?? 200) + 35}px`,
          top: `${(flyingSaveAnimation.startY ?? 300) + 20}px`,
        }}
      >
        <div className="p-1 bg-red-500 rounded-full text-white shadow-lg">
          <Heart className="w-3 h-3 fill-white" />
        </div>
      </div>
    </div>
  );
};
