import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Check,
  Plus,
  X,
  Lock,
  Globe,
  Users,
  ExternalLink,
  FolderHeart,
  Sparkles,
} from 'lucide-react';

export const SmartSaveBottomSheet: React.FC = () => {
  const {
    smartSaveBottomSheet,
    closeSmartSaveBottomSheet,
    userCollections,
    addProductToCollection,
    removeProductFromCollection,
    createCustomCollection,
    setIsFavoritesHubOpen,
    setActiveFavoritesTab,
  } = useApp();

  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [newCollectionName, setNewCollectionName] = useState('');
  const [selectedEmoji, setSelectedEmoji] = useState('📁');

  if (!smartSaveBottomSheet.isOpen || !smartSaveBottomSheet.productId) {
    return null;
  }

  const { product, productId } = smartSaveBottomSheet;
  const popularEmojis = ['❤️', '👟', '👕', '🏠', '🎁', '🔥', '🧳', '✨', '👜', '💍', '🎧'];

  const handleToggleCollection = (colId: string) => {
    const targetCol = userCollections.find((c) => c.id === colId);
    if (!targetCol) return;

    if (targetCol.itemProductIds.includes(productId)) {
      removeProductFromCollection(colId, productId);
    } else {
      addProductToCollection(colId, productId);
    }
  };

  const handleCreateAndAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCollectionName.trim()) return;

    const newCol = createCustomCollection(
      newCollectionName.trim(),
      selectedEmoji,
      'Created via Smart Save',
      'private',
      [productId]
    );

    setNewCollectionName('');
    setIsCreatingNew(false);
  };

  const handleOpenFavorites = () => {
    closeSmartSaveBottomSheet();
    setActiveFavoritesTab('products');
    setIsFavoritesHubOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-100/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200">
      {/* Backdrop click */}
      <div
        className="fixed inset-0"
        onClick={closeSmartSaveBottomSheet}
      />

      {/* Sheet Container */}
      <div className="relative w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden border border-neutral-100 flex flex-col max-h-[85vh] z-10 animate-in slide-in-from-bottom duration-300">
        {/* Drag handle */}
        <div className="flex justify-center pt-3 pb-1 sm:hidden">
          <div className="w-12 h-1.5 bg-neutral-200 rounded-full" />
        </div>

        {/* Header */}
        <div className="p-4 border-b border-neutral-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {product?.images?.[0] ? (
              <img
                src={product.images[0]}
                alt={product.name}
                className="w-12 h-12 rounded-xl object-cover border border-neutral-100 shadow-xs"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-12 h-12 rounded-xl bg-red-50 text-red-600 flex items-center justify-center font-bold">
                <FolderHeart className="w-6 h-6" />
              </div>
            )}
            <div className="max-w-[200px] sm:max-w-[260px]">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-600">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                Saved to Favorites
              </div>
              <h3 className="font-semibold text-neutral-900 text-sm truncate">
                {product?.name || 'Product'}
              </h3>
              <p className="text-xs text-neutral-500">
                ₹{(product?.price ?? 1499).toLocaleString('en-IN')} • Tap to organize
              </p>
            </div>
          </div>

          <button
            onClick={closeSmartSaveBottomSheet}
            className="p-2 rounded-full hover:bg-neutral-100 text-neutral-400 hover:text-neutral-700 transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Collections Picker List */}
        <div className="p-4 overflow-y-auto flex-1 space-y-2 divide-y divide-neutral-50">
          <div className="flex items-center justify-between pb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">
              Save to Collections
            </span>
            <span className="text-xs text-neutral-400">
              {userCollections.length} available
            </span>
          </div>

          <div className="pt-2 space-y-1.5">
            {userCollections.map((col) => {
              const isIncluded = col.itemProductIds.includes(productId);
              return (
                <button
                  key={col.id}
                  onClick={() => handleToggleCollection(col.id)}
                  className={`w-full flex items-center justify-between p-3 rounded-2xl transition text-left border ${
                    isIncluded
                      ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
                      : 'bg-neutral-50 hover:bg-neutral-100 text-neutral-800 border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{col.emoji || '📁'}</span>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className={`text-sm font-semibold ${isIncluded ? 'text-white' : 'text-neutral-900'}`}>
                          {col.name}
                        </span>
                        {col.privacy === 'private' && (
                          <Lock className={`w-3 h-3 ${isIncluded ? 'text-neutral-400' : 'text-neutral-400'}`} />
                        )}
                        {col.privacy === 'public' && (
                          <Globe className={`w-3 h-3 ${isIncluded ? 'text-blue-300' : 'text-blue-500'}`} />
                        )}
                        {col.privacy === 'collaborative' && (
                          <Users className={`w-3 h-3 ${isIncluded ? 'text-emerald-300' : 'text-emerald-500'}`} />
                        )}
                      </div>
                      <span className={`text-xs ${isIncluded ? 'text-neutral-300' : 'text-neutral-500'}`}>
                        {col.itemProductIds.length} items
                      </span>
                    </div>
                  </div>

                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center transition ${
                      isIncluded
                        ? 'bg-white text-neutral-900 shadow-xs'
                        : 'border border-neutral-300 text-transparent'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                </button>
              );
            })}
          </div>

          {/* Create new collection inline */}
          <div className="pt-3">
            {!isCreatingNew ? (
              <button
                onClick={() => setIsCreatingNew(true)}
                className="w-full flex items-center justify-center gap-2 p-3 rounded-2xl border-2 border-dashed border-neutral-200 hover:border-neutral-400 hover:bg-neutral-50 text-neutral-700 text-sm font-medium transition"
              >
                <Plus className="w-4 h-4 text-neutral-500" />
                <span>Create New Collection</span>
              </button>
            ) : (
              <form onSubmit={handleCreateAndAdd} className="p-3 bg-neutral-50 rounded-2xl space-y-3 border border-neutral-200">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-neutral-700">New Collection</span>
                  <button
                    type="button"
                    onClick={() => setIsCreatingNew(false)}
                    className="text-xs text-neutral-400 hover:text-neutral-600"
                  >
                    Cancel
                  </button>
                </div>

                {/* Emoji Selector */}
                <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                  {popularEmojis.map((emoji) => (
                    <button
                      key={emoji}
                      type="button"
                      onClick={() => setSelectedEmoji(emoji)}
                      className={`text-lg p-1.5 rounded-xl transition ${
                        selectedEmoji === emoji ? 'bg-white shadow-xs border border-neutral-300 scale-110' : 'opacity-70 hover:opacity-100'
                      }`}
                    >
                      {emoji}
                    </button>
                  ))}
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="e.g. Summer Vacation Fits"
                    value={newCollectionName}
                    onChange={(e) => setNewCollectionName(e.target.value)}
                    autoFocus
                    className="flex-1 px-3 py-2 text-sm bg-white rounded-xl border border-neutral-200 focus:outline-hidden focus:border-neutral-900"
                  />
                  <button
                    type="submit"
                    disabled={!newCollectionName.trim()}
                    className="px-4 py-2 bg-neutral-900 disabled:bg-neutral-300 text-white rounded-xl text-xs font-semibold hover:bg-slate-100 transition flex items-center gap-1 shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Create
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-neutral-50 border-t border-neutral-100 flex items-center justify-between gap-3">
          <button
            onClick={handleOpenFavorites}
            className="flex items-center gap-1.5 text-xs font-medium text-neutral-600 hover:text-neutral-900 transition"
          >
            <FolderHeart className="w-4 h-4 text-red-500" />
            <span>Open Favorites Hub</span>
            <ExternalLink className="w-3 h-3 text-neutral-400" />
          </button>

          <button
            onClick={closeSmartSaveBottomSheet}
            className="px-5 py-2.5 bg-neutral-900 text-white text-xs font-semibold rounded-xl hover:bg-slate-100 transition shadow-xs"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
