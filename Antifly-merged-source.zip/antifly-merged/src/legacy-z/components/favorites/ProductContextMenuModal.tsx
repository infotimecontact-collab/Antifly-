import React from 'react';
import { Product } from '../../types';
import { useApp } from '../../context/AppContext';
import {
  Eye,
  FolderInput,
  Share2,
  ShoppingCart,
  Zap,
  Bell,
  BellOff,
  Trash2,
  X,
  Sparkles,
} from 'lucide-react';

interface ProductContextMenuModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenMoveToCollection?: (product: Product) => void;
  onOpenShare?: (product: Product) => void;
}

export const ProductContextMenuModal: React.FC<ProductContextMenuModalProps> = ({
  product,
  isOpen,
  onClose,
  onOpenMoveToCollection,
  onOpenShare,
}) => {
  const {
    setActivePdpId,
    addToCart,
    buyNow,
    quickSaveProductWithSmartFlow,
    wishlistDetails,
    togglePriceDropAlert,
  } = useApp();

  if (!isOpen || !product) return null;

  const isPriceAlertOn = wishlistDetails[product.id]?.priceDropAlertEnabled ?? false;

  const handleViewProduct = () => {
    onClose();
    setActivePdpId(product.id);
  };

  const handleAddToCart = () => {
    addToCart(product);
    onClose();
  };

  const handleBuyNow = () => {
    onClose();
    buyNow(product);
  };

  const handleTogglePrice = () => {
    togglePriceDropAlert(product.id);
  };

  const handleRemove = () => {
    quickSaveProductWithSmartFlow(product.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-100/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative w-full max-w-sm bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden border border-neutral-100 flex flex-col z-10 animate-in slide-in-from-bottom duration-300">
        {/* Header with preview */}
        <div className="p-4 border-b border-neutral-100 flex items-center gap-3">
          <img
            src={product.images[0]}
            alt={product.name}
            className="w-14 h-14 rounded-2xl object-cover border border-neutral-100 shadow-xs"
            referrerPolicy="no-referrer"
          />
          <div className="flex-1 min-w-0">
            <span className="text-[10px] uppercase font-bold tracking-wider text-neutral-400">
              Quick Actions
            </span>
            <h4 className="font-semibold text-neutral-900 text-sm truncate">{product.name}</h4>
            <p className="text-xs font-bold text-neutral-900">
              ₹{product.price.toLocaleString('en-IN')}{' '}
              {product.mrp && product.mrp > product.price && (
                <span className="text-neutral-400 font-normal line-through ml-1">
                  ₹{product.mrp.toLocaleString('en-IN')}
                </span>
              )}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-neutral-100 text-neutral-400"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Items */}
        <div className="p-2 space-y-1">
          <button
            onClick={handleViewProduct}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-left text-sm font-medium text-neutral-800 hover:bg-neutral-50 transition"
          >
            <Eye className="w-4 h-4 text-neutral-600" />
            <span>View Product Details</span>
          </button>

          {onOpenMoveToCollection && (
            <button
              onClick={() => {
                onClose();
                onOpenMoveToCollection(product);
              }}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-left text-sm font-medium text-neutral-800 hover:bg-neutral-50 transition"
            >
              <FolderInput className="w-4 h-4 text-blue-600" />
              <span>Move to Collection...</span>
            </button>
          )}

          {onOpenShare && (
            <button
              onClick={() => {
                onClose();
                onOpenShare(product);
              }}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-left text-sm font-medium text-neutral-800 hover:bg-neutral-50 transition"
            >
              <Share2 className="w-4 h-4 text-neutral-600" />
              <span>Share with Friends</span>
            </button>
          )}

          <button
            onClick={handleAddToCart}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-left text-sm font-medium text-neutral-800 hover:bg-neutral-50 transition"
          >
            <ShoppingCart className="w-4 h-4 text-emerald-600" />
            <span>Add to Cart</span>
          </button>

          <button
            onClick={handleBuyNow}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-left text-sm font-semibold text-neutral-900 bg-neutral-50 hover:bg-neutral-100 transition"
          >
            <Zap className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span>Buy Now (Express Checkout)</span>
          </button>

          <button
            onClick={handleTogglePrice}
            className="w-full flex items-center justify-between px-4 py-3 rounded-2xl text-left text-sm font-medium text-neutral-800 hover:bg-neutral-50 transition"
          >
            <div className="flex items-center gap-3">
              {isPriceAlertOn ? (
                <Bell className="w-4 h-4 text-amber-500 fill-amber-500" />
              ) : (
                <BellOff className="w-4 h-4 text-neutral-400" />
              )}
              <span>Price Drop Alerts</span>
            </div>
            <span
              className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                isPriceAlertOn
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-neutral-100 text-neutral-500'
              }`}
            >
              {isPriceAlertOn ? 'Active' : 'Off'}
            </span>
          </button>

          <div className="border-t border-neutral-100 my-1" />

          <button
            onClick={handleRemove}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-left text-sm font-medium text-red-600 hover:bg-red-50 transition"
          >
            <Trash2 className="w-4 h-4 text-red-500" />
            <span>Remove from Favorites</span>
          </button>
        </div>
      </div>
    </div>
  );
};
