import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Coins,
  Gem,
  ArrowRight,
  TrendingUp,
  Award,
  Zap,
  CheckCircle2,
  HelpCircle,
  Sparkles,
  RefreshCw,
  Gift,
  ArrowUpRight,
  DollarSign,
  Store,
  Truck,
  CreditCard,
  Percent,
  Calendar,
  Share2,
  ShoppingBag,
  Clock,
  ShieldCheck,
  ChevronRight,
  Calculator,
  Flame,
  Star,
  Users,
  Film,
  Compass,
} from 'lucide-react';

interface CoinsAndDiamondsTrackerProps {
  initialView?: 'both' | 'coins' | 'diamonds';
  compact?: boolean;
  onOpenSuperCoinsModal?: () => void;
}

export const CoinsAndDiamondsTracker: React.FC<CoinsAndDiamondsTrackerProps> = ({
  initialView = 'both',
  compact = false,
  onOpenSuperCoinsModal,
}) => {
  const {
    superCoinsBalance,
    setSuperCoinsBalance,
    superCoinRewards,
    redeemSuperCoinReward,
    superCoinTransactions,
    currentUserSession,
    currentSeller,
    showToast,
    formatPrice,
    setIsSuperCoinsModalOpen,
  } = useApp();

  const [activeView, setActiveView] = useState<'both' | 'coins' | 'diamonds'>(initialView);
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'mechanics' | 'redemptions' | 'calculator' | 'history'>('overview');

  // Seller Diamond Balance simulation & state
  const [sellerDiamonds, setSellerDiamonds] = useState<number>(2450);
  const [isCashoutModalOpen, setIsCashoutModalOpen] = useState<boolean>(false);
  const [cashoutAmount, setCashoutAmount] = useState<number>(1000);
  const [cashoutUPI, setCashoutUPI] = useState<string>('seller.venture@okaxis');
  const [isCashingOut, setIsCashingOut] = useState<boolean>(false);

  // Calculator states
  const [calcCoins, setCalcCoins] = useState<number>(500);
  const [calcDiamonds, setCalcDiamonds] = useState<number>(1000);

  // Streak status
  const [checkInStreak, setCheckInStreak] = useState<number>(4);
  const [hasClaimedToday, setHasClaimedToday] = useState<boolean>(false);

  // User Tier Calculation
  const getCoinsTier = (coins: number) => {
    if (coins >= 10000) return { name: 'Diamond VIP', color: 'from-cyan-500 to-blue-600', next: null, target: 10000, current: coins, badge: '👑 VIP Elite' };
    if (coins >= 5000) return { name: 'Platinum Elite', color: 'from-purple-500 to-indigo-600', next: 'Diamond VIP', target: 10000, current: coins, badge: '💎 Platinum' };
    if (coins >= 1500) return { name: 'Gold Patron', color: 'from-amber-500 to-orange-500', next: 'Platinum Elite', target: 5000, current: coins, badge: '⭐ Gold' };
    if (coins >= 500) return { name: 'Silver Shopper', color: 'from-slate-400 to-slate-600', next: 'Gold Patron', target: 1500, current: coins, badge: '🥈 Silver' };
    return { name: 'Bronze Explorer', color: 'from-amber-700 to-amber-900', next: 'Silver Shopper', target: 500, current: coins, badge: '🥉 Bronze' };
  };

  // Seller Tier Calculation
  const getDiamondsTier = (diamonds: number) => {
    if (diamonds >= 5000) return { name: 'Diamond Sovereign', multiplier: '2.0x Boost', next: null, target: 5000, badge: '👑 Apex Venture' };
    if (diamonds >= 2500) return { name: 'Gold Artisan', multiplier: '1.5x Boost', next: 'Diamond Sovereign', target: 5000, badge: '🏆 Gold Partner' };
    if (diamonds >= 1000) return { name: 'Silver Merchant', multiplier: '1.25x Boost', next: 'Gold Artisan', target: 2500, badge: '🥈 Verified Merchant' };
    return { name: 'Venture Starter', multiplier: '1.0x Base', next: 'Silver Merchant', target: 1000, badge: '🌱 Rising Seller' };
  };

  const userTier = getCoinsTier(superCoinsBalance);
  const sellerTier = getDiamondsTier(sellerDiamonds);

  // Daily Streak Claim
  const handleClaimStreak = () => {
    if (hasClaimedToday) return;
    const bonus = (checkInStreak + 1) * 10;
    setSuperCoinsBalance((prev) => prev + bonus);
    setCheckInStreak((prev) => prev + 1);
    setHasClaimedToday(true);
    showToast(`🎉 Claimed Day ${checkInStreak + 1} Streak Bonus: +${bonus} SuperCoins!`);
  };

  // Seller Diamond Cashout to UPI
  const handleCashoutDiamonds = (e: React.FormEvent) => {
    e.preventDefault();
    if (sellerDiamonds < cashoutAmount) {
      showToast(`⚠️ Insufficient Diamonds. You have ${sellerDiamonds} 💎`);
      return;
    }
    if (cashoutAmount < 200) {
      showToast('⚠️ Minimum cashout is 200 Diamonds (₹100 INR)');
      return;
    }

    setIsCashingOut(true);
    setTimeout(() => {
      setSellerDiamonds((prev) => prev - cashoutAmount);
      setIsCashingOut(false);
      setIsCashoutModalOpen(false);
      const inrValue = Math.round(cashoutAmount * 0.5);
      showToast(`✅ Direct Payout Sent! ₹${inrValue} transferred to ${cashoutUPI} via Instant UPI.`);
    }, 1000);
  };

  // Convert Diamonds to Ad Boost
  const handleConvertDiamondsToAdBoost = () => {
    if (sellerDiamonds < 500) {
      showToast('⚠️ Need at least 500 Diamonds to unlock a Sponsored City Spotlight Boost.');
      return;
    }
    setSellerDiamonds((prev) => prev - 500);
    showToast('🚀 500 Diamonds converted to ₹375 Sponsored Ad Credit (1.5x boost applied to your venture)!');
  };

  return (
    <div
      id="coins-diamonds-tracker-component"
      className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-4 sm:p-6 shadow-sm space-y-6"
    >
      {/* 1. Header & Multi-View Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 via-orange-500 to-cyan-500 flex items-center justify-center text-white shadow-md">
            <Sparkles className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-extrabold text-base sm:text-lg text-slate-900 dark:text-white">
                Rewards & Value Economy Hub
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 font-black text-[10px] border border-amber-500/20">
                100% Real Value
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Live tracking for <strong>Coins</strong> (User Loyalty) and <strong>Diamonds</strong> (Seller Venture Royalty).
            </p>
          </div>
        </div>

        {/* View Switcher Chips */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700/80 self-start sm:self-auto">
          <button
            id="view-both-currencies-btn"
            onClick={() => setActiveView('both')}
            className={`px-3 py-1.5 rounded-xl font-extrabold text-xs transition-all flex items-center gap-1.5 ${
              activeView === 'both'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Dual Overview</span>
          </button>

          <button
            id="view-coins-only-btn"
            onClick={() => setActiveView('coins')}
            className={`px-3 py-1.5 rounded-xl font-extrabold text-xs transition-all flex items-center gap-1.5 ${
              activeView === 'coins'
                ? 'bg-amber-500 text-slate-800 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Coins className="w-3.5 h-3.5" />
            <span>User Coins</span>
          </button>

          <button
            id="view-diamonds-only-btn"
            onClick={() => setActiveView('diamonds')}
            className={`px-3 py-1.5 rounded-xl font-extrabold text-xs transition-all flex items-center gap-1.5 ${
              activeView === 'diamonds'
                ? 'bg-cyan-500 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Gem className="w-3.5 h-3.5" />
            <span>Seller Diamonds</span>
          </button>
        </div>
      </div>

      {/* 2. Visual Metric Cards (Coins vs Diamonds) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* CARD A: USER COINS CARD */}
        {(activeView === 'both' || activeView === 'coins') && (
          <div className="relative overflow-hidden p-5 rounded-3xl bg-gradient-to-br from-amber-500/10 via-orange-500/5 to-transparent border border-amber-500/30 dark:border-amber-500/20 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-2xl bg-amber-500 text-slate-800 flex items-center justify-center shadow-md">
                  <Coins className="w-5 h-5 fill-slate-950" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-black text-sm text-slate-900 dark:text-white">
                      User SuperCoins
                    </h4>
                    <span className="px-2 py-0.2 rounded-md bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-300 font-bold text-[9px]">
                      Customer Loyalty
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Direct conversion: <strong>1 Coin = ₹1.00 INR</strong>
                  </p>
                </div>
              </div>

              <span className="px-2.5 py-1 rounded-full bg-amber-500 text-slate-800 font-black text-xs shadow-xs">
                {userTier.badge}
              </span>
            </div>

            {/* Big Balance & Valuation */}
            <div className="p-4 bg-white/80 dark:bg-slate-900/80 rounded-2xl border border-amber-200 dark:border-amber-900/40 backdrop-blur-xs flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                  Spendable Balance
                </span>
                <div className="flex items-baseline gap-1.5 mt-0.5">
                  <span className="text-2xl sm:text-3xl font-black text-amber-600 dark:text-amber-400">
                    {superCoinsBalance.toLocaleString()}
                  </span>
                  <span className="text-xs font-extrabold text-slate-600 dark:text-slate-300">
                    Coins
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 block">
                  Checkout Offset Value
                </span>
                <span className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                  ₹{superCoinsBalance}.00
                </span>
                <span className="text-[9px] text-slate-400 block">Instant 1:1 deduction</span>
              </div>
            </div>

            {/* Tier Progress Bar */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-bold">
                <span className="text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Award className="w-3.5 h-3.5 text-amber-500" />
                  <span>Tier: {userTier.name}</span>
                </span>
                <span className="text-slate-500 text-[10px]">
                  {userTier.next ? `Next: ${userTier.next} (${userTier.target} Coins)` : 'Top VIP Rank'}
                </span>
              </div>
              <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-amber-500 to-orange-500 h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.min(100, Math.round((superCoinsBalance / userTier.target) * 100))}%`,
                  }}
                />
              </div>
            </div>

            {/* Quick Actions for Coins */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={handleClaimStreak}
                disabled={hasClaimedToday}
                className={`py-2 px-3 rounded-xl font-extrabold text-xs flex items-center justify-center gap-1.5 transition-all ${
                  hasClaimedToday
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 border border-emerald-300 dark:border-emerald-800'
                    : 'bg-amber-500 hover:bg-amber-600 text-slate-800 shadow-xs cursor-pointer'
                }`}
              >
                <Flame className="w-3.5 h-3.5 text-orange-600" />
                <span>{hasClaimedToday ? `Day ${checkInStreak} Claimed` : `Claim Day ${checkInStreak + 1} (+${(checkInStreak + 1) * 10})`}</span>
              </button>

              <button
                onClick={() => {
                  if (onOpenSuperCoinsModal) {
                    onOpenSuperCoinsModal();
                  } else {
                    setIsSuperCoinsModalOpen(true);
                  }
                }}
                className="py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs flex items-center justify-center gap-1 shadow-xs transition-all cursor-pointer"
              >
                <span>Voucher Store</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* CARD B: SELLER DIAMONDS CARD */}
        {(activeView === 'both' || activeView === 'diamonds') && (
          <div className="relative overflow-hidden p-5 rounded-3xl bg-gradient-to-br from-cyan-500/10 via-blue-500/5 to-transparent border border-cyan-500/30 dark:border-cyan-500/20 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 text-white flex items-center justify-center shadow-md">
                  <Gem className="w-5 h-5 fill-white" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-black text-sm text-slate-900 dark:text-white">
                      Seller Diamonds
                    </h4>
                    <span className="px-2 py-0.2 rounded-md bg-cyan-100 dark:bg-cyan-900/60 text-cyan-800 dark:text-cyan-300 font-bold text-[9px]">
                      Venture Royalty
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Direct conversion: <strong>100 💎 = ₹50.00 INR (or 1.5x Ad Boost)</strong>
                  </p>
                </div>
              </div>

              <span className="px-2.5 py-1 rounded-full bg-cyan-600 text-white font-black text-xs shadow-xs">
                {sellerTier.badge}
              </span>
            </div>

            {/* Big Balance & Valuation */}
            <div className="p-4 bg-white/80 dark:bg-slate-900/80 rounded-2xl border border-cyan-200 dark:border-cyan-900/40 backdrop-blur-xs flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                  Venture Diamond Vault
                </span>
                <div className="flex items-baseline gap-1.5 mt-0.5">
                  <span className="text-2xl sm:text-3xl font-black text-cyan-600 dark:text-cyan-400">
                    {sellerDiamonds.toLocaleString()}
                  </span>
                  <span className="text-xs font-extrabold text-slate-600 dark:text-slate-300">
                    Diamonds 💎
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 block">
                  Direct Cashout Value
                </span>
                <span className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                  ₹{(sellerDiamonds * 0.5).toFixed(2)}
                </span>
                <span className="text-[9px] text-cyan-600 dark:text-cyan-400 font-bold block">
                  or ₹{(sellerDiamonds * 0.75).toFixed(0)} Ad Boost
                </span>
              </div>
            </div>

            {/* Tier Progress Bar */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-bold">
                <span className="text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Store className="w-3.5 h-3.5 text-cyan-500" />
                  <span>Tier: {sellerTier.name}</span>
                </span>
                <span className="text-cyan-600 dark:text-cyan-400 text-[10px] font-black">
                  {sellerTier.multiplier}
                </span>
              </div>
              <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-cyan-500 to-blue-600 h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.min(100, Math.round((sellerDiamonds / sellerTier.target) * 100))}%`,
                  }}
                />
              </div>
            </div>

            {/* Quick Actions for Diamonds */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => setIsCashoutModalOpen(true)}
                className="py-2 px-3 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-all cursor-pointer"
              >
                <CreditCard className="w-3.5 h-3.5" />
                <span>Instant UPI Cashout</span>
              </button>

              <button
                onClick={handleConvertDiamondsToAdBoost}
                className="py-2 px-3 rounded-xl bg-cyan-50 dark:bg-cyan-950/40 hover:bg-cyan-100 text-cyan-800 dark:text-cyan-300 border border-cyan-300 dark:border-cyan-800 font-extrabold text-xs flex items-center justify-center gap-1 transition-all cursor-pointer"
              >
                <Zap className="w-3.5 h-3.5 text-cyan-500 fill-cyan-500" />
                <span>Convert to 1.5x Ad Boost</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 3. Navigation Sub-Tabs: Mechanics, Redemptions, Calculator, Ledger */}
      <div className="flex items-center gap-1.5 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto no-scrollbar">
        {[
          { id: 'overview', label: 'Earning Rules & Roadmap', icon: TrendingUp },
          { id: 'mechanics', label: 'Conversion Mechanics', icon: Percent },
          { id: 'redemptions', label: 'Redemption Paths', icon: Gift },
          { id: 'calculator', label: 'Interactive Value Calculator', icon: Calculator },
          { id: 'history', label: 'Reward Activity Ledger', icon: Clock },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 4. SUBTAB CONTENT */}

      {/* SUBTAB 1: EARNING RULES & ROADMAP */}
      {activeSubTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* User Coins Earning Streams */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Coins className="w-4 h-4 text-amber-500" />
                  <span>How Customers Earn Coins</span>
                </h4>
                <span className="text-[10px] font-bold text-amber-600 bg-amber-500/10 px-2 py-0.5 rounded-full">
                  User Loyalty
                </span>
              </div>

              <div className="space-y-2.5 text-xs">
                <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
                  <div className="w-7 h-7 rounded-lg bg-amber-100 dark:bg-amber-900/60 text-amber-700 dark:text-amber-300 flex items-center justify-center font-black shrink-0">
                    🛍️
                  </div>
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">Shop on Verified Ventures</div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      Earn <strong>5 to 10 SuperCoins per ₹100</strong> spent on any local brand or marketplace product.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
                  <div className="w-7 h-7 rounded-lg bg-orange-100 dark:bg-orange-900/60 text-orange-700 dark:text-orange-300 flex items-center justify-center font-black shrink-0">
                    📅
                  </div>
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">Daily Streak Check-Ins</div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      Collect escalating daily bonuses (+10, +20, +50, +100 Coins) on your 7-day streak cycle.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
                  <div className="w-7 h-7 rounded-lg bg-purple-100 dark:bg-purple-900/60 text-purple-700 dark:text-purple-300 flex items-center justify-center font-black shrink-0">
                    ⭐
                  </div>
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">Verified Photo Reviews</div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      Post photo or unboxing video reviews of delivered orders to earn <strong>+25 Coins</strong> each.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
                  <div className="w-7 h-7 rounded-lg bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-black shrink-0">
                    👥
                  </div>
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">Friend Invite Code</div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      Get <strong>500 SuperCoins</strong> credited the moment your referred neighbor places their first order.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Seller Diamonds Earning Streams */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Gem className="w-4 h-4 text-cyan-500" />
                  <span>How Sellers Earn Diamonds</span>
                </h4>
                <span className="text-[10px] font-bold text-cyan-600 bg-cyan-500/10 px-2 py-0.5 rounded-full">
                  Venture Royalty
                </span>
              </div>

              <div className="space-y-2.5 text-xs">
                <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
                  <div className="w-7 h-7 rounded-lg bg-cyan-100 dark:bg-cyan-900/60 text-cyan-700 dark:text-cyan-300 flex items-center justify-center font-black shrink-0">
                    📦
                  </div>
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">GMV Order Volume</div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      Earn <strong>1 Diamond per ₹150</strong> of completed sales volume automatically upon customer delivery.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
                  <div className="w-7 h-7 rounded-lg bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-black shrink-0">
                    ⚡
                  </div>
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">Hyperlocal Fast Handoff</div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      Package & hand off parcel to nearby Delivery Buddy within 30 minutes for <strong>+15 Bonus Diamonds</strong>.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
                  <div className="w-7 h-7 rounded-lg bg-amber-100 dark:bg-amber-900/60 text-amber-700 dark:text-amber-300 flex items-center justify-center font-black shrink-0">
                    🌟
                  </div>
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">5-Star Store Ratings & Low Returns</div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      Receive <strong>+50 Diamonds</strong> per 5-star review and a monthly <strong>500 Diamond bonus</strong> for return rates &lt; 1.5%.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
                  <div className="w-7 h-7 rounded-lg bg-purple-100 dark:bg-purple-900/60 text-purple-700 dark:text-purple-300 flex items-center justify-center font-black shrink-0">
                    🎥
                  </div>
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">Shoppable Video Reels</div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      Publish high-engagement creator reels driving &gt;10 direct orders to unlock <strong>+100 Diamonds</strong>.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: CONVERSION MECHANICS */}
      {activeSubTab === 'mechanics' && (
        <div className="space-y-4">
          <div className="p-4 bg-amber-500/10 dark:bg-amber-950/20 rounded-2xl border border-amber-500/30">
            <h4 className="font-black text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Percent className="w-4 h-4 text-amber-500" />
              <span>Exact Conversion Formulas & Economic Values</span>
            </h4>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
              Transparent, immutable exchange rates established for customer loyalty and venture growth.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {/* Coins Conversion Table */}
            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                <span className="font-extrabold text-amber-600 dark:text-amber-400 flex items-center gap-1.5">
                  <Coins className="w-4 h-4" />
                  <span>Coins Conversion Matrix</span>
                </span>
                <span className="font-bold text-slate-400 text-[10px]">100% Guaranteed Rate</span>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">Direct Checkout Offset</span>
                  <span className="font-black text-slate-900 dark:text-white">1 Coin = ₹1.00 INR (1:1)</span>
                </div>
                <div className="flex justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">Max Cart Offset Slabs</span>
                  <span className="font-black text-emerald-600">Up to 50% of Cart Total</span>
                </div>
                <div className="flex justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">OTT Pass Valuation</span>
                  <span className="font-black text-purple-600">250 Coins = ₹299 OTT Pass</span>
                </div>
                <div className="flex justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">Expiration Policy</span>
                  <span className="font-black text-slate-600 dark:text-slate-400">12 Months Rolling (Renewable)</span>
                </div>
              </div>
            </div>

            {/* Diamonds Conversion Table */}
            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                <span className="font-extrabold text-cyan-600 dark:text-cyan-400 flex items-center gap-1.5">
                  <Gem className="w-4 h-4" />
                  <span>Diamonds Conversion Matrix</span>
                </span>
                <span className="font-bold text-slate-400 text-[10px]">Instant Transferable</span>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">Direct Bank / UPI Cashout</span>
                  <span className="font-black text-emerald-600">100 Diamonds = ₹50.00 INR (₹0.50/💎)</span>
                </div>
                <div className="flex justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">Sponsored Storefront Ad Boost</span>
                  <span className="font-black text-cyan-600">100 Diamonds = ₹75.00 INR Ad Value (1.5x)</span>
                </div>
                <div className="flex justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">Minimum Cashout Threshold</span>
                  <span className="font-black text-slate-900 dark:text-white">200 Diamonds (₹100 INR)</span>
                </div>
                <div className="flex justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">Settlement Speed</span>
                  <span className="font-black text-emerald-600">&lt; 30 Seconds Instant UPI</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 3: REDEMPTION PATHS */}
      {activeSubTab === 'redemptions' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* User Redemption Paths */}
            <div className="p-4 bg-amber-50/50 dark:bg-amber-950/20 rounded-2xl border border-amber-200 dark:border-amber-900/40 space-y-3">
              <h4 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                <Gift className="w-4 h-4 text-amber-500" />
                <span>Customer Redemption Paths</span>
              </h4>

              <div className="space-y-2 text-xs">
                <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">1. Instant Checkout Cash Offset</div>
                    <p className="text-[11px] text-slate-500">Toggle switch on checkout screen to pay with coins.</p>
                  </div>
                  <span className="text-[10px] font-black text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-1 rounded-md">
                    1:1 INR
                  </span>
                </div>

                <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">2. OTT & Streaming Passes</div>
                    <p className="text-[11px] text-slate-500">Claim 3-month Disney+ Hotstar or Spotify Premium vouchers.</p>
                  </div>
                  <span className="text-[10px] font-black text-purple-600 bg-purple-50 dark:bg-purple-950/40 px-2 py-1 rounded-md">
                    250-500 Coins
                  </span>
                </div>

                <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">3. Local Store Coffee & Dine-out Passes</div>
                    <p className="text-[11px] text-slate-500">Redeem artisanal food passes for cafes in your district.</p>
                  </div>
                  <span className="text-[10px] font-black text-amber-600 bg-amber-50 dark:bg-amber-950/40 px-2 py-1 rounded-md">
                    150 Coins
                  </span>
                </div>
              </div>
            </div>

            {/* Seller Redemption Paths */}
            <div className="p-4 bg-cyan-50/50 dark:bg-cyan-950/20 rounded-2xl border border-cyan-200 dark:border-cyan-900/40 space-y-3">
              <h4 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                <Gem className="w-4 h-4 text-cyan-500" />
                <span>Seller Venture Redemption Paths</span>
              </h4>

              <div className="space-y-2 text-xs">
                <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">1. Instant Direct Bank / UPI Cashout</div>
                    <p className="text-[11px] text-slate-500">Zero fee direct transfer to your verified seller UPI.</p>
                  </div>
                  <span className="text-[10px] font-black text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-1 rounded-md">
                    ₹0.50 / 💎
                  </span>
                </div>

                <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">2. Sponsored Storefront Boost</div>
                    <p className="text-[11px] text-slate-500">Get top placement on city feeds at 1.5x bonus power.</p>
                  </div>
                  <span className="text-[10px] font-black text-cyan-600 bg-cyan-50 dark:bg-cyan-950/40 px-2 py-1 rounded-md">
                    +50% Bonus
                  </span>
                </div>

                <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">3. Delivery Buddy Fee Subsidies</div>
                    <p className="text-[11px] text-slate-500">Fund free delivery promotions for your buyers.</p>
                  </div>
                  <span className="text-[10px] font-black text-teal-600 bg-teal-50 dark:bg-teal-950/40 px-2 py-1 rounded-md">
                    0-Fee Shipping
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 4: INTERACTIVE VALUE CALCULATOR */}
      {activeSubTab === 'calculator' && (
        <div className="p-4 sm:p-6 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-6">
          <div>
            <h4 className="font-black text-base text-slate-900 dark:text-white flex items-center gap-2">
              <Calculator className="w-5 h-5 text-amber-500" />
              <span>Interactive Value & Yield Calculator</span>
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Test conversion values dynamically for both User Coins and Seller Diamonds.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Coins Calculator */}
            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-amber-300 dark:border-amber-900/60 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-amber-600 dark:text-amber-400">
                  Customer Coins Calculator
                </span>
                <span className="text-[10px] font-black text-slate-400">1:1 Value</span>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Enter SuperCoins Amount
                </label>
                <input
                  type="number"
                  min="10"
                  max="50000"
                  step="10"
                  value={calcCoins}
                  onChange={(e) => setCalcCoins(Number(e.target.value) || 0)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white font-mono font-bold text-sm focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="p-3 bg-amber-50 dark:bg-amber-950/30 rounded-xl border border-amber-200 dark:border-amber-900/40 space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-600 dark:text-slate-400">Direct Checkout Saving:</span>
                  <strong className="text-emerald-600 font-mono text-sm">₹{calcCoins}.00 INR</strong>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-600 dark:text-slate-400">Equivalent OTT Pass Value:</span>
                  <strong className="text-purple-600 font-mono">
                    {Math.floor(calcCoins / 250)} Free Months
                  </strong>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-600 dark:text-slate-400">Max Cart Qualifying:</span>
                  <strong className="text-slate-800 dark:text-slate-200 font-mono">₹{calcCoins * 2} Cart</strong>
                </div>
              </div>
            </div>

            {/* Diamonds Calculator */}
            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-cyan-300 dark:border-cyan-900/60 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-cyan-600 dark:text-cyan-400">
                  Seller Diamonds Calculator
                </span>
                <span className="text-[10px] font-black text-slate-400">Dual Payout / Boost</span>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Enter Diamonds Amount 💎
                </label>
                <input
                  type="number"
                  min="100"
                  max="100000"
                  step="50"
                  value={calcDiamonds}
                  onChange={(e) => setCalcDiamonds(Number(e.target.value) || 0)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white font-mono font-bold text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="p-3 bg-cyan-50 dark:bg-cyan-950/30 rounded-xl border border-cyan-200 dark:border-cyan-900/40 space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-600 dark:text-slate-400">Instant UPI Bank Cash:</span>
                  <strong className="text-emerald-600 font-mono text-sm">
                    ₹{(calcDiamonds * 0.5).toFixed(2)} INR
                  </strong>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-600 dark:text-slate-400">Or 1.5x Sponsored Ad Credit:</span>
                  <strong className="text-cyan-600 font-mono">
                    ₹{(calcDiamonds * 0.75).toFixed(0)} Ad Boost
                  </strong>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-600 dark:text-slate-400">Delivery Buddy Runs Funded:</span>
                  <strong className="text-teal-600 font-mono">
                    ~{Math.floor((calcDiamonds * 0.5) / 36)} Free Deliveries
                  </strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 5: REWARD ACTIVITY LEDGER */}
      {activeSubTab === 'history' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-slate-400" />
              <span>Real-time Reward Transactions</span>
            </h4>
            <span className="text-[10px] text-slate-400 font-semibold">Latest Entries</span>
          </div>

          <div className="space-y-2">
            {[
              {
                id: 'tx-1',
                title: 'Daily Streak Bonus (Day 4)',
                type: 'Coins',
                amount: '+40 Coins',
                date: 'Today, 09:30 AM',
                color: 'text-amber-600',
                bg: 'bg-amber-50 dark:bg-amber-950/40',
              },
              {
                id: 'tx-2',
                title: 'Order #ORD-9841 Completion Cashout Reward',
                type: 'Diamonds',
                amount: '+84 Diamonds',
                date: 'Yesterday, 04:15 PM',
                color: 'text-cyan-600',
                bg: 'bg-cyan-50 dark:bg-cyan-950/40',
              },
              {
                id: 'tx-3',
                title: 'Purchase of Handloom Saree (Venture Reward)',
                type: 'Coins',
                amount: '+65 Coins',
                date: '28 Aug 2026',
                color: 'text-amber-600',
                bg: 'bg-amber-50 dark:bg-amber-950/40',
              },
              {
                id: 'tx-4',
                title: 'Delivery Buddy Sub-30min Fast Handoff Bonus',
                type: 'Diamonds',
                amount: '+15 Diamonds',
                date: '27 Aug 2026',
                color: 'text-cyan-600',
                bg: 'bg-cyan-50 dark:bg-cyan-950/40',
              },
            ].map((tx) => (
              <div
                key={tx.id}
                className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-bold text-slate-900 dark:text-white">{tx.title}</div>
                  <div className="text-[10px] text-slate-400">{tx.date}</div>
                </div>
                <span className={`font-mono font-black ${tx.color} ${tx.bg} px-2 py-0.5 rounded-md`}>
                  {tx.amount}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. Direct Modal for Seller Diamond Cashout */}
      {isCashoutModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-100/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 max-w-md w-full p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-cyan-500 text-white flex items-center justify-center">
                  <Gem className="w-4 h-4" />
                </div>
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                  Instant UPI Diamond Cashout
                </h3>
              </div>
              <button
                onClick={() => setIsCashoutModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                &times;
              </button>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400">
              Convert your seller venture royalty diamonds directly into cash transferred to your verified UPI VPA.
            </p>

            <form onSubmit={handleCashoutDiamonds} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Diamonds to Cashout (Balance: {sellerDiamonds} 💎)
                </label>
                <input
                  type="number"
                  min="200"
                  max={sellerDiamonds}
                  step="50"
                  value={cashoutAmount}
                  onChange={(e) => setCashoutAmount(Number(e.target.value))}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 font-mono font-bold text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Beneficiary UPI VPA (ID)
                </label>
                <input
                  type="text"
                  value={cashoutUPI}
                  onChange={(e) => setCashoutUPI(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 font-mono text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/30 rounded-xl border border-emerald-200 dark:border-emerald-900/40 flex items-center justify-between">
                <span className="font-semibold text-emerald-800 dark:text-emerald-300">
                  Instant Cash Payout:
                </span>
                <strong className="text-base font-black text-emerald-600 font-mono">
                  ₹{(cashoutAmount * 0.5).toFixed(2)} INR
                </strong>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCashoutModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isCashingOut}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-extrabold shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  {isCashingOut ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  )}
                  <span>{isCashingOut ? 'Processing Payout...' : 'Transfer to UPI Now'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
