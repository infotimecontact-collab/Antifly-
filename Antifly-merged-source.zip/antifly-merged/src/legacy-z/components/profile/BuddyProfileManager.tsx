import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Truck,
  Zap,
  CheckCircle2,
  AlertCircle,
  CreditCard,
  Sparkles,
  ArrowRight,
  Navigation,
  MapPin,
  Compass,
  Phone,
  Power,
  RotateCw,
  Wallet,
  DollarSign,
  Layers,
  Bike,
  ShieldCheck,
  Save,
  Radio,
} from 'lucide-react';

interface BuddyProfileManagerProps {
  compact?: boolean;
  onNavigateToDriverPortal?: () => void;
}

export const BuddyProfileManager: React.FC<BuddyProfileManagerProps> = ({
  compact = false,
  onNavigateToDriverPortal,
}) => {
  const {
    drivers,
    activeDriverId,
    setActiveDriverId,
    currentDriver,
    toggleDriverOnline,
    driverTasks,
    currentUserSession,
    quickSwitchUser,
    setDeviceMode,
    showToast,
    formatPrice,
    driverUPIs,
    updateDriverUPI,
  } = useApp();

  const driver = drivers.find((d) => d.id === activeDriverId) || drivers[0];
  const [isBuddyActive, setIsBuddyActive] = useState<boolean>(
    currentUserSession.role === 'driver' || Boolean(currentUserSession.driverId) || true
  );

  // Driver details & Vehicle setup
  const [driverName, setDriverName] = useState<string>(driver?.name || 'Rahul Verma');
  const [driverPhone, setDriverPhone] = useState<string>(driver?.phone || '+91 98765 43210');
  const [vehicleType, setVehicleType] = useState<'ev_bike' | 'bicycle' | 'scooter' | 'van'>(
    'ev_bike'
  );
  const [operatingRadiusKm, setOperatingRadiusKm] = useState<number>(10);

  // Direct Bank & Instant UPI Payout Account Details
  const existingUPI = driver ? driverUPIs[driver.id] : null;
  const [bankAccountHolder, setBankAccountHolder] = useState<string>(
    existingUPI?.accountHolderName || driver?.name || 'Rahul Verma'
  );
  const [bankAccountNumber, setBankAccountNumber] = useState<string>(
    existingUPI?.bankAccountNumber || '3098124950123'
  );
  const [bankIfsc, setBankIfsc] = useState<string>(existingUPI?.ifscCode || 'SBIN0004521');
  const [bankName, setBankName] = useState<string>(existingUPI?.bankName || 'State Bank of India');
  const [upiVpa, setUpiVpa] = useState<string>(existingUPI?.upiVpa || 'rahul.driver@okaxis');

  // Performance calculations
  const completedTasks = driverTasks.filter((t) => t.status === 'Delivered');
  const totalTrips = completedTasks.length + 8; // base historical
  const totalDistanceKm = totalTrips * 4.2;
  const ratePerKm = 12; // dynamic rate ₹12 per km
  const totalEarned = Math.round(totalDistanceKm * ratePerKm + totalTrips * 30);

  const handleSavePayoutDetails = (e: React.FormEvent) => {
    e.preventDefault();
    if (driver && updateDriverUPI) {
      updateDriverUPI(driver.id, {
        accountHolderName: bankAccountHolder,
        bankAccountNumber: bankAccountNumber,
        ifscCode: bankIfsc,
        bankName: bankName,
        upiVpa: upiVpa,
        isVerified: true,
      });
    }
    showToast('✅ Delivery Buddy Payout UPI & Bank updated successfully!');
  };

  const handleLaunchDriverPortal = () => {
    if (onNavigateToDriverPortal) {
      onNavigateToDriverPortal();
    } else {
      quickSwitchUser('driver', driver?.id);
      setDeviceMode('driver');
    }
    showToast('🚴 Switched to Delivery Buddy Logistics Console');
  };

  return (
    <div
      id="buddy-profile-manager"
      className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-4 sm:p-6 shadow-sm space-y-6"
    >
      {/* 1. Header & Direct Role Activation Switch */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-500 flex items-center justify-center text-white shadow-md">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                Delivery Buddy Management
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold text-[10px] border border-emerald-500/20">
                Direct Driver Role
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Pick up parcels from nearby ventures, earn ₹12/km transit fees + 100% rider tips settled directly to your UPI.
            </p>
          </div>
        </div>

        {/* Activation & Duty Controls */}
        <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
          {/* Online Duty Toggle */}
          <button
            onClick={toggleDriverOnline}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              driver?.isOnline
                ? 'bg-emerald-500 text-white shadow-sm ring-2 ring-emerald-400/30'
                : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                driver?.isOnline ? 'bg-white animate-ping' : 'bg-slate-400'
              }`}
            />
            <span>{driver?.isOnline ? 'ONLINE (DUTY ON)' : 'OFFLINE'}</span>
          </button>

          {/* Master Buddy Role Activation */}
          <button
            id="toggle-buddy-role-btn"
            onClick={() => {
              const next = !isBuddyActive;
              setIsBuddyActive(next);
              showToast(next ? '🚴 Buddy Driver Role Activated on your profile!' : '⏸️ Buddy Role Paused');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all ${
              isBuddyActive
                ? 'bg-teal-600 text-white shadow-xs'
                : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${isBuddyActive ? 'fill-white' : ''}`} />
            <span>{isBuddyActive ? 'BUDDY ACTIVE' : 'DISABLED'}</span>
          </button>
        </div>
      </div>

      {/* 2. Buddy Real-time Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 bg-emerald-50/60 dark:bg-emerald-950/20 rounded-2xl border border-emerald-200 dark:border-emerald-900/40">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-[11px] font-semibold">
            <span>Completed Trips</span>
            <Navigation className="w-3.5 h-3.5 text-emerald-500" />
          </div>
          <p className="text-lg font-black text-slate-900 dark:text-white mt-1">
            {totalTrips} Parcels
          </p>
        </div>

        <div className="p-3.5 bg-teal-50/60 dark:bg-teal-950/20 rounded-2xl border border-teal-200 dark:border-teal-900/40">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-[11px] font-semibold">
            <span>Distance Logged</span>
            <Compass className="w-3.5 h-3.5 text-teal-500" />
          </div>
          <p className="text-lg font-black text-slate-900 dark:text-white mt-1">
            {totalDistanceKm.toFixed(1)} km
          </p>
        </div>

        <div className="p-3.5 bg-blue-50/60 dark:bg-blue-950/20 rounded-2xl border border-blue-200 dark:border-blue-900/40">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-[11px] font-semibold">
            <span>Transit Earnings</span>
            <DollarSign className="w-3.5 h-3.5 text-blue-500" />
          </div>
          <p className="text-lg font-black text-blue-700 dark:text-blue-400 mt-1">
            {formatPrice(totalEarned)}
          </p>
        </div>

        <div className="p-3.5 bg-purple-50/60 dark:bg-purple-950/20 rounded-2xl border border-purple-200 dark:border-purple-900/40">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-[11px] font-semibold">
            <span>Dynamic Rate</span>
            <Zap className="w-3.5 h-3.5 text-purple-500" />
          </div>
          <p className="text-lg font-black text-purple-700 dark:text-purple-300 mt-1">
            ₹{ratePerKm} / km
          </p>
        </div>
      </div>

      {/* 3. Vehicle & Service Radius Preference */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Vehicle Selection */}
        <div className="bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-xs text-slate-900 dark:text-white flex items-center gap-1.5">
              <Bike className="w-4 h-4 text-emerald-600" />
              <span>Vehicle Fleet Mode</span>
            </h4>
            <span className="text-[10px] font-bold text-slate-500">Green Logistics</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            {[
              { id: 'ev_bike', label: '⚡ Electric EV Bike', badge: 'Fast & Green' },
              { id: 'bicycle', label: '🚲 Cycle Courier', badge: 'Zero Emission' },
              { id: 'scooter', label: '🛵 Scooter / Bike', badge: 'City Express' },
              { id: 'van', label: '🚗 Mini Cargo Van', badge: 'Bulk Parcels' },
            ].map((v) => (
              <button
                key={v.id}
                type="button"
                onClick={() => {
                  setVehicleType(v.id as any);
                  showToast(`🛵 Switched vehicle mode to ${v.label}`);
                }}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  vehicleType === v.id
                    ? 'bg-emerald-500/10 border-emerald-500 text-emerald-900 dark:text-emerald-300 font-bold'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <div className="font-bold truncate">{v.label}</div>
                <div className="text-[9px] text-slate-400 mt-0.5">{v.badge}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Operating Radius */}
        <div className="bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-xs text-slate-900 dark:text-white flex items-center gap-1.5">
              <Compass className="w-4 h-4 text-teal-600" />
              <span>Delivery Corridor Radius</span>
            </h4>
            <span className="text-xs font-black text-teal-600 dark:text-teal-400 bg-teal-500/10 px-2 py-0.5 rounded-full border border-teal-500/20">
              {operatingRadiusKm} km
            </span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">
            You will automatically receive parcel dispatch alerts from ventures within this perimeter.
          </p>
          <input
            type="range"
            min="3"
            max="30"
            step="1"
            value={operatingRadiusKm}
            onChange={(e) => setOperatingRadiusKm(Number(e.target.value))}
            className="w-full accent-teal-500 cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-400 font-semibold">
            <span>3 km (Hyperlocal)</span>
            <span>15 km (City Hub)</span>
            <span>30 km (Metropolitan)</span>
          </div>
        </div>
      </div>

      {/* 4. Direct Driver Bank & Instant UPI Payout Form */}
      <div className="bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 sm:p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-emerald-500" />
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
              Direct Driver Bank & Instant UPI Settlement
            </h4>
          </div>
          <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
            <CheckCircle2 className="w-3 h-3" />
            Direct To Rider
          </span>
        </div>
        <p className="text-[11px] text-slate-500 dark:text-slate-400">
          Delivery fees (₹12/km) and customer tips transfer directly to your verified UPI/Bank without deductions.
        </p>

        <form onSubmit={handleSavePayoutDetails} className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Beneficiary / Rider Name
            </label>
            <input
              type="text"
              value={bankAccountHolder}
              onChange={(e) => setBankAccountHolder(e.target.value)}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500 font-medium"
              placeholder="e.g. Rahul Verma"
              required
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Direct UPI ID (VPA)
            </label>
            <input
              type="text"
              value={upiVpa}
              onChange={(e) => setUpiVpa(e.target.value)}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500 font-mono font-medium"
              placeholder="e.g. rahul@okaxis"
              required
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Bank Account Number
            </label>
            <input
              type="text"
              value={bankAccountNumber}
              onChange={(e) => setBankAccountNumber(e.target.value)}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500 font-mono font-medium"
              placeholder="e.g. 3098124950123"
              required
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Bank IFSC Code & Name
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={bankIfsc}
                onChange={(e) => setBankIfsc(e.target.value.toUpperCase())}
                className="w-1/2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500 font-mono uppercase font-medium"
                placeholder="SBIN0004521"
                required
              />
              <input
                type="text"
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                className="w-1/2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500 font-medium"
                placeholder="State Bank of India"
                required
              />
            </div>
          </div>

          <div className="sm:col-span-2 flex justify-end pt-1">
            <button
              type="submit"
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2 rounded-xl text-xs shadow-xs transition-all"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Update Rider Payout Details</span>
            </button>
          </div>
        </form>
      </div>

      {/* 5. Fast Action Launch Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500">
            Current Status:{' '}
            <strong className={driver?.isOnline ? 'text-emerald-600' : 'text-slate-600'}>
              {driver?.isOnline ? 'Receiving Nearby Parcels' : 'Resting'}
            </strong>
          </span>
        </div>

        <button
          onClick={handleLaunchDriverPortal}
          className="flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold px-5 py-2.5 rounded-2xl text-xs shadow-md transition-all"
        >
          <span>Launch Delivery Buddy Logistics Console</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
