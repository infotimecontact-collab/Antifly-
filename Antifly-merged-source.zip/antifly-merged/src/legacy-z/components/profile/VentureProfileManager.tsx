import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Store,
  CheckCircle2,
  AlertCircle,
  Building2,
  CreditCard,
  Sparkles,
  ArrowRight,
  Plus,
  Package,
  DollarSign,
  TrendingUp,
  Share2,
  MapPin,
  Phone,
  Mail,
  ShieldCheck,
  Zap,
  Gem,
  ExternalLink,
  Edit3,
  Save,
  Radio,
  Truck,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { CoinsAndDiamondsTracker } from './CoinsAndDiamondsTracker';

interface VentureProfileManagerProps {
  compact?: boolean;
  onNavigateToSellerPortal?: () => void;
}

export const VentureProfileManager: React.FC<VentureProfileManagerProps> = ({
  compact = false,
  onNavigateToSellerPortal,
}) => {
  const {
    sellers,
    activeSellerId,
    setActiveSellerId,
    currentUserSession,
    quickSwitchUser,
    setDeviceMode,
    products,
    orders,
    showToast,
    formatPrice,
    sellerUPIs,
    updateSellerUPI,
    setIsAddProductModalOpen,
    setIsSellerShareModalOpen,
  } = useApp();

  const currentSeller = sellers.find((s) => s.id === activeSellerId) || sellers[0];
  const [isVentureActive, setIsVentureActive] = useState<boolean>(
    currentUserSession.role === 'seller' || Boolean(currentUserSession.sellerId) || true
  );

  // Editable Store Information
  const [storeName, setStoreName] = useState<string>(currentSeller?.storeName || 'Artisan Craft Studio');
  const [storeCategory, setStoreCategory] = useState<string>(currentSeller?.category || 'Handmade Fashion');
  const [storeCity, setStoreCity] = useState<string>(currentSeller?.city || 'Bengaluru');
  const [storePhone, setStorePhone] = useState<string>(currentSeller?.contactPhone || '+91 98490 22334');
  const [storeEmail, setStoreEmail] = useState<string>(currentSeller?.contactEmail || 'studio@antifly.com');
  const [isOpenForOrders, setIsOpenForOrders] = useState<boolean>(true);

  // Bank & Direct UPI Settlement Details
  const existingUPI = currentSeller ? sellerUPIs[currentSeller.id] : null;
  const [bankAccountHolder, setBankAccountHolder] = useState<string>(
    existingUPI?.accountHolderName || currentSeller?.storeName || 'Priya Sharma Studio'
  );
  const [bankAccountNumber, setBankAccountNumber] = useState<string>(
    existingUPI?.bankAccountNumber || '50100492819283'
  );
  const [bankIfsc, setBankIfsc] = useState<string>(existingUPI?.ifscCode || 'HDFC0001245');
  const [bankName, setBankName] = useState<string>(existingUPI?.bankName || 'HDFC Bank Ltd');
  const [upiVpa, setUpiVpa] = useState<string>(existingUPI?.upiVpa || 'priyacrafts@okhdfcbank');
  const [showDiamondsTracker, setShowDiamondsTracker] = useState<boolean>(false);

  // Stats calculation
  const sellerProducts = products.filter((p) => p.sellerId === currentSeller?.id);
  const sellerOrders = orders.filter((o) =>
    o.items.some((it) => it.sellerId === currentSeller?.id || it.brand === currentSeller?.storeName)
  );
  const totalRevenue = sellerOrders.reduce((sum, o) => sum + o.totalAmount, 0);
  const earnedDiamonds = Math.max(18, Math.floor(totalRevenue / 150)); // Diamonds rewarded for sales volume

  const handleSaveBankDetails = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentSeller && updateSellerUPI) {
      updateSellerUPI(currentSeller.id, {
        accountHolderName: bankAccountHolder,
        bankAccountNumber: bankAccountNumber,
        ifscCode: bankIfsc,
        bankName: bankName,
        upiVpa: upiVpa,
        isVerified: true,
      });
    }
    showToast('✅ Direct Bank & UPI details linked! Customer payments will settle directly.');
  };

  const handleLaunchVenturePortal = () => {
    if (onNavigateToSellerPortal) {
      onNavigateToSellerPortal();
    } else {
      quickSwitchUser('seller', currentSeller?.id);
      setDeviceMode('seller');
    }
    showToast('🚀 Switched to Venture Central Merchant Studio');
  };

  return (
    <div
      id="venture-profile-manager"
      className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-4 sm:p-6 shadow-sm space-y-6"
    >
      {/* 1. Header & Direct Activation Switch */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-orange-500 to-amber-500 flex items-center justify-center text-white shadow-md">
            <Store className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                Venture Merchant Management
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-orange-500/10 text-orange-600 dark:text-orange-400 font-bold text-[10px] border border-orange-500/20">
                Direct Seller Role
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              List artisan products, ring nearby buddies for instant ₹12/km pickup & collect direct bank payouts.
            </p>
          </div>
        </div>

        {/* Activation Toggle */}
        <div className="flex items-center gap-3 bg-slate-50 dark:bg-slate-800/80 px-3 py-2 rounded-2xl border border-slate-200 dark:border-slate-700 self-start sm:self-auto">
          <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
            Venture Status:
          </span>
          <button
            id="toggle-venture-role-btn"
            onClick={() => {
              const next = !isVentureActive;
              setIsVentureActive(next);
              showToast(next ? '🎉 Venture Role Activated on your profile!' : '⏸️ Venture Role Paused');
            }}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-black transition-all ${
              isVentureActive
                ? 'bg-emerald-500 text-white shadow-xs'
                : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${isVentureActive ? 'fill-white' : ''}`} />
            <span>{isVentureActive ? 'ACTIVE & SELLING' : 'DISABLED'}</span>
          </button>
        </div>
      </div>

      {/* 2. Venture Real-time Performance Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 bg-orange-50/60 dark:bg-orange-950/20 rounded-2xl border border-orange-200 dark:border-orange-900/40">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-[11px] font-semibold">
            <span>Listed Products</span>
            <Package className="w-3.5 h-3.5 text-orange-500" />
          </div>
          <p className="text-lg font-black text-slate-900 dark:text-white mt-1">
            {sellerProducts.length} Items
          </p>
        </div>

        <div className="p-3.5 bg-amber-50/60 dark:bg-amber-950/20 rounded-2xl border border-amber-200 dark:border-amber-900/40">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-[11px] font-semibold">
            <span>Direct Orders</span>
            <TrendingUp className="w-3.5 h-3.5 text-amber-500" />
          </div>
          <p className="text-lg font-black text-slate-900 dark:text-white mt-1">
            {sellerOrders.length} Received
          </p>
        </div>

        <div className="p-3.5 bg-emerald-50/60 dark:bg-emerald-950/20 rounded-2xl border border-emerald-200 dark:border-emerald-900/40">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-[11px] font-semibold">
            <span>Gross Revenue</span>
            <DollarSign className="w-3.5 h-3.5 text-emerald-500" />
          </div>
          <p className="text-lg font-black text-emerald-700 dark:text-emerald-400 mt-1">
            {formatPrice(totalRevenue || 12450)}
          </p>
        </div>

        <div
          id="venture-diamonds-metric-card"
          onClick={() => setShowDiamondsTracker(!showDiamondsTracker)}
          className="p-3.5 bg-cyan-50/60 dark:bg-cyan-950/20 rounded-2xl border border-cyan-200 dark:border-cyan-900/40 cursor-pointer hover:border-cyan-400 transition-all group"
        >
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-[11px] font-semibold">
            <span>Diamonds 💎</span>
            <div className="flex items-center gap-1">
              <Gem className="w-3.5 h-3.5 text-cyan-500" />
              {showDiamondsTracker ? (
                <ChevronUp className="w-3 h-3 text-cyan-600" />
              ) : (
                <ChevronDown className="w-3 h-3 text-cyan-600 group-hover:translate-y-0.5 transition-transform" />
              )}
            </div>
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <p className="text-lg font-black text-cyan-700 dark:text-cyan-300">
              {earnedDiamonds} 💎
            </p>
            <span className="text-[10px] text-cyan-600 dark:text-cyan-400 font-bold">
              (₹{earnedDiamonds * 50} val)
            </span>
          </div>
          <span className="text-[9px] text-cyan-600 dark:text-cyan-400 block mt-0.5 font-medium">
            {showDiamondsTracker ? 'Hide conversion hub' : 'Click for conversion & payout hub →'}
          </span>
        </div>
      </div>

      {/* Expanded Diamond Breakdown & Conversion Tracker */}
      {showDiamondsTracker && (
        <div className="animate-in fade-in slide-in-from-top-2 duration-300">
          <CoinsAndDiamondsTracker initialView="diamonds" />
        </div>
      )}

      {/* 3. Direct Bank & UPI Settlement Setup Form */}
      <div className="bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 sm:p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-orange-500" />
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
              Direct Venture Bank & Instant UPI Payout Account
            </h4>
          </div>
          <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
            <CheckCircle2 className="w-3 h-3" />
            Direct Settlement
          </span>
        </div>
        <p className="text-[11px] text-slate-500 dark:text-slate-400">
          Customer product payments are deposited directly into this account with 0% middleman fees.
        </p>

        <form onSubmit={handleSaveBankDetails} className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Account Holder Name
            </label>
            <input
              type="text"
              value={bankAccountHolder}
              onChange={(e) => setBankAccountHolder(e.target.value)}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-orange-500 font-medium"
              placeholder="e.g. Priya Sharma Crafts"
              required
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Direct UPI ID (VPA)
            </label>
            <input
              type="text"
              value={upiVpa}
              onChange={(e) => setUpiVpa(e.target.value)}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-orange-500 font-mono font-medium"
              placeholder="e.g. store@okhdfcbank"
              required
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Bank Account Number
            </label>
            <input
              type="text"
              value={bankAccountNumber}
              onChange={(e) => setBankAccountNumber(e.target.value)}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-orange-500 font-mono font-medium"
              placeholder="e.g. 50100492819283"
              required
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Bank IFSC Code & Name
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={bankIfsc}
                onChange={(e) => setBankIfsc(e.target.value.toUpperCase())}
                className="w-1/2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-orange-500 font-mono uppercase font-medium"
                placeholder="HDFC0001245"
                required
              />
              <input
                type="text"
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                className="w-1/2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-orange-500 font-medium"
                placeholder="HDFC Bank"
                required
              />
            </div>
          </div>

          <div className="sm:col-span-2 flex justify-end pt-1">
            <button
              type="submit"
              className="flex items-center gap-1.5 bg-orange-500 hover:bg-orange-600 text-white font-bold px-4 py-2 rounded-xl text-xs shadow-xs transition-all"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Update Bank & Direct UPI Details</span>
            </button>
          </div>
        </form>
      </div>

      {/* 4. Action Buttons Strip */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
        <div className="flex items-center gap-2">
          {setIsAddProductModalOpen && (
            <button
              onClick={() => setIsAddProductModalOpen(true)}
              className="flex items-center gap-1.5 bg-slate-900 dark:bg-white hover:bg-slate-800 dark:hover:bg-slate-100 text-white dark:text-slate-800 font-extrabold px-4 py-2.5 rounded-2xl text-xs transition-all shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Product</span>
            </button>
          )}

          {setIsSellerShareModalOpen && (
            <button
              onClick={() => setIsSellerShareModalOpen(true)}
              className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold px-3.5 py-2.5 rounded-2xl text-xs transition-all"
            >
              <Share2 className="w-4 h-4" />
              <span>Share Store Link</span>
            </button>
          )}
        </div>

        <button
          onClick={handleLaunchVenturePortal}
          className="flex items-center gap-2 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-extrabold px-5 py-2.5 rounded-2xl text-xs shadow-md transition-all"
        >
          <span>Launch Venture Central Studio</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
