import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Navigation,
  MapPin,
  Phone,
  CheckCircle2,
  AlertCircle,
  Shield,
  Clock,
  Compass,
  DollarSign,
  Wallet,
  Camera,
  Edit3,
  Power,
  RotateCw,
  Truck,
  Package,
  Layers,
  ChevronRight,
  ExternalLink,
  LifeBuoy,
  BadgeAlert,
  KeyRound,
  LogIn,
  UserCheck,
} from 'lucide-react';
import { DriverDeliveryTask } from '../../types';

export const DriverPartnerPortal: React.FC = () => {
  const {
    drivers,
    activeDriverId,
    setActiveDriverId,
    currentDriver,
    toggleDriverOnline,
    driverTasks,
    updateDriverTaskStatus,
    completeDriverDeliveryWithOtp,
    formatPrice,
    showToast,
    setIsLoginModalOpen,
    currentUserSession,
    driverUPI,
    openUPIPinModal,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'trips' | 'wallet' | 'history'>('trips');
  const [selectedTaskId, setSelectedTaskId] = useState<string>(driverTasks[0]?.id || '');
  const [enteredOtp, setEnteredOtp] = useState<string>('');
  const [signatureName, setSignatureName] = useState<string>('');
  const [isVerifyingOtp, setIsVerifyingOtp] = useState<boolean>(false);
  const [isPhotoCaptured, setIsPhotoCaptured] = useState<boolean>(false);

  const activeTask = driverTasks.find((t) => t.id === selectedTaskId) || driverTasks[0];
  const pendingTasks = driverTasks.filter((t) => t.status !== 'Delivered');
  const completedTasks = driverTasks.filter((t) => t.status === 'Delivered');

  const handleVerifyAndDeliver = async () => {
    if (!enteredOtp) {
      showToast('Please enter the 4-digit OTP provided by customer');
      return;
    }
    setIsVerifyingOtp(true);
    const res = await completeDriverDeliveryWithOtp(
      activeTask.id,
      enteredOtp,
      isPhotoCaptured
        ? 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=400&auto=format&fit=crop&q=80'
        : undefined,
      signatureName || `${activeTask.customerName} (Signed)`
    );
    setIsVerifyingOtp(false);
    if (res.success) {
      setEnteredOtp('');
      setSignatureName('');
      setIsPhotoCaptured(false);
    }
  };

  return (
    <div id="driver-partner-portal" className="min-h-screen bg-slate-50 text-slate-900 pb-20">
      {/* Top Driver Bar - Light Theme */}
      <div className="bg-white border-b border-slate-200 px-4 sm:px-8 py-3.5 sticky top-12 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src={currentDriver.avatar}
                alt={currentDriver.name}
                className="w-11 h-11 rounded-full object-cover border-2 border-emerald-500 shadow-sm"
              />
              <span
                className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-white ${
                  currentDriver.isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'
                }`}
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                  {currentDriver.name}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  {currentDriver.badge}
                </span>
                <span className="hidden sm:inline-block text-xs font-semibold text-slate-500">
                  ⭐ {currentDriver.rating} ({currentDriver.completedDeliveries} Deliveries)
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                Vehicle: <strong className="text-slate-800">{currentDriver.vehicleType} ({currentDriver.vehicleNumber})</strong>
                <span className="mx-2 text-slate-300">•</span>
                <span>Phone: <strong className="text-slate-800">{currentDriver.phone}</strong></span>
              </p>
            </div>
          </div>

          {/* Online Toggle, Account Switcher & Auth Trigger */}
          <div className="flex items-center gap-2.5">
            <select
              value={activeDriverId}
              onChange={(e) => setActiveDriverId(e.target.value)}
              className="bg-slate-50 text-slate-800 font-semibold text-xs border border-slate-200 rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-xs"
            >
              {drivers.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.vehicleType})
                </option>
              ))}
            </select>

            <button
              onClick={() => setIsLoginModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs border border-slate-200 transition-all shadow-xs"
            >
              <LogIn className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden sm:inline">Switch / Login</span>
            </button>

            <button
              id="toggle-driver-online-btn"
              onClick={() => toggleDriverOnline(currentDriver.id)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl font-bold text-xs transition-all shadow-sm ${
                currentDriver.isOnline
                  ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                  : 'bg-rose-500 text-white hover:bg-rose-600'
              }`}
            >
              <Power className="w-4 h-4" />
              <span>{currentDriver.isOnline ? 'ONLINE' : 'GO ONLINE'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-3 sm:px-8 mt-4 sm:mt-6">
        {/* KPI Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3.5">
          <div className="bg-white border border-slate-200 p-3 sm:p-4 rounded-2xl shadow-xs min-w-0">
            <span className="text-[11px] sm:text-xs text-slate-500 block font-semibold truncate">Today's Earnings</span>
            <span className="text-lg sm:text-xl md:text-2xl font-black text-emerald-600 mt-0.5 block truncate">
              {formatPrice(currentDriver.todayEarnings)}
            </span>
          </div>

          <div className="bg-white border border-slate-200 p-3 sm:p-4 rounded-2xl shadow-xs min-w-0">
            <span className="text-[11px] sm:text-xs text-slate-500 block font-semibold truncate">Trips Today</span>
            <span className="text-lg sm:text-xl md:text-2xl font-black text-slate-900 mt-0.5 block truncate">
              {currentDriver.todayTrips} trips
            </span>
          </div>

          <div className="bg-white border border-slate-200 p-3 sm:p-4 rounded-2xl shadow-xs min-w-0">
            <span className="text-[11px] sm:text-xs text-slate-500 block font-semibold truncate">Withdrawable Wallet</span>
            <span className="text-lg sm:text-xl md:text-2xl font-black text-amber-600 mt-0.5 block truncate">
              {formatPrice(currentDriver.walletBalance)}
            </span>
          </div>

          <div className="bg-white border border-slate-200 p-3 sm:p-4 rounded-2xl shadow-xs min-w-0">
            <span className="text-[11px] sm:text-xs text-slate-500 block font-semibold truncate">Cash in Hand (COD)</span>
            <span className="text-lg sm:text-xl md:text-2xl font-black text-blue-600 mt-0.5 block truncate">
              {formatPrice(currentDriver.cashInHand)}
            </span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-200 pb-2.5 mt-4 sm:mt-6 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('trips')}
            className={`flex items-center gap-1.5 px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap shrink-0 transition-all ${
              activeTab === 'trips'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Compass className="w-4 h-4 shrink-0" />
            <span>Active Trips ({pendingTasks.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('wallet')}
            className={`flex items-center gap-1.5 px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap shrink-0 transition-all ${
              activeTab === 'wallet'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Wallet className="w-4 h-4 shrink-0" />
            <span>Earnings & Payouts</span>
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`flex items-center gap-1.5 px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap shrink-0 transition-all ${
              activeTab === 'history'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>Delivered History ({completedTasks.length})</span>
          </button>
        </div>

        {/* TAB 1: ACTIVE TRIPS & LIVE DELIVERY EXECUTION */}
        {activeTab === 'trips' && (
          <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Task List Selector (Left 5 cols) */}
            <div className="lg:col-span-5 space-y-3">
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                Assigned Delivery Queue
              </h3>
              {pendingTasks.length === 0 ? (
                <div className="bg-white border border-slate-200 p-8 rounded-2xl text-center text-slate-600 text-xs shadow-xs">
                  <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
                  <p className="font-bold text-slate-800 text-sm">All deliveries completed!</p>
                  <p className="text-slate-500 mt-1">Stay online to accept incoming instant dispatch orders.</p>
                </div>
              ) : (
                pendingTasks.map((t) => {
                  const isSelected = t.id === activeTask?.id;
                  return (
                    <div
                      key={t.id}
                      onClick={() => setSelectedTaskId(t.id)}
                      className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-emerald-50/50 border-emerald-500 shadow-sm ring-1 ring-emerald-500/50'
                          : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
                      }`}
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-slate-900 text-sm">{t.orderId}</span>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            t.paymentMode === 'COD'
                              ? 'bg-amber-50 text-amber-800 border border-amber-200'
                              : 'bg-blue-50 text-blue-700 border border-blue-200'
                          }`}
                        >
                          {t.paymentMode} ({t.paymentMode === 'COD' ? formatPrice(t.codAmountToCollect) : 'PREPAID'})
                        </span>
                      </div>

                      <div className="mt-2.5 space-y-1 text-xs">
                        <p className="font-bold text-slate-900 truncate">Customer: {t.customerName}</p>
                        <p className="text-slate-600 truncate flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          {t.customerAddress}
                        </p>
                      </div>

                      <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px]">
                        <span className="text-emerald-700 font-bold">
                          Fee: {formatPrice(t.payoutFee + t.tipAmount)}
                        </span>
                        <span className="text-slate-500 font-medium">
                          {t.distanceKm} km &bull; {t.estimatedMinutes} mins
                        </span>
                        <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-semibold text-[10px]">
                          {t.status}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Active Trip Execution Console (Right 7 cols) */}
            {activeTask && (
              <div className="lg:col-span-7 space-y-4">
                <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-xs">
                  {/* Top Bar with Live Route Status */}
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-600">
                        Active Waypoint
                      </span>
                      <h2 className="text-base font-bold text-slate-900">
                        Delivery for {activeTask.customerName}
                      </h2>
                    </div>
                    <div className="flex items-center gap-2">
                      <a
                        href={`tel:${activeTask.customerPhone}`}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        <span>Call Customer</span>
                      </a>
                      <button
                        onClick={() => showToast('🚨 Emergency SOS broadcasted to 24/7 Logistics Dispatch Desk.')}
                        className="flex items-center gap-1 px-2.5 py-1.5 bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 rounded-xl text-xs font-bold"
                      >
                        <LifeBuoy className="w-3.5 h-3.5" />
                        <span>SOS</span>
                      </button>
                    </div>
                  </div>

                  {/* Simulated GPS Routing HUD */}
                  <div className="relative bg-slate-900 text-white rounded-xl p-4 my-4 overflow-hidden border border-slate-800 shadow-md">
                    <div className="absolute top-2 right-2 flex items-center gap-1 text-[10px] bg-slate-800 px-2 py-1 rounded-md text-emerald-400 border border-slate-700 font-mono">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                      GPS LIVE (17.4399° N, 78.3989° E)
                    </div>

                    <div className="space-y-3 text-xs">
                      {/* Step 1: Pickup */}
                      <div className="flex items-start gap-3">
                        <div className="w-6 h-6 rounded-full bg-amber-500/20 border border-amber-500 text-amber-300 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                          1
                        </div>
                        <div>
                          <p className="text-[11px] text-slate-400 font-medium">Pickup Point (Seller Hub):</p>
                          <p className="font-bold text-white">{activeTask.sellerName}</p>
                          <p className="text-slate-400 text-[11px]">{activeTask.sellerAddress}</p>
                        </div>
                      </div>

                      {/* Line connector */}
                      <div className="ml-3 w-0.5 h-4 bg-slate-700" />

                      {/* Step 2: Dropoff */}
                      <div className="flex items-start gap-3">
                        <div className="w-6 h-6 rounded-full bg-emerald-500/20 border border-emerald-400 text-emerald-300 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                          2
                        </div>
                        <div>
                          <p className="text-[11px] text-slate-400 font-medium">Dropoff Destination:</p>
                          <p className="font-bold text-white">{activeTask.customerName} ({activeTask.customerPhone})</p>
                          <p className="text-slate-300 text-[11px] font-medium">{activeTask.customerAddress}</p>
                          {activeTask.specialInstructions && (
                            <p className="text-amber-300 text-[11px] mt-1 bg-amber-500/20 p-1.5 rounded border border-amber-500/30">
                              Note: {activeTask.specialInstructions}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Action Step Transitions */}
                    <div className="mt-4 pt-3 border-t border-slate-800 flex flex-wrap items-center gap-2">
                      <button
                        onClick={() => updateDriverTaskStatus(activeTask.id, 'Heading to Pickup')}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg font-medium"
                      >
                        Heading to Pickup
                      </button>
                      <button
                        onClick={() => updateDriverTaskStatus(activeTask.id, 'Picked Up')}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg font-medium"
                      >
                        Package Picked Up
                      </button>
                      <button
                        onClick={() => updateDriverTaskStatus(activeTask.id, 'In Transit')}
                        className="px-2.5 py-1 bg-blue-600 text-white text-xs rounded-lg font-bold"
                      >
                        In Transit
                      </button>
                      <button
                        onClick={() => updateDriverTaskStatus(activeTask.id, 'Arrived at Drop')}
                        className="px-2.5 py-1 bg-emerald-600 text-white text-xs rounded-lg font-bold"
                      >
                        Arrived at Doorstep
                      </button>
                    </div>
                  </div>

                  {/* Delivery Verification & OTP Section */}
                  <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-4">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                      <KeyRound className="w-4 h-4 text-amber-600" />
                      Doorstep Verification & Handover
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* OTP Box */}
                      <div>
                        <label className="text-xs text-slate-700 block mb-1 font-semibold flex items-center justify-between">
                          <span>Enter 4-Digit Customer OTP *</span>
                          <button
                            type="button"
                            onClick={() => {
                              setEnteredOtp(activeTask.otpCode);
                              showToast(`Auto-filled OTP: ${activeTask.otpCode}`);
                            }}
                            className="text-[10px] text-amber-700 hover:text-amber-800 underline font-mono font-bold"
                          >
                            Auto-Fill OTP ({activeTask.otpCode})
                          </button>
                        </label>
                        <input
                          type="text"
                          maxLength={4}
                          placeholder="e.g. 4829"
                          value={enteredOtp}
                          onChange={(e) => setEnteredOtp(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2.5 text-center text-lg font-mono font-bold tracking-widest text-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-xs"
                        />
                        <span className="text-[10px] text-slate-500 mt-1 block">
                          Customer receives this OTP upon placing their order. (Demo code: <strong className="text-amber-700 font-mono">{activeTask.otpCode}</strong>)
                        </span>
                      </div>

                      {/* COD Collection Verification */}
                      <div>
                        <label className="text-xs text-slate-700 block mb-1 font-semibold">
                          Payment Mode
                        </label>
                        <div className="bg-white border border-slate-200 rounded-xl p-2.5 text-xs shadow-xs">
                          {activeTask.paymentMode === 'COD' ? (
                            <div>
                              <span className="text-rose-600 font-bold">COLLECT CASH ON DELIVERY:</span>
                              <span className="text-lg font-black text-slate-900 block mt-0.5">
                                {formatPrice(activeTask.codAmountToCollect)}
                              </span>
                            </div>
                          ) : (
                            <div>
                              <span className="text-emerald-700 font-bold">PREPAID ORDER:</span>
                              <span className="text-slate-600 block text-xs mt-0.5">
                                No payment collection required from customer.
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Proof of delivery attachments */}
                    <div className="flex flex-wrap items-center gap-3 pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setIsPhotoCaptured(!isPhotoCaptured);
                          showToast(isPhotoCaptured ? 'Photo removed' : '📸 Doorstep parcel photo captured!');
                        }}
                        className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border transition-all ${
                          isPhotoCaptured
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                            : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100 shadow-xs'
                        }`}
                      >
                        <Camera className="w-3.5 h-3.5" />
                        <span>{isPhotoCaptured ? '✓ Photo Attached' : 'Capture Parcel Photo'}</span>
                      </button>

                      <div className="flex-1 min-w-[200px]">
                        <input
                          type="text"
                          placeholder="Recipient Name / Signature notes"
                          value={signatureName}
                          onChange={(e) => setSignatureName(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-xs"
                        />
                      </div>
                    </div>

                    {/* Deliver CTA */}
                    <button
                      id="driver-verify-deliver-btn"
                      onClick={handleVerifyAndDeliver}
                      disabled={isVerifyingOtp}
                      className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black py-3 rounded-xl text-sm transition-all shadow-md flex items-center justify-center gap-2"
                    >
                      <CheckCircle2 className="w-5 h-5" />
                      <span>{isVerifyingOtp ? 'Validating Handover...' : 'Confirm Handover & Complete Delivery'}</span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: DRIVER WALLET & PAYOUTS */}
        {activeTab === 'wallet' && (
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 mb-3">
                <Wallet className="w-4 h-4 text-emerald-600" />
                Driver Wallet & Cash Reconciliation
              </h3>

              <div className="space-y-3 text-xs">
                {/* Driver Linked UPI Info */}
                <div className="p-3 bg-emerald-50/60 border border-emerald-200 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs">
                      UPI
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 flex items-center gap-1.5">
                        <span>{driverUPI?.bankName || 'State Bank of India'}</span>
                        <span className="text-[10px] text-slate-500 font-mono">({driverUPI?.accountNumberMask || 'XX9012'})</span>
                      </p>
                      <p className="text-[11px] font-mono text-emerald-700 font-semibold">{driverUPI?.vpa || 'rajesh.express@oksbi'}</p>
                    </div>
                  </div>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full border border-emerald-300">
                    Primary Payout
                  </span>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex justify-between items-center">
                  <div>
                    <span className="text-slate-500 block text-[11px] font-semibold">Available Wallet Payout:</span>
                    <span className="text-2xl font-black text-emerald-600">{formatPrice(currentDriver.walletBalance)}</span>
                  </div>
                  <button
                    onClick={() => {
                      openUPIPinModal({
                        amount: currentDriver.walletBalance,
                        payeeName: `${currentDriver.name} (Direct Bank Payout)`,
                        payeeVpa: driverUPI?.vpa || 'rajesh.express@oksbi',
                        upiApp: driverUPI?.linkedApp || 'phonepe',
                        bankName: driverUPI?.bankName || 'State Bank of India',
                        accountMask: driverUPI?.accountNumberMask || 'XX9012',
                        onSuccess: (utr) => {
                          showToast(`💸 ₹${currentDriver.walletBalance} instant payout settled to ${driverUPI?.vpa}! UTR: ${utr}`);
                        },
                      });
                    }}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-3.5 py-2 rounded-xl text-xs shadow-xs cursor-pointer"
                  >
                    Withdraw via UPI PIN
                  </button>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex justify-between items-center">
                  <div>
                    <span className="text-slate-500 block text-[11px] font-semibold">Cash-in-Hand to Reconcile (COD):</span>
                    <span className="text-2xl font-black text-amber-600">{formatPrice(currentDriver.cashInHand)}</span>
                  </div>
                  <button
                    onClick={() => showToast('🏦 Cash deposit receipt generated for nearest Logistics Hub')}
                    className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold px-3.5 py-2 rounded-xl text-xs cursor-pointer"
                  >
                    Deposit at Hub
                  </button>
                </div>
              </div>
            </div>

            <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 mb-3">
                <DollarSign className="w-4 h-4 text-amber-600" />
                Incentive & Bonus Tier
              </h3>
              <div className="space-y-2 text-xs text-slate-600">
                <div className="flex justify-between py-2 border-b border-slate-100">
                  <span className="font-medium">Base Trip Fare:</span>
                  <span className="font-bold text-slate-900">₹80 / 3 km</span>
                </div>
                <div className="flex justify-between py-2 border-b border-slate-100">
                  <span className="font-medium">Distance Multiplier:</span>
                  <span className="font-bold text-slate-900">₹15 / extra km</span>
                </div>
                <div className="flex justify-between py-2 border-b border-slate-100">
                  <span className="font-medium">Customer Tip Retained:</span>
                  <span className="font-bold text-emerald-600">100% Direct</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="font-medium">Peak Rain/Night Surge Bonus:</span>
                  <span className="font-bold text-amber-600">+₹35 per trip</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: DELIVERED HISTORY */}
        {activeTab === 'history' && (
          <div className="mt-6 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-3">Delivered Order Receipts</h3>
            <div className="divide-y divide-slate-100">
              {completedTasks.map((t) => (
                <div key={t.id} className="py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900">{t.orderId}</span>
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] bg-emerald-50 text-emerald-700 font-bold border border-emerald-200">
                        Delivered
                      </span>
                      <span className="text-slate-500 font-medium">{t.deliveredAt || 'Today'}</span>
                    </div>
                    <p className="text-slate-600 mt-1">
                      Customer: {t.customerName} &bull; OTP: {t.otpCode} &bull; Signature: {t.customerSignature || 'Verified'}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-emerald-700 text-sm">
                      +{formatPrice(t.payoutFee + t.tipAmount)}
                    </span>
                    <span className="text-[10px] text-slate-400 block font-medium">Credited to Wallet</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
