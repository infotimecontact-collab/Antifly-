import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { MobileHomeScreen } from './MobileHomeScreen';
import { MobileSellersScreen } from './MobileSellersScreen';
import { MobileDiscoverScreen } from './MobileDiscoverScreen';
import { MobileAccountScreen } from './MobileAccountScreen';
import { SellerCentralPortal } from '../seller/SellerCentralPortal';
import { DriverPartnerPortal } from '../driver/DriverPartnerPortal';
import { SocialNetworkContainer } from '../social/SocialNetworkContainer';
import {
  Home,
  Store,
  Search,
  User,
  ShoppingBag,
  Sparkles,
  Wifi,
  Battery,
  Signal,
  Mic,
  Camera,
  Layers,
  Truck,
  Heart,
  UserCheck,
} from 'lucide-react';

export const MobileAppContainer: React.FC = () => {
  const {
    deviceMode,
    cart,
    wishlist,
    setIsCartOpen,
    setIsAntiflyAIOpen,
    setIsVoiceSearchOpen,
    setIsImageSearchOpen,
    searchQuery,
    setSearchQuery,
    followedSellerIds,
    openCameraStudio,
  } = useApp();

  const [mobileAppRole, setMobileAppRole] = useState<'customer' | 'seller' | 'driver'>('customer');
  const [activeTab, setActiveTab] = useState<'home' | 'sellers' | 'discover' | 'profile'>('home');
  const [currentTime, setCurrentTime] = useState('9:41');

  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      const hours = d.getHours() % 12 || 12;
      const mins = String(d.getMinutes()).padStart(2, '0');
      setCurrentTime(`${hours}:${mins}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  const isIOS = deviceMode === 'mobile-ios';
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-white/90 py-4 sm:py-8 flex items-center justify-center p-2">
      {/* Smartphone Device Frame */}
      <div
        id="mobile-phone-hardware-frame"
        className={`w-full max-w-[430px] h-[880px] bg-white rounded-[50px] p-3 shadow-2xl border-4 ${
          isIOS ? 'border-slate-700 ring-4 ring-slate-800' : 'border-slate-800 ring-2 ring-slate-700'
        } flex flex-col relative overflow-hidden transition-all duration-300`}
      >
        {/* Device Inner Screen */}
        <div className="w-full h-full bg-slate-50 dark:bg-white rounded-[40px] overflow-hidden flex flex-col relative border border-slate-800 text-slate-900 dark:text-white">
          {/* Native Mobile Status Bar */}
          <div className="px-7 pt-3 pb-1 flex items-center justify-between text-xs font-semibold select-none bg-white/90 dark:bg-white/90 backdrop-blur-sm z-30">
            <span className="font-bold tracking-tight text-xs">{currentTime}</span>

            {/* Dynamic Island for iOS / Punch-hole for Android */}
            {isIOS ? (
              <div className="w-28 h-5 bg-slate-100 rounded-full flex items-center justify-center gap-2 px-2 shadow-inner">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-800" />
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500/80 animate-pulse" />
              </div>
            ) : (
              <div className="w-3.5 h-3.5 rounded-full bg-slate-100 border border-slate-800 shadow-inner" />
            )}

            {/* System Icons */}
            <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
              <Signal className="w-3.5 h-3.5" />
              <Wifi className="w-3.5 h-3.5" />
              <Battery className="w-4 h-4" />
            </div>
          </div>

          {/* In-Phone 4-App Switcher Bar */}
          <div className="px-2 py-1 bg-slate-900 border-b border-slate-800 flex items-center justify-center gap-1 z-20 overflow-x-auto">
            <button
              onClick={() => setMobileAppRole('customer')}
              className={`flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold transition-all whitespace-nowrap ${
                mobileAppRole === 'customer'
                  ? 'bg-amber-500 text-slate-800 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ShoppingBag className="w-3 h-3" />
              <span>Customer</span>
            </button>
            <button
              onClick={() => setMobileAppRole('social' as any)}
              className={`flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold transition-all whitespace-nowrap ${
                (mobileAppRole as any) === 'social'
                  ? 'bg-violet-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3 h-3" />
              <span>AI Social</span>
            </button>
            <button
              onClick={() => setMobileAppRole('seller')}
              className={`flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold transition-all whitespace-nowrap ${
                mobileAppRole === 'seller'
                  ? 'bg-orange-500 text-slate-800 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Store className="w-3 h-3" />
              <span>Venture</span>
            </button>
            <button
              onClick={() => setMobileAppRole('driver')}
              className={`flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold transition-all whitespace-nowrap ${
                mobileAppRole === 'driver'
                  ? 'bg-emerald-500 text-slate-800 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Truck className="w-3 h-3" />
              <span>Buddy</span>
            </button>
          </div>

          {/* Customer Top Bar */}
          {mobileAppRole === 'customer' && (
            <div className="px-4 py-2 bg-white/90 dark:bg-white/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800/80 flex items-center justify-between gap-2 z-20">
              <div
                onClick={() => setActiveTab('home')}
                className="flex items-center gap-1.5 cursor-pointer"
              >
                <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-slate-800 font-black text-xs shadow-sm">
                  Z
                </div>
                <span className="font-extrabold text-sm tracking-tight text-slate-900 dark:text-white">
                  Antifly
                </span>
              </div>

              {/* Quick Search Click to open Discover screen */}
              <div
                onClick={() => setActiveTab('discover')}
                className="flex-1 max-w-[190px] relative cursor-pointer"
              >
                <div className="w-full pl-7 pr-4 py-1.5 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-full text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
                  <span className="truncate">Search products & drops...</span>
                </div>
                <Search className="w-3 h-3 text-slate-400 absolute left-2.5 top-2" />
              </div>

              {/* Bag Icon */}
              <button
                onClick={() => setIsCartOpen(true)}
                className="relative p-2 text-slate-700 dark:text-slate-300 hover:text-amber-500"
              >
                <ShoppingBag className="w-5 h-5" />
                {cartCount > 0 && (
                  <span className="absolute top-1 right-1 bg-amber-500 text-slate-800 font-bold text-[9px] w-4 h-4 rounded-full flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </button>
            </div>
          )}

          {/* Active Screen Body (Scrollable) */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden">
            {mobileAppRole === 'customer' && (
              <>
                {/* PAGE 1: HOME (Nearby Stores + Product Slider) */}
                {activeTab === 'home' && (
                  <MobileHomeScreen
                    onSelectCategory={() => setActiveTab('discover')}
                    onOpenAntiflyAI={() => setIsAntiflyAIOpen(true)}
                    onNavigateToSellers={() => setActiveTab('sellers')}
                    onNavigateToDiscover={() => setActiveTab('discover')}
                  />
                )}

                {/* PAGE 2: SELLERS (All Sellers + Follow Sellers) */}
                {activeTab === 'sellers' && (
                  <MobileSellersScreen />
                )}

                {/* PAGE 3: DISCOVER (Product Search + Recent Seller Images & Drops) */}
                {activeTab === 'discover' && (
                  <MobileDiscoverScreen />
                )}

                {/* PAGE 4: PROFILE (User Account & Followed Sellers) */}
                {activeTab === 'profile' && (
                  <MobileAccountScreen
                    onNavigateToSellers={() => setActiveTab('sellers')}
                    onNavigateToWishlist={() => setActiveTab('discover')}
                  />
                )}
              </>
            )}

            {(mobileAppRole as any) === 'social' && (
              <div className="p-1">
                <SocialNetworkContainer />
              </div>
            )}

            {mobileAppRole === 'seller' && (
              <div className="p-2">
                <SellerCentralPortal />
              </div>
            )}

            {mobileAppRole === 'driver' && (
              <div className="p-2">
                <DriverPartnerPortal />
              </div>
            )}
          </div>

          {/* 4-PAGE SIMPLIFIED NATIVE BOTTOM NAVIGATION BAR */}
          {mobileAppRole === 'customer' && (
            <div className="px-2 py-2 bg-white/95 dark:bg-white/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 flex items-center justify-around z-30 select-none">
              {/* Page 1: Home */}
              <button
                onClick={() => setActiveTab('home')}
                className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all ${
                  activeTab === 'home'
                    ? 'text-amber-600 dark:text-amber-400 font-extrabold'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Home className="w-5 h-5" />
                <span className="text-[10px]">Home</span>
              </button>

              {/* Page 2: Ventures */}
              <button
                onClick={() => setActiveTab('sellers')}
                className={`relative flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all ${
                  activeTab === 'sellers'
                    ? 'text-amber-600 dark:text-amber-400 font-extrabold'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Store className="w-5 h-5" />
                {followedSellerIds.length > 0 && (
                  <span className="absolute top-0.5 right-2 bg-amber-500 text-slate-800 font-black text-[8px] w-3.5 h-3.5 rounded-full flex items-center justify-center">
                    {followedSellerIds.length}
                  </span>
                )}
                <span className="text-[10px]">Ventures</span>
              </button>

              {/* Center Action: Camera Creation Studio */}
              <button
                id="btn-mobile-camera-studio-nav"
                onClick={() => openCameraStudio('photo')}
                className="flex flex-col items-center -mt-4 group"
                title="Camera Studio (AR Lenses, Snaps, Reels)"
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-amber-400 to-orange-500 text-slate-800 flex items-center justify-center shadow-lg shadow-amber-500/30 group-active:scale-95 transition-transform border-2 border-white dark:border-slate-900">
                  <Camera className="w-6 h-6" />
                </div>
                <span className="text-[9px] font-bold text-amber-500 mt-0.5">Studio</span>
              </button>

              {/* Page 3: Discover & Search */}
              <button
                onClick={() => setActiveTab('discover')}
                className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all ${
                  activeTab === 'discover'
                    ? 'text-amber-600 dark:text-amber-400 font-extrabold'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Search className="w-5 h-5" />
                <span className="text-[10px]">Discover</span>
              </button>

              {/* Page 4: Profile */}
              <button
                onClick={() => setActiveTab('profile')}
                className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all ${
                  activeTab === 'profile'
                    ? 'text-amber-600 dark:text-amber-400 font-extrabold'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <User className="w-5 h-5" />
                <span className="text-[10px]">Profile</span>
              </button>
            </div>
          )}

          {/* iOS Bottom Home Bar */}
          {isIOS && (
            <div className="w-32 h-1 bg-slate-400 dark:bg-slate-600 rounded-full mx-auto my-1.5 select-none" />
          )}
        </div>
      </div>
    </div>
  );
};
