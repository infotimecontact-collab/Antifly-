import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Store,
  MapPin,
  Star,
  Clock,
  CheckCircle2,
  UserPlus,
  UserCheck,
  ShoppingBag,
  ExternalLink,
  MessageCircle,
  Sparkles,
  Filter,
  Search,
  Share2,
  UserX,
} from 'lucide-react';

interface MobileSellersScreenProps {
  onSelectSellerCategory?: (category: string) => void;
}

export const MobileSellersScreen: React.FC<MobileSellersScreenProps> = () => {
  const {
    sellers,
    products,
    followedSellerIds,
    toggleFollowSeller,
    isFollowingSeller,
    setActivePdpId,
    setIsUniversalChatOpen,
    openSellerStorefront,
    formatPrice,
    openSellerShareModal,
    openBlockConfirmationModal,
    isSellerBlocked,
    toggleBlockSeller,
  } = useApp();

  const [activeFilter, setActiveFilter] = useState<'all' | 'following'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = ['All', 'Ethnic Wear & Silks', 'Audio & Gadgets', 'Ayurveda & Skincare', 'Handmade Jewelry'];

  const filteredSellers = sellers.filter((seller) => {
    if (activeFilter === 'following' && !followedSellerIds.includes(seller.id)) {
      return false;
    }
    if (selectedCategory !== 'All' && seller.category !== selectedCategory) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        seller.storeName.toLowerCase().includes(q) ||
        seller.warehouseAddress.city.toLowerCase().includes(q) ||
        (seller.category && seller.category.toLowerCase().includes(q))
      );
    }
    return true;
  });

  return (
    <div id="mobile-sellers-screen" className="p-3 space-y-4 text-xs pb-10">
      {/* Header Banner */}
      <div className="p-4 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-800 to-slate-950 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 space-y-1">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold text-[10px]">
            <Store className="w-3.5 h-3.5" />
            <span>Direct from Certified Artisans & Ventures</span>
          </div>
          <h2 className="text-base font-extrabold tracking-tight">Explore & Follow Ventures</h2>
          <p className="text-[11px] text-slate-300">
            Follow your favorite local venture studios to get instant alerts on newly launched products and exclusive discounts.
          </p>
        </div>
        <div className="absolute right-[-10px] bottom-[-10px] opacity-10">
          <Store className="w-32 h-32" />
        </div>
      </div>

      {/* Filter Tabs: All Ventures vs Following */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 p-1 bg-slate-200/70 dark:bg-slate-900 rounded-2xl flex-1 border border-slate-200 dark:border-slate-800">
          <button
            onClick={() => setActiveFilter('all')}
            className={`flex-1 py-1.5 px-3 rounded-xl font-bold text-[11px] transition-all ${
              activeFilter === 'all'
                ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            All Ventures ({sellers.length})
          </button>
          <button
            onClick={() => setActiveFilter('following')}
            className={`flex-1 py-1.5 px-3 rounded-xl font-bold text-[11px] transition-all flex items-center justify-center gap-1 ${
              activeFilter === 'following'
                ? 'bg-white dark:bg-slate-800 text-amber-600 dark:text-amber-400 shadow-xs'
                : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>Following ({followedSellerIds.length})</span>
          </button>
        </div>
      </div>

      {/* Search & Category Filter Chips */}
      <div className="space-y-2">
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search venture by name, city, craft..."
            className="w-full pl-8 pr-4 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl text-[11px] text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-xl text-[10px] font-bold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-amber-500 text-slate-800 shadow-xs'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Venture Cards List */}
      <div className="space-y-3.5">
        {filteredSellers.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 rounded-3xl text-center space-y-2">
            <Store className="w-10 h-10 text-slate-400 mx-auto" />
            <p className="font-bold text-slate-800 dark:text-slate-200">No ventures found</p>
            <p className="text-[11px] text-slate-500">
              {activeFilter === 'following'
                ? "You haven't followed any ventures yet. Explore all ventures and tap follow!"
                : 'Try adjusting your search or category filter.'}
            </p>
          </div>
        ) : (
          filteredSellers.map((seller) => {
            const isFollowed = isFollowingSeller(seller.id);
            const sellerCatalog = products.filter(
              (p) =>
                p.brand?.toLowerCase() === seller.storeName.toLowerCase() ||
                p.specifications?.some((s) => s.value === seller.storeName) ||
                p.tags?.some((t) => t.toLowerCase() === seller.storeName.toLowerCase())
            );
            const previewProducts = sellerCatalog.length > 0 ? sellerCatalog.slice(0, 3) : products.slice(0, 3);

            return (
              <div
                key={seller.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs hover:border-amber-400/50 transition-all"
              >
                {/* Store Cover Image Banner */}
                <div className="h-28 w-full relative overflow-hidden bg-slate-800">
                  <img
                    src={seller.storeBannerImage || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=900'}
                    alt={seller.storeName}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-100/80 via-slate-100/30 to-transparent" />
                  
                  {/* Distance & Delivery Badge */}
                  <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                    <span className="px-2 py-0.5 rounded-full bg-white/80 backdrop-blur-md text-white text-[10px] font-bold border border-white/10 flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-amber-400" />
                      <span>{seller.distanceKm || 1.2} km away</span>
                    </span>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-950/80 backdrop-blur-md text-emerald-300 text-[10px] font-bold border border-emerald-500/30 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-emerald-400" />
                      <span>{seller.deliveryTimeMin || 25} min delivery</span>
                    </span>
                  </div>

                  {/* Rating Tag */}
                  <div className="absolute top-2.5 right-2.5">
                    <span className="px-2 py-0.5 rounded-full bg-amber-500 text-slate-800 text-[10px] font-black flex items-center gap-1 shadow-sm">
                      <Star className="w-3 h-3 fill-slate-950" />
                      <span>{seller.rating}</span>
                    </span>
                  </div>
                </div>

                {/* Store Profile Info & Follow Action */}
                <div className="p-3.5 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <img
                        src={seller.storeAvatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200'}
                        alt={seller.storeName}
                        className="w-12 h-12 rounded-2xl object-cover border-2 border-white dark:border-slate-800 shadow-sm shrink-0"
                      />
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h3 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white leading-tight">
                            {seller.storeName}
                          </h3>
                          <CheckCircle2 className="w-3.5 h-3.5 text-amber-500 fill-amber-500/20 shrink-0" />
                        </div>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                          {seller.category || 'Specialty Merchant'} • {seller.warehouseAddress.city}, {seller.warehouseAddress.state}
                        </p>
                        <div className="flex items-center gap-2 text-[10px] text-slate-600 dark:text-slate-300 mt-1 font-medium">
                          <span>👥 {((seller.followersCount || 12000) + (isFollowed ? 1 : 0)).toLocaleString()} Followers</span>
                          <span>•</span>
                          <span>📦 {seller.totalOrders.toLocaleString()}+ orders</span>
                        </div>
                      </div>
                    </div>

                    {/* Follow / Following Toggle Button */}
                    <button
                      id={`follow-seller-btn-${seller.id}`}
                      onClick={() => toggleFollowSeller(seller.id)}
                      className={`px-3 py-1.5 rounded-xl font-extrabold text-[11px] flex items-center gap-1.5 transition-all shadow-xs shrink-0 ${
                        isFollowed
                          ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-300'
                          : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 shadow-sm'
                      }`}
                    >
                      {isFollowed ? (
                        <>
                          <UserCheck className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                          <span>Following</span>
                        </>
                      ) : (
                        <>
                          <UserPlus className="w-3.5 h-3.5 text-slate-800" />
                          <span>Follow</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Badge Strip */}
                  <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
                    <span className="px-2 py-0.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 text-[9px] font-bold">
                      {seller.badge}
                    </span>
                    <span className="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[9px] font-medium">
                      {seller.fulfillmentType}
                    </span>
                  </div>

                  {/* 3 Product Catalogue Previews */}
                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                        Latest Venture Catalog ({previewProducts.length} items)
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      {previewProducts.map((p) => (
                        <div
                          key={p.id}
                          onClick={() => setActivePdpId(p.id)}
                          className="group bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 rounded-2xl p-1.5 cursor-pointer hover:border-amber-500 transition-all text-left"
                        >
                          <div className="aspect-square rounded-xl overflow-hidden mb-1 relative bg-slate-200">
                            <img
                              src={p.image}
                              alt={p.name}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                            />
                            {p.discountPercentage > 0 && (
                              <span className="absolute top-1 left-1 bg-rose-600 text-white font-extrabold text-[8px] px-1 py-0.2 rounded">
                                {p.discountPercentage}% OFF
                              </span>
                            )}
                          </div>
                          <h4 className="text-[10px] font-bold text-slate-800 dark:text-slate-200 truncate">
                            {p.name}
                          </h4>
                          <p className="text-[10px] font-extrabold text-amber-600 dark:text-amber-400">
                            {formatPrice(p.price)}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Actions Footer */}
                  <div className="flex items-center gap-1.5 pt-1">
                    <button
                      onClick={() => openSellerStorefront(seller.id)}
                      className="flex-1 py-2 px-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-[10px] flex items-center justify-center gap-1 transition-all shadow-xs"
                    >
                      <Store className="w-3.5 h-3.5" />
                      <span>Studio & Drops</span>
                    </button>
                    <button
                      onClick={() => openSellerShareModal(seller)}
                      title="Share Venture Profile"
                      className="py-2 px-2.5 rounded-xl bg-pink-50 dark:bg-pink-950/40 hover:bg-pink-100 text-pink-600 dark:text-pink-400 font-bold text-[10px] flex items-center justify-center gap-1 border border-pink-200 dark:border-pink-800 transition-all"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>Share</span>
                    </button>
                    <button
                      onClick={() => {
                        if (isSellerBlocked(seller.id)) {
                          toggleBlockSeller(seller.id);
                        } else {
                          openBlockConfirmationModal(
                            'seller',
                            seller.id,
                            seller.storeName,
                            seller.storeAvatar,
                            `@${seller.storeName.toLowerCase().replace(/[^a-z0-9]/g, '_')}`
                          );
                        }
                      }}
                      title={isSellerBlocked(seller.id) ? 'Unblock Venture' : 'Block Venture'}
                      className={`p-2 rounded-xl text-[10px] flex items-center justify-center border transition-all ${
                        isSellerBlocked(seller.id)
                          ? 'bg-rose-100 text-rose-700 border-rose-300'
                          : 'bg-slate-100 dark:bg-slate-800 hover:bg-rose-50 text-slate-500 hover:text-rose-600 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      <UserX className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setIsUniversalChatOpen(true)}
                      className="py-2 px-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold text-[10px] flex items-center justify-center gap-1 transition-all"
                    >
                      <MessageCircle className="w-3.5 h-3.5 text-amber-500" />
                      <span>Chat</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
