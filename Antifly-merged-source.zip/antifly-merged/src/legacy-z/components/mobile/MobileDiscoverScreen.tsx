import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../common/ProductCard';
import {
  Search,
  Sparkles,
  SlidersHorizontal,
  Heart,
  Tag,
  Share2,
  ShoppingBag,
  ExternalLink,
  Store,
  Clock,
  ArrowRight,
  Flame,
  CheckCircle2,
} from 'lucide-react';
import { Product } from '../../types';

export const MobileDiscoverScreen: React.FC = () => {
  const {
    products,
    sellers,
    categories,
    setActivePdpId,
    addToCart,
    formatPrice,
    showToast,
    toggleWishlist,
    isInWishlist,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'search' | 'seller_drops'>('search');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState<'popular' | 'price_low' | 'price_high' | 'discount'>('popular');
  const [likedPosts, setLikedPosts] = useState<Record<string, boolean>>({});
  const [postLikesCount, setPostLikesCount] = useState<Record<string, number>>({});

  // Collect all seller recent images
  const allSellerRecentImages = useMemo(() => {
    const images: any[] = [];
    sellers.forEach((seller) => {
      if (seller.recentImages && seller.recentImages.length > 0) {
        seller.recentImages.forEach((img) => {
          images.push({
            ...img,
            sellerDistance: seller.distanceKm || 1.2,
            sellerBadge: seller.badge,
          });
        });
      }
    });
    return images;
  }, [sellers]);

  const handleToggleLikePost = (postId: string, initialLikes: number) => {
    const isCurrentlyLiked = likedPosts[postId];
    setLikedPosts((prev) => ({ ...prev, [postId]: !isCurrentlyLiked }));
    setPostLikesCount((prev) => ({
      ...prev,
      [postId]: (prev[postId] ?? initialLikes) + (isCurrentlyLiked ? -1 : 1),
    }));
    if (!isCurrentlyLiked) {
      showToast('❤️ Added to your Visual Inspiration Lookbook!');
    }
  };

  // Filtered Products for Search Function
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (selectedCategory !== 'all' && p.category !== selectedCategory) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = p.name.toLowerCase().includes(q);
        const matchesCategory = p.category.toLowerCase().includes(q);
        const matchesBrand = p.brand ? p.brand.toLowerCase().includes(q) : false;
        const matchesTags = p.tags?.some((t) => t.toLowerCase().includes(q));
        const matchesKeywords = p.searchKeywords?.some((k) => k.toLowerCase().includes(q));
        return matchesName || matchesCategory || matchesBrand || matchesTags || matchesKeywords;
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price_low') return a.price - b.price;
      if (sortBy === 'price_high') return b.price - a.price;
      if (sortBy === 'discount') return b.discountPercentage - a.discountPercentage;
      return (b.rating || 0) - (a.rating || 0);
    });
  }, [products, searchQuery, selectedCategory, sortBy]);

  const quickFilterTags = [
    { label: 'All Items', value: 'all' },
    { label: 'Ethnic Wear', value: 'ethnic-wear' },
    { label: 'Electronics', value: 'electronics' },
    { label: 'Beauty & Skincare', value: 'beauty' },
    { label: 'Jewelry', value: 'jewelry' },
    { label: 'Footwear', value: 'footwear' },
  ];

  return (
    <div id="mobile-discover-screen" className="p-3 space-y-4 text-xs pb-10">
      {/* Top Discover Navigation Header */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-200/80 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setActiveTab('search')}
          className={`flex-1 py-2 px-3 rounded-xl font-extrabold text-[11px] flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'search'
              ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Search className="w-3.5 h-3.5 text-amber-500" />
          <span>Product Search ({filteredProducts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('seller_drops')}
          className={`flex-1 py-2 px-3 rounded-xl font-extrabold text-[11px] flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'seller_drops'
              ? 'bg-white dark:bg-slate-800 text-amber-600 dark:text-amber-400 shadow-xs'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-500" />
          <span>Recent Venture Drops ({allSellerRecentImages.length})</span>
        </button>
      </div>

      {/* VIEW 1: PRODUCT SEARCH FUNCTION */}
      {activeTab === 'search' && (
        <div className="space-y-3">
          {/* Main Search Input */}
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search 1,000+ products, fabrics, brands..."
              className="w-full pl-9 pr-10 py-2.5 bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 focus:border-amber-500 rounded-2xl text-xs text-slate-900 dark:text-white font-medium focus:outline-none transition-all shadow-xs"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 px-1.5 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-[10px] font-bold text-slate-600 dark:text-slate-300"
              >
                ✕
              </button>
            )}
          </div>

          {/* Quick Category Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
            {quickFilterTags.map((tag) => (
              <button
                key={tag.value}
                onClick={() => setSelectedCategory(tag.value)}
                className={`px-3 py-1 rounded-xl text-[10px] font-bold whitespace-nowrap transition-all ${
                  selectedCategory === tag.value
                    ? 'bg-amber-500 text-slate-800 shadow-xs'
                    : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                {tag.label}
              </button>
            ))}
          </div>

          {/* Filter & Sort Bar */}
          <div className="flex items-center justify-between text-[11px] px-1 text-slate-500">
            <span>
              Showing <strong className="text-slate-900 dark:text-white">{filteredProducts.length}</strong> items
            </span>
            <div className="flex items-center gap-1">
              <span className="text-[10px]">Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-2 py-0.5 text-[10px] font-semibold text-slate-700 dark:text-slate-200 focus:outline-none"
              >
                <option value="popular">Top Rated</option>
                <option value="price_low">Price: Low to High</option>
                <option value="price_high">Price: High to Low</option>
                <option value="discount">Biggest Discount</option>
              </select>
            </div>
          </div>

          {/* Product Results Grid */}
          {filteredProducts.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 rounded-3xl text-center space-y-2">
              <Search className="w-10 h-10 text-slate-400 mx-auto" />
              <p className="font-bold text-slate-800 dark:text-slate-200">No products matched "{searchQuery}"</p>
              <p className="text-[11px] text-slate-500">Try searching for "Silk", "Kurta", "Headphones", or "Silver"</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2.5">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* VIEW 2: RECENT VENTURE IMAGES & PRODUCTS FEED */}
      {activeTab === 'seller_drops' && (
        <div className="space-y-4">
          <div className="p-3 bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-transparent border border-amber-500/30 rounded-2xl flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-800 flex items-center justify-center font-bold">
              <Flame className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-xs text-slate-900 dark:text-white">
                Live From Venture Looms & Studios
              </h3>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                Fresh photos, artisan updates, and product launches uploaded directly by registered ventures.
              </p>
            </div>
          </div>

          {/* Visual Image Posts Feed */}
          <div className="space-y-4">
            {allSellerRecentImages.map((post) => {
              const isLiked = likedPosts[post.id];
              const likes = postLikesCount[post.id] ?? post.likesCount;
              const taggedProduct = products.find((p) => p.id === post.taggedProductId) || products[0];

              return (
                <div
                  key={post.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs hover:border-amber-400/40 transition-all"
                >
                  {/* Venture Header */}
                  <div className="p-3 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <img
                        src={post.sellerAvatar}
                        alt={post.sellerName}
                        className="w-9 h-9 rounded-full object-cover border border-amber-500"
                      />
                      <div>
                        <div className="flex items-center gap-1">
                          <h4 className="font-extrabold text-xs text-slate-900 dark:text-white leading-none">
                            {post.sellerName}
                          </h4>
                          <CheckCircle2 className="w-3 h-3 text-amber-500 fill-amber-500/20" />
                        </div>
                        <span className="text-[10px] text-slate-500 flex items-center gap-1 mt-0.5">
                          <Clock className="w-2.5 h-2.5" />
                          <span>{post.uploadedAt}</span>
                          <span>•</span>
                          <span>{post.sellerDistance} km away</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* High-Res Image Display */}
                  <div className="w-full relative aspect-square bg-white overflow-hidden">
                    <img
                      src={post.imageUrl}
                      alt={post.caption}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    />
                    
                    {/* Tagged Product Instant Buy Pill Overlay */}
                    {post.taggedProductName && (
                      <div
                        onClick={() => setActivePdpId(post.taggedProductId || taggedProduct.id)}
                        className="absolute bottom-3 left-3 right-3 p-2 rounded-2xl bg-white/85 backdrop-blur-md border border-white/20 text-white flex items-center justify-between cursor-pointer hover:bg-white transition-all shadow-lg"
                      >
                        <div className="flex items-center gap-2 truncate pr-2">
                          <Tag className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                          <div className="truncate">
                            <p className="text-[10px] font-bold truncate">{post.taggedProductName}</p>
                            <p className="text-[10px] font-black text-amber-400">
                              {formatPrice(post.taggedProductPrice || taggedProduct.price)}
                            </p>
                          </div>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            addToCart(taggedProduct, 1);
                          }}
                          className="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-slate-800 font-extrabold text-[10px] rounded-xl flex items-center gap-1 shrink-0 shadow-sm"
                        >
                          <ShoppingBag className="w-3 h-3" />
                          <span>Buy</span>
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Actions & Caption */}
                  <div className="p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => handleToggleLikePost(post.id, post.likesCount)}
                          className={`flex items-center gap-1 text-xs font-bold transition-all ${
                            isLiked ? 'text-rose-500' : 'text-slate-600 dark:text-slate-300 hover:text-rose-500'
                          }`}
                        >
                          <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-500' : ''}`} />
                          <span>{likes}</span>
                        </button>

                        <button
                          onClick={() => showToast('🔗 Share link copied to clipboard!')}
                          className="flex items-center gap-1 text-xs font-bold text-slate-600 dark:text-slate-300 hover:text-amber-500"
                        >
                          <Share2 className="w-4 h-4" />
                          <span>Share</span>
                        </button>
                      </div>

                      <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 px-2 py-0.5 rounded-lg border border-amber-200 dark:border-amber-800">
                        {post.sellerBadge}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed">
                      <strong className="text-slate-900 dark:text-white font-extrabold mr-1">
                        {post.sellerName}
                      </strong>
                      {post.caption}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
