import React, { useState, useRef } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../common/ProductCard';
import { RealtimeETABadge } from '../common/RealtimeETABadge';
import {
  Sparkles,
  Zap,
  MapPin,
  Clock,
  Star,
  ChevronRight,
  ChevronLeft,
  Store,
  CheckCircle2,
  UserPlus,
  UserCheck,
  ShoppingBag,
  Gift,
  Coins,
  ArrowRight,
  TrendingUp,
  Tag,
  Heart,
  Camera,
  Radio,
  Layers,
  Plus,
  Hourglass,
  Share2,
  Navigation,
  Truck,
  Bell,
  Filter,
  ChevronDown,
  ChevronUp,
  ExternalLink,
} from 'lucide-react';

interface MobileHomeScreenProps {
  onSelectCategory: () => void;
  onOpenAntiflyAI: () => void;
  onNavigateToSellers?: () => void;
  onNavigateToDiscover?: () => void;
}

export const MobileHomeScreen: React.FC<MobileHomeScreenProps> = ({
  onSelectCategory,
  onOpenAntiflyAI,
  onNavigateToSellers,
  onNavigateToDiscover,
}) => {
  const {
    products,
    categories,
    sellers,
    banners,
    setSelectedCategorySlug,
    applyCouponCode,
    showToast,
    superCoinsBalance,
    setIsSuperCoinsModalOpen,
    followedSellerIds,
    toggleFollowSeller,
    isFollowingSeller,
    setActivePdpId,
    addToCart,
    formatPrice,
    toggleWishlist,
    isInWishlist,
    timeShiftStories,
    openTimeShiftStoryViewer,
    openTimeShiftCamera,
    setIsWhatsNewModalOpen,
    getNearbyInterestedProducts,
    openStockAlertModal,
    isSubscribedToStockAlert,
  } = useApp();

  const [activeBannerIdx, setActiveBannerIdx] = useState(0);
  const [exclusiveToggle, setExclusiveToggle] = useState(true);
  const [selectedHeroCategory, setSelectedHeroCategory] = useState('All');
  const productSliderRef = useRef<HTMLDivElement>(null);

  // App-exclusive banners & nearby matches
  const mobileBanners = banners.filter((b) => b.isActive);
  const flashSaleProducts = products.filter((p) => p.discountPercentage >= 25);
  const sliderProducts = products.filter((p) => p.isFeatured || p.isTrending || p.rating >= 4.7);
  const [nearbyFilter, setNearbyFilter] = useState<'fastest' | 'price_low' | 'rating_high'>('fastest');
  const [expandedNearbyCardId, setExpandedNearbyCardId] = useState<string | null>(null);
  const allNearby = getNearbyInterestedProducts ? getNearbyInterestedProducts() : [];
  const nearbyProducts = [...allNearby]
    .sort((a, b) => {
      if (nearbyFilter === 'fastest') {
        return (a.etaMinutes ?? a.distanceKm * 4) - (b.etaMinutes ?? b.distanceKm * 4);
      }
      if (nearbyFilter === 'price_low') {
        const priceA = a.product.finalPrice ?? a.product.price;
        const priceB = b.product.finalPrice ?? b.product.price;
        return priceA - priceB;
      }
      if (nearbyFilter === 'rating_high') {
        return (b.product.rating ?? 0) - (a.product.rating ?? 0);
      }
      return 0;
    })
    .slice(0, 6);

  const handleShareNearbyProduct = async (e: React.MouseEvent, match: any) => {
    e.stopPropagation();
    const product = match.product;
    const shareTitle = `${product.name} — Available Nearby (${match.distanceKm} km)`;
    const shareText = `Check out "${product.name}" from ${match.seller.storeName} (${match.deliveryType} • ETA ${match.etaMinutes}m) on Antifly!`;
    const shareUrl = `${window.location.origin}/#product-${product.id}`;

    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareText,
          url: shareUrl,
        });
        showToast('✨ Product link shared successfully!');
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          if (navigator.clipboard) {
            navigator.clipboard.writeText(`${shareTitle}\n${shareText}\n${shareUrl}`);
            showToast('🔗 Product link copied! Share via WhatsApp or Instagram.');
          }
        }
      }
    } else {
      if (navigator.clipboard) {
        navigator.clipboard.writeText(`${shareTitle}\n${shareText}\n${shareUrl}`);
        showToast('🔗 Product link copied! Paste into WhatsApp or Instagram.');
      } else {
        showToast(`Shared: ${shareTitle}`);
      }
    }
  };
  
  // Dynamically filter AI recommended products based on selected hero category
  const aiRecommendedProducts = products
    .filter((p) => {
      if (selectedHeroCategory === 'All') return true;
      if (selectedHeroCategory === 'Women') {
        return (
          p.category?.toLowerCase().includes('saree') ||
          p.category?.toLowerCase().includes('anarkali') ||
          p.category?.toLowerCase().includes('women') ||
          p.category?.toLowerCase().includes('dress') ||
          p.name.toLowerCase().includes('saree') ||
          p.name.toLowerCase().includes('anarkali')
        );
      }
      if (selectedHeroCategory === 'Men') {
        return (
          p.category?.toLowerCase().includes('shirt') ||
          p.category?.toLowerCase().includes('men') ||
          p.category?.toLowerCase().includes('kurta') ||
          p.name.toLowerCase().includes('shirt') ||
          p.name.toLowerCase().includes('men')
        );
      }
      if (selectedHeroCategory === 'Accessories') {
        return (
          p.category?.toLowerCase().includes('bag') ||
          p.category?.toLowerCase().includes('accessories') ||
          p.category?.toLowerCase().includes('jewelry') ||
          p.name.toLowerCase().includes('handbag') ||
          p.name.toLowerCase().includes('watch')
        );
      }
      if (selectedHeroCategory === 'Silks') {
        return (
          p.category?.toLowerCase().includes('silk') ||
          p.name.toLowerCase().includes('silk') ||
          p.tags?.some((t) => t.toLowerCase().includes('silk'))
        );
      }
      return true;
    })
    .slice(0, 6);

  const scrollProductSlider = (direction: 'left' | 'right') => {
    if (productSliderRef.current) {
      const scrollAmount = direction === 'left' ? -220 : 220;
      productSliderRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  const handleApplyAppCoupon = async (code: string) => {
    const res = await applyCouponCode(code);
    showToast(res.message);
  };

  return (
    <div id="mobile-home-screen" className="p-3 space-y-4 text-xs pb-10">
      {/* TIME-SHIFT 3D LIVING STORIES TRAY */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            <span className="font-black text-xs text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1">
              <Radio className="w-3.5 h-3.5 text-fuchsia-500" />
              Time-Shift 3D Stories
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setIsWhatsNewModalOpen(true)}
              className="text-[10px] font-extrabold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full flex items-center gap-1 border border-emerald-500/20"
            >
              <Sparkles className="w-3 h-3" />
              What's New
            </button>
            <span className="text-[10px] font-extrabold text-fuchsia-500 dark:text-fuchsia-400 bg-fuchsia-50 dark:bg-fuchsia-950/60 px-2 py-0.5 rounded-full flex items-center gap-1">
              <Hourglass className="w-3 h-3" />
              2h
            </span>
          </div>
        </div>

        {/* Stories Horizontal Slider */}
        <div className="flex items-center gap-2.5 overflow-x-auto no-scrollbar py-1">
          {/* Create Story Button */}
          <button
            onClick={openTimeShiftCamera}
            className="flex flex-col items-center shrink-0 group focus:outline-hidden"
          >
            <div className="relative w-16 h-16 rounded-full p-0.5 border-2 border-dashed border-fuchsia-500 bg-gradient-to-tr from-violet-500/20 to-fuchsia-500/20 flex items-center justify-center group-hover:scale-105 transition-transform">
              <div className="w-full h-full rounded-full bg-gradient-to-tr from-violet-600 to-fuchsia-600 text-white flex items-center justify-center shadow-md">
                <Plus className="w-6 h-6" />
              </div>
            </div>
            <span className="text-[10px] font-bold text-slate-700 dark:text-slate-300 mt-1 max-w-[64px] truncate">
              Your 3D
            </span>
          </button>

          {/* Living Stories */}
          {timeShiftStories.map((story) => {
            const expiresAtMs = new Date(story.expiresAt).getTime();
            const minutesLeft = Math.max(
              1,
              Math.floor((expiresAtMs - Date.now()) / (1000 * 60))
            );
            return (
              <button
                key={story.id}
                onClick={() => openTimeShiftStoryViewer(story)}
                className="flex flex-col items-center shrink-0 group focus:outline-hidden relative"
              >
                <div className="relative w-16 h-16 rounded-full p-[2.5px] bg-gradient-to-tr from-amber-400 via-fuchsia-500 to-violet-600 group-hover:scale-105 transition-transform shadow-md">
                  <img
                    src={story.mediaUrl}
                    alt={story.authorName}
                    className="w-full h-full rounded-full object-cover ring-2 ring-white dark:ring-slate-900"
                  />
                  <span className="absolute -top-1 -right-1 bg-violet-600 text-white text-[8px] font-black px-1.5 py-0.2 rounded-full shadow-xs">
                    3D
                  </span>
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-white/90 text-amber-300 text-[8px] font-black px-1.5 py-0.2 rounded-full whitespace-nowrap border border-amber-400/40">
                    {minutesLeft}m
                  </span>
                </div>
                <span className="text-[10px] font-extrabold text-slate-800 dark:text-slate-200 mt-1.5 max-w-[64px] truncate">
                  {(story.authorName || '').split(' ')[0]}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* LUXURY HERO BANNER (ShopieQ Style from Figma/Mockup) */}
      <div className="relative rounded-[32px] overflow-hidden bg-slate-900 shadow-xl border border-slate-800">
        <div className="relative h-64 w-full">
          <img
            src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=900&auto=format&fit=crop&q=80"
            alt="New Arrivals"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950/70 via-transparent to-transparent" />

          {/* Hero Content Overlay */}
          <div className="absolute inset-0 p-5 flex flex-col justify-between text-white z-10">
            <div className="space-y-1">
              <span className="text-[11px] font-semibold text-amber-300 tracking-wider uppercase">
                New Arrivals
              </span>
              <h2 className="text-2xl font-black tracking-tight leading-tight max-w-[200px]">
                Elevate Your Everyday
              </h2>
              <p className="text-[11px] text-slate-300 max-w-[210px] leading-snug">
                Explore the latest in luxury fashion & boutique lifestyle.
              </p>
            </div>

            {/* Quick Hero Category Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-2">
              {[
                { name: 'All', avatar: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=100' },
                { name: 'Women', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100' },
                { name: 'Men', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100' },
                { name: 'Accessories', avatar: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=100' },
                { name: 'Silks', avatar: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=100' },
              ].map((item) => (
                <button
                  key={item.name}
                  onClick={() => setSelectedHeroCategory(item.name)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-bold backdrop-blur-md transition-all shrink-0 ${
                    selectedHeroCategory === item.name
                      ? 'bg-white/90 text-slate-800 shadow-md ring-1 ring-amber-400'
                      : 'bg-slate-100/40 text-white/90 hover:bg-slate-100/60 border border-white/10'
                  }`}
                >
                  <img
                    src={item.avatar}
                    alt={item.name}
                    className="w-4 h-4 rounded-full object-cover border border-amber-400"
                  />
                  <span>{item.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* AI-POWERED RECOMMENDATIONS GLASS CARD */}
      <div className="p-3.5 bg-slate-900/90 dark:bg-slate-900/90 backdrop-blur-md rounded-3xl border border-amber-500/30 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-amber-500/20 flex items-center justify-center text-amber-400">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
            <div>
              <h3 className="font-extrabold text-xs text-white">AI-Powered Recommendations</h3>
              <p className="text-[10px] text-slate-400">Handpicked for your style preference</p>
            </div>
          </div>

          <button
            onClick={onNavigateToDiscover}
            className="px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/20 text-amber-300 font-bold text-[10px] transition-all"
          >
            View All
          </button>
        </div>

        {/* AI Recommendations Horizontal Cards */}
        <div className="flex items-center gap-2.5 overflow-x-auto no-scrollbar pb-1">
          {aiRecommendedProducts.map((prod, idx) => {
            const isWish = isInWishlist(prod.id);
            const isHighlighted = idx === 1;
            return (
              <div
                key={prod.id}
                onClick={() => setActivePdpId(prod.id)}
                className={`w-36 shrink-0 rounded-2xl overflow-hidden p-2 bg-white/80 cursor-pointer transition-all duration-200 ${
                  isHighlighted
                    ? 'border-2 border-amber-400 shadow-md shadow-amber-500/20 ring-2 ring-amber-400/20 scale-[1.02]'
                    : 'border border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="relative aspect-square rounded-xl overflow-hidden bg-slate-900 mb-1.5">
                  <img src={prod.image} alt={prod.name} className="w-full h-full object-cover" />
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleWishlist(prod.id);
                    }}
                    className="absolute top-1.5 right-1.5 p-1 rounded-full bg-slate-100/50 backdrop-blur-xs text-white hover:text-rose-500 transition-colors"
                  >
                    <Heart className={`w-3 h-3 ${isWish ? 'fill-rose-500 text-rose-500' : ''}`} />
                  </button>
                </div>
                <h4 className="font-bold text-[10px] text-white truncate">{prod.name}</h4>
                <p className="font-extrabold text-[11px] text-amber-400 mt-0.5">
                  {formatPrice(prod.price)}
                </p>
              </div>
            );
          })}
        </div>

        {/* Exclusive Switch Row */}
        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
          <div>
            <h4 className="font-bold text-xs text-white">Exclusive for You</h4>
            <p className="text-[10px] text-slate-400">Special offers on boutique premium picks</p>
          </div>
          <button
            onClick={() => setExclusiveToggle(!exclusiveToggle)}
            className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
              exclusiveToggle ? 'bg-amber-500' : 'bg-slate-700'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${
                exclusiveToggle ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* 1. App-Only Voucher Header Bar */}
      <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 text-slate-800 flex items-center justify-between shadow-md">
        <div className="space-y-0.5">
          <div className="flex items-center gap-1 font-extrabold text-[11px] uppercase tracking-wider">
            <Gift className="w-3.5 h-3.5" />
            <span>App-Only Perk: 15% OFF</span>
          </div>
          <p className="text-[10px] font-medium opacity-90">
            Use code <strong className="font-mono bg-white/40 px-1 py-0.5 rounded text-slate-800 font-bold">APPEXCLUSIVE15</strong>
          </p>
        </div>
        <button
          onClick={() => handleApplyAppCoupon('APPEXCLUSIVE15')}
          className="bg-white text-white font-bold px-3 py-1.5 rounded-xl text-[10px] shadow-sm hover:bg-slate-900 transition-all"
        >
          Claim
        </button>
      </div>

      {/* ========================================================= */}
      {/* SECTION 1: ALL NEARBY VENTURES */}
      {/* ========================================================= */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5">
              <Store className="w-4 h-4 text-amber-500" />
              <h2 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white uppercase tracking-wider">
                Nearby Ventures & Studios
              </h2>
            </div>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5">
              <MapPin className="w-2.5 h-2.5 text-amber-500" />
              <span>Delivering in 20-35 mins around your area</span>
            </p>
          </div>

          {onNavigateToSellers && (
            <button
              onClick={onNavigateToSellers}
              className="text-[11px] font-bold text-amber-600 dark:text-amber-400 flex items-center gap-0.5 hover:underline"
            >
              <span>View All</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          )}
        </div>

        {/* Nearby Ventures Horizontal Cards List */}
        <div className="flex items-center gap-3 overflow-x-auto no-scrollbar pb-1">
          {sellers.map((seller) => {
            const isFollowed = isFollowingSeller(seller.id);
            return (
              <div
                key={seller.id}
                className="w-56 shrink-0 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs hover:border-amber-400/60 transition-all"
              >
                {/* Venture Banner */}
                <div className="h-20 w-full relative overflow-hidden bg-slate-800">
                  <img
                    src={seller.storeBannerImage || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600'}
                    alt={seller.storeName}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-100/70 to-transparent" />
                  <div className="absolute top-1.5 left-1.5 flex items-center gap-1">
                    <span className="px-1.5 py-0.5 rounded-md bg-white/80 backdrop-blur-xs text-white text-[9px] font-bold">
                      📍 {seller.distanceKm || 1.2} km
                    </span>
                  </div>
                  <div className="absolute top-1.5 right-1.5">
                    <span className="px-1.5 py-0.5 rounded-md bg-amber-500 text-slate-800 text-[9px] font-black flex items-center gap-0.5">
                      <Star className="w-2.5 h-2.5 fill-slate-950" />
                      <span>{seller.rating}</span>
                    </span>
                  </div>
                </div>

                {/* Venture Body */}
                <div className="p-2.5 space-y-2">
                  <div className="flex items-center gap-2">
                    <img
                      src={seller.storeAvatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200'}
                      alt={seller.storeName}
                      className="w-8 h-8 rounded-xl object-cover border border-amber-500 shrink-0"
                    />
                    <div className="truncate">
                      <h4 className="font-extrabold text-[11px] text-slate-900 dark:text-white truncate">
                        {seller.storeName}
                      </h4>
                      <p className="text-[9px] text-slate-500 truncate">
                        {seller.category || 'Specialty Venture'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[9px] text-slate-500 border-t border-slate-100 dark:border-slate-800 pt-1.5">
                    <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold">
                      <Clock className="w-2.5 h-2.5" />
                      <span>{seller.deliveryTimeMin || 25} mins</span>
                    </span>

                    {/* Follow button */}
                    <button
                      onClick={() => toggleFollowSeller(seller.id)}
                      className={`px-2 py-0.5 rounded-lg text-[9px] font-bold transition-all ${
                        isFollowed
                          ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                          : 'bg-amber-500 text-slate-800 hover:bg-amber-600'
                      }`}
                    >
                      {isFollowed ? '✓ Following' : '+ Follow'}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ========================================================= */}
      {/* SECTION 1.5: NEARBY PRODUCTS MATCHING VIBE */}
      {/* ========================================================= */}
      {nearbyProducts.length > 0 && (
        <div className="space-y-2.5">
          <div className="flex items-center justify-between gap-2">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1.5">
                  <Truck className="w-4 h-4 text-emerald-500" />
                  <h2 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white uppercase tracking-wider">
                    Nearby Fast Delivery
                  </h2>
                </div>

                {/* Filter By Dropdown */}
                <div className="inline-flex items-center gap-1 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2 py-0.5 text-[11px]">
                  <Filter className="w-3 h-3 text-emerald-500 shrink-0" />
                  <label htmlFor="mobile-nearby-filter-select" className="text-[10px] font-semibold text-slate-500 dark:text-slate-400">
                    Filter by:
                  </label>
                  <select
                    id="mobile-nearby-filter-select"
                    value={nearbyFilter}
                    onChange={(e) => setNearbyFilter(e.target.value as 'fastest' | 'price_low' | 'rating_high')}
                    className="bg-transparent text-[11px] font-bold text-slate-800 dark:text-slate-100 focus:outline-none cursor-pointer"
                  >
                    <option value="fastest" className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100">
                      Fastest Delivery
                    </option>
                    <option value="price_low" className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100">
                      Lowest Price
                    </option>
                    <option value="rating_high" className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100">
                      Highest Rated
                    </option>
                  </select>
                </div>
              </div>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                Artisan items in your radius with instant hyper-local shipping
              </p>
            </div>
            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full shrink-0">
              ⚡ 20-45m
            </span>
          </div>

          <motion.div
            key={nearbyFilter}
            className="flex items-stretch gap-3 overflow-x-auto no-scrollbar pb-1"
            initial="hidden"
            animate="visible"
            variants={{
              hidden: { opacity: 0 },
              visible: {
                opacity: 1,
                transition: {
                  staggerChildren: 0.08,
                  delayChildren: 0.05,
                },
              },
            }}
          >
            {nearbyProducts.map((match) => {
              const isOutOfStock =
                (match.product.totalStock ?? match.product.stock ?? 0) <= 0 || match.stockCount <= 0;
              const isStockAlertSubscribed = isSubscribedToStockAlert(match.product.id);
              const isExpanded = expandedNearbyCardId === match.product.id;

              return (
                <motion.div
                  key={match.product.id}
                  layout
                  layoutId={`mobile-nearby-card-${match.product.id}`}
                  transition={{
                    layout: { duration: 0.35, ease: [0.22, 1, 0.36, 1] },
                    opacity: { duration: 0.2 },
                  }}
                  variants={{
                    hidden: { opacity: 0, y: 22 },
                    visible: {
                      opacity: 1,
                      y: 0,
                      transition: {
                        duration: 0.45,
                        ease: [0.22, 1, 0.36, 1],
                      },
                    },
                  }}
                  onClick={() => {
                    setExpandedNearbyCardId(isExpanded ? null : match.product.id);
                  }}
                  className={`w-52 shrink-0 bg-white dark:bg-slate-900 border rounded-2xl overflow-hidden shadow-xs flex flex-col justify-between group transition-all cursor-pointer ${
                    isExpanded
                      ? 'border-emerald-500 ring-2 ring-emerald-500/20 shadow-lg'
                      : 'border-slate-200 dark:border-slate-800 hover:border-emerald-500/60'
                  }`}
                >
                  {isExpanded ? (
                    /* Expanded Summary View in Mobile Card */
                    <div
                      className="p-2.5 flex flex-col justify-between h-full space-y-2 select-text"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {/* Mini Header */}
                      <div className="flex items-start justify-between gap-1.5 pb-1.5 border-b border-slate-100 dark:border-slate-800">
                        <div className="flex items-center gap-2 min-w-0">
                          <img
                            src={match.product.images[0]}
                            alt={match.product.name}
                            className="w-8 h-8 rounded-lg object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                          />
                          <div className="min-w-0">
                            <h4 className="font-extrabold text-[10px] text-slate-900 dark:text-white truncate">
                              {match.product.name}
                            </h4>
                            <span className="text-[10px] font-black text-emerald-600">
                              {formatPrice(match.product.price)}
                            </span>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setExpandedNearbyCardId(null);
                          }}
                          className="p-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-500 shrink-0"
                        >
                          <ChevronUp className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Store Rating */}
                      <div className="bg-slate-50 dark:bg-slate-800/80 rounded-xl p-2 border border-slate-200/70 dark:border-slate-700/70 space-y-1">
                        <div className="flex items-center justify-between text-[10px] gap-1">
                          <div className="flex items-center gap-1 min-w-0">
                            <span className="font-bold text-slate-800 dark:text-slate-200 truncate max-w-[80px]">
                              {match.seller.storeName}
                            </span>
                            <span className="inline-flex items-center px-1 py-0.2 rounded-full text-[8px] font-black bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700/60 shrink-0">
                              {match.distanceKm} km away
                            </span>
                          </div>
                          <div className="flex items-center text-amber-500 gap-0.5 shrink-0">
                            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                            <span className="font-extrabold text-slate-900 dark:text-white">
                              {match.seller.rating || 4.9}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center justify-between text-[9px] text-slate-500">
                          <span>{match.seller.city || 'Hub'}</span>
                          <span className="text-emerald-600 font-bold">99.2% on-time</span>
                        </div>
                      </div>

                      {/* Delivery Map Snippet */}
                      <div className="group/map bg-white text-white rounded-xl p-2 border border-slate-800 hover:border-emerald-500/50 transition-all duration-300 space-y-1.5 cursor-pointer">
                        <div className="flex items-center justify-between text-[9px] font-bold text-emerald-400">
                          <span className="flex items-center gap-1 group-hover/map:text-emerald-300 transition-colors">
                            <Navigation className="w-2.5 h-2.5 group-hover/map:rotate-12 transition-transform" />
                            <span>Route Radar</span>
                          </span>
                          <div className="flex items-center gap-1">
                            <span className="inline-flex items-center gap-0.5 px-1 py-0.2 rounded bg-emerald-500/20 group-hover/map:bg-emerald-500/30 border border-emerald-400/40 text-emerald-300 text-[8px] font-black group-hover/map:shadow-[0_0_6px_rgba(52,211,153,0.5)] transition-all">
                              <Zap className="w-2 h-2 fill-amber-400 text-amber-400 animate-pulse" />
                              Fastest Path
                            </span>
                            <span className="text-slate-300">{match.etaMinutes}m ETA</span>
                          </div>
                        </div>
                        <div className="flex items-center justify-between text-[9px] text-slate-300">
                          <span className="truncate max-w-[55px]">{match.seller.city}</span>
                          <div className="flex-1 mx-1.5 relative h-4 flex items-center justify-center">
                            {/* SVG mini routes with hover glow */}
                            <svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox="0 0 100 16">
                              {/* Alternate detour */}
                              <path
                                d="M 5,8 C 30,14 70,2 95,8"
                                fill="none"
                                stroke="#475569"
                                strokeWidth="1"
                                strokeDasharray="2 2"
                                strokeOpacity="0.5"
                                className="transition-opacity duration-300 group-hover/map:stroke-opacity-30"
                              />
                              {/* Active fastest path */}
                              <path
                                d="M 5,8 C 30,2 70,14 95,8"
                                fill="none"
                                stroke="#10b981"
                                strokeWidth="2"
                                strokeLinecap="round"
                                className="transition-all duration-300 group-hover/map:stroke-emerald-300 group-hover/map:stroke-[2.8] group-hover/map:[filter:drop-shadow(0_0_6px_rgba(52,211,153,0.9))]"
                                style={{
                                  filter: 'drop-shadow(0 0 1px rgba(16,185,129,0.5))',
                                }}
                              />
                            </svg>
                            <span className="w-2 h-2 rounded-full bg-emerald-400 absolute left-1/2 -translate-x-1/2 shadow-xs shadow-emerald-400 animate-ping group-hover/map:scale-125" />
                            <span className="w-2 h-2 rounded-full bg-emerald-400 absolute left-1/2 -translate-x-1/2 group-hover/map:bg-emerald-300" />
                          </div>
                          <span className="truncate max-w-[55px]">You</span>
                        </div>
                        <div className="flex items-center justify-between text-[8px] text-slate-400">
                          <span className="text-emerald-400 group-hover/map:text-emerald-300 font-bold flex items-center gap-0.5 transition-colors">
                            <Zap className="w-2 h-2 fill-amber-400 text-amber-400" />
                            {match.distanceKm} km direct corridor
                          </span>
                          <span className="text-slate-500">2 routes</span>
                        </div>
                      </div>

                      {/* Action Button */}
                      {isOutOfStock ? (
                        <button
                          id={`mobile-expanded-notify-btn-${match.product.id}`}
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            openStockAlertModal(match.product);
                          }}
                          className="w-full py-1.5 rounded-xl text-[10px] font-bold bg-gradient-to-r from-amber-500 to-orange-500 text-slate-800 flex items-center justify-center gap-1"
                        >
                          <Bell className="w-3 h-3" />
                          <span>Notify Me</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            addToCart({
                              productId: match.product.id,
                              variantId: 'default',
                              productName: match.product.name,
                              brand: match.product.brand,
                              color: match.product.colors[0]?.name || 'Standard',
                              size: match.product.sizes[0] || 'Standard',
                              price: match.product.price,
                              mrp: match.product.mrp,
                              image: match.product.images[0],
                              quantity: 1,
                              stock: match.product.totalStock,
                            });
                            showToast(`⚡ Added "${match.product.name}" to cart!`);
                          }}
                          className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[10px] font-bold flex items-center justify-center gap-1 shadow-xs"
                        >
                          <ShoppingBag className="w-3 h-3" />
                          <span>Express Buy</span>
                        </button>
                      )}
                    </div>
                  ) : (
                    /* Standard Collapsed View in Mobile Card */
                    <>
                      <div className="relative overflow-hidden aspect-[4/3] bg-slate-100 dark:bg-slate-800">
                        <img
                          src={match.product.images[0]}
                          alt={match.product.name}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActivePdpId(match.product.id);
                          }}
                          className={`w-full h-full object-cover cursor-pointer group-hover:scale-105 transition-transform duration-300 ${
                            isOutOfStock ? 'grayscale-[30%] opacity-90' : ''
                          }`}
                        />
                        {/* Delivery & Out of Stock Badges */}
                        <div className="absolute top-1.5 left-1.5 flex flex-col gap-1">
                          <span className="bg-emerald-600 text-white text-[8px] font-black uppercase px-1.5 py-0.5 rounded shadow-xs flex items-center gap-0.5">
                            <Truck className="w-2.5 h-2.5" /> {match.deliveryType}
                          </span>
                          {isOutOfStock && (
                            <span className="bg-rose-600/95 text-white text-[8px] font-black uppercase px-1.5 py-0.5 rounded shadow-xs flex items-center gap-0.5">
                              <span className="w-1 h-1 rounded-full bg-white animate-ping" />
                              Sold Out
                            </span>
                          )}
                        </div>

                        {/* Top-Right: Distance + Share */}
                        <div className="absolute top-1.5 right-1.5 flex items-center gap-1 z-10">
                          <span className="bg-white/80 backdrop-blur-xs text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
                            <Navigation className="w-2.5 h-2.5 text-emerald-400" />
                            {match.distanceKm}km
                          </span>
                          <button
                            id={`mobile-nearby-share-btn-${match.product.id}`}
                            type="button"
                            onClick={(e) => handleShareNearbyProduct(e, match)}
                            className="w-6 h-6 rounded-full bg-white/85 hover:bg-emerald-600 backdrop-blur-xs text-white flex items-center justify-center transition-all shadow-xs cursor-pointer border border-white/20 hover:scale-110 active:scale-95"
                            title="Share product link (WhatsApp, Instagram, Web Share)"
                          >
                            <Share2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      <div className="p-2.5 flex-1 flex flex-col justify-between space-y-2">
                        <div
                          onClick={(e) => {
                            e.stopPropagation();
                            setActivePdpId(match.product.id);
                          }}
                          className="cursor-pointer space-y-0.5"
                        >
                          <div className="flex items-center justify-between text-[9px] text-slate-400">
                            <span className="truncate max-w-[95px]">{match.seller.storeName}</span>
                            <RealtimeETABadge
                              initialMinutes={match.etaMinutes}
                              compact
                              id={`mobile-nearby-eta-tag-${match.product.id}`}
                            />
                          </div>
                          <h4 className="font-bold text-[11px] text-slate-900 dark:text-white line-clamp-1">
                            {match.product.name}
                          </h4>
                          <div className="flex items-baseline gap-1 pt-0.5">
                            <span className="font-extrabold text-xs text-emerald-600 dark:text-emerald-400">
                              {formatPrice(match.product.price)}
                            </span>
                            {match.product.mrp && match.product.mrp > match.product.price && (
                              <span className="text-[9px] text-slate-400 line-through">
                                {formatPrice(match.product.mrp)}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Interactive In-Card Expansion Hint */}
                        <div
                          onClick={(e) => {
                            e.stopPropagation();
                            setExpandedNearbyCardId(match.product.id);
                          }}
                          className="pt-1.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[10px] text-emerald-600 font-bold cursor-pointer"
                        >
                          <span>Store &amp; Route Map</span>
                          <ChevronDown className="w-3 h-3" />
                        </div>

                        {isOutOfStock ? (
                          <button
                            id={`mobile-nearby-notify-btn-${match.product.id}`}
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              openStockAlertModal(match.product);
                            }}
                            className={`w-full py-1.5 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer ${
                              isStockAlertSubscribed
                                ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-700/60'
                                : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 font-extrabold'
                            }`}
                            title={
                              isStockAlertSubscribed
                                ? 'Stock alert active — click to test restock push notification'
                                : 'Notify me when restocked at nearby store'
                            }
                          >
                            <Bell
                              className={`w-3 h-3 ${
                                isStockAlertSubscribed
                                  ? 'fill-emerald-500 text-emerald-500'
                                  : 'fill-slate-950 text-slate-800'
                              }`}
                            />
                            <span>{isStockAlertSubscribed ? 'Alert Active' : 'Notify Me'}</span>
                          </button>
                        ) : (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              addToCart({
                                productId: match.product.id,
                                variantId: 'default',
                                productName: match.product.name,
                                brand: match.product.brand,
                                color: match.product.colors[0]?.name || 'Standard',
                                size: match.product.sizes[0] || 'Standard',
                                price: match.product.price,
                                mrp: match.product.mrp,
                                image: match.product.images[0],
                                quantity: 1,
                                stock: match.product.totalStock,
                              });
                              showToast(`⚡ Added "${match.product.name}" to cart!`);
                            }}
                            className="w-full py-1.5 bg-slate-900 hover:bg-emerald-600 text-white rounded-xl text-[10px] font-bold flex items-center justify-center gap-1 transition-all shadow-xs cursor-pointer"
                          >
                            <Plus className="w-3 h-3 text-emerald-400" />
                            <span>Quick Add</span>
                          </button>
                        )}
                      </div>
                    </>
                  )}
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SECTION 2: PRODUCTS SLIDER */}
      {/* ========================================================= */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-amber-500" />
              <h2 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white uppercase tracking-wider">
                Featured Product Slider
              </h2>
            </div>
            <p className="text-[10px] text-slate-500 dark:text-slate-400">
              Swipe to explore trending artisan & brand drops
            </p>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => scrollProductSlider('left')}
              className="p-1.5 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 transition-all"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => scrollProductSlider('right')}
              className="p-1.5 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 transition-all"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Horizontal Slider Track */}
        <div
          ref={productSliderRef}
          className="flex items-stretch gap-3 overflow-x-auto no-scrollbar scroll-smooth pb-2"
        >
          {sliderProducts.map((product) => (
            <div
              key={product.id}
              className="w-44 shrink-0 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs flex flex-col justify-between group hover:border-amber-500 transition-all"
            >
              <div
                onClick={() => setActivePdpId(product.id)}
                className="cursor-pointer"
              >
                {/* Product Image Box */}
                <div className="aspect-[4/3] relative overflow-hidden bg-slate-100 dark:bg-slate-800">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  {product.discountPercentage > 0 && (
                    <span className="absolute top-1.5 left-1.5 bg-rose-600 text-white font-black text-[9px] px-1.5 py-0.5 rounded-md shadow-xs">
                      {product.discountPercentage}% OFF
                    </span>
                  )}
                  {product.rating >= 4.8 && (
                    <span className="absolute top-1.5 right-1.5 bg-white/80 backdrop-blur-xs text-amber-400 font-bold text-[9px] px-1.5 py-0.5 rounded-md flex items-center gap-0.5">
                      ★ {product.rating}
                    </span>
                  )}
                </div>

                {/* Product Metadata */}
                <div className="p-2.5 space-y-1">
                  <span className="text-[9px] font-semibold text-slate-400 block truncate">
                    {product.brand || 'Artisan Direct'}
                  </span>
                  <h4 className="font-bold text-[11px] text-slate-900 dark:text-white line-clamp-1 leading-tight">
                    {product.name}
                  </h4>
                  <div className="flex items-baseline gap-1.5 pt-0.5">
                    <span className="font-extrabold text-xs text-amber-600 dark:text-amber-400">
                      {formatPrice(product.price)}
                    </span>
                    {product.mrp && product.mrp > product.price && (
                      <span className="text-[9px] text-slate-400 line-through">
                        {formatPrice(product.mrp)}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* 1-Tap Add to Cart Button */}
              <div className="p-2 pt-0">
                <button
                  onClick={() => addToCart(product, 1)}
                  className="w-full py-1.5 px-2 bg-slate-900 dark:bg-slate-800 hover:bg-amber-500 hover:text-slate-800 text-white rounded-xl font-extrabold text-[10px] flex items-center justify-center gap-1 transition-all shadow-xs"
                >
                  <ShoppingBag className="w-3 h-3" />
                  <span>Add to Cart</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Category Story Circles */}
      <div className="space-y-2">
        <h3 className="font-extrabold text-xs text-slate-900 dark:text-white uppercase tracking-wider">
          Explore Categories
        </h3>
        <div className="flex items-center gap-3 overflow-x-auto pb-1 no-scrollbar">
          {categories.map((cat) => (
            <div
              key={cat.id}
              onClick={() => {
                setSelectedCategorySlug(cat.slug);
                onSelectCategory();
              }}
              className="flex flex-col items-center gap-1 cursor-pointer flex-shrink-0"
            >
              <div className="w-13 h-13 rounded-full p-0.5 bg-gradient-to-tr from-amber-500 to-orange-500 shadow-xs hover:scale-105 transition-transform">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full rounded-full object-cover border-2 border-white dark:border-slate-200"
                />
              </div>
              <span className="text-[10px] font-semibold text-slate-800 dark:text-slate-200 truncate w-14 text-center">
                {cat.name.split(' ')[0]}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* 4. AI Stylist Assistant Trigger */}
      <div
        onClick={onOpenAntiflyAI}
        className="p-3 bg-slate-900 text-white rounded-2xl border border-slate-800 flex items-center justify-between cursor-pointer shadow-md hover:border-amber-500 transition-all"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h4 className="font-bold text-xs">Need fashion advice?</h4>
            <p className="text-[10px] text-slate-400">Ask AntiflyAI: "Wedding silk saree under ₹5000"</p>
          </div>
        </div>
        <ArrowRight className="w-4 h-4 text-amber-400" />
      </div>

      {/* 5. Flash Deals Section */}
      <div className="space-y-2 pt-1">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-amber-500" />
            <h3 className="font-extrabold text-xs text-slate-900 dark:text-white uppercase tracking-wider">
              Flash Deals of the Day
            </h3>
          </div>
          <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400">
            Limited Time
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {flashSaleProducts.slice(0, 4).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
};
