import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  User,
  Package,
  MapPin,
  CreditCard,
  Sparkles,
  Truck,
  RotateCcw,
  ChevronRight,
  ShieldCheck,
  Gift,
  Bell,
  Coins,
  Gem,
  Store,
  Heart,
  Bookmark,
  MessageCircle,
  LogOut,
  RefreshCw,
  Zap,
  Bike,
} from 'lucide-react';
import { VentureProfileManager } from '../profile/VentureProfileManager';
import { BuddyProfileManager } from '../profile/BuddyProfileManager';
import { CoinsAndDiamondsTracker } from '../profile/CoinsAndDiamondsTracker';

interface MobileAccountScreenProps {
  onNavigateToSellers?: () => void;
  onNavigateToWishlist?: () => void;
}

export const MobileAccountScreen: React.FC<MobileAccountScreenProps> = ({
  onNavigateToSellers,
  onNavigateToWishlist,
}) => {
  const {
    currentUserSession,
    currentCustomer,
    orders,
    setActiveTrackingOrder,
    setIsAntiflyAIOpen,
    setIsNotificationDrawerOpen,
    setIsUniversalChatOpen,
    followedSellerIds,
    sellers,
    superCoinsBalance,
    setIsSuperCoinsModalOpen,
    wishlist,
    formatPrice,
    quickSwitchUser,
    showToast,
    setIsSavePortfolioOpen,
    savedProductIds,
    savedSellerPostIds,
  } = useApp();

  const [activeProfileTab, setActiveProfileTab] = useState<'profile' | 'rewards' | 'venture' | 'buddy'>('profile');

  const totalSavedCount = (savedProductIds?.length || 0) + (savedSellerPostIds?.length || 0);

  const customerOrders = orders.filter(
    (o) => o.customerId === currentCustomer.id || o.customerEmail === currentCustomer.email
  );

  const followedSellers = sellers.filter((s) => followedSellerIds.includes(s.id));

  return (
    <div id="mobile-account-screen" className="p-3 space-y-4 text-xs pb-10">
      {/* 1. Profile Header Card */}
      <div className="p-4 rounded-3xl bg-gradient-to-tr from-slate-950 via-slate-900 to-slate-800 text-white shadow-lg relative overflow-hidden">
        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 p-0.5 shadow-md">
              <img
                src={currentUserSession.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300'}
                alt={currentUserSession.name}
                className="w-full h-full rounded-2xl object-cover"
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <h3 className="font-extrabold text-sm">{currentUserSession.name}</h3>
                <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 text-[9px] font-bold rounded-full border border-amber-500/30">
                  Verified Member
                </span>
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5">
                {currentUserSession.phone || '+91 98490 22334'} • {currentUserSession.email}
              </p>
            </div>
          </div>
        </div>

        {/* Quick Stat Badges */}
        <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-800 relative z-10 text-center">
          <div
            onClick={onNavigateToSellers}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 cursor-pointer transition-all"
          >
            <span className="text-[10px] text-slate-400 block font-medium">Following</span>
            <span className="text-sm font-extrabold text-amber-400 block mt-0.5">
              {followedSellerIds.length} Ventures
            </span>
          </div>

          <div
            onClick={() => setIsSuperCoinsModalOpen(true)}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 cursor-pointer transition-all"
          >
            <span className="text-[10px] text-slate-400 block font-medium">SuperCoins</span>
            <span className="text-sm font-extrabold text-amber-400 block mt-0.5">
              {superCoinsBalance} 🪙
            </span>
          </div>

          <div
            onClick={onNavigateToWishlist}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 cursor-pointer transition-all"
          >
            <span className="text-[10px] text-slate-400 block font-medium">Wishlist</span>
            <span className="text-sm font-extrabold text-amber-400 block mt-0.5">
              {wishlist.length} Items
            </span>
          </div>
        </div>
      </div>

      {/* 2. Direct Role Navigation Tabs (Customer / Rewards / Venture / Buddy) */}
      <div className="grid grid-cols-4 gap-1 p-1 bg-slate-100 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/80">
        <button
          id="tab-profile-overview"
          onClick={() => setActiveProfileTab('profile')}
          className={`flex flex-col sm:flex-row items-center justify-center gap-1 py-2 px-1 rounded-xl font-extrabold text-[10px] sm:text-[11px] transition-all ${
            activeProfileTab === 'profile'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <User className="w-3.5 h-3.5 text-amber-500" />
          <span>Profile</span>
        </button>

        <button
          id="tab-rewards-manage"
          onClick={() => setActiveProfileTab('rewards')}
          className={`flex flex-col sm:flex-row items-center justify-center gap-1 py-2 px-1 rounded-xl font-extrabold text-[10px] sm:text-[11px] transition-all ${
            activeProfileTab === 'rewards'
              ? 'bg-amber-500 text-slate-800 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Coins className="w-3.5 h-3.5" />
          <span>Rewards</span>
        </button>

        <button
          id="tab-venture-manage"
          onClick={() => setActiveProfileTab('venture')}
          className={`flex flex-col sm:flex-row items-center justify-center gap-1 py-2 px-1 rounded-xl font-extrabold text-[10px] sm:text-[11px] transition-all ${
            activeProfileTab === 'venture'
              ? 'bg-orange-500 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Store className="w-3.5 h-3.5" />
          <span>Venture</span>
        </button>

        <button
          id="tab-buddy-manage"
          onClick={() => setActiveProfileTab('buddy')}
          className={`flex flex-col sm:flex-row items-center justify-center gap-1 py-2 px-1 rounded-xl font-extrabold text-[10px] sm:text-[11px] transition-all ${
            activeProfileTab === 'buddy'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Truck className="w-3.5 h-3.5" />
          <span>Buddy</span>
        </button>
      </div>

      {/* TAB CONTENT: REWARDS & ECONOMY TRACKER (COINS & DIAMONDS) */}
      {activeProfileTab === 'rewards' && (
        <CoinsAndDiamondsTracker />
      )}

      {/* TAB CONTENT: VENTURE SELLER */}
      {activeProfileTab === 'venture' && (
        <VentureProfileManager />
      )}

      {/* TAB CONTENT: BUDDY DRIVER */}
      {activeProfileTab === 'buddy' && (
        <BuddyProfileManager />
      )}

      {/* TAB CONTENT: DEFAULT PROFILE & ORDERS */}
      {activeProfileTab === 'profile' && (
        <>
          {/* Visual Tracking Quick Highlight: Coins & Diamonds */}
          <div
            id="profile-rewards-highlight-card"
            onClick={() => setActiveProfileTab('rewards')}
            className="p-3.5 bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-cyan-500/15 dark:from-amber-950/30 dark:via-orange-950/20 dark:to-cyan-950/30 rounded-2xl border border-amber-500/30 dark:border-amber-500/20 cursor-pointer hover:border-amber-400 transition-all space-y-2.5 shadow-xs"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-cyan-500 text-slate-800 flex items-center justify-center shadow-xs">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-extrabold text-[12px] text-slate-900 dark:text-white">
                      Rewards & Value Economy
                    </h4>
                    <span className="px-1.5 py-0.2 bg-amber-500/20 text-amber-600 dark:text-amber-300 text-[8px] font-black rounded-md">
                      Live Balance
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400">
                    Track Coins (User Loyalty) & Diamonds (Seller Royalty)
                  </p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </div>

            <div className="grid grid-cols-2 gap-2 text-center pt-1 border-t border-slate-200/60 dark:border-slate-800">
              <div className="p-2 rounded-xl bg-white/70 dark:bg-slate-900/70 border border-amber-200/60 dark:border-amber-900/40">
                <span className="text-[9px] font-bold text-amber-700 dark:text-amber-400 flex items-center justify-center gap-1">
                  <Coins className="w-3 h-3 text-amber-500" />
                  <span>Coins: {superCoinsBalance} 🪙</span>
                </span>
                <span className="text-[10px] font-black text-slate-900 dark:text-white block mt-0.5">
                  ₹{superCoinsBalance}.00 Offset (1:1)
                </span>
              </div>

              <div className="p-2 rounded-xl bg-white/70 dark:bg-slate-900/70 border border-cyan-200/60 dark:border-cyan-900/40">
                <span className="text-[9px] font-bold text-cyan-700 dark:text-cyan-400 flex items-center justify-center gap-1">
                  <Gem className="w-3.5 h-3.5 text-cyan-500" />
                  <span>Diamonds: 2,450 💎</span>
                </span>
                <span className="text-[10px] font-black text-slate-900 dark:text-white block mt-0.5">
                  ₹1,225 UPI / 1.5x Boost
                </span>
              </div>
            </div>
          </div>

          {/* Quick Role Direct Activation Banners */}
          <div className="grid grid-cols-2 gap-2">
            <div
              onClick={() => setActiveProfileTab('venture')}
              className="p-3 bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-950/30 dark:to-amber-950/30 rounded-2xl border border-orange-200 dark:border-orange-900/60 cursor-pointer hover:border-orange-400 transition-all group"
            >
              <div className="flex items-center justify-between">
                <div className="w-8 h-8 rounded-xl bg-orange-500 text-white flex items-center justify-center shadow-xs">
                  <Store className="w-4 h-4" />
                </div>
                <span className="text-[9px] font-black uppercase text-orange-600 dark:text-orange-400 bg-orange-100 dark:bg-orange-900/60 px-1.5 py-0.5 rounded-md">
                  Venture
                </span>
              </div>
              <h4 className="font-extrabold text-[11px] text-slate-900 dark:text-white mt-2 group-hover:text-orange-600 transition-colors">
                Sell as Venture
              </h4>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                Direct bank payout & 0% admin cut
              </p>
            </div>

            <div
              onClick={() => setActiveProfileTab('buddy')}
              className="p-3 bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30 rounded-2xl border border-emerald-200 dark:border-emerald-900/60 cursor-pointer hover:border-emerald-400 transition-all group"
            >
              <div className="flex items-center justify-between">
                <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                  <Truck className="w-4 h-4" />
                </div>
                <span className="text-[9px] font-black uppercase text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-900/60 px-1.5 py-0.5 rounded-md">
                  Buddy
                </span>
              </div>
              <h4 className="font-extrabold text-[11px] text-slate-900 dark:text-white mt-2 group-hover:text-emerald-600 transition-colors">
                Deliver as Buddy
              </h4>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                Earn ₹12/km nearby parcel fee
              </p>
            </div>
          </div>

          {/* Followed Ventures Strip */}
          <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-white text-[11px]">
                <Store className="w-3.5 h-3.5 text-amber-500" />
                <span>Followed Ventures ({followedSellers.length})</span>
              </div>
              {onNavigateToSellers && (
                <button
                  onClick={onNavigateToSellers}
                  className="text-[10px] font-bold text-amber-600 dark:text-amber-400 hover:underline"
                >
                  Manage
                </button>
              )}
            </div>

            {followedSellers.length === 0 ? (
              <p className="text-[10px] text-slate-500 py-1">
                You haven't followed any ventures yet. Visit Ventures tab to follow local ventures!
              </p>
            ) : (
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
                {followedSellers.map((s) => (
                  <div
                    key={s.id}
                    onClick={onNavigateToSellers}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shrink-0 cursor-pointer hover:border-amber-500 transition-all"
                  >
                    <img
                      src={s.storeAvatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200'}
                      alt={s.storeName}
                      className="w-5 h-5 rounded-full object-cover"
                    />
                    <span className="text-[10px] font-bold text-slate-800 dark:text-slate-200 truncate max-w-[100px]">
                      {s.storeName}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Live Order Tracking Card */}
          {customerOrders.length > 0 && (
            <div className="p-3.5 bg-amber-50 dark:bg-amber-950/30 rounded-2xl border border-amber-300 dark:border-amber-900/60 space-y-2">
              <div className="flex items-center justify-between text-[11px] font-bold text-amber-900 dark:text-amber-300">
                <span className="flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-amber-600" />
                  <span>Latest Order #{customerOrders[0].orderNumber}</span>
                </span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 bg-amber-200 dark:bg-amber-900/80 rounded-md font-bold">
                  {customerOrders[0].status}
                </span>
              </div>

              <div className="flex items-center justify-between pt-1">
                <div className="text-[10px] text-slate-600 dark:text-slate-400">
                  <span>{customerOrders[0].items.length} items &bull; {formatPrice(customerOrders[0].totalAmount)}</span>
                </div>
                <button
                  onClick={() => setActiveTrackingOrder(customerOrders[0])}
                  className="bg-amber-500 hover:bg-amber-600 text-slate-800 font-extrabold px-3 py-1 rounded-xl text-[10px] shadow-sm transition-all"
                >
                  Track Package
                </button>
              </div>
            </div>
          )}

          {/* Quick Account Actions List */}
          <div className="space-y-1 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-2">
            <div
              onClick={() => customerOrders.length > 0 && setActiveTrackingOrder(customerOrders[0])}
              className="p-2.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl cursor-pointer transition-all"
            >
              <div className="flex items-center gap-2.5 text-slate-800 dark:text-slate-200 font-semibold">
                <Package className="w-4 h-4 text-amber-500" />
                <span>Order History ({customerOrders.length})</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </div>

            <div
              onClick={() => setIsSavePortfolioOpen(true)}
              className="p-2.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl cursor-pointer transition-all"
            >
              <div className="flex items-center gap-2.5 text-slate-800 dark:text-slate-200 font-semibold">
                <Bookmark className="w-4 h-4 text-amber-500" />
                <span>Saved Portfolio & Lookbook ({totalSavedCount})</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </div>

            <div
              onClick={() => setIsUniversalChatOpen(true)}
              className="p-2.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl cursor-pointer transition-all"
            >
              <div className="flex items-center gap-2.5 text-slate-800 dark:text-slate-200 font-semibold">
                <MessageCircle className="w-4 h-4 text-amber-500" />
                <span>Messages & Seller Support</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </div>

            <div
              onClick={() => setIsAntiflyAIOpen(true)}
              className="p-2.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl cursor-pointer transition-all"
            >
              <div className="flex items-center gap-2.5 text-slate-800 dark:text-slate-200 font-semibold">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>Antifly AI Personal Concierge</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </div>

            <div
              onClick={() => setIsNotificationDrawerOpen(true)}
              className="p-2.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl cursor-pointer transition-all"
            >
              <div className="flex items-center gap-2.5 text-slate-800 dark:text-slate-200 font-semibold">
                <Bell className="w-4 h-4 text-amber-500" />
                <span>Notifications & Delivery Alerts</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </div>
          </div>
        </>
      )}
    </div>
  );
};

