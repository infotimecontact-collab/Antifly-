import React from 'react';
import { CameraMode } from '../../types';
import { Camera, Video, Sparkles, Tag, Zap, Film, Store, MessageCircle } from 'lucide-react';

interface CameraModeSwitcherProps {
  currentMode: CameraMode;
  onSelectMode: (mode: CameraMode) => void;
  isRecording?: boolean;
}

interface ModeConfig {
  id: CameraMode;
  label: string;
  sublabel: string;
  icon: React.ComponentType<{ className?: string }>;
  accentColor: string;
}

const MODES: ModeConfig[] = [
  { id: 'photo', label: 'Photo', sublabel: 'HD Capture', icon: Camera, accentColor: 'from-sky-500 to-blue-600' },
  { id: 'video', label: 'Video', sublabel: '15s - 60s', icon: Video, accentColor: 'from-red-500 to-rose-600' },
  { id: 'lens', label: 'AR Lens', sublabel: 'Face 3D', icon: Sparkles, accentColor: 'from-amber-400 to-orange-500' },
  { id: 'product', label: 'Product', sublabel: 'Shoppable Tag', icon: Tag, accentColor: 'from-emerald-500 to-teal-600' },
  { id: 'story', label: 'Story', sublabel: '24h Snap', icon: Zap, accentColor: 'from-purple-500 to-indigo-600' },
  { id: 'reel', label: 'Reel', sublabel: 'Music Sync', icon: Film, accentColor: 'from-pink-500 to-rose-500' },
  { id: 'seller', label: 'Seller Pro', sublabel: 'Catalog Shoot', icon: Store, accentColor: 'from-amber-600 to-orange-700' },
  { id: 'chat', label: 'Chat Snap', sublabel: 'View-Once ①', icon: MessageCircle, accentColor: 'from-emerald-600 to-green-700' },
];

export const CameraModeSwitcher: React.FC<CameraModeSwitcherProps> = ({
  currentMode,
  onSelectMode,
  isRecording = false,
}) => {
  return (
    <div className="w-full relative py-2 overflow-x-auto no-scrollbar flex items-center justify-start md:justify-center px-4 space-x-2 select-none">
      {MODES.map((mode) => {
        const isActive = currentMode === mode.id;
        const IconComponent = mode.icon;

        return (
          <button
            key={mode.id}
            id={`camera-mode-btn-${mode.id}`}
            type="button"
            disabled={isRecording}
            onClick={() => onSelectMode(mode.id)}
            className={`flex-shrink-0 flex items-center space-x-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all duration-200 ${
              isActive
                ? 'bg-white text-slate-800 shadow-lg shadow-black/25 scale-105 ring-2 ring-white/50'
                : 'bg-slate-100/40 backdrop-blur-md text-white/80 hover:bg-slate-100/60 hover:text-white border border-white/10'
            } ${isRecording ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'}`}
          >
            <IconComponent className={`w-3.5 h-3.5 ${isActive ? 'text-slate-900' : 'text-white/70'}`} />
            <span>{mode.label}</span>
            {isActive && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse ml-0.5" />
            )}
          </button>
        );
      })}
    </div>
  );
};
