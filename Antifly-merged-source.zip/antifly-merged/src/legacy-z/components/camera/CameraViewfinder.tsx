import React, { useState, useEffect, useRef } from 'react';
import {
  CameraMode,
  CameraFlashMode,
  CameraFacing,
  CameraAspectRatio,
  CameraLens,
  CameraMusicTrack,
  CameraCapturedMedia,
} from '../../types';
import { DEFAULT_CAMERA_LENSES } from '../../data/defaultCameraData';
import {
  RotateCcw,
  Zap,
  Grid,
  Sparkles,
  Sliders,
  Sun,
  Lock,
  Unlock,
  Circle,
  Play,
  Square,
  Image as ImageIcon,
  Layers,
} from 'lucide-react';

interface CameraViewfinderProps {
  currentMode: CameraMode;
  aspectRatio: CameraAspectRatio;
  flashMode: CameraFlashMode;
  facing: CameraFacing;
  onToggleFacing: () => void;
  selectedLens: CameraLens;
  onSelectLens: (lens: CameraLens) => void;
  selectedMusic?: CameraMusicTrack;
  isRecording: boolean;
  recordingSeconds: number;
  maxRecordingSeconds: number;
  onStartRecording: () => void;
  onStopRecording: () => void;
  onCapturePhoto: (capturedUrl?: string) => void;
  onOpenGallery: () => void;
  recentThumbnail?: string;
  isBeautyActive: boolean;
  beautyLevel: number;
  onBeautyLevelChange: (level: number) => void;
  timerSeconds: number;
  isCountingDown: boolean;
  countdownCurrent: number;
}

export const CameraViewfinder: React.FC<CameraViewfinderProps> = ({
  currentMode,
  aspectRatio,
  flashMode,
  facing,
  onToggleFacing,
  selectedLens,
  onSelectLens,
  selectedMusic,
  isRecording,
  recordingSeconds,
  maxRecordingSeconds,
  onStartRecording,
  onStopRecording,
  onCapturePhoto,
  onOpenGallery,
  recentThumbnail,
  isBeautyActive,
  beautyLevel,
  onBeautyLevelChange,
  timerSeconds,
  isCountingDown,
  countdownCurrent,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [streamActive, setStreamActive] = useState(false);
  const [permissionError, setPermissionError] = useState(false);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [showGrid, setShowGrid] = useState(false);
  const [focusPoint, setFocusPoint] = useState<{ x: number; y: number } | null>(null);
  const [exposureLevel, setExposureLevel] = useState<number>(0);
  const [isHandsFreeLocked, setIsHandsFreeLocked] = useState(false);

  // Fallback high-resolution simulated backgrounds if camera access is restricted in iframe/sandbox
  const simulatedBackgrounds: Record<CameraFacing, string> = {
    user: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=1080&auto=format&fit=crop&q=80',
    environment: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=1080&auto=format&fit=crop&q=80',
  };

  // Attempt real camera access
  useEffect(() => {
    let mediaStream: MediaStream | null = null;

    async function initCamera() {
      if (typeof navigator !== 'undefined' && navigator.mediaDevices?.getUserMedia) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({
            video: {
              facingMode: facing === 'user' ? 'user' : 'environment',
              width: { ideal: 1280 },
              height: { ideal: 1920 },
            },
            audio: currentMode === 'video' || currentMode === 'reel',
          });
          mediaStream = stream;
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play().catch(() => {});
          }
          setStreamActive(true);
          setPermissionError(false);
        } catch (err) {
          console.warn('Live webcam stream not accessible, switching to High-Def simulated Studio sensor stream:', err);
          setStreamActive(false);
          setPermissionError(true);
        }
      } else {
        setStreamActive(false);
      }
    }

    initCamera();

    return () => {
      if (mediaStream) {
        mediaStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [facing, currentMode]);

  // Tap to focus handler
  const handleTapViewfinder = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setFocusPoint({ x, y });

    // Auto-hide focus brackets after 3 seconds
    setTimeout(() => {
      setFocusPoint(null);
    }, 3000);
  };

  // Recording circular progress SVG calculation
  const progressPercent = (recordingSeconds / maxRecordingSeconds) * 100;
  const strokeDashoffset = 283 - (283 * progressPercent) / 100;

  return (
    <div className="relative w-full h-full flex items-center justify-center bg-slate-100 overflow-hidden select-none">
      {/* Viewport Frame Box based on Aspect Ratio */}
      <div
        id="camera-viewfinder-frame"
        onClick={handleTapViewfinder}
        className={`relative overflow-hidden cursor-crosshair flex items-center justify-center transition-all duration-300 ${
          aspectRatio === '1:1'
            ? 'aspect-square max-h-[85vh] w-auto'
            : aspectRatio === '4:5'
            ? 'aspect-[4/5] max-h-[85vh] w-auto'
            : 'w-full h-full max-h-[92vh] max-w-[480px] aspect-[9/16]'
        }`}
        style={{
          transform: `scale(${zoomLevel})`,
          transformOrigin: 'center center',
          filter: `${selectedLens.filterCss || ''} brightness(${1 + exposureLevel * 0.15})`,
        }}
      >
        {/* Real Live Video or HD Studio Stream */}
        {streamActive ? (
          <video
            ref={videoRef}
            playsInline
            muted
            autoPlay
            className={`w-full h-full object-cover ${facing === 'user' ? 'scale-x-[-1]' : ''}`}
          />
        ) : (
          <div className="relative w-full h-full bg-slate-900 overflow-hidden">
            <img
              src={simulatedBackgrounds[facing]}
              alt="Camera Simulation Sensor"
              className="w-full h-full object-cover filter contrast-105"
            />
            {/* Live studio simulation pulse badge */}
            <div className="absolute top-4 left-4 flex items-center space-x-1.5 bg-slate-100/60 backdrop-blur-md px-2.5 py-1 rounded-full text-[10px] font-bold text-white border border-white/20">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>Studio HDR Sensor Active</span>
            </div>
          </div>
        )}

        {/* AR Face Overlay Visualizer */}
        {selectedLens.overlayType === 'gold_sparkles' && (
          <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center">
            <div className="text-6xl animate-bounce filter drop-shadow-[0_0_15px_rgba(234,179,8,0.8)]">
              👑
            </div>
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-400/20 via-transparent to-transparent animate-pulse" />
          </div>
        )}

        {selectedLens.overlayType === 'neon_glasses' && (
          <div className="absolute top-[38%] left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
            <div className="text-7xl filter drop-shadow-[0_0_20px_rgba(236,72,153,0.9)] animate-pulse">
              🕶️
            </div>
          </div>
        )}

        {selectedLens.overlayType === 'cyber_visor' && (
          <div className="absolute inset-0 pointer-events-none border border-cyan-400/40 m-6 rounded-2xl flex flex-col justify-between p-4 text-cyan-400 font-mono text-[10px]">
            <div className="flex justify-between items-center">
              <span className="bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-400/50">
                AI SCAN // 98.4%
              </span>
              <span>LIVE TELEMETRY</span>
            </div>
            <div className="flex items-center justify-center">
              <div className="w-32 h-32 rounded-full border border-dashed border-cyan-400/60 animate-spin" />
            </div>
            <div className="flex justify-between items-center">
              <span>FACE TRACK: LOCKED</span>
              <span>ISO 100 • 1/250s</span>
            </div>
          </div>
        )}

        {selectedLens.overlayType === 'beauty_glow' && (
          <div className="absolute inset-0 pointer-events-none bg-radial from-pink-300/15 via-transparent to-slate-100/30" />
        )}

        {selectedLens.overlayType === 'bokeh_luxury' && (
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-10 left-10 w-24 h-24 rounded-full bg-amber-400/20 blur-xl animate-pulse" />
            <div className="absolute bottom-20 right-10 w-32 h-32 rounded-full bg-purple-400/20 blur-2xl animate-pulse" />
          </div>
        )}

        {selectedLens.overlayType === 'vhs_glitch' && (
          <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%)] bg-[length:100%_4px] flex flex-col justify-between p-4 font-mono text-yellow-300 text-xs">
            <div className="flex justify-between">
              <span className="animate-pulse">● REC 00:19:98</span>
              <span>SP 1998</span>
            </div>
            <div>PLAY ▶ [STEREO]</div>
          </div>
        )}

        {/* Product Catalog Center Assist Box for Product/Seller modes */}
        {(currentMode === 'product' || currentMode === 'seller') && (
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center m-12 border-2 border-dashed border-emerald-400/60 rounded-3xl">
            <span className="absolute -top-3 bg-emerald-600 text-white font-black text-[10px] uppercase px-2 py-0.5 rounded-full shadow-md">
              Align Product Inside Frame
            </span>
          </div>
        )}

        {/* Rule of Thirds Grid Overlay */}
        {showGrid && (
          <div className="absolute inset-0 pointer-events-none grid grid-cols-3 grid-rows-3 border border-white/20">
            <div className="border-r border-b border-white/20" />
            <div className="border-r border-b border-white/20" />
            <div className="border-b border-white/20" />
            <div className="border-r border-b border-white/20" />
            <div className="border-r border-b border-white/20" />
            <div className="border-b border-white/20" />
            <div className="border-r border-white/20" />
            <div className="border-r border-white/20" />
            <div />
          </div>
        )}

        {/* Tap To Focus Brackets & Exposure Slider */}
        {focusPoint && (
          <div
            style={{
              left: `${focusPoint.x}%`,
              top: `${focusPoint.y}%`,
              transform: 'translate(-50%, -50%)',
            }}
            className="absolute z-30 pointer-events-none animate-in zoom-in-75 duration-200"
          >
            <div className="relative w-16 h-16 border-2 border-amber-400 rounded-lg flex items-center justify-center shadow-lg">
              <span className="w-1.5 h-1.5 bg-amber-400 rounded-full animate-ping" />
              <Sun className="w-3.5 h-3.5 text-amber-300 absolute -right-6 top-1/2 -translate-y-1/2 animate-pulse" />
            </div>
          </div>
        )}

        {/* Large Animated Countdown Timer Overlay */}
        {isCountingDown && (
          <div className="absolute inset-0 z-40 bg-slate-100/50 backdrop-blur-sm flex items-center justify-center pointer-events-none">
            <span className="text-8xl font-black text-white animate-ping drop-shadow-2xl">
              {countdownCurrent}
            </span>
          </div>
        )}
      </div>

      {/* Top Floating Camera Controls Dock */}
      <div className="absolute top-4 inset-x-4 max-w-lg mx-auto flex items-center justify-between z-30 pointer-events-auto">
        <div className="flex items-center space-x-2">
          {/* Switch Camera Facing (Front / Back) */}
          <button
            id="camera-btn-switch-facing"
            type="button"
            onClick={onToggleFacing}
            className="w-10 h-10 rounded-full bg-slate-100/50 backdrop-blur-md text-white flex items-center justify-center hover:bg-slate-100/70 border border-white/20 transition-transform active:rotate-180"
            title={`Switch to ${facing === 'user' ? 'Back' : 'Front'} Camera`}
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Grid Toggle */}
          <button
            id="camera-btn-toggle-grid"
            type="button"
            onClick={() => setShowGrid(!showGrid)}
            className={`w-10 h-10 rounded-full backdrop-blur-md flex items-center justify-center border transition-all ${
              showGrid ? 'bg-amber-400 text-slate-800 border-amber-400 shadow-md font-bold' : 'bg-slate-100/50 text-white border-white/20'
            }`}
            title="Toggle Rule-of-Thirds Grid"
          >
            <Grid className="w-4 h-4" />
          </button>
        </div>

        {/* Selected Music / Soundtrack pill */}
        {selectedMusic && (
          <div className="bg-gradient-to-r from-pink-500/90 to-rose-500/90 backdrop-blur-md px-3 py-1 rounded-full text-white text-xs font-bold flex items-center space-x-1.5 shadow-lg border border-white/20 max-w-[180px] truncate">
            <span className="animate-bounce">🎵</span>
            <span className="truncate">{selectedMusic.title}</span>
          </div>
        )}

        {/* Zoom Selector Pills (0.5x, 1x, 2x, 5x) */}
        <div className="flex items-center bg-slate-100/50 backdrop-blur-md p-1 rounded-full border border-white/20 space-x-1">
          {[0.5, 1, 2, 5].map((z) => (
            <button
              key={z}
              type="button"
              onClick={() => setZoomLevel(z === 0.5 ? 0.9 : z)}
              className={`px-2 py-0.5 rounded-full text-[10px] font-bold transition-all ${
                zoomLevel === (z === 0.5 ? 0.9 : z)
                  ? 'bg-amber-400 text-slate-800'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              {z}x
            </button>
          ))}
        </div>
      </div>

      {/* Beauty Level Slider Popover */}
      {isBeautyActive && (
        <div className="absolute top-20 right-4 z-30 bg-slate-100/60 backdrop-blur-xl p-3 rounded-2xl border border-white/20 text-white w-48 space-y-2">
          <div className="flex justify-between text-xs font-bold">
            <span className="flex items-center space-x-1 text-pink-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Glamour Skin</span>
            </span>
            <span className="font-mono">{beautyLevel}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={beautyLevel}
            onChange={(e) => onBeautyLevelChange(Number(e.target.value))}
            className="w-full accent-pink-500"
          />
        </div>
      )}

      {/* Bottom AR Lens Selector Carousel */}
      <div className="absolute bottom-28 inset-x-0 z-30 flex items-center justify-center px-4 overflow-x-auto no-scrollbar pointer-events-auto">
        <div className="flex items-center space-x-3 py-1">
          {DEFAULT_CAMERA_LENSES.map((lens) => (
            <button
              key={lens.id}
              id={`camera-lens-${lens.id}`}
              type="button"
              onClick={() => onSelectLens(lens)}
              className={`flex-shrink-0 flex flex-col items-center space-y-1 transition-all ${
                selectedLens.id === lens.id
                  ? 'scale-110'
                  : 'opacity-60 hover:opacity-100'
              }`}
            >
              <div
                className={`w-11 h-11 rounded-full flex items-center justify-center text-xl shadow-xl transition-all ${
                  selectedLens.id === lens.id
                    ? 'bg-gradient-to-tr from-amber-400 to-yellow-300 text-slate-800 ring-4 ring-white/50'
                    : 'bg-slate-100/60 backdrop-blur-md text-white border border-white/20'
                }`}
              >
                {lens.emoji}
              </div>
              <span className="text-[10px] font-bold text-white drop-shadow-md">
                {lens.name}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Primary Capture & Gallery Shutter Dock */}
      <div className="absolute bottom-6 inset-x-4 max-w-md mx-auto flex items-center justify-around z-30 pointer-events-auto">
        {/* Left: Gallery Vault Thumbnail Trigger */}
        <button
          id="camera-btn-open-gallery"
          type="button"
          onClick={onOpenGallery}
          className="w-12 h-12 rounded-2xl bg-slate-100/60 backdrop-blur-md p-0.5 border border-white/30 shadow-xl overflow-hidden hover:scale-105 transition-transform flex items-center justify-center relative"
          title="Open Camera Vault Gallery"
        >
          {recentThumbnail ? (
            <img src={recentThumbnail} alt="Recent" className="w-full h-full object-cover rounded-xl" />
          ) : (
            <ImageIcon className="w-5 h-5 text-white/80" />
          )}
          <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border border-slate-200" />
        </button>

        {/* Center: Universal Shutter & Recording Button */}
        <div className="relative flex items-center justify-center">
          {/* Circular SVG Recording Timer Ring */}
          {isRecording && (
            <svg className="absolute w-24 h-24 -rotate-90 pointer-events-none">
              <circle
                cx="48"
                cy="48"
                r="45"
                stroke="currentColor"
                strokeWidth="5"
                className="text-red-500 transition-all duration-200"
                fill="transparent"
                strokeDasharray="283"
                strokeDashoffset={strokeDashoffset}
              />
            </svg>
          )}

          <button
            id="camera-shutter-main-btn"
            type="button"
            onClick={() => {
              if (currentMode === 'video' || currentMode === 'reel') {
                if (isRecording) onStopRecording();
                else onStartRecording();
              } else {
                onCapturePhoto();
              }
            }}
            onMouseDown={() => {
              if (currentMode !== 'photo') onStartRecording();
            }}
            onMouseUp={() => {
              if (!isHandsFreeLocked && (currentMode === 'video' || currentMode === 'reel')) {
                onStopRecording();
              }
            }}
            className={`w-20 h-20 rounded-full flex items-center justify-center p-1 transition-all active:scale-95 shadow-2xl ${
              isRecording
                ? 'bg-red-600 ring-8 ring-red-500/30'
                : currentMode === 'seller'
                ? 'bg-gradient-to-tr from-amber-500 to-orange-500 ring-4 ring-white/50'
                : 'bg-white ring-4 ring-white/40'
            }`}
          >
            {isRecording ? (
              <Square className="w-8 h-8 fill-current text-white animate-pulse" />
            ) : currentMode === 'video' || currentMode === 'reel' ? (
              <div className="w-7 h-7 rounded-full bg-red-600" />
            ) : (
              <div className="w-16 h-16 rounded-full border-2 border-slate-900/40 bg-white" />
            )}
          </button>
        </div>

        {/* Right: Hands-Free Lock Toggle */}
        <button
          id="camera-btn-hands-free"
          type="button"
          onClick={() => setIsHandsFreeLocked(!isHandsFreeLocked)}
          className={`w-12 h-12 rounded-2xl backdrop-blur-md flex flex-col items-center justify-center border transition-all ${
            isHandsFreeLocked
              ? 'bg-emerald-500 text-slate-800 border-emerald-400 font-bold shadow-lg'
              : 'bg-slate-100/60 text-white/80 border-white/30 hover:text-white'
          }`}
          title={isHandsFreeLocked ? 'Hands-Free Recording Locked' : 'Tap to Lock Hands-Free'}
        >
          {isHandsFreeLocked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
          <span className="text-[9px] font-bold mt-0.5">Lock</span>
        </button>
      </div>
    </div>
  );
};
