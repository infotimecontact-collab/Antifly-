import React, { useState } from 'react';
import { CameraCapturedMedia, Product } from '../../types';
import {
  X,
  Grid,
  Film,
  Tag,
  Clock,
  Trash2,
  Share2,
  Download,
  Play,
  Zap,
  ShoppingBag,
  ExternalLink,
  Store,
} from 'lucide-react';

interface CameraGalleryVaultModalProps {
  isOpen: boolean;
  onClose: () => void;
  galleryMedia: CameraCapturedMedia[];
  onSelectMediaToEdit: (media: CameraCapturedMedia) => void;
  onDeleteMedia: (id: string) => void;
  onPublishToStory: (media: CameraCapturedMedia) => void;
  onPublishToReel: (media: CameraCapturedMedia) => void;
  formatPrice: (inrAmount: number) => string;
}

export const CameraGalleryVaultModal: React.FC<CameraGalleryVaultModalProps> = ({
  isOpen,
  onClose,
  galleryMedia,
  onSelectMediaToEdit,
  onDeleteMedia,
  onPublishToStory,
  onPublishToReel,
  formatPrice,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'shoppable' | 'reels' | 'drafts' | 'seller'>('all');
  const [activePreviewMedia, setActivePreviewMedia] = useState<CameraCapturedMedia | null>(null);

  if (!isOpen) return null;

  const filteredMedia = galleryMedia.filter((item) => {
    if (activeTab === 'all') return true;
    if (activeTab === 'shoppable') return item.productTags && item.productTags.length > 0;
    if (activeTab === 'reels') return item.type === 'video' || item.mode === 'reel';
    if (activeTab === 'drafts') return item.isDraft;
    if (activeTab === 'seller') return item.mode === 'seller' || item.sellerStudioDetails;
    return true;
  });

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-100/85 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div className="bg-slate-900 border border-white/15 rounded-3xl shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden text-white">
        {/* Header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-white/60">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center shadow-lg">
              <Grid className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Camera Media Vault & Gallery</h3>
              <p className="text-xs text-slate-400">
                {galleryMedia.length} Captures • Shoppable Snaps, Reels & Studio Shoots
              </p>
            </div>
          </div>
          <button
            id="btn-close-gallery-vault"
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 text-white flex items-center justify-center hover:bg-white/20 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Filters */}
        <div className="px-6 py-3 border-b border-white/10 bg-white/30 flex items-center space-x-2 overflow-x-auto no-scrollbar">
          {[
            { id: 'all', label: 'All Media', count: galleryMedia.length },
            { id: 'shoppable', label: '🏷️ Shoppable Snaps', count: galleryMedia.filter((m) => m.productTags?.length > 0).length },
            { id: 'reels', label: '🎬 15s Reels', count: galleryMedia.filter((m) => m.type === 'video' || m.mode === 'reel').length },
            { id: 'seller', label: '🏪 Studio Drops', count: galleryMedia.filter((m) => m.mode === 'seller').length },
            { id: 'drafts', label: '💾 Drafts', count: galleryMedia.filter((m) => m.isDraft).length },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-white text-slate-800 shadow-md font-bold'
                  : 'bg-white/5 text-slate-300 hover:bg-white/10 border border-white/10'
              }`}
            >
              <span>{tab.label}</span>
              <span className="ml-1.5 opacity-60 font-mono text-[10px]">({tab.count})</span>
            </button>
          ))}
        </div>

        {/* Media Grid */}
        <div className="flex-1 overflow-y-auto p-6">
          {filteredMedia.length === 0 ? (
            <div className="text-center py-16 space-y-3">
              <div className="w-16 h-16 rounded-full bg-white/5 mx-auto flex items-center justify-center text-slate-500">
                <Grid className="w-8 h-8" />
              </div>
              <h4 className="text-sm font-bold text-white">No Media In This Folder</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Use the camera to capture high-res photos, tag products, record 15s reels, or design seller catalog drops.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3.5">
              {filteredMedia.map((item) => (
                <div
                  key={item.id}
                  className="group relative rounded-2xl overflow-hidden bg-white border border-white/10 hover:border-emerald-500 transition-all flex flex-col aspect-[3/4] shadow-md cursor-pointer"
                  onClick={() => setActivePreviewMedia(item)}
                >
                  {/* Thumbnail */}
                  <div className="relative w-full h-full overflow-hidden bg-slate-800">
                    <img
                      src={item.mediaUrl}
                      alt={item.caption || 'Camera capture'}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />

                    {/* Type badge */}
                    <div className="absolute top-2 left-2 flex items-center space-x-1">
                      {item.type === 'video' ? (
                        <span className="bg-red-600/90 backdrop-blur-md text-white text-[10px] font-black px-2 py-0.5 rounded-full flex items-center space-x-1 shadow-md">
                          <Play className="w-2.5 h-2.5 fill-current" />
                          <span>15s</span>
                        </span>
                      ) : (
                        <span className="bg-slate-100/60 backdrop-blur-md text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                          Photo
                        </span>
                      )}

                      {item.productTags && item.productTags.length > 0 && (
                        <span className="bg-emerald-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full flex items-center space-x-0.5">
                          <Tag className="w-2.5 h-2.5" />
                          <span>{item.productTags.length}</span>
                        </span>
                      )}
                    </div>

                    {/* Mode tag */}
                    <div className="absolute top-2 right-2">
                      <span className="bg-slate-100/60 backdrop-blur-md text-white text-[9px] uppercase font-bold px-1.5 py-0.5 rounded-md">
                        {item.mode}
                      </span>
                    </div>

                    {/* Bottom overlay info */}
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-100/90 via-slate-100/50 to-transparent p-2.5 pt-6 text-left">
                      <p className="text-xs font-bold text-white line-clamp-1">
                        {item.caption || 'Studio Capture'}
                      </p>
                      <p className="text-[10px] text-slate-400 mt-0.5">{item.createdAt}</p>
                    </div>
                  </div>

                  {/* Hover Actions Menu */}
                  <div className="absolute inset-0 bg-white/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-3 space-y-2">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectMediaToEdit(item);
                        onClose();
                      }}
                      className="w-full py-1.5 bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold rounded-xl shadow-md transition-colors"
                    >
                      Open in Studio
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onPublishToStory(item);
                      }}
                      className="w-full py-1.5 bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold rounded-xl transition-colors flex items-center justify-center space-x-1"
                    >
                      <Zap className="w-3 h-3" />
                      <span>Post Story</span>
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteMedia(item.id);
                      }}
                      className="text-red-400 hover:text-red-300 text-[11px] font-medium flex items-center space-x-1 pt-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Media Detail Full-Screen Lightbox Modal */}
      {activePreviewMedia && (
        <div className="fixed inset-0 z-70 bg-slate-100/90 backdrop-blur-xl flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-white/20 rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl flex flex-col md:flex-row">
            <div className="relative md:w-1/2 aspect-[9/16] bg-slate-100">
              {activePreviewMedia.type === 'video' ? (
                <video
                  src={activePreviewMedia.mediaUrl}
                  autoPlay
                  loop
                  controls
                  playsInline
                  className="w-full h-full object-cover"
                />
              ) : (
                <img
                  src={activePreviewMedia.mediaUrl}
                  alt={activePreviewMedia.caption}
                  className="w-full h-full object-cover"
                />
              )}
            </div>

            <div className="p-6 md:w-1/2 flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                    {activePreviewMedia.mode} Mode
                  </span>
                  <button
                    type="button"
                    onClick={() => setActivePreviewMedia(null)}
                    className="text-slate-400 hover:text-white"
                  >
                    ✕
                  </button>
                </div>

                <h4 className="text-base font-bold text-white mb-1">
                  {activePreviewMedia.caption || 'Studio Creation'}
                </h4>
                <p className="text-xs text-slate-400 mb-4">{activePreviewMedia.createdAt}</p>

                {/* Tagged Products in this media */}
                {activePreviewMedia.productTags && activePreviewMedia.productTags.length > 0 && (
                  <div className="space-y-2 mb-4">
                    <p className="text-xs font-bold text-slate-300">Tagged Products:</p>
                    {activePreviewMedia.productTags.map((tag) => (
                      <div
                        key={tag.id}
                        className="flex items-center space-x-2.5 p-2 bg-white/5 rounded-xl border border-white/10"
                      >
                        <img src={tag.image} alt={tag.productName} className="w-8 h-8 rounded-lg object-cover" />
                        <div className="flex-1 min-w-0 text-left">
                          <p className="text-xs font-bold text-white truncate">{tag.productName}</p>
                          <p className="text-xs text-emerald-400 font-extrabold">{formatPrice(tag.price)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => {
                    onSelectMediaToEdit(activePreviewMedia);
                    setActivePreviewMedia(null);
                    onClose();
                  }}
                  className="w-full py-2.5 bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg hover:bg-emerald-600 transition-colors"
                >
                  Edit in Studio
                </button>
                <button
                  type="button"
                  onClick={() => setActivePreviewMedia(null)}
                  className="w-full py-2 bg-white/10 text-slate-300 font-semibold text-xs rounded-xl hover:bg-white/20 transition-colors"
                >
                  Close Preview
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
