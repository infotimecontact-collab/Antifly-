import React, { useState, useEffect, useRef } from 'react';
import {
  StoryCameraCaptureMode,
  StoryLifetimeDuration,
  StoryPhaseType,
  StoryMood,
  InteractiveStoryObject,
  AISmartTagSuggestion,
  TimeShiftStoryItem,
  Product,
  StoryVisualFilter,
  StorySoundtrack,
  StoryPollSticker,
  StoryCountdownSticker,
  StoryBountySticker,
  StorySpatialTextSticker,
  StoryAudienceScope,
} from '../../types';
import { useApp } from '../../context/AppContext';
import {
  INITIAL_AI_SMART_TAG_CANDIDATES,
  STORY_SOUNDTRACK_PRESETS,
  STORY_SCENE_PRESETS,
  StorySoundtrackPreset,
  StoryScenePreset,
} from '../../data/timeShiftStoryData';
import {
  X,
  Camera,
  Video,
  Sparkles,
  Layers,
  Globe,
  Film,
  Zap,
  Tag,
  MapPin,
  Clock,
  Mic,
  Volume2,
  VolumeX,
  Check,
  Plus,
  Trash2,
  Eye,
  Gift,
  Store,
  Users,
  Compass,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Sliders,
  Play,
  Pause,
  RotateCcw,
  Percent,
  Music,
  Wand2,
  Image as ImageIcon,
  Upload,
  Radio,
  Flame,
  Coins,
  Type,
  Timer,
  HelpCircle,
  Activity,
  Lock,
  Unlock,
  Share2,
  Smile,
  Disc,
} from 'lucide-react';

interface TimeShiftStoryCameraModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TimeShiftStoryCameraModal: React.FC<TimeShiftStoryCameraModalProps> = ({
  isOpen,
  onClose,
}) => {
  const {
    products,
    sellers,
    formatPrice,
    showToast,
    currentUserSession,
    publishTimeShiftStory,
    goalCommunities,
    temporaryCommunities,
    livingUserProfile,
  } = useApp();

  // Workflow Stages
  const [cameraStage, setCameraStage] = useState<'capture' | 'ai_analysis' | 'customize' | 'preview'>('capture');
  const [activeCustomizeTab, setActiveCustomizeTab] = useState<'stickers' | 'audio' | 'filters' | 'audience' | 'ai_tags'>('stickers');

  // Mode & Media
  const [captureMode, setCaptureMode] = useState<StoryCameraCaptureMode>('depth');
  const [mediaType, setMediaType] = useState<'photo' | 'video'>('video');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const maxRecording = 20;

  // Selected Lifetime & Mood
  const [selectedLifetime, setSelectedLifetime] = useState<StoryLifetimeDuration>('2h');
  const [selectedMood, setSelectedMood] = useState<StoryMood>('Luxury');
  const [captionText, setCaptionText] = useState('');
  const [locationRadiusKm, setLocationRadiusKm] = useState<number>(2);
  const [locationName, setLocationName] = useState('Godowlia Silk Market, Varanasi');
  const [isLocationAttached, setIsLocationAttached] = useState(true);
  const [isMultiPersonEnabled, setIsMultiPersonEnabled] = useState(true);

  // New Feature 1: Visual Shaders & Filters
  const [visualFilter, setVisualFilter] = useState<StoryVisualFilter>('golden_hour');
  const [lightingPreset, setLightingPreset] = useState<'natural' | 'studio_rim' | 'warm_candle' | 'cyber_cyan'>('warm_candle');

  // New Feature 2: Neuro-Soundtrack & Ambient Music Matrix
  const [selectedSoundtrack, setSelectedSoundtrack] = useState<StorySoundtrackPreset | null>(STORY_SOUNDTRACK_PRESETS[0]);
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const [audioVolumeBalance, setAudioVolumeBalance] = useState<number>(75); // 0 to 100

  // New Feature 3: Interactive 3D Poll Sticker
  const [hasPollSticker, setHasPollSticker] = useState(true);
  const [pollQuestion, setPollQuestion] = useState('Should we unlock early access slots?');
  const [pollOptionA, setPollOptionA] = useState('Yes! Open Drops 🚀');
  const [pollOptionB, setPollOptionB] = useState('Keep Exclusive 🔒');
  const [pollThemeColor, setPollThemeColor] = useState<'cyan' | 'purple' | 'amber' | 'emerald' | 'rose'>('amber');
  const [pollDepthZ, setPollDepthZ] = useState(6);

  // New Feature 4: Countdown / Flash Drop Timer Sticker
  const [hasCountdownSticker, setHasCountdownSticker] = useState(false);
  const [countdownTitle, setCountdownTitle] = useState('VIP Flash Drop Starts In');
  const [countdownMinutes, setCountdownMinutes] = useState(45);
  const [countdownTheme, setCountdownTheme] = useState<'cyan' | 'purple' | 'amber' | 'emerald' | 'rose'>('rose');

  // New Feature 5: Token Bounty & Quest Sticker
  const [hasBountySticker, setHasBountySticker] = useState(false);
  const [bountyQuestTitle, setBountyQuestTitle] = useState('Spot the Easter Egg & Comment');
  const [bountyTokens, setBountyTokens] = useState(50);
  const [bountyLimit, setBountyLimit] = useState(10);

  // New Feature 6: 3D Spatial Hologram Text Stickers
  const [spatialTextStickers, setSpatialTextStickers] = useState<StorySpatialTextSticker[]>([
    {
      id: 'txt-1',
      text: '★ 2-HOUR LIMITED EDITION ★',
      fontStyle: 'cyber_mono',
      color: '#F59E0B',
      x: 50,
      y: 20,
      depthZ: 8,
      scale: 1,
    },
  ]);
  const [newTextString, setNewTextString] = useState('');
  const [newTextStyle, setNewTextStyle] = useState<'cyber_mono' | 'editorial_serif' | 'neon_glow' | 'bold_marker'>('neon_glow');

  // New Feature 7: Co-Creation, Remix & Audience Governance
  const [audienceScope, setAudienceScope] = useState<StoryAudienceScope>('public_radar');
  const [remixPermission, setRemixPermission] = useState<'open_to_all' | 'community_only' | 'disabled'>('open_to_all');
  const [ephemeralGhostMode, setEphemeralGhostMode] = useState(false);

  // Interconnected Community & Living Profile Sync State
  const [selectedCommunityId, setSelectedCommunityId] = useState<string>('goal-comm-startup');
  const [milestoneTagText, setMilestoneTagText] = useState<string>('Week 4 MVP Demo');
  const [isProfileStoryFlag, setIsProfileStoryFlag] = useState<boolean>(true);

  // AI & Voice Command simulation
  const [isListeningVoice, setIsListeningVoice] = useState(false);
  const [voiceCommandStatus, setVoiceCommandStatus] = useState<string | null>(null);

  // AI Smart Tags & Interactive Objects
  const [aiSmartTags, setAiSmartTags] = useState<AISmartTagSuggestion[]>(INITIAL_AI_SMART_TAG_CANDIDATES);
  const [interactiveObjects, setInteractiveObjects] = useState<InteractiveStoryObject[]>([]);
  const [isProductPickerOpen, setIsProductPickerOpen] = useState(false);
  const [isSecretRewardModalOpen, setIsSecretRewardModalOpen] = useState(false);

  // Secret Reward Config
  const [secretTitle, setSecretTitle] = useState('VIP 2-Hour Flash Voucher');
  const [secretDiscount, setSecretDiscount] = useState(20);
  const [secretCode, setSecretCode] = useState('FLASH2H');

  // Captured media & Ingestion studio
  const [capturedMediaUrl, setCapturedMediaUrl] = useState(
    'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=1080&auto=format&fit=crop&q=80'
  );
  const [isScenePickerOpen, setIsScenePickerOpen] = useState(false);
  const [isGenAiModalOpen, setIsGenAiModalOpen] = useState(false);
  const [genAiPrompt, setGenAiPrompt] = useState('Hyper-realistic cyber artisan weaving silk in neon ambient lighting');
  const [isGeneratingAiScene, setIsGeneratingAiScene] = useState(false);

  // 3D Tilt simulation for Preview Mode
  const [previewTilt, setPreviewTilt] = useState({ x: 0, y: 0 });
  const previewBoxRef = useRef<HTMLDivElement>(null);

  // Generated Story DNA
  const [storyDna, setStoryDna] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setStoryDna(`MOMENT-${Math.random().toString(36).substring(2, 6).toUpperCase()}`);
      setCameraStage('capture');
      setIsRecording(false);
      setRecordingSeconds(0);
      setCaptionText('');
      setIsAudioPlaying(false);
    }
  }, [isOpen]);

  // Video recording timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecording) {
      interval = setInterval(() => {
        setRecordingSeconds((prev) => {
          if (prev >= maxRecording) {
            handleStopRecording();
            return maxRecording;
          }
          return prev + 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  if (!isOpen) return null;

  const handleStartRecording = () => {
    setIsRecording(true);
    setRecordingSeconds(0);
  };

  const handleStopRecording = () => {
    setIsRecording(false);
    triggerAIAnalysis();
  };

  const handleCapturePhoto = () => {
    setMediaType('photo');
    triggerAIAnalysis();
  };

  const triggerAIAnalysis = () => {
    setCameraStage('ai_analysis');
    setTimeout(() => {
      const detectedProd = products[0] || {
        id: 'wi-prod-001',
        name: 'Royal Crimson Banarasi Zari Silk Saree',
        price: 4999,
        mrp: 8999,
        images: ['https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=500'],
      };

      setInteractiveObjects([
        {
          id: `obj-${Date.now()}-1`,
          label: detectedProd.name,
          category: 'product',
          productId: detectedProd.id,
          productDetails: {
            name: detectedProd.name,
            price: detectedProd.price,
            mrp: detectedProd.mrp,
            discountPercent: Math.round(((detectedProd.mrp - detectedProd.price) / detectedProd.mrp) * 100) || 40,
            image: detectedProd.images?.[0] || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=500',
            inStock: true,
            deliveryEta: '28 Mins Express',
            sellerName: 'Heritage Silk Weavers',
          },
          x: 50,
          y: 45,
          depthZ: 4,
          spatialSurface: 'floating',
          actionType: 'buy_now',
        },
        {
          id: `obj-${Date.now()}-2`,
          label: '✨ Hidden Reward (Tap to Unlock)',
          category: 'secret_offer',
          secretReward: {
            title: 'VIP 2-Hour Flash Voucher',
            promoCode: 'SILK2HOUR',
            discountPercent: 20,
            badgeName: 'Royal Explorer',
            claimed: false,
          },
          x: 24,
          y: 78,
          depthZ: 8,
          spatialSurface: 'table',
          actionType: 'reveal_offer',
        },
      ]);
      setCameraStage('customize');
    }, 1600);
  };

  const handleVoiceCommand = () => {
    setIsListeningVoice(true);
    setVoiceCommandStatus('Listening to voice prompt...');
    setTimeout(() => {
      setVoiceCommandStatus('🤖 AI: "Applied Golden Hour shader, attached Alpha 40Hz soundtrack & activated 20% Flash Drop Poll!"');
      setCaptureMode('cinematic');
      setSelectedMood('Luxury');
      setVisualFilter('golden_hour');
      setHasPollSticker(true);
      setPollQuestion('Which Varanasi silk pattern looks best?');
      setPollOptionA('Royal Crimson Gold 👑');
      setPollOptionB('Midnight Peacock Silk 🦚');
      setCaptionText('Live Varanasi Silk Loom Drop — Handwoven in 2-Hour Flash Window! ✨🌸');
      setIsListeningVoice(false);
      showToast('🗣️ Voice-to-Story AI: Story parameters customized!');
    }, 2000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setCapturedMediaUrl(event.target.result as string);
          showToast('📸 Custom media loaded into 3D Story Viewfinder!');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSelectScenePreset = (preset: StoryScenePreset) => {
    setCapturedMediaUrl(preset.imageUrl);
    setVisualFilter(preset.defaultFilter as StoryVisualFilter);
    setCaptionText(`${preset.title} — ${preset.defaultPrompt}`);
    setIsScenePickerOpen(false);
    showToast(`✨ Selected scene: ${preset.title}`);
  };

  const handleSynthesizeGenAiScene = () => {
    if (!genAiPrompt.trim()) return;
    setIsGeneratingAiScene(true);
    setTimeout(() => {
      setIsGeneratingAiScene(false);
      setIsGenAiModalOpen(false);
      setCapturedMediaUrl('https://images.unsplash.com/photo-1531482615713-2afd69097998?w=1080&auto=format&fit=crop&q=80');
      setVisualFilter('hologram_mesh');
      setCaptionText(`AI Synthesized Moment: "${genAiPrompt}"`);
      showToast('🔮 Gemini Generative Story Scene Synthesized!');
    }, 2000);
  };

  const handleAddSpatialText = () => {
    if (!newTextString.trim()) return;
    const newSticker: StorySpatialTextSticker = {
      id: `txt-${Date.now()}`,
      text: newTextString.trim(),
      fontStyle: newTextStyle,
      color: newTextStyle === 'neon_glow' ? '#38BDF8' : '#F43F5E',
      x: 50,
      y: 35 + (spatialTextStickers.length * 12) % 40,
      depthZ: 6,
      scale: 1,
    };
    setSpatialTextStickers((prev) => [...prev, newSticker]);
    setNewTextString('');
    showToast('🏷️ Added 3D Spatial Hologram Text Sticker!');
  };

  const toggleTagStatus = (tagId: string) => {
    setAiSmartTags((prev) =>
      prev.map((t) => (t.id === tagId ? { ...t, isTagged: !t.isTagged } : t))
    );
  };

  const handleAddProductObject = (product: Product) => {
    const newObj: InteractiveStoryObject = {
      id: `obj-prod-${Date.now()}`,
      label: product.name,
      category: 'product',
      productId: product.id,
      productDetails: {
        name: product.name,
        price: product.price,
        mrp: product.mrp,
        discountPercent: product.discountPercentage || 30,
        image: product.images?.[0] || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=500',
        inStock: true,
        deliveryEta: 'Express 30 Mins',
        sellerName: product.sellerName || 'Verified Boutique',
      },
      x: 50,
      y: 40,
      depthZ: 5,
      spatialSurface: 'floating',
      actionType: 'buy_now',
    };
    setInteractiveObjects((prev) => [...prev, newObj]);
    setIsProductPickerOpen(false);
    showToast(`🛍️ Added interactive shoppable card for "${product.name}"!`);
  };

  const handleAddSecretReward = () => {
    const newSecret: InteractiveStoryObject = {
      id: `obj-secret-${Date.now()}`,
      label: `🎁 ${secretTitle}`,
      category: 'secret_offer',
      secretReward: {
        title: secretTitle,
        promoCode: secretCode,
        discountPercent: secretDiscount,
        badgeName: 'Secret Finder',
        claimed: false,
      },
      x: 30,
      y: 75,
      depthZ: 7,
      spatialSurface: 'table',
      actionType: 'reveal_offer',
    };
    setInteractiveObjects((prev) => [...prev, newSecret]);
    setIsSecretRewardModalOpen(false);
    showToast('✨ Embedded Secret Discovery Layer into scene!');
  };

  // Helper CSS Filter Styling generator
  const getFilterStyle = (filter: StoryVisualFilter) => {
    switch (filter) {
      case 'cyberpunk_neon':
        return 'contrast(125%) saturate(160%) hue-rotate(15deg)';
      case 'golden_hour':
        return 'sepia(30%) saturate(140%) brightness(105%) contrast(110%)';
      case 'vintage_35mm':
        return 'sepia(45%) contrast(90%) brightness(95%) saturate(120%)';
      case 'hologram_mesh':
        return 'hue-rotate(180deg) saturate(180%) contrast(120%)';
      case 'dreamy_soft':
        return 'brightness(110%) contrast(95%) saturate(130%)';
      case 'noir_monochrome':
        return 'grayscale(100%) contrast(140%) brightness(90%)';
      case 'nordic_clean':
        return 'contrast(110%) saturate(85%) brightness(105%)';
      default:
        return 'none';
    }
  };

  const handlePublishStory = () => {
    const lifetimeSecondsMap: Record<StoryLifetimeDuration, number> = {
      '15m': 15 * 60,
      '30m': 30 * 60,
      '1h': 60 * 60,
      '2h': 2 * 60 * 60,
      '4h': 4 * 60 * 60,
      '6h': 6 * 60 * 60,
      '12h': 12 * 60 * 60,
      '24h': 24 * 60 * 60,
    };

    const totalSecs = lifetimeSecondsMap[selectedLifetime] || 7200;
    const now = new Date();
    const expiresAt = new Date(now.getTime() + totalSecs * 1000);

    const goalComm = goalCommunities.find((c) => c.id === selectedCommunityId);
    const tempComm = temporaryCommunities.find((c) => c.id === selectedCommunityId);
    const matchedComm = goalComm || tempComm;

    const pollPayload: StoryPollSticker | undefined = hasPollSticker
      ? {
          id: `poll-${Date.now()}`,
          question: pollQuestion,
          optionA: { id: 'opt-a', text: pollOptionA, votes: 0 },
          optionB: { id: 'opt-b', text: pollOptionB, votes: 0 },
          x: 50,
          y: 62,
          depthZ: pollDepthZ,
          totalVotes: 0,
          themeColor: pollThemeColor,
        }
      : undefined;

    const countdownPayload: StoryCountdownSticker | undefined = hasCountdownSticker
      ? {
          id: `cd-${Date.now()}`,
          title: countdownTitle,
          targetMinutes: countdownMinutes,
          badgeTheme: countdownTheme,
          x: 50,
          y: 28,
          depthZ: 5,
        }
      : undefined;

    const bountyPayload: StoryBountySticker | undefined = hasBountySticker
      ? {
          id: `bounty-${Date.now()}`,
          questTitle: bountyQuestTitle,
          tokenReward: bountyTokens,
          tokenSymbol: 'SOV',
          claimLimit: bountyLimit,
          claimedCount: 0,
          x: 50,
          y: 82,
          depthZ: 7,
        }
      : undefined;

    const authorDisplayName = ephemeralGhostMode
      ? 'Anonymous Sovereign (ZK Mask)'
      : (livingUserProfile?.name || currentUserSession.name || 'Alex Chen');

    const authorDisplayHandle = ephemeralGhostMode
      ? '@zk_ghost'
      : (livingUserProfile?.handle || '@alexchen');

    const authorDisplayAvatar = ephemeralGhostMode
      ? 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300'
      : (livingUserProfile?.avatar || currentUserSession.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300');

    const newStory: TimeShiftStoryItem = {
      id: `story-${Date.now()}`,
      storyDna: storyDna || `MOMENT-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
      authorId: ephemeralGhostMode ? 'anon-user-zk' : (livingUserProfile?.handle ? 'living-user-alex' : (currentUserSession.sellerId || 'user-me')),
      authorName: authorDisplayName,
      authorHandle: authorDisplayHandle,
      authorAvatar: authorDisplayAvatar,
      authorRole: currentUserSession.role === 'seller' ? 'seller' : 'creator',
      isVerified: !ephemeralGhostMode,
      captureMode,
      mediaUrl: capturedMediaUrl,
      depthMapUrl: capturedMediaUrl,
      parallaxStrength: captureMode === 'depth' || captureMode === 'world' ? 1.8 : 1.2,
      mediaType,
      durationSeconds: mediaType === 'video' ? Math.max(5, recordingSeconds) : 15,
      lifetimeDuration: selectedLifetime,
      publishedAt: now.toISOString(),
      expiresAt: expiresAt.toISOString(),
      totalLifetimeSeconds: totalSecs,
      remainingSeconds: totalSecs,
      currentPhase: 'reveal',
      mood: selectedMood,
      caption: captionText || 'Live 2-Hour Moment with Shoppable 3D Objects',
      interactiveObjects: [...interactiveObjects],
      pollSticker: pollPayload,
      countdownSticker: countdownPayload,
      bountySticker: bountyPayload,
      spatialTextStickers: [...spatialTextStickers],
      visualFilter,
      soundtrack: selectedSoundtrack ? {
        id: selectedSoundtrack.id,
        title: selectedSoundtrack.title,
        artist: selectedSoundtrack.artist,
        genre: selectedSoundtrack.genre,
        durationFormatted: selectedSoundtrack.durationFormatted,
        energyLevel: selectedSoundtrack.energyLevel,
        audioWaveform: selectedSoundtrack.audioWaveform,
        coverGradient: selectedSoundtrack.coverGradient,
      } : undefined,
      audienceScope,
      remixPermission,
      ephemeralGhostMode,
      aiTags: aiSmartTags.filter((t) => t.isTagged),
      communityId: matchedComm?.id,
      communityName: matchedComm?.name,
      communityType: goalComm ? 'goal_community' : tempComm ? 'temporary_community' : undefined,
      milestoneTag: milestoneTagText.trim() || undefined,
      isPersonalStory: true,
      isProfileStory: isProfileStoryFlag,
      viewedByUsers: [
        {
          id: 'user_priya',
          name: 'Priya Sharma',
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200',
          viewedAt: 'Just now',
        },
      ],
      location: isLocationAttached
        ? {
            name: locationName,
            lat: 25.3176,
            lng: 82.9739,
            radiusKm: locationRadiusKm,
            distanceMeters: 350,
          }
        : undefined,
      multiContributors: isMultiPersonEnabled
        ? [
            {
              id: 'contrib-self',
              name: authorDisplayName,
              role: currentUserSession.role === 'seller' ? 'Seller' : 'Creator',
              avatar: authorDisplayAvatar,
              mediaUrl: capturedMediaUrl,
              caption: captionText || 'Creator Live Stream',
              time: 'Just now',
            },
          ]
        : [],
      secretLayerUnlockedCount: 0,
      livePulse: {
        currentViewers: 1,
        reactionsCount: 0,
        productClicks: 0,
        isTrendingNearby: true,
      },
      momentReactions: [],
      status: 'active',
    };

    publishTimeShiftStory(newStory);
    showToast(`🚀 Published ${selectedLifetime.toUpperCase()} Living Story across network!`);
    onClose();
  };

  const handleMouseMovePreview = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!previewBoxRef.current) return;
    const rect = previewBoxRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 20;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * -20;
    setPreviewTilt({ x, y });
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-slate-100 flex flex-col select-none overflow-hidden"
    >
      {/* Top Header Bar */}
      <header className="absolute top-0 inset-x-0 z-40 p-4 flex items-center justify-between pointer-events-auto bg-gradient-to-b from-slate-100/90 via-slate-100/50 to-transparent">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-2xl bg-gradient-to-tr from-amber-400 via-orange-500 to-rose-500 flex items-center justify-center shadow-lg shadow-amber-500/20">
            <Sparkles className="w-4 h-4 text-slate-800 font-black" />
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="text-xs font-black text-white tracking-wider uppercase">
                TIME-SHIFT 3D STORY STUDIO
              </span>
              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[10px] font-extrabold">
                {selectedLifetime.toUpperCase()} LIVING STORY
              </span>
            </div>
            <p className="text-[10px] text-white/60 font-mono">
              DNA: {storyDna} • FILTER: {visualFilter.toUpperCase()}
            </p>
          </div>
        </div>

        {/* Top Right Actions */}
        <div className="flex items-center space-x-2">
          {cameraStage === 'customize' && (
            <button
              type="button"
              onClick={() => setCameraStage('preview')}
              className="px-3 py-1.5 rounded-full bg-cyan-500/20 border border-cyan-400 text-cyan-300 hover:bg-cyan-500/30 text-xs font-bold flex items-center space-x-1.5 transition-all"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>3D Preview</span>
            </button>
          )}

          <button
            id="btn-close-timeshift-camera"
            type="button"
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-md text-white flex items-center justify-center hover:bg-white/20 border border-white/20 transition-all shadow-xl"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Hidden File Input for Image/Video Upload */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileUpload}
        accept="image/*,video/*"
        className="hidden"
      />

      {/* VIEWPORT & WORKFLOW STAGES */}
      <div className="relative flex-1 w-full h-full flex flex-col justify-between overflow-hidden">
        {/* ========================================================================= */}
        {/* STAGE 1: LIVE CAPTURE & MEDIA INGESTION STUDIO */}
        {/* ========================================================================= */}
        {cameraStage === 'capture' && (
          <div className="relative w-full h-full flex flex-col justify-between items-center">
            {/* Camera Viewfinder Media */}
            <div className="relative w-full h-full flex items-center justify-center bg-white overflow-hidden">
              <img
                src={capturedMediaUrl}
                alt="Camera Live Stream"
                style={{ filter: getFilterStyle(visualFilter) }}
                className="w-full h-full object-cover transition-all duration-300"
              />

              {/* Spatial 3D Grid & Depth Indicators */}
              <div className="absolute inset-0 pointer-events-none border border-white/10">
                <div className="absolute inset-0 bg-radial from-transparent via-transparent to-slate-100/40" />

                {/* Depth Layer Grid */}
                <div className="absolute inset-8 border border-white/20 border-dashed rounded-3xl opacity-60 flex items-center justify-center">
                  <div className="text-center bg-slate-100/50 backdrop-blur-md px-3 py-1 rounded-full border border-white/20 text-[10px] text-white/80 font-mono flex items-center space-x-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    <span>SPATIAL DEPTH SENSOR: ACTIVE ({captureMode.toUpperCase()})</span>
                  </div>
                </div>

                {/* Real-Time AI Detection Bounding Boxes */}
                <div className="absolute top-1/3 left-1/4 w-32 h-44 border-2 border-emerald-400 rounded-xl animate-pulse">
                  <div className="absolute -top-5 left-0 px-2 py-0.5 bg-emerald-500 text-slate-800 text-[9px] font-black uppercase rounded">
                    Detected: Banarasi Saree (98%)
                  </div>
                </div>

                <div className="absolute bottom-1/4 right-1/4 w-28 h-20 border-2 border-purple-400 rounded-xl">
                  <div className="absolute -top-5 left-0 px-2 py-0.5 bg-purple-500 text-white text-[9px] font-black uppercase rounded">
                    Surface: Wooden Table (0.8m)
                  </div>
                </div>
              </div>

              {/* Floating Quick Media Action Bar */}
              <div className="absolute top-20 inset-x-4 flex flex-wrap items-center justify-center gap-2 z-30 pointer-events-auto">
                <button
                  id="btn-voice-to-story"
                  type="button"
                  onClick={handleVoiceCommand}
                  className={`flex items-center space-x-1.5 px-3.5 py-1.5 rounded-full backdrop-blur-xl border text-xs font-bold transition-all ${
                    isListeningVoice
                      ? 'bg-red-500/80 border-red-400 text-white animate-pulse'
                      : 'bg-slate-100/60 border-white/20 text-white hover:bg-white/20'
                  }`}
                >
                  <Mic className="w-3.5 h-3.5 text-amber-400" />
                  <span>{isListeningVoice ? 'Listening...' : 'Voice AI'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsScenePickerOpen(true)}
                  className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-full bg-slate-100/60 backdrop-blur-xl border border-white/20 text-white hover:bg-white/20 text-xs font-bold"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Scene Presets</span>
                </button>

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-full bg-slate-100/60 backdrop-blur-xl border border-white/20 text-white hover:bg-white/20 text-xs font-bold"
                >
                  <Upload className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Upload Media</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsGenAiModalOpen(true)}
                  className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-purple-600/80 to-indigo-600/80 backdrop-blur-xl border border-purple-400/40 text-white hover:brightness-110 text-xs font-bold shadow-lg"
                >
                  <Wand2 className="w-3.5 h-3.5 text-amber-300" />
                  <span>GenAI Scene Studio</span>
                </button>
              </div>

              {voiceCommandStatus && (
                <div className="absolute top-32 inset-x-6 z-30 p-2.5 bg-amber-500/90 text-slate-800 rounded-2xl text-xs font-bold text-center shadow-2xl animate-in fade-in">
                  {voiceCommandStatus}
                </div>
              )}
            </div>

            {/* Bottom Camera Controls & Mode Switcher */}
            <div className="absolute bottom-0 inset-x-0 p-6 z-30 bg-gradient-to-t from-slate-100 via-slate-100/80 to-transparent flex flex-col items-center space-y-4">
              {/* Capture Mode Selector */}
              <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar py-1 px-3 bg-slate-100/60 backdrop-blur-xl rounded-full border border-white/20">
                {(
                  [
                    { id: 'real', label: 'REAL', icon: Camera },
                    { id: 'depth', label: 'DEPTH 3D', icon: Layers },
                    { id: 'world', label: 'WORLD', icon: Globe },
                    { id: 'cinematic', label: 'CINEMATIC', icon: Film },
                    { id: 'motion', label: 'MOTION', icon: Zap },
                    { id: 'auto', label: 'AUTO AI', icon: Sparkles },
                  ] as const
                ).map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setCaptureMode(m.id)}
                    className={`px-3 py-1.5 rounded-full text-xs font-black tracking-wide flex items-center space-x-1 transition-all ${
                      captureMode === m.id
                        ? 'bg-amber-400 text-slate-800 shadow-md shadow-amber-400/30 scale-105'
                        : 'text-white/70 hover:text-white'
                    }`}
                  >
                    <span>{m.label}</span>
                  </button>
                ))}
              </div>

              {/* Shutter / Record Button */}
              <div className="flex items-center justify-between w-full max-w-sm px-6">
                {/* Media Type Toggle */}
                <button
                  type="button"
                  onClick={() => setMediaType(mediaType === 'video' ? 'photo' : 'video')}
                  className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex flex-col items-center justify-center text-white hover:bg-white/20"
                >
                  {mediaType === 'video' ? <Video className="w-5 h-5" /> : <Camera className="w-5 h-5" />}
                  <span className="text-[9px] uppercase font-bold">{mediaType}</span>
                </button>

                {/* Primary Shutter Ring */}
                {mediaType === 'video' ? (
                  <button
                    id="btn-shutter-record-video"
                    type="button"
                    onClick={isRecording ? handleStopRecording : handleStartRecording}
                    className={`w-20 h-20 rounded-full border-4 flex items-center justify-center transition-all ${
                      isRecording
                        ? 'border-red-500 bg-red-500/20 scale-110'
                        : 'border-white bg-white/20 hover:scale-105'
                    }`}
                  >
                    <div
                      className={`transition-all ${
                        isRecording
                          ? 'w-8 h-8 rounded-lg bg-red-500 animate-pulse'
                          : 'w-14 h-14 rounded-full bg-red-500 shadow-xl shadow-red-500/40'
                      }`}
                    />
                  </button>
                ) : (
                  <button
                    id="btn-shutter-capture-photo"
                    type="button"
                    onClick={handleCapturePhoto}
                    className="w-20 h-20 rounded-full border-4 border-white bg-white/20 hover:scale-105 flex items-center justify-center transition-all"
                  >
                    <div className="w-14 h-14 rounded-full bg-white shadow-xl" />
                  </button>
                )}

                {/* Lifetime Quick Selector */}
                <div className="w-12 h-12 rounded-full bg-amber-500/20 border border-amber-400 flex flex-col items-center justify-center text-amber-300">
                  <Clock className="w-4 h-4" />
                  <span className="text-[9px] font-black uppercase">{selectedLifetime}</span>
                </div>
              </div>

              {isRecording && (
                <div className="text-xs font-mono font-bold text-red-400 animate-pulse">
                  ● RECORDING: 00:{recordingSeconds < 10 ? `0${recordingSeconds}` : recordingSeconds} / 00:20
                </div>
              )}
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* STAGE 2: AI DEEP SCENE & MOMENT UNDERSTANDING */}
        {/* ========================================================================= */}
        {cameraStage === 'ai_analysis' && (
          <div className="relative w-full h-full flex flex-col items-center justify-center bg-white p-6 text-center space-y-6">
            <div className="relative w-32 h-32 rounded-full flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border-4 border-amber-400/20 border-t-amber-400 animate-spin" />
              <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-600 flex items-center justify-center shadow-2xl shadow-amber-500/40">
                <Sparkles className="w-10 h-10 text-slate-800 animate-pulse" />
              </div>
            </div>

            <div className="space-y-2 max-w-sm">
              <h3 className="text-xl font-black text-white">AI Spatial Scene Parsing</h3>
              <p className="text-xs text-slate-400">
                Analyzing scene geometry, computing depth mesh (Z-axis), detecting shoppable catalog items, and indexing neural frequency soundscapes...
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 text-left w-full max-w-xs text-[11px] font-mono text-amber-300 bg-white/5 p-3.5 rounded-2xl border border-white/10">
              <div className="flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>3D Depth Mesh (2.4m)</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Product Matched (98%)</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Poll Layer Ready</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Soundtrack Synchronized</span>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* STAGE 3: CUSTOMIZE COMPREHENSIVE STORY MATRIX */}
        {/* ========================================================================= */}
        {cameraStage === 'customize' && (
          <div className="relative w-full h-full flex flex-col justify-between bg-white overflow-y-auto">
            <div className="p-4 space-y-4 pb-28 max-w-4xl mx-auto w-full">
              {/* Media Preview Thumbnail & Caption Input */}
              <div className="flex space-x-3 bg-white/5 p-3 rounded-2xl border border-white/10">
                <div className="w-24 h-32 rounded-xl overflow-hidden bg-slate-100 flex-shrink-0 relative">
                  <img
                    src={capturedMediaUrl}
                    alt="Preview"
                    style={{ filter: getFilterStyle(visualFilter) }}
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute bottom-1 right-1 px-1.5 py-0.5 bg-slate-100/80 text-[8px] font-mono text-amber-300 rounded">
                    {visualFilter.toUpperCase()}
                  </span>
                </div>
                <div className="flex-1 flex flex-col justify-between">
                  <textarea
                    rows={3}
                    value={captionText}
                    onChange={(e) => setCaptionText(e.target.value)}
                    placeholder="Write an enticing caption for your 2-Hour Moment... (e.g. Tap saree for 20% discount or vote in the poll below!)"
                    className="w-full bg-transparent text-white text-xs font-semibold placeholder:text-slate-500 focus:outline-none resize-none"
                  />
                  <div className="flex flex-wrap items-center justify-between gap-1 text-[10px] text-slate-400 border-t border-white/10 pt-1.5">
                    <span>Story DNA: <strong className="text-amber-400">{storyDna}</strong></span>
                    <span>Audience: <strong className="text-cyan-400 uppercase">{audienceScope.replace('_', ' ')}</strong></span>
                  </div>
                </div>
              </div>

              {/* Navigation Tabs for Customizer Modules */}
              <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar p-1.5 bg-slate-100/60 rounded-2xl border border-white/10">
                {[
                  { id: 'stickers', label: '3D Widgets & Stickers', icon: Tag },
                  { id: 'filters', label: 'Visual Shaders', icon: Sparkles },
                  { id: 'audio', label: 'Soundtrack Matrix', icon: Music },
                  { id: 'audience', label: 'Audience & Sovereignty', icon: ShieldCheck },
                  { id: 'ai_tags', label: 'AI Mentions & Sync', icon: Users },
                ].map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeCustomizeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setActiveCustomizeTab(tab.id as any)}
                      className={`flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                        isActive
                          ? 'bg-amber-400 text-slate-800 shadow-md shadow-amber-400/20 font-black'
                          : 'bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{tab.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* ---------------------------------------------------- */}
              {/* TAB 1: 3D WIDGETS & STICKERS */}
              {/* ---------------------------------------------------- */}
              {activeCustomizeTab === 'stickers' && (
                <div className="space-y-4 animate-in fade-in duration-200">
                  {/* 1. Interactive 3D Poll Sticker */}
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/10 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                          <Radio className="w-3.5 h-3.5" />
                        </div>
                        <h4 className="text-xs font-black text-white">Interactive 3D Poll Sticker</h4>
                      </div>
                      <input
                        type="checkbox"
                        checked={hasPollSticker}
                        onChange={(e) => setHasPollSticker(e.target.checked)}
                        className="rounded accent-cyan-400"
                      />
                    </div>

                    {hasPollSticker && (
                      <div className="space-y-2.5 pt-1">
                        <div>
                          <label className="text-[10px] text-slate-400 font-bold uppercase">Poll Question</label>
                          <input
                            type="text"
                            value={pollQuestion}
                            onChange={(e) => setPollQuestion(e.target.value)}
                            placeholder="e.g. Should we open public early access?"
                            className="w-full mt-1 px-3 py-1.5 rounded-xl bg-slate-100/60 border border-white/10 text-white text-xs font-bold"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="text-[10px] text-slate-400 font-bold uppercase">Option A</label>
                            <input
                              type="text"
                              value={pollOptionA}
                              onChange={(e) => setPollOptionA(e.target.value)}
                              className="w-full mt-1 px-3 py-1.5 rounded-xl bg-slate-100/60 border border-white/10 text-emerald-300 text-xs font-bold"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] text-slate-400 font-bold uppercase">Option B</label>
                            <input
                              type="text"
                              value={pollOptionB}
                              onChange={(e) => setPollOptionB(e.target.value)}
                              className="w-full mt-1 px-3 py-1.5 rounded-xl bg-slate-100/60 border border-white/10 text-rose-300 text-xs font-bold"
                            />
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-1">
                          <span className="text-[10px] text-slate-400">Theme Color:</span>
                          <div className="flex space-x-1.5">
                            {(['cyan', 'purple', 'amber', 'emerald', 'rose'] as const).map((color) => (
                              <button
                                key={color}
                                type="button"
                                onClick={() => setPollThemeColor(color)}
                                className={`w-5 h-5 rounded-full border-2 transition-all ${
                                  pollThemeColor === color ? 'border-white scale-125' : 'border-transparent'
                                } ${
                                  color === 'cyan'
                                    ? 'bg-cyan-500'
                                    : color === 'purple'
                                    ? 'bg-fuchsia-500'
                                    : color === 'amber'
                                    ? 'bg-amber-500'
                                    : color === 'emerald'
                                    ? 'bg-emerald-500'
                                    : 'bg-rose-500'
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* 2. Countdown / Flash Drop Timer */}
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/10 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center">
                          <Timer className="w-3.5 h-3.5" />
                        </div>
                        <h4 className="text-xs font-black text-white">Countdown / Flash Drop Timer</h4>
                      </div>
                      <input
                        type="checkbox"
                        checked={hasCountdownSticker}
                        onChange={(e) => setHasCountdownSticker(e.target.checked)}
                        className="rounded accent-rose-400"
                      />
                    </div>

                    {hasCountdownSticker && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                        <div>
                          <label className="text-[10px] text-slate-400 font-bold uppercase">Timer Label</label>
                          <input
                            type="text"
                            value={countdownTitle}
                            onChange={(e) => setCountdownTitle(e.target.value)}
                            className="w-full mt-1 px-3 py-1.5 rounded-xl bg-slate-100/60 border border-white/10 text-white text-xs font-bold"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-400 font-bold uppercase">Target Duration (Mins)</label>
                          <input
                            type="number"
                            value={countdownMinutes}
                            onChange={(e) => setCountdownMinutes(Number(e.target.value))}
                            className="w-full mt-1 px-3 py-1.5 rounded-xl bg-slate-100/60 border border-white/10 text-amber-300 text-xs font-bold"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* 3. Token Quest & Micro-Bounty Sticker */}
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/10 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                          <Coins className="w-3.5 h-3.5" />
                        </div>
                        <h4 className="text-xs font-black text-white">Viewer Token Bounty & Micro-Quest</h4>
                      </div>
                      <input
                        type="checkbox"
                        checked={hasBountySticker}
                        onChange={(e) => setHasBountySticker(e.target.checked)}
                        className="rounded accent-amber-400"
                      />
                    </div>

                    {hasBountySticker && (
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                        <div className="sm:col-span-2">
                          <label className="text-[10px] text-slate-400 font-bold uppercase">Quest Goal</label>
                          <input
                            type="text"
                            value={bountyQuestTitle}
                            onChange={(e) => setBountyQuestTitle(e.target.value)}
                            className="w-full mt-1 px-3 py-1.5 rounded-xl bg-slate-100/60 border border-white/10 text-white text-xs font-bold"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-400 font-bold uppercase">Reward Tokens</label>
                          <input
                            type="number"
                            value={bountyTokens}
                            onChange={(e) => setBountyTokens(Number(e.target.value))}
                            className="w-full mt-1 px-3 py-1.5 rounded-xl bg-slate-100/60 border border-white/10 text-amber-300 text-xs font-bold"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* 4. 3D Spatial Hologram Text Stickers */}
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/10 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center">
                          <Type className="w-3.5 h-3.5" />
                        </div>
                        <h4 className="text-xs font-black text-white">
                          3D Spatial Hologram Text ({spatialTextStickers.length})
                        </h4>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={newTextString}
                        onChange={(e) => setNewTextString(e.target.value)}
                        placeholder="Type 3D floating hologram text..."
                        className="flex-1 px-3 py-1.5 rounded-xl bg-slate-100/60 border border-white/10 text-white text-xs font-bold"
                      />
                      <select
                        value={newTextStyle}
                        onChange={(e) => setNewTextStyle(e.target.value as any)}
                        className="px-2 py-1.5 rounded-xl bg-slate-100/60 border border-white/10 text-white text-xs font-semibold"
                      >
                        <option value="cyber_mono">Cyber Mono</option>
                        <option value="neon_glow">Neon Glow</option>
                        <option value="editorial_serif">Editorial Serif</option>
                        <option value="bold_marker">Bold Marker</option>
                      </select>
                      <button
                        type="button"
                        onClick={handleAddSpatialText}
                        className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center space-x-1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add</span>
                      </button>
                    </div>

                    {spatialTextStickers.length > 0 && (
                      <div className="space-y-1.5 pt-1">
                        {spatialTextStickers.map((stk) => (
                          <div
                            key={stk.id}
                            className="flex items-center justify-between p-2 rounded-xl bg-slate-100/40 border border-white/5 text-xs text-white"
                          >
                            <span className="font-mono font-bold text-amber-300">{stk.text}</span>
                            <div className="flex items-center space-x-2">
                              <span className="text-[10px] text-slate-400 uppercase">{stk.fontStyle}</span>
                              <button
                                type="button"
                                onClick={() => setSpatialTextStickers((prev) => prev.filter((s) => s.id !== stk.id))}
                                className="text-slate-500 hover:text-red-400 p-1"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* 5. Interactive Shoppable Product & Secret Offer Layers */}
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/10 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-black text-white flex items-center space-x-1.5">
                        <Tag className="w-4 h-4 text-emerald-400" />
                        <span>Catalog Objects & Secret Rewards ({interactiveObjects.length})</span>
                      </label>
                      <div className="flex space-x-1.5">
                        <button
                          type="button"
                          onClick={() => setIsProductPickerOpen(true)}
                          className="px-2.5 py-1 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-[10px] font-bold flex items-center space-x-1 hover:bg-emerald-500/30"
                        >
                          <Plus className="w-3 h-3" />
                          <span>Tag Product</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setIsSecretRewardModalOpen(true)}
                          className="px-2.5 py-1 rounded-lg bg-purple-500/20 border border-purple-500/30 text-purple-300 text-[10px] font-bold flex items-center space-x-1 hover:bg-purple-500/30"
                        >
                          <Gift className="w-3 h-3" />
                          <span>Secret Layer</span>
                        </button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      {interactiveObjects.map((obj) => (
                        <div
                          key={obj.id}
                          className="flex items-center justify-between p-2.5 rounded-xl bg-slate-100/40 border border-white/10"
                        >
                          <div className="flex items-center space-x-2.5">
                            {obj.category === 'product' ? (
                              <img
                                src={obj.productDetails?.image || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=100'}
                                alt={obj.label}
                                className="w-9 h-9 rounded-lg object-cover"
                              />
                            ) : (
                              <div className="w-9 h-9 rounded-lg bg-purple-500/20 border border-purple-400/40 flex items-center justify-center text-purple-300">
                                <Gift className="w-5 h-5" />
                              </div>
                            )}
                            <div>
                              <p className="text-xs font-bold text-white truncate max-w-[180px]">{obj.label}</p>
                              <p className="text-[10px] text-slate-400">
                                {obj.category === 'product'
                                  ? `₹${obj.productDetails?.price.toLocaleString('en-IN')} • Shoppable 3D Card`
                                  : `Hidden Offer (${obj.secretReward?.discountPercent}% Off)`}
                              </p>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() =>
                              setInteractiveObjects((prev) => prev.filter((o) => o.id !== obj.id))
                            }
                            className="text-slate-500 hover:text-red-400 p-1"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* ---------------------------------------------------- */}
              {/* TAB 2: VISUAL SHADERS & LIGHTING */}
              {/* ---------------------------------------------------- */}
              {activeCustomizeTab === 'filters' && (
                <div className="space-y-4 animate-in fade-in duration-200">
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/10 space-y-3">
                    <h4 className="text-xs font-black text-white flex items-center space-x-1.5">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <span>Cinematic Shader Presets</span>
                    </h4>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {(
                        [
                          { id: 'none', label: 'Natural Raw', desc: 'No grading' },
                          { id: 'golden_hour', label: 'Golden Varanasi', desc: 'Warm Amber Glow' },
                          { id: 'cyberpunk_neon', label: 'Cyberpunk Tokyo', desc: 'Neon Cyan & Magenta' },
                          { id: 'vintage_35mm', label: 'Vintage 35mm', desc: 'Retro Film Grain' },
                          { id: 'hologram_mesh', label: 'Holo-Mesh Spatial', desc: 'Iridescent Laser Grid' },
                          { id: 'dreamy_soft', label: 'Dreamy Soft Glow', desc: 'Ethereal Bloom' },
                          { id: 'noir_monochrome', label: 'Noir Monochrome', desc: 'Deep Silver Halide' },
                          { id: 'nordic_clean', label: 'Nordic Clean Minimal', desc: 'Crisp & Neutral' },
                        ] as const
                      ).map((f) => (
                        <button
                          key={f.id}
                          type="button"
                          onClick={() => setVisualFilter(f.id)}
                          className={`p-2.5 rounded-xl text-left transition-all border ${
                            visualFilter === f.id
                              ? 'bg-amber-500/20 border-amber-400 shadow-lg shadow-amber-500/10'
                              : 'bg-slate-100/40 border-white/10 hover:bg-white/5'
                          }`}
                        >
                          <p className="text-xs font-bold text-white">{f.label}</p>
                          <p className="text-[10px] text-slate-400">{f.desc}</p>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* ⏱️ STORY LIFETIME SELECTOR */}
                  <div className="space-y-2 bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-transparent p-4 rounded-2xl border border-amber-500/20">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-black text-white flex items-center space-x-1.5">
                        <Clock className="w-4 h-4 text-amber-400" />
                        <span>Story Lifetime Duration</span>
                      </label>
                      <span className="text-[10px] text-amber-400 font-bold">
                        Signature: 2 Hours
                      </span>
                    </div>

                    <div className="grid grid-cols-4 gap-1.5 pt-1">
                      {(
                        [
                          { id: '15m', label: '15 Mins' },
                          { id: '30m', label: '30 Mins' },
                          { id: '1h', label: '1 Hour' },
                          { id: '2h', label: '2 Hours ★' },
                          { id: '4h', label: '4 Hours' },
                          { id: '6h', label: '6 Hours' },
                          { id: '12h', label: '12 Hours' },
                          { id: '24h', label: '24 Hours' },
                        ] as const
                      ).map((dur) => (
                        <button
                          key={dur.id}
                          type="button"
                          onClick={() => setSelectedLifetime(dur.id)}
                          className={`py-2 rounded-xl text-xs font-black transition-all ${
                            selectedLifetime === dur.id
                              ? 'bg-amber-400 text-slate-800 shadow-lg shadow-amber-500/20 scale-105 ring-2 ring-amber-300'
                              : 'bg-white/5 text-slate-300 hover:bg-white/10 border border-white/10'
                          }`}
                        >
                          {dur.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* ---------------------------------------------------- */}
              {/* TAB 3: SOUNDTRACK MATRIX */}
              {/* ---------------------------------------------------- */}
              {activeCustomizeTab === 'audio' && (
                <div className="space-y-4 animate-in fade-in duration-200">
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/10 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-black text-white flex items-center space-x-1.5">
                        <Music className="w-4 h-4 text-cyan-400" />
                        <span>Curated Neuro-Soundtracks & Ambient Audio</span>
                      </h4>
                      <button
                        type="button"
                        onClick={() => setIsAudioPlaying(!isAudioPlaying)}
                        className="px-3 py-1 rounded-full bg-white/10 hover:bg-white/20 text-white text-xs font-bold flex items-center space-x-1"
                      >
                        {isAudioPlaying ? <Pause className="w-3 h-3 text-cyan-400" /> : <Play className="w-3 h-3 text-cyan-400" />}
                        <span>{isAudioPlaying ? 'Pause Audio' : 'Preview Soundtrack'}</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {STORY_SOUNDTRACK_PRESETS.map((track) => {
                        const isSelected = selectedSoundtrack?.id === track.id;
                        return (
                          <div
                            key={track.id}
                            onClick={() => {
                              setSelectedSoundtrack(track);
                              setIsAudioPlaying(true);
                            }}
                            className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-center space-x-3 ${
                              isSelected
                                ? 'bg-cyan-500/10 border-cyan-400 shadow-lg shadow-cyan-500/10 ring-1 ring-cyan-400'
                                : 'bg-slate-100/40 border-white/10 hover:bg-white/5'
                            }`}
                          >
                            <div className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${track.coverGradient} flex items-center justify-center text-white flex-shrink-0 shadow-md`}>
                              <Disc className={`w-5 h-5 ${isAudioPlaying && isSelected ? 'animate-spin' : ''}`} />
                            </div>

                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between">
                                <p className="text-xs font-bold text-white truncate">{track.title}</p>
                                <span className="text-[9px] font-mono text-cyan-300 font-bold">{track.durationFormatted}</span>
                              </div>
                              <p className="text-[10px] text-slate-400 truncate">{track.artist} • {track.genre}</p>

                              {/* Animated Waveform Indicator */}
                              {isSelected && isAudioPlaying && (
                                <div className="flex items-end space-x-0.5 mt-1.5 h-3">
                                  {track.audioWaveform.map((h, idx) => (
                                    <div
                                      key={idx}
                                      style={{ height: `${(h / 100) * 12}px` }}
                                      className="w-1 bg-cyan-400 rounded-full animate-pulse"
                                    />
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Audio Balance Slider */}
                    <div className="p-3 bg-slate-100/40 rounded-xl border border-white/5 space-y-1.5 mt-2">
                      <div className="flex items-center justify-between text-[11px] text-slate-300">
                        <span>Original Mic Voice ({100 - audioVolumeBalance}%)</span>
                        <span className="font-bold text-cyan-400">Background Soundtrack ({audioVolumeBalance}%)</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={100}
                        value={audioVolumeBalance}
                        onChange={(e) => setAudioVolumeBalance(Number(e.target.value))}
                        className="w-full accent-cyan-400 h-1 bg-slate-800 rounded-lg cursor-pointer"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* ---------------------------------------------------- */}
              {/* TAB 4: AUDIENCE & SOVEREIGNTY */}
              {/* ---------------------------------------------------- */}
              {activeCustomizeTab === 'audience' && (
                <div className="space-y-4 animate-in fade-in duration-200">
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/10 space-y-3">
                    <h4 className="text-xs font-black text-white flex items-center space-x-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      <span>Audience Reach & Sovereign Privacy Dial</span>
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {(
                        [
                          {
                            id: 'public_radar',
                            title: 'Public Radar (All Nearby)',
                            desc: 'Visible on hyper-local radar map & public lifeos stories',
                          },
                          {
                            id: 'inner_syndicate',
                            title: 'Inner Syndicate Circle',
                            desc: 'Restricted to close collaborators & trusted peers only',
                          },
                          {
                            id: 'community_sprint',
                            title: 'Goal Community Sprint Cohort',
                            desc: 'Broadcasted to active members of selected sprint',
                          },
                          {
                            id: 'zk_ghost_anon',
                            title: 'ZK Ghost Anonymous Mask',
                            desc: 'Publishes with cryptographic ZK identity protection',
                          },
                        ] as const
                      ).map((scope) => (
                        <button
                          key={scope.id}
                          type="button"
                          onClick={() => {
                            setAudienceScope(scope.id);
                            if (scope.id === 'zk_ghost_anon') {
                              setEphemeralGhostMode(true);
                            } else {
                              setEphemeralGhostMode(false);
                            }
                          }}
                          className={`p-3 rounded-2xl border text-left transition-all ${
                            audienceScope === scope.id
                              ? 'bg-emerald-500/10 border-emerald-400 shadow-md shadow-emerald-500/10 ring-1 ring-emerald-400'
                              : 'bg-slate-100/40 border-white/10 hover:bg-white/5'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-white">{scope.title}</span>
                            {audienceScope === scope.id && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                          </div>
                          <p className="text-[10px] text-slate-400 mt-1">{scope.desc}</p>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Multi-Person Moments & Remix Permissions */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="p-4 bg-white/5 rounded-2xl border border-white/10 space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-bold text-white flex items-center space-x-1.5">
                          <Users className="w-3.5 h-3.5 text-purple-400" />
                          <span>Multi-Person Co-Creation</span>
                        </label>
                        <input
                          type="checkbox"
                          checked={isMultiPersonEnabled}
                          onChange={(e) => setIsMultiPersonEnabled(e.target.checked)}
                          className="rounded accent-purple-400"
                        />
                      </div>
                      <p className="text-[10px] text-slate-400">
                        Allows invited sprint peers, customer, or seller to stack clips into this temporary 2-hour story.
                      </p>
                    </div>

                    <div className="p-4 bg-white/5 rounded-2xl border border-white/10 space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-bold text-white flex items-center space-x-1.5">
                          <Share2 className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Remix & Duet Permissions</span>
                        </label>
                        <select
                          value={remixPermission}
                          onChange={(e) => setRemixPermission(e.target.value as any)}
                          className="text-[11px] bg-slate-100/60 border border-white/10 rounded-lg text-white font-bold p-1"
                        >
                          <option value="open_to_all">Open to All</option>
                          <option value="community_only">Cohort Only</option>
                          <option value="disabled">Disabled</option>
                        </select>
                      </div>
                      <p className="text-[10px] text-slate-400">
                        Controls if viewers can create split-screen depth responses or quote this story into their world.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* ---------------------------------------------------- */}
              {/* TAB 5: AI MENTIONS & COMMUNITY SYNC */}
              {/* ---------------------------------------------------- */}
              {activeCustomizeTab === 'ai_tags' && (
                <div className="space-y-4 animate-in fade-in duration-200">
                  {/* AI Smart Story Tag Suggestions */}
                  <div className="space-y-2.5 bg-white/5 p-4 rounded-2xl border border-white/10">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-black text-white flex items-center space-x-1.5">
                        <Sparkles className="w-4 h-4 text-amber-400" />
                        <span>AI Smart Story Tag Suggestions</span>
                      </label>
                      <span className="text-[10px] text-slate-400">Privacy Safe • Creator Verified</span>
                    </div>

                    <div className="space-y-2">
                      {aiSmartTags.map((tag) => (
                        <div
                          key={tag.id}
                          className={`flex items-center justify-between p-2.5 rounded-xl border transition-all ${
                            tag.isTagged
                              ? 'bg-amber-500/10 border-amber-500/40'
                              : 'bg-slate-100/30 border-white/10 opacity-70'
                          }`}
                        >
                          <div className="flex items-center space-x-2.5">
                            <img
                              src={tag.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                              alt={tag.name}
                              className="w-8 h-8 rounded-full object-cover"
                            />
                            <div>
                              <div className="flex items-center space-x-1.5">
                                <span className="text-xs font-bold text-white">{tag.name}</span>
                                <span
                                  className={`px-1.5 py-0.2 rounded text-[8px] font-black uppercase ${
                                    tag.confidence === 'high'
                                      ? 'bg-emerald-500/20 text-emerald-300'
                                      : 'bg-amber-500/20 text-amber-300'
                                  }`}
                                >
                                  {tag.confidence} Match 🟢
                                </span>
                              </div>
                              <p className="text-[10px] text-slate-400 italic">"{tag.reasonWhy}"</p>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => toggleTagStatus(tag.id)}
                            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                              tag.isTagged
                                ? 'bg-amber-400 text-slate-800'
                                : 'bg-white/10 text-white hover:bg-white/20'
                            }`}
                          >
                            {tag.isTagged ? 'Tagged ✓' : 'Tag +'}
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Interconnected LifeOS Community Sync */}
                  <div className="p-4 bg-gradient-to-r from-violet-950/40 via-purple-950/30 to-slate-900/60 rounded-2xl border border-violet-500/30 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
                        <h4 className="text-xs font-black uppercase tracking-wider text-white">
                          Interconnected Community & Profile Sync
                        </h4>
                      </div>
                      <span className="text-[10px] font-bold bg-violet-500/20 text-violet-300 border border-violet-400/30 px-2 py-0.5 rounded-full">
                        Social Interlock
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-bold text-slate-300">
                          Link to Joined Community / Sprint:
                        </label>
                        <select
                          value={selectedCommunityId}
                          onChange={(e) => setSelectedCommunityId(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-slate-100/60 border border-white/20 text-white text-xs font-semibold focus:outline-none focus:border-violet-400"
                        >
                          <option value="">None (Personal Only)</option>
                          <optgroup label="Goal Communities & Sprints">
                            {goalCommunities.map((c) => (
                              <option key={c.id} value={c.id}>
                                🎯 {c.name} ({c.activeMembersCount} members)
                              </option>
                            ))}
                          </optgroup>
                          <optgroup label="Live Temporary Communities">
                            {temporaryCommunities.map((c) => (
                              <option key={c.id} value={c.id}>
                                ⚡ {c.name} ({c.activeUsersCount} online)
                              </option>
                            ))}
                          </optgroup>
                        </select>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[11px] font-bold text-slate-300">
                          Milestone / Sprint Tag:
                        </label>
                        <input
                          type="text"
                          value={milestoneTagText}
                          onChange={(e) => setMilestoneTagText(e.target.value)}
                          placeholder="e.g. Week 4 MVP Demo, Sprint Goal #1"
                          className="w-full px-3 py-2 rounded-xl bg-slate-100/60 border border-white/20 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-violet-400"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-1 border-t border-white/10">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-xs text-slate-200 font-semibold">
                          Publish to Living Profile as Active Story
                        </span>
                      </div>
                      <input
                        type="checkbox"
                        checked={isProfileStoryFlag}
                        onChange={(e) => setIsProfileStoryFlag(e.target.checked)}
                        className="rounded accent-emerald-400"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Action Footer */}
            <div className="fixed bottom-0 inset-x-0 p-4 bg-white/95 backdrop-blur-xl border-t border-white/10 flex items-center justify-between z-40">
              <button
                type="button"
                onClick={() => setCameraStage('capture')}
                className="px-4 py-2.5 rounded-xl bg-white/10 text-white text-xs font-bold hover:bg-white/20 flex items-center space-x-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retake</span>
              </button>

              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={() => setCameraStage('preview')}
                  className="px-4 py-2.5 rounded-xl bg-cyan-500/20 border border-cyan-400 text-cyan-300 text-xs font-bold hover:bg-cyan-500/30 flex items-center space-x-1.5"
                >
                  <Eye className="w-4 h-4" />
                  <span>3D Preview</span>
                </button>

                <button
                  id="btn-publish-timeshift-story"
                  type="button"
                  onClick={handlePublishStory}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-orange-500 to-rose-500 text-slate-800 text-xs font-black shadow-xl shadow-amber-500/20 hover:brightness-110 flex items-center space-x-2"
                >
                  <span>Publish {selectedLifetime.toUpperCase()} Living Story</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* STAGE 4: INTERACTIVE 3D PARALLAX PREVIEW & GYROSCOPE SIMULATOR */}
        {/* ========================================================================= */}
        {cameraStage === 'preview' && (
          <div
            ref={previewBoxRef}
            onMouseMove={handleMouseMovePreview}
            className="relative w-full h-full flex flex-col justify-between bg-white overflow-hidden items-center"
          >
            {/* 3D Parallax Canvas Viewport */}
            <div
              style={{
                perspective: '1000px',
                transform: `rotateY(${previewTilt.x}deg) rotateX(${previewTilt.y}deg)`,
                transition: 'transform 0.1s ease-out',
              }}
              className="relative w-full max-w-sm h-[80vh] rounded-3xl overflow-hidden shadow-2xl border border-white/20 mt-12 bg-slate-100 flex items-center justify-center select-none"
            >
              {/* Background Media */}
              <img
                src={capturedMediaUrl}
                alt="3D Preview"
                style={{ filter: getFilterStyle(visualFilter) }}
                className="w-full h-full object-cover scale-105"
              />

              {/* Ambient Glow Gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-100/80 via-transparent to-slate-100/60 pointer-events-none" />

              {/* Hologram Text Stickers */}
              {spatialTextStickers.map((stk) => (
                <div
                  key={stk.id}
                  style={{
                    top: `${stk.y}%`,
                    left: `${stk.x}%`,
                    transform: `translate(-50%, -50%) translateZ(${stk.depthZ * 5}px)`,
                  }}
                  className={`absolute z-20 pointer-events-none text-center px-3 py-1 rounded-full ${
                    stk.fontStyle === 'neon_glow'
                      ? 'bg-cyan-950/70 border border-cyan-400 text-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.6)] font-mono'
                      : stk.fontStyle === 'cyber_mono'
                      ? 'bg-amber-950/70 border border-amber-400 text-amber-300 font-mono tracking-widest'
                      : 'bg-slate-100/60 border border-white/30 text-white font-serif italic'
                  } text-xs font-black uppercase`}
                >
                  {stk.text}
                </div>
              ))}

              {/* Interactive Objects */}
              {interactiveObjects.map((obj) => (
                <div
                  key={obj.id}
                  style={{
                    top: `${obj.y}%`,
                    left: `${obj.x}%`,
                    transform: `translate(-50%, -50%) translateZ(${(obj.depthZ || 4) * 6}px)`,
                  }}
                  className="absolute z-20 flex items-center space-x-1.5 p-1.5 pr-3 rounded-full bg-slate-100/80 backdrop-blur-md border border-white/30 text-white shadow-2xl animate-bounce"
                >
                  {obj.category === 'product' ? (
                    <div className="w-5 h-5 rounded-full bg-emerald-500 text-slate-800 flex items-center justify-center font-bold">
                      🛍️
                    </div>
                  ) : (
                    <div className="w-5 h-5 rounded-full bg-purple-500 text-white flex items-center justify-center">
                      🎁
                    </div>
                  )}
                  <span className="text-[10px] font-bold truncate max-w-[120px]">{obj.label}</span>
                </div>
              ))}

              {/* Poll Sticker in Preview */}
              {hasPollSticker && (
                <div
                  style={{
                    top: '62%',
                    left: '50%',
                    transform: 'translate(-50%, -50%) translateZ(25px)',
                  }}
                  className={`absolute z-20 w-[85%] p-3 rounded-2xl backdrop-blur-xl border shadow-2xl ${
                    pollThemeColor === 'amber'
                      ? 'bg-white/85 border-amber-400/50 shadow-amber-500/20'
                      : pollThemeColor === 'rose'
                      ? 'bg-white/85 border-rose-400/50 shadow-rose-500/20'
                      : 'bg-white/85 border-cyan-400/50 shadow-cyan-500/20'
                  }`}
                >
                  <div className="flex items-center space-x-1.5 text-[10px] font-bold text-amber-300 mb-1">
                    <Radio className="w-3 h-3 animate-ping text-cyan-400" />
                    <span>LIVE 3D POLL</span>
                  </div>
                  <p className="text-xs font-black text-white mb-2">{pollQuestion}</p>
                  <div className="grid grid-cols-2 gap-1.5 text-[10px]">
                    <div className="p-1.5 rounded-lg bg-white/10 border border-white/10 text-white font-bold text-center">
                      {pollOptionA}
                    </div>
                    <div className="p-1.5 rounded-lg bg-white/10 border border-white/10 text-white font-bold text-center">
                      {pollOptionB}
                    </div>
                  </div>
                </div>
              )}

              {/* Soundtrack Badge Preview */}
              {selectedSoundtrack && (
                <div className="absolute top-4 left-4 z-20 flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-slate-100/70 backdrop-blur-md border border-white/20 text-white text-[10px] font-bold">
                  <Music className="w-3 h-3 text-cyan-400" />
                  <span className="truncate max-w-[140px]">{selectedSoundtrack.title}</span>
                </div>
              )}

              {/* Caption Overlay */}
              <div className="absolute bottom-4 inset-x-4 z-20 text-white text-xs font-semibold bg-slate-100/60 backdrop-blur-md p-2.5 rounded-xl border border-white/10">
                {captionText || 'No caption set'}
              </div>
            </div>

            {/* Tilt Simulator Hint */}
            <div className="p-2 text-center text-[10px] text-slate-400 font-mono">
              ✦ Move your cursor or tilt device to inspect spatial 3D layers & parallax depth
            </div>

            {/* Bottom Floating Bar */}
            <div className="p-4 w-full max-w-sm flex items-center justify-between z-30">
              <button
                type="button"
                onClick={() => setCameraStage('customize')}
                className="px-4 py-2.5 rounded-xl bg-white/10 text-white text-xs font-bold hover:bg-white/20"
              >
                Back to Edit
              </button>

              <button
                type="button"
                onClick={handlePublishStory}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-orange-500 to-rose-500 text-slate-800 text-xs font-black shadow-xl hover:brightness-110 flex items-center space-x-1.5"
              >
                <span>Publish Now</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* SUBMODAL 1: SCENE PRESET GALLERY */}
      {/* ========================================================================= */}
      {isScenePickerOpen && (
        <div className="fixed inset-0 z-60 bg-slate-100/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-white/20 rounded-3xl p-5 max-w-md w-full space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center space-x-1.5">
                <ImageIcon className="w-4 h-4 text-cyan-400" />
                <span>Thematic High-Res Scene Presets</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsScenePickerOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5 max-h-80 overflow-y-auto">
              {STORY_SCENE_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => handleSelectScenePreset(preset)}
                  className="rounded-2xl overflow-hidden border border-white/10 bg-slate-100 text-left group hover:border-cyan-400 transition-all relative"
                >
                  <img src={preset.imageUrl} alt={preset.title} className="w-full h-24 object-cover group-hover:scale-105 transition-transform" />
                  <div className="p-2 bg-white">
                    <p className="text-[11px] font-bold text-white truncate">{preset.title}</p>
                    <p className="text-[9px] text-cyan-300 font-semibold">{preset.category}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUBMODAL 2: GENAI PROMPT TO SCENE STUDIO */}
      {/* ========================================================================= */}
      {isGenAiModalOpen && (
        <div className="fixed inset-0 z-60 bg-slate-100/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-purple-400/40 rounded-3xl p-5 max-w-md w-full space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center space-x-1.5">
                <Wand2 className="w-4 h-4 text-purple-400 animate-pulse" />
                <span>Gemini GenAI Story Scene Synthesizer</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsGenAiModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Describe your vision and Gemini AI will synthesize spatial depth layers, color grades, and auto-generate the story backdrop.
            </p>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase">Creative Scene Prompt</label>
              <textarea
                rows={3}
                value={genAiPrompt}
                onChange={(e) => setGenAiPrompt(e.target.value)}
                className="w-full mt-1 p-2.5 bg-white border border-white/10 rounded-xl text-white text-xs font-semibold focus:outline-none focus:border-purple-400"
              />
            </div>

            <div className="flex flex-wrap gap-1.5">
              {[
                'Banarasi Heritage Loom at Midnight',
                'Silicon Valley Demo Pitch Stage',
                'Kyoto Cherry Blossom Zen Garden',
                'Neon Cyberpunk Hacker Den',
              ].map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => setGenAiPrompt(suggestion)}
                  className="px-2.5 py-1 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-bold hover:bg-purple-500/30"
                >
                  + {suggestion}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={handleSynthesizeGenAiScene}
              disabled={isGeneratingAiScene}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-xs shadow-xl hover:brightness-110 flex items-center justify-center space-x-2"
            >
              {isGeneratingAiScene ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin text-amber-300" />
                  <span>Synthesizing Generative Spatial Scene...</span>
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4 text-amber-300" />
                  <span>Generate Scene with Gemini</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUBMODAL 3: PRODUCT TAGGER SELECTOR */}
      {/* ========================================================================= */}
      {isProductPickerOpen && (
        <div className="fixed inset-0 z-60 bg-slate-100/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-white/20 rounded-3xl p-5 max-w-sm w-full space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center space-x-1.5">
                <Tag className="w-4 h-4 text-emerald-400" />
                <span>Select Catalog Product</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsProductPickerOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto">
              {products.slice(0, 8).map((prod) => (
                <button
                  key={prod.id}
                  type="button"
                  onClick={() => handleAddProductObject(prod)}
                  className="w-full flex items-center space-x-3 p-2 rounded-xl bg-white/5 border border-white/5 text-left hover:bg-emerald-500/10 hover:border-emerald-500/30 transition-all"
                >
                  <img
                    src={prod.images?.[0] || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=100'}
                    alt={prod.name}
                    className="w-10 h-10 rounded-lg object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-white truncate">{prod.name}</p>
                    <p className="text-[10px] text-emerald-400 font-bold">
                      ₹{prod.price.toLocaleString('en-IN')}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUBMODAL 4: SECRET REWARD CONFIG */}
      {/* ========================================================================= */}
      {isSecretRewardModalOpen && (
        <div className="fixed inset-0 z-60 bg-slate-100/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-white/20 rounded-3xl p-5 max-w-sm w-full space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center space-x-1.5">
                <Gift className="w-4 h-4 text-purple-400" />
                <span>Configure Secret Discovery Reward</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsSecretRewardModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 font-semibold">Reward Title</label>
                <input
                  type="text"
                  value={secretTitle}
                  onChange={(e) => setSecretTitle(e.target.value)}
                  className="w-full mt-1 p-2 bg-white border border-white/10 rounded-xl text-white font-bold"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-400 font-semibold">Discount %</label>
                  <input
                    type="number"
                    value={secretDiscount}
                    onChange={(e) => setSecretDiscount(Number(e.target.value))}
                    className="w-full mt-1 p-2 bg-white border border-white/10 rounded-xl text-white font-bold"
                  />
                </div>
                <div>
                  <label className="text-slate-400 font-semibold">Promo Code</label>
                  <input
                    type="text"
                    value={secretCode}
                    onChange={(e) => setSecretCode(e.target.value)}
                    className="w-full mt-1 p-2 bg-white border border-white/10 rounded-xl text-white font-bold uppercase"
                  />
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={handleAddSecretReward}
              className="w-full py-2.5 rounded-xl bg-purple-600 text-white font-bold text-xs shadow-lg hover:bg-purple-500"
            >
              Embed Secret Reward into Scene
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
