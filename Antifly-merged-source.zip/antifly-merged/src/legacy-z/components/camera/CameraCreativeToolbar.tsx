import React from 'react';
import {
  Music,
  Tag,
  Type,
  PenTool,
  Smile,
  Timer,
  Maximize2,
  Sliders,
  Sparkles,
  Zap,
  Wand2,
} from 'lucide-react';
import { CameraAspectRatio, CameraFlashMode, CameraMusicTrack } from '../../types';

interface CameraCreativeToolbarProps {
  onOpenMusicPicker: () => void;
  onOpenProductTagger: () => void;
  onToggleTextEditor: () => void;
  onToggleDrawingCanvas: () => void;
  onOpenStickerPicker: () => void;
  onToggleTimer: () => void;
  timerSeconds: number; // 0, 3, 5, 10
  onToggleAspectRatio: () => void;
  aspectRatio: CameraAspectRatio;
  onToggleFlash: () => void;
  flashMode: CameraFlashMode;
  onToggleBeautySlider: () => void;
  isBeautyActive: boolean;
  onAutoEnhanceToggle: () => void;
  isAutoEnhanceActive: boolean;
  selectedMusic?: CameraMusicTrack;
  taggedProductsCount: number;
  hasDrawings: boolean;
  hasTextOverlays: boolean;
}

export const CameraCreativeToolbar: React.FC<CameraCreativeToolbarProps> = ({
  onOpenMusicPicker,
  onOpenProductTagger,
  onToggleTextEditor,
  onToggleDrawingCanvas,
  onOpenStickerPicker,
  onToggleTimer,
  timerSeconds,
  onToggleAspectRatio,
  aspectRatio,
  onToggleFlash,
  flashMode,
  onToggleBeautySlider,
  isBeautyActive,
  onAutoEnhanceToggle,
  isAutoEnhanceActive,
  selectedMusic,
  taggedProductsCount,
  hasDrawings,
  hasTextOverlays,
}) => {
  return (
    <aside
      aria-label="Creative Studio Tools"
      className="flex flex-col items-center space-y-2.5 bg-slate-100/40 backdrop-blur-xl p-2 rounded-2xl border border-white/10 shadow-2xl z-30"
    >
      {/* Flash toggle */}
      <button
        id="camera-tool-flash"
        type="button"
        onClick={onToggleFlash}
        className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
          flashMode !== 'off'
            ? 'bg-amber-400 text-slate-800 font-bold shadow-lg shadow-amber-400/30'
            : 'text-white/80 hover:bg-white/20 hover:text-white'
        }`}
        title={`Flash: ${flashMode.toUpperCase()}`}
      >
        <Zap className="w-4 h-4" />
      </button>

      {/* Music / Soundtrack */}
      <button
        id="camera-tool-music"
        type="button"
        onClick={onOpenMusicPicker}
        className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all relative ${
          selectedMusic
            ? 'bg-gradient-to-tr from-pink-500 to-rose-500 text-white shadow-lg'
            : 'text-white/80 hover:bg-white/20 hover:text-white'
        }`}
        title="Add Music & Sound"
      >
        <Music className="w-4 h-4" />
        {selectedMusic && (
          <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full border-2 border-slate-900 animate-pulse" />
        )}
      </button>

      {/* Tag Products */}
      <button
        id="camera-tool-tag-product"
        type="button"
        onClick={onOpenProductTagger}
        className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all relative ${
          taggedProductsCount > 0
            ? 'bg-emerald-500 text-white font-bold shadow-lg shadow-emerald-500/30'
            : 'text-white/80 hover:bg-white/20 hover:text-white'
        }`}
        title="Tag Shoppable Products"
      >
        <Tag className="w-4 h-4" />
        {taggedProductsCount > 0 && (
          <span className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] bg-red-500 text-white text-[10px] font-extrabold flex items-center justify-center rounded-full px-1 border border-white">
            {taggedProductsCount}
          </span>
        )}
      </button>

      {/* Text Overlay */}
      <button
        id="camera-tool-text"
        type="button"
        onClick={onToggleTextEditor}
        className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
          hasTextOverlays
            ? 'bg-purple-600 text-white shadow-lg'
            : 'text-white/80 hover:bg-white/20 hover:text-white'
        }`}
        title="Add Text Caption"
      >
        <Type className="w-4 h-4" />
      </button>

      {/* Freehand Brush / Drawing */}
      <button
        id="camera-tool-drawing"
        type="button"
        onClick={onToggleDrawingCanvas}
        className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
          hasDrawings
            ? 'bg-orange-500 text-white shadow-lg'
            : 'text-white/80 hover:bg-white/20 hover:text-white'
        }`}
        title="Draw & Paint Brush"
      >
        <PenTool className="w-4 h-4" />
      </button>

      {/* Stickers, Emojis & Polls */}
      <button
        id="camera-tool-stickers"
        type="button"
        onClick={onOpenStickerPicker}
        className="w-9 h-9 rounded-xl flex items-center justify-center text-white/80 hover:bg-white/20 hover:text-white transition-all"
        title="Stickers, Emojis, Polls"
      >
        <Smile className="w-4 h-4" />
      </button>

      {/* Beauty / Retouch */}
      <button
        id="camera-tool-beauty"
        type="button"
        onClick={onToggleBeautySlider}
        className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
          isBeautyActive
            ? 'bg-pink-500 text-white shadow-lg shadow-pink-500/30'
            : 'text-white/80 hover:bg-white/20 hover:text-white'
        }`}
        title="Skin Smoothing & Glamour Glow"
      >
        <Sparkles className="w-4 h-4" />
      </button>

      {/* AI Auto-Enhance */}
      <button
        id="camera-tool-auto-enhance"
        type="button"
        onClick={onAutoEnhanceToggle}
        className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
          isAutoEnhanceActive
            ? 'bg-indigo-500 text-white shadow-lg'
            : 'text-white/80 hover:bg-white/20 hover:text-white'
        }`}
        title="AI Auto-Enhance Contrast & Lighting"
      >
        <Wand2 className="w-4 h-4" />
      </button>

      {/* Timer (0s, 3s, 5s, 10s) */}
      <button
        id="camera-tool-timer"
        type="button"
        onClick={onToggleTimer}
        className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all relative ${
          timerSeconds > 0
            ? 'bg-amber-500 text-slate-800 font-bold'
            : 'text-white/80 hover:bg-white/20 hover:text-white'
        }`}
        title={`Countdown Timer: ${timerSeconds === 0 ? 'Off' : `${timerSeconds}s`}`}
      >
        <Timer className="w-4 h-4" />
        {timerSeconds > 0 && (
          <span className="absolute -top-1 -right-1 text-[9px] font-black bg-white text-slate-900 rounded-full w-3.5 h-3.5 flex items-center justify-center">
            {timerSeconds}
          </span>
        )}
      </button>

      {/* Aspect Ratio (9:16, 1:1, 4:5, 16:9) */}
      <button
        id="camera-tool-aspect-ratio"
        type="button"
        onClick={onToggleAspectRatio}
        className="w-9 h-9 rounded-xl flex flex-col items-center justify-center text-white/80 hover:bg-white/20 hover:text-white transition-all text-[9px] font-bold"
        title={`Aspect Ratio: ${aspectRatio}`}
      >
        <Maximize2 className="w-3.5 h-3.5 mb-0.5" />
        <span>{aspectRatio}</span>
      </button>
    </aside>
  );
};
