import React, { useState, useMemo } from 'react';
import { Product, CameraProductTag } from '../../types';
import {
  Search,
  X,
  Tag,
  Check,
  Percent,
  Sparkles,
  ShoppingBag,
  Sliders,
  Move,
} from 'lucide-react';

interface CameraProductTaggerModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  currentTags: CameraProductTag[];
  onAddTag: (tag: CameraProductTag) => void;
  onRemoveTag: (tagId: string) => void;
  formatPrice: (inrAmount: number) => string;
}

export const CameraProductTaggerModal: React.FC<CameraProductTaggerModalProps> = ({
  isOpen,
  onClose,
  products,
  currentTags,
  onAddTag,
  onRemoveTag,
  formatPrice,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [tagStyle, setTagStyle] = useState<'pill' | 'badge' | 'card' | 'minimal'>('pill');
  const [posX, setPosX] = useState<number>(50);
  const [posY, setPosY] = useState<number>(50);
  const [accentColor, setAccentColor] = useState<string>('#dc2626');

  const filteredProducts = useMemo(() => {
    if (!searchQuery.trim()) return products.slice(0, 12);
    const q = searchQuery.toLowerCase();
    return products.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.brand?.toLowerCase().includes(q)
    );
  }, [products, searchQuery]);

  if (!isOpen) return null;

  const handleApplyTag = () => {
    if (!selectedProduct) return;
    const newTag: CameraProductTag = {
      id: `tag-${Date.now()}`,
      productId: selectedProduct.id,
      productName: selectedProduct.name,
      price: selectedProduct.price,
      mrp: selectedProduct.mrp,
      discountPercent: selectedProduct.discount,
      image: selectedProduct.images?.[0] || selectedProduct.thumbnail,
      x: posX,
      y: posY,
      style: tagStyle,
      colorHex: accentColor,
    };
    onAddTag(newTag);
    setSelectedProduct(null);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-100/80 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div className="bg-white rounded-3xl shadow-2xl max-w-xl w-full max-h-[90vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500 text-white flex items-center justify-center shadow-md">
              <Tag className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Tag Shoppable Products</h3>
              <p className="text-xs text-slate-500">Enable 1-tap checkout directly from photo or video</p>
            </div>
          </div>
          <button
            id="btn-close-product-tagger"
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200/80 text-slate-700 flex items-center justify-center hover:bg-slate-300 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Existing Active Tags */}
        {currentTags.length > 0 && (
          <div className="px-6 py-3 bg-emerald-50/60 border-b border-emerald-100 flex items-center justify-between">
            <div className="flex items-center space-x-2 overflow-x-auto no-scrollbar py-1">
              <span className="text-xs font-semibold text-emerald-800 flex-shrink-0">Active Tags:</span>
              {currentTags.map((tag) => (
                <span
                  key={tag.id}
                  className="inline-flex items-center space-x-1.5 px-2.5 py-1 bg-white rounded-full text-xs font-medium text-slate-800 shadow-sm border border-emerald-200 flex-shrink-0"
                >
                  <img src={tag.image} alt={tag.productName} className="w-4 h-4 rounded-full object-cover" />
                  <span className="truncate max-w-[120px]">{tag.productName}</span>
                  <span className="text-emerald-700 font-bold">{formatPrice(tag.price)}</span>
                  <button
                    type="button"
                    onClick={() => onRemoveTag(tag.id)}
                    className="text-slate-400 hover:text-red-500 ml-1"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {!selectedProduct ? (
            <div className="space-y-4">
              {/* Search Bar */}
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  id="camera-search-product-input"
                  type="text"
                  placeholder="Search products by title, category, or fabric..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-100 border border-slate-200 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all"
                />
              </div>

              {/* Product Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {filteredProducts.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setSelectedProduct(p)}
                    className="flex flex-col text-left p-2 rounded-2xl border border-slate-200 hover:border-emerald-500 hover:shadow-md transition-all bg-white group"
                  >
                    <div className="relative w-full aspect-square rounded-xl overflow-hidden bg-slate-100 mb-2">
                      <img
                        src={p.images?.[0] || p.thumbnail}
                        alt={p.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      {p.discount ? (
                        <span className="absolute top-1.5 left-1.5 bg-red-500 text-white text-[10px] font-extrabold px-1.5 py-0.5 rounded-md shadow-sm">
                          {p.discount}% OFF
                        </span>
                      ) : null}
                    </div>
                    <h4 className="text-xs font-semibold text-slate-900 line-clamp-1 group-hover:text-emerald-700">
                      {p.name}
                    </h4>
                    <p className="text-xs font-extrabold text-emerald-700 mt-0.5">
                      {formatPrice(p.price)}
                    </p>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            /* Configure Tag Placement & Appearance */
            <div className="space-y-5">
              <div className="flex items-center justify-between bg-slate-50 p-3 rounded-2xl border border-slate-200">
                <div className="flex items-center space-x-3">
                  <img
                    src={selectedProduct.images?.[0] || selectedProduct.thumbnail}
                    alt={selectedProduct.name}
                    className="w-12 h-12 rounded-xl object-cover"
                  />
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">{selectedProduct.name}</h4>
                    <p className="text-xs text-emerald-700 font-extrabold">{formatPrice(selectedProduct.price)}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedProduct(null)}
                  className="text-xs text-slate-500 hover:text-slate-800 font-semibold underline"
                >
                  Change Product
                </button>
              </div>

              {/* Tag Style Selector */}
              <div>
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                  Tag Visual Style
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {(['pill', 'badge', 'card', 'minimal'] as const).map((style) => (
                    <button
                      key={style}
                      type="button"
                      onClick={() => setTagStyle(style)}
                      className={`p-2.5 rounded-xl border text-center transition-all ${
                        tagStyle === style
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold ring-2 ring-emerald-500/20'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <span className="text-xs capitalize">{style}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Position On Screen */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center space-x-1">
                    <Move className="w-3.5 h-3.5 text-slate-500" />
                    <span>Screen Position (X: {posX}%, Y: {posY}%)</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => { setPosX(50); setPosY(50); }}
                    className="text-[11px] text-emerald-600 font-semibold"
                  >
                    Center
                  </button>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-3 text-xs text-slate-600">
                    <span className="w-12 font-medium">Horiz (X)</span>
                    <input
                      type="range"
                      min="10"
                      max="90"
                      value={posX}
                      onChange={(e) => setPosX(Number(e.target.value))}
                      className="flex-1 accent-emerald-600"
                    />
                    <span className="w-8 text-right font-mono">{posX}%</span>
                  </div>
                  <div className="flex items-center space-x-3 text-xs text-slate-600">
                    <span className="w-12 font-medium">Vert (Y)</span>
                    <input
                      type="range"
                      min="10"
                      max="90"
                      value={posY}
                      onChange={(e) => setPosY(Number(e.target.value))}
                      className="flex-1 accent-emerald-600"
                    />
                    <span className="w-8 text-right font-mono">{posY}%</span>
                  </div>
                </div>
              </div>

              {/* Tag Live Preview */}
              <div>
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                  Tag Live Preview
                </label>
                <div className="relative w-full h-32 rounded-2xl bg-slate-900 flex items-center justify-center overflow-hidden border border-slate-700">
                  <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px]" />
                  
                  {tagStyle === 'pill' && (
                    <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-slate-100/80 backdrop-blur-md border border-white/30 text-white shadow-xl">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                      <span className="text-xs font-bold">{selectedProduct.name}</span>
                      <span className="text-xs font-black text-emerald-400">{formatPrice(selectedProduct.price)}</span>
                    </div>
                  )}

                  {tagStyle === 'badge' && (
                    <div className="inline-flex items-center space-x-1.5 px-3 py-1 bg-red-600 text-white rounded-lg shadow-lg font-black text-xs uppercase tracking-wider">
                      <Percent className="w-3.5 h-3.5" />
                      <span>{selectedProduct.discount || 40}% OFF • {formatPrice(selectedProduct.price)}</span>
                    </div>
                  )}

                  {tagStyle === 'card' && (
                    <div className="flex items-center space-x-2.5 p-2 bg-white/95 backdrop-blur-md rounded-xl text-slate-900 shadow-2xl border border-white/40 max-w-[200px]">
                      <img
                        src={selectedProduct.images?.[0] || selectedProduct.thumbnail}
                        alt={selectedProduct.name}
                        className="w-10 h-10 rounded-lg object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-[11px] font-bold truncate">{selectedProduct.name}</p>
                        <p className="text-xs font-extrabold text-emerald-700">{formatPrice(selectedProduct.price)}</p>
                      </div>
                    </div>
                  )}

                  {tagStyle === 'minimal' && (
                    <div className="relative flex items-center justify-center">
                      <span className="w-4 h-4 rounded-full bg-white shadow-md animate-ping absolute" />
                      <span className="w-3 h-3 rounded-full bg-white shadow-lg relative border-2 border-emerald-600" />
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-sm font-semibold text-slate-600 hover:text-slate-900 transition-colors"
          >
            Cancel
          </button>
          <button
            id="camera-apply-product-tag-btn"
            type="button"
            disabled={!selectedProduct}
            onClick={handleApplyTag}
            className="px-6 py-2.5 rounded-xl bg-white text-white font-bold text-sm hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed transition-all shadow-lg flex items-center space-x-2"
          >
            <Check className="w-4 h-4" />
            <span>Place Shoppable Tag</span>
          </button>
        </div>
      </div>
    </div>
  );
};
