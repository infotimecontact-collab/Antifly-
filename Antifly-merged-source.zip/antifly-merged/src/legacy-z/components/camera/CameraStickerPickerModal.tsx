import React, { useState } from 'react';
import { CameraSticker } from '../../types';
import {
  X,
  Smile,
  Percent,
  HelpCircle,
  Clock,
  MapPin,
  Flame,
  Sparkles,
  ShoppingBag,
} from 'lucide-react';

interface CameraStickerPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddSticker: (sticker: CameraSticker) => void;
}

export const CameraStickerPickerModal: React.FC<CameraStickerPickerModalProps> = ({
  isOpen,
  onClose,
  onAddSticker,
}) => {
  const [activeCategory, setActiveCategory] = useState<'emojis' | 'badges' | 'polls' | 'locations'>('emojis');
  const [pollQuestion, setPollQuestion] = useState('Cop or Drop?');
  const [pollOptA, setPollOptA] = useState('✨ Love it!');
  const [pollOptB, setPollOptB] = useState('❌ Skip');

  if (!isOpen) return null;

  const handleCreatePoll = () => {
    const newStk: CameraSticker = {
      id: `poll-${Date.now()}`,
      type: 'poll',
      content: pollQuestion,
      x: 50,
      y: 75,
      pollData: {
        question: pollQuestion,
        optionA: pollOptA,
        optionB: pollOptB,
      },
    };
    onAddSticker(newStk);
    onClose();
  };

  const handleSelectSimple = (content: string, type: 'emoji' | 'badge' | 'location') => {
    const newStk: CameraSticker = {
      id: `stk-${Date.now()}`,
      type,
      content,
      x: 50,
      y: 50,
      scale: 1,
    };
    onAddSticker(newStk);
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-100/80 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div className="bg-slate-900 border border-white/20 rounded-3xl shadow-2xl max-w-md w-full max-h-[85vh] flex flex-col overflow-hidden text-white">
        {/* Header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-white/60">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center shadow-lg">
              <Smile className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Stickers & Interactive Widgets</h3>
              <p className="text-xs text-slate-400">Engage shoppers with polls, emojis & sale badges</p>
            </div>
          </div>
          <button
            id="btn-close-sticker-picker"
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 text-white flex items-center justify-center hover:bg-white/20 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Categories */}
        <div className="px-4 py-2 border-b border-white/10 bg-white/30 flex items-center space-x-2 overflow-x-auto no-scrollbar">
          {[
            { id: 'emojis', label: '😃 Emojis' },
            { id: 'badges', label: '🏷️ Sale Badges' },
            { id: 'polls', label: '📊 Live Polls' },
            { id: 'locations', label: '📍 Cities' },
          ].map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setActiveCategory(cat.id as any)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
                activeCategory === cat.id
                  ? 'bg-white text-slate-800 shadow-md'
                  : 'bg-white/5 text-slate-300 hover:bg-white/10'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5">
          {activeCategory === 'emojis' && (
            <div className="grid grid-cols-5 gap-3 text-center">
              {[
                '🔥', '✨', '🛍️', '💖', '💯', '⚡', '👑', '🚀', '😍', '🎉',
                '💎', '👗', '👟', '🕶️', '🌸', '🎁', '⭐', '❤️', '🤩', '🎯'
              ].map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => handleSelectSimple(emoji, 'emoji')}
                  className="aspect-square bg-white/5 hover:bg-white/15 rounded-2xl flex items-center justify-center text-3xl hover:scale-125 transition-transform"
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}

          {activeCategory === 'badges' && (
            <div className="grid grid-cols-2 gap-2.5">
              {[
                '🔥 50% OFF FLASH DROP',
                '⚡ LIMITED FESTIVE STOCK',
                '👑 LUXURY EXCLUSIVE',
                '✨ 100% PURE HANDLOOM',
                '🛍️ BUY 1 GET 1 FREE',
                '🚚 30-MIN DISPATCH',
                '🌟 TOP RATED PICK',
                '💖 CREATOR APPROVED',
              ].map((badge) => (
                <button
                  key={badge}
                  type="button"
                  onClick={() => handleSelectSimple(badge, 'badge')}
                  className="p-3 bg-red-600/80 hover:bg-red-600 border border-red-400 rounded-xl text-left font-black text-xs text-white shadow-md hover:scale-102 transition-transform"
                >
                  {badge}
                </button>
              ))}
            </div>
          )}

          {activeCategory === 'polls' && (
            <div className="space-y-4 bg-white/5 p-4 rounded-2xl border border-white/10">
              <h4 className="text-xs font-bold text-slate-300">Create Interactive Shopper Poll</h4>
              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                  Poll Question
                </label>
                <input
                  type="text"
                  value={pollQuestion}
                  onChange={(e) => setPollQuestion(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-semibold text-slate-400 block mb-1">Option A</label>
                  <input
                    type="text"
                    value={pollOptA}
                    onChange={(e) => setPollOptA(e.target.value)}
                    className="w-full px-3 py-1.5 bg-white border border-white/10 rounded-xl text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-400 block mb-1">Option B</label>
                  <input
                    type="text"
                    value={pollOptB}
                    onChange={(e) => setPollOptB(e.target.value)}
                    className="w-full px-3 py-1.5 bg-white border border-white/10 rounded-xl text-xs text-white"
                  />
                </div>
              </div>

              <button
                type="button"
                onClick={handleCreatePoll}
                className="w-full py-2 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-800 font-bold text-xs rounded-xl shadow-lg hover:brightness-110 transition-all"
              >
                Place Live Poll On Screen
              </button>
            </div>
          )}

          {activeCategory === 'locations' && (
            <div className="grid grid-cols-2 gap-2">
              {[
                '📍 Mumbai, India',
                '📍 Bengaluru, India',
                '📍 New Delhi, India',
                '📍 Hyderabad, India',
                '📍 Chennai, India',
                '📍 Kolkata, India',
                '📍 Dubai, UAE',
                '📍 London, UK',
                '📍 New York, USA',
              ].map((loc) => (
                <button
                  key={loc}
                  type="button"
                  onClick={() => handleSelectSimple(loc, 'location')}
                  className="p-2.5 bg-white/5 hover:bg-white/15 rounded-xl border border-white/10 text-xs font-semibold text-white text-left truncate hover:border-emerald-400 transition-colors"
                >
                  {loc}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
