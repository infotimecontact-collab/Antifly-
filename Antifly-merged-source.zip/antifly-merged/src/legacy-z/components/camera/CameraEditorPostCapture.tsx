import React, { useState, useRef, useEffect } from 'react';
import {
  CameraCapturedMedia,
  CameraFilterPreset,
  CameraProductTag,
  CameraTextOverlay,
  CameraSticker,
  CameraDrawingPath,
  CameraMusicTrack,
  Product,
} from '../../types';
import { DEFAULT_CAMERA_FILTERS } from '../../data/defaultCameraData';
import {
  ArrowLeft,
  Download,
  Share2,
  Send,
  Zap,
  Film,
  ShoppingBag,
  Type,
  PenTool,
  Smile,
  Tag,
  Sparkles,
  Check,
  Eye,
  Clock,
  Store,
  MessageCircle,
  Percent,
  Sliders,
  RotateCcw,
  Volume2,
  VolumeX,
} from 'lucide-react';

interface CameraEditorPostCaptureProps {
  media: CameraCapturedMedia;
  onBackToCamera: () => void;
  onSaveToGallery: (media: CameraCapturedMedia) => void;
  onSaveDraft: (media: CameraCapturedMedia) => void;
  onPublishToStory: (media: CameraCapturedMedia) => void;
  onPublishToReel: (media: CameraCapturedMedia) => void;
  onPublishToFeed: (media: CameraCapturedMedia) => void;
  onPublishToCatalog: (media: CameraCapturedMedia) => void;
  onSendToChat: (conversationId: string, media: CameraCapturedMedia) => void;
  availableChatConversations?: { id: string; name: string; avatar?: string }[];
  targetConversationId?: string | null;
  products: Product[];
  onOpenProductTagger: () => void;
  formatPrice: (amount: number) => string;
}

export const CameraEditorPostCapture: React.FC<CameraEditorPostCaptureProps> = ({
  media,
  onBackToCamera,
  onSaveToGallery,
  onSaveDraft,
  onPublishToStory,
  onPublishToReel,
  onPublishToFeed,
  onPublishToCatalog,
  onSendToChat,
  availableChatConversations = [],
  targetConversationId,
  products,
  onOpenProductTagger,
  formatPrice,
}) => {
  const [editedMedia, setEditedMedia] = useState<CameraCapturedMedia>({ ...media });
  const [activeFilter, setActiveFilter] = useState<string>(media.filterName || 'Normal');
  const [selectedPrivacy, setSelectedPrivacy] = useState(media.privacy || 'public');
  const [isViewOnce, setIsViewOnce] = useState<boolean>(media.viewOnce || false);
  const [caption, setCaption] = useState<string>(media.caption || '');
  const [hashtags, setHashtags] = useState<string>(media.hashtags?.join(' ') || '#ZoloStudio #ShopTheLook');
  const [isAudioMuted, setIsAudioMuted] = useState(false);

  // Active overlay editing states
  const [isTextEditing, setIsTextEditing] = useState(false);
  const [newTextContent, setNewTextContent] = useState('');
  const [newTextFont, setNewTextFont] = useState<'modern' | 'serif' | 'cyber' | 'script' | 'typewriter'>('modern');
  const [newTextColor, setNewTextColor] = useState('#ffffff');
  const [newTextBg, setNewTextBg] = useState('#dc2626');

  // Drawing state
  const [isDrawingMode, setIsDrawingMode] = useState(false);
  const [brushColor, setBrushColor] = useState('#ef4444');
  const [brushType, setBrushType] = useState<'pen' | 'neon' | 'highlighter' | 'eraser'>('neon');
  const [brushWidth, setBrushWidth] = useState(6);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isPainting = useRef(false);
  const currentPath = useRef<{ x: number; y: number }[]>([]);

  // Share drawer state
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [selectedChatId, setSelectedChatId] = useState<string>(targetConversationId || availableChatConversations[0]?.id || 'conv-1');

  // Sync filter CSS
  const handleSelectFilter = (filter: CameraFilterPreset) => {
    setActiveFilter(filter.name);
    setEditedMedia((prev) => ({
      ...prev,
      filterName: filter.name,
      filterCss: filter.css,
    }));
  };

  // Add text overlay
  const handleSaveTextOverlay = () => {
    if (!newTextContent.trim()) {
      setIsTextEditing(false);
      return;
    }
    const newOverlay: CameraTextOverlay = {
      id: `text-${Date.now()}`,
      text: newTextContent.trim(),
      fontStyle: newTextFont,
      color: newTextColor,
      bgColor: newTextBg,
      x: 50,
      y: 35,
    };
    setEditedMedia((prev) => ({
      ...prev,
      textOverlays: [...prev.textOverlays, newOverlay],
    }));
    setNewTextContent('');
    setIsTextEditing(false);
  };

  const handleRemoveTextOverlay = (id: string) => {
    setEditedMedia((prev) => ({
      ...prev,
      textOverlays: prev.textOverlays.filter((t) => t.id !== id),
    }));
  };

  const handleRemoveSticker = (id: string) => {
    setEditedMedia((prev) => ({
      ...prev,
      stickers: prev.stickers.filter((s) => s.id !== id),
    }));
  };

  const handleAddQuickSticker = (content: string, type: 'emoji' | 'badge' | 'poll' = 'emoji') => {
    const newStk: CameraSticker = {
      id: `stk-${Date.now()}`,
      type,
      content,
      x: Math.floor(Math.random() * 40) + 30,
      y: Math.floor(Math.random() * 40) + 30,
      scale: 1,
    };
    setEditedMedia((prev) => ({
      ...prev,
      stickers: [...prev.stickers, newStk],
    }));
  };

  // Drawing event handlers
  const handleStartDraw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawingMode || !canvasRef.current) return;
    isPainting.current = true;
    const rect = canvasRef.current.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    const x = ((clientX - rect.left) / rect.width) * 100;
    const y = ((clientY - rect.top) / rect.height) * 100;
    currentPath.current = [{ x, y }];
  };

  const handleDrawMove = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawingMode || !isPainting.current || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    const x = ((clientX - rect.left) / rect.width) * 100;
    const y = ((clientY - rect.top) / rect.height) * 100;
    currentPath.current.push({ x, y });

    // Live render
    const ctx = canvasRef.current.getContext('2d');
    if (ctx && currentPath.current.length > 1) {
      ctx.strokeStyle = brushColor;
      ctx.lineWidth = brushWidth;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      if (brushType === 'neon') {
        ctx.shadowColor = brushColor;
        ctx.shadowBlur = 12;
      } else {
        ctx.shadowBlur = 0;
      }
      ctx.beginPath();
      const p1 = currentPath.current[currentPath.current.length - 2];
      const p2 = currentPath.current[currentPath.current.length - 1];
      ctx.moveTo((p1.x / 100) * canvasRef.current.width, (p1.y / 100) * canvasRef.current.height);
      ctx.lineTo((p2.x / 100) * canvasRef.current.width, (p2.y / 100) * canvasRef.current.height);
      ctx.stroke();
    }
  };

  const handleEndDraw = () => {
    if (!isDrawingMode || !isPainting.current) return;
    isPainting.current = false;
    if (currentPath.current.length > 1) {
      const newDrawingPath: CameraDrawingPath = {
        id: `draw-${Date.now()}`,
        points: [...currentPath.current],
        color: brushColor,
        brushType,
        strokeWidth: brushWidth,
      };
      setEditedMedia((prev) => ({
        ...prev,
        drawingPaths: [...prev.drawingPaths, newDrawingPath],
      }));
    }
    currentPath.current = [];
  };

  const handleClearDrawings = () => {
    setEditedMedia((prev) => ({ ...prev, drawingPaths: [] }));
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      ctx?.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    }
  };

  // Compile final media object
  const getCompiledMedia = (): CameraCapturedMedia => ({
    ...editedMedia,
    caption,
    hashtags: hashtags.split(' ').filter((h) => h.startsWith('#')),
    privacy: selectedPrivacy as any,
    viewOnce: isViewOnce,
  });

  return (
    <div className="fixed inset-0 z-50 bg-white flex flex-col md:flex-row text-white select-none overflow-hidden">
      {/* Left / Top Stage: Full Viewport Preview Canvas */}
      <div className="relative flex-1 flex items-center justify-center bg-slate-100 overflow-hidden">
        {/* Media Surface Container */}
        <div
          className={`relative overflow-hidden shadow-2xl flex items-center justify-center ${
            editedMedia.aspectRatio === '1:1'
              ? 'aspect-square max-h-[85vh] w-auto'
              : editedMedia.aspectRatio === '4:5'
              ? 'aspect-[4/5] max-h-[85vh] w-auto'
              : 'w-full h-full max-h-[92vh] max-w-[480px] aspect-[9/16]'
          }`}
          style={{
            filter: editedMedia.filterCss || 'none',
          }}
        >
          {editedMedia.type === 'video' ? (
            <video
              src={editedMedia.mediaUrl}
              autoPlay
              loop
              playsInline
              muted={isAudioMuted}
              className="w-full h-full object-cover"
            />
          ) : (
            <img
              src={editedMedia.mediaUrl}
              alt="Capture"
              className="w-full h-full object-cover"
            />
          )}

          {/* Interactive HTML5 Drawing Canvas Overlay */}
          <canvas
            ref={canvasRef}
            width={720}
            height={1280}
            onMouseDown={handleStartDraw}
            onMouseMove={handleDrawMove}
            onMouseUp={handleEndDraw}
            onTouchStart={handleStartDraw}
            onTouchMove={handleDrawMove}
            onTouchEnd={handleEndDraw}
            className={`absolute inset-0 w-full h-full z-20 ${
              isDrawingMode ? 'pointer-events-auto cursor-crosshair' : 'pointer-events-none'
            }`}
          />

          {/* Text Overlays */}
          {editedMedia.textOverlays.map((t) => (
            <div
              key={t.id}
              style={{
                left: `${t.x}%`,
                top: `${t.y}%`,
                transform: 'translate(-50%, -50%)',
              }}
              className="absolute z-25 group cursor-pointer"
            >
              <div
                style={{
                  backgroundColor: t.bgColor || 'rgba(71,85,105,0.30)',
                  color: t.color,
                }}
                className="px-3.5 py-1.5 rounded-xl font-bold text-sm md:text-base shadow-xl backdrop-blur-sm border border-white/20 flex items-center space-x-1.5"
              >
                <span>{t.text}</span>
                <button
                  type="button"
                  onClick={() => handleRemoveTextOverlay(t.id)}
                  className="opacity-0 group-hover:opacity-100 text-white/80 hover:text-red-400 ml-1 text-xs"
                >
                  ✕
                </button>
              </div>
            </div>
          ))}

          {/* Stickers */}
          {editedMedia.stickers.map((stk) => (
            <div
              key={stk.id}
              style={{
                left: `${stk.x}%`,
                top: `${stk.y}%`,
                transform: 'translate(-50%, -50%)',
              }}
              className="absolute z-25 group cursor-pointer"
            >
              {stk.type === 'poll' && stk.pollData ? (
                <div className="bg-white/90 backdrop-blur-md text-slate-900 rounded-2xl p-3 shadow-2xl border border-white/40 min-w-[200px]">
                  <p className="text-xs font-bold text-center mb-2">{stk.pollData.question}</p>
                  <div className="grid grid-cols-2 gap-1.5 text-xs font-black">
                    <div className="bg-emerald-500 text-white text-center py-1.5 rounded-xl">
                      {stk.pollData.optionA}
                    </div>
                    <div className="bg-slate-200 text-slate-800 text-center py-1.5 rounded-xl">
                      {stk.pollData.optionB}
                    </div>
                  </div>
                </div>
              ) : stk.type === 'badge' ? (
                <div className="bg-red-600 text-white font-black text-xs px-3 py-1 rounded-full shadow-xl border border-white uppercase tracking-wider flex items-center space-x-1">
                  <span>{stk.content}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveSticker(stk.id)}
                    className="opacity-0 group-hover:opacity-100 text-white/80 hover:text-yellow-200 ml-1 text-xs"
                  >
                    ✕
                  </button>
                </div>
              ) : (
                <span className="text-4xl filter drop-shadow-lg select-none">{stk.content}</span>
              )}
            </div>
          ))}

          {/* Shoppable Product Tags */}
          {editedMedia.productTags.map((tag) => (
            <div
              key={tag.id}
              style={{
                left: `${tag.x}%`,
                top: `${tag.y}%`,
                transform: 'translate(-50%, -50%)',
              }}
              className="absolute z-30 animate-in fade-in zoom-in duration-300"
            >
              {tag.style === 'pill' ? (
                <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-white/85 backdrop-blur-md border border-white/30 text-white shadow-2xl">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-xs font-bold truncate max-w-[120px]">{tag.productName}</span>
                  <span className="text-xs font-black text-emerald-400">{formatPrice(tag.price)}</span>
                </div>
              ) : tag.style === 'card' ? (
                <div className="flex items-center space-x-2 p-1.5 bg-white/95 backdrop-blur-md rounded-xl text-slate-900 shadow-2xl border border-white max-w-[170px]">
                  <img src={tag.image} alt={tag.productName} className="w-8 h-8 rounded-lg object-cover" />
                  <div className="flex-1 min-w-0">
                    <p className="text-[10px] font-bold truncate">{tag.productName}</p>
                    <p className="text-xs font-black text-emerald-700">{formatPrice(tag.price)}</p>
                  </div>
                </div>
              ) : tag.style === 'badge' ? (
                <div className="inline-flex items-center space-x-1 px-2.5 py-1 bg-red-600 text-white rounded-lg shadow-lg font-black text-xs">
                  <Percent className="w-3 h-3" />
                  <span>{tag.discountPercent || 40}% OFF • {formatPrice(tag.price)}</span>
                </div>
              ) : (
                <div className="relative flex items-center justify-center">
                  <span className="w-3.5 h-3.5 rounded-full bg-white shadow-md animate-ping absolute" />
                  <span className="w-2.5 h-2.5 rounded-full bg-white shadow-lg relative border-2 border-emerald-600" />
                </div>
              )}
            </div>
          ))}

          {/* Top Quick Actions Floating Overlay */}
          <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-30 pointer-events-auto">
            <button
              id="camera-editor-back-btn"
              type="button"
              onClick={onBackToCamera}
              className="w-10 h-10 rounded-full bg-slate-100/50 backdrop-blur-md text-white flex items-center justify-center hover:bg-slate-100/80 border border-white/20 transition-all"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-2">
              {editedMedia.type === 'video' && (
                <button
                  type="button"
                  onClick={() => setIsAudioMuted(!isAudioMuted)}
                  className="w-9 h-9 rounded-full bg-slate-100/50 backdrop-blur-md text-white flex items-center justify-center hover:bg-slate-100/80 border border-white/20"
                >
                  {isAudioMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
              )}

              <button
                id="camera-editor-add-tag-btn"
                type="button"
                onClick={onOpenProductTagger}
                className="px-3 py-1.5 rounded-full bg-emerald-500 text-white text-xs font-bold flex items-center space-x-1 shadow-lg hover:bg-emerald-600 transition-colors"
              >
                <Tag className="w-3.5 h-3.5" />
                <span>+ Tag Product</span>
              </button>

              <button
                type="button"
                onClick={() => setIsTextEditing(true)}
                className="w-9 h-9 rounded-full bg-slate-100/50 backdrop-blur-md text-white flex items-center justify-center hover:bg-slate-100/80 border border-white/20"
                title="Add Text"
              >
                <Type className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => setIsDrawingMode(!isDrawingMode)}
                className={`w-9 h-9 rounded-full backdrop-blur-md text-white flex items-center justify-center border transition-all ${
                  isDrawingMode ? 'bg-orange-500 border-orange-400 shadow-lg' : 'bg-slate-100/50 border-white/20'
                }`}
                title="Draw Brush"
              >
                <PenTool className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick Emoji Reaction Dock */}
          <div className="absolute bottom-4 left-4 right-4 flex items-center justify-center space-x-3 z-30 pointer-events-auto">
            {['🔥', '✨', '🛍️', '💖', '💯', '⚡'].map((emoji) => (
              <button
                key={emoji}
                type="button"
                onClick={() => handleAddQuickSticker(emoji, 'emoji')}
                className="w-9 h-9 rounded-full bg-slate-100/40 backdrop-blur-md hover:bg-white/20 hover:scale-125 transition-all text-xl flex items-center justify-center border border-white/10"
              >
                {emoji}
              </button>
            ))}
            <button
              type="button"
              onClick={() => handleAddQuickSticker('50% OFF FLASH DROP', 'badge')}
              className="px-2.5 py-1 bg-red-600/90 backdrop-blur-md text-white text-[10px] font-black rounded-full shadow-lg border border-red-400 hover:scale-105 transition-all"
            >
              + Sale Badge
            </button>
          </div>
        </div>
      </div>

      {/* Right / Bottom Studio Control Dashboard */}
      <div className="w-full md:w-96 bg-slate-900 border-t md:border-t-0 md:border-l border-white/10 flex flex-col justify-between overflow-y-auto p-5 space-y-6">
        {/* Filter Carousel */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Aesthetic Color Presets</span>
            </h4>
            <span className="text-xs font-semibold text-slate-300">{activeFilter}</span>
          </div>

          <div className="flex items-center space-x-2 overflow-x-auto no-scrollbar py-1">
            {DEFAULT_CAMERA_FILTERS.map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => handleSelectFilter(f)}
                className={`flex-shrink-0 flex flex-col items-center space-y-1 p-1 rounded-xl transition-all ${
                  activeFilter === f.name
                    ? 'ring-2 ring-emerald-500 scale-105 bg-white/10'
                    : 'opacity-70 hover:opacity-100'
                }`}
              >
                <div className={`w-12 h-12 rounded-lg ${f.thumbnailColor} shadow-inner flex items-center justify-center`}>
                  {activeFilter === f.name && <Check className="w-4 h-4 text-slate-800 font-bold" />}
                </div>
                <span className="text-[10px] font-medium text-slate-300">{f.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Caption & Hashtag input */}
        <div className="space-y-3 bg-white/5 p-3.5 rounded-2xl border border-white/5">
          <div>
            <label className="text-xs font-bold text-slate-300 block mb-1">
              Shoppable Caption & Story Note
            </label>
            <input
              id="camera-post-caption-input"
              type="text"
              placeholder="Write a catchy caption (e.g., Pure Kanchipuram Silk drop!)..."
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-white/10 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div>
            <label className="text-[11px] font-semibold text-slate-400 block mb-1">
              Trending Hashtags
            </label>
            <input
              id="camera-post-hashtags-input"
              type="text"
              value={hashtags}
              onChange={(e) => setHashtags(e.target.value)}
              className="w-full px-3 py-1.5 bg-white border border-white/10 rounded-xl text-xs text-indigo-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* View-Once & Disappearing controls (WhatsApp Inspired) */}
          <div className="pt-2 border-t border-white/10 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-bold flex items-center justify-center border border-emerald-500/40">
                ①
              </span>
              <div>
                <p className="text-xs font-bold text-white">View-Once Mode</p>
                <p className="text-[10px] text-slate-400">Media disappears after first open in Chat</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsViewOnce(!isViewOnce)}
              className={`w-11 h-6 rounded-full transition-colors relative ${
                isViewOnce ? 'bg-emerald-500' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                  isViewOnce ? 'left-6' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Primary Destination Publishing Grid */}
        <div className="space-y-2.5">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
            Publish & Share Instantly
          </label>

          <div className="grid grid-cols-2 gap-2">
            {/* Share to 24h Story */}
            <button
              id="btn-publish-camera-story"
              type="button"
              onClick={() => onPublishToStory(getCompiledMedia())}
              className="flex items-center space-x-2 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-xs hover:brightness-110 shadow-lg transition-all"
            >
              <Zap className="w-4 h-4" />
              <span>Add to Story (24h)</span>
            </button>

            {/* Share to 15s Reel / Community Feed */}
            <button
              id="btn-publish-camera-reel"
              type="button"
              onClick={() => onPublishToReel(getCompiledMedia())}
              className="flex items-center space-x-2 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold text-xs hover:brightness-110 shadow-lg transition-all"
            >
              <Film className="w-4 h-4" />
              <span>Post Shoppable Reel</span>
            </button>

            {/* Publish Direct to Store Catalog (Seller Mode) */}
            <button
              id="btn-publish-camera-catalog"
              type="button"
              onClick={() => onPublishToCatalog(getCompiledMedia())}
              className="flex items-center space-x-2 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 text-white font-bold text-xs hover:brightness-110 shadow-lg transition-all"
            >
              <Store className="w-4 h-4" />
              <span>Publish to Catalog</span>
            </button>

            {/* Send Direct to Chat */}
            <button
              id="btn-publish-camera-chat"
              type="button"
              onClick={() => {
                if (targetConversationId) {
                  onSendToChat(targetConversationId, getCompiledMedia());
                } else {
                  setIsShareModalOpen(true);
                }
              }}
              className="flex items-center space-x-2 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold text-xs hover:brightness-110 shadow-lg transition-all"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Send to Chat</span>
            </button>
          </div>

          {/* Secondary Actions (Save Vault / Save Draft) */}
          <div className="flex items-center space-x-2 pt-2">
            <button
              id="btn-save-camera-vault"
              type="button"
              onClick={() => onSaveToGallery(getCompiledMedia())}
              className="flex-1 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Save to Vault</span>
            </button>

            <button
              id="btn-save-camera-draft"
              type="button"
              onClick={() => onSaveDraft(getCompiledMedia())}
              className="flex-1 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors"
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Save Draft</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Text Editor Modal Overlay */}
      {isTextEditing && (
        <div className="fixed inset-0 z-60 bg-slate-100/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-white/20 rounded-3xl p-6 max-w-md w-full space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white">Add Text Caption</h3>
              <button
                type="button"
                onClick={() => setIsTextEditing(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <textarea
              rows={2}
              placeholder="Type your message..."
              value={newTextContent}
              onChange={(e) => setNewTextContent(e.target.value)}
              className="w-full p-3 bg-white border border-white/20 rounded-xl text-white font-bold text-base focus:outline-none focus:ring-2 focus:ring-purple-500"
            />

            {/* Typography Styles */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-400">Typography Font</label>
              <div className="grid grid-cols-3 gap-1.5 text-xs font-semibold">
                {(['modern', 'serif', 'cyber', 'script', 'typewriter'] as const).map((font) => (
                  <button
                    key={font}
                    type="button"
                    onClick={() => setNewTextFont(font)}
                    className={`py-1.5 rounded-lg border capitalize ${
                      newTextFont === font
                        ? 'bg-purple-600 border-purple-500 text-white'
                        : 'bg-white/5 border-white/10 text-slate-300'
                    }`}
                  >
                    {font}
                  </button>
                ))}
              </div>
            </div>

            {/* Color Selectors */}
            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-semibold text-slate-400">Badge BG:</span>
                {['#dc2626', '#16a34a', '#2563eb', '#9333ea', '#0f172a', 'transparent'].map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setNewTextBg(c)}
                    style={{ backgroundColor: c === 'transparent' ? '#334155' : c }}
                    className={`w-6 h-6 rounded-full border-2 ${
                      newTextBg === c ? 'border-white scale-110' : 'border-transparent'
                    }`}
                  />
                ))}
              </div>
            </div>

            <div className="flex items-center justify-end space-x-2 pt-3">
              <button
                type="button"
                onClick={() => setIsTextEditing(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                id="btn-confirm-text-overlay"
                type="button"
                onClick={handleSaveTextOverlay}
                className="px-5 py-2 rounded-xl bg-purple-600 text-white text-xs font-bold shadow-lg hover:bg-purple-500"
              >
                Place Text
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Share to Chat Target Selector Modal */}
      {isShareModalOpen && (
        <div className="fixed inset-0 z-60 bg-slate-100/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-white/20 rounded-3xl p-6 max-w-sm w-full space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>Select Conversation</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsShareModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto">
              {availableChatConversations.map((conv) => (
                <button
                  key={conv.id}
                  type="button"
                  onClick={() => setSelectedChatId(conv.id)}
                  className={`w-full flex items-center space-x-3 p-2.5 rounded-xl border text-left transition-all ${
                    selectedChatId === conv.id
                      ? 'bg-emerald-500/20 border-emerald-500 text-white'
                      : 'bg-white/5 border-white/5 text-slate-300 hover:bg-white/10'
                  }`}
                >
                  <img
                    src={conv.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                    alt={conv.name}
                    className="w-8 h-8 rounded-full object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold truncate">{conv.name}</p>
                    <p className="text-[10px] text-slate-400">Direct Chat</p>
                  </div>
                  {selectedChatId === conv.id && <Check className="w-4 h-4 text-emerald-400" />}
                </button>
              ))}
            </div>

            <div className="pt-3 border-t border-white/10 flex items-center justify-end space-x-2">
              <button
                type="button"
                onClick={() => setIsShareModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                id="btn-confirm-send-to-chat"
                type="button"
                onClick={() => {
                  onSendToChat(selectedChatId, getCompiledMedia());
                  setIsShareModalOpen(false);
                }}
                className="px-5 py-2 rounded-xl bg-emerald-500 text-white text-xs font-bold shadow-lg hover:bg-emerald-600 flex items-center space-x-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send Now</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
