import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  TimeShiftStoryItem,
  InteractiveStoryObject,
  StoryMomentReaction,
  StoryReactionType,
  MultiPersonContribution,
  StoryPollSticker,
  StoryPollOption,
} from '../../types';
import { useApp } from '../../context/AppContext';
import {
  X,
  Clock,
  Eye,
  Flame,
  Heart,
  Sparkles,
  ShoppingBag,
  Store,
  MapPin,
  Gift,
  Share2,
  Volume2,
  VolumeX,
  Compass,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  Send,
  Truck,
  RotateCcw,
  BarChart2,
  BarChart3,
  AlertTriangle,
  Zap,
  Radio,
  SmilePlus,
  Copy,
  Check,
  Link,
  QrCode,
  MessageCircle,
  ExternalLink,
  Users,
  Smartphone,
  Edit3,
  Trash2,
  PlusCircle,
  HelpCircle,
  Vote,
} from 'lucide-react';

export const MOMENT_REACTION_CONFIG: {
  type: StoryReactionType;
  emoji: string;
  label: string;
  bgColor: string;
  ringColor: string;
  glowColor: string;
  textColor: string;
}[] = [
  {
    type: 'heart',
    emoji: '❤️',
    label: 'Love',
    bgColor: 'from-rose-500 to-red-600',
    ringColor: 'ring-rose-400',
    glowColor: 'shadow-[0_0_16px_rgba(244,63,94,0.9)]',
    textColor: 'text-rose-400',
  },
  {
    type: 'fire',
    emoji: '🔥',
    label: 'Fire',
    bgColor: 'from-orange-500 to-amber-600',
    ringColor: 'ring-orange-400',
    glowColor: 'shadow-[0_0_16px_rgba(249,115,22,0.9)]',
    textColor: 'text-orange-400',
  },
  {
    type: 'sparkle',
    emoji: '✨',
    label: 'Sparkle',
    bgColor: 'from-amber-400 to-yellow-500',
    ringColor: 'ring-amber-300',
    glowColor: 'shadow-[0_0_16px_rgba(251,191,36,0.9)]',
    textColor: 'text-amber-300',
  },
  {
    type: 'clap',
    emoji: '👏',
    label: 'Clap',
    bgColor: 'from-yellow-400 to-amber-500',
    ringColor: 'ring-yellow-300',
    glowColor: 'shadow-[0_0_16px_rgba(234,179,8,0.9)]',
    textColor: 'text-yellow-400',
  },
  {
    type: 'mindblown',
    emoji: '🤯',
    label: 'Mindblown',
    bgColor: 'from-fuchsia-500 to-pink-600',
    ringColor: 'ring-fuchsia-400',
    glowColor: 'shadow-[0_0_16px_rgba(217,70,239,0.9)]',
    textColor: 'text-fuchsia-400',
  },
  {
    type: 'hundred',
    emoji: '💯',
    label: '100',
    bgColor: 'from-red-500 to-rose-600',
    ringColor: 'ring-red-400',
    glowColor: 'shadow-[0_0_16px_rgba(239,68,68,0.9)]',
    textColor: 'text-red-400',
  },
  {
    type: 'diamond',
    emoji: '💎',
    label: 'Luxe',
    bgColor: 'from-cyan-400 to-blue-600',
    ringColor: 'ring-cyan-300',
    glowColor: 'shadow-[0_0_16px_rgba(6,182,212,0.9)]',
    textColor: 'text-cyan-300',
  },
  {
    type: 'rocket',
    emoji: '🚀',
    label: 'Hype',
    bgColor: 'from-blue-500 to-indigo-600',
    ringColor: 'ring-blue-400',
    glowColor: 'shadow-[0_0_16px_rgba(59,130,246,0.9)]',
    textColor: 'text-blue-400',
  },
  {
    type: 'want',
    emoji: '🛍️',
    label: 'Want',
    bgColor: 'from-emerald-400 to-teal-600',
    ringColor: 'ring-emerald-300',
    glowColor: 'shadow-[0_0_16px_rgba(16,185,129,0.9)]',
    textColor: 'text-emerald-400',
  },
  {
    type: 'wow',
    emoji: '😮',
    label: 'Wow',
    bgColor: 'from-purple-500 to-indigo-600',
    ringColor: 'ring-purple-400',
    glowColor: 'shadow-[0_0_16px_rgba(168,85,247,0.9)]',
    textColor: 'text-purple-400',
  },
];

interface TimeShift3DStoryViewerModalProps {
  story: TimeShiftStoryItem | null;
  isOpen: boolean;
  onClose: () => void;
}

export const TimeShift3DStoryViewerModal: React.FC<TimeShift3DStoryViewerModalProps> = ({
  story,
  isOpen,
  onClose,
}) => {
  const {
    timeShiftStories,
    formatPrice,
    addToCart,
    showToast,
    openSellerStorefront,
    recordStoryMomentReaction,
    unlockSecretStoryReward,
    voteStoryPoll,
    addOrUpdateStoryPoll,
    removeStoryPoll,
    currentUserSession,
  } = useApp();

  // Active Story & Index
  const [currentStoryId, setCurrentStoryId] = useState<string>(story?.id || '');
  const activeStory = timeShiftStories.find((s) => s.id === currentStoryId) || story || timeShiftStories[0];

  // Interactive Poll Sticker Creator / Editor State
  const [isPollEditorOpen, setIsPollEditorOpen] = useState<boolean>(false);
  const [pollQuestion, setPollQuestion] = useState<string>('');
  const [pollOptionA, setPollOptionA] = useState<string>('');
  const [pollOptionB, setPollOptionB] = useState<string>('');
  const [pollThemeColor, setPollThemeColor] = useState<'cyan' | 'purple' | 'amber' | 'emerald' | 'rose'>('cyan');
  const [pollDepthZ, setPollDepthZ] = useState<number>(6);
  const [pollYPercent, setPollYPercent] = useState<number>(62);
  const [pollXPercent, setPollXPercent] = useState<number>(50);

  // 3D Perspective Tilt State (Mouse / Device Gyro)
  const [tiltX, setTiltX] = useState<number>(0);
  const [tiltY, setTiltY] = useState<number>(0);
  const [is3DModeActive, setIs3DModeActive] = useState<boolean>(true);

  // Customer-Perspective Mode ("My View")
  const [isMyViewActive, setIsMyViewActive] = useState<boolean>(false);

  // Video playback & timeline
  const [playbackProgress, setPlaybackProgress] = useState<number>(0);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Deep-Link & Social Sharing Modal State
  const [isShareModalOpen, setIsShareModalOpen] = useState<boolean>(false);
  const [hasCopiedDeepLink, setHasCopiedDeepLink] = useState<boolean>(false);
  const [shareRecipientTab, setShareRecipientTab] = useState<'link' | 'direct' | 'qr'>('link');
  const [selectedSharePeerId, setSelectedSharePeerId] = useState<string>('');
  const [customShareMessage, setCustomShareMessage] = useState<string>('');
  const [isSharingLive, setIsSharingLive] = useState<boolean>(false);

  // Helper to compute seconds left from expiresAt or remainingSeconds
  const computeSecondsLeft = (storyItem?: TimeShiftStoryItem | null): number => {
    if (!storyItem) return 5100;
    if (storyItem.expiresAt) {
      const expiryMs = new Date(storyItem.expiresAt).getTime();
      if (!isNaN(expiryMs)) {
        const diffSecs = Math.floor((expiryMs - Date.now()) / 1000);
        return Math.max(0, diffSecs);
      }
    }
    return storyItem.remainingSeconds || 5100;
  };

  // Live Timer & Expiration Countdown
  const [remainingSecs, setRemainingSecs] = useState<number>(() =>
    computeSecondsLeft(activeStory)
  );
  const [showTimeWarpMenu, setShowTimeWarpMenu] = useState<boolean>(false);
  const hasTriggeredEndingSoonToast = useRef<boolean>(false);

  // Active Selected Interactive Object for Popover Card
  const [selectedObject, setSelectedObject] = useState<InteractiveStoryObject | null>(null);

  // Secret Reward Discovery state
  const [revealedSecret, setRevealedSecret] = useState<any | null>(null);

  // Multi-person story contributor active tab
  const [activeContributorIdx, setActiveContributorIdx] = useState<number>(0);

  // Moment Reaction floating particles
  const [floatingReactions, setFloatingReactions] = useState<{ id: string; type: string; emoji: string; x: number; y: number; label?: string }[]>([]);

  // Expiration Analytics Modal State
  const [isExpirationReportOpen, setIsExpirationReportOpen] = useState<boolean>(false);

  // ==========================================
  // REACTION BY MOMENT & TIMELINE RIPPLES STATE
  // ==========================================
  const stageRef = useRef<HTMLDivElement | null>(null);
  const [isLongPressing, setIsLongPressing] = useState<boolean>(false);
  const [longPressCharge, setLongPressCharge] = useState<number>(0);
  const [pressCoordinates, setPressCoordinates] = useState<{ x: number; y: number } | null>(null);
  const [momentPickerCoordinates, setMomentPickerCoordinates] = useState<{ x: number; y: number } | null>(null);
  const [showMomentReactionPicker, setShowMomentReactionPicker] = useState<boolean>(false);
  const [targetReactionTimestampSec, setTargetReactionTimestampSec] = useState<number>(0);
  const [hoveredClusterSec, setHoveredClusterSec] = useState<number | null>(null);

  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);
  const longPressIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const pressStartTimeRef = useRef<number>(0);

  // Aggregated Moment Reaction Clusters for Progress Bar Ripples
  const momentClusters = useMemo(() => {
    const map = new Map<
      number,
      {
        timestampSecond: number;
        totalCount: number;
        reactions: { type: StoryReactionType; count: number; config: typeof MOMENT_REACTION_CONFIG[0] }[];
        dominantConfig: typeof MOMENT_REACTION_CONFIG[0];
      }
    >();

    const reactions = activeStory.momentReactions || [];
    reactions.forEach((m) => {
      const sec = m.timestampSecond;
      const config = MOMENT_REACTION_CONFIG.find((c) => c.type === m.reactionType) || MOMENT_REACTION_CONFIG[0];

      if (!map.has(sec)) {
        map.set(sec, {
          timestampSecond: sec,
          totalCount: 0,
          reactions: [],
          dominantConfig: config,
        });
      }
      const entry = map.get(sec)!;
      entry.totalCount += m.count;
      entry.reactions.push({ type: m.reactionType, count: m.count, config });

      // Identify dominant reaction at this timestamp
      const dominant = entry.reactions.reduce((max, cur) => (cur.count > max.count ? cur : max), entry.reactions[0]);
      entry.dominantConfig = dominant.config;
    });

    return Array.from(map.values()).sort((a, b) => a.timestampSecond - b.timestampSecond);
  }, [activeStory.momentReactions]);

  // Current exact video playback time in seconds
  const currentPlaybackSec = useMemo(() => {
    return Math.round((playbackProgress / 100) * (activeStory.durationSeconds || 15));
  }, [playbackProgress, activeStory.durationSeconds]);

  // Fetch story moment reactions from backend on mount or switch
  useEffect(() => {
    if (!isOpen || !activeStory?.id) return;
    fetch(`/api/stories/${activeStory.id}/reactions`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.momentReactions) {
          activeStory.momentReactions = data.momentReactions;
        }
      })
      .catch(() => {});
  }, [isOpen, activeStory?.id]);

  // Reset state on story switch
  useEffect(() => {
    if (story) {
      setCurrentStoryId(story.id);
      const secs = computeSecondsLeft(story);
      setRemainingSecs(secs);
      setSelectedObject(null);
      setRevealedSecret(null);
      setPlaybackProgress(0);
      setActiveContributorIdx(0);
      setShowMomentReactionPicker(false);
      setIsLongPressing(false);
      setLongPressCharge(0);
      hasTriggeredEndingSoonToast.current = false;
    }
  }, [story]);

  // Live Story Countdown Interval (Server-synced countdown based on expiresAt timestamp)
  useEffect(() => {
    if (!isOpen || !activeStory) return;

    const timer = setInterval(() => {
      setRemainingSecs((prev) => {
        // If expiresAt is set, calculate exact real-world delta
        if (activeStory.expiresAt) {
          const expiryMs = new Date(activeStory.expiresAt).getTime();
          if (!isNaN(expiryMs)) {
            const diffSecs = Math.floor((expiryMs - Date.now()) / 1000);
            if (diffSecs <= 0) {
              return 0;
            }
            return diffSecs;
          }
        }
        if (prev <= 1) {
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen, activeStory]);

  // Video progress bar interval
  useEffect(() => {
    if (!isOpen || isPaused) return;

    const progressTimer = setInterval(() => {
      setPlaybackProgress((prev) => {
        if (prev >= 100) {
          return 0; // Loop story playback
        }
        return prev + 1;
      });
    }, (activeStory?.durationSeconds ? (activeStory.durationSeconds * 1000) / 100 : 200));

    return () => clearInterval(progressTimer);
  }, [isOpen, isPaused, activeStory]);

  // Total Lifetime helper
  const totalLifetimeSecs = (() => {
    switch (activeStory?.lifetimeDuration) {
      case '15m': return 900;
      case '30m': return 1800;
      case '1h': return 3600;
      case '2h': return 7200;
      case '4h': return 14400;
      case '6h': return 21600;
      case '12h': return 43200;
      case '24h': return 86400;
      default: return 7200;
    }
  })();

  // Detect when expiresAt timestamp is less than 5 minutes (300 seconds) away
  const isEndingSoon = useMemo(() => {
    if (remainingSecs > 0 && remainingSecs <= 300) return true;
    if (activeStory?.expiresAt) {
      const expiryMs = new Date(activeStory.expiresAt).getTime();
      if (!isNaN(expiryMs)) {
        const diffSecs = Math.floor((expiryMs - Date.now()) / 1000);
        return diffSecs > 0 && diffSecs <= 300;
      }
    }
    return false;
  }, [remainingSecs, activeStory?.expiresAt]);

  const isCriticalUrgency = remainingSecs > 0 && remainingSecs <= 60; // <= 1 min
  const isExpired = remainingSecs <= 0;
  const expirationPercentRemaining = Math.max(0, Math.min(100, (remainingSecs / totalLifetimeSecs) * 100));

  // Trigger Ending Soon notification when entering under 5 minutes
  useEffect(() => {
    if (isEndingSoon && !hasTriggeredEndingSoonToast.current) {
      hasTriggeredEndingSoonToast.current = true;
      showToast('⚠️ Urgency Alert: This Time-Shift 3D Story is Ending Soon (< 5m left)!');
    }
  }, [isEndingSoon, showToast]);

  // Mouse Move 3D Parallax Tracking
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!is3DModeActive) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5; // -0.5 to +0.5
    const y = (e.clientY - rect.top) / rect.height - 0.5; // -0.5 to +0.5
    setTiltX(x * 25); // tilt degree
    setTiltY(-y * 25);
  };

  const handleMouseLeave = () => {
    setTiltX(0);
    setTiltY(0);
  };

  if (!isOpen || !activeStory) return null;

  // Format seconds to HH:MM:SS
  const formatCountdown = (totalSecs: number) => {
    if (totalSecs <= 0) return '00:00:00 (EXPIRED)';
    const h = Math.floor(totalSecs / 3600);
    const m = Math.floor((totalSecs % 3600) / 60);
    const s = totalSecs % 60;
    return `${h < 10 ? `0${h}` : h}:${m < 10 ? `0${m}` : m}:${s < 10 ? `0${s}` : s}`;
  };

  // Urgency indicator class
  const getUrgencyBadge = () => {
    if (remainingSecs <= 0) {
      return { text: 'EXPIRED', bg: 'bg-red-600 text-white' };
    }
    if (remainingSecs <= 300) {
      return { text: '🔥 FINAL 5 MINS', bg: 'bg-red-500 text-white animate-pulse' };
    }
    if (remainingSecs <= 600) {
      return { text: '⚡ 10 MINS LEFT', bg: 'bg-orange-500 text-slate-800 font-black' };
    }
    if (remainingSecs <= 1800) {
      return { text: '⏳ 30 MINS LEFT', bg: 'bg-amber-400 text-slate-800 font-black' };
    }
    return { text: `${activeStory.lifetimeDuration.toUpperCase()} LIVING STORY`, bg: 'bg-amber-500/20 text-amber-300 border border-amber-500/40' };
  };

  const urgency = getUrgencyBadge();

  // Canonical Deep Link URL calculation
  const storyDeepLinkUrl = useMemo(() => {
    if (typeof window !== 'undefined') {
      const base = `${window.location.origin}${window.location.pathname}`;
      return `${base}?storyId=${activeStory.id}&dna=${activeStory.storyDna}&mode=timeshift3d`;
    }
    return `https://infotime.app/stories/${activeStory.id}`;
  }, [activeStory.id, activeStory.storyDna]);

  // Handle Clipboard Copy of Deep Link
  const handleCopyDeepLink = async () => {
    try {
      if (typeof navigator !== 'undefined' && navigator.clipboard) {
        await navigator.clipboard.writeText(storyDeepLinkUrl);
        setHasCopiedDeepLink(true);
        showToast('🔗 Deep-Link copied to clipboard!');
        setTimeout(() => setHasCopiedDeepLink(false), 2500);
      }
    } catch (_) {
      showToast('🔗 Deep-Link: ' + storyDeepLinkUrl);
    }
  };

  // Handle Native Web Share API or open Share modal
  const handleNativeOrModalShare = async () => {
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: `3D Story by ${activeStory.authorName} // ${activeStory.storyDna}`,
          text: `Explore this 2-Hour Time-Shift 3D Story on Infotime: "${activeStory.caption}"`,
          url: storyDeepLinkUrl,
        });
        showToast('🚀 Story shared successfully!');
        return;
      } catch (err) {
        // User dismissed native share sheet; fallback to modal
      }
    }
    setIsPaused(true);
    setIsShareModalOpen(true);
  };

  // Social share intent triggers
  const handleShareToExternal = (platform: 'whatsapp' | 'twitter' | 'telegram' | 'linkedin') => {
    const text = encodeURIComponent(`⚡ Check out this 2-Hour Time-Shift 3D Story by ${activeStory.authorName} on Infotime!\n\n"${activeStory.caption}"\n\n`);
    const encodedUrl = encodeURIComponent(storyDeepLinkUrl);

    let targetUrl = '';
    switch (platform) {
      case 'whatsapp':
        targetUrl = `https://api.whatsapp.com/send?text=${text}${encodedUrl}`;
        break;
      case 'twitter':
        targetUrl = `https://twitter.com/intent/tweet?text=${text}&url=${encodedUrl}&hashtags=Infotime3D,TimeShift,LifeOS`;
        break;
      case 'telegram':
        targetUrl = `https://t.me/share/url?url=${encodedUrl}&text=${text}`;
        break;
      case 'linkedin':
        targetUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`;
        break;
    }

    if (typeof window !== 'undefined') {
      window.open(targetUrl, '_blank', 'noopener,noreferrer');
      showToast(`📤 Opened ${platform.toUpperCase()} to share story deep-link!`);
    }
  };

  // Send Story via In-App Direct Message
  const handleSendDirectMessageToPeer = (peerName: string) => {
    setIsSharingLive(true);
    setTimeout(() => {
      setIsSharingLive(false);
      setIsShareModalOpen(false);
      setIsPaused(false);
      showToast(`💬 Deep-Link sent to ${peerName} with interactive 3D preview card!`);
    }, 600);
  };

  // ==========================================
  // INTERACTIVE POLL STICKER HANDLERS
  // ==========================================
  const handleOpenPollEditor = () => {
    setIsPaused(true);
    if (activeStory.pollSticker) {
      setPollQuestion(activeStory.pollSticker.question);
      setPollOptionA(activeStory.pollSticker.optionA.text);
      setPollOptionB(activeStory.pollSticker.optionB.text);
      setPollThemeColor(activeStory.pollSticker.themeColor || 'cyan');
      setPollDepthZ(activeStory.pollSticker.depthZ || 6);
      setPollYPercent(activeStory.pollSticker.y || 62);
      setPollXPercent(activeStory.pollSticker.x || 50);
    } else {
      setPollQuestion('Which festive styling option looks more royal? ✨');
      setPollOptionA('Crimson Zari ❤️');
      setPollOptionB('Royal Emerald 💚');
      setPollThemeColor('cyan');
      setPollDepthZ(6);
      setPollYPercent(62);
      setPollXPercent(50);
    }
    setIsPollEditorOpen(true);
  };

  const handleSavePoll = () => {
    if (!pollQuestion.trim() || !pollOptionA.trim() || !pollOptionB.trim()) {
      showToast('⚠️ Please provide a poll question and both options');
      return;
    }

    const existing = activeStory.pollSticker;
    const newPoll: StoryPollSticker = {
      id: existing?.id || `poll-${Date.now()}`,
      question: pollQuestion.trim(),
      optionA: {
        id: existing?.optionA?.id || 'opt-a',
        text: pollOptionA.trim(),
        votes: existing?.optionA?.votes || 0,
      },
      optionB: {
        id: existing?.optionB?.id || 'opt-b',
        text: pollOptionB.trim(),
        votes: existing?.optionB?.votes || 0,
      },
      x: pollXPercent,
      y: pollYPercent,
      depthZ: pollDepthZ,
      totalVotes: existing?.totalVotes || ((existing?.optionA?.votes || 0) + (existing?.optionB?.votes || 0)),
      userVotedOptionId: existing?.userVotedOptionId,
      themeColor: pollThemeColor,
      createdAt: existing?.createdAt || new Date().toISOString(),
    };

    addOrUpdateStoryPoll(activeStory.id, newPoll);
    setIsPollEditorOpen(false);
    setIsPaused(false);
  };

  const handleDeletePoll = () => {
    if (activeStory.pollSticker) {
      removeStoryPoll(activeStory.id, activeStory.pollSticker.id);
    }
    setIsPollEditorOpen(false);
    setIsPaused(false);
  };

  const handleVotePoll = (optionId: string, e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
    }
    if (!activeStory.pollSticker) return;

    const currentPoll = activeStory.pollSticker;
    const isOptionA = optionId === 'opt-a' || optionId === currentPoll.optionA.id;
    const selectedText = isOptionA ? currentPoll.optionA.text : currentPoll.optionB.text;

    // Trigger Context Vote with real-time percentage recalculation
    voteStoryPoll(activeStory.id, currentPoll.id, optionId);

    // Haptic vibration feedback
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate([25, 40, 25]);
      } catch (_) {}
    }

    // Spawn celebratory floating reaction particles around the poll
    const pollX = currentPoll.x || 50;
    const pollY = currentPoll.y || 62;

    const voteParticles = [
      {
        id: `poll-v-${Date.now()}-1`,
        type: 'sparkle',
        emoji: '📊',
        x: pollX - 12,
        y: pollY - 6,
        scale: 1.3,
        driftX: -14,
        label: 'Voted!',
      },
      {
        id: `poll-v-${Date.now()}-2`,
        type: 'sparkle',
        emoji: isOptionA ? '✨' : '🔥',
        x: pollX + 12,
        y: pollY - 8,
        scale: 1.3,
        driftX: 16,
        label: 'Live %',
      },
      {
        id: `poll-v-${Date.now()}-3`,
        type: 'sparkle',
        emoji: '🎉',
        x: pollX,
        y: pollY - 12,
        scale: 1.1,
        driftX: Math.random() * 10 - 5,
      },
    ];

    setFloatingReactions((prev) => [...prev, ...voteParticles]);

    setTimeout(() => {
      setFloatingReactions((prev) => prev.filter((p) => !voteParticles.some((vp) => vp.id === p.id)));
    }, 2500);

    showToast(`📊 Vote recorded: "${selectedText}"`);
  };

  // Reaction handler with multi-particle physics burst & live pulse
  const handleSendReaction = (
    type: StoryReactionType,
    customTimestampSec?: number,
    spawnCoords?: { x: number; y: number }
  ) => {
    const timestampSec =
      customTimestampSec !== undefined
        ? customTimestampSec
        : Math.round((playbackProgress / 100) * (activeStory.durationSeconds || 15));

    recordStoryMomentReaction(activeStory.id, timestampSec, type);

    // Increment local live counter for instant tactile feedback
    if (activeStory.livePulse) {
      activeStory.livePulse.reactionsCount = (activeStory.livePulse.reactionsCount || 0) + 1;
    }

    const config = MOMENT_REACTION_CONFIG.find((c) => c.type === type) || MOMENT_REACTION_CONFIG[0];

    // Haptic vibration feedback if supported
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate(35);
      } catch (_) {}
    }

    // Spawn 4-5 multi-scale floating particles with dynamic randomized drift
    const spawnX = spawnCoords ? spawnCoords.x : Math.random() * 40 + 30;
    const spawnY = spawnCoords ? spawnCoords.y : 80;

    const newParticles = [
      {
        id: `p-${Date.now()}-1`,
        type,
        emoji: config.emoji,
        x: spawnX,
        y: spawnY,
        scale: 1.3,
        driftX: Math.random() * 20 - 10,
        label: `00:${timestampSec < 10 ? `0${timestampSec}` : timestampSec}`,
      },
      {
        id: `p-${Date.now()}-2`,
        type,
        emoji: config.emoji,
        x: Math.max(10, Math.min(90, spawnX + (Math.random() * 24 - 12))),
        y: Math.max(15, spawnY - 6),
        scale: 1.0,
        driftX: Math.random() * 30 - 15,
      },
      {
        id: `p-${Date.now()}-3`,
        type,
        emoji: config.emoji,
        x: Math.max(10, Math.min(90, spawnX + (Math.random() * 30 - 15))),
        y: Math.max(15, spawnY - 12),
        scale: 0.85,
        driftX: Math.random() * 40 - 20,
      },
      {
        id: `p-${Date.now()}-4`,
        type,
        emoji: config.emoji,
        x: Math.max(10, Math.min(90, spawnX + (Math.random() * 20 - 10))),
        y: Math.max(15, spawnY + 4),
        scale: 1.15,
        driftX: Math.random() * 20 - 10,
      },
    ];

    setFloatingReactions((prev) => [...prev, ...newParticles]);

    setTimeout(() => {
      setFloatingReactions((prev) => prev.filter((p) => !newParticles.some((np) => np.id === p.id)));
    }, 2000);

    setShowMomentReactionPicker(false);
    setIsLongPressing(false);
    setLongPressCharge(0);

    showToast(`${config.emoji} Reacted with ${config.label} at 00:${timestampSec < 10 ? `0${timestampSec}` : timestampSec}!`);
  };

  // Stage Pointer Down: begins long-press timer and captures tap timestamp
  const handleStagePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if ((e.target as HTMLElement).closest('button, [role="button"], input, a')) {
      return;
    }

    if (!stageRef.current) return;
    const rect = stageRef.current.getBoundingClientRect();
    const xPct = ((e.clientX - rect.left) / rect.width) * 100;
    const yPct = ((e.clientY - rect.top) / rect.height) * 100;

    const currentSec = Math.round((playbackProgress / 100) * (activeStory.durationSeconds || 15));
    setTargetReactionTimestampSec(currentSec);
    setPressCoordinates({ x: xPct, y: yPct });
    pressStartTimeRef.current = Date.now();
    setIsLongPressing(true);
    setLongPressCharge(0);

    // Charge progress animation interval (300ms)
    let progress = 0;
    longPressIntervalRef.current = setInterval(() => {
      progress += 15;
      setLongPressCharge(Math.min(100, progress));
    }, 45);

    // Long press trigger (300ms threshold)
    longPressTimerRef.current = setTimeout(() => {
      if (longPressIntervalRef.current) clearInterval(longPressIntervalRef.current);
      setIsPaused(true);
      setMomentPickerCoordinates({ x: xPct, y: Math.max(20, Math.min(75, yPct)) });
      setShowMomentReactionPicker(true);
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try {
          navigator.vibrate(50);
        } catch (_) {}
      }
    }, 300);
  };

  // Stage Pointer Up: triggers tap reaction or clears long-press state
  const handleStagePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (longPressTimerRef.current) clearTimeout(longPressTimerRef.current);
    if (longPressIntervalRef.current) clearInterval(longPressIntervalRef.current);

    const pressDuration = Date.now() - pressStartTimeRef.current;

    // Quick Tap (< 300ms): Instant Moment Reaction at touch coordinates
    if (pressDuration < 300 && isLongPressing && !showMomentReactionPicker) {
      if (!(e.target as HTMLElement).closest('button, [role="button"], input')) {
        const rect = stageRef.current?.getBoundingClientRect();
        const xPct = rect ? ((e.clientX - rect.left) / rect.width) * 100 : 50;
        const yPct = rect ? ((e.clientY - rect.top) / rect.height) * 100 : 65;
        handleSendReaction('heart', targetReactionTimestampSec, { x: xPct, y: yPct });
      }
    }

    setIsLongPressing(false);
    setLongPressCharge(0);
  };

  const handleStagePointerCancel = () => {
    if (longPressTimerRef.current) clearTimeout(longPressTimerRef.current);
    if (longPressIntervalRef.current) clearInterval(longPressIntervalRef.current);
    setIsLongPressing(false);
    setLongPressCharge(0);
  };

  // Progress Bar Seek & Timestamp selection handler
  const handleTimelineSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const pct = Math.max(0, Math.min(100, (clickX / rect.width) * 100));
    setPlaybackProgress(pct);
    const targetSec = Math.round((pct / 100) * (activeStory.durationSeconds || 15));
    setTargetReactionTimestampSec(targetSec);
  };

  // Interactive Object click handler
  const handleObjectClick = (obj: InteractiveStoryObject, e: React.MouseEvent) => {
    e.stopPropagation();
    if (obj.category === 'secret_offer' && obj.secretReward) {
      setRevealedSecret(obj.secretReward);
      unlockSecretStoryReward(activeStory.id, obj.id);
      showToast('🎉 Secret Discovery Unlocked: 20% Off Coupon!');
    } else {
      setSelectedObject(obj);
    }
  };

  // Next/Prev story navigation
  const currentIndex = timeShiftStories.findIndex((s) => s.id === activeStory.id);
  const handlePrevStory = () => {
    if (currentIndex > 0) {
      setCurrentStoryId(timeShiftStories[currentIndex - 1].id);
    }
  };
  const handleNextStory = () => {
    if (currentIndex < timeShiftStories.length - 1) {
      setCurrentStoryId(timeShiftStories[currentIndex + 1].id);
    }
  };

  // Multi-person contributor list
  const currentContributor = activeStory.multiContributors?.[activeContributorIdx] || {
    id: 'primary',
    name: activeStory.authorName,
    role: activeStory.authorRole === 'seller' ? 'Seller' : 'Creator',
    avatar: activeStory.authorAvatar,
    mediaUrl: activeStory.mediaUrl,
    caption: activeStory.caption || '',
    time: 'Live',
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-slate-100/95 backdrop-blur-2xl flex items-center justify-center select-none overflow-hidden"
    >
      {/* 3D Story Canvas Frame */}
      <div
        id="timeshift-story-viewer-stage"
        ref={stageRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        onPointerDown={handleStagePointerDown}
        onPointerUp={handleStagePointerUp}
        onPointerCancel={handleStagePointerCancel}
        className={`relative w-full max-w-md h-[92vh] max-h-[850px] bg-white rounded-[36px] overflow-hidden shadow-2xl flex flex-col justify-between transition-all duration-300 select-none ${
          isExpired
            ? 'border-2 border-slate-700 opacity-90'
            : isEndingSoon
            ? 'border-2 border-rose-500 shadow-[0_0_50px_rgba(244,63,94,0.55)] ring-4 ring-rose-500/30'
            : 'border border-white/20'
        }`}
        style={{
          perspective: '1200px',
        }}
      >
        {/* PARALLAX 3D SPATIAL MEDIA LAYER */}
        <div
          className="absolute inset-0 w-full h-full overflow-hidden transition-transform duration-100 ease-out"
          style={{
            transform: is3DModeActive && !isExpired
              ? `rotateY(${tiltX}deg) rotateX(${tiltY}deg) scale(1.04)`
              : 'none',
            transformStyle: 'preserve-3d',
          }}
        >
          {/* Background Ambient Depth Glow */}
          <div className={`absolute inset-0 z-10 pointer-events-none transition-colors duration-500 ${
            isEndingSoon && !isExpired
              ? 'bg-gradient-to-t from-rose-950/60 via-transparent to-slate-100/70'
              : 'bg-gradient-to-t from-slate-100 via-transparent to-slate-100/60'
          }`} />

          {/* Primary Visual Media */}
          <img
            src={currentContributor.mediaUrl || activeStory.mediaUrl}
            alt={activeStory.caption}
            style={{
              filter: activeStory.visualFilter === 'cyberpunk_neon'
                ? 'contrast(125%) saturate(160%) hue-rotate(15deg)'
                : activeStory.visualFilter === 'golden_hour'
                ? 'sepia(30%) saturate(140%) brightness(105%) contrast(110%)'
                : activeStory.visualFilter === 'vintage_35mm'
                ? 'sepia(45%) contrast(90%) brightness(95%) saturate(120%)'
                : activeStory.visualFilter === 'hologram_mesh'
                ? 'hue-rotate(180deg) saturate(180%) contrast(120%)'
                : activeStory.visualFilter === 'dreamy_soft'
                ? 'brightness(110%) contrast(95%) saturate(130%)'
                : activeStory.visualFilter === 'noir_monochrome'
                ? 'grayscale(100%) contrast(140%) brightness(90%)'
                : activeStory.visualFilter === 'nordic_clean'
                ? 'contrast(110%) saturate(85%) brightness(105%)'
                : isExpired ? 'grayscale(100%) contrast(125%)' : undefined,
            }}
            className={`w-full h-full object-cover select-none transition-all duration-500`}
          />

          {/* 3D SPATIAL HOLOGRAM TEXT STICKERS */}
          {!isExpired && activeStory.spatialTextStickers && activeStory.spatialTextStickers.map((stk) => (
            <div
              key={stk.id}
              style={{
                top: `${stk.y}%`,
                left: `${stk.x}%`,
                transform: is3DModeActive
                  ? `translate(-50%, -50%) translateZ(${((stk.depthZ || 6) * 8)}px) rotateX(${tiltY * 0.4}deg) rotateY(${tiltX * 0.4}deg)`
                  : 'translate(-50%, -50%)',
              }}
              className={`absolute z-20 pointer-events-none text-center px-3.5 py-1.5 rounded-full ${
                stk.fontStyle === 'neon_glow'
                  ? 'bg-cyan-950/80 border border-cyan-400 text-cyan-300 shadow-[0_0_20px_rgba(6,182,212,0.8)] font-mono'
                  : stk.fontStyle === 'cyber_mono'
                  ? 'bg-amber-950/80 border border-amber-400 text-amber-300 font-mono tracking-widest'
                  : stk.fontStyle === 'bold_marker'
                  ? 'bg-rose-950/80 border border-rose-400 text-rose-300 font-black tracking-wider'
                  : 'bg-slate-100/70 border border-white/40 text-white font-serif italic'
              } text-xs sm:text-sm font-black uppercase shadow-2xl backdrop-blur-md`}
            >
              {stk.text}
            </div>
          ))}

          {/* ⏳ COUNTDOWN / FLASH DROP STICKER */}
          {!isExpired && activeStory.countdownSticker && (
            <div
              style={{
                top: `${activeStory.countdownSticker.y || 25}%`,
                left: `${activeStory.countdownSticker.x || 50}%`,
                transform: is3DModeActive
                  ? `translate(-50%, -50%) translateZ(${((activeStory.countdownSticker.depthZ || 5) * 8)}px) rotateX(${tiltY * 0.3}deg) rotateY(${tiltX * 0.3}deg)`
                  : 'translate(-50%, -50%)',
              }}
              className="absolute z-25 flex items-center space-x-2 px-3 py-1.5 rounded-2xl bg-rose-950/85 backdrop-blur-xl border border-rose-400/50 shadow-2xl shadow-rose-500/30 text-white animate-pulse"
            >
              <div className="w-2 h-2 rounded-full bg-rose-400 animate-ping" />
              <span className="text-[10px] font-mono font-black uppercase text-rose-200">
                {activeStory.countdownSticker.title}:
              </span>
              <span className="text-xs font-mono font-black text-amber-300">
                {activeStory.countdownSticker.targetMinutes}:00 MINS
              </span>
            </div>
          )}

          {/* 🪙 BOUNTY & MICRO-QUEST STICKER */}
          {!isExpired && activeStory.bountySticker && (
            <div
              style={{
                top: `${activeStory.bountySticker.y || 82}%`,
                left: `${activeStory.bountySticker.x || 50}%`,
                transform: is3DModeActive
                  ? `translate(-50%, -50%) translateZ(${((activeStory.bountySticker.depthZ || 7) * 8)}px) rotateX(${tiltY * 0.3}deg) rotateY(${tiltX * 0.3}deg)`
                  : 'translate(-50%, -50%)',
              }}
              className="absolute z-25 flex items-center space-x-2 px-3.5 py-2 rounded-2xl bg-amber-950/90 backdrop-blur-xl border border-amber-400/60 shadow-2xl shadow-amber-500/30 text-white"
            >
              <div className="w-6 h-6 rounded-full bg-amber-400 text-slate-800 flex items-center justify-center font-black text-xs">
                🪙
              </div>
              <div>
                <p className="text-[10px] font-bold text-white leading-tight">{activeStory.bountySticker.questTitle}</p>
                <p className="text-[9px] text-amber-300 font-mono font-black">
                  Reward: +{activeStory.bountySticker.tokenReward} {activeStory.bountySticker.tokenSymbol} Tokens
                </p>
              </div>
            </div>
          )}

          {/* TAPPABLE 3D INTERACTIVE STORY OBJECTS */}
          {!isExpired && activeStory.interactiveObjects.map((obj) => (
            <button
              key={obj.id}
              type="button"
              onClick={(e) => handleObjectClick(obj, e)}
              style={{
                top: `${obj.y}%`,
                left: `${obj.x}%`,
                transform: is3DModeActive
                  ? `translate(-50%, -50%) translateZ(${((obj.depthZ || 4) * 8)}px)`
                  : 'translate(-50%, -50%)',
              }}
              className="absolute z-20 group flex items-center space-x-1.5 p-1.5 pr-3 rounded-full bg-slate-100/70 backdrop-blur-md border border-white/30 text-white shadow-2xl hover:scale-110 hover:border-amber-400 transition-all cursor-pointer animate-bounce"
            >
              {obj.category === 'product' ? (
                <div className="w-6 h-6 rounded-full bg-emerald-500 text-slate-800 flex items-center justify-center">
                  <ShoppingBag className="w-3.5 h-3.5" />
                </div>
              ) : obj.category === 'secret_offer' ? (
                <div className="w-6 h-6 rounded-full bg-purple-500 text-white flex items-center justify-center animate-spin">
                  <Gift className="w-3.5 h-3.5" />
                </div>
              ) : (
                <div className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center">
                  <Store className="w-3.5 h-3.5" />
                </div>
              )}

              <span className="text-[11px] font-black truncate max-w-[120px]">
                {obj.label}
              </span>

              {obj.category === 'product' && obj.productDetails && (
                <span className="text-[10px] font-bold text-amber-300">
                  ₹{obj.productDetails.price.toLocaleString('en-IN')}
                </span>
              )}
            </button>
          ))}

          {/* 📊 INTERACTIVE 3D STORY POLL STICKER */}
          {!isExpired && activeStory.pollSticker && (
            <div
              id={`story-poll-sticker-${activeStory.pollSticker.id}`}
              onClick={(e) => e.stopPropagation()}
              style={{
                top: `${activeStory.pollSticker.y || 62}%`,
                left: `${activeStory.pollSticker.x || 50}%`,
                transform: is3DModeActive
                  ? `translate(-50%, -50%) translateZ(${((activeStory.pollSticker.depthZ || 6) * 8)}px) rotateX(${tiltY * 0.4}deg) rotateY(${tiltX * 0.4}deg)`
                  : 'translate(-50%, -50%)',
              }}
              className={`absolute z-30 w-[90%] max-w-[340px] rounded-3xl p-3.5 backdrop-blur-xl border transition-all duration-300 shadow-2xl group ${
                activeStory.pollSticker.themeColor === 'purple'
                  ? 'bg-white/85 border-fuchsia-400/40 shadow-[0_0_35px_rgba(217,70,239,0.3)]'
                  : activeStory.pollSticker.themeColor === 'amber'
                  ? 'bg-white/85 border-amber-400/40 shadow-[0_0_35px_rgba(251,191,36,0.3)]'
                  : activeStory.pollSticker.themeColor === 'emerald'
                  ? 'bg-white/85 border-emerald-400/40 shadow-[0_0_35px_rgba(16,185,129,0.3)]'
                  : activeStory.pollSticker.themeColor === 'rose'
                  ? 'bg-white/85 border-rose-400/40 shadow-[0_0_35px_rgba(244,63,94,0.3)]'
                  : 'bg-white/85 border-cyan-400/40 shadow-[0_0_35px_rgba(6,182,212,0.3)]'
              }`}
            >
              {/* Poll Header */}
              <div className="flex items-center justify-between gap-2 mb-2">
                <div className="flex items-center space-x-1.5 min-w-0">
                  <span className="flex h-2 w-2 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
                  </span>
                  <span className="text-[10px] font-black uppercase tracking-wider text-cyan-300 font-mono">
                    Live Poll
                  </span>
                  <span className="text-[10px] text-white/40">•</span>
                  <span className="text-[10px] font-medium text-slate-300 truncate">
                    {activeStory.pollSticker.totalVotes || (activeStory.pollSticker.optionA.votes + activeStory.pollSticker.optionB.votes)} votes
                  </span>
                </div>

                {/* Creator Edit Trigger */}
                <button
                  type="button"
                  id="btn-edit-poll-sticker"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleOpenPollEditor();
                  }}
                  className="p-1 px-2 rounded-lg bg-white/10 hover:bg-white/20 text-white/80 hover:text-white transition-colors text-[10px] flex items-center space-x-1"
                  title="Edit or customize this poll sticker"
                >
                  <Edit3 className="w-2.5 h-2.5" />
                  <span className="text-[9px] font-bold">Edit</span>
                </button>
              </div>

              {/* Question */}
              <h4 className="text-xs sm:text-sm font-extrabold text-white leading-snug mb-2.5 drop-shadow-md">
                {activeStory.pollSticker.question}
              </h4>

              {/* Options (Two Options with Real-Time Vote & Percentage Fill) */}
              {(() => {
                const poll = activeStory.pollSticker;
                const votesA = poll.optionA.votes;
                const votesB = poll.optionB.votes;
                const total = votesA + votesB;
                const hasVoted = Boolean(poll.userVotedOptionId);
                const isVotedA = poll.userVotedOptionId === 'opt-a' || poll.userVotedOptionId === poll.optionA.id;
                const isVotedB = poll.userVotedOptionId === 'opt-b' || poll.userVotedOptionId === poll.optionB.id;
                const pctA = total > 0 ? Math.round((votesA / total) * 100) : 50;
                const pctB = total > 0 ? 100 - pctA : 50;

                return (
                  <div className="space-y-2">
                    {/* OPTION A BUTTON */}
                    <button
                      type="button"
                      id="btn-vote-poll-option-a"
                      onClick={(e) => handleVotePoll('opt-a', e)}
                      className={`w-full relative overflow-hidden rounded-2xl p-2.5 text-left border transition-all duration-300 flex items-center justify-between group/opt active:scale-[0.98] cursor-pointer ${
                        isVotedA
                          ? 'border-cyan-400 bg-cyan-950/40 shadow-lg shadow-cyan-500/20 ring-1 ring-cyan-400'
                          : 'border-white/15 bg-white/5 hover:border-white/30 hover:bg-white/10'
                      }`}
                    >
                      {/* Animated percentage background fill */}
                      {hasVoted && (
                        <div
                          style={{ width: `${pctA}%` }}
                          className={`absolute inset-y-0 left-0 transition-all duration-700 ease-out pointer-events-none ${
                            isVotedA
                              ? 'bg-gradient-to-r from-cyan-500/40 to-blue-600/40'
                              : 'bg-white/10'
                          }`}
                        />
                      )}

                      <div className="relative z-10 flex items-center space-x-2 min-w-0 flex-1 mr-2">
                        {isVotedA && (
                          <div className="w-4 h-4 rounded-full bg-cyan-400 text-slate-800 flex items-center justify-center shrink-0 shadow-sm animate-in zoom-in-50">
                            <Check className="w-2.5 h-2.5 stroke-[3]" />
                          </div>
                        )}
                        <span className={`text-xs font-black truncate ${isVotedA ? 'text-white' : 'text-slate-100'}`}>
                          {poll.optionA.text}
                        </span>
                      </div>

                      {/* Percentage & Vote Count badge */}
                      <div className="relative z-10 flex items-center space-x-1.5 shrink-0">
                        {hasVoted ? (
                          <div className="flex items-center space-x-1">
                            <span className="text-[10px] text-slate-400 font-mono">({votesA})</span>
                            <span className="text-xs sm:text-sm font-black font-mono text-cyan-300">
                              {pctA}%
                            </span>
                          </div>
                        ) : (
                          <span className="text-[10px] text-white/50 font-bold group-hover/opt:text-cyan-300 transition-colors">
                            Tap to vote
                          </span>
                        )}
                      </div>
                    </button>

                    {/* OPTION B BUTTON */}
                    <button
                      type="button"
                      id="btn-vote-poll-option-b"
                      onClick={(e) => handleVotePoll('opt-b', e)}
                      className={`w-full relative overflow-hidden rounded-2xl p-2.5 text-left border transition-all duration-300 flex items-center justify-between group/opt active:scale-[0.98] cursor-pointer ${
                        isVotedB
                          ? 'border-purple-400 bg-purple-950/40 shadow-lg shadow-purple-500/20 ring-1 ring-purple-400'
                          : 'border-white/15 bg-white/5 hover:border-white/30 hover:bg-white/10'
                      }`}
                    >
                      {/* Animated percentage background fill */}
                      {hasVoted && (
                        <div
                          style={{ width: `${pctB}%` }}
                          className={`absolute inset-y-0 left-0 transition-all duration-700 ease-out pointer-events-none ${
                            isVotedB
                              ? 'bg-gradient-to-r from-purple-500/40 to-pink-600/40'
                              : 'bg-white/10'
                          }`}
                        />
                      )}

                      <div className="relative z-10 flex items-center space-x-2 min-w-0 flex-1 mr-2">
                        {isVotedB && (
                          <div className="w-4 h-4 rounded-full bg-purple-400 text-slate-800 flex items-center justify-center shrink-0 shadow-sm animate-in zoom-in-50">
                            <Check className="w-2.5 h-2.5 stroke-[3]" />
                          </div>
                        )}
                        <span className={`text-xs font-black truncate ${isVotedB ? 'text-white' : 'text-slate-100'}`}>
                          {poll.optionB.text}
                        </span>
                      </div>

                      {/* Percentage & Vote Count badge */}
                      <div className="relative z-10 flex items-center space-x-1.5 shrink-0">
                        {hasVoted ? (
                          <div className="flex items-center space-x-1">
                            <span className="text-[10px] text-slate-400 font-mono">({votesB})</span>
                            <span className="text-xs sm:text-sm font-black font-mono text-purple-300">
                              {pctB}%
                            </span>
                          </div>
                        ) : (
                          <span className="text-[10px] text-white/50 font-bold group-hover/opt:text-purple-300 transition-colors">
                            Tap to vote
                          </span>
                        )}
                      </div>
                    </button>

                    {/* Footer note after voting */}
                    {hasVoted ? (
                      <div className="flex items-center justify-between pt-1 px-1 text-[9px] text-slate-400">
                        <span className="flex items-center space-x-1 text-emerald-400">
                          <CheckCircle2 className="w-2.5 h-2.5" />
                          <span>Vote recorded • Tap option to switch</span>
                        </span>
                        <span className="text-cyan-400/80 font-mono">Live Sync</span>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between pt-0.5 px-1 text-[9px] text-slate-400">
                        <span className="text-white/40">Real-time percentage reveal upon tap</span>
                        <span className="text-amber-400 font-mono">2-Choice Poll</span>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>
          )}

          {/* LONG PRESS CHARGING RIPPLE AURA UNDER POINTER */}
          {isLongPressing && pressCoordinates && (
            <div
              style={{ left: `${pressCoordinates.x}%`, top: `${pressCoordinates.y}%` }}
              className="absolute z-40 pointer-events-none -translate-x-1/2 -translate-y-1/2 flex flex-col items-center"
            >
              <div className="relative w-16 h-16 flex items-center justify-center">
                <div className="animate-ping absolute inset-0 rounded-full bg-amber-400 opacity-40" />
                <svg className="w-16 h-16 -rotate-90">
                  <circle
                    cx="32"
                    cy="32"
                    r="26"
                    className="text-white/20 stroke-current"
                    strokeWidth="4"
                    fill="transparent"
                  />
                  <circle
                    cx="32"
                    cy="32"
                    r="26"
                    className="text-amber-400 stroke-current transition-all"
                    strokeWidth="4"
                    strokeDasharray={163.3}
                    strokeDashoffset={163.3 - (163.3 * longPressCharge) / 100}
                    strokeLinecap="round"
                    fill="transparent"
                  />
                </svg>
                <div className="absolute text-amber-300 text-[10px] font-mono font-black">
                  00:{targetReactionTimestampSec < 10 ? `0${targetReactionTimestampSec}` : targetReactionTimestampSec}
                </div>
              </div>
              <span className="mt-1 px-2 py-0.5 rounded-full bg-slate-100/80 text-[9px] font-bold text-amber-300 border border-amber-500/40 backdrop-blur-md">
                Hold for Reactions
              </span>
            </div>
          )}

          {/* FLOATING CROWD REACTION PARTICLES */}
          {floatingReactions.map((p) => (
            <div
              key={p.id}
              style={{ left: `${p.x}%`, top: `${p.y}%` }}
              className="absolute z-30 pointer-events-none flex flex-col items-center -translate-x-1/2 animate-bounce transition-all"
            >
              <span className="text-3xl filter drop-shadow-[0_0_12px_rgba(251,191,36,0.9)]">
                {p.emoji || (p.type === 'heart' ? '❤️' : p.type === 'fire' ? '🔥' : p.type === 'diamond' ? '💎' : '😮')}
              </span>
              {p.label && (
                <span className="text-[9px] font-mono font-black text-white bg-slate-100/70 px-1.5 py-0.2 rounded-full border border-white/20">
                  {p.label}
                </span>
              )}
            </div>
          ))}
        </div>

        {/* TOP STORY HEADER & LIVE EXPIRATION SYSTEM */}
        <div className="relative z-30 p-3.5 space-y-2 bg-gradient-to-b from-slate-100/95 via-slate-100/60 to-transparent">
          {/* Dual Progress: 1) Interactive Playback Timeline with Moment Ripples + 2) Story Lifetime Expiration Bar */}
          <div className="space-y-1">
            {/* 15s Story Clip Progress with Interactive Moment Ripples */}
            <div
              className="relative w-full h-5 flex items-center cursor-pointer group select-none"
              onClick={handleTimelineSeek}
              title="Click or scrub along the story timeline to explore Moment Reactions"
            >
              {/* Base Progress Line Track */}
              <div className="w-full h-1.5 bg-white/20 rounded-full overflow-hidden backdrop-blur-sm transition-all group-hover:h-2">
                <div
                  className="h-full bg-gradient-to-r from-amber-400 via-orange-500 to-rose-500 rounded-full transition-all duration-100 shadow-[0_0_10px_rgba(251,191,36,0.8)]"
                  style={{ width: `${playbackProgress}%` }}
                />
              </div>

              {/* TIMESTAMPED REACTION RIPPLES ON THE PROGRESS BAR */}
              {momentClusters.map((cluster) => {
                const duration = activeStory.durationSeconds || 15;
                const leftPercent = (cluster.timestampSecond / duration) * 100;
                const isPlaybackNear = Math.abs(currentPlaybackSec - cluster.timestampSecond) <= 0.6;
                const isHovered = hoveredClusterSec === cluster.timestampSecond;

                return (
                  <div
                    key={cluster.timestampSecond}
                    style={{ left: `${leftPercent}%` }}
                    onMouseEnter={(e) => {
                      e.stopPropagation();
                      setHoveredClusterSec(cluster.timestampSecond);
                    }}
                    onMouseLeave={() => setHoveredClusterSec(null)}
                    onClick={(e) => {
                      e.stopPropagation();
                      setPlaybackProgress(leftPercent);
                      setTargetReactionTimestampSec(cluster.timestampSecond);
                      setShowMomentReactionPicker(true);
                    }}
                    className="absolute -translate-x-1/2 flex items-center justify-center cursor-pointer z-30 transition-transform hover:scale-125"
                  >
                    {/* Ripple Wave 1: Ambient Expanding Ping Ring */}
                    <span
                      className={`animate-ping absolute inline-flex h-4 w-4 rounded-full opacity-60 pointer-events-none ${
                        cluster.dominantConfig.bgColor.replace('from-', 'bg-').split(' ')[0]
                      }`}
                    />

                    {/* Ripple Wave 2: Playback Head Collision Surge Aura */}
                    {isPlaybackNear && (
                      <span className="animate-pulse absolute inline-flex h-6 w-6 rounded-full bg-amber-400/50 ring-4 ring-amber-300 pointer-events-none" />
                    )}

                    {/* Ripple Wave 3: Inner Glow Center Dot / Emoji Beacon */}
                    <div
                      className={`relative flex items-center justify-center w-3 h-3 rounded-full border border-white text-[8px] font-black transition-all ${
                        isPlaybackNear
                          ? 'scale-125 ring-2 ring-white shadow-[0_0_12px_rgba(255,255,255,0.9)]'
                          : isHovered
                          ? 'scale-125 ring-1 ring-white'
                          : ''
                      } bg-gradient-to-br ${cluster.dominantConfig.bgColor} text-white`}
                    >
                      {cluster.totalCount > 1 ? (
                        <span className="text-[7px] leading-none font-black">{cluster.dominantConfig.emoji}</span>
                      ) : (
                        <span className="w-1.5 h-1.5 rounded-full bg-white" />
                      )}
                    </div>

                    {/* Hover Tooltip / Reaction Popover */}
                    {isHovered && (
                      <div
                        className="absolute bottom-6 z-50 bg-slate-900/95 backdrop-blur-xl border border-white/25 rounded-2xl p-2.5 shadow-2xl space-y-1.5 text-xs text-white min-w-[160px] animate-in zoom-in-95 pointer-events-auto"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="flex items-center justify-between text-[10px] text-slate-300 font-mono">
                          <span className="font-black text-amber-300 flex items-center space-x-1">
                            <Zap className="w-3 h-3 text-amber-400" />
                            <span>00:{cluster.timestampSecond < 10 ? `0${cluster.timestampSecond}` : cluster.timestampSecond}</span>
                          </span>
                          <span className="bg-white/10 px-1.5 py-0.2 rounded text-[9px] font-bold">
                            {cluster.totalCount} {cluster.totalCount === 1 ? 'Reaction' : 'Reactions'}
                          </span>
                        </div>

                        <div className="flex items-center space-x-1 overflow-x-auto no-scrollbar py-0.5">
                          {cluster.reactions.map((r, rIdx) => (
                            <span
                              key={rIdx}
                              className="flex items-center space-x-0.5 px-1.5 py-0.5 rounded-lg bg-white/10 text-[10px]"
                            >
                              <span>{r.config.emoji}</span>
                              <span className="font-bold text-slate-200">x{r.count}</span>
                            </span>
                          ))}
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            setPlaybackProgress(leftPercent);
                            setTargetReactionTimestampSec(cluster.timestampSecond);
                            setShowMomentReactionPicker(true);
                          }}
                          className="w-full py-1 rounded-lg bg-gradient-to-r from-amber-400 to-orange-500 text-slate-800 font-black text-[10px] hover:brightness-110 flex items-center justify-center space-x-1"
                        >
                          <SmilePlus className="w-3 h-3" />
                          <span>React at this Moment</span>
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Live Ephemeral Expiration Gauge */}
            <div className="flex items-center justify-between text-[8px] font-mono text-slate-400 px-0.5">
              <span className="flex items-center gap-1">
                <Clock className="w-2.5 h-2.5 text-amber-400" />
                Live Expiration: {formatCountdown(remainingSecs)}
              </span>
              <span className={isEndingSoon ? 'text-rose-400 font-bold animate-pulse' : 'text-slate-300'}>
                {Math.round(expirationPercentRemaining)}% Time Remaining
              </span>
            </div>
            <div className="w-full h-1 bg-slate-100/50 rounded-full overflow-hidden border border-white/10">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  isExpired
                    ? 'bg-slate-600'
                    : isEndingSoon
                    ? 'bg-gradient-to-r from-rose-500 to-red-600 animate-pulse'
                    : remainingSecs <= 600
                    ? 'bg-gradient-to-r from-orange-400 to-amber-500'
                    : 'bg-gradient-to-r from-emerald-400 to-teal-500'
                }`}
                style={{ width: `${expirationPercentRemaining}%` }}
              />
            </div>
          </div>

          {/* ENDING SOON (< 5 MINS) LIVE URGENCY TICKER BANNER */}
          {isEndingSoon && !isExpired && (
            <div className="py-1 px-3 rounded-full bg-gradient-to-r from-rose-600 via-red-600 to-amber-600 text-white text-[11px] font-black flex items-center justify-between shadow-lg shadow-rose-600/30 animate-pulse border border-rose-400/50">
              <div className="flex items-center space-x-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-200 animate-bounce" />
                <span>ENDING SOON: {formatCountdown(remainingSecs)}</span>
              </div>
              <span className="bg-slate-100/50 px-2 py-0.5 rounded-full text-[9px] uppercase tracking-wider text-rose-200">
                Final 5 Minutes!
              </span>
            </div>
          )}

          {/* Author Details & Live 2-Hour Timer Bar */}
          <div className="flex items-center justify-between pt-0.5">
            <div className="flex items-center space-x-2.5">
              <img
                src={activeStory.authorAvatar}
                alt={activeStory.authorName}
                className="w-9 h-9 rounded-full object-cover border-2 border-amber-400 shadow-md"
              />
              <div>
                <div className="flex items-center space-x-1.5">
                  <span className="text-xs font-black text-white">{activeStory.authorName}</span>
                  {activeStory.isVerified && (
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 fill-blue-400" />
                  )}
                  <span className="px-1.5 py-0.2 rounded text-[8px] font-black uppercase bg-white/20 text-white">
                    {activeStory.captureMode} 3D
                  </span>
                </div>
                <div className="flex items-center space-x-2 text-[10px] text-slate-300 font-mono">
                  <span className="text-amber-400 font-bold">DNA: {activeStory.storyDna}</span>
                  <span>•</span>
                  <span>Phase: {activeStory.currentPhase.toUpperCase()}</span>
                </div>
              </div>
            </div>

            {/* Quick Action Tools & Close */}
            <div className="flex items-center space-x-1.5">
              {/* Time-Warp Simulation Menu for Instant Testing */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowTimeWarpMenu(!showTimeWarpMenu)}
                  className="px-2 py-1 rounded-full bg-slate-100/60 text-[10px] font-bold text-amber-300 hover:text-white border border-amber-500/30 flex items-center gap-1"
                  title="Simulate Countdown Time-Warp"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span className="hidden sm:inline">Warp</span>
                </button>

                {showTimeWarpMenu && (
                  <div className="absolute right-0 top-8 z-50 w-48 bg-slate-900/95 backdrop-blur-xl border border-white/20 rounded-2xl p-2 shadow-2xl space-y-1 text-xs text-white">
                    <p className="text-[9px] font-bold text-slate-400 uppercase px-2 py-0.5">
                      Simulate Remaining Time:
                    </p>
                    <button
                      onClick={() => {
                        const newSecs = 7200;
                        setRemainingSecs(newSecs);
                        if (activeStory) {
                          activeStory.expiresAt = new Date(Date.now() + newSecs * 1000).toISOString();
                          activeStory.remainingSeconds = newSecs;
                        }
                        setShowTimeWarpMenu(false);
                        showToast('⏱️ Reset to 2 Hours (Standard State)');
                      }}
                      className="w-full text-left px-2 py-1.5 rounded-lg hover:bg-white/10 text-[11px] font-bold"
                    >
                      ⏳ 2 Hours (7200s)
                    </button>
                    <button
                      onClick={() => {
                        const newSecs = 1800;
                        setRemainingSecs(newSecs);
                        if (activeStory) {
                          activeStory.expiresAt = new Date(Date.now() + newSecs * 1000).toISOString();
                          activeStory.remainingSeconds = newSecs;
                        }
                        setShowTimeWarpMenu(false);
                        showToast('⏳ Warped to 30 Minutes Remaining');
                      }}
                      className="w-full text-left px-2 py-1.5 rounded-lg hover:bg-white/10 text-[11px] font-bold text-amber-300"
                    >
                      ⏳ 30 Mins (1800s)
                    </button>
                    <button
                      onClick={() => {
                        const newSecs = 600;
                        setRemainingSecs(newSecs);
                        if (activeStory) {
                          activeStory.expiresAt = new Date(Date.now() + newSecs * 1000).toISOString();
                          activeStory.remainingSeconds = newSecs;
                        }
                        setShowTimeWarpMenu(false);
                        showToast('⚡ Warped to 10 Minutes Remaining');
                      }}
                      className="w-full text-left px-2 py-1.5 rounded-lg hover:bg-white/10 text-[11px] font-bold text-orange-400"
                    >
                      ⚡ 10 Mins (600s)
                    </button>
                    <button
                      onClick={() => {
                        const newSecs = 240; // 4 minutes (< 5 mins)
                        setRemainingSecs(newSecs);
                        if (activeStory) {
                          activeStory.expiresAt = new Date(Date.now() + newSecs * 1000).toISOString();
                          activeStory.remainingSeconds = newSecs;
                        }
                        setShowTimeWarpMenu(false);
                        showToast('🔥 Triggered "Ending Soon" State (< 5m left)!');
                      }}
                      className="w-full text-left px-2 py-1.5 rounded-lg bg-rose-600/30 hover:bg-rose-600/50 text-[11px] font-black text-rose-300 flex items-center justify-between"
                    >
                      <span>🚨 Ending Soon (4m)</span>
                      <span className="text-[9px] bg-rose-500 text-white px-1.5 rounded-full animate-pulse">
                        PULSE
                      </span>
                    </button>
                    <button
                      onClick={() => {
                        const newSecs = 5;
                        setRemainingSecs(newSecs);
                        if (activeStory) {
                          activeStory.expiresAt = new Date(Date.now() + newSecs * 1000).toISOString();
                          activeStory.remainingSeconds = newSecs;
                        }
                        setShowTimeWarpMenu(false);
                        showToast('⌛ Fast forward to Expiration in 5 seconds!');
                      }}
                      className="w-full text-left px-2 py-1.5 rounded-lg bg-red-600/40 hover:bg-red-600/60 text-[11px] font-black text-red-200"
                    >
                      ⏱️ Expire in 5s
                    </button>
                  </div>
                )}
              </div>

              {/* Share Deep-Link Trigger Button */}
              <button
                id="btn-timeshift-header-share"
                type="button"
                onClick={handleNativeOrModalShare}
                className="p-2 rounded-full bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/40 hover:text-white border border-cyan-400/40 transition-all hover:scale-105"
                title="Share 3D Story & Deep Link"
              >
                <Share2 className="w-3.5 h-3.5" />
              </button>

              {/* Poll Sticker Action Trigger Button */}
              <button
                id="btn-timeshift-header-poll"
                type="button"
                onClick={handleOpenPollEditor}
                className={`p-2 rounded-full border transition-all hover:scale-105 ${
                  activeStory.pollSticker
                    ? 'bg-purple-500/20 text-purple-300 hover:bg-purple-500/40 hover:text-white border-purple-400/40'
                    : 'bg-slate-100/50 text-white/70 hover:text-white border-white/20'
                }`}
                title={activeStory.pollSticker ? 'Edit Poll Sticker' : 'Add Interactive Poll Sticker'}
              >
                <Vote className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => setIsExpirationReportOpen(true)}
                className="p-2 rounded-full bg-slate-100/50 text-white/80 hover:text-white border border-white/20"
                title="View Story Analytics"
              >
                <BarChart2 className="w-3.5 h-3.5" />
              </button>
              <button
                id="btn-close-timeshift-viewer"
                type="button"
                onClick={onClose}
                className="p-2 rounded-full bg-slate-100/50 text-white hover:bg-white/20 border border-white/20"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* ⏱️ COUNTDOWN PILL WITH INJECTED PULSATING 'ENDING SOON' STATE */}
          <div className="flex items-center justify-between pt-1">
            {/* The Countdown Pill */}
            <div
              id="timeshift-countdown-pill"
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-full backdrop-blur-md transition-all duration-300 font-mono text-xs font-black shadow-lg ${
                isEndingSoon && !isExpired
                  ? 'bg-gradient-to-r from-rose-600 via-red-600 to-amber-600 text-white border-2 border-rose-300 animate-pulse ring-4 ring-rose-500/50 shadow-[0_0_25px_rgba(244,63,94,0.8)]'
                  : isExpired
                  ? 'bg-slate-800/90 text-slate-300 border border-slate-700'
                  : remainingSecs <= 600
                  ? 'bg-orange-500/20 text-orange-300 border border-orange-500/40'
                  : 'bg-slate-100/60 text-white border border-white/20'
              }`}
            >
              {isEndingSoon && !isExpired ? (
                <>
                  <div className="relative flex items-center justify-center">
                    <span className="animate-ping absolute inline-flex h-2.5 w-2.5 rounded-full bg-amber-300 opacity-75" />
                    <Flame className="w-3.5 h-3.5 text-amber-200 relative z-10 animate-bounce" />
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <span className="bg-slate-100/40 px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-wider text-rose-100">
                      ENDING SOON
                    </span>
                    <span className="text-white font-black tracking-tight">
                      {formatCountdown(remainingSecs)}
                    </span>
                  </div>
                </>
              ) : isExpired ? (
                <>
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>00:00:00 (EXPIRED)</span>
                </>
              ) : (
                <>
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <div className="flex items-center space-x-1">
                    <span className="text-white font-extrabold">{formatCountdown(remainingSecs)}</span>
                    <span className={`px-1.5 py-0.2 rounded text-[8px] font-black uppercase ${urgency.bg}`}>
                      {urgency.text}
                    </span>
                  </div>
                </>
              )}
            </div>

            {/* 3D Parallax & Audio Toggles */}
            <div className="flex items-center space-x-1.5">
              <button
                type="button"
                onClick={() => setIs3DModeActive(!is3DModeActive)}
                className={`px-2.5 py-1 rounded-full text-[9px] font-black tracking-wider border transition-all ${
                  is3DModeActive
                    ? 'bg-amber-400 text-slate-800 border-amber-300 shadow-md'
                    : 'bg-slate-100/50 text-white border-white/20'
                }`}
              >
                {is3DModeActive ? '3D TILT ON' : '2D FLAT'}
              </button>

              <button
                type="button"
                onClick={() => setIsMuted(!isMuted)}
                className="p-1 rounded-full bg-slate-100/50 text-white border border-white/20 hover:bg-white/20"
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
              </button>
            </div>
          </div>

          {/* INTERCONNECTED COMMUNITY & LIVING PROFILE STORY BADGE */}
          {(activeStory.communityName || activeStory.isProfileStory || activeStory.milestoneTag || activeStory.soundtrack || activeStory.ephemeralGhostMode) && (
            <div className="flex flex-wrap items-center gap-1.5 pt-1.5">
              {activeStory.soundtrack && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-cyan-950/80 border border-cyan-400/40 text-cyan-300 text-[10px] font-bold shadow-md animate-pulse">
                  <span>🎵</span>
                  <span className="truncate max-w-[140px]">{activeStory.soundtrack.title}</span>
                  <span className="text-[9px] font-mono text-cyan-400/70">({activeStory.soundtrack.genre})</span>
                </span>
              )}

              {activeStory.ephemeralGhostMode && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-900/90 border border-slate-600 text-slate-300 text-[9px] font-mono">
                  <span>👻 ZK Ghost</span>
                </span>
              )}

              {activeStory.communityName && (
                <button
                  type="button"
                  onClick={() => {
                    showToast(`🔗 Connected to Community: ${activeStory.communityName}`);
                  }}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-gradient-to-r from-violet-900/90 to-slate-900/90 border border-violet-400/40 text-violet-200 text-[10px] font-bold shadow-md hover:border-violet-300 transition-all cursor-pointer"
                >
                  <span>{activeStory.communityType === 'goal_community' ? '🎯' : activeStory.communityType === 'temporary_community' ? '⚡' : '🌐'}</span>
                  <span className="truncate max-w-[200px]">{activeStory.communityName}</span>
                </button>
              )}

              {activeStory.milestoneTag && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 text-[9px] font-mono font-bold">
                  <span>★</span>
                  <span>{activeStory.milestoneTag}</span>
                </span>
              )}

              {(activeStory.isProfileStory || activeStory.isPersonalStory) && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-[9px] font-bold">
                  <span>👤 Living Profile Story</span>
                </span>
              )}
            </div>
          )}

          {/* MULTI-PERSON STORY CONTRIBUTOR TABS (If Multi-Person enabled) */}
          {activeStory.multiContributors && activeStory.multiContributors.length > 1 && (
            <div className="flex items-center space-x-1.5 pt-1 overflow-x-auto no-scrollbar">
              {activeStory.multiContributors.map((contrib, idx) => (
                <button
                  key={contrib.id}
                  type="button"
                  onClick={() => setActiveContributorIdx(idx)}
                  className={`flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold transition-all ${
                    activeContributorIdx === idx
                      ? 'bg-purple-600 text-white shadow-lg border border-purple-400'
                      : 'bg-slate-100/40 text-slate-300 border border-white/10'
                  }`}
                >
                  <img src={contrib.avatar} alt={contrib.name} className="w-4 h-4 rounded-full" />
                  <span>{contrib.role}: {contrib.name.split(' ')[0]}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* EXPIRED STORY OVERLAY */}
        {isExpired && (
          <div className="absolute inset-0 z-40 bg-slate-100/90 backdrop-blur-xl flex flex-col items-center justify-center p-6 text-center space-y-4 animate-in fade-in zoom-in-95">
            <div className="w-16 h-16 rounded-3xl bg-red-500/20 text-red-400 border border-red-500/30 flex items-center justify-center">
              <Clock className="w-8 h-8 animate-pulse" />
            </div>

            <div className="space-y-1.5">
              <span className="px-3 py-1 rounded-full bg-red-600/30 text-red-300 text-[10px] font-black uppercase tracking-wider border border-red-500/40">
                Story Archived
              </span>
              <h3 className="text-lg font-black text-white">This 3D Story Has Expired</h3>
              <p className="text-xs text-slate-400 max-w-xs leading-relaxed">
                The {activeStory.lifetimeDuration} public window has concluded. Interactive elements and active flash offers have been archived.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 w-full max-w-xs pt-2">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-left">
                <p className="text-[10px] text-slate-400">Total Viewers</p>
                <p className="text-base font-black text-white">{activeStory.analytics?.totalViews || 412}</p>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-left">
                <p className="text-[10px] text-slate-400">Total Reactions</p>
                <p className="text-base font-black text-amber-400">{activeStory.livePulse.reactionsCount}</p>
              </div>
            </div>

            <div className="flex items-center space-x-2 w-full max-w-xs pt-2">
              <button
                type="button"
                onClick={() => setIsExpirationReportOpen(true)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 text-white font-bold text-xs hover:bg-white/20 border border-white/20"
              >
                Full Analytics
              </button>
              <button
                type="button"
                onClick={currentIndex < timeShiftStories.length - 1 ? handleNextStory : onClose}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 text-slate-800 font-black text-xs hover:brightness-110 shadow-lg shadow-amber-500/20"
              >
                {currentIndex < timeShiftStories.length - 1 ? 'Next Story ➔' : 'Close Viewer'}
              </button>
            </div>
          </div>
        )}

        {/* MIDDLE TAP NAVIGATION ZONES */}
        <div className="absolute inset-x-0 top-36 bottom-36 flex z-10 pointer-events-auto">
          <div className="w-1/3 h-full cursor-w-resize" onClick={handlePrevStory} />
          <div
            className="w-1/3 h-full cursor-pointer flex items-center justify-center"
            onClick={() => setIsPaused(!isPaused)}
          />
          <div className="w-1/3 h-full cursor-e-resize" onClick={handleNextStory} />
        </div>

        {/* 👁️ CUSTOMER-PERSPECTIVE MODE ("MY VIEW") & CAPTION */}
        <div className="relative z-30 p-4 space-y-3 bg-gradient-to-t from-slate-100 via-slate-100/80 to-transparent">
          {/* Live Story Pulse */}
          <div className="flex items-center justify-between text-[11px] text-white/80 bg-white/5 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10">
            <div className="flex items-center space-x-3">
              <span className="flex items-center space-x-1 font-bold text-amber-300">
                <Eye className="w-3.5 h-3.5" />
                <span>{activeStory.livePulse.currentViewers} viewing</span>
              </span>
              <span className="flex items-center space-x-1 text-red-400 font-bold">
                <Heart className="w-3.5 h-3.5" />
                <span>{activeStory.livePulse.reactionsCount} reactions</span>
              </span>
            </div>

            {/* MY VIEW TRIGGER BUTTON */}
            <button
              id="btn-customer-my-view"
              type="button"
              onClick={() => setIsMyViewActive(!isMyViewActive)}
              className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center space-x-1 transition-all ${
                isMyViewActive
                  ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-lg shadow-blue-500/30 ring-2 ring-blue-400'
                  : 'bg-white/10 text-white/90 hover:bg-white/20 border border-white/20'
              }`}
            >
              <Compass className="w-3 h-3 text-cyan-300" />
              <span>{isMyViewActive ? 'MY VIEW ACTIVE' : '👁️ MY VIEW'}</span>
            </button>
          </div>

          {/* Context-Aware "My View" Display Overlay */}
          {isMyViewActive && (
            <div className="p-2.5 rounded-2xl bg-blue-950/80 border border-blue-500/40 text-blue-200 text-xs space-y-1 animate-in fade-in">
              <div className="flex items-center justify-between font-bold">
                <span className="flex items-center space-x-1 text-white">
                  <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Only {activeStory.location?.distanceMeters || 450}m away from your location</span>
                </span>
                <span className="text-emerald-400 text-[10px]">● Express 28-Min</span>
              </div>
              <p className="text-[10px] text-blue-300">
                ⚡ Immediate doorstep delivery active for your verified shipping pin. Verified store genuine guarantee.
              </p>
            </div>
          )}

          {/* Caption & Tags */}
          <div className="space-y-1">
            <p className="text-xs font-semibold text-white leading-relaxed">
              {currentContributor.caption || activeStory.caption}
            </p>
            {activeStory.aiTags.length > 0 && (
              <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar">
                {activeStory.aiTags.map((tag) => (
                  <span
                    key={tag.id}
                    className="px-2 py-0.5 rounded-full bg-white/10 text-amber-300 text-[10px] font-bold"
                  >
                    @{tag.name}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* CROWD-REACTION & QUICK ACTIONS BAR */}
          <div className="flex items-center justify-between pt-1 gap-2">
            {/* Quick Moment Reaction Palette with Glow and Smooth Physics */}
            <div className="flex items-center space-x-1 bg-slate-100/80 backdrop-blur-xl px-2 py-1.5 rounded-full border border-white/25 shadow-lg shadow-black/60 overflow-x-auto no-scrollbar">
              {MOMENT_REACTION_CONFIG.map((r) => (
                <button
                  key={r.type}
                  type="button"
                  onClick={() => handleSendReaction(r.type)}
                  className="hover:scale-130 active:scale-90 transition-transform text-base p-1 hover:brightness-125 focus:outline-none"
                  title={`React ${r.label} (${r.emoji}) at 00:${currentPlaybackSec < 10 ? `0${currentPlaybackSec}` : currentPlaybackSec}`}
                >
                  {r.emoji}
                </button>
              ))}
            </div>

            {/* Reaction by Moment Button with Live Timestamp */}
            <button
              type="button"
              onClick={() => {
                setIsPaused(true);
                setTargetReactionTimestampSec(currentPlaybackSec);
                setShowMomentReactionPicker(true);
              }}
              className="px-2.5 py-1.5 rounded-full bg-amber-400/20 hover:bg-amber-400/30 text-amber-300 border border-amber-500/40 text-[10px] font-black flex items-center space-x-1 shrink-0 transition-all hover:scale-105"
              title="Trigger Reaction at exact story timestamp"
            >
              <Zap className="w-3 h-3 text-amber-400 animate-pulse" />
              <span>⏱️ 00:{currentPlaybackSec < 10 ? `0${currentPlaybackSec}` : currentPlaybackSec}</span>
            </button>

            {/* Social Share & Deep-Link Button */}
            <button
              id="btn-timeshift-footer-share"
              type="button"
              onClick={handleNativeOrModalShare}
              className="px-2.5 py-1.5 rounded-full bg-cyan-500/20 hover:bg-cyan-500/35 text-cyan-300 border border-cyan-400/40 text-[10px] font-black flex items-center space-x-1 shrink-0 transition-all hover:scale-105"
              title="Share 3D Story & Deep Link"
            >
              <Share2 className="w-3 h-3 text-cyan-400" />
              <span className="hidden sm:inline">Share</span>
            </button>

            {/* Poll Sticker Button */}
            <button
              id="btn-timeshift-footer-poll"
              type="button"
              onClick={handleOpenPollEditor}
              className={`px-2.5 py-1.5 rounded-full border text-[10px] font-black flex items-center space-x-1 shrink-0 transition-all hover:scale-105 ${
                activeStory.pollSticker
                  ? 'bg-purple-500/20 hover:bg-purple-500/35 text-purple-300 border-purple-400/40'
                  : 'bg-white/10 hover:bg-white/20 text-white/80 border-white/20'
              }`}
              title="Interactive Poll Sticker"
            >
              <Vote className="w-3 h-3 text-purple-400" />
              <span className="hidden sm:inline">{activeStory.pollSticker ? 'Poll' : '+ Poll'}</span>
            </button>

            {/* Primary Action / Direct Shop */}
            {activeStory.interactiveObjects[0]?.category === 'product' && (
              <button
                type="button"
                onClick={() => setSelectedObject(activeStory.interactiveObjects[0])}
                className="px-3.5 py-1.5 rounded-full bg-gradient-to-r from-amber-400 to-orange-500 text-slate-800 text-xs font-black shadow-lg shadow-amber-500/20 hover:brightness-110 flex items-center space-x-1 shrink-0"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Shop</span>
              </button>
            )}
          </div>
        </div>

        {/* FLOATING / RADIAL REACTION BY MOMENT PICKER POPUP */}
        {showMomentReactionPicker && (
          <div
            className="absolute inset-0 z-50 bg-slate-100/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in"
            onClick={() => {
              setShowMomentReactionPicker(false);
              setIsPaused(false);
            }}
          >
            <div
              className="bg-slate-900/95 backdrop-blur-2xl border-2 border-amber-400/60 rounded-3xl p-4 max-w-xs w-full shadow-2xl space-y-3 animate-in zoom-in-95 text-center"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-1.5">
                  <div className="w-6 h-6 rounded-full bg-amber-400 text-slate-800 flex items-center justify-center font-black text-xs">
                    ⚡
                  </div>
                  <h3 className="text-xs font-black text-white uppercase tracking-wider">
                    React at 00:{targetReactionTimestampSec < 10 ? `0${targetReactionTimestampSec}` : targetReactionTimestampSec}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setShowMomentReactionPicker(false);
                    setIsPaused(false);
                  }}
                  className="text-slate-400 hover:text-white text-sm p-1"
                >
                  ✕
                </button>
              </div>

              <p className="text-[11px] text-slate-300 leading-tight">
                Stamp this exact frame with your live crowd reaction. Ripples will pulse on the progress bar!
              </p>

              {/* Reaction Choices Grid */}
              <div className="grid grid-cols-4 gap-2 pt-1">
                {MOMENT_REACTION_CONFIG.map((r) => (
                  <button
                    key={r.type}
                    type="button"
                    onClick={() => {
                      handleSendReaction(r.type, targetReactionTimestampSec);
                      setIsPaused(false);
                    }}
                    className={`flex flex-col items-center justify-center p-2 rounded-2xl bg-white/5 hover:bg-white/15 border border-white/10 hover:border-amber-400/80 transition-all hover:scale-110 active:scale-95 group ${r.glowColor}`}
                  >
                    <span className="text-2xl group-hover:scale-125 transition-transform">{r.emoji}</span>
                    <span className={`text-[10px] font-black mt-1 ${r.textColor}`}>{r.label}</span>
                  </button>
                ))}
              </div>

              {/* Quick Seek to another second slider */}
              <div className="pt-2 border-t border-white/10 flex items-center space-x-2 text-[10px] text-slate-400 font-mono">
                <span>00:00</span>
                <input
                  type="range"
                  min="0"
                  max={activeStory.durationSeconds || 15}
                  value={targetReactionTimestampSec}
                  onChange={(e) => {
                    const sec = parseInt(e.target.value, 10);
                    setTargetReactionTimestampSec(sec);
                    setPlaybackProgress((sec / (activeStory.durationSeconds || 15)) * 100);
                  }}
                  className="flex-1 accent-amber-400 cursor-pointer"
                />
                <span>00:{activeStory.durationSeconds || 15}</span>
              </div>
            </div>
          </div>
        )}

        {/* POPOVER: IN-STORY PRODUCT PURCHASE CARD (No need to leave story!) */}
        {selectedObject && selectedObject.productDetails && (
          <div className="absolute inset-x-3 bottom-3 z-40 p-4 bg-slate-900/95 backdrop-blur-2xl rounded-3xl border border-white/20 shadow-2xl space-y-3 animate-in slide-in-from-bottom">
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-3">
                <img
                  src={selectedObject.productDetails.image}
                  alt={selectedObject.productDetails.name}
                  className="w-14 h-14 rounded-2xl object-cover border border-white/10"
                />
                <div>
                  <h4 className="text-xs font-black text-white line-clamp-1">
                    {selectedObject.productDetails.name}
                  </h4>
                  <div className="flex items-center space-x-2 pt-0.5">
                    <span className="text-sm font-black text-amber-400">
                      ₹{selectedObject.productDetails.price.toLocaleString('en-IN')}
                    </span>
                    {selectedObject.productDetails.mrp && (
                      <span className="text-[11px] text-slate-400 line-through">
                        ₹{selectedObject.productDetails.mrp.toLocaleString('en-IN')}
                      </span>
                    )}
                    <span className="px-1.5 py-0.2 rounded bg-red-500/20 text-red-300 text-[9px] font-bold">
                      {selectedObject.productDetails.discountPercent}% OFF
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 flex items-center space-x-1 pt-0.5">
                    <Truck className="w-3 h-3 text-emerald-400" />
                    <span>{selectedObject.productDetails.deliveryEta}</span>
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSelectedObject(null)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Direct In-Story Buy Now Action */}
            <div className="flex items-center space-x-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  if (selectedObject.productId) {
                    addToCart(selectedObject.productId);
                    showToast(`🛍️ Added "${selectedObject.productDetails?.name}" to Cart!`);
                  }
                  setSelectedObject(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-white/10 text-white text-xs font-bold hover:bg-white/20"
              >
                Add to Bag
              </button>
              <button
                type="button"
                onClick={() => {
                  if (selectedObject.productId) {
                    addToCart(selectedObject.productId);
                    showToast(`⚡ Direct In-Story Checkout initiated for ₹${selectedObject.productDetails?.price}!`);
                  }
                  setSelectedObject(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 text-slate-800 text-xs font-black shadow-lg hover:brightness-110"
              >
                Buy Now
              </button>
            </div>
          </div>
        )}

        {/* POPOVER: SECRET REWARD DISCOVERY MINI-GAME REVEAL */}
        {revealedSecret && (
          <div className="absolute inset-x-4 bottom-16 z-40 p-5 bg-gradient-to-br from-purple-950 via-slate-900 to-slate-950 rounded-3xl border-2 border-purple-400 shadow-2xl text-center space-y-3 animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-purple-500/30 text-purple-300 mx-auto flex items-center justify-center">
              <Gift className="w-6 h-6 animate-bounce" />
            </div>

            <div className="space-y-1">
              <h4 className="text-sm font-black text-white">🎉 SECRET LAYER DISCOVERED!</h4>
              <p className="text-xs text-purple-300 font-bold">{revealedSecret.title}</p>
              <p className="text-[11px] text-slate-300">
                You explored the 3D scene and unlocked the hidden voucher:
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-100/60 border border-purple-500/40 font-mono text-sm font-black text-amber-400">
              CODE: {revealedSecret.promoCode} ({revealedSecret.discountPercent}% OFF)
            </div>

            <button
              type="button"
              onClick={() => {
                showToast(`🎟️ Voucher "${revealedSecret.promoCode}" applied to your wallet!`);
                setRevealedSecret(null);
              }}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold text-xs shadow-lg hover:brightness-110"
            >
              Claim & Apply Discount
            </button>
          </div>
        )}
      </div>

      {/* SUBMODAL: POST-EXPIRATION / STORY ANALYTICS REPORT */}
      {isExpirationReportOpen && (
        <div className="fixed inset-0 z-60 bg-slate-100/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-white/20 rounded-3xl p-6 max-w-md w-full space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <BarChart2 className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-black text-white uppercase">
                  Story Analytics // {activeStory.storyDna}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsExpirationReportOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
                <p className="text-[10px] text-slate-400">Total Views</p>
                <p className="text-lg font-black text-white">{activeStory.analytics?.totalViews || 412}</p>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
                <p className="text-[10px] text-slate-400">Product Clicks</p>
                <p className="text-lg font-black text-amber-400">{activeStory.analytics?.productClicks || 52}</p>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
                <p className="text-[10px] text-slate-400">Conversions</p>
                <p className="text-lg font-black text-emerald-400">{activeStory.analytics?.conversionsCount || 9}</p>
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-300 bg-white/5 p-3.5 rounded-2xl border border-white/10">
              <div className="flex justify-between">
                <span className="text-slate-400">Completion Rate:</span>
                <strong className="text-white">{activeStory.analytics?.completionRate || 84.5}%</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Peak Phase:</span>
                <strong className="text-purple-300">{activeStory.analytics?.peakPhase || 'Interaction Phase'}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Top Moment:</span>
                <strong className="text-red-400">00:09 (32 Reactions)</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Secret Discoveries:</span>
                <strong className="text-amber-400">{activeStory.secretLayerUnlockedCount} Shoppers Unlocked</strong>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsExpirationReportOpen(false)}
              className="w-full py-2.5 rounded-xl bg-white/10 text-white font-bold text-xs hover:bg-white/20"
            >
              Close Report
            </button>
          </div>
        </div>
      )}

      {/* SUBMODAL: TIMESHIFT 3D STORY SOCIAL SHARE & DEEP-LINK MODAL */}
      {isShareModalOpen && (
        <div
          className="fixed inset-0 z-60 bg-slate-100/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in"
          onClick={() => {
            setIsShareModalOpen(false);
            setIsPaused(false);
          }}
        >
          <div
            className="bg-slate-900/95 border border-cyan-500/30 rounded-3xl p-5 max-w-md w-full shadow-[0_0_50px_rgba(6,182,212,0.2)] space-y-4 animate-in zoom-in-95 text-white"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-slate-800 font-black shadow-lg shadow-cyan-500/30">
                  <Share2 className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white flex items-center space-x-2">
                    <span>Share 3D Story</span>
                    <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono text-[10px] border border-cyan-500/30">
                      {activeStory.storyDna}
                    </span>
                  </h3>
                  <p className="text-[10px] text-slate-400">Generate deep-link & send across social or direct message</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsShareModalOpen(false);
                  setIsPaused(false);
                }}
                className="p-1.5 rounded-full bg-white/5 hover:bg-white/15 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Story Mini-Preview Card */}
            <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center space-x-3">
              <img
                src={activeStory.mediaUrl}
                alt={activeStory.caption}
                className="w-14 h-14 rounded-xl object-cover border border-white/15 shrink-0"
              />
              <div className="min-w-0 flex-1 space-y-1">
                <div className="flex items-center space-x-1.5">
                  <img
                    src={activeStory.authorAvatar}
                    alt={activeStory.authorName}
                    className="w-4 h-4 rounded-full object-cover"
                  />
                  <span className="text-xs font-bold text-white truncate">{activeStory.authorName}</span>
                  {activeStory.isVerified && <ShieldCheck className="w-3 h-3 text-cyan-400 shrink-0" />}
                </div>
                <p className="text-[11px] text-slate-300 line-clamp-1 italic">"{activeStory.caption}"</p>
                <div className="flex items-center space-x-2 text-[10px] text-amber-400 font-mono">
                  <Clock className="w-3 h-3 text-amber-400" />
                  <span>{formatCountdown(remainingSecs)} remaining</span>
                </div>
              </div>
            </div>

            {/* Share Navigation Tabs */}
            <div className="flex rounded-xl bg-slate-100/40 p-1 border border-white/10 text-xs font-bold">
              <button
                type="button"
                onClick={() => setShareRecipientTab('link')}
                className={`flex-1 py-1.5 rounded-lg flex items-center justify-center space-x-1.5 transition-all ${
                  shareRecipientTab === 'link'
                    ? 'bg-cyan-500 text-slate-800 shadow-md font-black'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Link className="w-3.5 h-3.5" />
                <span>Deep-Link & Social</span>
              </button>
              <button
                type="button"
                onClick={() => setShareRecipientTab('direct')}
                className={`flex-1 py-1.5 rounded-lg flex items-center justify-center space-x-1.5 transition-all ${
                  shareRecipientTab === 'direct'
                    ? 'bg-cyan-500 text-slate-800 shadow-md font-black'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>Direct Message</span>
              </button>
              <button
                type="button"
                onClick={() => setShareRecipientTab('qr')}
                className={`flex-1 py-1.5 rounded-lg flex items-center justify-center space-x-1.5 transition-all ${
                  shareRecipientTab === 'qr'
                    ? 'bg-cyan-500 text-slate-800 shadow-md font-black'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <QrCode className="w-3.5 h-3.5" />
                <span>Spatial QR</span>
              </button>
            </div>

            {/* TAB CONTENT 1: DEEP-LINK & QUICK SOCIAL */}
            {shareRecipientTab === 'link' && (
              <div className="space-y-3 animate-in fade-in">
                {/* Copy Deep Link Input Group */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-300 flex items-center justify-between">
                    <span>Story Deep-Link URL</span>
                    <span className="text-[10px] text-cyan-400">Direct 3D Mode</span>
                  </label>
                  <div className="flex items-center space-x-2 bg-slate-100/60 border border-white/15 rounded-xl p-1.5 focus-within:border-cyan-400 transition-colors">
                    <input
                      type="text"
                      readOnly
                      value={storyDeepLinkUrl}
                      className="bg-transparent text-xs text-slate-300 px-2 font-mono flex-1 outline-none truncate"
                    />
                    <button
                      id="btn-copy-story-deep-link"
                      type="button"
                      onClick={handleCopyDeepLink}
                      className={`px-3 py-1.5 rounded-lg text-xs font-black flex items-center space-x-1.5 transition-all shrink-0 ${
                        hasCopiedDeepLink
                          ? 'bg-emerald-500 text-slate-800 shadow-lg shadow-emerald-500/30'
                          : 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:brightness-110'
                      }`}
                    >
                      {hasCopiedDeepLink ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy Link</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Social Share Grid */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-300">Quick Share to Social Channels</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => handleShareToExternal('whatsapp')}
                      className="flex items-center space-x-2.5 p-2.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 text-xs font-bold transition-all hover:scale-[1.02]"
                    >
                      <div className="w-6 h-6 rounded-lg bg-emerald-500 text-slate-800 flex items-center justify-center font-black">
                        💬
                      </div>
                      <div className="text-left">
                        <p className="font-black text-white">WhatsApp</p>
                        <p className="text-[9px] text-emerald-400">Direct Chat / Status</p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleShareToExternal('twitter')}
                      className="flex items-center space-x-2.5 p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-white/20 text-slate-200 text-xs font-bold transition-all hover:scale-[1.02]"
                    >
                      <div className="w-6 h-6 rounded-lg bg-white text-slate-800 flex items-center justify-center font-black text-xs">
                        𝕏
                      </div>
                      <div className="text-left">
                        <p className="font-black text-white">X (Twitter)</p>
                        <p className="text-[9px] text-slate-400">Post to feed</p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleShareToExternal('telegram')}
                      className="flex items-center space-x-2.5 p-2.5 rounded-xl bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/30 text-sky-300 text-xs font-bold transition-all hover:scale-[1.02]"
                    >
                      <div className="w-6 h-6 rounded-lg bg-sky-500 text-white flex items-center justify-center font-black">
                        ✈️
                      </div>
                      <div className="text-left">
                        <p className="font-black text-white">Telegram</p>
                        <p className="text-[9px] text-sky-400">Channels & Groups</p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleShareToExternal('linkedin')}
                      className="flex items-center space-x-2.5 p-2.5 rounded-xl bg-blue-600/15 hover:bg-blue-600/25 border border-blue-600/30 text-blue-300 text-xs font-bold transition-all hover:scale-[1.02]"
                    >
                      <div className="w-6 h-6 rounded-lg bg-blue-600 text-white flex items-center justify-center font-black text-xs">
                        in
                      </div>
                      <div className="text-left">
                        <p className="font-black text-white">LinkedIn</p>
                        <p className="text-[9px] text-blue-400">Professional Feed</p>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* TAB CONTENT 2: DIRECT IN-APP MESSAGE */}
            {shareRecipientTab === 'direct' && (
              <div className="space-y-3 animate-in fade-in">
                <p className="text-[11px] text-slate-300">
                  Send this 3D story directly to your LifeOS contacts & peers. They will receive an ephemeral interactive viewer banner.
                </p>

                {/* Peers List */}
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {[
                    { id: 'peer-1', name: 'Aarav Mehta', handle: '@aarav.m', role: 'Collaborator', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80', status: 'Active 2m ago' },
                    { id: 'peer-2', name: 'Dev Sharma', handle: '@dev.lifeos', role: 'Tech Lead', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80', status: 'Online' },
                    { id: 'peer-3', name: 'Aisha Patel', handle: '@aisha.craft', role: 'Creative Director', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80', status: 'In LifeOS Studio' },
                    { id: 'peer-4', name: 'Vikram Rao', handle: '@vikram_style', role: 'Fashion Curator', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80', status: 'Online' },
                    { id: 'peer-5', name: 'Carlos Mendes', handle: '@carlos.3d', role: '3D Spatial Explorer', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80', status: '5m ago' },
                  ].map((peer) => (
                    <div
                      key={peer.id}
                      className="flex items-center justify-between p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors"
                    >
                      <div className="flex items-center space-x-2.5">
                        <div className="relative">
                          <img
                            src={peer.avatar}
                            alt={peer.name}
                            className="w-8 h-8 rounded-full object-cover border border-white/20"
                          />
                          <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-slate-900" />
                        </div>
                        <div>
                          <div className="flex items-center space-x-1.5">
                            <span className="text-xs font-bold text-white">{peer.name}</span>
                            <span className="text-[10px] text-slate-400 font-mono">{peer.handle}</span>
                          </div>
                          <p className="text-[9px] text-cyan-400">{peer.status} • {peer.role}</p>
                        </div>
                      </div>

                      <button
                        type="button"
                        disabled={isSharingLive}
                        onClick={() => handleSendDirectMessageToPeer(peer.name)}
                        className="px-3 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500 text-cyan-300 hover:text-slate-800 border border-cyan-400/40 text-[10px] font-black transition-all hover:scale-105 active:scale-95 flex items-center space-x-1"
                      >
                        <Send className="w-3 h-3" />
                        <span>Send</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB CONTENT 3: SPATIAL QR CODE */}
            {shareRecipientTab === 'qr' && (
              <div className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-2xl border border-white/10 space-y-3 text-center animate-in fade-in">
                {/* Stylized QR Code Frame */}
                <div className="p-3 bg-white rounded-2xl shadow-xl border-4 border-cyan-400/50 relative group">
                  <svg className="w-36 h-36" viewBox="0 0 120 120">
                    {/* Corner Position Boxes */}
                    <rect x="10" y="10" width="30" height="30" rx="4" fill="#0f172a" />
                    <rect x="16" y="16" width="18" height="18" rx="2" fill="white" />
                    <rect x="20" y="20" width="10" height="10" rx="2" fill="#0f172a" />

                    <rect x="80" y="10" width="30" height="30" rx="4" fill="#0f172a" />
                    <rect x="86" y="16" width="18" height="18" rx="2" fill="white" />
                    <rect x="90" y="20" width="10" height="10" rx="2" fill="#0f172a" />

                    <rect x="10" y="80" width="30" height="30" rx="4" fill="#0f172a" />
                    <rect x="16" y="86" width="18" height="18" rx="2" fill="white" />
                    <rect x="20" y="90" width="10" height="10" rx="2" fill="#0f172a" />

                    {/* Stylized Grid Pattern Elements */}
                    <rect x="46" y="12" width="6" height="6" fill="#0f172a" />
                    <rect x="58" y="12" width="12" height="6" fill="#0f172a" />
                    <rect x="46" y="24" width="18" height="6" fill="#0f172a" />
                    <rect x="68" y="24" width="6" height="12" fill="#0f172a" />
                    <rect x="46" y="36" width="12" height="6" fill="#0f172a" />

                    <rect x="12" y="46" width="12" height="6" fill="#0f172a" />
                    <rect x="30" y="46" width="6" height="12" fill="#0f172a" />
                    <rect x="46" y="46" width="28" height="28" rx="6" fill="#06b6d4" />
                    <rect x="80" y="46" width="12" height="6" fill="#0f172a" />
                    <rect x="98" y="46" width="10" height="18" fill="#0f172a" />

                    <rect x="12" y="60" width="18" height="6" fill="#0f172a" />
                    <rect x="80" y="60" width="14" height="6" fill="#0f172a" />

                    <rect x="46" y="80" width="12" height="6" fill="#0f172a" />
                    <rect x="64" y="80" width="12" height="12" fill="#0f172a" />
                    <rect x="82" y="80" width="6" height="6" fill="#0f172a" />
                    <rect x="94" y="80" width="14" height="6" fill="#0f172a" />

                    <rect x="46" y="96" width="24" height="6" fill="#0f172a" />
                    <rect x="76" y="96" width="6" height="12" fill="#0f172a" />
                    <rect x="88" y="96" width="20" height="14" fill="#0f172a" />
                  </svg>

                  {/* Central Logo Overlay */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-8 h-8 rounded-full bg-white border-2 border-cyan-400 flex items-center justify-center shadow-lg">
                      <Sparkles className="w-4 h-4 text-cyan-400" />
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
                  <p className="text-xs font-black text-white">Instant Spatial AirDrop / Scan</p>
                  <p className="text-[10px] text-slate-400 max-w-xs">
                    Point any camera, spatial headset, or phone at this code to open this 2-hour 3D story directly.
                  </p>
                </div>
              </div>
            )}

            {/* Modal Footer */}
            <div className="flex items-center justify-between pt-2 border-t border-white/10 text-slate-400 text-[10px]">
              <span className="flex items-center space-x-1">
                <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
                <span>Deep-Link formatted for iOS, Android & Spatial Web</span>
              </span>
              <button
                type="button"
                onClick={() => {
                  setIsShareModalOpen(false);
                  setIsPaused(false);
                }}
                className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUBMODAL: CREATOR INTERACTIVE 3D POLL STICKER EDITOR */}
      {isPollEditorOpen && (
        <div
          className="fixed inset-0 z-60 bg-slate-100/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in"
          onClick={() => {
            setIsPollEditorOpen(false);
            setIsPaused(false);
          }}
        >
          <div
            className="bg-slate-900/95 border border-purple-500/30 rounded-3xl p-5 max-w-md w-full shadow-[0_0_50px_rgba(217,70,239,0.25)] space-y-4 animate-in zoom-in-95 text-white max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-500 to-indigo-600 flex items-center justify-center text-white font-black shadow-lg shadow-purple-500/30">
                  <Vote className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white flex items-center space-x-2">
                    <span>Interactive Poll Sticker</span>
                    <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-mono text-[9px] border border-purple-500/30">
                      2-Option 3D
                    </span>
                  </h3>
                  <p className="text-[10px] text-slate-400">Attach a real-time voting sticker to this 3D story</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsPollEditorOpen(false);
                  setIsPaused(false);
                }}
                className="p-1.5 rounded-full bg-white/5 hover:bg-white/15 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Templates presets */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-purple-300 flex items-center space-x-1">
                <Sparkles className="w-3 h-3 text-purple-400" />
                <span>Quick Prompt Presets</span>
              </label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  {
                    q: 'Which festive shade is more royal? ✨',
                    a: 'Royal Crimson ❤️',
                    b: 'Emerald Silk 💚',
                  },
                  {
                    q: 'Should we drop this tonight? 🔥',
                    a: 'Yes, Drop It! ⚡',
                    b: 'Wait for Weekend ⏳',
                  },
                  {
                    q: 'Rate this 3D capture angle! 🎥',
                    a: 'Cinematic 10/10 🌟',
                    b: 'Needs More Tilt 👀',
                  },
                  {
                    q: 'Pair with loafers or boots? 👞',
                    a: 'Classic Loafers 👞',
                    b: 'Chelsea Boots 🥾',
                  },
                ].map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setPollQuestion(preset.q);
                      setPollOptionA(preset.a);
                      setPollOptionB(preset.b);
                    }}
                    className="text-[10px] px-2.5 py-1 rounded-full bg-white/5 hover:bg-purple-500/20 text-slate-300 hover:text-purple-200 border border-white/10 hover:border-purple-400/40 transition-colors"
                  >
                    {preset.q.split(' ')[0]} {preset.q.split(' ')[1]}...
                  </button>
                ))}
              </div>
            </div>

            {/* Poll Question Input */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-slate-200">
                Poll Question <span className="text-purple-400">*</span>
              </label>
              <input
                type="text"
                id="input-poll-question"
                value={pollQuestion}
                onChange={(e) => setPollQuestion(e.target.value)}
                placeholder="e.g. Which festive color is more royal? ✨"
                className="w-full px-3 py-2 rounded-xl bg-slate-100/50 border border-white/15 focus:border-purple-400 focus:outline-none text-xs font-semibold text-white placeholder:text-slate-500"
              />
            </div>

            {/* Two Options Inputs */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-cyan-300 flex items-center space-x-1">
                  <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                  <span>Option A</span>
                </label>
                <input
                  type="text"
                  id="input-poll-option-a"
                  value={pollOptionA}
                  onChange={(e) => setPollOptionA(e.target.value)}
                  placeholder="e.g. Crimson Red ❤️"
                  className="w-full px-3 py-2 rounded-xl bg-slate-100/50 border border-cyan-500/30 focus:border-cyan-400 focus:outline-none text-xs font-semibold text-white placeholder:text-slate-500"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-purple-300 flex items-center space-x-1">
                  <span className="w-2 h-2 rounded-full bg-purple-400"></span>
                  <span>Option B</span>
                </label>
                <input
                  type="text"
                  id="input-poll-option-b"
                  value={pollOptionB}
                  onChange={(e) => setPollOptionB(e.target.value)}
                  placeholder="e.g. Emerald Silk 💚"
                  className="w-full px-3 py-2 rounded-xl bg-slate-100/50 border border-purple-500/30 focus:border-purple-400 focus:outline-none text-xs font-semibold text-white placeholder:text-slate-500"
                />
              </div>
            </div>

            {/* Theme Color Selector */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-slate-200">Glow Palette Theme</label>
              <div className="flex items-center space-x-2">
                {[
                  { id: 'cyan', label: 'Cyan', bg: 'bg-cyan-500' },
                  { id: 'purple', label: 'Purple', bg: 'bg-fuchsia-500' },
                  { id: 'amber', label: 'Amber', bg: 'bg-amber-500' },
                  { id: 'emerald', label: 'Emerald', bg: 'bg-emerald-500' },
                  { id: 'rose', label: 'Rose', bg: 'bg-rose-500' },
                ].map((color) => (
                  <button
                    key={color.id}
                    type="button"
                    onClick={() => setPollThemeColor(color.id as any)}
                    className={`flex-1 py-1.5 rounded-xl border text-[10px] font-bold flex items-center justify-center space-x-1 transition-all ${
                      pollThemeColor === color.id
                        ? 'border-white bg-white/20 text-white ring-2 ring-purple-400'
                        : 'border-white/10 bg-white/5 text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className={`w-2.5 h-2.5 rounded-full ${color.bg}`} />
                    <span>{color.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Spatial Position & Depth Controls */}
            <div className="grid grid-cols-2 gap-3 p-3 rounded-2xl bg-slate-100/40 border border-white/10">
              <div className="space-y-1">
                <div className="flex justify-between text-[10px] font-bold text-slate-300">
                  <span>3D Depth Z</span>
                  <span className="font-mono text-purple-300">{pollDepthZ}x</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="12"
                  step="1"
                  value={pollDepthZ}
                  onChange={(e) => setPollDepthZ(Number(e.target.value))}
                  className="w-full accent-purple-400 cursor-pointer"
                />
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-[10px] font-bold text-slate-300">
                  <span>Vertical Pos</span>
                  <span className="font-mono text-cyan-300">{pollYPercent}%</span>
                </div>
                <input
                  type="range"
                  min="30"
                  max="80"
                  step="2"
                  value={pollYPercent}
                  onChange={(e) => setPollYPercent(Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>
            </div>

            {/* Live Interactive Preview Box */}
            <div className="space-y-1.5">
              <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                Sticker Preview
              </label>
              <div className="p-3.5 rounded-2xl bg-white/90 border border-purple-400/40 space-y-2">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-cyan-300 font-mono font-bold">● LIVE POLL</span>
                  <span className="text-slate-400">Real-time sync</span>
                </div>
                <p className="text-xs font-bold text-white">
                  {pollQuestion || 'Your question here...'}
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2 rounded-xl bg-white/10 border border-white/15 text-left">
                    <span className="text-[10px] font-bold text-slate-200 truncate block">
                      {pollOptionA || 'Option A'}
                    </span>
                    <span className="text-[9px] text-cyan-300 font-mono">50%</span>
                  </div>
                  <div className="p-2 rounded-xl bg-white/10 border border-white/15 text-left">
                    <span className="text-[10px] font-bold text-slate-200 truncate block">
                      {pollOptionB || 'Option B'}
                    </span>
                    <span className="text-[9px] text-purple-300 font-mono">50%</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center space-x-2 pt-2 border-t border-white/10">
              {activeStory.pollSticker && (
                <button
                  type="button"
                  id="btn-delete-poll-sticker"
                  onClick={handleDeletePoll}
                  className="px-3.5 py-2.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/30 font-bold text-xs flex items-center space-x-1.5 transition-colors"
                  title="Remove Poll Sticker from Story"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Remove</span>
                </button>
              )}
              <button
                type="button"
                id="btn-save-poll-sticker"
                onClick={handleSavePoll}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-purple-500 via-indigo-500 to-cyan-500 text-white font-black text-xs hover:brightness-110 shadow-lg shadow-purple-500/25 transition-all flex items-center justify-center space-x-1.5"
              >
                <Check className="w-4 h-4" />
                <span>{activeStory.pollSticker ? 'Update Poll Sticker' : 'Attach Poll to 3D Story'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
