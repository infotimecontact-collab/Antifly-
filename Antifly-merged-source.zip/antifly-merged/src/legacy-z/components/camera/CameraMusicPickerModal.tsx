import React, { useState, useRef } from 'react';
import { CameraMusicTrack } from '../../types';
import { DEFAULT_MUSIC_TRACKS } from '../../data/defaultCameraData';
import {
  X,
  Music,
  Play,
  Pause,
  Check,
  Search,
  Volume2,
  Sparkles,
} from 'lucide-react';

interface CameraMusicPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedMusic?: CameraMusicTrack;
  onSelectMusic: (track: CameraMusicTrack | undefined) => void;
}

export const CameraMusicPickerModal: React.FC<CameraMusicPickerModalProps> = ({
  isOpen,
  onClose,
  selectedMusic,
  onSelectMusic,
}) => {
  const [playingTrackId, setPlayingTrackId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const audioRef = useRef<HTMLAudioElement | null>(null);

  if (!isOpen) return null;

  const filteredTracks = DEFAULT_MUSIC_TRACKS.filter(
    (t) =>
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.artist.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.genre.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleTogglePlay = (track: CameraMusicTrack) => {
    if (playingTrackId === track.id) {
      audioRef.current?.pause();
      setPlayingTrackId(null);
    } else {
      if (audioRef.current) {
        audioRef.current.src = track.previewUrl;
        audioRef.current.play().catch(() => {});
      }
      setPlayingTrackId(track.id);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-100/80 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div className="bg-slate-900 border border-white/20 rounded-3xl shadow-2xl max-w-lg w-full max-h-[85vh] flex flex-col overflow-hidden text-white">
        {/* Header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-white/60">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-pink-500 to-rose-500 flex items-center justify-center shadow-lg">
              <Music className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Add Soundtrack & Beat</h3>
              <p className="text-xs text-slate-400">Sync viral tunes to your shoppable snap or 15s reel</p>
            </div>
          </div>
          <button
            id="btn-close-music-picker"
            type="button"
            onClick={() => {
              audioRef.current?.pause();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-white/10 text-white flex items-center justify-center hover:bg-white/20 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search */}
        <div className="p-4 border-b border-white/10 bg-white/30">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              id="camera-music-search-input"
              type="text"
              placeholder="Search by track name, genre, or mood..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white border border-white/15 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-pink-500"
            />
          </div>
        </div>

        {/* Track List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {/* Option to clear music */}
          <button
            type="button"
            onClick={() => {
              onSelectMusic(undefined);
              audioRef.current?.pause();
              onClose();
            }}
            className="w-full p-3 rounded-2xl border border-dashed border-white/20 text-slate-400 hover:text-white hover:bg-white/5 text-xs font-semibold flex items-center justify-center space-x-2"
          >
            <span>Original Video Audio (No Background Music)</span>
          </button>

          {filteredTracks.map((track) => {
            const isSelected = selectedMusic?.id === track.id;
            const isPlaying = playingTrackId === track.id;

            return (
              <div
                key={track.id}
                className={`flex items-center justify-between p-3 rounded-2xl border transition-all ${
                  isSelected
                    ? 'bg-pink-500/20 border-pink-500 text-white'
                    : 'bg-white/5 border-white/5 text-slate-300 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center space-x-3 min-w-0">
                  <div className="relative w-12 h-12 rounded-xl overflow-hidden bg-slate-800 flex-shrink-0">
                    <img src={track.coverArt} alt={track.title} className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => handleTogglePlay(track)}
                      className="absolute inset-0 bg-slate-100/50 backdrop-blur-xs flex items-center justify-center text-white hover:scale-110 transition-transform"
                    >
                      {isPlaying ? (
                        <Pause className="w-4 h-4 fill-current" />
                      ) : (
                        <Play className="w-4 h-4 fill-current ml-0.5" />
                      )}
                    </button>
                  </div>

                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-white truncate">{track.title}</h4>
                    <p className="text-[11px] text-slate-400">{track.artist} • {track.genre}</p>
                    {track.bpm && (
                      <span className="text-[10px] text-pink-400 font-mono font-bold">
                        {track.bpm} BPM
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center space-x-2 flex-shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      onSelectMusic(track);
                      audioRef.current?.pause();
                      onClose();
                    }}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      isSelected
                        ? 'bg-pink-500 text-white shadow-md'
                        : 'bg-white/10 hover:bg-white/20 text-white'
                    }`}
                  >
                    {isSelected ? 'Attached' : 'Use Track'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Hidden HTML5 Audio Element for live preview playback */}
        <audio ref={audioRef} onEnded={() => setPlayingTrackId(null)} />
      </div>
    </div>
  );
};
