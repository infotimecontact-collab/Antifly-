import React, { useState, useEffect, useRef } from 'react';
import {
  CameraMode,
  CameraFlashMode,
  CameraFacing,
  CameraAspectRatio,
  CameraLens,
  CameraMusicTrack,
  CameraCapturedMedia,
  CameraProductTag,
  CameraSticker,
} from '../../types';
import { useApp } from '../../context/AppContext';
import { DEFAULT_CAMERA_LENSES, DEFAULT_MUSIC_TRACKS } from '../../data/defaultCameraData';
import { CameraViewfinder } from './CameraViewfinder';
import { CameraModeSwitcher } from './CameraModeSwitcher';
import { CameraCreativeToolbar } from './CameraCreativeToolbar';
import { CameraEditorPostCapture } from './CameraEditorPostCapture';
import { CameraProductTaggerModal } from './CameraProductTaggerModal';
import { CameraMusicPickerModal } from './CameraMusicPickerModal';
import { CameraStickerPickerModal } from './CameraStickerPickerModal';
import { CameraGalleryVaultModal } from './CameraGalleryVaultModal';
import { X, Sparkles, AlertCircle } from 'lucide-react';

export const CameraStudioModal: React.FC = () => {
  const {
    isCameraStudioOpen,
    setIsCameraStudioOpen,
    cameraInitialMode,
    cameraTargetConversationId,
    cameraTargetProductId,
    cameraGalleryMedia,
    saveMediaToCameraGallery,
    saveMediaDraft,
    deleteMediaFromCameraGallery,
    publishMediaToStory,
    publishMediaToReel,
    publishMediaToFeed,
    publishMediaToProductCatalog,
    sendMediaDirectToChat,
    products,
    formatPrice,
    chatConversations,
  } = useApp();

  // Studio Flow State: 'viewfinder' | 'editor'
  const [studioStage, setStudioStage] = useState<'viewfinder' | 'editor'>('viewfinder');
  const [cameraMode, setCameraMode] = useState<CameraMode>(cameraInitialMode || 'photo');
  const [aspectRatio, setAspectRatio] = useState<CameraAspectRatio>('9:16');
  const [flashMode, setFlashMode] = useState<CameraFlashMode>('off');
  const [facing, setFacing] = useState<CameraFacing>('environment');
  const [selectedLens, setSelectedLens] = useState<CameraLens>(DEFAULT_CAMERA_LENSES[0]);
  const [selectedMusic, setSelectedMusic] = useState<CameraMusicTrack | undefined>(undefined);
  const [isBeautyActive, setIsBeautyActive] = useState(false);
  const [beautyLevel, setBeautyLevel] = useState(50);
  const [isAutoEnhanceActive, setIsAutoEnhanceActive] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState<number>(0);
  const [isCountingDown, setIsCountingDown] = useState(false);
  const [countdownCurrent, setCountdownCurrent] = useState(0);

  // Video recording
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const maxRecordingSeconds = cameraMode === 'reel' ? 15 : 60;
  const recordingTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Captured media being edited
  const [capturedMedia, setCapturedMedia] = useState<CameraCapturedMedia | null>(null);

  // Submodals
  const [isProductTaggerOpen, setIsProductTaggerOpen] = useState(false);
  const [isMusicPickerOpen, setIsMusicPickerOpen] = useState(false);
  const [isStickerPickerOpen, setIsStickerPickerOpen] = useState(false);
  const [isGalleryVaultOpen, setIsGalleryVaultOpen] = useState(false);

  // Active tags, stickers, drawings during capture session
  const [activeTags, setActiveTags] = useState<CameraProductTag[]>([]);
  const [activeStickers, setActiveStickers] = useState<CameraSticker[]>([]);

  // Sync initial camera mode when triggered from external entry points
  useEffect(() => {
    if (isCameraStudioOpen) {
      if (cameraInitialMode) setCameraMode(cameraInitialMode);
      setStudioStage('viewfinder');
      setCapturedMedia(null);

      // If opened with target product ID, auto-tag product
      if (cameraTargetProductId) {
        const prod = products.find((p) => p.id === cameraTargetProductId);
        if (prod) {
          setActiveTags([
            {
              id: `tag-${Date.now()}`,
              productId: prod.id,
              productName: prod.name,
              price: prod.price,
              mrp: prod.mrp,
              discountPercent: prod.discount,
              image: prod.images?.[0] || prod.thumbnail,
              x: 50,
              y: 50,
              style: 'pill',
            },
          ]);
        }
      }
    }
  }, [isCameraStudioOpen, cameraInitialMode, cameraTargetProductId, products]);

  // Video recording timer interval
  useEffect(() => {
    if (isRecording) {
      recordingTimerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => {
          if (prev >= maxRecordingSeconds) {
            handleStopRecording();
            return maxRecordingSeconds;
          }
          return prev + 1;
        });
      }, 1000);
    } else {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
    }
    return () => {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
    };
  }, [isRecording, maxRecordingSeconds]);

  if (!isCameraStudioOpen) return null;

  // Flash toggle cycle: off -> on -> auto -> torch
  const handleToggleFlash = () => {
    const cycle: Record<CameraFlashMode, CameraFlashMode> = {
      off: 'on',
      on: 'auto',
      auto: 'torch',
      torch: 'off',
    };
    setFlashMode(cycle[flashMode]);
  };

  // Aspect ratio cycle: 9:16 -> 1:1 -> 4:5 -> 16:9
  const handleToggleAspectRatio = () => {
    const cycle: Record<CameraAspectRatio, CameraAspectRatio> = {
      '9:16': '1:1',
      '1:1': '4:5',
      '4:5': '16:9',
      '16:9': '9:16',
    };
    setAspectRatio(cycle[aspectRatio]);
  };

  // Timer cycle: 0 -> 3 -> 5 -> 10 -> 0
  const handleToggleTimer = () => {
    const cycle: Record<number, number> = {
      0: 3,
      3: 5,
      5: 10,
      10: 0,
    };
    setTimerSeconds(cycle[timerSeconds] ?? 0);
  };

  // Trigger photo capture
  const handleCapturePhoto = (customUrl?: string) => {
    if (timerSeconds > 0 && !isCountingDown) {
      setIsCountingDown(true);
      setCountdownCurrent(timerSeconds);
      const timerInt = setInterval(() => {
        setCountdownCurrent((prev) => {
          if (prev <= 1) {
            clearInterval(timerInt);
            setIsCountingDown(false);
            executePhotoCapture(customUrl);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return;
    }
    executePhotoCapture(customUrl);
  };

  const executePhotoCapture = (customUrl?: string) => {
    const samplePhoto =
      facing === 'user'
        ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=1080&auto=format&fit=crop&q=80'
        : 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=1080&auto=format&fit=crop&q=80';

    const newMedia: CameraCapturedMedia = {
      id: `media-${Date.now()}`,
      type: 'photo',
      mediaUrl: customUrl || samplePhoto,
      aspectRatio,
      mode: cameraMode,
      createdAt: 'Just now',
      filterName: selectedLens.name,
      filterCss: selectedLens.filterCss,
      productTags: [...activeTags],
      textOverlays: [],
      stickers: [...activeStickers],
      drawingPaths: [],
      musicTrack: selectedMusic,
      privacy: 'public',
    };

    setCapturedMedia(newMedia);
    setStudioStage('editor');
  };

  // Trigger video recording start/stop
  const handleStartRecording = () => {
    setRecordingSeconds(0);
    setIsRecording(true);
  };

  const handleStopRecording = () => {
    setIsRecording(false);
    const sampleVideo =
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1080&auto=format&fit=crop&q=80';

    const newMedia: CameraCapturedMedia = {
      id: `media-vid-${Date.now()}`,
      type: 'video',
      mediaUrl: sampleVideo,
      durationSeconds: Math.max(1, recordingSeconds),
      aspectRatio,
      mode: cameraMode,
      createdAt: 'Just now',
      filterName: selectedLens.name,
      filterCss: selectedLens.filterCss,
      productTags: [...activeTags],
      textOverlays: [],
      stickers: [...activeStickers],
      drawingPaths: [],
      musicTrack: selectedMusic || DEFAULT_MUSIC_TRACKS[0],
      privacy: 'public',
    };

    setCapturedMedia(newMedia);
    setStudioStage('editor');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-slate-100 flex flex-col select-none animate-in fade-in duration-200"
    >
      {/* Studio Header Bar */}
      <header className="absolute top-0 inset-x-0 z-40 p-4 flex items-center justify-between pointer-events-auto">
        {/* Brand / Mode Badge */}
        <div className="flex items-center space-x-2.5 bg-slate-100/60 backdrop-blur-xl px-3.5 py-1.5 rounded-full border border-white/20 shadow-xl">
          <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-amber-400 to-orange-500 flex items-center justify-center">
            <Sparkles className="w-3 h-3 text-slate-800 font-black" />
          </div>
          <span className="text-xs font-black text-white tracking-wider uppercase">
            Studio // {cameraMode}
          </span>
        </div>

        {/* Close Button */}
        <button
          id="btn-close-camera-studio-main"
          type="button"
          onClick={() => setIsCameraStudioOpen(false)}
          className="w-10 h-10 rounded-full bg-slate-100/60 backdrop-blur-xl text-white flex items-center justify-center hover:bg-white/20 border border-white/20 transition-all shadow-xl"
        >
          <X className="w-5 h-5" />
        </button>
      </header>

      {/* Main Studio Viewport */}
      {studioStage === 'viewfinder' ? (
        <div className="relative w-full h-full flex flex-col justify-between overflow-hidden">
          {/* Central Live Viewfinder */}
          <div className="relative flex-1 w-full h-full flex items-center justify-center">
            <CameraViewfinder
              currentMode={cameraMode}
              aspectRatio={aspectRatio}
              flashMode={flashMode}
              facing={facing}
              onToggleFacing={() => setFacing(facing === 'user' ? 'environment' : 'user')}
              selectedLens={selectedLens}
              onSelectLens={setSelectedLens}
              selectedMusic={selectedMusic}
              isRecording={isRecording}
              recordingSeconds={recordingSeconds}
              maxRecordingSeconds={maxRecordingSeconds}
              onStartRecording={handleStartRecording}
              onStopRecording={handleStopRecording}
              onCapturePhoto={handleCapturePhoto}
              onOpenGallery={() => setIsGalleryVaultOpen(true)}
              recentThumbnail={cameraGalleryMedia[0]?.mediaUrl}
              isBeautyActive={isBeautyActive}
              beautyLevel={beautyLevel}
              onBeautyLevelChange={setBeautyLevel}
              timerSeconds={timerSeconds}
              isCountingDown={isCountingDown}
              countdownCurrent={countdownCurrent}
            />

            {/* Right Side Floating Creative Toolbar */}
            <div className="absolute right-4 top-20 z-30 pointer-events-auto">
              <CameraCreativeToolbar
                onOpenMusicPicker={() => setIsMusicPickerOpen(true)}
                onOpenProductTagger={() => setIsProductTaggerOpen(true)}
                onToggleTextEditor={() => handleCapturePhoto()}
                onToggleDrawingCanvas={() => handleCapturePhoto()}
                onOpenStickerPicker={() => setIsStickerPickerOpen(true)}
                onToggleTimer={handleToggleTimer}
                timerSeconds={timerSeconds}
                onToggleAspectRatio={handleToggleAspectRatio}
                aspectRatio={aspectRatio}
                onToggleFlash={handleToggleFlash}
                flashMode={flashMode}
                onToggleBeautySlider={() => setIsBeautyActive(!isBeautyActive)}
                isBeautyActive={isBeautyActive}
                onAutoEnhanceToggle={() => setIsAutoEnhanceActive(!isAutoEnhanceActive)}
                isAutoEnhanceActive={isAutoEnhanceActive}
                selectedMusic={selectedMusic}
                taggedProductsCount={activeTags.length}
                hasDrawings={false}
                hasTextOverlays={false}
              />
            </div>
          </div>

          {/* Bottom Mode Switcher Bar */}
          <div className="w-full pb-2 z-30 bg-gradient-to-t from-slate-100 via-slate-100/80 to-transparent">
            <CameraModeSwitcher
              currentMode={cameraMode}
              onSelectMode={(mode) => setCameraMode(mode)}
              isRecording={isRecording}
            />
          </div>
        </div>
      ) : (
        /* Post-Capture Review & Composition Stage */
        capturedMedia && (
          <CameraEditorPostCapture
            media={capturedMedia}
            onBackToCamera={() => {
              setStudioStage('viewfinder');
              setCapturedMedia(null);
            }}
            onSaveToGallery={(m) => {
              saveMediaToCameraGallery(m);
              setIsCameraStudioOpen(false);
            }}
            onSaveDraft={(m) => {
              saveMediaDraft(m);
              setIsCameraStudioOpen(false);
            }}
            onPublishToStory={(m) => {
              publishMediaToStory(m);
              setIsCameraStudioOpen(false);
            }}
            onPublishToReel={(m) => {
              publishMediaToReel(m);
              setIsCameraStudioOpen(false);
            }}
            onPublishToFeed={(m) => {
              publishMediaToFeed(m);
              setIsCameraStudioOpen(false);
            }}
            onPublishToCatalog={(m) => {
              publishMediaToProductCatalog(m);
              setIsCameraStudioOpen(false);
            }}
            onSendToChat={(convId, m) => {
              sendMediaDirectToChat(convId, m);
              setIsCameraStudioOpen(false);
            }}
            availableChatConversations={chatConversations.map((c) => ({
              id: c.id,
              name: c.peerName,
              avatar: c.peerAvatar,
            }))}
            targetConversationId={cameraTargetConversationId}
            products={products}
            onOpenProductTagger={() => setIsProductTaggerOpen(true)}
            formatPrice={formatPrice}
          />
        )
      )}

      {/* Submodal: Shoppable Product Tagger */}
      <CameraProductTaggerModal
        isOpen={isProductTaggerOpen}
        onClose={() => setIsProductTaggerOpen(false)}
        products={products}
        currentTags={activeTags}
        onAddTag={(tag) => {
          setActiveTags((prev) => [...prev, tag]);
          setIsProductTaggerOpen(false);
        }}
        onRemoveTag={(tagId) => setActiveTags((prev) => prev.filter((t) => t.id !== tagId))}
        formatPrice={formatPrice}
      />

      {/* Submodal: Music & Soundtrack Picker */}
      <CameraMusicPickerModal
        isOpen={isMusicPickerOpen}
        onClose={() => setIsMusicPickerOpen(false)}
        selectedMusic={selectedMusic}
        onSelectMusic={(track) => setSelectedMusic(track)}
      />

      {/* Submodal: Sticker & Poll Picker */}
      <CameraStickerPickerModal
        isOpen={isStickerPickerOpen}
        onClose={() => setIsStickerPickerOpen(false)}
        onAddSticker={(stk) => setActiveStickers((prev) => [...prev, stk])}
      />

      {/* Submodal: Camera Media Vault Gallery */}
      <CameraGalleryVaultModal
        isOpen={isGalleryVaultOpen}
        onClose={() => setIsGalleryVaultOpen(false)}
        galleryMedia={cameraGalleryMedia}
        onSelectMediaToEdit={(item) => {
          setCapturedMedia(item);
          setStudioStage('editor');
          setIsGalleryVaultOpen(false);
        }}
        onDeleteMedia={(id) => deleteMediaFromCameraGallery(id)}
        onPublishToStory={(item) => {
          publishMediaToStory(item);
          setIsGalleryVaultOpen(false);
        }}
        onPublishToReel={(item) => {
          publishMediaToReel(item);
          setIsGalleryVaultOpen(false);
        }}
        formatPrice={formatPrice}
      />
    </div>
  );
};
