import React from 'react';
import { useApp } from '../../context/AppContext';
import { ShieldAlert, UserX, Store, X } from 'lucide-react';

export const InstagramBlockConfirmationModal: React.FC = () => {
  const { blockConfirmModal, closeBlockConfirmationModal } = useApp();

  if (!blockConfirmModal || !blockConfirmModal.isOpen) return null;

  const { targetType, targetName, targetAvatar, targetHandle, onConfirm } = blockConfirmModal;

  return (
    <div
      id="instagram-block-confirmation-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-white/80 backdrop-blur-md p-4 animate-in fade-in duration-150"
    >
      <div className="w-full max-w-xs bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col text-center animate-in zoom-in-95 duration-150">
        <div className="p-6 flex flex-col items-center">
          {/* Avatar / Icon */}
          <div className="relative mb-3">
            <div className="w-16 h-16 rounded-full border-2 border-rose-500/50 p-0.5 overflow-hidden shadow-inner">
              {targetAvatar ? (
                <img src={targetAvatar} alt={targetName} className="w-full h-full rounded-full object-cover" />
              ) : (
                <div className="w-full h-full rounded-full bg-rose-50 dark:bg-rose-950/40 text-rose-600 flex items-center justify-center">
                  {targetType === 'seller' ? <Store className="w-7 h-7" /> : <UserX className="w-7 h-7" />}
                </div>
              )}
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-rose-600 text-white flex items-center justify-center shadow-md">
              <UserX className="w-3.5 h-3.5" />
            </div>
          </div>

          <h3 className="text-base font-black text-slate-900 dark:text-white">
            Block {targetHandle || targetName}?
          </h3>

          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed text-center px-1">
            {targetType === 'seller'
              ? "They won't be able to message you, show up in your feed, or receive your orders on Antifly."
              : targetType === 'user'
              ? "They won't be able to message you, see your community lookbooks, or view your reviews and comments."
              : "They won't be able to view your store catalog, place orders, or message your venture."}
          </p>

          <div className="mt-3 py-2 px-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 text-left space-y-1.5 w-full">
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
              <span>They won't be notified that you blocked them.</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
              <span>You can unblock them at any time in Settings.</span>
            </div>
          </div>
        </div>

        {/* Action Buttons (Instagram Style Stack) */}
        <div className="border-t border-slate-100 dark:border-slate-800 flex flex-col divide-y divide-slate-100 dark:divide-slate-800">
          <button
            type="button"
            id="confirm-block-action-btn"
            onClick={onConfirm}
            className="w-full py-3.5 text-sm font-bold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition cursor-pointer active:bg-rose-100"
          >
            Block
          </button>
          <button
            type="button"
            onClick={closeBlockConfirmationModal}
            className="w-full py-3.5 text-sm font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
