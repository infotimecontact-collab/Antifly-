import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShieldCheck,
  Lock,
  X,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  Building2,
  Smartphone,
  Fingerprint,
  RefreshCw,
  Info,
} from 'lucide-react';
import { UPIAppType } from '../../types';

export const UPIPinAuthenticatorModal: React.FC = () => {
  const { upiPinModalConfig, closeUPIPinModal, verifyUPIPin, showToast } = useApp();

  const [pin, setPin] = useState<string>('');
  const [showPin, setShowPin] = useState<boolean>(false);
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [utrNumber, setUtrNumber] = useState<string>('');

  const pinLength = 6; // Standard 6-digit bank UPI PIN

  useEffect(() => {
    if (upiPinModalConfig) {
      setPin('');
      setShowPin(false);
      setIsVerifying(false);
      setIsSuccess(false);
      setErrorMessage('');
      setUtrNumber('');
    }
  }, [upiPinModalConfig]);

  if (!upiPinModalConfig || !upiPinModalConfig.isOpen) return null;

  const { amount, payeeName, payeeVpa, upiApp, bankName, accountMask, onSuccess } = upiPinModalConfig;

  const handleKeyPress = (num: string) => {
    if (pin.length < pinLength && !isVerifying && !isSuccess) {
      setPin((prev) => prev + num);
      setErrorMessage('');
    }
  };

  const handleBackspace = () => {
    if (!isVerifying && !isSuccess) {
      setPin((prev) => prev.slice(0, -1));
      setErrorMessage('');
    }
  };

  const handleClear = () => {
    if (!isVerifying && !isSuccess) {
      setPin('');
      setErrorMessage('');
    }
  };

  const handleConfirmPin = async () => {
    if (pin.length < 4) {
      setErrorMessage(`Please enter your complete ${pinLength}-digit UPI PIN`);
      return;
    }

    setIsVerifying(true);
    setErrorMessage('');

    try {
      const res = await verifyUPIPin(pin);
      if (res.success) {
        setIsSuccess(true);
        setUtrNumber(res.utr);
        showToast(`✅ Payment authorized via ${getAppName(upiApp)}!`);
        setTimeout(() => {
          onSuccess(res.utr);
          closeUPIPinModal();
        }, 1200);
      } else {
        setIsVerifying(false);
        setErrorMessage(res.message || 'Incorrect UPI PIN. Please check and re-enter.');
        setPin('');
      }
    } catch (e) {
      setIsVerifying(false);
      setErrorMessage('Bank gateway connection timeout. Please retry.');
    }
  };

  const getAppStyle = (app: UPIAppType) => {
    switch (app) {
      case 'phonepe':
        return {
          name: 'PhonePe UPI',
          bg: 'from-purple-700 to-indigo-800',
          badgeBg: 'bg-purple-600',
          textColor: 'text-purple-600',
          logoText: 'PhonePe',
        };
      case 'gpay':
        return {
          name: 'Google Pay (GPay)',
          bg: 'from-blue-600 to-indigo-700',
          badgeBg: 'bg-blue-600',
          textColor: 'text-blue-600',
          logoText: 'Google Pay',
        };
      case 'paytm':
        return {
          name: 'Paytm UPI',
          bg: 'from-sky-600 to-blue-700',
          badgeBg: 'bg-sky-500',
          textColor: 'text-sky-600',
          logoText: 'Paytm',
        };
      case 'cred':
        return {
          name: 'CRED UPI',
          bg: 'from-slate-900 to-slate-100',
          badgeBg: 'bg-amber-500',
          textColor: 'text-amber-500',
          logoText: 'CRED',
        };
      case 'bhim':
      default:
        return {
          name: 'BHIM UPI',
          bg: 'from-emerald-700 to-teal-800',
          badgeBg: 'bg-emerald-600',
          textColor: 'text-emerald-600',
          logoText: 'BHIM UPI',
        };
    }
  };

  const appStyle = getAppStyle(upiApp);

  function getAppName(app: UPIAppType) {
    switch (app) {
      case 'phonepe':
        return 'PhonePe';
      case 'gpay':
        return 'Google Pay';
      case 'paytm':
        return 'Paytm';
      case 'cred':
        return 'CRED';
      default:
        return 'UPI';
    }
  }

  return (
    <div
      id="upi-pin-authenticator-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-white/80 backdrop-blur-md p-3 sm:p-4 animate-in fade-in duration-200"
    >
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col animate-in zoom-in-95 duration-200 text-slate-800 dark:text-slate-100">
        {/* NPCI & Bank Header */}
        <div className={`bg-gradient-to-r ${appStyle.bg} text-white p-4 relative`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-white/20 flex items-center justify-center backdrop-blur-sm">
                <Lock className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-[11px] font-medium text-white/80 uppercase tracking-wider">NPCI Unified Payments</p>
                <h3 className="font-black text-sm tracking-tight">{appStyle.name}</h3>
              </div>
            </div>

            <button
              onClick={closeUPIPinModal}
              disabled={isVerifying || isSuccess}
              className="w-7 h-7 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center text-white transition-colors cursor-pointer disabled:opacity-50"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Amount & Payee Bar */}
          <div className="mt-3 bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/15 flex items-center justify-between">
            <div>
              <p className="text-[10px] text-white/80 uppercase font-semibold">Paying To</p>
              <p className="text-xs font-bold text-white truncate max-w-[170px]">{payeeName}</p>
              <p className="text-[10px] font-mono text-white/70 truncate max-w-[170px]">{payeeVpa}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-white/80 uppercase font-semibold">Total Amount</p>
              <p className="text-base font-black text-white">₹{amount.toLocaleString('en-IN')}</p>
            </div>
          </div>
        </div>

        {/* Bank & Account Info Strip */}
        <div className="px-5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-slate-500" />
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200">{bankName || 'HDFC Bank'}</span>
              <span className="text-[11px] text-slate-500 font-mono ml-1.5">{accountMask || 'A/C XX4821'}</span>
            </div>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-bold">
            Verified Account
          </span>
        </div>

        {/* PIN Input Stage */}
        <div className="p-5 flex flex-col items-center">
          {isSuccess ? (
            <div className="py-8 flex flex-col items-center text-center animate-in zoom-in-95">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-600 flex items-center justify-center mb-3">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h4 className="font-bold text-base text-slate-900 dark:text-white">Payment Successful</h4>
              <p className="text-xs text-slate-500 mt-1">₹{amount.toLocaleString('en-IN')} debited from {bankName}</p>
              {utrNumber && (
                <p className="text-[10px] font-mono text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-1 rounded-lg mt-2 font-bold">
                  {utrNumber}
                </p>
              )}
            </div>
          ) : isVerifying ? (
            <div className="py-8 flex flex-col items-center text-center">
              <RefreshCw className="w-10 h-10 text-amber-500 animate-spin mb-3" />
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">Connecting with Bank Gateway...</h4>
              <p className="text-xs text-slate-500 mt-1">Verifying 6-Digit Encrypted UPI PIN with NPCI</p>
            </div>
          ) : (
            <>
              <div className="w-full flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  ENTER {pinLength}-DIGIT UPI PIN
                </span>
                <button
                  type="button"
                  onClick={() => setShowPin(!showPin)}
                  className="text-[11px] font-bold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1 cursor-pointer"
                >
                  {showPin ? (
                    <>
                      <EyeOff className="w-3.5 h-3.5" />
                      <span>HIDE</span>
                    </>
                  ) : (
                    <>
                      <Eye className="w-3.5 h-3.5" />
                      <span>SHOW</span>
                    </>
                  )}
                </button>
              </div>

              {/* Masked PIN Indicators */}
              <div className="flex items-center justify-center gap-3 my-3">
                {Array.from({ length: pinLength }).map((_, idx) => {
                  const hasChar = pin.length > idx;
                  return (
                    <div
                      key={idx}
                      className={`w-9 h-11 rounded-xl flex items-center justify-center font-mono font-bold text-base transition-all ${
                        hasChar
                          ? 'border-2 border-amber-500 bg-amber-50 dark:bg-amber-950/30 text-amber-600 dark:text-amber-400 shadow-sm scale-105'
                          : 'border border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-400'
                      }`}
                    >
                      {hasChar ? (showPin ? pin[idx] : '●') : ''}
                    </div>
                  );
                })}
              </div>

              {errorMessage && (
                <div className="flex items-center gap-1.5 text-xs text-rose-600 dark:text-rose-400 font-medium mb-2 bg-rose-50 dark:bg-rose-950/30 px-3 py-1.5 rounded-lg">
                  <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* NPCI Trust Notice */}
              <div className="flex items-center gap-1.5 text-[10px] text-slate-500 dark:text-slate-400 mb-4 text-center">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                <span>UPI PIN will keep your account safe from unauthorized transactions.</span>
              </div>

              {/* Numeric Keypad */}
              <div className="w-full grid grid-cols-3 gap-2 mt-1">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => handleKeyPress(num.toString())}
                    className="py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-95 rounded-xl font-bold text-base text-slate-800 dark:text-slate-100 transition shadow-xs cursor-pointer"
                  >
                    {num}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={handleClear}
                  className="py-3 bg-slate-100 dark:bg-slate-800 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/40 text-slate-600 rounded-xl font-bold text-xs transition cursor-pointer"
                >
                  CLEAR
                </button>
                <button
                  type="button"
                  onClick={() => handleKeyPress('0')}
                  className="py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-95 rounded-xl font-bold text-base text-slate-800 dark:text-slate-100 transition shadow-xs cursor-pointer"
                >
                  0
                </button>
                <button
                  type="button"
                  onClick={handleBackspace}
                  className="py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 rounded-xl font-bold text-xs flex items-center justify-center transition cursor-pointer"
                >
                  ⌫
                </button>
              </div>

              {/* Action Buttons */}
              <div className="w-full mt-4 flex gap-2">
                <button
                  type="button"
                  onClick={closeUPIPinModal}
                  className="flex-1 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  id="confirm-upi-pin-btn"
                  onClick={handleConfirmPin}
                  disabled={pin.length < 4 || isVerifying}
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Submit PIN</span>
                </button>
              </div>

              <div className="mt-3 text-center">
                <button
                  type="button"
                  onClick={() => showToast('🔒 Demo PIN: Enter 123456 (or any 4-6 digit number) to authorize.')}
                  className="text-[10px] text-sky-600 hover:underline font-semibold"
                >
                  Forgot UPI PIN? / Demo Hint
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
