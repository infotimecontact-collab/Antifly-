import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShieldAlert,
  UserX,
  Store,
  X,
  Search,
  Check,
  Ban,
  UserCheck,
  Info,
  SlidersHorizontal,
  Sparkles,
  ExternalLink,
  Plus,
} from 'lucide-react';

export const BlockedAccountsModal: React.FC = () => {
  const {
    isBlockedAccountsModalOpen,
    setIsBlockedAccountsModalOpen,
    blockRecords,
    unblockEntity,
    toggleBlockUser,
    toggleBlockSeller,
    sellers,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'users' | 'sellers'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [quickSearchQuery, setQuickSearchQuery] = useState('');
  const [showQuickBlockDropdown, setShowQuickBlockDropdown] = useState(false);

  if (!isBlockedAccountsModalOpen) return null;

  // Mock list of discoverable creators for quick blocking test
  const demoDiscoverableCreators = [
    {
      id: 'creator-priya',
      name: 'Priya Sharma',
      handle: '@priya_handlooms',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      role: 'Fashion Influencer',
    },
    {
      id: 'creator-rohit',
      name: 'Rohit Varma',
      handle: '@rohit_ethnic',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      role: 'Style Curator',
    },
    {
      id: 'creator-sneha',
      name: 'Sneha Kapoor',
      handle: '@sneha_drapes',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150',
      role: 'Saree Reviewer',
    },
    {
      id: 'creator-vikram',
      name: 'Vikram Mehta',
      handle: '@vikram_linen',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
      role: 'Textile Enthusiast',
    },
  ];

  const filteredRecords = blockRecords.filter((record) => {
    // Tab filter
    if (activeTab === 'users' && record.blockedType !== 'user') return false;
    if (activeTab === 'sellers' && record.blockedType !== 'seller') return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = record.blockedName.toLowerCase().includes(q);
      const matchHandle = record.blockedHandle?.toLowerCase().includes(q);
      const matchReason = record.reason?.toLowerCase().includes(q);
      return matchName || matchHandle || matchReason;
    }

    return true;
  });

  const totalBlockedCount = blockRecords.length;
  const userBlockedCount = blockRecords.filter((r) => r.blockedType === 'user').length;
  const sellerBlockedCount = blockRecords.filter((r) => r.blockedType === 'seller').length;

  const handleUnblock = (id: string, name: string) => {
    unblockEntity(id);
  };

  const handleQuickBlockSeller = (sellerId: string, storeName: string, avatar: string) => {
    toggleBlockSeller(sellerId, 'Blocked via Blocked Accounts Manager', storeName, avatar);
    setQuickSearchQuery('');
    setShowQuickBlockDropdown(false);
  };

  const handleQuickBlockCreator = (creator: typeof demoDiscoverableCreators[0]) => {
    toggleBlockUser(creator.id, creator.name, creator.avatar, creator.handle, 'Blocked via Blocked Accounts Manager');
    setQuickSearchQuery('');
    setShowQuickBlockDropdown(false);
  };

  return (
    <div
      id="blocked-accounts-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-white/80 backdrop-blur-md p-4 animate-in fade-in duration-200"
    >
      <div
        className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-rose-600 via-rose-500 to-amber-600 p-5 text-white flex items-center justify-between shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white border border-white/30">
              <Ban className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-full">
                  Instagram Privacy Standard
                </span>
              </div>
              <h2 className="text-lg font-black leading-tight mt-0.5">
                Blocked Accounts ({totalBlockedCount})
              </h2>
            </div>
          </div>

          <button
            onClick={() => setIsBlockedAccountsModalOpen(false)}
            className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Subheader Banner */}
        <div className="bg-slate-50 dark:bg-slate-800/60 px-5 py-3 border-b border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 flex items-start gap-2.5">
          <Info className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            Blocked accounts cannot message you, see your community lookbooks, or view your reviews. Their products and posts are removed from your feeds.
          </p>
        </div>

        {/* Tabs & Search */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 space-y-3">
          {/* Tabs */}
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl gap-1">
            <button
              onClick={() => setActiveTab('all')}
              className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition cursor-pointer ${
                activeTab === 'all'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              All ({totalBlockedCount})
            </button>
            <button
              onClick={() => setActiveTab('users')}
              className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition cursor-pointer ${
                activeTab === 'users'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Users & Creators ({userBlockedCount})
            </button>
            <button
              onClick={() => setActiveTab('sellers')}
              className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition cursor-pointer ${
                activeTab === 'sellers'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Sellers & Stores ({sellerBlockedCount})
            </button>
          </div>

          {/* Search Filter */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search blocked accounts or reasons..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-rose-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Content List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filteredRecords.length === 0 ? (
            <div className="py-12 flex flex-col items-center justify-center text-center px-4">
              <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 mb-3">
                <UserCheck className="w-8 h-8 text-emerald-500" />
              </div>
              <h3 className="text-sm font-bold text-slate-800 dark:text-white">
                {searchQuery ? 'No matching blocked accounts' : 'No Blocked Accounts in this Tab'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mt-1">
                {searchQuery
                  ? 'Try searching by a different name or handle.'
                  : 'When you block a user, creator, or store from their profile, comments, or chat, they will appear here.'}
              </p>
            </div>
          ) : (
            filteredRecords.map((record) => (
              <div
                key={record.id}
                className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3 hover:border-rose-300 dark:hover:border-rose-800 transition"
              >
                {/* Account info */}
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative shrink-0">
                    <img
                      src={
                        record.blockedAvatar ||
                        'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'
                      }
                      alt={record.blockedName}
                      className="w-11 h-11 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                    />
                    <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center text-[10px] shadow-xs">
                      {record.blockedType === 'seller' ? (
                        <Store className="w-2.5 h-2.5" />
                      ) : (
                        <UserX className="w-2.5 h-2.5" />
                      )}
                    </div>
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {record.blockedName}
                      </h4>
                      <span className="text-[10px] font-semibold px-1.5 py-0.2 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 shrink-0">
                        {record.blockedRole || (record.blockedType === 'seller' ? 'Store' : 'User')}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      {record.blockedHandle || `@${record.blockedName.toLowerCase().replace(/\s+/g, '_')}`}
                    </p>

                    {record.reason && (
                      <p className="text-[10px] text-rose-600 dark:text-rose-400 mt-0.5 truncate flex items-center gap-1 font-medium">
                        <Ban className="w-2.5 h-2.5 shrink-0" />
                        <span>{record.reason}</span>
                      </p>
                    )}
                  </div>
                </div>

                {/* Unblock Action */}
                <button
                  onClick={() => handleUnblock(record.blockedId, record.blockedName)}
                  className="px-3.5 py-1.5 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 hover:border-emerald-500 hover:text-emerald-600 dark:hover:text-emerald-400 text-xs font-bold text-slate-800 dark:text-white rounded-xl transition shadow-2xs cursor-pointer shrink-0"
                >
                  Unblock
                </button>
              </div>
            ))
          )}

          {/* Quick Block Simulation Section (To test blocking easily) */}
          <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Test Block / Search Accounts</span>
              </span>
              <span className="text-[10px] text-slate-400">Interactive Sandbox</span>
            </div>

            <div className="space-y-2">
              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
                Select any seller or creator to test blocking them and observe how their products and posts are instantly excluded:
              </p>

              {/* Quick Seller Buttons */}
              <div className="flex flex-wrap gap-1.5">
                {sellers.slice(0, 4).map((seller) => {
                  const isBlocked = blockRecords.some((r) => r.blockedId === seller.id);
                  return (
                    <button
                      key={seller.id}
                      onClick={() => {
                        if (isBlocked) {
                          unblockEntity(seller.id);
                        } else {
                          handleQuickBlockSeller(seller.id, seller.storeName, seller.storeAvatar || seller.logo);
                        }
                      }}
                      className={`text-[11px] font-bold px-2.5 py-1 rounded-lg border transition flex items-center gap-1 cursor-pointer ${
                        isBlocked
                          ? 'bg-rose-50 dark:bg-rose-950/50 border-rose-300 text-rose-700 dark:text-rose-300'
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-slate-400'
                      }`}
                    >
                      <Store className="w-3 h-3" />
                      <span>{seller.storeName}</span>
                      <span className="text-[9px] opacity-75">({isBlocked ? 'Blocked' : 'Block'})</span>
                    </button>
                  );
                })}
              </div>

              {/* Quick Creator Buttons */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {demoDiscoverableCreators.map((creator) => {
                  const isBlocked = blockRecords.some((r) => r.blockedId === creator.id);
                  return (
                    <button
                      key={creator.id}
                      onClick={() => {
                        if (isBlocked) {
                          unblockEntity(creator.id);
                        } else {
                          handleQuickBlockCreator(creator);
                        }
                      }}
                      className={`text-[11px] font-bold px-2.5 py-1 rounded-lg border transition flex items-center gap-1 cursor-pointer ${
                        isBlocked
                          ? 'bg-rose-50 dark:bg-rose-950/50 border-rose-300 text-rose-700 dark:text-rose-300'
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-slate-400'
                      }`}
                    >
                      <UserX className="w-3 h-3" />
                      <span>{creator.name}</span>
                      <span className="text-[9px] opacity-75">({isBlocked ? 'Blocked' : 'Block'})</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <span className="text-[11px] text-slate-500 dark:text-slate-400">
            Changes take effect across your feed immediately.
          </span>
          <button
            onClick={() => setIsBlockedAccountsModalOpen(false)}
            className="px-4 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold text-xs rounded-xl shadow-xs hover:opacity-90 transition cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
