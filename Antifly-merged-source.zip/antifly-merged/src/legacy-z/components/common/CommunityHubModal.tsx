import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  Film,
  Image as ImageIcon,
  Heart,
  MessageCircle,
  Share2,
  Send,
  Sparkles,
  PlusCircle,
  Play,
  ShoppingBag,
  X,
  Compass,
  CheckCircle2,
  Flame,
  ArrowRight,
  Upload,
  MoreVertical,
  Ban,
  UserX,
} from 'lucide-react';
import { CommunityPostItem } from '../../types';

export const CommunityHubModal: React.FC = () => {
  const {
    isCommunityHubOpen,
    setIsCommunityHubOpen,
    communityPosts,
    likeCommunityPost,
    addCommunityComment,
    createCommunityPost,
    shareCommunityPostToChat,
    currentUserSession,
    products,
    formatPrice,
    showToast,
    addToCart,
    isUserBlocked,
    isSellerBlocked,
    openBlockConfirmationModal,
    setIsBlockedAccountsModalOpen,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'reels' | 'images' | 'create'>('reels');
  const [commentInput, setCommentInput] = useState<{ [postId: string]: string }>({});
  const [activeMenuPostId, setActiveMenuPostId] = useState<string | null>(null);
  const [selectedReel, setSelectedReel] = useState<CommunityPostItem | null>(null);

  // New Post Form State
  const [newCaption, setNewCaption] = useState('');
  const [newMediaType, setNewMediaType] = useState<'reel_15s' | 'image'>('reel_15s');
  const [newMediaUrl, setNewMediaUrl] = useState('');
  const [newTags, setNewTags] = useState('#AntiflyStyle #15sReel');

  if (!isCommunityHubOpen) return null;

  // Filter out posts authored by blocked users or blocked sellers
  const visiblePosts = communityPosts.filter(
    (p) => !isUserBlocked(p.authorId) && !isUserBlocked(p.authorHandle) && !isSellerBlocked(p.authorId)
  );

  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCaption.trim()) {
      showToast('Please add a caption for your reel / post');
      return;
    }

    const defaultImg =
      newMediaType === 'reel_15s'
        ? 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=600'
        : 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=600';

    createCommunityPost({
      caption: newCaption,
      mediaType: newMediaType,
      mediaUrl: newMediaUrl.trim() || defaultImg,
      tags: newTags.split(' ').filter(Boolean),
    });

    setNewCaption('');
    setNewMediaUrl('');
    setActiveTab('reels');
  };

  const handleAddComment = (postId: string) => {
    const text = commentInput[postId] || '';
    if (!text.trim()) return;
    addCommunityComment(postId, text);
    setCommentInput((prev) => ({ ...prev, [postId]: '' }));
  };

  return (
    <div
      id="community-hub-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-100/65 backdrop-blur-md p-2 sm:p-4 overflow-y-auto"
    >
      <div className="bg-white w-full max-w-5xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-slate-100 animate-in fade-in zoom-in-95">
        {/* TOP BAR */}
        <div className="bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 p-4 sm:p-5 text-white flex items-center justify-between shadow-md">
          <div className="flex items-center space-x-3">
            <div className="w-11 h-11 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 shadow-inner">
              <Users className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-bold tracking-tight">Antifly Creators & Shoppers Community</h2>
                <span className="bg-white/25 text-white text-[11px] px-2 py-0.5 rounded-full font-semibold">
                  Live Hub
                </span>
              </div>
              <p className="text-xs text-rose-100 mt-0.5">
                Share 15s short video reels, lookbooks, chat directly, and shop master artisan pieces
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsBlockedAccountsModalOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold transition flex items-center gap-1.5 border border-white/20 cursor-pointer"
              title="Manage Blocked Creators & Stores"
            >
              <Ban className="w-3.5 h-3.5 text-rose-200" />
              <span className="hidden sm:inline">Blocked Accounts</span>
            </button>

            <button
              id="btn-close-community"
              onClick={() => setIsCommunityHubOpen(false)}
              className="w-9 h-9 rounded-full bg-slate-100/20 hover:bg-slate-100/40 text-white flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* NAVIGATION TABS */}
        <div className="bg-slate-50 border-b border-slate-200 px-4 sm:px-6 py-2.5 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setActiveTab('reels')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'reels'
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
              }`}
            >
              <Film className="w-4 h-4" />
              <span>15s Video Reels ({visiblePosts.filter((p) => p.mediaType === 'reel_15s').length})</span>
            </button>

            <button
              onClick={() => setActiveTab('images')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'images'
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
              }`}
            >
              <ImageIcon className="w-4 h-4" />
              <span>Image Lookbooks ({visiblePosts.filter((p) => p.mediaType === 'image').length})</span>
            </button>
          </div>

          <button
            id="btn-tab-create-post"
            onClick={() => setActiveTab('create')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 ${
              activeTab === 'create'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
            }`}
          >
            <PlusCircle className="w-4 h-4" />
            <span>Post Reel / Image</span>
          </button>
        </div>

        {/* BODY CONTENT */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-50/50">
          {/* TAB 1: REELS & TAB 2: IMAGES GRID */}
          {activeTab !== 'create' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {visiblePosts
                .filter((p) => (activeTab === 'reels' ? p.mediaType === 'reel_15s' : p.mediaType === 'image'))
                .map((post) => {
                  const taggedProd = products.find((prod) => post.taggedProductIds?.includes(prod.id)) || products[0];
                  const visibleComments = post.comments.filter(
                    (c) => !isUserBlocked(c.authorId) && !isUserBlocked(c.authorName)
                  );
                  return (
                    <div
                      key={post.id}
                      id={`community-post-${post.id}`}
                      className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col relative"
                    >
                      {/* Author Header */}
                      <div className="p-3 flex items-center justify-between border-b border-slate-100">
                        <div className="flex items-center space-x-2.5">
                          <img
                            src={post.authorAvatar}
                            alt={post.authorName}
                            className="w-9 h-9 rounded-full object-cover border border-slate-200"
                          />
                          <div>
                            <div className="flex items-center gap-1">
                              <h4 className="font-bold text-xs text-slate-900 leading-tight">
                                {post.authorName}
                              </h4>
                              {post.isVerified && (
                                <CheckCircle2 className="w-3 h-3 text-blue-500 fill-current" />
                              )}
                            </div>
                            <p className="text-[10px] text-slate-400">
                              {post.authorHandle} • {post.createdAt}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-1">
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-medium capitalize">
                            {post.authorRole}
                          </span>

                          <div className="relative">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setActiveMenuPostId(activeMenuPostId === post.id ? null : post.id);
                              }}
                              className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition cursor-pointer"
                              title="Options"
                            >
                              <MoreVertical className="w-4 h-4" />
                            </button>

                            {/* 3-dots popup */}
                            {activeMenuPostId === post.id && (
                              <div
                                onClick={(e) => e.stopPropagation()}
                                className="absolute right-0 top-7 z-20 w-44 bg-white rounded-xl shadow-xl border border-slate-200 p-1 space-y-0.5 animate-in fade-in zoom-in-95"
                              >
                                <button
                                  onClick={() => {
                                    setActiveMenuPostId(null);
                                    openBlockConfirmationModal(
                                      'user',
                                      post.authorId,
                                      post.authorName,
                                      post.authorAvatar,
                                      post.authorHandle
                                    );
                                  }}
                                  className="w-full text-left px-2.5 py-1.5 text-xs text-rose-600 hover:bg-rose-50 rounded-lg flex items-center gap-2 font-medium cursor-pointer"
                                >
                                  <Ban className="w-3.5 h-3.5" />
                                  <span>Block {post.authorHandle}</span>
                                </button>
                                <button
                                  onClick={() => {
                                    setActiveMenuPostId(null);
                                    shareCommunityPostToChat(post);
                                  }}
                                  className="w-full text-left px-2.5 py-1.5 text-xs text-slate-700 hover:bg-slate-100 rounded-lg flex items-center gap-2 cursor-pointer"
                                >
                                  <Share2 className="w-3.5 h-3.5" />
                                  <span>Share to Chat</span>
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Media Card (15s Reel or Photo) */}
                      <div className="relative aspect-[4/5] bg-slate-100 overflow-hidden group">
                        <img
                          src={post.mediaUrl}
                          alt={post.caption}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />

                        {post.mediaType === 'reel_15s' && (
                          <div className="absolute inset-0 bg-gradient-to-t from-slate-100/70 via-transparent to-slate-100/20 flex flex-col justify-between p-3">
                            <div className="flex items-center justify-between">
                              <span className="bg-red-600/90 text-white text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 shadow">
                                <Flame className="w-3 h-3" /> 15s Reel
                              </span>
                              <span className="text-white/80 text-[10px] font-mono bg-slate-100/40 px-1.5 py-0.5 rounded">
                                0:15
                              </span>
                            </div>

                            <button
                              onClick={() => setSelectedReel(post)}
                              className="self-center w-14 h-14 rounded-full bg-white/30 backdrop-blur-md text-white flex items-center justify-center border-2 border-white shadow-xl hover:scale-110 transition-transform"
                            >
                              <Play className="w-7 h-7 fill-current ml-1" />
                            </button>

                            <div className="text-white text-xs">
                              <p className="line-clamp-2 font-medium drop-shadow">{post.caption}</p>
                              <div className="flex flex-wrap gap-1 mt-1">
                                {post.tags.map((t) => (
                                  <span key={t} className="text-[10px] text-rose-300 font-semibold">
                                    {t}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Tagged Product Box */}
                      {taggedProd && (
                        <div className="p-2.5 bg-rose-50/60 border-y border-rose-100 flex items-center justify-between">
                          <div className="flex items-center space-x-2 min-w-0">
                            <img
                              src={taggedProd.images[0]}
                              alt={taggedProd.name}
                              className="w-9 h-9 rounded-lg object-cover border border-rose-200 flex-shrink-0"
                            />
                            <div className="min-w-0">
                              <p className="text-[11px] font-semibold text-slate-800 truncate">
                                {taggedProd.name}
                              </p>
                              <p className="text-xs font-bold text-rose-700">
                                {formatPrice(taggedProd.price)}
                              </p>
                            </div>
                          </div>
                          <button
                            onClick={() => {
                              addToCart({
                                productId: taggedProd.id,
                                name: taggedProd.name,
                                price: taggedProd.price,
                                image: taggedProd.images[0],
                                quantity: 1,
                                size: 'Standard',
                                color: 'Silk',
                                brand: taggedProd.brand,
                              });
                            }}
                            className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-[10px] font-bold shadow-sm whitespace-nowrap"
                          >
                            Buy Look
                          </button>
                        </div>
                      )}

                      {/* Engagement Bar & WhatsApp Share */}
                      <div className="p-3 border-t border-slate-100 flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <button
                            onClick={() => likeCommunityPost(post.id)}
                            className={`flex items-center space-x-1 text-xs font-semibold ${
                              post.isLikedByMe ? 'text-red-600' : 'text-slate-600 hover:text-red-600'
                            }`}
                          >
                            <Heart className={`w-4 h-4 ${post.isLikedByMe ? 'fill-current' : ''}`} />
                            <span>{post.likesCount}</span>
                          </button>

                          <div className="flex items-center space-x-1 text-xs text-slate-600 font-semibold">
                            <MessageCircle className="w-4 h-4 text-slate-400" />
                            <span>{visibleComments.length}</span>
                          </div>
                        </div>

                        {/* WhatsApp Share Button */}
                        <button
                          onClick={() => shareCommunityPostToChat(post)}
                          className="flex items-center space-x-1 px-3 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 rounded-lg text-xs font-bold transition-colors cursor-pointer"
                        >
                          <Share2 className="w-3.5 h-3.5" />
                          <span>Share to Chat</span>
                        </button>
                      </div>

                      {/* Comments List & Add Comment */}
                      <div className="p-3 bg-slate-50/70 border-t border-slate-100 flex-1 flex flex-col justify-end">
                        {visibleComments.length > 0 && (
                          <div className="space-y-1.5 mb-2.5 max-h-24 overflow-y-auto text-xs">
                            {visibleComments.slice(0, 2).map((comm) => (
                              <div
                                key={comm.id}
                                className="bg-white p-1.5 px-2 rounded-lg border border-slate-100 flex items-center justify-between group"
                              >
                                <div>
                                  <span className="font-semibold text-slate-900 mr-1.5">{comm.authorName}:</span>
                                  <span className="text-slate-600">{comm.text}</span>
                                </div>
                                <button
                                  onClick={() =>
                                    openBlockConfirmationModal(
                                      'user',
                                      comm.authorId || `user-${comm.authorName.toLowerCase().replace(/\s+/g, '_')}`,
                                      comm.authorName,
                                      undefined,
                                      `@${comm.authorName.toLowerCase().replace(/\s+/g, '_')}`
                                    )
                                  }
                                  className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-rose-600 transition p-0.5 cursor-pointer"
                                  title={`Block ${comm.authorName}`}
                                >
                                  <Ban className="w-3 h-3" />
                                </button>
                              </div>
                            ))}
                          </div>
                        )}

                        <div className="flex items-center space-x-1.5">
                          <input
                            type="text"
                            placeholder="Add a comment to this reel..."
                            value={commentInput[post.id] || ''}
                            onChange={(e) =>
                              setCommentInput((prev) => ({ ...prev, [post.id]: e.target.value }))
                            }
                            onKeyDown={(e) => e.key === 'Enter' && handleAddComment(post.id)}
                            className="flex-1 text-xs bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 focus:ring-1 focus:ring-rose-500 focus:outline-hidden"
                          />
                          <button
                            onClick={() => handleAddComment(post.id)}
                            className="p-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg cursor-pointer"
                          >
                            <Send className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          )}

          {/* TAB 3: CREATE POST / REEL */}
          {activeTab === 'create' && (
            <div className="max-w-2xl mx-auto bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
              <div className="flex items-center space-x-3 pb-4 border-b border-slate-100 mb-6">
                <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center">
                  <Upload className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">Post to Antifly Community</h3>
                  <p className="text-xs text-slate-500">
                    Publish your 15s style reel or high-res outfit look to our millions of community members
                  </p>
                </div>
              </div>

              <form onSubmit={handlePostSubmit} className="space-y-4">
                {/* Media Type Selection */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">Content Format</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setNewMediaType('reel_15s')}
                      className={`p-3 rounded-xl border flex items-center space-x-3 ${
                        newMediaType === 'reel_15s'
                          ? 'border-red-600 bg-red-50/50 text-red-700 font-bold'
                          : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <Film className="w-5 h-5" />
                      <div className="text-left">
                        <p className="text-xs">15-Second Video Reel</p>
                        <p className="text-[10px] text-slate-400 font-normal">HD short fabric review</p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setNewMediaType('image')}
                      className={`p-3 rounded-xl border flex items-center space-x-3 ${
                        newMediaType === 'image'
                          ? 'border-red-600 bg-red-50/50 text-red-700 font-bold'
                          : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <ImageIcon className="w-5 h-5" />
                      <div className="text-left">
                        <p className="text-xs">Photo Lookbook</p>
                        <p className="text-[10px] text-slate-400 font-normal">Single high-res fit</p>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Caption */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">Caption & Story</label>
                  <textarea
                    rows={3}
                    placeholder="Describe your outfit, master weaver craftsmanship, styling tips..."
                    value={newCaption}
                    onChange={(e) => setNewCaption(e.target.value)}
                    className="w-full text-xs text-slate-800 border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-rose-500 focus:outline-none"
                    required
                  />
                </div>

                {/* Media URL / Upload Simulation */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Media URL / Camera Upload
                  </label>
                  <input
                    type="url"
                    placeholder="https://images.unsplash.com/... or leave blank for curated template"
                    value={newMediaUrl}
                    onChange={(e) => setNewMediaUrl(e.target.value)}
                    className="w-full text-xs text-slate-800 border border-slate-300 rounded-xl p-2.5 focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  />
                </div>

                {/* Tags */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">Hashtags</label>
                  <input
                    type="text"
                    value={newTags}
                    onChange={(e) => setNewTags(e.target.value)}
                    className="w-full text-xs text-slate-800 border border-slate-300 rounded-xl p-2.5 focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  />
                </div>

                {/* Submit button */}
                <div className="pt-3">
                  <button
                    type="submit"
                    className="w-full py-3 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white rounded-xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Publish Reel to Community Hub</span>
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
