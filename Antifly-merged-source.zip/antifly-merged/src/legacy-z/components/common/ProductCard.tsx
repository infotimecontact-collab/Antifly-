import React, { useState } from 'react';
import { Product, NotInterestedReason } from '../../types';
import { useApp } from '../../context/AppContext';
import {
  Heart,
  Star,
  ShoppingBag,
  Sparkles,
  Scale,
  Eye,
  Check,
  MessageCircle,
  Share2,
  Bookmark,
  Store,
  ThumbsDown,
  ThumbsUp,
  MoreVertical,
  Undo2,
  SlidersHorizontal,
  Info,
  Bell,
  Zap,
} from 'lucide-react';

interface ProductCardProps {
  product: Product;
  badge?: string;
  isCompact?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, badge, isCompact = false }) => {
  const {
    wishlist,
    toggleWishlist,
    addToCart,
    setActivePdpId,
    addToComparison,
    comparisonList,
    toggleLikeProduct,
    isProductLiked,
    getProductLikeCount,
    toggleSaveProductSocial,
    isProductSavedSocial,
    setActiveCommentsProductId,
    setIsProductCommentsOpen,
    setActiveShareProduct,
    setIsProductShareOpen,
    openSellerStorefront,
    sellers,
    markProductInterested,
    markProductNotInterested,
    undoNotInterested,
    isProductInterested,
    isProductNotInterested,
    isProductSellerBlocked,
    openBlockConfirmationModal,
    setIsInterestManagerOpen,
    setIsBlockedAccountsModalOpen,
    showToast,
    quickSaveProductWithSmartFlow,
    openStockAlertModal,
    isSubscribedToStockAlert,
  } = useApp();

  const isWishlisted = wishlist.includes(product.id);
  const isCompared = comparisonList.some((p) => p.id === product.id);
  const isLiked = isProductLiked(product.id);
  const isInterested = isProductInterested(product.id);
  const isHidden = isProductNotInterested(product.id);
  const isSellerBlockedFlag = isProductSellerBlocked(product);
  const likeCount = getProductLikeCount(product.id);
  const isSaved = isProductSavedSocial(product.id);

  const isOutOfStock = (product.totalStock ?? product.stock ?? 0) <= 0;
  const isStockAlertSubscribed = isSubscribedToStockAlert(product.id);

  const matchedSeller = sellers.find(
    (s) =>
      s.storeName.toLowerCase() === product.brand.toLowerCase() ||
      product.tags.includes(s.storeName) ||
      product.brand.toLowerCase().includes(s.storeName.toLowerCase())
  ) || sellers[0];

  const [selectedVariant, setSelectedVariant] = useState(product.variants[0] || null);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const [showHeartPop, setShowHeartPop] = useState(false);
  const [showNotInterestedMenu, setShowNotInterestedMenu] = useState(false);
  const [lastTapTime, setLastTapTime] = useState(0);

  // Instagram-style double tap to like on image
  const handleImageDoubleTap = (e: React.MouseEvent) => {
    e.stopPropagation();
    const now = Date.now();
    if (now - lastTapTime < 300) {
      // Double tap detected!
      setShowHeartPop(true);
      markProductInterested(product.id);
      setTimeout(() => setShowHeartPop(false), 900);
    }
    setLastTapTime(now);
  };

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart({
      productId: product.id,
      variantId: selectedVariant?.id || 'default',
      productName: product.name,
      brand: product.brand,
      color: selectedVariant?.color || product.colors[0]?.name || 'Standard',
      size: selectedVariant?.size || product.sizes[0] || 'Standard',
      price: product.price,
      mrp: product.mrp,
      image: product.images[0],
      quantity: 1,
      stock: product.totalStock,
    });
  };

  const handleWishlistClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id);
  };

  const handleCompareClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToComparison(product);
  };

  const handleLikeClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isLiked) {
      markProductInterested(product.id);
    } else {
      toggleLikeProduct(product.id);
    }
  };

  const handleCommentClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveCommentsProductId(product.id);
    setIsProductCommentsOpen(true);
  };

  const handleShareClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveShareProduct(product);
    setIsProductShareOpen(true);
  };

  const handleSaveClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    quickSaveProductWithSmartFlow(product.id, e);
  };

  const handleSellerClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (matchedSeller) openSellerStorefront(matchedSeller.id);
  };

  const handleNotInterestedSelection = (
    e: React.MouseEvent,
    reason: NotInterestedReason,
    reasonText: string
  ) => {
    e.stopPropagation();
    setShowNotInterestedMenu(false);
    markProductNotInterested(product.id, reason, reasonText);
  };

  // If seller is blocked, hide product from feed
  if (isSellerBlockedFlag) {
    return null;
  }

  // If item was marked Not-Interested, render Flipkart/Amazon style Inline Suppressed Card with 1-click Undo
  if (isHidden) {
    return (
      <div
        id={`product-card-hidden-${product.id}`}
        className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-4 border border-dashed border-slate-300 dark:border-slate-700 flex flex-col items-center justify-center text-center gap-2.5 min-h-[280px] transition-all"
      >
        <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-500">
          <ThumbsDown className="w-4 h-4" />
        </div>
        <div>
          <p className="text-xs font-bold text-slate-700 dark:text-slate-200">
            Hidden from Recommendations
          </p>
          <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">{product.name}</p>
        </div>

        <button
          onClick={(e) => {
            e.stopPropagation();
            undoNotInterested(product.id);
          }}
          className="px-3 py-1.5 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg text-xs font-bold text-slate-800 dark:text-white hover:bg-slate-100 dark:hover:bg-slate-600 flex items-center gap-1.5 transition cursor-pointer shadow-2xs"
        >
          <Undo2 className="w-3.5 h-3.5 text-emerald-600" />
          <span>Undo</span>
        </button>

        <button
          onClick={(e) => {
            e.stopPropagation();
            setIsInterestManagerOpen(true);
          }}
          className="text-[10px] text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
        >
          <SlidersHorizontal className="w-2.5 h-2.5" />
          <span>Tune Preferences</span>
        </button>
      </div>
    );
  }

  return (
    <div
      id={`product-card-${product.id}`}
      onClick={() => setActivePdpId(product.id)}
      onMouseEnter={() => {
        setIsHovered(true);
        if (product.images.length > 1) setActiveImageIndex(1);
      }}
      onMouseLeave={() => {
        setIsHovered(false);
        setActiveImageIndex(0);
        setShowNotInterestedMenu(false);
      }}
      className="group relative bg-[#fdfcf9] rounded-2xl overflow-hidden border border-[#e8e2d8] hover:border-slate-400 hover:shadow-xl transition-all duration-300 flex flex-col cursor-pointer"
    >
      {/* Image container with 3D soft framing */}
      <div
        onClick={handleImageDoubleTap}
        className="relative aspect-[4/5] w-full bg-[#f2ede4] overflow-hidden select-none"
      >
        <img
          src={product.images[activeImageIndex] || product.images[0]}
          alt={product.name}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Instagram Heart Explosion on Double Tap */}
        {showHeartPop && (
          <div className="absolute inset-0 flex items-center justify-center z-30 pointer-events-none animate-ping">
            <Heart className="w-20 h-20 fill-rose-500 text-rose-500 drop-shadow-2xl opacity-90" />
          </div>
        )}

        {/* Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5 z-10">
          {isOutOfStock && (
            <span className="bg-rose-600/95 backdrop-blur-md text-white text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded shadow-md border border-white/20 flex items-center gap-1">
              <Bell className="w-2.5 h-2.5 fill-white" /> Sold Out
            </span>
          )}
          {isInterested && !isOutOfStock && (
            <span className="bg-gradient-to-r from-rose-500 to-amber-500 text-white text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded shadow-md flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5" /> For You
            </span>
          )}
          {badge && !isInterested && !isOutOfStock && (
            <span className="bg-white/80 backdrop-blur-md text-amber-300 text-[10px] font-semibold tracking-wider uppercase px-2 py-0.5 rounded shadow-sm">
              {badge}
            </span>
          )}
          {product.discountPercentage > 0 && !isOutOfStock && (
            <span className="bg-orange-600 text-white text-[11px] font-bold px-2 py-0.5 rounded shadow-sm">
              {product.discountPercentage}% OFF
            </span>
          )}
          {product.isNewArrival && !isOutOfStock && (
            <span className="bg-emerald-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-sm">
              NEW
            </span>
          )}
        </div>

        {/* Floating Coral-Glowing Heart Action & Quick Buttons (Image 5 & 7) */}
        <div className="absolute top-2.5 right-2.5 flex flex-col gap-1.5 z-10">
          {/* Glowing Wishlist Button */}
          <button
            id={`wishlist-btn-${product.id}`}
            onClick={handleWishlistClick}
            className={`p-2 rounded-full transition-all shadow-md cursor-pointer ${
              isWishlisted
                ? 'coral-glow-btn text-white scale-105'
                : 'bg-white/90 text-slate-700 hover:text-rose-500 hover:scale-110 shadow-xs'
            }`}
            title="Add to Wishlist"
          >
            <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-white text-white' : ''}`} />
          </button>

          {/* Compare Button */}
          <button
            id={`compare-btn-${product.id}`}
            onClick={handleCompareClick}
            className={`p-2 rounded-full backdrop-blur-md transition-all shadow-xs cursor-pointer ${
              isCompared
                ? 'bg-amber-100 text-amber-800'
                : 'bg-white/90 text-slate-700 hover:text-amber-500 hover:scale-110'
            }`}
            title="Compare with another product"
          >
            <Scale className="w-4 h-4" />
          </button>

          {/* Amazon / Flipkart / Instagram Style "Not Interested" Dropdown Trigger */}
          <button
            id={`not-interested-btn-${product.id}`}
            onClick={(e) => {
              e.stopPropagation();
              setShowNotInterestedMenu((prev) => !prev);
            }}
            className="p-2 rounded-full backdrop-blur-md bg-white/90 text-slate-700 hover:text-rose-600 hover:scale-110 transition shadow-xs cursor-pointer"
            title="Not Interested / Hide"
          >
            <MoreVertical className="w-4 h-4" />
          </button>
        </div>

        {/* Not Interested Reason Menu Popup */}
        {showNotInterestedMenu && (
          <div
            onClick={(e) => e.stopPropagation()}
            className="absolute top-12 right-2.5 z-40 w-52 bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 p-2 space-y-1 animate-fade-in"
          >
            <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 border-b border-slate-100 dark:border-slate-700/60 mb-1">
              Personalize Feed
            </div>

            <button
              onClick={(e) => handleNotInterestedSelection(e, 'not_relevant', 'Not relevant to my style')}
              className="w-full text-left px-2.5 py-1.5 text-xs text-slate-700 dark:text-slate-200 hover:bg-rose-50 dark:hover:bg-rose-950/50 hover:text-rose-600 rounded-xl flex items-center gap-2 transition cursor-pointer"
            >
              <ThumbsDown className="w-3.5 h-3.5 text-rose-500" />
              <span>Not interested in this</span>
            </button>

            <button
              onClick={(e) => handleNotInterestedSelection(e, 'dont_like_style', 'Don’t like this color or design')}
              className="w-full text-left px-2.5 py-1.5 text-xs text-slate-700 dark:text-slate-200 hover:bg-rose-50 dark:hover:bg-rose-950/50 hover:text-rose-600 rounded-xl flex items-center gap-2 transition cursor-pointer"
            >
              <ThumbsDown className="w-3.5 h-3.5 text-rose-500" />
              <span>Don't like this style</span>
            </button>

            <button
              onClick={(e) => handleNotInterestedSelection(e, 'price_too_high', 'Price too high for this item')}
              className="w-full text-left px-2.5 py-1.5 text-xs text-slate-700 dark:text-slate-200 hover:bg-rose-50 dark:hover:bg-rose-950/50 hover:text-rose-600 rounded-xl flex items-center gap-2 transition cursor-pointer"
            >
              <ThumbsDown className="w-3.5 h-3.5 text-rose-500" />
              <span>Price is too high</span>
            </button>

            <button
              onClick={(e) => handleNotInterestedSelection(e, 'already_bought', 'Already purchased this item')}
              className="w-full text-left px-2.5 py-1.5 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl flex items-center gap-2 transition cursor-pointer"
            >
              <Check className="w-3.5 h-3.5 text-emerald-500" />
              <span>Already bought this</span>
            </button>

            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowNotInterestedMenu(false);
                if (matchedSeller) {
                  openBlockConfirmationModal(
                    'seller',
                    matchedSeller.id,
                    matchedSeller.storeName,
                    matchedSeller.storeAvatar || matchedSeller.logo,
                    `@${matchedSeller.storeName.toLowerCase().replace(/\s+/g, '_')}`
                  );
                }
              }}
              className="w-full text-left px-2.5 py-1.5 text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/50 rounded-xl flex items-center gap-2 transition cursor-pointer font-medium"
            >
              <Store className="w-3.5 h-3.5 text-rose-500" />
              <span>Block {matchedSeller?.storeName || 'Seller'}</span>
            </button>

            <div className="pt-1 border-t border-slate-100 dark:border-slate-700/60 mt-1 space-y-1">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowNotInterestedMenu(false);
                  setIsInterestManagerOpen(true);
                }}
                className="w-full text-left px-2.5 py-1 text-[11px] font-bold text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1.5 cursor-pointer"
              >
                <SlidersHorizontal className="w-3 h-3" />
                <span>Open Interest Manager</span>
              </button>
            </div>
          </div>
        )}

        {/* Hover Quick View / Visual Search Overlay */}
        <div className="absolute bottom-2.5 inset-x-2.5 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex gap-1.5 z-10">
          {isOutOfStock ? (
            <button
              onClick={(e) => {
                e.stopPropagation();
                openStockAlertModal(product, selectedVariant?.id);
              }}
              className={`flex-1 text-xs font-semibold py-2 px-3 rounded-lg backdrop-blur-md transition-all flex items-center justify-center gap-1.5 shadow-md cursor-pointer ${
                isStockAlertSubscribed
                  ? 'bg-emerald-700/90 text-white hover:bg-emerald-600'
                  : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 font-bold'
              }`}
            >
              <Bell className="w-3.5 h-3.5 fill-current" />
              {isStockAlertSubscribed ? 'Alert Set' : 'Notify Me'}
            </button>
          ) : (
            <button
              onClick={handleQuickAdd}
              className="flex-1 bg-white/90 hover:bg-orange-600 text-white text-xs font-semibold py-2 px-3 rounded-lg backdrop-blur-md transition-all flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              Quick Add
            </button>
          )}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setActivePdpId(product.id);
            }}
            className="p-2 bg-white/90 dark:bg-slate-800/90 text-slate-800 dark:text-slate-200 hover:text-amber-500 rounded-lg backdrop-blur-md shadow-md cursor-pointer"
            title="View Details"
          >
            <Eye className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Instagram / Meesho Style Social Action Bar directly below image */}
      <div className="px-3 py-1.5 bg-slate-50/90 dark:bg-slate-800/60 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {/* Like / Interested Heart Icon & Count */}
          <button
            id={`product-card-like-${product.id}`}
            onClick={handleLikeClick}
            className={`flex items-center gap-1 text-xs transition-colors py-0.5 px-1.5 rounded cursor-pointer ${
              isLiked || isInterested
                ? 'text-rose-600 font-bold bg-rose-50 dark:bg-rose-950/40'
                : 'text-slate-600 dark:text-slate-400 hover:text-rose-500'
            }`}
            title={isLiked ? 'Interested / Liked' : 'Double tap or click to mark Interested'}
          >
            <Heart className={`w-3.5 h-3.5 ${isLiked || isInterested ? 'fill-rose-500 text-rose-500' : ''}`} />
            <span className="text-[11px]">{likeCount}</span>
          </button>

          {/* Comment Icon */}
          <button
            id={`product-card-comment-${product.id}`}
            onClick={handleCommentClick}
            className="text-slate-600 dark:text-slate-400 hover:text-orange-600 transition-colors p-1 cursor-pointer"
            title="Instagram Comments"
          >
            <MessageCircle className="w-3.5 h-3.5" />
          </button>

          {/* Share Icon */}
          <button
            id={`product-card-share-${product.id}`}
            onClick={handleShareClick}
            className="text-slate-600 dark:text-slate-400 hover:text-orange-600 transition-colors p-1 cursor-pointer"
            title="Share Product"
          >
            <Share2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Save to Portfolio Bookmark Icon */}
        <button
          id={`product-card-save-${product.id}`}
          onClick={handleSaveClick}
          className={`p-1 transition-colors cursor-pointer ${
            isSaved
              ? 'text-amber-500'
              : 'text-slate-400 dark:text-slate-500 hover:text-amber-500'
          }`}
          title={isSaved ? 'Saved in Portfolio' : 'Save to Portfolio'}
        >
          <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-amber-500 text-amber-500' : ''}`} />
        </button>
      </div>

      {/* Details Container */}
      <div className="p-3.5 flex-1 flex flex-col justify-between">
        <div>
          {/* Brand & Category */}
          <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 mb-1">
            <button
              onClick={handleSellerClick}
              className="font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-300 hover:text-orange-600 flex items-center gap-1 transition-colors truncate cursor-pointer"
              title="Visit Seller Storefront"
            >
              <Store className="w-3 h-3 text-amber-600 shrink-0" />
              <span className="truncate">{product.brand}</span>
            </button>
            <div className="flex items-center gap-1 bg-amber-50 dark:bg-amber-950/60 px-1.5 py-0.5 rounded text-amber-700 dark:text-amber-300 text-[10px] font-bold shrink-0">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
              <span>{product.rating}</span>
              <span className="text-slate-400">({product.reviewCount})</span>
            </div>
          </div>

          {/* Product Name */}
          <h3
            className={`font-semibold text-slate-800 dark:text-slate-100 line-clamp-1 group-hover:text-orange-600 dark:group-hover:text-amber-400 transition-colors ${
              isCompact ? 'text-xs' : 'text-sm'
            }`}
          >
            {product.name}
          </h3>

          {/* Color variant dots */}
          {product.colors && product.colors.length > 0 && (
            <div className="flex items-center gap-1.5 mt-2">
              {product.colors.slice(0, 4).map((c, i) => (
                <span
                  key={i}
                  className="w-2.5 h-2.5 rounded-full border border-slate-300 dark:border-slate-700 ring-1 ring-transparent hover:ring-slate-400 dark:hover:ring-slate-500 transition-all"
                  style={{ backgroundColor: c.hex }}
                  title={c.name}
                />
              ))}
              {product.colors.length > 4 && (
                <span className="text-[10px] text-slate-400 font-medium">
                  +{product.colors.length - 4}
                </span>
              )}
            </div>
          )}
        </div>

        {/* Pricing & Stock Footer */}
        <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
          <div className="flex items-baseline gap-1.5">
            <span className="text-base font-bold text-slate-900 dark:text-white">
              ₹{product.price.toLocaleString('en-IN')}
            </span>
            {product.mrp > product.price && (
              <span className="text-xs text-slate-400 line-through">
                ₹{product.mrp.toLocaleString('en-IN')}
              </span>
            )}
          </div>

          {/* Stock hint / Out-of-Stock Notify Me Button */}
          {isOutOfStock ? (
            <button
              id={`card-stock-alert-btn-${product.id}`}
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                openStockAlertModal(product, selectedVariant?.id);
              }}
              className={`px-2.5 py-1 rounded-full text-[11px] font-bold flex items-center gap-1 transition-all shadow-xs cursor-pointer ${
                isStockAlertSubscribed
                  ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-700/60 hover:bg-emerald-100'
                  : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 hover:shadow-md hover:scale-102'
              }`}
              title={
                isStockAlertSubscribed
                  ? 'Stock Alert Active - Click to Manage or Test'
                  : 'Out of Stock - Click to Get Web Push Alert on Restock'
              }
            >
              <Bell
                className={`w-3 h-3 ${
                  isStockAlertSubscribed
                    ? 'fill-emerald-500 text-emerald-500'
                    : 'fill-slate-950 text-slate-800'
                }`}
              />
              <span>{isStockAlertSubscribed ? 'Alert Set' : 'Notify Me'}</span>
            </button>
          ) : product.totalStock <= 20 ? (
            <span className="text-[10px] font-medium text-orange-600 dark:text-orange-400">
              Only {product.totalStock} left
            </span>
          ) : (
            <span className="text-[10px] font-medium text-emerald-600 dark:text-emerald-400 flex items-center gap-0.5">
              <Check className="w-2.5 h-2.5" /> In Stock
            </span>
          )}
        </div>
      </div>
    </div>
  );
};


