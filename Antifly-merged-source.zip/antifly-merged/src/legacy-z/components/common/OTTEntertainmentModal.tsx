import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Tv,
  X,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  Star,
  Clock,
  Sparkles,
  Flame,
  Film,
  Crown,
  ChevronRight,
  ShieldCheck,
  Radio,
} from 'lucide-react';
import { OTTShow, OTTPlatform } from '../../types';

export const OTTEntertainmentModal: React.FC = () => {
  const {
    isOTTModalOpen,
    setIsOTTModalOpen,
    ottPlatforms,
    ottShows,
    activeStreamingShow,
    setActiveStreamingShow,
    antiflyOneSubscription,
    setIsAntiflyOneModalOpen,
  } = useApp();

  const [activeCategory, setActiveCategory] = useState<'All' | 'Movie' | 'Web Series' | 'Live Sports'>('All');
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [videoResolution, setVideoResolution] = useState<string>('4K HDR');
  const [audioLanguage, setAudioLanguage] = useState<string>('Hindi [Original] 5.1');

  if (!isOTTModalOpen) return null;

  const currentShow = activeStreamingShow || ottShows[0];

  const filteredShows = ottShows.filter((show) => {
    if (activeCategory === 'All') return true;
    return show.type === activeCategory;
  });

  return (
    <div
      id="ott-entertainment-modal"
      className="fixed inset-0 z-50 bg-white/90 backdrop-blur-lg flex items-center justify-center p-2 sm:p-4 lg:p-6 animate-fade-in"
    >
      <div className="bg-slate-900 text-white w-full max-w-5xl rounded-3xl shadow-2xl border border-slate-800 overflow-hidden flex flex-col my-auto max-h-[94vh]">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-purple-900 via-pink-900 to-rose-950 p-5 text-white flex-shrink-0 flex items-center justify-between border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center text-white border border-white/20 shadow-inner flex-shrink-0">
              <Tv className="w-6 h-6 text-pink-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-pink-500 to-rose-500 text-white px-2 py-0.5 rounded-full">
                  🎬 AntiflyStream All-in-One OTT
                </span>
                {antiflyOneSubscription.isActive ? (
                  <span className="text-[10px] font-bold bg-amber-400 text-slate-800 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <Crown className="w-3 h-3 fill-slate-950" /> VIP Pass: 6 Apps Active
                  </span>
                ) : (
                  <button
                    onClick={() => setIsAntiflyOneModalOpen(true)}
                    className="text-[10px] font-bold bg-white/20 hover:bg-white/30 text-white px-2 py-0.5 rounded-full transition"
                  >
                    Unlock all with AntiflyOne &gt;
                  </button>
                )}
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white mt-0.5">
                Blockbuster Movies, Web Series & Live Cricket
              </h2>
            </div>
          </div>

          <button
            onClick={() => setIsOTTModalOpen(false)}
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Active OTT Platforms Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-6 gap-2">
            {ottPlatforms.map((platform) => (
              <div
                key={platform.id}
                className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/80 flex flex-col items-center justify-center text-center space-y-1"
              >
                <div
                  className={`w-10 h-10 rounded-xl ${platform.color} flex items-center justify-center font-black text-xs text-white shadow`}
                >
                  {platform.name.slice(0, 2).toUpperCase()}
                </div>
                <span className="text-xs font-bold text-slate-200">{platform.name}</span>
                <span className="text-[9px] text-emerald-400 font-semibold">● Active Pass</span>
              </div>
            ))}
          </div>

          {/* Video Player Simulator */}
          <div className="rounded-3xl overflow-hidden bg-slate-100 border border-slate-800 shadow-2xl relative">
            <div className="relative aspect-video max-h-[380px] w-full bg-white">
              <img
                src={currentShow.backdropUrl}
                alt={currentShow.title}
                className="w-full h-full object-cover opacity-75"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-100/40" />

              {/* Live Sports Overlay if Live Cricket */}
              {currentShow.isLive && (
                <div className="absolute top-4 left-4 flex items-center gap-2 bg-rose-600/90 text-white px-3 py-1 rounded-full text-xs font-black tracking-wider animate-pulse">
                  <Radio className="w-3.5 h-3.5" />
                  <span>LIVE 4K BROADCAST</span>
                </div>
              )}

              {/* Player Top Badges */}
              <div className="absolute top-4 right-4 flex items-center gap-2">
                <span className="bg-slate-100/60 backdrop-blur-md px-2.5 py-1 rounded-lg text-xs font-mono font-bold text-amber-400 border border-white/10">
                  {videoResolution}
                </span>
                <span className="bg-slate-100/60 backdrop-blur-md px-2.5 py-1 rounded-lg text-xs font-bold text-slate-300 border border-white/10">
                  {currentShow.platform}
                </span>
              </div>

              {/* Middle Play Button */}
              <div className="absolute inset-0 flex items-center justify-center">
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="w-16 h-16 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md text-white flex items-center justify-center border border-white/40 shadow-2xl transition cursor-pointer"
                >
                  {isPlaying ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8 fill-white ml-1" />}
                </button>
              </div>

              {/* Player Bottom Control Bar */}
              <div className="absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-slate-100 via-slate-100/80 to-transparent flex items-center justify-between text-xs">
                <div className="flex items-center gap-3">
                  <button onClick={() => setIsPlaying(!isPlaying)} className="hover:text-pink-400 cursor-pointer">
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
                  </button>
                  <button onClick={() => setIsMuted(!isMuted)} className="hover:text-pink-400 cursor-pointer">
                    {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                  <span className="font-mono text-slate-300">
                    {currentShow.isLive ? '🔴 LIVE OVER 18.2 (IND 194/3)' : '01:24:18 / 02:45:00'}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={audioLanguage}
                    onChange={(e) => setAudioLanguage(e.target.value)}
                    className="bg-slate-100/60 text-slate-200 rounded-lg px-2 py-1 text-[11px] border border-white/20 focus:outline-none"
                  >
                    <option>Hindi [Original] 5.1</option>
                    <option>English [Dolby Atmos]</option>
                    <option>Tamil [Dolby 5.1]</option>
                    <option>Telugu [Dolby 5.1]</option>
                  </select>

                  <select
                    value={videoResolution}
                    onChange={(e) => setVideoResolution(e.target.value)}
                    className="bg-slate-100/60 text-slate-200 rounded-lg px-2 py-1 text-[11px] border border-white/20 focus:outline-none"
                  >
                    <option>4K HDR</option>
                    <option>1080p FHD</option>
                    <option>720p HD</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Current Show Meta */}
            <div className="p-5 bg-slate-900 border-t border-slate-800 space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-xl font-black text-white">{currentShow.title}</h3>
                  <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
                    <span className="text-emerald-400 font-bold flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 fill-emerald-400" /> {currentShow.rating}
                    </span>
                    <span>• {currentShow.releaseYear}</span>
                    <span>• {currentShow.maturityRating}</span>
                    <span>• {currentShow.duration}</span>
                    <span>• {currentShow.genres.join(', ')}</span>
                  </div>
                </div>

                <span className="text-xs font-mono font-bold bg-pink-950 text-pink-300 border border-pink-800 px-3 py-1 rounded-xl">
                  {currentShow.type}
                </span>
              </div>

              <p className="text-xs text-slate-300 line-clamp-2">{currentShow.description}</p>
              <p className="text-[11px] text-slate-400">
                <span className="font-bold text-slate-300">Starring:</span> {currentShow.cast.join(', ')}
              </p>
            </div>
          </div>

          {/* Catalog Filter Tabs */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Film className="w-4 h-4 text-pink-400" />
                <h3 className="font-extrabold text-sm uppercase tracking-wider text-slate-300">
                  Trending Stream Queue
                </h3>
              </div>

              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                {(['All', 'Movie', 'Web Series', 'Live Sports'] as const).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition cursor-pointer ${
                      activeCategory === cat
                        ? 'bg-pink-600 text-white shadow'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Shows Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
              {filteredShows.map((show) => {
                const isSelected = currentShow.id === show.id;

                return (
                  <div
                    key={show.id}
                    onClick={() => setActiveStreamingShow(show)}
                    className={`group rounded-2xl overflow-hidden border transition cursor-pointer flex flex-col ${
                      isSelected
                        ? 'border-pink-500 ring-2 ring-pink-500/50 shadow-lg'
                        : 'border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="relative aspect-[2/3] bg-slate-800 overflow-hidden">
                      <img
                        src={show.posterUrl}
                        alt={show.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-100/80 via-transparent to-slate-100/20" />

                      <span className="absolute top-2 left-2 text-[9px] font-black uppercase bg-slate-100/60 backdrop-blur-md text-pink-300 px-1.5 py-0.5 rounded">
                        {show.platform}
                      </span>

                      {show.isLive && (
                        <span className="absolute top-2 right-2 text-[9px] font-black uppercase bg-rose-600 text-white px-1.5 py-0.5 rounded animate-pulse">
                          LIVE
                        </span>
                      )}

                      <div className="absolute bottom-2 left-2 right-2">
                        <h4 className="font-extrabold text-white text-xs truncate">{show.title}</h4>
                        <div className="flex items-center justify-between text-[10px] text-slate-300 mt-0.5">
                          <span>{show.type}</span>
                          <span className="flex items-center gap-0.5 text-amber-400 font-bold">
                            <Star className="w-2.5 h-2.5 fill-amber-400" /> {show.rating}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
