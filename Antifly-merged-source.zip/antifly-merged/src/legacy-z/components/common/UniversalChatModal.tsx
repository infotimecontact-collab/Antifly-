import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  MessageSquare,
  Send,
  Paperclip,
  Image as ImageIcon,
  Video,
  Mic,
  Smile,
  ShieldCheck,
  MoreVertical,
  Search,
  Check,
  CheckCheck,
  X,
  Lock,
  Phone,
  Video as VideoCallIcon,
  ShoppingBag,
  BellOff,
  Ban,
  Clock,
  Power,
  Users,
  Store,
  Truck,
  Bot,
  User,
  Sparkles,
  Play,
  Volume2,
  ChevronRight,
  Camera,
} from 'lucide-react';
import { ChatConversation, ChatMessageItem, ChatMessageType } from '../../types';

export const UniversalChatModal: React.FC = () => {
  const {
    isUniversalChatOpen,
    setIsUniversalChatOpen,
    chatConversations,
    activeConversationId,
    setActiveConversationId,
    chatMessages,
    sendChatMessage,
    toggleConversationMute,
    toggleConversationBlock,
    toggleConversationChatEnabled,
    updateDisappearingTimer,
    currentUserSession,
    formatPrice,
    showToast,
    openCameraStudio,
  } = useApp();

  const [filterRole, setFilterRole] = useState<'all' | 'customer' | 'seller' | 'driver' | 'support_ai' | 'community_group'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [inputMessage, setInputMessage] = useState('');
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [showSecurityMenu, setShowSecurityMenu] = useState(false);
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [voiceSeconds, setVoiceSeconds] = useState(0);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeConv = chatConversations.find((c) => c.id === activeConversationId) || chatConversations[0];
  const activeMessages = activeConv ? chatMessages[activeConv.id] || [] : [];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeMessages]);

  useEffect(() => {
    let timer: any;
    if (isRecordingVoice) {
      timer = setInterval(() => setVoiceSeconds((s) => s + 1), 1000);
    } else {
      setVoiceSeconds(0);
    }
    return () => clearInterval(timer);
  }, [isRecordingVoice]);

  if (!isUniversalChatOpen) return null;

  const filteredConversations = chatConversations.filter((c) => {
    const matchRole = filterRole === 'all' || c.peerRole === filterRole;
    const matchSearch =
      c.peerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.lastMessage.toLowerCase().includes(searchQuery.toLowerCase());
    return matchRole && matchSearch;
  });

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;
    sendChatMessage(activeConv.id, inputMessage.trim(), 'text');
    setInputMessage('');
  };

  const handleSendSampleMedia = (type: 'image' | 'video_15s' | 'product_card') => {
    setShowAttachMenu(false);
    if (type === 'image') {
      sendChatMessage(activeConv.id, 'Shared a high-resolution weave swatch', 'image', {
        mediaUrl: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&auto=format&fit=crop&q=80',
      });
      showToast('📷 Photo sent to chat');
    } else if (type === 'video_15s') {
      sendChatMessage(activeConv.id, 'Shared a 15-second fabric shine video clip', 'video_15s', {
        mediaUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=600',
        durationSeconds: 15,
      });
      showToast('🎬 15s Video clip sent');
    } else if (type === 'product_card') {
      sendChatMessage(activeConv.id, 'Kanchipuram Pure Mulberry Silk Saree', 'product_card', {
        productSnippet: {
          id: 'prod-01',
          name: 'Kanchipuram Pure Mulberry Silk Saree',
          price: 4999,
          image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=300',
        },
      });
      showToast('🛍️ Product Card shared');
    }
  };

  const handleSendVoiceNote = () => {
    setIsRecordingVoice(false);
    sendChatMessage(activeConv.id, `Voice message (${voiceSeconds || 3}s)`, 'voice_note', {
      durationSeconds: voiceSeconds || 3,
    });
    showToast('🎤 Voice Note sent to chat');
  };

  return (
    <div
      id="universal-chat-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-2 sm:p-4"
    >
      <div className="bg-white w-full max-w-5xl h-[92vh] max-h-[820px] rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row border border-emerald-100">
        {/* LEFT COLUMN: CONVERSATION LIST (WhatsApp Style) */}
        <div className="w-full md:w-80 lg:w-96 bg-slate-50 border-r border-slate-200 flex flex-col flex-shrink-0">
          {/* Header */}
          <div className="bg-[#005c4b] text-white p-3.5 flex items-center justify-between shadow-sm">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-emerald-700/80 border-2 border-emerald-300/40 overflow-hidden flex items-center justify-center">
                {currentUserSession.avatar ? (
                  <img
                    src={currentUserSession.avatar}
                    alt={currentUserSession.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="w-5 h-5 text-emerald-100" />
                )}
              </div>
              <div>
                <h3 className="font-semibold text-sm leading-tight flex items-center gap-1.5">
                  <span>Chats & Community</span>
                  <span className="text-[10px] bg-emerald-400/30 text-emerald-200 px-1.5 py-0.5 rounded font-mono">
                    E2EE
                  </span>
                </h3>
                <p className="text-xs text-emerald-100/80 truncate max-w-[150px]">
                  {currentUserSession.name} ({currentUserSession.role.toUpperCase()})
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                id="btn-close-chat-mobile"
                onClick={() => setIsUniversalChatOpen(false)}
                className="md:hidden p-1.5 text-white hover:bg-emerald-700 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Search bar */}
          <div className="p-2.5 bg-white border-b border-slate-100">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search chats, drivers, sellers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-100 text-xs text-slate-800 rounded-lg pl-9 pr-3 py-2 border-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
              />
            </div>
          </div>

          {/* Role Filter Tabs */}
          <div className="flex items-center space-x-1 p-2 bg-slate-100/80 border-b border-slate-200 overflow-x-auto scrollbar-none text-[11px] font-medium">
            <button
              onClick={() => setFilterRole('all')}
              className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-colors ${
                filterRole === 'all' ? 'bg-[#00a884] text-white font-semibold' : 'bg-white text-slate-600 hover:bg-slate-200'
              }`}
            >
              All ({chatConversations.length})
            </button>
            <button
              onClick={() => setFilterRole('seller')}
              className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-colors flex items-center gap-1 ${
                filterRole === 'seller' ? 'bg-[#00a884] text-white font-semibold' : 'bg-white text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Store className="w-3 h-3" /> Sellers
            </button>
            <button
              onClick={() => setFilterRole('driver')}
              className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-colors flex items-center gap-1 ${
                filterRole === 'driver' ? 'bg-[#00a884] text-white font-semibold' : 'bg-white text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Truck className="w-3 h-3" /> Drivers
            </button>
            <button
              onClick={() => setFilterRole('community_group')}
              className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-colors flex items-center gap-1 ${
                filterRole === 'community_group' ? 'bg-[#00a884] text-white font-semibold' : 'bg-white text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Users className="w-3 h-3" /> Community
            </button>
            <button
              onClick={() => setFilterRole('support_ai')}
              className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-colors flex items-center gap-1 ${
                filterRole === 'support_ai' ? 'bg-[#00a884] text-white font-semibold' : 'bg-white text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Bot className="w-3 h-3" /> AI Bots
            </button>
          </div>

          {/* Conversations List */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
            {filteredConversations.map((conv) => {
              const isActive = conv.id === activeConversationId;
              return (
                <div
                  key={conv.id}
                  id={`chat-conv-${conv.id}`}
                  onClick={() => setActiveConversationId(conv.id)}
                  className={`p-3 flex items-start space-x-3 cursor-pointer transition-colors relative ${
                    isActive ? 'bg-emerald-50/80 border-l-4 border-[#00a884]' : 'hover:bg-slate-100/60 bg-white'
                  }`}
                >
                  {/* Avatar with Status badge */}
                  <div className="relative flex-shrink-0">
                    <img
                      src={conv.peerAvatar}
                      alt={conv.peerName}
                      className="w-12 h-12 rounded-full object-cover border border-slate-200"
                    />
                    {conv.isOnline && (
                      <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full"></span>
                    )}
                  </div>

                  {/* Conv Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-semibold text-slate-900 truncate flex items-center gap-1.5">
                        <span>{conv.peerName}</span>
                        {conv.peerRole === 'seller' && (
                          <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded font-medium">
                            Seller
                          </span>
                        )}
                        {conv.peerRole === 'driver' && (
                          <span className="text-[10px] bg-blue-100 text-blue-800 px-1.5 py-0.2 rounded font-medium">
                            Rider
                          </span>
                        )}
                        {conv.peerRole === 'support_ai' && (
                          <span className="text-[10px] bg-purple-100 text-purple-800 px-1.5 py-0.2 rounded font-medium">
                            AI Bot
                          </span>
                        )}
                      </h4>
                      <span className="text-[11px] text-slate-400 whitespace-nowrap">{conv.lastMessageTime}</span>
                    </div>

                    <p className="text-xs text-slate-500 truncate mt-0.5 flex items-center gap-1">
                      {conv.isBlocked && <Ban className="w-3 h-3 text-red-500 flex-shrink-0" />}
                      {!conv.chatEnabled && <Power className="w-3 h-3 text-amber-500 flex-shrink-0" />}
                      <span className="truncate">{conv.lastMessage}</span>
                    </p>
                  </div>

                  {/* Unread badge */}
                  {conv.unreadCount > 0 && (
                    <span className="w-5 h-5 bg-[#25d366] text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                      {conv.unreadCount}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* RIGHT COLUMN: ACTIVE CHAT SCREEN */}
        <div className="flex-1 flex flex-col bg-[#efeae2] relative min-w-0">
          {/* Active Chat Header */}
          <div className="bg-[#f0f2f5] p-3 px-4 border-b border-slate-200 flex items-center justify-between shadow-sm z-10">
            <div className="flex items-center space-x-3 min-w-0">
              <div className="relative flex-shrink-0">
                <img
                  src={activeConv.peerAvatar}
                  alt={activeConv.peerName}
                  className="w-10 h-10 rounded-full object-cover border border-slate-300"
                />
                {activeConv.isOnline && (
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border-2 border-white rounded-full"></span>
                )}
              </div>
              <div className="min-w-0">
                <h3 className="font-semibold text-sm text-slate-900 leading-tight truncate flex items-center gap-2">
                  <span>{activeConv.peerName}</span>
                  {activeConv.disappearingTimer !== 'off' && (
                    <span className="text-[10px] text-slate-500 flex items-center gap-0.5 bg-slate-200 px-1 rounded">
                      <Clock className="w-2.5 h-2.5" /> {activeConv.disappearingTimer}
                    </span>
                  )}
                </h3>
                <p className="text-xs text-slate-500 truncate flex items-center gap-1.5">
                  {activeConv.isOnline ? (
                    <span className="text-emerald-600 font-medium">Online</span>
                  ) : (
                    <span>Last active {activeConv.lastMessageTime}</span>
                  )}
                  <span>•</span>
                  <span className="text-slate-400 capitalize">{activeConv.peerRole.replace('_', ' ')}</span>
                </p>
              </div>
            </div>

            {/* Security & Action Tools */}
            <div className="flex items-center space-x-2 relative">
              <button
                id="btn-voice-call"
                onClick={() => showToast(`📞 Voice call initiated with ${activeConv.peerName}`)}
                className="p-2 text-slate-600 hover:bg-slate-200 rounded-full transition-colors"
                title="Voice Call"
              >
                <Phone className="w-4 h-4" />
              </button>
              <button
                id="btn-video-call"
                onClick={() => showToast(`📹 HD Video call connected with ${activeConv.peerName}`)}
                className="p-2 text-slate-600 hover:bg-slate-200 rounded-full transition-colors"
                title="Video Call"
              >
                <VideoCallIcon className="w-4 h-4" />
              </button>

              {/* Security & Settings Dropdown */}
              <button
                id="btn-security-settings"
                onClick={() => setShowSecurityMenu(!showSecurityMenu)}
                className={`p-2 rounded-full transition-colors ${
                  showSecurityMenu ? 'bg-slate-300 text-slate-900' : 'text-slate-600 hover:bg-slate-200'
                }`}
                title="Security & Chat Settings"
              >
                <MoreVertical className="w-4 h-4" />
              </button>

              {/* Close Modal Button */}
              <button
                id="btn-close-universal-chat"
                onClick={() => setIsUniversalChatOpen(false)}
                className="p-2 text-slate-600 hover:bg-red-50 hover:text-red-600 rounded-full transition-colors ml-1"
                title="Close Chat"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Security Popup Menu */}
              {showSecurityMenu && (
                <div className="absolute right-0 top-12 w-64 bg-white rounded-xl shadow-xl border border-slate-200 p-2 z-30 animate-in fade-in zoom-in-95 text-xs text-slate-700">
                  <div className="px-2 py-1.5 border-b border-slate-100 mb-1">
                    <p className="font-semibold text-slate-900 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      Chat Security & Privacy
                    </p>
                    <p className="text-[10px] text-slate-500">256-bit End-to-End Encryption active</p>
                  </div>

                  {/* Toggle Chat Enabled */}
                  <button
                    onClick={() => {
                      toggleConversationChatEnabled(activeConv.id);
                      setShowSecurityMenu(false);
                    }}
                    className="w-full flex items-center justify-between px-2.5 py-2 hover:bg-slate-100 rounded-lg text-left"
                  >
                    <span className="flex items-center gap-2">
                      <Power className={`w-3.5 h-3.5 ${activeConv.chatEnabled ? 'text-emerald-600' : 'text-slate-400'}`} />
                      <span>{activeConv.chatEnabled ? 'Disable Chat for Peer' : 'Enable Chat'}</span>
                    </span>
                    <span className={`w-2 h-2 rounded-full ${activeConv.chatEnabled ? 'bg-emerald-500' : 'bg-red-400'}`} />
                  </button>

                  {/* Mute notifications */}
                  <button
                    onClick={() => {
                      toggleConversationMute(activeConv.id);
                      setShowSecurityMenu(false);
                    }}
                    className="w-full flex items-center justify-between px-2.5 py-2 hover:bg-slate-100 rounded-lg text-left"
                  >
                    <span className="flex items-center gap-2">
                      <BellOff className="w-3.5 h-3.5 text-slate-500" />
                      <span>{activeConv.isMuted ? 'Unmute Notifications' : 'Mute Notifications'}</span>
                    </span>
                    {activeConv.isMuted && <span className="text-[10px] text-amber-600 font-semibold">Muted</span>}
                  </button>

                  {/* Disappearing Messages */}
                  <div className="px-2.5 py-2 border-t border-slate-100">
                    <p className="font-medium text-slate-800 flex items-center gap-1.5 mb-1.5">
                      <Clock className="w-3.5 h-3.5 text-blue-600" /> Disappearing Messages:
                    </p>
                    <div className="grid grid-cols-3 gap-1">
                      {(['off', '24h', '7d'] as const).map((t) => (
                        <button
                          key={t}
                          onClick={() => {
                            updateDisappearingTimer(activeConv.id, t);
                            setShowSecurityMenu(false);
                          }}
                          className={`py-1 text-center rounded text-[11px] font-medium border ${
                            activeConv.disappearingTimer === t
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {t.toUpperCase()}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Block / Report */}
                  <div className="border-t border-slate-100 pt-1 mt-1">
                    <button
                      onClick={() => {
                        toggleConversationBlock(activeConv.id);
                        setShowSecurityMenu(false);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-2 text-red-600 hover:bg-red-50 rounded-lg text-left font-medium"
                    >
                      <Ban className="w-3.5 h-3.5" />
                      <span>{activeConv.isBlocked ? 'Unblock Contact' : 'Block & Report Contact'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Security Banner / Notice */}
          <div className="bg-amber-50/90 border-b border-amber-200/60 px-4 py-1.5 flex items-center justify-center gap-2 text-[11px] text-amber-900 shadow-sm">
            <Lock className="w-3 h-3 text-amber-700" />
            <span>Messages & calls are end-to-end encrypted. No one outside of this chat can read or listen.</span>
          </div>

          {/* Chat Messages Feed */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {activeMessages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
                <MessageSquare className="w-12 h-12 text-slate-300 mb-2" />
                <p className="text-sm font-medium text-slate-600">No messages yet</p>
                <p className="text-xs">Say hello or share a 15-second reel with {activeConv.peerName}</p>
              </div>
            ) : (
              activeMessages.map((msg) => {
                const isSelf = msg.isSelf;
                return (
                  <div
                    key={msg.id}
                    id={`chat-msg-${msg.id}`}
                    className={`flex flex-col ${isSelf ? 'items-end' : 'items-start'}`}
                  >
                    <div
                      className={`max-w-[85%] sm:max-w-[70%] rounded-2xl p-3 shadow-sm relative text-sm ${
                        isSelf
                          ? 'bg-[#d9fdd3] text-slate-900 rounded-tr-none'
                          : 'bg-white text-slate-900 rounded-tl-none border border-slate-200/60'
                      }`}
                    >
                      {/* Sender name for group chats */}
                      {!isSelf && activeConv.peerRole === 'community_group' && (
                        <p className="text-[11px] font-bold text-emerald-700 mb-1">{msg.senderName}</p>
                      )}

                      {/* Photo / Image */}
                      {msg.type === 'image' && msg.mediaUrl && (
                        <div className="rounded-lg overflow-hidden mb-2 border border-slate-200/10">
                          <img
                            src={msg.mediaUrl}
                            alt="Chat Attachment"
                            className="w-full max-h-60 object-cover hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                      )}

                      {/* 15s Video Clip / Reel */}
                      {(msg.type === 'video_15s' || msg.type === 'reel') && msg.mediaUrl && (
                        <div className="rounded-lg overflow-hidden mb-2 border border-slate-200/10 relative group">
                          <img
                            src={msg.mediaUrl}
                            alt="15s Reel Preview"
                            className="w-full max-h-60 object-cover"
                          />
                          <div className="absolute inset-0 bg-slate-100/30 flex items-center justify-center">
                            <div className="w-12 h-12 rounded-full bg-red-600/90 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                              <Play className="w-6 h-6 fill-current ml-0.5" />
                            </div>
                          </div>
                          <div className="absolute top-2 left-2 bg-slate-100/60 text-white text-[10px] px-2 py-0.5 rounded-full font-mono">
                            🎬 15s Reel
                          </div>
                        </div>
                      )}

                      {/* Product Card */}
                      {msg.type === 'product_card' && msg.productSnippet && (
                        <div className="bg-slate-50 border border-slate-200 rounded-xl p-2.5 mb-2 flex items-center space-x-3">
                          <img
                            src={msg.productSnippet.image}
                            alt={msg.productSnippet.name}
                            className="w-14 h-14 rounded-lg object-cover border border-slate-200 flex-shrink-0"
                          />
                          <div className="min-w-0 flex-1">
                            <h5 className="font-semibold text-xs text-slate-900 truncate">
                              {msg.productSnippet.name}
                            </h5>
                            <p className="text-emerald-700 font-bold text-sm mt-0.5">
                              {formatPrice(msg.productSnippet.price)}
                            </p>
                            <span className="text-[10px] text-blue-600 font-medium inline-flex items-center gap-0.5 mt-0.5">
                              Tap to View Product <ChevronRight className="w-3 h-3" />
                            </span>
                          </div>
                        </div>
                      )}

                      {/* Voice Note */}
                      {msg.type === 'voice_note' && (
                        <div className="flex items-center space-x-2.5 py-1 min-w-[200px]">
                          <button
                            onClick={() => showToast('▶️ Playing 15s voice note message')}
                            className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center flex-shrink-0"
                          >
                            <Play className="w-4 h-4 fill-current ml-0.5" />
                          </button>
                          <div className="flex-1">
                            <div className="h-1.5 bg-slate-300 rounded-full overflow-hidden">
                              <div className="w-1/2 h-full bg-emerald-600"></div>
                            </div>
                            <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1">
                              <span>0:0{msg.durationSeconds || 4}</span>
                              <span className="flex items-center gap-0.5">
                                <Volume2 className="w-3 h-3" /> Voice Clip
                              </span>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Text Content */}
                      <p className="leading-relaxed whitespace-pre-wrap">{msg.content}</p>

                      {/* Time & Read Status */}
                      <div className="flex items-center justify-end space-x-1 mt-1 text-[10px] text-slate-400 select-none">
                        <span>{msg.timestamp}</span>
                        {isSelf && (
                          <span>
                            {msg.status === 'read' ? (
                              <CheckCheck className="w-3.5 h-3.5 text-[#53bdeb]" />
                            ) : msg.status === 'delivered' ? (
                              <CheckCheck className="w-3.5 h-3.5 text-slate-400" />
                            ) : (
                              <Check className="w-3.5 h-3.5 text-slate-400" />
                            )}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Blocked or Disabled Banner */}
          {(!activeConv.chatEnabled || activeConv.isBlocked) && (
            <div className="p-3 bg-red-50 border-t border-red-200 text-center text-xs text-red-700 flex items-center justify-center gap-2">
              <Ban className="w-4 h-4" />
              <span>
                {activeConv.isBlocked
                  ? 'You have blocked this contact. Unblock to send messages.'
                  : 'Chat has been disabled for this contact.'}
              </span>
            </div>
          )}

          {/* Input & Media Action Bar */}
          {activeConv.chatEnabled && !activeConv.isBlocked && (
            <div className="p-2.5 bg-[#f0f2f5] border-t border-slate-200 relative">
              {/* Attachment Drawer Menu */}
              {showAttachMenu && (
                <div className="absolute bottom-16 left-4 bg-white rounded-2xl shadow-2xl border border-slate-200 p-3 grid grid-cols-3 gap-2.5 z-20 animate-in fade-in slide-in-from-bottom-2">
                  <button
                    onClick={() => {
                      setShowAttachMenu(false);
                      openCameraStudio('chat', activeConv.id);
                    }}
                    className="flex flex-col items-center p-2.5 hover:bg-amber-50 rounded-xl transition-colors text-center"
                  >
                    <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mb-1">
                      <Camera className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-semibold text-slate-800">Camera Studio</span>
                  </button>

                  <button
                    onClick={() => handleSendSampleMedia('image')}
                    className="flex flex-col items-center p-2.5 hover:bg-emerald-50 rounded-xl transition-colors text-center"
                  >
                    <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mb-1">
                      <ImageIcon className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-semibold text-slate-800">Photos</span>
                  </button>

                  <button
                    onClick={() => handleSendSampleMedia('video_15s')}
                    className="flex flex-col items-center p-2.5 hover:bg-red-50 rounded-xl transition-colors text-center"
                  >
                    <div className="w-10 h-10 rounded-full bg-red-100 text-red-600 flex items-center justify-center mb-1">
                      <Video className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-semibold text-slate-800">15s Video Reel</span>
                  </button>

                  <button
                    onClick={() => handleSendSampleMedia('product_card')}
                    className="flex flex-col items-center p-2.5 hover:bg-blue-50 rounded-xl transition-colors text-center"
                  >
                    <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mb-1">
                      <ShoppingBag className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-semibold text-slate-800">Catalog Item</span>
                  </button>
                </div>
              )}

              {/* Recording Overlay */}
              {isRecordingVoice ? (
                <div className="flex items-center justify-between bg-red-50 border border-red-200 rounded-xl p-2 px-4">
                  <div className="flex items-center space-x-3">
                    <span className="w-3 h-3 bg-red-600 rounded-full animate-ping"></span>
                    <span className="text-xs font-semibold text-red-700">
                      Recording Voice Note: 0:0{voiceSeconds}s (Max 15s)
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setIsRecordingVoice(false)}
                      className="px-3 py-1 bg-slate-200 text-slate-700 rounded-lg text-xs font-medium hover:bg-slate-300"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSendVoiceNote}
                      className="px-3 py-1 bg-emerald-600 text-white rounded-lg text-xs font-semibold hover:bg-emerald-700 flex items-center gap-1"
                    >
                      <Send className="w-3 h-3" /> Send
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <button
                    id="btn-attach-media"
                    onClick={() => setShowAttachMenu(!showAttachMenu)}
                    className="p-2 text-slate-500 hover:text-emerald-700 hover:bg-slate-200 rounded-full transition-colors"
                    title="Attach Media / 15s Video / Product"
                  >
                    <Paperclip className="w-5 h-5" />
                  </button>

                  <button
                    id="btn-chat-open-camera"
                    onClick={() => openCameraStudio('chat', activeConv.id)}
                    className="p-2 text-slate-500 hover:text-amber-600 hover:bg-amber-50 rounded-full transition-colors"
                    title="Open Camera Studio (Take Photo / Reel / View-Once)"
                  >
                    <Camera className="w-5 h-5" />
                  </button>

                  <div className="flex-1 bg-white rounded-xl border border-slate-200 flex items-center px-3 py-1.5 focus-within:ring-2 focus-within:ring-emerald-500">
                    <input
                      id="input-chat-message"
                      type="text"
                      placeholder={`Message ${activeConv.peerName}...`}
                      value={inputMessage}
                      onChange={(e) => setInputMessage(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                      className="w-full text-sm text-slate-800 placeholder-slate-400 border-none outline-none focus:ring-0 p-0"
                    />
                    <button
                      onClick={() => setInputMessage((prev) => prev + ' ✨')}
                      className="text-slate-400 hover:text-amber-500 transition-colors p-1"
                      title="Add Emoji"
                    >
                      <Smile className="w-4 h-4" />
                    </button>
                  </div>

                  {inputMessage.trim() ? (
                    <button
                      id="btn-send-chat-msg"
                      onClick={handleSendMessage}
                      className="p-2.5 bg-[#00a884] text-white rounded-full hover:bg-emerald-600 transition-colors shadow-md flex-shrink-0"
                      title="Send Message"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      id="btn-record-voice"
                      onClick={() => setIsRecordingVoice(true)}
                      className="p-2.5 bg-slate-200 text-slate-700 hover:bg-emerald-100 hover:text-emerald-700 rounded-full transition-colors flex-shrink-0"
                      title="Hold to Record Voice Note"
                    >
                      <Mic className="w-4 h-4" />
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
