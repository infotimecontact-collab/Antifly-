import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Sparkles,
  Heart,
  EyeOff,
  Sliders,
  MapPin,
  RefreshCw,
  Trash2,
  Undo2,
  CheckCircle2,
  Store,
  Star,
  ShoppingBag,
  TrendingUp,
  Tag,
  ThumbsUp,
  ThumbsDown,
  Info,
} from 'lucide-react';
import { NotInterestedReason, NotInterestedRecord } from '../../types';

export const UserInterestManagerModal: React.FC = () => {
  const {
    isInterestManagerOpen,
    setIsInterestManagerOpen,
    userInterestProfile,
    updateCategoryAffinity,
    removeInterestProduct,
    undoNotInterested,
    clearAllNotInterested,
    resetInterestProfile,
    products,
    sellers,
    setActivePdpId,
    addToCart,
    showToast,
    formatPrice,
    updateUserLocationPreference,
    setShoppingVibePreference,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'affinities' | 'interested' | 'hidden' | 'location'>('affinities');

  if (!isInterestManagerOpen) return null;

  const interestedProductsList = products.filter((p) =>
    userInterestProfile.interestedProductIds.includes(p.id)
  );

  const hiddenRecordEntries: NotInterestedRecord[] = Object.values(userInterestProfile.notInterestedRecords);

  const availableCities = [
    { name: 'Bengaluru', pin: '560034', state: 'Karnataka' },
    { name: 'Mumbai', pin: '400001', state: 'Maharashtra' },
    { name: 'Delhi NCR', pin: '110001', state: 'Delhi' },
    { name: 'Jaipur', pin: '302001', state: 'Rajasthan' },
    { name: 'Pune', pin: '411001', state: 'Maharashtra' },
    { name: 'Hyderabad', pin: '500001', state: 'Telangana' },
    { name: 'Chennai', pin: '600001', state: 'Tamil Nadu' },
    { name: 'Kolkata', pin: '700001', state: 'West Bengal' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center shadow-inner">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-full">
                  AI Personalization Engine
                </span>
                <span className="text-xs text-amber-100 font-bold">Amazon & Instagram Style</span>
              </div>
              <h2 className="text-lg font-black leading-tight mt-0.5">
                Your Shopping Interests & Feed Tuner
              </h2>
            </div>
          </div>

          <button
            onClick={() => setIsInterestManagerOpen(false)}
            className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 px-4 pt-2 gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('affinities')}
            className={`pb-2.5 px-3 text-xs font-bold flex items-center gap-1.5 border-b-2 transition whitespace-nowrap cursor-pointer ${
              activeTab === 'affinities'
                ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Category Affinities</span>
          </button>

          <button
            onClick={() => setActiveTab('interested')}
            className={`pb-2.5 px-3 text-xs font-bold flex items-center gap-1.5 border-b-2 transition whitespace-nowrap cursor-pointer ${
              activeTab === 'interested'
                ? 'border-rose-500 text-rose-600 dark:text-rose-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Heart className="w-3.5 h-3.5" />
            <span>Interested & Liked ({interestedProductsList.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('hidden')}
            className={`pb-2.5 px-3 text-xs font-bold flex items-center gap-1.5 border-b-2 transition whitespace-nowrap cursor-pointer ${
              activeTab === 'hidden'
                ? 'border-slate-900 text-slate-900 dark:text-white'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <EyeOff className="w-3.5 h-3.5" />
            <span>Not Interested / Hidden ({hiddenRecordEntries.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('location')}
            className={`pb-2.5 px-3 text-xs font-bold flex items-center gap-1.5 border-b-2 transition whitespace-nowrap cursor-pointer ${
              activeTab === 'location'
                ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>Nearby Location & Delivery</span>
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: CATEGORY AFFINITIES & SHOPPING VIBES */}
          {activeTab === 'affinities' && (
            <div className="space-y-6">
              <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 p-4 rounded-2xl flex items-start gap-3">
                <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="text-xs text-amber-900 dark:text-amber-200 leading-relaxed">
                  <p className="font-bold mb-1">How AI Personalization Works:</p>
                  When you <strong>Like ❤️</strong>, browse, or mark an item as <strong>Interested</strong>, we increase the score for that category and brand. Marking items as <strong>Not Interested 🚫</strong> immediately lowers recommendations for that specific theme.
                </div>
              </div>

              {/* Shopping Vibe Quick Selector */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
                  Current Shopping Vibe Preference
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {[
                    { id: 'all', label: '🌟 All Styles', desc: 'Balanced Mix' },
                    { id: 'festive', label: '🪔 Festive & Wedding', desc: 'Silk & Kurtas' },
                    { id: 'daily', label: '🌿 Everyday Casual', desc: 'Linen & Cottons' },
                    { id: 'luxury', label: '👑 Luxury Artisanal', desc: 'Premium Handcrafted' },
                    { id: 'budget', label: '⚡ Steal Deals', desc: 'Under ₹1,999' },
                  ].map((vibe) => (
                    <button
                      key={vibe.id}
                      onClick={() => {
                        setShoppingVibePreference(vibe.id as any);
                        showToast(`Shopping vibe set to ${vibe.label}`);
                      }}
                      className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                        userInterestProfile.shoppingVibe === vibe.id
                          ? 'bg-amber-500 text-slate-800 border-amber-400 font-bold shadow-sm'
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:border-amber-400'
                      }`}
                    >
                      <p className="text-xs font-bold">{vibe.label}</p>
                      <p className="text-[10px] opacity-80 mt-0.5">{vibe.desc}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Category Sliders */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Category Affinity Weights (0% - 100%)
                  </h3>
                  <button
                    onClick={() => {
                      resetInterestProfile();
                      showToast('🔄 Interest profile recalibrated to default baseline!');
                    }}
                    className="text-xs text-amber-600 font-bold hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    Reset Baseline
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {Object.entries(userInterestProfile.categoryAffinities).map(([catName, score]) => (
                    <div
                      key={catName}
                      className="p-3.5 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2"
                    >
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-bold text-slate-900 dark:text-white">{catName}</span>
                        <span className="font-mono font-black text-amber-600 dark:text-amber-400 bg-amber-100 dark:bg-amber-950 px-2 py-0.5 rounded-full text-[11px]">
                          {score}% Affinity
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={score}
                        onChange={(e) => updateCategoryAffinity(catName, parseInt(e.target.value))}
                        className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: INTERESTED & LIKED PRODUCTS (Instagram / Meesho style) */}
          {activeTab === 'interested' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Products You Marked as Interested ❤️
                  </h3>
                  <p className="text-xs text-slate-500">
                    These products boost your personalized recommendation feed on the homepage.
                  </p>
                </div>
              </div>

              {interestedProductsList.length === 0 ? (
                <div className="p-8 text-center bg-slate-50 dark:bg-slate-800/60 rounded-3xl border border-dashed border-slate-200 dark:border-slate-700 space-y-2">
                  <Heart className="w-8 h-8 text-slate-400 mx-auto" />
                  <p className="text-sm font-bold text-slate-800 dark:text-slate-200">No Liked Items Yet</p>
                  <p className="text-xs text-slate-500">
                    Double-tap or click the Heart icon on any product card on the homepage to start personalizing your feed!
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {interestedProductsList.map((product) => (
                    <div
                      key={product.id}
                      className="p-3 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3 shadow-xs"
                    >
                      <div
                        onClick={() => {
                          setActivePdpId(product.id);
                          setIsInterestManagerOpen(false);
                        }}
                        className="flex items-center gap-3 min-w-0 cursor-pointer group flex-1"
                      >
                        <img
                          src={product.images[0]}
                          alt={product.name}
                          className="w-14 h-14 rounded-xl object-cover shrink-0"
                        />
                        <div className="truncate">
                          <p className="text-xs font-bold text-slate-900 dark:text-white truncate group-hover:text-amber-500 transition">
                            {product.name}
                          </p>
                          <p className="text-[11px] text-slate-500">{product.brand}</p>
                          <p className="text-xs font-black text-amber-600 dark:text-amber-400 mt-0.5">
                            {formatPrice(product.price)}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => {
                            addToCart({
                              productId: product.id,
                              variantId: 'default',
                              productName: product.name,
                              brand: product.brand,
                              color: product.colors[0]?.name || 'Standard',
                              size: product.sizes[0] || 'Standard',
                              price: product.price,
                              mrp: product.mrp,
                              image: product.images[0],
                              quantity: 1,
                              stock: product.totalStock,
                            });
                          }}
                          className="p-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs transition cursor-pointer"
                          title="Add to Cart"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            removeInterestProduct(product.id);
                            showToast(`Removed "${product.name}" from interested list`);
                          }}
                          className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/60 rounded-xl transition cursor-pointer"
                          title="Remove from Interests"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: NOT INTERESTED / HIDDEN ITEMS (Amazon / Flipkart / Instagram style) */}
          {activeTab === 'hidden' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Products You Marked as "Not Interested" 🚫
                  </h3>
                  <p className="text-xs text-slate-500">
                    These items are suppressed from your homepage and search recommendations.
                  </p>
                </div>

                {hiddenRecordEntries.length > 0 && (
                  <button
                    onClick={() => {
                      clearAllNotInterested();
                      showToast('✨ All hidden products restored to your feed!');
                    }}
                    className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer transition"
                  >
                    <RefreshCw className="w-3 h-3" />
                    Restore All
                  </button>
                )}
              </div>

              {hiddenRecordEntries.length === 0 ? (
                <div className="p-8 text-center bg-slate-50 dark:bg-slate-800/60 rounded-3xl border border-dashed border-slate-200 dark:border-slate-700 space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
                  <p className="text-sm font-bold text-slate-800 dark:text-slate-200">No Suppressed Items</p>
                  <p className="text-xs text-slate-500">
                    If you see a product you don't like on the homepage, click "Not Interested" to remove it and tune your recommendations.
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {hiddenRecordEntries.map((rec) => {
                    const prod = products.find((p) => p.id === rec.productId);
                    return (
                      <div
                        key={rec.productId}
                        className="p-3.5 bg-rose-50/40 dark:bg-slate-800/80 border border-rose-200/80 dark:border-slate-700 rounded-2xl flex items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          {prod && (
                            <img
                              src={prod.images[0]}
                              alt={rec.productName}
                              className="w-12 h-12 rounded-xl object-cover shrink-0 opacity-70"
                            />
                          )}
                          <div className="truncate">
                            <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                              {rec.productName}
                            </p>
                            <p className="text-[11px] text-slate-500">
                              {rec.brand} &bull; {rec.category}
                            </p>
                            <span className="inline-block mt-0.5 text-[10px] bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 font-bold px-2 py-0.5 rounded-full">
                              Reason: {rec.reasonText}
                            </span>
                          </div>
                        </div>

                        <button
                          onClick={() => {
                            undoNotInterested(rec.productId);
                            showToast(`Restored "${rec.productName}" to recommendations`);
                          }}
                          className="px-3 py-1.5 bg-white dark:bg-slate-700 hover:bg-slate-100 text-slate-700 dark:text-white text-xs font-bold border border-slate-300 dark:border-slate-600 rounded-xl flex items-center gap-1 transition cursor-pointer shadow-2xs"
                        >
                          <Undo2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Unhide</span>
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: NEARBY LOCATION & HYPERLOCAL PREFERENCES */}
          {activeTab === 'location' && (
            <div className="space-y-6">
              <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 p-4 rounded-2xl flex items-start gap-3">
                <MapPin className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="text-xs text-emerald-900 dark:text-emerald-200 leading-relaxed">
                  <p className="font-bold mb-1">Hyperlocal Artisan & Boutique Routing:</p>
                  We prioritize nearby verified weaver studios and artisan shops in your city for same-day delivery, 30-min express courier drops, and live pickup.
                </div>
              </div>

              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
                  Select Your City / Delivery Hub
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {availableCities.map((c) => {
                    const isSelected = userInterestProfile.userCity.toLowerCase() === c.name.toLowerCase();
                    return (
                      <button
                        key={c.name}
                        onClick={() => {
                          updateUserLocationPreference(c.name, c.pin, userInterestProfile.maxDistanceRadiusKm);
                          showToast(`📍 Location updated to ${c.name} (${c.pin})`);
                        }}
                        className={`p-3 rounded-2xl border text-left transition cursor-pointer ${
                          isSelected
                            ? 'bg-emerald-600 text-white border-emerald-500 font-bold shadow-md'
                            : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:border-emerald-400'
                        }`}
                      >
                        <p className="text-xs font-bold">{c.name}</p>
                        <p className="text-[10px] opacity-80 mt-0.5">{c.state} ({c.pin})</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Distance Radius Slider */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-slate-900 dark:text-white">
                    Maximum Distance Radius for Local Sellers
                  </span>
                  <span className="font-mono font-black text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-950 px-2 py-0.5 rounded-full text-[11px]">
                    {userInterestProfile.maxDistanceRadiusKm} km radius
                  </span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="30"
                  step="1"
                  value={userInterestProfile.maxDistanceRadiusKm}
                  onChange={(e) => {
                    updateUserLocationPreference(
                      userInterestProfile.userCity,
                      userInterestProfile.userPincode,
                      parseInt(e.target.value)
                    );
                  }}
                  className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Last Updated: <strong className="text-slate-700 dark:text-slate-300">{userInterestProfile.lastUpdated}</strong>
          </span>
          <button
            onClick={() => setIsInterestManagerOpen(false)}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer"
          >
            Done & Apply
          </button>
        </div>
      </div>
    </div>
  );
};
