import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Monitor,
  Smartphone,
  ShieldCheck,
  Store,
  Truck,
  Code,
  Sparkles,
  Mic,
  Camera,
  Bell,
  Scale,
  Globe,
  BarChart3,
  Search,
  Share2,
  Users,
  Bot,
  Zap,
} from 'lucide-react';
import { DeviceMode, LanguageCode } from '../../types';
import { SUPPORTED_LANGUAGES } from '../../utils/i18n';
import { UserCheck, LogIn } from 'lucide-react';

export const DeviceSwitcher: React.FC = () => {
  const {
    deviceMode,
    setDeviceMode,
    notifications,
    setIsNotificationDrawerOpen,
    setIsAntiflyAIOpen,
    setIsVoiceSearchOpen,
    setIsImageSearchOpen,
    setIsProductFinderOpen,
    setIsGA4ModalOpen,
    setIsSEOModalOpen,
    comparisonList,
    setIsComparisonOpen,
    language,
    setLanguage,
    t,
    currentUserSession,
    setIsLoginModalOpen,
  } = useApp();

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <header
      id="antifly-global-control-bar"
      className="sticky top-0 z-50 bg-white/95 text-slate-900 backdrop-blur-xl border-b border-slate-200 px-2 sm:px-6 py-2.5 shadow-xs transition-all"
    >
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs sm:text-sm">
        {/* Brand identity & Language selector */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-2 bg-gradient-to-r from-cyan-600 via-indigo-600 to-purple-600 px-3 py-1.5 rounded-xl text-white font-extrabold tracking-wider text-xs shadow-xs">
            <span className="w-2 h-2 rounded-full bg-cyan-300 animate-pulse" />
            <span>KELOI</span>
          </div>

          {/* 12-Language Switcher */}
          <div className="flex items-center bg-slate-100 px-2.5 py-1.5 rounded-xl border border-slate-200 shadow-xs">
            <Globe className="w-3.5 h-3.5 text-cyan-600 mr-1.5 shrink-0" />
            <select
              id="global-language-select"
              value={language}
              onChange={(e) => setLanguage(e.target.value as LanguageCode)}
              className="bg-transparent text-slate-800 text-xs font-semibold focus:outline-none cursor-pointer"
              title="Select Worldwide Language"
            >
              {SUPPORTED_LANGUAGES.map((lang) => (
                <option key={lang.code} value={lang.code} className="bg-white text-slate-900">
                  {lang.flag} {lang.nativeName} ({lang.code.toUpperCase()})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* 3-in-1 Omnichannel SuperApp Switcher + LIFEOS Flagship */}
        <div className="flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200 overflow-x-auto max-w-full shadow-xs gap-1">
          {/* LIFEOS Flagship Social OS Switcher */}
          {/* 0. Merged LIFEOS Super App Flagship */}
          <button
            id="switch-to-lifeos"
            onClick={() => setDeviceMode('lifeos')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl transition-all font-extrabold whitespace-nowrap text-xs cursor-pointer ${
              deviceMode === 'lifeos' || deviceMode === 'social'
                ? 'bg-gradient-to-r from-cyan-600 via-indigo-600 to-purple-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
            title="LIFEOS — Unified Life, Social, Commerce & Community Operating System"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
            <span>LIFEOS (Unified Super App)</span>
            <span className="bg-cyan-100 text-cyan-900 text-[9px] font-black px-1.5 py-0.2 rounded-full uppercase tracking-wider">
              MERGED
            </span>
          </button>

          <div className="h-4 w-px bg-slate-200 mx-1 hidden sm:block" />

          <button
            id="switch-to-website"
            onClick={() => setDeviceMode('website')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all font-bold whitespace-nowrap text-xs cursor-pointer ${
              deviceMode === 'website'
                ? 'bg-amber-500 text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
            title="1. Customer Shopping App & Storefront"
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Customer App</span>
          </button>

          <button
            id="switch-to-seller-portal"
            onClick={() => setDeviceMode('seller')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all font-bold whitespace-nowrap text-xs cursor-pointer ${
              deviceMode === 'seller'
                ? 'bg-orange-500 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
            title="2. Venture Central & Merchant Inventory"
          >
            <Store className="w-3.5 h-3.5" />
            <span>Venture App</span>
          </button>

          <button
            id="switch-to-driver-portal"
            onClick={() => setDeviceMode('driver')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all font-bold whitespace-nowrap text-xs cursor-pointer ${
              deviceMode === 'driver'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
            title="3. Delivery Buddy Logistics App"
          >
            <Truck className="w-3.5 h-3.5" />
            <span>Buddy App</span>
          </button>

          <div className="h-4 w-px bg-slate-200 mx-1 hidden sm:block" />

          <button
            id="switch-to-mobile-ios"
            onClick={() => setDeviceMode('mobile-ios')}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl transition-all font-semibold whitespace-nowrap text-xs cursor-pointer ${
              deviceMode === 'mobile-ios'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
            title="Simulate iOS Mobile Screen"
          >
            <Smartphone className="w-3.5 h-3.5 text-blue-500" />
            <span>iOS</span>
          </button>

          <button
            id="switch-to-mobile-android"
            onClick={() => setDeviceMode('mobile-android')}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl transition-all font-semibold whitespace-nowrap text-xs cursor-pointer ${
              deviceMode === 'mobile-android'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
            title="Simulate Android Mobile Screen"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-500" />
            <span>Android</span>
          </button>

          <button
            id="switch-to-admin-panel"
            onClick={() => setDeviceMode('admin')}
            className={`flex items-center gap-1 px-2 py-1.5 rounded-xl transition-all text-[11px] font-medium whitespace-nowrap cursor-pointer opacity-70 hover:opacity-100 ${
              deviceMode === 'admin'
                ? 'bg-purple-600 text-white font-bold opacity-100 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
            title="Sovereign Admin & Platform Moderation Console (Self-Service First)"
          >
            <ShieldCheck className="w-3 h-3 text-purple-600" />
            <span className="hidden sm:inline">Admin Ops</span>
          </button>

          <button
            id="switch-to-api-docs"
            onClick={() => setDeviceMode('api-docs')}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl transition-all font-semibold whitespace-nowrap text-xs cursor-pointer ${
              deviceMode === 'api-docs'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
            title="Worldwide Open REST APIs & Playground"
          >
            <Code className="w-3.5 h-3.5" />
            <span>APIs</span>
          </button>
        </div>

        {/* AI Quick Tools, Analytics & Notifications */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Product Finder (Gemini AI recommendations) */}
          <button
            id="top-product-finder-trigger"
            onClick={() => setIsProductFinderOpen(true)}
            className="flex items-center gap-1 bg-amber-50 hover:bg-amber-100 text-amber-900 px-2.5 py-1.5 rounded-xl border border-amber-200 transition-all text-xs font-bold shadow-xs cursor-pointer"
            title="AI Interactive Product Finder"
          >
            <Search className="w-3.5 h-3.5 text-amber-600" />
            <span className="hidden md:inline">Finder</span>
          </button>

          {/* Google Analytics 4 Config Trigger */}
          <button
            id="top-ga4-trigger"
            onClick={() => setIsGA4ModalOpen(true)}
            className="flex items-center gap-1 bg-cyan-50 hover:bg-cyan-100 text-cyan-900 px-2 py-1.5 rounded-xl border border-cyan-200 transition-all text-xs font-bold shadow-xs cursor-pointer"
            title="Google Analytics 4 Enhanced E-commerce Tracking"
          >
            <BarChart3 className="w-3.5 h-3.5 text-cyan-600" />
            <span className="hidden xl:inline">GA4</span>
          </button>

          {/* SEO & OpenGraph Preview Trigger */}
          <button
            id="top-seo-trigger"
            onClick={() => setIsSEOModalOpen(true)}
            className="flex items-center gap-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 px-2 py-1.5 rounded-xl border border-emerald-200 transition-all text-xs font-bold shadow-xs cursor-pointer"
            title="SEO Metadata, Schema & Social OpenGraph Card Preview"
          >
            <Share2 className="w-3.5 h-3.5 text-emerald-600" />
            <span className="hidden xl:inline">SEO</span>
          </button>

          {/* Voice Search trigger */}
          <button
            id="top-voice-trigger"
            onClick={() => setIsVoiceSearchOpen(true)}
            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-all border border-slate-200 cursor-pointer"
            title="Voice Search (12 Languages Supported)"
          >
            <Mic className="w-4 h-4" />
          </button>

          {/* Image Search trigger */}
          <button
            id="top-camera-trigger"
            onClick={() => setIsImageSearchOpen(true)}
            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-all border border-slate-200 cursor-pointer"
            title="Visual AI Image Matcher"
          >
            <Camera className="w-4 h-4" />
          </button>

          {/* Comparison trigger */}
          {comparisonList.length > 0 && (
            <button
              id="top-comparison-trigger"
              onClick={() => setIsComparisonOpen(true)}
              className="relative p-1.5 text-amber-900 bg-amber-50 hover:bg-amber-100 rounded-xl transition-all flex items-center gap-1 text-xs border border-amber-200 cursor-pointer"
              title="Compare Products"
            >
              <Scale className="w-4 h-4" />
              <span className="bg-amber-500 text-slate-900 font-bold rounded-full w-4 h-4 flex items-center justify-center text-[10px]">
                {comparisonList.length}
              </span>
            </button>
          )}

          {/* Notifications / Transaction Emails Drawer */}
          <button
            id="top-notifications-trigger"
            onClick={() => setIsNotificationDrawerOpen(true)}
            className="relative p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-all border border-slate-200 cursor-pointer"
            title="Notifications & Transactional Center"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute top-0.5 right-0.5 w-2.5 h-2.5 bg-rose-500 rounded-full ring-2 ring-white" />
            )}
          </button>

          {/* Universal Unified Login / Active User Badge */}
          <button
            id="top-universal-auth-trigger"
            onClick={() => setIsLoginModalOpen(true)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all border shadow-xs cursor-pointer ${
              currentUserSession.isLoggedIn
                ? 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100'
                : 'bg-slate-900 text-white border-slate-900 hover:bg-slate-800'
            }`}
            title="Universal Login: Mobile OTP or Social Account"
          >
            {currentUserSession.isLoggedIn ? (
              <>
                <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span className="truncate max-w-[80px] sm:max-w-[120px]">
                  {currentUserSession.name.split(' ')[0]}
                </span>
                <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-amber-200 text-amber-900 uppercase font-black">
                  {currentUserSession.role}
                </span>
              </>
            ) : (
              <>
                <LogIn className="w-3.5 h-3.5 text-white" />
                <span>Log In</span>
              </>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};

