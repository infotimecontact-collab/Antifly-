import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShoppingBag,
  Store,
  Truck,
  ShieldCheck,
  Smartphone,
  MessageSquare,
  Users,
  Layers,
  ArrowRightLeft,
  Heart,
  Camera,
  Radio,
  Sparkles,
} from 'lucide-react';
import { DeviceMode } from '../../types';

export const GlobalAppDock: React.FC = () => {
  const {
    deviceMode,
    setDeviceMode,
    cart,
    driverTasks,
    currentSeller,
    orders,
    setIsUniversalChatOpen,
    setIsCommunityHubOpen,
    setIsAppArchitectureModalOpen,
    setIsFavoritesHubOpen,
    savedProductIds,
    openCameraStudio,
    openTimeShiftCamera,
    setIsWhatsNewModalOpen,
  } = useApp();

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const pendingDeliveries = driverTasks.filter((t) => t.status !== 'Delivered').length;
  const sellerPendingOrders = orders.filter((o) => o.status === 'Processing' || o.status === 'Confirmed').length;

  const appButtons: {
    mode: DeviceMode;
    label: string;
    sub: string;
    icon: React.ReactNode;
    badge?: number;
    color: string;
    activeBg: string;
  }[] = [
    {
      mode: 'lifeos',
      label: 'LIFEOS',
      sub: 'Social OS',
      icon: <Sparkles className="w-4 h-4" />,
      color: 'text-cyan-400',
      activeBg: 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white shadow-lg shadow-cyan-500/20 font-bold',
    },
    {
      mode: 'website',
      label: 'Customer App',
      sub: 'Storefront',
      icon: <ShoppingBag className="w-4 h-4" />,
      badge: cartCount > 0 ? cartCount : undefined,
      color: 'text-red-500',
      activeBg: 'bg-red-600 text-white shadow-lg shadow-red-500/20 font-bold',
    },
    {
      mode: 'seller',
      label: 'Venture App',
      sub: 'Venture Central',
      icon: <Store className="w-4 h-4" />,
      badge: sellerPendingOrders > 0 ? sellerPendingOrders : undefined,
      color: 'text-amber-500',
      activeBg: 'bg-amber-600 text-white shadow-lg shadow-amber-500/20 font-bold',
    },
    {
      mode: 'driver',
      label: 'Buddy App',
      sub: 'Delivery Buddy',
      icon: <Truck className="w-4 h-4" />,
      badge: pendingDeliveries > 0 ? pendingDeliveries : undefined,
      color: 'text-blue-500',
      activeBg: 'bg-blue-600 text-white shadow-lg shadow-blue-500/20 font-bold',
    },
  ];

  return (
    <aside
      id="global-ecosystem-app-dock"
      aria-label="App Ecosystem Switcher"
      className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 max-w-[96vw] sm:max-w-max"
    >
      <div className="bg-white/90 backdrop-blur-2xl border border-slate-800/80 rounded-2xl p-1.5 shadow-2xl flex items-center gap-1 sm:gap-1.5 ring-1 ring-white/10">
        <div className="hidden lg:flex items-center gap-1.5 px-3 py-1 text-[11px] font-bold text-slate-400 border-r border-slate-800">
          <ArrowRightLeft className="w-3.5 h-3.5 text-cyan-400" />
          <span>Infotime Dock:</span>
        </div>

        {appButtons.map((btn) => {
          const isActive = deviceMode === btn.mode;

          return (
            <button
              key={btn.mode}
              onClick={() => setDeviceMode(btn.mode)}
              className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs transition-all whitespace-nowrap ${
                isActive
                  ? btn.activeBg
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
              }`}
            >
              <span className={isActive ? 'text-current' : btn.color}>{btn.icon}</span>
              <div className="text-left leading-tight">
                <p className="text-xs font-bold">{btn.label}</p>
                <p className={`text-[10px] hidden sm:block ${isActive ? 'opacity-90' : 'text-slate-400'}`}>
                  {btn.sub}
                </p>
              </div>

              {btn.badge !== undefined && (
                <span
                  className={`ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                    isActive ? 'bg-white text-slate-900' : 'bg-red-600 text-white'
                  }`}
                >
                  {btn.badge}
                </span>
              )}
            </button>
          );
        })}

        {/* Separator */}
        <div className="h-6 w-[1px] bg-slate-800 mx-1 hidden sm:block"></div>

        {/* What's New & Latest Features Prompt */}
        <button
          id="btn-dock-whats-new"
          onClick={() => setIsWhatsNewModalOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:brightness-110 font-bold transition-all shadow-md shadow-emerald-500/20 whitespace-nowrap"
          title="Prompt Latest Features & Capability Explorer"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Latest</span> Features
        </button>

        {/* Camera Creation Studio trigger */}
        <button
          id="btn-dock-camera-studio"
          onClick={() => openCameraStudio('photo')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs bg-gradient-to-r from-amber-500 to-orange-500 text-slate-800 hover:brightness-110 font-bold transition-all shadow-md shadow-amber-500/20 whitespace-nowrap"
          title="Camera Studio (Snap, AR Lenses, Reels & Shoppable Drops)"
        >
          <Camera className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Camera</span> Studio
        </button>

        {/* Time-Shift 3D Stories trigger */}
        <button
          id="btn-dock-time-shift-story"
          onClick={openTimeShiftCamera}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white hover:brightness-110 font-bold transition-all shadow-md shadow-fuchsia-500/20 whitespace-nowrap"
          title="Time-Shift 3D Stories (2-Hour Ephemeral Spatial Media)"
        >
          <Radio className="w-3.5 h-3.5 animate-pulse" />
          <span className="hidden sm:inline">3D</span> Story
        </button>

        {/* Favorites & Saved trigger */}
        <button
          id="btn-dock-favorites-hub"
          onClick={() => setIsFavoritesHubOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 border border-rose-500/30 font-bold transition-all shadow-xs whitespace-nowrap"
          title="Favorites & Saved Collections Hub"
        >
          <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
          <span className="hidden sm:inline">Favorites</span>
          {savedProductIds.length > 0 && (
            <span className="bg-rose-500 text-white px-1.5 py-0.2 rounded-full text-[10px] font-bold">
              {savedProductIds.length}
            </span>
          )}
        </button>

        {/* Universal Chat trigger */}
        <button
          id="btn-dock-whatsapp-chat"
          onClick={() => setIsUniversalChatOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/30 font-bold transition-all shadow-xs whitespace-nowrap"
          title="WhatsApp 1-to-1 & Multi-Role Chat"
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">WhatsApp</span> Chat
        </button>

        {/* Community Hub trigger */}
        <button
          id="btn-dock-community-hub"
          onClick={() => setIsCommunityHubOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 border border-cyan-500/30 font-bold transition-all shadow-xs whitespace-nowrap"
          title="15s Reels & Lookbook Community"
        >
          <Users className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Join</span> Community
        </button>

        {/* Architecture Explainer trigger */}
        <button
          id="btn-dock-architecture-flow"
          onClick={() => setIsAppArchitectureModalOpen(true)}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs bg-slate-800 text-slate-200 hover:bg-slate-700 hover:text-white border border-slate-700 font-bold transition-all shadow-xs whitespace-nowrap"
          title="How It's Built & Purpose Flowchart"
        >
          <Layers className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden md:inline">How It Works</span>
        </button>
      </div>
    </aside>
  );
};
