import React, { useState, useEffect } from 'react';
import { Timer, Radio, TrendingDown, Zap } from 'lucide-react';

interface RealtimeETABadgeProps {
  initialMinutes: number;
  compact?: boolean;
  className?: string;
  id?: string;
}

export const RealtimeETABadge: React.FC<RealtimeETABadgeProps> = ({
  initialMinutes,
  compact = false,
  className = '',
  id,
}) => {
  // Total remaining seconds initialized with a deterministic offset
  const [remainingSeconds, setRemainingSeconds] = useState<number>(() => Math.max(120, initialMinutes * 60 - 18));
  const [trafficShift, setTrafficShift] = useState<'faster' | 'recalibrating' | null>(null);

  useEffect(() => {
    // 1-second countdown tick
    const interval = setInterval(() => {
      setRemainingSeconds((prev) => (prev > 60 ? prev - 1 : prev));
    }, 1000);

    // Periodic subtle traffic recalculation simulation (every 28-35s)
    const trafficTimer = setInterval(() => {
      setTrafficShift('faster');
      // subtle 15-30s speed-up adjustment
      setRemainingSeconds((prev) => Math.max(60, prev - Math.floor(Math.random() * 15 + 5)));

      const clearTimer = setTimeout(() => {
        setTrafficShift(null);
      }, 2500);

      return () => clearTimeout(clearTimer);
    }, 32000);

    return () => {
      clearInterval(interval);
      clearInterval(trafficTimer);
    };
  }, []);

  const mins = Math.floor(remainingSeconds / 60);
  const secs = remainingSeconds % 60;
  const formattedSecs = secs < 10 ? `0${secs}` : `${secs}`;

  return (
    <div
      id={id}
      className={`inline-flex items-center gap-1.5 font-bold tracking-tight rounded-md transition-all duration-300 select-none ${
        trafficShift === 'faster'
          ? 'bg-emerald-500 text-white shadow-xs scale-102 ring-1 ring-emerald-400'
          : 'bg-emerald-50 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-400 border border-emerald-200/80 dark:border-emerald-800/60'
      } ${compact ? 'text-[9px] px-1.5 py-0.5' : 'text-[10px] px-2 py-0.5'} ${className}`}
      title="Real-time live GPS & traffic estimation"
    >
      {/* Live radar pulsing dot indicator */}
      <span className="relative flex h-1.5 w-1.5 shrink-0">
        <span
          className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
            trafficShift === 'faster' ? 'bg-white' : 'bg-emerald-400'
          }`}
        />
        <span
          className={`relative inline-flex rounded-full h-1.5 w-1.5 ${
            trafficShift === 'faster' ? 'bg-white' : 'bg-emerald-500'
          }`}
        />
      </span>

      {/* Countdown & ETA text */}
      <span className="flex items-center gap-0.5">
        <span className="opacity-80">ETA</span>
        <span className="font-mono font-extrabold">
          {mins}m {formattedSecs}s
        </span>
      </span>

      {/* Real-time recalculation indicator icon */}
      {trafficShift === 'faster' ? (
        <span className="flex items-center text-[8px] uppercase tracking-wider font-black animate-pulse">
          <TrendingDown className="w-2.5 h-2.5 inline mr-0.5" />
          -1m
        </span>
      ) : (
        <Radio
          className={`w-2.5 h-2.5 shrink-0 opacity-60 animate-pulse ${
            trafficShift === 'faster' ? 'text-white' : 'text-emerald-600 dark:text-emerald-400'
          }`}
        />
      )}
    </div>
  );
};
