import React, { useEffect, useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Bell,
  X,
  ExternalLink,
  ShoppingBag,
  Sparkles,
  Volume2,
  CheckCircle2,
} from 'lucide-react';

export const PushNotificationMockBanner: React.FC = () => {
  const { activePushNotificationMock, dismissPushNotificationMock, setActivePdpId } = useApp();
  const [progress, setProgress] = useState(100);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (!activePushNotificationMock) return;

    setProgress(100);
    const interval = 100;
    const totalTime = 8000;
    const decrement = (interval / totalTime) * 100;

    const timer = setInterval(() => {
      if (!isPaused) {
        setProgress((prev) => {
          if (prev <= 0) {
            clearInterval(timer);
            dismissPushNotificationMock();
            return 0;
          }
          return prev - decrement;
        });
      }
    }, interval);

    return () => clearInterval(timer);
  }, [activePushNotificationMock, isPaused, dismissPushNotificationMock]);

  if (!activePushNotificationMock) return null;

  const handleShopNow = () => {
    if (activePushNotificationMock.productId) {
      setActivePdpId(activePushNotificationMock.productId);
    }
    dismissPushNotificationMock();
  };

  return (
    <div
      id="push-notification-mock-banner"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      className="fixed top-5 right-5 z-[9999] max-w-md w-full sm:w-[420px] bg-white/95 text-white rounded-2xl shadow-[0_20px_60px_-15px_rgba(71,85,105,0.35)] border border-amber-500/40 backdrop-blur-xl p-4 animate-in slide-in-from-top-6 duration-300 transition-all ring-1 ring-amber-400/20"
      role="alert"
      aria-live="assertive"
    >
      {/* Header Bar */}
      <div className="flex items-center justify-between pb-2 mb-2 border-b border-white/10">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-md bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-slate-800 font-black text-[10px] shadow-sm">
            <Bell className="w-3 h-3 text-slate-800 fill-slate-950" />
          </div>
          <span className="text-[11px] font-bold tracking-wider uppercase text-amber-400 flex items-center gap-1.5 font-mono">
            <span>ANTIFLY PUSH NOTIFICATION</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-slate-400 flex items-center gap-1">
            <Volume2 className="w-3 h-3 text-slate-400" />
            <span>Just now</span>
          </span>
          <button
            id="btn-close-push-mock"
            onClick={dismissPushNotificationMock}
            className="p-1 text-slate-400 hover:text-white rounded-md hover:bg-white/10 transition cursor-pointer"
            title="Dismiss Push Notification"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Notification Body */}
      <div className="flex items-start gap-3.5">
        {/* Product Image Thumbnail */}
        {activePushNotificationMock.image ? (
          <div className="relative w-16 h-16 rounded-xl overflow-hidden bg-slate-900 border border-white/15 shrink-0 shadow-md">
            <img
              src={activePushNotificationMock.image}
              alt={activePushNotificationMock.productName || 'Product'}
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 inset-x-0 bg-emerald-600/90 text-white text-[8px] font-black text-center py-0.5 uppercase tracking-tighter">
              Restocked
            </div>
          </div>
        ) : (
          <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 border border-amber-500/30">
            <Sparkles className="w-6 h-6" />
          </div>
        )}

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 text-amber-300 font-bold text-xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <h4 className="truncate">{activePushNotificationMock.title}</h4>
          </div>
          <p className="text-xs text-slate-200 mt-1 leading-snug font-medium line-clamp-2">
            {activePushNotificationMock.body}
          </p>
          {activePushNotificationMock.variantInfo && (
            <span className="inline-block mt-1 text-[10px] font-mono text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
              {activePushNotificationMock.variantInfo}
            </span>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-3 pt-2.5 flex items-center justify-end gap-2">
        <button
          id="btn-dismiss-push-mock-action"
          type="button"
          onClick={dismissPushNotificationMock}
          className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-300 hover:text-white hover:bg-white/10 transition cursor-pointer"
        >
          Later
        </button>
        <button
          id="btn-shop-push-mock-action"
          type="button"
          onClick={handleShopNow}
          className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-800 font-black text-xs transition-all shadow-md hover:shadow-amber-500/20 flex items-center gap-1.5 cursor-pointer"
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          <span>Shop Restocked Item</span>
        </button>
      </div>

      {/* Progress countdown bar */}
      <div className="absolute bottom-0 inset-x-0 h-1 bg-white/10 rounded-b-2xl overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 transition-all duration-100 ease-linear"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
};
