import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Bell,
  CheckCircle2,
  Mail,
  Phone,
  Sparkles,
  Zap,
  Layers,
  ShieldCheck,
  Smartphone,
  Trash2,
  ArrowRight,
  Info,
} from 'lucide-react';

export const StockAlertModal: React.FC = () => {
  const {
    isStockAlertModalOpen,
    closeStockAlertModal,
    activeStockAlertProduct,
    activeStockAlertVariantId,
    stockAlerts,
    subscribeToStockAlert,
    unsubscribeFromStockAlert,
    simulateStockReplenishmentPush,
    currentUserSession,
  } = useApp();

  const product = activeStockAlertProduct;

  const [selectedVariantId, setSelectedVariantId] = useState<string>('all');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [enablePush, setEnablePush] = useState<boolean>(true);
  const [enableEmail, setEnableEmail] = useState<boolean>(true);
  const [enableWhatsapp, setEnableWhatsapp] = useState<boolean>(false);
  const [pushPermissionStatus, setPushPermissionStatus] = useState<'granted' | 'default'>('granted');

  useEffect(() => {
    if (activeStockAlertProduct) {
      setSelectedVariantId(activeStockAlertVariantId || 'all');
      setEmail(currentUserSession.email || 'infotime.contact@gmail.com');
      setPhone(currentUserSession.phone || '+91 98490 22334');
      setEnablePush(true);
      setEnableEmail(true);
    }
  }, [activeStockAlertProduct, activeStockAlertVariantId, currentUserSession]);

  if (!isStockAlertModalOpen || !product) return null;

  // Check if existing subscription exists
  const existingAlert = stockAlerts.find(
    (a) =>
      a.productId === product.id &&
      (selectedVariantId === 'all' ? true : a.variantId === selectedVariantId || !a.variantId) &&
      a.status === 'active'
  );

  const selectedVariant = product.variants.find((v) => v.id === selectedVariantId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email && !phone && !enablePush) return;

    subscribeToStockAlert({
      productId: product.id,
      variantId: selectedVariantId === 'all' ? undefined : selectedVariantId,
      variantName:
        selectedVariantId === 'all'
          ? 'Any Size / Color'
          : `${selectedVariant?.color || ''} - ${selectedVariant?.size || ''}`.trim(),
      color: selectedVariant?.color,
      size: selectedVariant?.size,
      userEmail: email,
      userPhone: phone,
      enablePush,
      enableEmail,
      enableWhatsapp,
    });
  };

  const handleSimulateRestock = () => {
    simulateStockReplenishmentPush(
      product.id,
      selectedVariantId === 'all' ? undefined : selectedVariantId,
      25
    );
    closeStockAlertModal();
  };

  return (
    <div
      id="stock-alert-modal-overlay"
      className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in"
      onClick={closeStockAlertModal}
    >
      <div
        id="stock-alert-modal-card"
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 max-w-lg w-full shadow-2xl space-y-5 animate-in zoom-in-95 text-slate-900 dark:text-white max-h-[92vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3.5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-slate-800 font-black shadow-lg shadow-amber-500/20">
              <Bell className="w-5 h-5 text-slate-800 fill-slate-950" />
            </div>
            <div>
              <h3 className="text-base font-bold flex items-center gap-2">
                <span>Stock Alert Notification</span>
                <span className="px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-600 dark:text-rose-400 font-mono text-[10px] font-bold border border-rose-500/20">
                  Sold Out
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Get notified instantly via Web Push when this item returns to stock.
              </p>
            </div>
          </div>
          <button
            id="btn-close-stock-alert-modal"
            type="button"
            onClick={closeStockAlertModal}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Product Snapshot */}
        <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 flex items-center gap-3.5">
          <div className="relative w-16 h-20 rounded-xl overflow-hidden bg-slate-200 dark:bg-slate-700 shrink-0 border border-slate-300 dark:border-slate-600">
            <img
              src={product.images[0]}
              alt={product.name}
              className="w-full h-full object-cover grayscale-30"
            />
            <div className="absolute inset-0 bg-white/20 flex items-center justify-center">
              <span className="text-[9px] font-black uppercase text-white bg-rose-600/90 px-1.5 py-0.5 rounded">
                Out of Stock
              </span>
            </div>
          </div>
          <div className="flex-1 min-w-0">
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
              {product.brand}
            </span>
            <h4 className="text-sm font-bold truncate text-slate-900 dark:text-white mt-0.5">
              {product.name}
            </h4>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-sm font-extrabold text-slate-900 dark:text-white">
                ₹{product.price.toLocaleString('en-IN')}
              </span>
              {product.mrp > product.price && (
                <span className="text-xs text-slate-400 line-through">
                  ₹{product.mrp.toLocaleString('en-IN')}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Variant Picker */}
        {product.variants && product.variants.length > 0 && (
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-amber-500" />
              <span>Select Preferred Variant to Watch</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              <button
                type="button"
                id="btn-select-variant-all"
                onClick={() => setSelectedVariantId('all')}
                className={`p-2.5 rounded-xl border text-left text-xs font-semibold transition cursor-pointer flex flex-col justify-between ${
                  selectedVariantId === 'all'
                    ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-300 ring-2 ring-amber-500/20'
                    : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-400'
                }`}
              >
                <span>All Sizes & Colors</span>
                <span className="text-[10px] text-slate-400 font-mono mt-0.5">First available</span>
              </button>
              {product.variants.map((v) => (
                <button
                  key={v.id}
                  type="button"
                  id={`btn-select-variant-${v.id}`}
                  onClick={() => setSelectedVariantId(v.id)}
                  className={`p-2.5 rounded-xl border text-left text-xs font-semibold transition cursor-pointer flex flex-col justify-between ${
                    selectedVariantId === v.id
                      ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-300 ring-2 ring-amber-500/20'
                      : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-400'
                  }`}
                >
                  <span className="truncate">{v.color} - {v.size}</span>
                  <span className="text-[10px] font-mono text-rose-500">
                    {v.stock <= 0 ? 'Sold Out' : `${v.stock} in stock`}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Existing Subscription Active Banner */}
        {existingAlert && (
          <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-300 dark:border-emerald-800/60 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <h5 className="text-xs font-bold text-emerald-900 dark:text-emerald-200">
                You are currently on the Priority Restock List!
              </h5>
              <p className="text-[11px] text-emerald-700 dark:text-emerald-300 mt-0.5">
                Target: <strong>{existingAlert.variantName}</strong> &bull; Registered {existingAlert.subscribedAt}.
              </p>
              <div className="flex items-center gap-2 mt-2.5">
                <button
                  type="button"
                  id="btn-test-push-from-modal"
                  onClick={handleSimulateRestock}
                  className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Zap className="w-3.5 h-3.5 fill-white" />
                  <span>Simulate Restock & Push Alert</span>
                </button>
                <button
                  type="button"
                  id="btn-unsubscribe-from-modal"
                  onClick={() => unsubscribeFromStockAlert(product.id, existingAlert.variantId)}
                  className="px-2.5 py-1 bg-white dark:bg-slate-800 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800/60 rounded-lg text-xs font-semibold hover:bg-rose-50 dark:hover:bg-rose-950/40 transition flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Cancel Alert</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Channels Configuration Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2.5">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Notification Channels
            </label>

            {/* Web Push Notification Toggle Card */}
            <div
              onClick={() => setEnablePush(!enablePush)}
              className={`p-3.5 rounded-2xl border transition cursor-pointer flex items-center justify-between ${
                enablePush
                  ? 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-400 dark:border-amber-800/60'
                  : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 opacity-60'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-slate-900 dark:text-white">
                      Instant Web / Mobile Push Notification
                    </span>
                    <span className="px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[9px] font-bold">
                      Fastest
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Pops up on your device the millisecond inventory is updated
                  </p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={enablePush}
                onChange={(e) => setEnablePush(e.target.checked)}
                className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                onClick={(e) => e.stopPropagation()}
              />
            </div>

            {/* Email Channel Input */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-slate-300">
                <span className="flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  <span>Email Dispatch</span>
                </span>
                <label className="flex items-center gap-1.5 text-[11px] text-slate-400 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableEmail}
                    onChange={(e) => setEnableEmail(e.target.checked)}
                    className="w-3.5 h-3.5 accent-amber-500 rounded"
                  />
                  <span>Enable Email</span>
                </label>
              </div>
              <input
                type="email"
                id="stock-alert-email-input"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your.email@example.com"
                disabled={!enableEmail}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:border-amber-500 disabled:opacity-50"
              />
            </div>

            {/* WhatsApp / SMS Channel Input */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-slate-300">
                <span className="flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span>WhatsApp / SMS Instant Ping</span>
                </span>
                <label className="flex items-center gap-1.5 text-[11px] text-slate-400 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableWhatsapp}
                    onChange={(e) => setEnableWhatsapp(e.target.checked)}
                    className="w-3.5 h-3.5 accent-amber-500 rounded"
                  />
                  <span>Enable WhatsApp</span>
                </label>
              </div>
              <input
                type="tel"
                id="stock-alert-phone-input"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 98490 22334"
                disabled={!enableWhatsapp}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:border-amber-500 disabled:opacity-50"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center gap-2.5">
            <button
              id="btn-submit-stock-alert"
              type="submit"
              className="w-full sm:flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 font-black text-xs transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Bell className="w-4 h-4 text-slate-800 fill-slate-950" />
              <span>{existingAlert ? 'Update Stock Alert Settings' : 'Notify Me When in Stock'}</span>
            </button>

            <button
              id="btn-simulate-push-restock-now"
              type="button"
              onClick={handleSimulateRestock}
              className="w-full sm:w-auto py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 text-amber-400 font-bold text-xs border border-amber-500/30 transition flex items-center justify-center gap-1.5 cursor-pointer"
              title="Test the push notification simulation right now"
            >
              <Zap className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span>Test Push Alert Mock</span>
            </button>
          </div>
        </form>

        {/* Security & Privacy Assurance */}
        <div className="flex items-center gap-2 text-[11px] text-slate-400 justify-center">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
          <span>Zero spam guaranteed. We will only contact you when this exact item returns.</span>
        </div>
      </div>
    </div>
  );
};
