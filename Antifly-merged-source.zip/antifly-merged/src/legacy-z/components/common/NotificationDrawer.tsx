import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Bell,
  CheckCircle2,
  Tag,
  Package,
  Info,
  Clock,
  Sparkles,
  ArrowRight,
} from 'lucide-react';

export const NotificationDrawer: React.FC = () => {
  const {
    isNotificationDrawerOpen,
    setIsNotificationDrawerOpen,
    notifications,
    markNotificationsAsRead,
    setActiveTrackingOrder,
    setActivePdpId,
    orders,
  } = useApp();

  if (!isNotificationDrawerOpen) return null;

  const handleOpenOrder = (link?: string) => {
    if (orders.length > 0) {
      setActiveTrackingOrder(orders[0]);
      setIsNotificationDrawerOpen(false);
    }
  };

  const handleOpenProduct = (productId?: string) => {
    if (productId) {
      setActivePdpId(productId);
      setIsNotificationDrawerOpen(false);
    }
  };

  return (
    <div
      id="notification-drawer-overlay"
      className="fixed inset-0 z-50 bg-white/70 backdrop-blur-sm flex justify-end animate-fade-in"
    >
      <div
        id="notification-drawer-panel"
        className="w-full max-w-sm bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col border-l border-slate-200 dark:border-slate-800 animate-slide-in-right"
      >
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-amber-400" />
            <h2 className="font-bold text-base">Notifications</h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={markNotificationsAsRead}
              className="text-[11px] text-amber-400 hover:underline font-semibold"
            >
              Mark all as read
            </button>
            <button
              onClick={() => setIsNotificationDrawerOpen(false)}
              className="p-1 text-slate-400 hover:text-white rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {notifications.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <Bell className="w-10 h-10 mb-2 stroke-1" />
              <p className="text-sm font-semibold">No notifications right now</p>
            </div>
          ) : (
            notifications.map((n) => {
              const isOrder = n.type === 'order';
              const isPromo = n.type === 'promo';
              const isStockAlert = n.type === 'stock_alert';

              return (
                <div
                  key={n.id}
                  className={`p-3.5 rounded-xl border transition-all ${
                    !n.isRead
                      ? isStockAlert
                        ? 'bg-emerald-50/80 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800/70'
                        : 'bg-amber-50/70 dark:bg-amber-950/20 border-amber-300 dark:border-amber-900/60'
                      : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {n.image ? (
                      <img
                        src={n.image}
                        alt="Product"
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 rounded-lg object-cover border border-slate-200 dark:border-slate-700 flex-shrink-0"
                      />
                    ) : (
                      <div
                        className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                          isStockAlert
                            ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400'
                            : isOrder
                            ? 'bg-blue-500/10 text-blue-600'
                            : isPromo
                            ? 'bg-amber-500/10 text-amber-600'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {isStockAlert ? (
                          <Bell className="w-4 h-4 fill-emerald-500 text-emerald-500" />
                        ) : isOrder ? (
                          <Package className="w-4 h-4" />
                        ) : isPromo ? (
                          <Tag className="w-4 h-4" />
                        ) : (
                          <Info className="w-4 h-4" />
                        )}
                      </div>
                    )}

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="font-bold text-xs text-slate-900 dark:text-white truncate">
                          {n.title}
                        </h4>
                        {!n.isRead && (
                          <span
                            className={`w-2 h-2 rounded-full flex-shrink-0 ${
                              isStockAlert ? 'bg-emerald-500' : 'bg-amber-500'
                            }`}
                          />
                        )}
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                        {n.message}
                      </p>

                      <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-200/60 dark:border-slate-700/60 text-[10px] text-slate-500">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {n.timestamp}
                        </span>

                        {isOrder && (
                          <button
                            onClick={() => handleOpenOrder(n.link)}
                            className="font-bold text-amber-600 hover:text-amber-700 flex items-center gap-0.5 cursor-pointer"
                          >
                            <span>Track Package</span>
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        )}

                        {isStockAlert && n.productId && (
                          <button
                            onClick={() => handleOpenProduct(n.productId)}
                            className="font-bold text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 flex items-center gap-0.5 cursor-pointer"
                          >
                            <span>View Product</span>
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
