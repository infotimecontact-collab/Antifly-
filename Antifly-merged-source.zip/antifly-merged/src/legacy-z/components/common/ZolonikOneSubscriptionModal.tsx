import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Crown,
  X,
  CheckCircle2,
  Sparkles,
  UtensilsCrossed,
  Truck,
  Tv,
  Coins,
  CreditCard,
  Headphones,
  Zap,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';

export const AntiflyOneSubscriptionModal: React.FC = () => {
  const {
    isAntiflyOneModalOpen,
    setIsAntiflyOneModalOpen,
    antiflyOnePlans,
    antiflyOneSubscription,
    subscribeToAntiflyOne,
    setIsOTTModalOpen,
    setIsFoodDeliveryModalOpen,
  } = useApp();

  const [selectedPlanId, setSelectedPlanId] = useState<string>('wiseone-annual');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isAntiflyOneModalOpen) return null;

  const handleActivatePlan = async (planId: string) => {
    setIsProcessing(true);
    try {
      await subscribeToAntiflyOne(planId);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div
      id="wiseone-subscription-modal"
      className="fixed inset-0 z-50 bg-white/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 lg:p-6 animate-fade-in"
    >
      <div className="bg-white dark:bg-slate-900 w-full max-w-4xl rounded-3xl shadow-2xl border border-amber-300 dark:border-amber-900/40 overflow-hidden flex flex-col my-auto max-h-[94vh]">
        {/* VIP Golden Header */}
        <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-500 p-6 text-slate-800 relative overflow-hidden flex-shrink-0">
          <div className="absolute right-0 top-0 translate-x-8 -translate-y-8 opacity-20 pointer-events-none">
            <Crown className="w-56 h-56 text-slate-800" />
          </div>

          <div className="flex items-start justify-between relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center border border-slate-200/10 shadow-inner flex-shrink-0">
                <Crown className="w-8 h-8 text-slate-800" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase tracking-wider bg-white text-amber-300 px-2.5 py-0.5 rounded-full">
                    👑 All-In-One Super Subscription
                  </span>
                  {antiflyOneSubscription.isActive && (
                    <span className="text-[10px] font-bold bg-white/40 text-slate-800 px-2 py-0.5 rounded-full">
                      Active: {antiflyOneSubscription.planName}
                    </span>
                  )}
                </div>
                <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-800 mt-1">
                  AntiflyOne Master VIP Pass
                </h2>
                <p className="text-xs font-semibold text-slate-900/90 mt-0.5">
                  1 Pass = Free Food Delivery + Free Store Shipping + All 6 OTT Apps + 2x Coin Cashback + 0-Cost Bank EMI
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsAntiflyOneModalOpen(false)}
              className="w-9 h-9 rounded-full bg-white/15 hover:bg-white/30 text-slate-800 flex items-center justify-center transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Active Pass Stats Bar */}
          {antiflyOneSubscription.isActive && (
            <div className="mt-5 p-3.5 bg-white/10 backdrop-blur-md rounded-2xl border border-slate-200/15 flex flex-wrap items-center justify-between gap-4 text-xs font-bold text-slate-800">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-900" />
                <span>Total Lifetime Savings: ₹{antiflyOneSubscription.totalSavedSoFar}</span>
              </div>
              <div className="flex items-center gap-2">
                <UtensilsCrossed className="w-4 h-4 text-amber-900" />
                <span>{antiflyOneSubscription.freeDeliveriesUsed} Free Orders Delivered</span>
              </div>
              <div className="flex items-center gap-2">
                <Tv className="w-4 h-4 text-amber-900" />
                <span>6 OTT Apps Unlocked</span>
              </div>
              <div>
                <span>Valid Until: {antiflyOneSubscription.expiryDate}</span>
              </div>
            </div>
          )}
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-7 space-y-6">
          {/* 6-in-1 Value Highlights */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {[
              {
                icon: UtensilsCrossed,
                title: 'Free Food Delivery',
                desc: 'Unlimited ₹0 delivery on all Biryani, Pizza & dining orders',
                color: 'text-orange-500 bg-orange-50 dark:bg-orange-950/40',
              },
              {
                icon: Truck,
                title: 'Free Express Shipping',
                desc: 'Next-day delivery on all E-Commerce catalog products',
                color: 'text-blue-500 bg-blue-50 dark:bg-blue-950/40',
              },
              {
                icon: Tv,
                title: 'All-In-One OTT Access',
                desc: 'Netflix, Prime, Hotstar, SonyLIV, Zee5 & JioCinema bundle',
                color: 'text-pink-500 bg-pink-50 dark:bg-pink-950/40',
              },
              {
                icon: Coins,
                title: '2X ZoloCoins Multiplier',
                desc: 'Earn double coin cashback on every checkout & order',
                color: 'text-amber-500 bg-amber-50 dark:bg-amber-950/40',
              },
              {
                icon: CreditCard,
                title: 'No-Cost Bank EMI',
                desc: 'Zero processing fee & special interest waivers on all cards',
                color: 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/40',
              },
              {
                icon: Headphones,
                title: '24/7 VIP Concierge',
                desc: 'Direct priority resolution on WhatsApp & instant callbacks',
                color: 'text-indigo-500 bg-indigo-50 dark:bg-indigo-950/40',
              },
            ].map((feature, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-start gap-3"
              >
                <div className={`p-2 rounded-xl flex-shrink-0 ${feature.color}`}>
                  <feature.icon className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h4 className="font-extrabold text-slate-900 dark:text-white text-xs">
                    {feature.title}
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2">
                    {feature.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Subscription Plans Selection */}
          <div className="space-y-3">
            <h3 className="font-extrabold text-slate-900 dark:text-white text-sm uppercase tracking-wider text-stone-500">
              Select Your AntiflyOne VIP Plan
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {antiflyOnePlans.map((plan) => {
                const isSelected = selectedPlanId === plan.id;
                const isCurrentActive =
                  antiflyOneSubscription.isActive && antiflyOneSubscription.planId === plan.id;

                return (
                  <div
                    key={plan.id}
                    onClick={() => setSelectedPlanId(plan.id)}
                    className={`relative rounded-3xl p-5 border-2 transition cursor-pointer flex flex-col justify-between space-y-4 ${
                      isSelected
                        ? 'border-amber-500 bg-amber-50/40 dark:bg-amber-950/20 shadow-lg'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/40 hover:border-slate-300'
                    }`}
                  >
                    {plan.isPopular && (
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-amber-500 to-rose-500 text-slate-800 font-black text-[10px] uppercase tracking-wider px-3 py-0.5 rounded-full shadow">
                        {plan.badge}
                      </div>
                    )}

                    <div className="space-y-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="text-[11px] font-black uppercase text-amber-700 dark:text-amber-400">
                            {plan.duration}
                          </span>
                          <h4 className="font-extrabold text-slate-900 dark:text-white text-base">
                            {plan.name}
                          </h4>
                        </div>
                        {isSelected && (
                          <div className="w-5 h-5 rounded-full bg-amber-500 text-white flex items-center justify-center">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          </div>
                        )}
                      </div>

                      <div className="flex items-baseline gap-2">
                        <span className="text-2xl font-black text-slate-900 dark:text-white font-mono">
                          ₹{plan.price}
                        </span>
                        <span className="text-xs text-slate-400 line-through font-mono">
                          ₹{plan.originalPrice}
                        </span>
                        <span className="text-[10px] font-black bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 px-1.5 py-0.5 rounded">
                          SAVE {Math.round(((plan.originalPrice - plan.price) / plan.originalPrice) * 100)}%
                        </span>
                      </div>

                      <p className="text-xs text-slate-500 dark:text-slate-400">{plan.tagline}</p>
                    </div>

                    <div className="space-y-2 pt-3 border-t border-slate-100 dark:border-slate-700/60">
                      {plan.benefits.slice(0, 4).map((b, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-xs text-slate-700 dark:text-slate-300">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0 mt-0.5" />
                          <span>{b}</span>
                        </div>
                      ))}
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleActivatePlan(plan.id);
                      }}
                      disabled={isProcessing}
                      className={`w-full py-2.5 rounded-xl font-bold text-xs transition cursor-pointer flex items-center justify-center gap-1.5 ${
                        isCurrentActive
                          ? 'bg-emerald-600 text-white'
                          : isSelected
                          ? 'bg-amber-500 hover:bg-amber-400 text-slate-800 font-black shadow'
                          : 'bg-slate-100 dark:bg-slate-700 text-slate-900 dark:text-white hover:bg-slate-200'
                      }`}
                    >
                      {isCurrentActive ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Current Active Plan</span>
                        </>
                      ) : (
                        <>
                          <Crown className="w-3.5 h-3.5" />
                          <span>Activate Plan • ₹{plan.price}</span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* OTT Streaming Quick Launcher Section */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-indigo-950 text-white border border-indigo-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-pink-600 text-white px-2 py-0.5 rounded-full">
                  Included Free with AntiflyOne
                </span>
                <span className="text-xs text-indigo-200">6 OTT Streaming Platforms Ready</span>
              </div>
              <h4 className="text-base font-extrabold mt-1">
                Stream Blockbuster Movies & Live Cricket Matches
              </h4>
              <p className="text-xs text-indigo-300">
                Netflix • Prime Video • Disney+ Hotstar • SonyLIV • Zee5 • JioCinema
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setIsAntiflyOneModalOpen(false);
                  setIsOTTModalOpen(true);
                }}
                className="px-4 py-2 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white text-xs font-black rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
              >
                <Tv className="w-3.5 h-3.5" />
                <span>Open OTT Stream Lounge</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
