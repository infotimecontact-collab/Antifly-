import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { Mic, MicOff, X, Sparkles, Volume2, ArrowRight, ShoppingBag } from 'lucide-react';
import { Product } from '../../types';

export const VoiceSearchModal: React.FC = () => {
  const {
    isVoiceSearchOpen,
    setIsVoiceSearchOpen,
    products,
    setActivePdpId,
    addToCart,
    setSearchQuery,
    setSelectedCategorySlug,
  } = useApp();

  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [parsedResult, setParsedResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const samplePrompts = [
    '1500 ke andar black oversized t-shirt dikhao',
    'Find white linen Cuban shirts for summer',
    'Show running sneakers below 2000 rupees',
    'Casual watches for office under 2500',
  ];

  // Start listening automatically on open
  useEffect(() => {
    if (isVoiceSearchOpen) {
      startListening();
    } else {
      setIsListening(false);
      setTranscript('');
      setParsedResult(null);
    }
  }, [isVoiceSearchOpen]);

  const startListening = () => {
    setIsListening(true);
    setTranscript('');
    setParsedResult(null);

    // Check if webkitSpeechRecognition or SpeechRecognition is available
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      try {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = true;
        recognition.lang = 'en-IN'; // Indian English / Hindi mix

        recognition.onresult = (event: any) => {
          const current = event.resultIndex;
          const text = event.results[current][0].transcript;
          setTranscript(text);
          if (event.results[current].isFinal) {
            recognition.stop();
            setIsListening(false);
            processVoiceQuery(text);
          }
        };

        recognition.onerror = () => {
          setIsListening(false);
        };

        recognition.start();
      } catch (e) {
        console.warn('Speech recognition fallback:', e);
      }
    }
  };

  const processVoiceQuery = async (queryText: string) => {
    if (!queryText.trim()) return;
    setLoading(true);

    try {
      const res = await fetch('/api/wiseai/voice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transcript: queryText }),
      });
      const data = await res.json();
      setParsedResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSimulateVoice = (promptText: string) => {
    setTranscript(promptText);
    setIsListening(false);
    processVoiceQuery(promptText);
  };

  if (!isVoiceSearchOpen) return null;

  const matchedProducts: Product[] = parsedResult?.matchedProductIds
    ? products.filter((p) => parsedResult.matchedProductIds.includes(p.id))
    : [];

  return (
    <div
      id="voice-search-modal-overlay"
      className="fixed inset-0 z-50 bg-white/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fade-in"
    >
      <div className="bg-white dark:bg-slate-900 w-full max-w-xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400">
              <Mic className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm tracking-wide">Multilingual Voice Search</h3>
              <p className="text-[11px] text-slate-400">Supports English, Hindi & Hinglish</p>
            </div>
          </div>
          <button
            onClick={() => setIsVoiceSearchOpen(false)}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Center Mic & Wave Area */}
        <div className="p-6 text-center bg-slate-50/50 dark:bg-white/50 flex flex-col items-center">
          <div className="relative my-4">
            {isListening && (
              <div className="absolute -inset-4 rounded-full bg-amber-500/20 animate-ping" />
            )}
            <button
              onClick={isListening ? () => setIsListening(false) : startListening}
              className={`relative z-10 w-20 h-20 rounded-full flex items-center justify-center transition-all shadow-xl ${
                isListening
                  ? 'bg-gradient-to-tr from-rose-500 to-orange-500 text-white scale-105'
                  : 'bg-gradient-to-tr from-amber-500 to-orange-600 text-white hover:scale-105'
              }`}
            >
              {isListening ? <Mic className="w-8 h-8 animate-pulse" /> : <MicOff className="w-8 h-8" />}
            </button>
          </div>

          <p className="font-semibold text-slate-800 dark:text-slate-200 text-sm">
            {isListening
              ? 'Listening... Speak naturally in English or Hindi'
              : transcript
              ? `"${transcript}"`
              : 'Tap microphone to speak'}
          </p>

          {/* Quick Voice Prompt Shortcuts */}
          <div className="mt-4 flex flex-wrap justify-center gap-1.5 max-w-md">
            <span className="text-[11px] text-slate-400 w-full mb-1">Try saying or tap to test:</span>
            {samplePrompts.map((p, i) => (
              <button
                key={i}
                onClick={() => handleSimulateVoice(p)}
                className="text-[11px] bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:text-amber-600 dark:hover:text-amber-400 hover:border-amber-400 px-2.5 py-1 rounded-full border border-slate-200 dark:border-slate-700 shadow-sm transition-all"
              >
                "{p}"
              </button>
            ))}
          </div>

          {loading && (
            <div className="mt-4 flex items-center gap-2 text-xs text-amber-600 dark:text-amber-400">
              <Sparkles className="w-4 h-4 animate-spin" />
              <span>AntiflyAI is parsing language intent & catalog match...</span>
            </div>
          )}
        </div>

        {/* Parsed Output & Products */}
        {parsedResult && (
          <div className="p-5 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
            {/* Intent badges */}
            <div className="flex flex-wrap items-center gap-2 mb-3 text-xs">
              <span className="bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 px-2.5 py-1 rounded-md font-medium border border-amber-200 dark:border-amber-900/50">
                Language: {parsedResult.detectedLanguage || 'Hinglish'}
              </span>
              {parsedResult.maxPrice && (
                <span className="bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 px-2.5 py-1 rounded-md font-medium border border-emerald-200 dark:border-emerald-900/50">
                  Budget: Up to ₹{parsedResult.maxPrice.toLocaleString('en-IN')}
                </span>
              )}
              {parsedResult.extractedColor && parsedResult.extractedColor !== 'Any' && (
                <span className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2.5 py-1 rounded-md font-medium">
                  Color: {parsedResult.extractedColor}
                </span>
              )}
            </div>

            {/* Product list */}
            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {matchedProducts.length > 0 ? (
                matchedProducts.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => {
                      setActivePdpId(p.id);
                      setIsVoiceSearchOpen(false);
                    }}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex items-center justify-between hover:border-amber-400 cursor-pointer transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <img src={p.images[0]} alt={p.name} className="w-12 h-12 rounded-lg object-cover" />
                      <div>
                        <h4 className="font-semibold text-xs text-slate-900 dark:text-white line-clamp-1">
                          {p.name}
                        </h4>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          {p.brand} &bull; ₹{p.price.toLocaleString('en-IN')}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        addToCart({
                          productId: p.id,
                          variantId: p.variants[0]?.id || 'default',
                          productName: p.name,
                          brand: p.brand,
                          color: p.colors[0]?.name || 'Standard',
                          size: p.sizes[0] || 'Standard',
                          price: p.price,
                          mrp: p.mrp,
                          image: p.images[0],
                          quantity: 1,
                          stock: p.totalStock,
                        });
                      }}
                      className="p-1.5 bg-amber-500 hover:bg-amber-600 text-slate-800 rounded-lg text-xs font-semibold flex items-center gap-1"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      Add
                    </button>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-500 text-center py-3">No direct matches found.</p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
