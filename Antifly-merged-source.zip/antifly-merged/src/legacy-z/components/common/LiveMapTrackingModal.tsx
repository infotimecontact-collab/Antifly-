import React, { useState, useEffect } from 'react';
import {
  X,
  Navigation,
  MapPin,
  Truck,
  Phone,
  Clock,
  ShieldCheck,
  CheckCircle,
  Package,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const LiveMapTrackingModal: React.FC = () => {
  const { isLiveMapOpen, setIsLiveMapOpen, activeMapTracking, formatPrice, orders } = useApp();
  const [activeStep, setActiveStep] = useState(2);
  const [simulatedEta, setSimulatedEta] = useState(22);

  useEffect(() => {
    if (activeMapTracking) {
      setActiveStep(activeMapTracking.currentStepIndex);
      setSimulatedEta(activeMapTracking.etaMinutes);
    }
  }, [activeMapTracking]);

  // Live ETA heartbeat
  useEffect(() => {
    if (!isLiveMapOpen) return;
    const interval = setInterval(() => {
      setSimulatedEta((prev) => (prev > 5 ? prev - 1 : 18));
    }, 15000);
    return () => clearInterval(interval);
  }, [isLiveMapOpen]);

  if (!isLiveMapOpen || !activeMapTracking) return null;

  const tracking = activeMapTracking;
  const relatedOrder = orders.find((o) => o.id === tracking.orderId);

  const steps = [
    { label: 'Origin Fulfillment Hub', detail: tracking.originHub.name, city: tracking.originHub.city, done: activeStep >= 0 },
    { label: 'Air / Transit Hub', detail: tracking.transitHub.name, city: tracking.transitHub.city, done: activeStep >= 1 },
    { label: 'Local Dispatch Hub', detail: tracking.deliveryHub.name, city: tracking.deliveryHub.city, done: activeStep >= 2 },
    { label: 'Destination Doorstep', detail: tracking.destination.name, city: tracking.destination.city, done: activeStep >= 3 },
  ];

  return (
    <div
      id="live-map-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-stone-900/60 backdrop-blur-sm overflow-y-auto"
    >
      <div
        id="live-map-modal-container"
        className="bg-white border border-stone-200 rounded-2xl shadow-2xl w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-stone-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center text-amber-800">
              <Navigation className="w-5 h-5 animate-pulse text-amber-700" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-stone-900">Live GPS Route & Logistics Tracking</h2>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></span>
                  LIVE GPS
                </span>
              </div>
              <p className="text-xs text-stone-500 font-mono">
                {tracking.courierName} • Waybill #{tracking.trackingNumber}
              </p>
            </div>
          </div>
          <button
            id="live-map-close-btn"
            type="button"
            onClick={() => setIsLiveMapOpen(false)}
            className="p-2 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body: Map on Left / Details on Right */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-y-auto">
          {/* Visual Interactive SVG Map Canvas */}
          <div className="lg:col-span-7 bg-stone-100 p-4 sm:p-6 flex flex-col relative min-h-[380px] border-b lg:border-b-0 lg:border-r border-stone-200">
            {/* Map Top Status Bar */}
            <div className="bg-white/95 backdrop-blur-sm border border-stone-200 rounded-xl p-3 shadow-sm mb-4 flex items-center justify-between z-10">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-amber-50 text-amber-800">
                  <Truck className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-[11px] text-stone-500 font-medium">Estimated Arrival</p>
                  <p className="text-sm font-extrabold text-stone-900">{simulatedEta} Minutes</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-[11px] text-stone-500 font-medium">Current Location</p>
                <p className="text-xs font-bold text-amber-800 truncate max-w-[180px]">{tracking.currentLocation.address}</p>
              </div>
            </div>

            {/* Custom Interactive SVG Schematic Map */}
            <div className="relative flex-1 bg-stone-50 rounded-2xl border border-stone-200 overflow-hidden shadow-inner p-4 flex items-center justify-center">
              {/* Map grid background pattern */}
              <div
                className="absolute inset-0 opacity-40"
                style={{
                  backgroundImage: `radial-gradient(#d6d3d1 1px, transparent 1px)`,
                  backgroundSize: '20px 20px',
                }}
              />

              {/* Schematic Route Graphics */}
              <svg className="w-full h-full min-h-[260px]" viewBox="0 0 450 260" fill="none">
                {/* Roads / Highway lines */}
                <path d="M 40 200 Q 150 140 225 130 T 410 60" stroke="#e7e5e4" strokeWidth="18" strokeLinecap="round" />
                <path d="M 40 200 Q 150 140 225 130 T 410 60" stroke="#f59e0b" strokeWidth="4" strokeDasharray="8 6" className="animate-pulse" />

                {/* Secondary arterial streets */}
                <path d="M 120 230 L 225 130 L 260 210" stroke="#e7e5e4" strokeWidth="6" strokeLinecap="round" />
                <path d="M 225 130 L 320 70 L 380 180" stroke="#e7e5e4" strokeWidth="6" strokeLinecap="round" />

                {/* Node 1: Origin */}
                <g transform="translate(40, 200)">
                  <circle r="14" fill="#fef3c7" stroke="#d97706" strokeWidth="3" />
                  <circle r="6" fill="#b45309" />
                  <text y="28" textAnchor="middle" fontSize="10" fontWeight="bold" fill="#78350f">
                    Hub (Origin)
                  </text>
                </g>

                {/* Node 2: Regional Transit */}
                <g transform="translate(180, 145)">
                  <circle r="10" fill="#fef3c7" stroke="#d97706" strokeWidth="2" />
                  <circle r="4" fill="#b45309" />
                  <text y="-14" textAnchor="middle" fontSize="9" fontWeight="600" fill="#78350f">
                    Regional Sort
                  </text>
                </g>

                {/* Node 3: Local Dispatch Hub */}
                <g transform="translate(290, 100)">
                  <circle r="10" fill="#fef3c7" stroke="#d97706" strokeWidth="2" />
                  <circle r="4" fill="#b45309" />
                  <text y="-14" textAnchor="middle" fontSize="9" fontWeight="600" fill="#78350f">
                    Local Hub
                  </text>
                </g>

                {/* Live Delivery Vehicle (Animated Position along line) */}
                <g transform="translate(345, 82)">
                  <circle r="18" fill="#10b981" fillOpacity="0.2" className="animate-ping" />
                  <circle r="14" fill="#047857" stroke="#ffffff" strokeWidth="2.5" />
                  <circle r="5" fill="#ffffff" />
                  <text y="28" textAnchor="middle" fontSize="10" fontWeight="bold" fill="#065f46">
                    Courier Moving
                  </text>
                </g>

                {/* Node 4: Destination */}
                <g transform="translate(410, 60)">
                  <circle r="16" fill="#fee2e2" stroke="#dc2626" strokeWidth="3" />
                  <circle r="6" fill="#b91c1c" />
                  <text y="30" textAnchor="middle" fontSize="10" fontWeight="bold" fill="#991b1b">
                    Customer
                  </text>
                </g>
              </svg>

              {/* Floating Map Legend */}
              <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-sm border border-stone-200 rounded-lg px-2.5 py-1.5 text-[10px] text-stone-600 flex items-center gap-3">
                <span className="flex items-center gap-1 font-medium">
                  <span className="w-2 h-2 rounded-full bg-amber-500"></span> Logistics Hubs
                </span>
                <span className="flex items-center gap-1 font-medium">
                  <span className="w-2 h-2 rounded-full bg-emerald-600"></span> Live Courier
                </span>
                <span className="flex items-center gap-1 font-medium">
                  <span className="w-2 h-2 rounded-full bg-rose-600"></span> Destination
                </span>
              </div>
            </div>

            {/* Rider Contact Card */}
            <div className="mt-4 bg-white border border-stone-200 rounded-xl p-3.5 flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-800 font-bold flex items-center justify-center text-sm border border-amber-200">
                  {tracking.riderName.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-bold text-stone-900">{tracking.riderName}</p>
                    <span className="text-[10px] px-1.5 py-0.2 bg-stone-100 text-stone-600 rounded">
                      Verified Delivery Buddy
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-500">
                    Vehicle: {tracking.vehicleNumber} ({tracking.vehicleType.toUpperCase()})
                  </p>
                </div>
              </div>

              <a
                href={`tel:${tracking.riderPhone}`}
                id="call-rider-btn"
                className="flex items-center gap-1.5 px-3 py-1.5 bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold rounded-lg transition-colors shadow-sm"
              >
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <span>Call Buddy</span>
              </a>
            </div>
          </div>

          {/* Right Panel: Step By Step Milestones & Order Overview */}
          <div className="lg:col-span-5 p-6 flex flex-col justify-between space-y-6 bg-white">
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider text-amber-800">
                  Logistics Milestones
                </h3>
                <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  On Schedule
                </span>
              </div>

              {/* Milestone Timeline */}
              <div className="space-y-4 relative before:absolute before:left-3.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-stone-200">
                {steps.map((step, idx) => {
                  const isCurrent = idx === activeStep;
                  return (
                    <div key={idx} className="relative flex items-start gap-3.5 pl-1">
                      <div
                        className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold z-10 shrink-0 ${
                          step.done
                            ? 'bg-amber-600 text-white'
                            : isCurrent
                            ? 'bg-emerald-600 text-white animate-bounce'
                            : 'bg-stone-100 text-stone-400 border border-stone-300'
                        }`}
                      >
                        {step.done ? <CheckCircle className="w-3.5 h-3.5" /> : idx + 1}
                      </div>
                      <div className="flex-1 -mt-0.5">
                        <div className="flex items-center justify-between">
                          <p
                            className={`text-xs font-bold ${
                              isCurrent ? 'text-stone-900' : step.done ? 'text-stone-800' : 'text-stone-400'
                            }`}
                          >
                            {step.label}
                          </p>
                          {isCurrent && (
                            <span className="text-[10px] text-amber-700 font-bold bg-amber-50 px-1.5 py-0.2 rounded border border-amber-200">
                              Current Hub
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-stone-600">{step.detail}</p>
                        <p className="text-[10px] text-stone-400">{step.city}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Related Order Card */}
            {relatedOrder && (
              <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-stone-200 pb-2">
                  <span className="text-[11px] font-bold text-stone-700">Order Package Details</span>
                  <span className="text-xs font-bold text-amber-800">
                    {formatPrice(relatedOrder.totalAmount)}
                  </span>
                </div>
                <div className="space-y-1.5">
                  {relatedOrder.items.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between text-xs">
                      <span className="text-stone-700 font-medium truncate max-w-[180px]">
                        {item.quantity}x {item.productName}
                      </span>
                      <span className="text-stone-500 font-mono text-[11px]">
                        {formatPrice(item.price * item.quantity)}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="pt-2 border-t border-stone-200/80 flex items-center justify-between text-[11px] text-stone-500">
                  <span>Guaranteed SLA:</span>
                  <span className="font-semibold text-stone-800">5-Day Instant Refund Protected</span>
                </div>
              </div>
            )}

            {/* Safety & Compliance Badge */}
            <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl flex items-start gap-2.5 text-xs text-amber-900">
              <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <p className="text-[11px] leading-relaxed">
                Antifly contactless delivery protocol active. OTP validation is requested upon doorstep arrival.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
