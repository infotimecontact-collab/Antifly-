import React from 'react';

/**
 * Shimmering Product Card Skeleton for visual feedback while data is loading
 */
export const ProductCardSkeleton: React.FC<{ isCompact?: boolean }> = ({ isCompact = false }) => {
  return (
    <div className="group relative bg-white dark:bg-slate-900 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 animate-pulse flex flex-col">
      {/* Image Skeleton */}
      <div className="relative aspect-[4/5] w-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
        {/* Shimmer gradient */}
        <div className="absolute inset-0 -translate-x-full animate-[shimmer_1.5s_infinite] bg-gradient-to-r from-transparent via-white/20 dark:via-white/5 to-transparent" />

        {/* Badge Skeletons */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5 z-10">
          <div className="w-14 h-4 bg-slate-300 dark:bg-slate-700 rounded" />
          <div className="w-16 h-4 bg-slate-300 dark:bg-slate-700 rounded" />
        </div>

        {/* Action icons skeleton */}
        <div className="absolute top-2.5 right-2.5 flex flex-col gap-1.5 z-10">
          <div className="w-8 h-8 rounded-full bg-slate-300/80 dark:bg-slate-700/80" />
          <div className="w-8 h-8 rounded-full bg-slate-300/80 dark:bg-slate-700/80" />
        </div>
      </div>

      {/* Social Action Bar Skeleton */}
      <div className="px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-3.5 bg-slate-200 dark:bg-slate-700 rounded" />
          <div className="w-5 h-3.5 bg-slate-200 dark:bg-slate-700 rounded" />
          <div className="w-5 h-3.5 bg-slate-200 dark:bg-slate-700 rounded" />
        </div>
        <div className="w-4 h-4 bg-slate-200 dark:bg-slate-700 rounded" />
      </div>

      {/* Details Skeleton */}
      <div className="p-3.5 flex-1 flex flex-col justify-between space-y-3">
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="w-20 h-3 bg-slate-200 dark:bg-slate-700 rounded" />
            <div className="w-10 h-3 bg-slate-200 dark:bg-slate-700 rounded" />
          </div>
          <div className="w-full h-4 bg-slate-300 dark:bg-slate-700 rounded mb-1.5" />
          <div className="w-3/4 h-3 bg-slate-200 dark:bg-slate-700 rounded" />

          {/* Color Dots Skeleton */}
          <div className="flex items-center gap-1.5 mt-3">
            <div className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />
            <div className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />
            <div className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />
          </div>
        </div>

        {/* Pricing Skeleton */}
        <div className="pt-2.5 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
          <div className="flex items-baseline gap-2">
            <div className="w-16 h-5 bg-slate-300 dark:bg-slate-700 rounded font-bold" />
            <div className="w-10 h-3.5 bg-slate-200 dark:bg-slate-800 rounded" />
          </div>
          <div className="w-14 h-3.5 bg-slate-200 dark:bg-slate-700 rounded" />
        </div>
      </div>
    </div>
  );
};

/**
 * Category Item Skeleton
 */
export const CategorySkeleton: React.FC = () => {
  return (
    <div className="p-3 sm:p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 animate-pulse flex flex-col items-center text-center">
      <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-slate-200 dark:bg-slate-700 mb-3" />
      <div className="w-16 h-3.5 bg-slate-300 dark:bg-slate-600 rounded mb-1" />
      <div className="w-12 h-2.5 bg-slate-200 dark:bg-slate-700 rounded" />
    </div>
  );
};

/**
 * Lookbook / Style Cast Skeleton
 */
export const LookbookCardSkeleton: React.FC = () => {
  return (
    <div className="rounded-3xl bg-slate-900 border border-slate-800 animate-pulse relative h-[360px] p-4 flex flex-col justify-between overflow-hidden">
      <div className="flex justify-between items-center">
        <div className="w-20 h-5 bg-slate-800 rounded-full" />
        <div className="w-16 h-5 bg-slate-800 rounded-full" />
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-slate-800" />
          <div className="space-y-1">
            <div className="w-16 h-3 bg-slate-800 rounded" />
            <div className="w-12 h-2 bg-slate-850 rounded" />
          </div>
        </div>
        <div className="w-full h-4 bg-slate-800 rounded" />
        <div className="w-2/3 h-4 bg-slate-800 rounded" />
      </div>
    </div>
  );
};

/**
 * Nearby Product Card Skeleton
 */
export const NearbyProductCardSkeleton: React.FC = () => {
  return (
    <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 animate-pulse flex flex-col justify-between space-y-3">
      <div className="flex items-center justify-between">
        <div className="w-24 h-4 bg-slate-200 dark:bg-slate-700 rounded-full" />
        <div className="w-14 h-4 bg-slate-200 dark:bg-slate-700 rounded-full" />
      </div>

      <div className="flex gap-3">
        <div className="w-16 h-16 rounded-xl bg-slate-200 dark:bg-slate-700 shrink-0" />
        <div className="flex-1 space-y-2">
          <div className="w-3/4 h-3.5 bg-slate-300 dark:bg-slate-600 rounded" />
          <div className="w-1/2 h-3 bg-slate-200 dark:bg-slate-700 rounded" />
          <div className="w-1/3 h-4 bg-slate-300 dark:bg-slate-600 rounded" />
        </div>
      </div>

      <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
        <div className="w-20 h-3 bg-slate-200 dark:bg-slate-700 rounded" />
        <div className="w-16 h-6 bg-slate-200 dark:bg-slate-700 rounded-lg" />
      </div>
    </div>
  );
};
