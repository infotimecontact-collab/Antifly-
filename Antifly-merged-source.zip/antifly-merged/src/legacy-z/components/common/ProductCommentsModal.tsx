import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Heart,
  Send,
  Sparkles,
  MessageCircle,
  ThumbsUp,
  AlertCircle,
  CheckCircle2,
  Share2,
  ShieldCheck,
  Smile,
  Store,
} from 'lucide-react';

export const ProductCommentsModal: React.FC = () => {
  const {
    activeCommentsProductId,
    setActiveCommentsProductId,
    isProductCommentsOpen,
    setIsProductCommentsOpen,
    products,
    productComments,
    addProductComment,
    likeProductComment,
    toggleLikeProduct,
    isProductLiked,
    getProductLikeCount,
    toggleSaveProductSocial,
    isProductSavedSocial,
    setActiveShareProduct,
    setIsProductShareOpen,
    openSellerStorefront,
    sellers,
  } = useApp();

  const [commentInput, setCommentInput] = useState('');
  const [selectedQuickChip, setSelectedQuickChip] = useState<string | null>(null);

  if (!isProductCommentsOpen || !activeCommentsProductId) return null;

  const product = products.find((p) => p.id === activeCommentsProductId);
  if (!product) return null;

  const comments = productComments[product.id] || [];
  const isLiked = isProductLiked(product.id);
  const likeCount = getProductLikeCount(product.id);
  const isSaved = isProductSavedSocial(product.id);

  const matchedSeller = sellers.find(
    (s) =>
      s.storeName.toLowerCase() === product.brand.toLowerCase() ||
      product.tags.includes(s.storeName) ||
      product.brand.toLowerCase().includes(s.storeName.toLowerCase())
  ) || sellers[0];

  const quickSentimentTemplates = [
    {
      label: 'This product is good.',
      text: 'This product is good. High quality and matches description perfectly!',
      type: 'good' as const,
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100',
      icon: '✨',
    },
    {
      label: 'This product is not good.',
      text: 'This product is not good. Size was slightly different than expected.',
      type: 'not_good' as const,
      color: 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100',
      icon: '⚠️',
    },
    {
      label: 'This is a bad product.',
      text: 'This is a bad product for rough outdoor use, handle with extra care.',
      type: 'bad' as const,
      color: 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100',
      icon: '👎',
    },
    {
      label: "Don't buy it.",
      text: "Don't buy it if you need immediate overnight delivery, takes 2 days for artisan craft.",
      type: 'dont_buy' as const,
      color: 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200',
      icon: '🛑',
    },
  ];

  const handlePost = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!commentInput.trim()) return;

    let reactionType: 'good' | 'not_good' | 'bad' | 'dont_buy' | 'custom' = 'custom';
    if (commentInput.includes('is good')) reactionType = 'good';
    else if (commentInput.includes('not good')) reactionType = 'not_good';
    else if (commentInput.includes('bad product')) reactionType = 'bad';
    else if (commentInput.includes("Don't buy") || commentInput.includes("don't buy")) reactionType = 'dont_buy';

    addProductComment(product.id, commentInput, reactionType);
    setCommentInput('');
    setSelectedQuickChip(null);
  };

  const handleQuickTemplateClick = (item: typeof quickSentimentTemplates[0]) => {
    setSelectedQuickChip(item.label);
    setCommentInput(item.text);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-white/60 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
      <div
        id="product-comments-modal-container"
        className="bg-white rounded-t-2xl sm:rounded-2xl w-full max-w-lg max-h-[90vh] sm:max-h-[85vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden text-slate-800"
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-white sticky top-0 z-10">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-50 text-amber-600 rounded-full">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 leading-tight">Comments & Reactions</h2>
              <p className="text-xs text-slate-500">{comments.length} verified community reviews</p>
            </div>
          </div>
          <button
            id="close-comments-modal-btn"
            onClick={() => setIsProductCommentsOpen(false)}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Product Snippet Banner */}
        <div className="p-3 bg-slate-50/80 border-b border-slate-100 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <img
              src={product.images[0]}
              alt={product.name}
              className="w-12 h-12 rounded-lg object-cover border border-slate-200 shrink-0"
            />
            <div className="min-w-0">
              <p className="text-xs font-semibold text-slate-900 truncate">{product.name}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-xs font-bold text-orange-600">₹{product.price.toLocaleString('en-IN')}</span>
                <span className="text-[11px] text-slate-400">by</span>
                <button
                  onClick={() => {
                    setIsProductCommentsOpen(false);
                    if (matchedSeller) openSellerStorefront(matchedSeller.id);
                  }}
                  className="text-[11px] font-semibold text-slate-700 hover:text-orange-600 flex items-center gap-1 truncate"
                >
                  <Store className="w-3 h-3 text-amber-600" />
                  {product.brand}
                </button>
              </div>
            </div>
          </div>

          {/* Social icons in snippet */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => toggleLikeProduct(product.id)}
              className={`p-2 rounded-full border transition-all ${
                isLiked
                  ? 'bg-rose-50 border-rose-200 text-rose-500'
                  : 'bg-white border-slate-200 text-slate-600 hover:text-rose-500'
              }`}
              title={isLiked ? 'Unlike' : 'Like'}
            >
              <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-500' : ''}`} />
            </button>
            <button
              onClick={() => {
                setActiveShareProduct(product);
                setIsProductShareOpen(true);
              }}
              className="p-2 rounded-full border border-slate-200 bg-white text-slate-600 hover:text-orange-600 transition-all"
              title="Share"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Quick Reaction Sentiment Chips */}
        <div className="px-4 py-2.5 bg-white border-b border-slate-100">
          <p className="text-[11px] font-bold tracking-wider uppercase text-slate-400 mb-1.5">
            Quick 1-Tap Sentiment Options
          </p>
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {quickSentimentTemplates.map((item, idx) => (
              <button
                key={idx}
                id={`quick-sentiment-${item.type}`}
                type="button"
                onClick={() => handleQuickTemplateClick(item)}
                className={`text-xs px-2.5 py-1 rounded-full border shrink-0 transition-all font-medium flex items-center gap-1 ${
                  selectedQuickChip === item.label
                    ? 'ring-2 ring-orange-500 ring-offset-1 ' + item.color
                    : item.color
                }`}
              >
                <span>{item.icon}</span>
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Comments Feed */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 divide-y divide-slate-100">
          {comments.length === 0 ? (
            <div className="text-center py-10">
              <MessageCircle className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-700">No comments yet on this product</p>
              <p className="text-xs text-slate-400 mt-1">
                Be the first to share whether this product is good or what to look out for!
              </p>
            </div>
          ) : (
            comments.map((comment) => (
              <div key={comment.id} className="pt-3 first:pt-0 flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <img
                    src={comment.userAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                    alt={comment.userName}
                    className="w-8 h-8 rounded-full object-cover border border-slate-200 shrink-0 mt-0.5"
                  />
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold text-slate-900">{comment.userName}</span>
                      {comment.userRole && (
                        <span
                          className={`text-[10px] font-semibold px-1.5 py-0.2 rounded ${
                            comment.userRole === 'Verified Buyer'
                              ? 'bg-emerald-50 text-emerald-700'
                              : comment.userRole === 'Seller'
                              ? 'bg-amber-50 text-amber-800'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {comment.userRole}
                        </span>
                      )}
                      <span className="text-[11px] text-slate-400">{comment.timestamp}</span>
                    </div>

                    <p className="text-xs text-slate-700 leading-relaxed">{comment.text}</p>

                    {/* Replies if any */}
                    {comment.replies && comment.replies.length > 0 && (
                      <div className="mt-2 pl-3 border-l-2 border-slate-200 space-y-2">
                        {comment.replies.map((reply) => (
                          <div key={reply.id} className="flex items-start gap-2">
                            <img
                              src={reply.userAvatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100'}
                              alt={reply.userName}
                              className="w-6 h-6 rounded-full object-cover shrink-0"
                            />
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="text-[11px] font-bold text-slate-900">{reply.userName}</span>
                                <span className="text-[10px] text-slate-400">{reply.timestamp}</span>
                              </div>
                              <p className="text-[11px] text-slate-600">{reply.text}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Heart / Like action on comment */}
                <button
                  onClick={() => likeProductComment(product.id, comment.id)}
                  className="flex flex-col items-center gap-0.5 text-slate-400 hover:text-rose-500 p-1 shrink-0 transition-colors"
                >
                  <Heart
                    className={`w-3.5 h-3.5 ${
                      comment.isLikedByMe ? 'fill-rose-500 text-rose-500' : 'text-slate-400'
                    }`}
                  />
                  <span className="text-[10px] font-medium">{comment.likesCount}</span>
                </button>
              </div>
            ))
          )}
        </div>

        {/* Comment Input Footer */}
        <form onSubmit={handlePost} className="p-3 border-t border-slate-100 bg-white flex items-center gap-2">
          <input
            type="text"
            id="product-comment-input-field"
            value={commentInput}
            onChange={(e) => setCommentInput(e.target.value)}
            placeholder="Add an Instagram comment... (e.g. This product is good)"
            className="flex-1 bg-slate-100 hover:bg-slate-100/80 focus:bg-white text-xs px-3.5 py-2.5 rounded-full border border-transparent focus:border-orange-500 outline-none transition-all placeholder:text-slate-400 text-slate-800"
          />
          <button
            type="submit"
            id="submit-product-comment-btn"
            disabled={!commentInput.trim()}
            className="p-2.5 bg-orange-600 hover:bg-orange-700 disabled:opacity-40 disabled:hover:bg-orange-600 text-white rounded-full transition-all shadow-sm shrink-0"
            title="Send Comment"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
