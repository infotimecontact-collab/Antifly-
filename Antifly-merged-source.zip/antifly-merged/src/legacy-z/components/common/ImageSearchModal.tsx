import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { Camera, Upload, X, Sparkles, Image as ImageIcon, CheckCircle, ShoppingBag } from 'lucide-react';
import { Product } from '../../types';

export const ImageSearchModal: React.FC = () => {
  const { isImageSearchOpen, setIsImageSearchOpen, products, setActivePdpId, addToCart } = useApp();

  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const sampleOutfitImages = [
    {
      name: 'Beige Cuban Shirt',
      url: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400&auto=format&fit=crop&q=80',
    },
    {
      name: 'Black Minimalist Tee',
      url: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=400&auto=format&fit=crop&q=80',
    },
    {
      name: 'Retro Running Shoes',
      url: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&auto=format&fit=crop&q=80',
    },
  ];

  if (!isImageSearchOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setPreviewImage(base64String);
        analyzeImage(base64String, file.type);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSampleClick = async (sampleUrl: string) => {
    setPreviewImage(sampleUrl);
    setLoading(true);
    try {
      // Find matching items from catalog
      const res = await fetch('/api/wiseai/image-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: 'sample-image-placeholder', mimeType: 'image/jpeg' }),
      });
      const data = await res.json();
      setAnalysisResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const analyzeImage = async (base64Full: string, mimeType: string) => {
    setLoading(true);
    setAnalysisResult(null);
    try {
      // strip data:image/...;base64,
      const base64Data = base64Full.split(',')[1] || base64Full;
      const res = await fetch('/api/wiseai/image-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: base64Data, mimeType: mimeType || 'image/jpeg' }),
      });
      const data = await res.json();
      setAnalysisResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const matchedProducts: Product[] = analysisResult?.matchedProductIds
    ? products.filter((p) => analysisResult.matchedProductIds.includes(p.id))
    : [];

  return (
    <div
      id="image-search-modal-overlay"
      className="fixed inset-0 z-50 bg-white/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fade-in"
    >
      <div className="bg-white dark:bg-slate-900 w-full max-w-xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm tracking-wide">Visual AI Image Search</h3>
              <p className="text-[11px] text-slate-400">Snap or upload a photo to match Antifly styles</p>
            </div>
          </div>
          <button
            onClick={() => setIsImageSearchOpen(false)}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Upload & Preview area */}
        <div className="p-5 overflow-y-auto space-y-4">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept="image/*"
            className="hidden"
          />

          {!previewImage ? (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-amber-500 dark:hover:border-amber-500 rounded-2xl p-8 text-center cursor-pointer transition-all bg-slate-50/50 dark:bg-white/50"
            >
              <div className="w-14 h-14 mx-auto rounded-full bg-amber-500/10 text-amber-500 flex items-center justify-center mb-3">
                <Upload className="w-6 h-6" />
              </div>
              <p className="font-semibold text-slate-800 dark:text-slate-200 text-sm">
                Drop your outfit image here or click to browse
              </p>
              <p className="text-xs text-slate-400 mt-1">Supports JPG, PNG, WEBP up to 10MB</p>
            </div>
          ) : (
            <div className="relative rounded-xl overflow-hidden max-h-48 bg-white flex items-center justify-center">
              <img src={previewImage} alt="Uploaded preview" className="h-48 object-contain" />
              <button
                onClick={() => {
                  setPreviewImage(null);
                  setAnalysisResult(null);
                }}
                className="absolute top-2 right-2 p-1.5 bg-slate-900/80 text-white rounded-full hover:bg-rose-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Sample images */}
          {!previewImage && (
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-2 font-medium">
                Or try with sample luxury references:
              </p>
              <div className="grid grid-cols-3 gap-2">
                {sampleOutfitImages.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => handleSampleClick(s.url)}
                    className="p-1 rounded-lg border border-slate-200 dark:border-slate-800 hover:border-amber-500 text-left transition-all"
                  >
                    <img src={s.url} alt={s.name} className="w-full h-20 object-cover rounded" />
                    <span className="block text-[10px] font-semibold text-slate-700 dark:text-slate-300 mt-1 truncate">
                      {s.name}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Loading indicator */}
          {loading && (
            <div className="flex items-center justify-center gap-2.5 py-6 text-xs text-amber-600 dark:text-amber-400">
              <Sparkles className="w-5 h-5 animate-spin" />
              <span>Analyzing visual textures, cut, and matching catalog items...</span>
            </div>
          )}

          {/* Results Analysis */}
          {analysisResult && (
            <div className="space-y-3 pt-2">
              <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-700 dark:text-amber-300">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Visual Match Score: {analysisResult.similarityScore || 94}%</span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5">
                    {analysisResult.analysis}
                  </p>
                </div>
              </div>

              {/* Matched Catalog Items */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Matching Antifly Catalog Items:
                </h4>
                {matchedProducts.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => {
                      setActivePdpId(p.id);
                      setIsImageSearchOpen(false);
                    }}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex items-center justify-between hover:border-amber-400 cursor-pointer transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <img src={p.images[0]} alt={p.name} className="w-12 h-12 rounded-lg object-cover" />
                      <div>
                        <h5 className="font-semibold text-xs text-slate-900 dark:text-white">{p.name}</h5>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          {p.brand} &bull; ₹{p.price.toLocaleString('en-IN')}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        addToCart({
                          productId: p.id,
                          variantId: p.variants[0]?.id || 'default',
                          productName: p.name,
                          brand: p.brand,
                          color: p.colors[0]?.name || 'Standard',
                          size: p.sizes[0] || 'Standard',
                          price: p.price,
                          mrp: p.mrp,
                          image: p.images[0],
                          quantity: 1,
                          stock: p.totalStock,
                        });
                      }}
                      className="p-1.5 bg-amber-500 hover:bg-amber-600 text-slate-800 rounded-lg text-xs font-semibold flex items-center gap-1"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      Add
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
