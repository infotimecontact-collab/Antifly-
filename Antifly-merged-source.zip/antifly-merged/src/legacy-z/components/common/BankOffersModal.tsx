import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  CreditCard,
  X,
  Percent,
  Calculator,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Building2,
  Coins,
  ChevronRight,
} from 'lucide-react';
import { BankCardOffer } from '../../types';

export const BankOffersModal: React.FC = () => {
  const {
    isBankOffersModalOpen,
    setIsBankOffersModalOpen,
    bankOffers,
    appliedBankOffer,
    applyBankOffer,
    removeBankOffer,
  } = useApp();

  const [activeBankFilter, setActiveBankFilter] = useState<string>('ALL');
  const [emiPurchaseAmount, setEmiPurchaseAmount] = useState<number>(18000);
  const [selectedEmiMonths, setSelectedEmiMonths] = useState<number>(6);
  const [selectedEmiBank, setSelectedEmiBank] = useState<string>('HDFC');

  if (!isBankOffersModalOpen) return null;

  const filteredOffers = bankOffers.filter((offer) => {
    if (activeBankFilter === 'ALL') return true;
    return offer.bankCode === activeBankFilter;
  });

  const activeEmiOffer = bankOffers.find((b) => b.bankCode === selectedEmiBank) || bankOffers[0];
  const emiOptionsList = [
    { months: 3, isNoCost: true, interestRate: 0 },
    { months: 6, isNoCost: true, interestRate: 0 },
    { months: 9, isNoCost: false, interestRate: 14 },
    { months: 12, isNoCost: false, interestRate: 15 },
    { months: 24, isNoCost: false, interestRate: 16 },
  ];

  const currentEmiChoice = emiOptionsList.find((e) => e.months === selectedEmiMonths) || emiOptionsList[1];
  const monthlyEmiAmount = Math.round(
    currentEmiChoice.isNoCost
      ? emiPurchaseAmount / currentEmiChoice.months
      : (emiPurchaseAmount * (1 + (currentEmiChoice.interestRate / 100) * (currentEmiChoice.months / 12))) /
          currentEmiChoice.months
  );
  const totalInterestSavings = currentEmiChoice.isNoCost
    ? Math.round(emiPurchaseAmount * 0.14 * (currentEmiChoice.months / 12))
    : 0;

  return (
    <div
      id="bank-offers-modal"
      className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 lg:p-6 animate-fade-in"
    >
      <div className="bg-white dark:bg-slate-900 w-full max-w-4xl rounded-3xl shadow-2xl border border-blue-200 dark:border-slate-800 overflow-hidden flex flex-col my-auto max-h-[94vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 p-6 text-white relative flex-shrink-0">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center text-white border border-white/20 shadow-inner flex-shrink-0">
                <CreditCard className="w-8 h-8 text-sky-400" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase tracking-wider bg-sky-500 text-slate-800 px-2 py-0.5 rounded-full">
                    💳 All Bank Card Privileges
                  </span>
                  <span className="text-[10px] font-bold text-sky-200 bg-white/10 px-2 py-0.5 rounded-full">
                    Instant 10% - 15% Discounts
                  </span>
                </div>
                <h2 className="text-2xl font-black text-white mt-1">
                  Bank Credit Cards & No-Cost EMI Hub
                </h2>
                <p className="text-xs text-sky-200/90 font-medium">
                  Instant card savings across HDFC, SBI, ICICI, Axis, Kotak, Amex & No-Cost EMI Calculator
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsBankOffersModalOpen(false)}
              className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 mt-5 overflow-x-auto pb-1">
            {['ALL', 'HDFC', 'SBI', 'ICICI', 'AXIS', 'KOTAK', 'AMEX'].map((code) => (
              <button
                key={code}
                onClick={() => setActiveBankFilter(code)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex-shrink-0 cursor-pointer ${
                  activeBankFilter === code
                    ? 'bg-sky-400 text-slate-800 shadow'
                    : 'bg-white/10 text-white hover:bg-white/20'
                }`}
              >
                {code === 'ALL' ? 'All Banks' : `${code} Bank`}
              </button>
            ))}
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-7 space-y-7">
          {/* Card Offers Grid */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-slate-900 dark:text-white text-sm uppercase tracking-wider text-stone-500">
                Active Bank Card Discounts
              </h3>
              <span className="text-xs text-slate-400 font-semibold">
                Showing {filteredOffers.length} Offers
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredOffers.map((offer) => {
                const isApplied = appliedBankOffer?.id === offer.id;

                return (
                  <div
                    key={offer.id}
                    className={`p-5 rounded-2xl border-2 transition flex flex-col justify-between space-y-3 ${
                      isApplied
                        ? 'border-sky-500 bg-sky-50/40 dark:bg-sky-950/20 shadow-md'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/60 hover:border-slate-300'
                    }`}
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider shadow-xs ${offer.iconBg}`}
                          >
                            {offer.logoText}
                          </span>
                          <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                            {offer.bankName}
                          </span>
                        </div>

                        <span className="text-[11px] font-black uppercase text-emerald-600 bg-emerald-50 dark:bg-emerald-950/50 dark:text-emerald-300 px-2 py-0.5 rounded-full">
                          {offer.instantDiscountText}
                        </span>
                      </div>

                      <h4 className="font-extrabold text-slate-900 dark:text-white text-sm">
                        {offer.title}
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                        {offer.description}
                      </p>

                      <div className="pt-1 flex flex-wrap gap-1 text-[10px] text-slate-500">
                        <span className="font-semibold">Eligible Cards:</span>
                        {offer.popularCardNames.join(', ')}
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
                      <span className="text-xs font-mono font-bold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded-md">
                        Code: {offer.code}
                      </span>

                      {isApplied ? (
                        <button
                          onClick={removeBankOffer}
                          className="text-xs font-bold text-rose-600 hover:underline flex items-center gap-1 cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Applied • Remove</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => applyBankOffer(offer.id)}
                          className="px-3.5 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-bold transition shadow cursor-pointer flex items-center gap-1"
                        >
                          <span>Apply Offer</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Interactive No-Cost EMI Calculator */}
          <div className="p-6 rounded-3xl bg-gradient-to-br from-slate-50 via-sky-50 to-indigo-50 dark:from-slate-800 dark:to-slate-900 border border-sky-200 dark:border-slate-700 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-sky-600 text-white flex items-center justify-center">
                  <Calculator className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 dark:text-white text-base">
                    Interactive No-Cost EMI Calculator
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Split your purchase into easy monthly installments with 0% interest
                  </p>
                </div>
              </div>

              <span className="text-xs font-black text-emerald-600 bg-emerald-100 dark:bg-emerald-950 px-2.5 py-1 rounded-full w-fit">
                ⚡ 0% Processing Fee
              </span>
            </div>

            {/* Slider & Presets */}
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs font-bold text-slate-700 dark:text-slate-300">
                <span>Select Purchase Amount:</span>
                <span className="font-mono text-base text-sky-600 dark:text-sky-400 font-black">
                  ₹{emiPurchaseAmount.toLocaleString('en-IN')}
                </span>
              </div>

              <input
                type="range"
                min="3000"
                max="100000"
                step="1000"
                value={emiPurchaseAmount}
                onChange={(e) => setEmiPurchaseAmount(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-sky-600"
              />

              <div className="flex gap-2">
                {[5000, 15000, 30000, 60000].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setEmiPurchaseAmount(amt)}
                    className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-sky-400 cursor-pointer"
                  >
                    ₹{amt.toLocaleString('en-IN')}
                  </button>
                ))}
              </div>
            </div>

            {/* Bank Card Selection */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                Select Your Bank Card:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {['HDFC', 'SBI', 'ICICI', 'AXIS'].map((bank) => (
                  <button
                    key={bank}
                    onClick={() => setSelectedEmiBank(bank)}
                    className={`p-2.5 rounded-xl text-xs font-bold border transition text-center cursor-pointer ${
                      selectedEmiBank === bank
                        ? 'bg-sky-600 text-white border-sky-600 shadow'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {bank} Bank
                  </button>
                ))}
              </div>
            </div>

            {/* Tenure Choices */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                Choose EMI Tenure:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {emiOptionsList.map((tenure) => {
                  const isSelected = selectedEmiMonths === tenure.months;
                  const monthly = Math.round(
                    tenure.isNoCost
                      ? emiPurchaseAmount / tenure.months
                      : (emiPurchaseAmount * (1 + (tenure.interestRate / 100) * (tenure.months / 12))) /
                          tenure.months
                  );

                  return (
                    <button
                      key={tenure.months}
                      onClick={() => setSelectedEmiMonths(tenure.months)}
                      className={`p-3 rounded-2xl border-2 text-center transition cursor-pointer ${
                        isSelected
                          ? 'bg-white dark:bg-slate-800 border-sky-500 shadow-md'
                          : 'bg-white/60 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      <span className="text-xs font-black block text-slate-900 dark:text-white">
                        {tenure.months} Months
                      </span>
                      <span className="font-mono text-sm font-black text-sky-600 dark:text-sky-400 block mt-0.5">
                        ₹{monthly}/mo
                      </span>
                      {tenure.isNoCost ? (
                        <span className="text-[9px] font-black bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 px-1.5 py-0.5 rounded-full inline-block mt-1">
                          No-Cost EMI
                        </span>
                      ) : (
                        <span className="text-[9px] text-slate-400 font-semibold block mt-1">
                          {tenure.interestRate}% p.a.
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Calculated Breakdown Card */}
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <span className="text-xs text-slate-500 block font-semibold">
                  You Pay Every Month for {selectedEmiMonths} Months:
                </span>
                <span className="text-2xl font-black text-slate-900 dark:text-white font-mono">
                  ₹{monthlyEmiAmount} <span className="text-xs font-normal text-slate-400">/month</span>
                </span>
                {totalInterestSavings > 0 && (
                  <span className="text-xs text-emerald-600 font-bold block mt-0.5">
                    🎉 You save ₹{totalInterestSavings} in interest with No-Cost EMI!
                  </span>
                )}
              </div>

              <button
                onClick={() => {
                  applyBankOffer(activeEmiOffer.id);
                  setIsBankOffersModalOpen(false);
                }}
                className="w-full sm:w-auto px-6 py-2.5 bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-black text-xs rounded-xl shadow transition cursor-pointer"
              >
                Apply {selectedEmiBank} No-Cost EMI to Cart
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
