import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Bookmark,
  Heart,
  MessageCircle,
  Share2,
  ShoppingBag,
  Store,
  Sparkles,
  Trash2,
  ExternalLink,
  ThumbsUp,
  ThumbsDown,
  Tag,
  CheckCircle,
} from 'lucide-react';

export const SavePortfolioModal: React.FC = () => {
  const {
    isSavePortfolioOpen,
    setIsSavePortfolioOpen,
    savedProductIds,
    savedSellerPostIds,
    savedSellerPortfolioIds,
    products,
    sellers,
    toggleSaveProductSocial,
    toggleSaveSellerPost,
    toggleSaveSellerPortfolioItem,
    addToCart,
    setActivePdpId,
    setActiveCommentsProductId,
    setIsProductCommentsOpen,
    setActiveShareProduct,
    setIsProductShareOpen,
    openSellerStorefront,
    likeSellerPost,
    dislikeSellerPost,
    likeSellerPortfolioItem,
    dislikeSellerPortfolioItem,
    isFollowingSeller,
    toggleFollowSeller,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'products' | 'posts' | 'portfolio'>('products');

  if (!isSavePortfolioOpen) return null;

  const savedProductsList = products.filter((p) => savedProductIds.includes(p.id));

  // Collect all saved posts across all sellers
  const allSellerPosts = sellers.flatMap((s) => s.posts || []);
  const savedPostsList = allSellerPosts.filter((post) =>
    savedSellerPostIds.includes(post.id) || post.isSavedByMe
  );

  // Collect all saved portfolio items across all sellers
  const allSellerPortfolios = sellers.flatMap((s) => s.portfolio || []);
  const savedPortfoliosList = allSellerPortfolios.filter((item) =>
    savedSellerPortfolioIds.includes(item.id) || item.isSavedByMe
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-white/60 backdrop-blur-sm p-2 sm:p-4 animate-in fade-in duration-200">
      <div
        id="save-portfolio-modal-container"
        className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden text-slate-800"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-white sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-50 text-amber-600 rounded-xl border border-amber-200">
              <Bookmark className="w-5 h-5 fill-amber-500 text-amber-500" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 leading-tight">My Saved Portfolio</h2>
              <p className="text-xs text-slate-500">
                Aggregated collection of your saved products, artisan posts, and master craftsman portfolios
              </p>
            </div>
          </div>
          <button
            id="close-save-portfolio-modal-btn"
            onClick={() => setIsSavePortfolioOpen(false)}
            className="p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-5 border-b border-slate-100 flex items-center gap-2 bg-slate-50">
          <button
            id="saved-tab-products"
            onClick={() => setActiveTab('products')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'products'
                ? 'border-orange-600 text-orange-600 bg-white shadow-sm -mb-px rounded-t-lg'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Saved Products</span>
            <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-slate-200 text-slate-700 font-semibold">
              {savedProductsList.length}
            </span>
          </button>

          <button
            id="saved-tab-posts"
            onClick={() => setActiveTab('posts')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'posts'
                ? 'border-orange-600 text-orange-600 bg-white shadow-sm -mb-px rounded-t-lg'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Saved Posts & Images</span>
            <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-slate-200 text-slate-700 font-semibold">
              {savedPostsList.length}
            </span>
          </button>

          <button
            id="saved-tab-portfolio"
            onClick={() => setActiveTab('portfolio')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'portfolio'
                ? 'border-orange-600 text-orange-600 bg-white shadow-sm -mb-px rounded-t-lg'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            <span>Saved Artisan Portfolios</span>
            <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-slate-200 text-slate-700 font-semibold">
              {savedPortfoliosList.length}
            </span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {/* TAB 1: SAVED PRODUCTS */}
          {activeTab === 'products' && (
            <div>
              {savedProductsList.length === 0 ? (
                <div className="text-center py-16">
                  <Bookmark className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-sm font-bold text-slate-700">Your Saved Products Portfolio is empty</p>
                  <p className="text-xs text-slate-400 mt-1">
                    Click the bookmark icon below any product or in the product details to save items here!
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {savedProductsList.map((product) => (
                    <div
                      key={product.id}
                      className="group bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-md transition-all flex flex-col justify-between"
                    >
                      <div>
                        {/* Image */}
                        <div
                          className="relative aspect-square bg-slate-100 overflow-hidden cursor-pointer"
                          onClick={() => {
                            setIsSavePortfolioOpen(false);
                            setActivePdpId(product.id);
                          }}
                        >
                          <img
                            src={product.images[0]}
                            alt={product.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleSaveProductSocial(product.id);
                            }}
                            className="absolute top-2.5 right-2.5 p-2 rounded-full bg-white/90 text-amber-600 hover:bg-rose-50 hover:text-rose-600 shadow-md backdrop-blur-sm transition-all"
                            title="Remove from Saved Portfolio"
                          >
                            <Bookmark className="w-4 h-4 fill-amber-500 text-amber-500" />
                          </button>
                        </div>

                        {/* Info */}
                        <div className="p-3.5">
                          <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                            {product.brand}
                          </p>
                          <h3
                            onClick={() => {
                              setIsSavePortfolioOpen(false);
                              setActivePdpId(product.id);
                            }}
                            className="text-xs font-bold text-slate-900 line-clamp-1 hover:text-orange-600 cursor-pointer mt-0.5"
                          >
                            {product.name}
                          </h3>
                          <div className="flex items-center gap-2 mt-1.5">
                            <span className="text-sm font-extrabold text-orange-600">
                              ₹{product.price.toLocaleString('en-IN')}
                            </span>
                            {product.mrp > product.price && (
                              <span className="text-xs text-slate-400 line-through">
                                ₹{product.mrp.toLocaleString('en-IN')}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Action Bar */}
                      <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              setActiveCommentsProductId(product.id);
                              setIsProductCommentsOpen(true);
                            }}
                            className="p-1.5 text-slate-600 hover:text-orange-600 rounded-lg hover:bg-white transition-all"
                            title="Comments"
                          >
                            <MessageCircle className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              setActiveShareProduct(product);
                              setIsProductShareOpen(true);
                            }}
                            className="p-1.5 text-slate-600 hover:text-orange-600 rounded-lg hover:bg-white transition-all"
                            title="Share"
                          >
                            <Share2 className="w-4 h-4" />
                          </button>
                        </div>

                        <button
                          onClick={() => {
                            addToCart({
                              productId: product.id,
                              variantId: 'default',
                              productName: product.name,
                              brand: product.brand,
                              color: product.colors[0]?.name || 'Standard',
                              size: product.sizes[0] || 'Standard',
                              price: product.price,
                              mrp: product.mrp,
                              image: product.images[0],
                              quantity: 1,
                              stock: product.totalStock,
                            });
                          }}
                          className="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-sm transition-all"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>Add to Cart</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: SAVED SELLER POSTS & STORIES */}
          {activeTab === 'posts' && (
            <div>
              {savedPostsList.length === 0 ? (
                <div className="text-center py-16">
                  <Sparkles className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-sm font-bold text-slate-700">No saved seller posts yet</p>
                  <p className="text-xs text-slate-400 mt-1">
                    Visit any Seller Profile Storefront to like and bookmark live studio photos!
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  {savedPostsList.map((post) => (
                    <div
                      key={post.id}
                      className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm flex flex-col justify-between"
                    >
                      <div>
                        {/* Seller Header */}
                        <div className="p-3 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                          <div
                            onClick={() => {
                              setIsSavePortfolioOpen(false);
                              openSellerStorefront(post.sellerId);
                            }}
                            className="flex items-center gap-2.5 cursor-pointer group"
                          >
                            <img
                              src={post.sellerAvatar}
                              alt={post.sellerName}
                              className="w-8 h-8 rounded-full object-cover border border-slate-200"
                            />
                            <div>
                              <p className="text-xs font-bold text-slate-900 group-hover:text-orange-600 transition-colors">
                                {post.sellerName}
                              </p>
                              <p className="text-[10px] text-slate-400">{post.uploadedAt}</p>
                            </div>
                          </div>

                          <button
                            onClick={() => toggleSaveSellerPost(post.sellerId, post.id)}
                            className="p-1.5 text-amber-600 hover:text-slate-400"
                            title="Remove bookmark"
                          >
                            <Bookmark className="w-4 h-4 fill-amber-500" />
                          </button>
                        </div>

                        {/* Post Photo */}
                        <div className="relative aspect-video bg-slate-100 overflow-hidden">
                          <img src={post.imageUrl} alt={post.caption} className="w-full h-full object-cover" />
                          {post.taggedProductName && (
                            <div className="absolute bottom-2 left-2 bg-white/80 backdrop-blur-md text-white text-[11px] font-semibold px-2.5 py-1 rounded-lg flex items-center gap-1.5 shadow-md">
                              <Tag className="w-3 h-3 text-amber-400" />
                              <span>{post.taggedProductName}</span>
                              <span className="text-orange-400 font-bold">₹{post.taggedProductPrice}</span>
                            </div>
                          )}
                        </div>

                        {/* Caption */}
                        <div className="p-3.5">
                          <p className="text-xs text-slate-800 leading-relaxed">{post.caption}</p>
                        </div>
                      </div>

                      {/* Action Bar */}
                      <div className="p-3 border-t border-slate-100 flex items-center justify-between bg-slate-50">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => likeSellerPost(post.sellerId, post.id)}
                            className={`flex items-center gap-1 text-xs px-2.5 py-1 rounded-full border transition-all ${
                              post.isLikedByMe
                                ? 'bg-rose-50 border-rose-200 text-rose-600 font-bold'
                                : 'bg-white border-slate-200 text-slate-600 hover:text-rose-600'
                            }`}
                          >
                            <ThumbsUp className="w-3.5 h-3.5" />
                            <span>{post.likesCount}</span>
                          </button>

                          <button
                            onClick={() => dislikeSellerPost(post.sellerId, post.id)}
                            className={`flex items-center gap-1 text-xs px-2.5 py-1 rounded-full border transition-all ${
                              post.isDislikedByMe
                                ? 'bg-slate-200 border-slate-300 text-slate-800 font-bold'
                                : 'bg-white border-slate-200 text-slate-500 hover:text-slate-700'
                            }`}
                          >
                            <ThumbsDown className="w-3.5 h-3.5" />
                            <span>{post.dislikesCount}</span>
                          </button>
                        </div>

                        <button
                          onClick={() => {
                            setIsSavePortfolioOpen(false);
                            openSellerStorefront(post.sellerId);
                          }}
                          className="text-xs font-semibold text-orange-600 hover:text-orange-700 flex items-center gap-1"
                        >
                          <span>View Seller Store</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: SAVED ARTISAN PORTFOLIOS */}
          {activeTab === 'portfolio' && (
            <div>
              {savedPortfoliosList.length === 0 ? (
                <div className="text-center py-16">
                  <Store className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-sm font-bold text-slate-700">No saved craftsman portfolios yet</p>
                  <p className="text-xs text-slate-400 mt-1">
                    Save awards, weaving workshops, and master studios from seller storefronts!
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  {savedPortfoliosList.map((item) => (
                    <div
                      key={item.id}
                      className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm flex flex-col justify-between"
                    >
                      <div>
                        <div className="relative aspect-video bg-slate-100 overflow-hidden">
                          <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
                          <span className="absolute top-2.5 left-2.5 bg-white/80 backdrop-blur-md text-amber-300 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded shadow">
                            {item.category}
                          </span>
                          <button
                            onClick={() => toggleSaveSellerPortfolioItem(item.sellerId, item.id)}
                            className="absolute top-2.5 right-2.5 p-2 rounded-full bg-white/90 text-amber-600 hover:bg-rose-50 shadow backdrop-blur-sm transition-all"
                            title="Remove from Saved Portfolio"
                          >
                            <Bookmark className="w-4 h-4 fill-amber-500" />
                          </button>
                        </div>

                        <div className="p-4">
                          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                            <span className="font-semibold text-slate-700">{item.sellerName}</span>
                            {item.dateAdded && <span>{item.dateAdded}</span>}
                          </div>
                          <h3 className="text-sm font-bold text-slate-900 leading-snug">{item.title}</h3>
                          <p className="text-xs text-slate-600 mt-2 leading-relaxed">{item.description}</p>

                          {/* Tags */}
                          {item.tags && item.tags.length > 0 && (
                            <div className="flex items-center gap-1.5 flex-wrap mt-3">
                              {item.tags.map((tag, i) => (
                                <span
                                  key={i}
                                  className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-medium"
                                >
                                  #{tag}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Action Bar */}
                      <div className="p-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => likeSellerPortfolioItem(item.sellerId, item.id)}
                            className={`flex items-center gap-1 text-xs px-2.5 py-1 rounded-full border transition-all ${
                              item.isLikedByMe
                                ? 'bg-rose-50 border-rose-200 text-rose-600 font-bold'
                                : 'bg-white border-slate-200 text-slate-600 hover:text-rose-600'
                            }`}
                          >
                            <ThumbsUp className="w-3.5 h-3.5" />
                            <span>{item.likesCount}</span>
                          </button>

                          <button
                            onClick={() => dislikeSellerPortfolioItem(item.sellerId, item.id)}
                            className={`flex items-center gap-1 text-xs px-2.5 py-1 rounded-full border transition-all ${
                              item.isDislikedByMe
                                ? 'bg-slate-200 border-slate-300 text-slate-800 font-bold'
                                : 'bg-white border-slate-200 text-slate-500 hover:text-slate-700'
                            }`}
                          >
                            <ThumbsDown className="w-3.5 h-3.5" />
                            <span>{item.dislikesCount}</span>
                          </button>
                        </div>

                        <button
                          onClick={() => {
                            setIsSavePortfolioOpen(false);
                            openSellerStorefront(item.sellerId);
                          }}
                          className="text-xs font-semibold text-orange-600 hover:text-orange-700 flex items-center gap-1"
                        >
                          <span>Explore Seller Studio</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
