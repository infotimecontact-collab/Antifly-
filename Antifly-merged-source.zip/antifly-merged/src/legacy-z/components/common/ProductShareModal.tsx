import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Share2,
  Copy,
  Check,
  Send,
  MessageCircle,
  QrCode,
  Sparkles,
  ExternalLink,
  Store,
} from 'lucide-react';

export const ProductShareModal: React.FC = () => {
  const {
    activeShareProduct,
    setActiveShareProduct,
    isProductShareOpen,
    setIsProductShareOpen,
    showToast,
  } = useApp();

  const [copied, setCopied] = useState(false);

  if (!isProductShareOpen || !activeShareProduct) return null;

  const shareUrl = `${window.location.origin}/?product=${activeShareProduct.id}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    showToast('🔗 Product link copied to clipboard!');
    setTimeout(() => setCopied(false), 2500);
  };

  const handleShareOption = (platform: string) => {
    const text = `Check out ${activeShareProduct.name} (₹${activeShareProduct.price}) on Antifly!`;
    if (platform === 'whatsapp') {
      window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text + ' ' + shareUrl)}`, '_blank');
    } else if (platform === 'instagram') {
      handleCopy();
      showToast('📸 Link copied! Open Instagram and paste into your Story or Direct Message.');
    } else if (platform === 'twitter') {
      window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(shareUrl)}`, '_blank');
    } else if (platform === 'facebook') {
      window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`, '_blank');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-white/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div
        id="product-share-modal-container"
        className="bg-white rounded-2xl w-full max-w-md shadow-2xl border border-slate-200 overflow-hidden text-slate-800 animate-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-orange-50 text-orange-600 rounded-full">
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 leading-tight">Share Product</h2>
              <p className="text-xs text-slate-500">Instagram, WhatsApp & Social Links</p>
            </div>
          </div>
          <button
            id="close-share-modal-btn"
            onClick={() => setIsProductShareOpen(false)}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Product preview card */}
        <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center gap-3">
          <img
            src={activeShareProduct.images[0]}
            alt={activeShareProduct.name}
            className="w-16 h-16 rounded-xl object-cover border border-slate-200 shrink-0"
          />
          <div className="min-w-0">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              {activeShareProduct.brand}
            </span>
            <h3 className="text-xs font-bold text-slate-900 line-clamp-1">{activeShareProduct.name}</h3>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-sm font-extrabold text-orange-600">
                ₹{activeShareProduct.price.toLocaleString('en-IN')}
              </span>
              {activeShareProduct.mrp > activeShareProduct.price && (
                <span className="text-xs text-slate-400 line-through">
                  ₹{activeShareProduct.mrp.toLocaleString('en-IN')}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Social Share Grid */}
        <div className="p-4">
          <p className="text-xs font-semibold text-slate-500 mb-3 uppercase tracking-wider">
            Share Directly Via
          </p>
          <div className="grid grid-cols-4 gap-3 text-center">
            <button
              id="share-instagram-btn"
              onClick={() => handleShareOption('instagram')}
              className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 text-white hover:opacity-90 transition-all shadow-sm"
            >
              <div className="w-6 h-6 flex items-center justify-center font-bold text-sm">📸</div>
              <span className="text-[11px] font-semibold">Instagram</span>
            </button>

            <button
              id="share-whatsapp-btn"
              onClick={() => handleShareOption('whatsapp')}
              className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700 transition-all shadow-sm"
            >
              <MessageCircle className="w-6 h-6" />
              <span className="text-[11px] font-semibold">WhatsApp</span>
            </button>

            <button
              id="share-twitter-btn"
              onClick={() => handleShareOption('twitter')}
              className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-slate-900 text-white hover:bg-slate-800 transition-all shadow-sm"
            >
              <div className="w-6 h-6 flex items-center justify-center font-bold text-sm">𝕏</div>
              <span className="text-[11px] font-semibold">X / Twitter</span>
            </button>

            <button
              id="share-facebook-btn"
              onClick={() => handleShareOption('facebook')}
              className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-blue-600 text-white hover:bg-blue-700 transition-all shadow-sm"
            >
              <div className="w-6 h-6 flex items-center justify-center font-bold text-sm">f</div>
              <span className="text-[11px] font-semibold">Facebook</span>
            </button>
          </div>

          {/* Copy Link Section */}
          <div className="mt-4 pt-4 border-t border-slate-100">
            <p className="text-xs font-semibold text-slate-500 mb-2">Page Link</p>
            <div className="flex items-center gap-2 bg-slate-100 p-1.5 pl-3 rounded-xl border border-slate-200">
              <span className="text-xs text-slate-600 truncate flex-1 font-mono">{shareUrl}</span>
              <button
                id="copy-product-share-url-btn"
                onClick={handleCopy}
                className="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-all shrink-0"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
