import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  UtensilsCrossed,
  X,
  Clock,
  Star,
  MapPin,
  Flame,
  Plus,
  Minus,
  ShoppingBag,
  Sparkles,
  CheckCircle2,
  Bike,
  Phone,
  ShieldCheck,
  ChevronRight,
  Search,
  Filter,
  Crown,
} from 'lucide-react';
import { Restaurant, FoodItem } from '../../types';

export const FoodDeliveryModal: React.FC = () => {
  const {
    isFoodDeliveryModalOpen,
    setIsFoodDeliveryModalOpen,
    restaurants,
    selectedRestaurant,
    setSelectedRestaurant,
    foodCart,
    addToFoodCart,
    updateFoodCartQuantity,
    removeFromFoodCart,
    clearFoodCart,
    foodOrders,
    placeFoodOrder,
    antiflyOneSubscription,
    setIsAntiflyOneModalOpen,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'restaurants' | 'menu' | 'tracking'>('restaurants');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterVegOnly, setFilterVegOnly] = useState(false);
  const [selectedCustomizingItem, setSelectedCustomizingItem] = useState<FoodItem | null>(null);
  const [customPortion, setCustomPortion] = useState('Regular');
  const [selectedAddons, setSelectedAddons] = useState<string[]>([]);
  const [riderTip, setRiderTip] = useState(30);
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);
  const [activeTrackingOrderIndex, setActiveTrackingOrderIndex] = useState(0);

  if (!isFoodDeliveryModalOpen) return null;

  const currentRestaurant = selectedRestaurant || restaurants[0];

  const filteredRestaurants = restaurants.filter((r) => {
    const matchesSearch =
      r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.cuisines.some((c) => c.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesVeg = filterVegOnly ? r.isPureVeg : true;
    return matchesSearch && matchesVeg;
  });

  const cartSubtotal = foodCart.reduce(
    (sum, item) => sum + item.foodItem.price * item.quantity + (item.extraPrice || 0),
    0
  );
  const deliveryFee = 0;
  const taxes = Math.round(cartSubtotal * 0.05);
  const antiflyOneDiscount = antiflyOneSubscription.isActive ? Math.round(cartSubtotal * 0.1) : 0;
  const cartTotal = cartSubtotal + deliveryFee + taxes + riderTip - antiflyOneDiscount;

  const handleOpenRestaurantMenu = (rest: Restaurant) => {
    setSelectedRestaurant(rest);
    setActiveTab('menu');
  };

  const handleAddDishClick = (dish: FoodItem) => {
    if (dish.customizationOptions && dish.customizationOptions.length > 0) {
      setSelectedCustomizingItem(dish);
      setCustomPortion(dish.customizationOptions[0].options[0].label);
      setSelectedAddons([]);
    } else {
      addToFoodCart({
        foodItem: dish,
        restaurantId: currentRestaurant.id,
        restaurantName: currentRestaurant.name,
        quantity: 1,
        extraPrice: 0,
      });
    }
  };

  const handleConfirmCustomization = () => {
    if (!selectedCustomizingItem) return;
    let extra = 0;
    if (customPortion.includes('Jumbo') || customPortion.includes('Family')) extra += 180;
    if (customPortion.includes('Cheese Burst')) extra += 79;
    extra += selectedAddons.length * 35;

    addToFoodCart({
      foodItem: selectedCustomizingItem,
      restaurantId: currentRestaurant.id,
      restaurantName: currentRestaurant.name,
      quantity: 1,
      extraPrice: extra,
      selectedOptions: { portion: customPortion, addons: selectedAddons.join(', ') },
    });
    setSelectedCustomizingItem(null);
  };

  const handleExecutePlaceOrder = async () => {
    if (foodCart.length === 0) return;
    setIsPlacingOrder(true);
    try {
      await placeFoodOrder(riderTip);
      setActiveTab('tracking');
      setActiveTrackingOrderIndex(0);
    } finally {
      setIsPlacingOrder(false);
    }
  };

  return (
    <div
      id="food-delivery-modal"
      className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 lg:p-6 animate-fade-in"
    >
      <div className="bg-white dark:bg-slate-900 w-full max-w-5xl rounded-3xl shadow-2xl border border-orange-200 dark:border-slate-800 overflow-hidden flex flex-col my-auto max-h-[94vh]">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-orange-600 via-amber-500 to-rose-600 p-5 text-white flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shadow-inner flex-shrink-0">
                <UtensilsCrossed className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase tracking-wider bg-white text-orange-700 px-2 py-0.5 rounded-full">
                    ⚡ AntiflyBites Instant Food
                  </span>
                  {antiflyOneSubscription.isActive ? (
                    <span className="flex items-center gap-1 text-[10px] font-bold bg-amber-400 text-slate-800 px-2 py-0.5 rounded-full">
                      <Crown className="w-3 h-3 fill-slate-950" /> AntiflyOne Free Delivery Active
                    </span>
                  ) : (
                    <button
                      onClick={() => setIsAntiflyOneModalOpen(true)}
                      className="text-[10px] font-bold bg-white/30 hover:bg-white/40 text-white px-2 py-0.5 rounded-full transition"
                    >
                      Get AntiflyOne for ₹0 Delivery &gt;
                    </button>
                  )}
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-white mt-0.5">
                  Hot Food, Cloud Kitchens & Gourmet Dining
                </h2>
              </div>
            </div>

            <button
              onClick={() => setIsFoodDeliveryModalOpen(false)}
              className="w-9 h-9 rounded-full bg-slate-100/20 hover:bg-slate-100/40 text-white flex items-center justify-center transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Sub Navigation Bar */}
          <div className="flex items-center gap-2 mt-4 overflow-x-auto pb-1">
            <button
              onClick={() => setActiveTab('restaurants')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'restaurants'
                  ? 'bg-white text-orange-700 shadow'
                  : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              <UtensilsCrossed className="w-3.5 h-3.5" />
              <span>Explore Restaurants ({restaurants.length})</span>
            </button>

            {selectedRestaurant && (
              <button
                onClick={() => setActiveTab('menu')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  activeTab === 'menu'
                    ? 'bg-white text-orange-700 shadow'
                    : 'bg-white/20 text-white hover:bg-white/30'
                }`}
              >
                <span>Menu: {selectedRestaurant.name}</span>
              </button>
            )}

            {foodOrders.length > 0 && (
              <button
                onClick={() => setActiveTab('tracking')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  activeTab === 'tracking'
                    ? 'bg-white text-orange-700 shadow'
                    : 'bg-white/20 text-white hover:bg-white/30'
                }`}
              >
                <Bike className="w-3.5 h-3.5" />
                <span>Live Food Tracker ({foodOrders.length})</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              </button>
            )}
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* TAB 1: RESTAURANT EXPLORER */}
          {activeTab === 'restaurants' && (
            <div className="space-y-5">
              {/* Search & Veg Filter */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="relative flex-1 w-full">
                  <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search dishes (Biryani, Sourdough Pizza, Ramen, Burgers)..."
                    className="w-full pl-9 pr-4 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl text-xs border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    onClick={() => setFilterVegOnly(!filterVegOnly)}
                    className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition cursor-pointer ${
                      filterVegOnly
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-300 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300'
                    }`}
                  >
                    <span className="w-3 h-3 rounded-full border border-emerald-600 flex items-center justify-center p-0.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                    </span>
                    <span>Pure Veg Only</span>
                  </button>

                  <span className="text-xs text-slate-500 font-medium">
                    ⚡ Indiranagar Delivery Hub
                  </span>
                </div>
              </div>

              {/* Restaurant Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredRestaurants.map((rest) => (
                  <div
                    key={rest.id}
                    onClick={() => handleOpenRestaurantMenu(rest)}
                    className="group bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700/80 overflow-hidden hover:shadow-xl hover:border-orange-300 transition cursor-pointer flex flex-col"
                  >
                    <div className="relative h-44 overflow-hidden bg-slate-100">
                      <img
                        src={rest.image}
                        alt={rest.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-100/80 via-slate-100/20 to-transparent" />

                      {rest.isPromoted && (
                        <span className="absolute top-2.5 left-2.5 bg-orange-600 text-white text-[10px] font-black px-2 py-0.5 rounded-md uppercase tracking-wider">
                          ⭐ Featured Partner
                        </span>
                      )}

                      {rest.isPureVeg && (
                        <span className="absolute top-2.5 right-2.5 bg-emerald-600 text-white text-[10px] font-black px-2 py-0.5 rounded-md flex items-center gap-1">
                          ● PURE VEG
                        </span>
                      )}

                      <div className="absolute bottom-2.5 left-3 right-3 text-white">
                        <span className="text-[11px] font-black bg-white/20 backdrop-blur-md px-2 py-0.5 rounded-md border border-white/30 text-amber-300 block mb-1 truncate">
                          {rest.discountOffer}
                        </span>
                      </div>
                    </div>

                    <div className="p-4 flex-1 flex flex-col justify-between space-y-2">
                      <div>
                        <div className="flex items-center justify-between">
                          <h3 className="font-extrabold text-slate-900 dark:text-white text-base truncate">
                            {rest.name}
                          </h3>
                          <span className="flex items-center gap-1 bg-emerald-700 text-white text-xs font-black px-1.5 py-0.5 rounded-md">
                            {rest.rating} <Star className="w-3 h-3 fill-white" />
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                          {rest.cuisines.join(' • ')}
                        </p>
                      </div>

                      <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs text-slate-500 font-medium">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-orange-500" />
                          {rest.deliveryTimeMin}-{rest.deliveryTimeMax} mins
                        </span>
                        <span>₹{rest.priceForTwo} for two</span>
                        <span>{rest.distanceKm} km</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: RESTAURANT MENU & LIVE FOOD CART */}
          {activeTab === 'menu' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left 2 Cols: Menu */}
              <div className="lg:col-span-2 space-y-6">
                {/* Banner */}
                <div className="relative rounded-2xl overflow-hidden h-40 bg-slate-900 text-white p-5 flex flex-col justify-end">
                  <img
                    src={currentRestaurant.bannerImage}
                    alt={currentRestaurant.name}
                    className="absolute inset-0 w-full h-full object-cover opacity-40"
                  />
                  <div className="relative z-10">
                    <h2 className="text-2xl font-black text-white">{currentRestaurant.name}</h2>
                    <p className="text-xs text-slate-200 mt-0.5">{currentRestaurant.cuisines.join(' • ')} • {currentRestaurant.address}</p>
                    <div className="flex items-center gap-3 mt-2 text-xs">
                      <span className="bg-emerald-600 text-white font-bold px-2 py-0.5 rounded-md flex items-center gap-1">
                        {currentRestaurant.rating} <Star className="w-3 h-3 fill-white" />
                      </span>
                      <span>⏱️ {currentRestaurant.deliveryTimeMin}-{currentRestaurant.deliveryTimeMax} mins</span>
                      <span>🚴 ₹{currentRestaurant.priceForTwo} for two</span>
                    </div>
                  </div>
                </div>

                {/* Categories & Dishes */}
                {currentRestaurant.menuCategories.map((cat) => (
                  <div key={cat.id} className="space-y-3">
                    <h3 className="font-extrabold text-slate-900 dark:text-white text-lg border-b border-slate-200 dark:border-slate-700 pb-1.5 flex items-center justify-between">
                      <span>{cat.name}</span>
                      <span className="text-xs text-slate-400 font-semibold">{cat.items.length} items</span>
                    </h3>

                    <div className="space-y-3">
                      {cat.items.map((dish) => {
                        const inCartItem = foodCart.find((i) => i.foodItem.id === dish.id);
                        return (
                          <div
                            key={dish.id}
                            className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-4"
                          >
                            <div className="flex-1 min-w-0 space-y-1">
                              <div className="flex items-center gap-2">
                                <span
                                  className={`w-3.5 h-3.5 border rounded-sm flex items-center justify-center p-0.5 ${
                                    dish.isVeg
                                      ? 'border-emerald-600'
                                      : 'border-rose-600'
                                  }`}
                                >
                                  <span
                                    className={`w-1.5 h-1.5 rounded-full ${
                                      dish.isVeg ? 'bg-emerald-600' : 'bg-rose-600'
                                    }`}
                                  />
                                </span>
                                {dish.isBestseller && (
                                  <span className="text-[9px] font-black uppercase tracking-wider bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-300 px-1.5 py-0.5 rounded">
                                    ⭐ Bestseller
                                  </span>
                                )}
                                {dish.isSpicy && (
                                  <span className="text-[9px] font-black bg-rose-100 text-rose-800 px-1.5 py-0.5 rounded">
                                    🌶️ Spicy
                                  </span>
                                )}
                              </div>

                              <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                                {dish.name}
                              </h4>
                              <div className="flex items-baseline gap-2">
                                <span className="font-mono font-black text-slate-900 dark:text-white text-sm">
                                  ₹{dish.price}
                                </span>
                                {dish.mrp > dish.price && (
                                  <span className="font-mono text-xs text-slate-400 line-through">
                                    ₹{dish.mrp}
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                                {dish.description}
                              </p>
                            </div>

                            {/* Image & Add Button */}
                            <div className="relative w-28 h-24 rounded-xl overflow-hidden bg-slate-200 flex-shrink-0">
                              <img
                                src={dish.image}
                                alt={dish.name}
                                className="w-full h-full object-cover"
                              />
                              <div className="absolute inset-x-2 bottom-1.5">
                                {inCartItem ? (
                                  <div className="bg-orange-600 text-white font-bold text-xs py-1 px-2 rounded-lg flex items-center justify-between shadow-md">
                                    <button
                                      onClick={() =>
                                        updateFoodCartQuantity(dish.id, inCartItem.quantity - 1)
                                      }
                                      className="hover:opacity-80 cursor-pointer"
                                    >
                                      <Minus className="w-3 h-3" />
                                    </button>
                                    <span>{inCartItem.quantity}</span>
                                    <button
                                      onClick={() =>
                                        updateFoodCartQuantity(dish.id, inCartItem.quantity + 1)
                                      }
                                      className="hover:opacity-80 cursor-pointer"
                                    >
                                      <Plus className="w-3 h-3" />
                                    </button>
                                  </div>
                                ) : (
                                  <button
                                    onClick={() => handleAddDishClick(dish)}
                                    className="w-full bg-white text-orange-600 font-extrabold text-xs py-1 rounded-lg border border-orange-200 shadow-md hover:bg-orange-50 transition cursor-pointer"
                                  >
                                    ADD +
                                  </button>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>

              {/* Right Col: Live Cart & Bill Summary */}
              <div className="space-y-4">
                <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm space-y-4 sticky top-4">
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                    <div className="flex items-center gap-2">
                      <ShoppingBag className="w-4 h-4 text-orange-500" />
                      <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                        Food Bag ({foodCart.length} items)
                      </h3>
                    </div>
                    {foodCart.length > 0 && (
                      <button
                        onClick={clearFoodCart}
                        className="text-[11px] text-rose-600 hover:underline font-semibold"
                      >
                        Clear
                      </button>
                    )}
                  </div>

                  {/* Cart Items List */}
                  {foodCart.length === 0 ? (
                    <div className="text-center py-8 text-slate-400 space-y-2">
                      <UtensilsCrossed className="w-8 h-8 mx-auto opacity-40 text-orange-500" />
                      <p className="text-xs font-semibold">Your food bag is empty</p>
                      <p className="text-[11px]">Add delicious starters & meals to checkout</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {foodCart.map((item) => (
                        <div
                          key={item.foodItem.id}
                          className="flex items-center justify-between text-xs py-1.5 border-b border-slate-50 dark:border-slate-750"
                        >
                          <div className="flex-1 pr-2">
                            <span className="font-bold text-slate-900 dark:text-white block">
                              {item.foodItem.name}
                            </span>
                            {item.selectedOptions?.portion && (
                              <span className="text-[10px] text-slate-400 block">
                                {item.selectedOptions.portion}
                              </span>
                            )}
                            <span className="font-mono text-slate-700 dark:text-slate-300 font-semibold">
                              ₹{(item.foodItem.price + (item.extraPrice || 0)) * item.quantity}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded-lg">
                            <button
                              onClick={() =>
                                updateFoodCartQuantity(item.foodItem.id, item.quantity - 1)
                              }
                              className="hover:text-orange-600 cursor-pointer"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="font-bold font-mono">{item.quantity}</span>
                            <button
                              onClick={() =>
                                updateFoodCartQuantity(item.foodItem.id, item.quantity + 1)
                              }
                              className="hover:text-orange-600 cursor-pointer"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      ))}

                      {/* Rider Tip Selector */}
                      <div className="pt-2">
                        <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-1.5">
                          🚴 Tip Your Delivery Hero (100% goes to rider):
                        </label>
                        <div className="flex gap-2">
                          {[20, 30, 50].map((amount) => (
                            <button
                              key={amount}
                              onClick={() => setRiderTip(amount)}
                              className={`flex-1 py-1 rounded-lg text-xs font-bold border transition ${
                                riderTip === amount
                                  ? 'bg-orange-500 text-white border-orange-500'
                                  : 'bg-slate-50 dark:bg-slate-700 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-600'
                              }`}
                            >
                              ₹{amount}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Bill Breakdown */}
                      <div className="pt-3 border-t border-slate-100 dark:border-slate-700 space-y-1.5 text-xs">
                        <div className="flex justify-between text-slate-500">
                          <span>Item Total</span>
                          <span className="font-mono">₹{cartSubtotal}</span>
                        </div>
                        <div className="flex justify-between text-slate-500">
                          <span>Delivery Fee</span>
                          {antiflyOneSubscription.isActive ? (
                            <span className="font-bold text-emerald-600">FREE (AntiflyOne VIP)</span>
                          ) : (
                            <span className="font-mono">₹39</span>
                          )}
                        </div>
                        {antiflyOneDiscount > 0 && (
                          <div className="flex justify-between text-emerald-600 font-semibold">
                            <span>AntiflyOne 10% Pass Discount</span>
                            <span className="font-mono">-₹{antiflyOneDiscount}</span>
                          </div>
                        )}
                        <div className="flex justify-between text-slate-500">
                          <span>Restaurant GST & Handling (5%)</span>
                          <span className="font-mono">₹{taxes}</span>
                        </div>
                        <div className="flex justify-between text-slate-500">
                          <span>Rider Tip</span>
                          <span className="font-mono">₹{riderTip}</span>
                        </div>

                        <div className="flex justify-between items-baseline pt-2 border-t border-slate-200 dark:border-slate-700 font-extrabold text-slate-900 dark:text-white text-sm">
                          <span>To Pay</span>
                          <span className="font-mono text-base text-orange-600">₹{cartTotal}</span>
                        </div>
                      </div>

                      {/* Place Order Button */}
                      <button
                        onClick={handleExecutePlaceOrder}
                        disabled={isPlacingOrder}
                        className="w-full bg-gradient-to-r from-orange-500 to-rose-600 hover:from-orange-400 hover:to-rose-500 text-white font-extrabold py-3 rounded-xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                      >
                        {isPlacingOrder ? (
                          <span>Sending to Kitchen...</span>
                        ) : (
                          <>
                            <span>Place Food Order • ₹{cartTotal}</span>
                            <ChevronRight className="w-4 h-4" />
                          </>
                        )}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: LIVE FOOD ORDER TRACKER */}
          {activeTab === 'tracking' && (
            <div className="space-y-6">
              {foodOrders.length === 0 ? (
                <div className="text-center py-12 text-slate-400">
                  <Bike className="w-12 h-12 mx-auto opacity-30 text-orange-500 mb-2" />
                  <p className="font-bold">No active food deliveries currently.</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Active Order Card */}
                  {foodOrders[activeTrackingOrderIndex] && (
                    <div className="p-6 rounded-3xl bg-gradient-to-br from-orange-50 via-amber-50 to-white dark:from-slate-800 dark:to-slate-900 border border-orange-200 dark:border-slate-700 space-y-6">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={foodOrders[activeTrackingOrderIndex].restaurantImage}
                            alt=""
                            className="w-14 h-14 rounded-2xl object-cover"
                          />
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-black uppercase tracking-wider bg-orange-600 text-white px-2 py-0.5 rounded-full">
                                {foodOrders[activeTrackingOrderIndex].id}
                              </span>
                              <span className="text-xs text-slate-500 font-medium">
                                Placed at {foodOrders[activeTrackingOrderIndex].placedAt}
                              </span>
                            </div>
                            <h3 className="text-lg font-black text-slate-900 dark:text-white mt-0.5">
                              {foodOrders[activeTrackingOrderIndex].restaurantName}
                            </h3>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="text-xs text-slate-500 font-bold block">Estimated Arrival</span>
                          <span className="text-xl font-black text-orange-600 font-mono">
                            {foodOrders[activeTrackingOrderIndex].etaMinutes} Minutes
                          </span>
                        </div>
                      </div>

                      {/* Live Step Progress Bar */}
                      <div className="grid grid-cols-4 gap-2 pt-2">
                        {[
                          { title: 'Order Confirmed', done: true },
                          { title: 'Kitchen Cooking', done: true },
                          { title: 'Rider Picked Up', done: true },
                          { title: 'Arriving at Doorstep', done: false },
                        ].map((step, idx) => (
                          <div key={idx} className="space-y-1">
                            <div
                              className={`h-2 rounded-full ${
                                step.done ? 'bg-orange-500' : 'bg-slate-200 dark:bg-slate-700'
                              }`}
                            />
                            <p className="text-[10px] font-bold text-slate-700 dark:text-slate-300 truncate">
                              {step.title}
                            </p>
                          </div>
                        ))}
                      </div>

                      {/* Delivery Rider Contact Info */}
                      <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-orange-100 dark:bg-orange-950 text-orange-600 flex items-center justify-center font-bold">
                            <Bike className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="font-bold text-xs text-slate-900 dark:text-white">
                              {foodOrders[activeTrackingOrderIndex].riderName}
                            </p>
                            <p className="text-[11px] text-slate-400 font-mono">
                              {foodOrders[activeTrackingOrderIndex].riderVehicle}
                            </p>
                          </div>
                        </div>

                        <a
                          href={`tel:${foodOrders[activeTrackingOrderIndex].riderPhone}`}
                          className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          <span>Call Rider</span>
                        </a>
                      </div>

                      {/* Ordered Items Summary */}
                      <div className="text-xs space-y-1 text-slate-600 dark:text-slate-400">
                        <span className="font-bold block text-slate-900 dark:text-white">Items:</span>
                        {foodOrders[activeTrackingOrderIndex].items.map((i, idx) => (
                          <div key={idx} className="flex justify-between">
                            <span>
                              {i.quantity}x {i.foodItem.name}
                            </span>
                            <span className="font-mono">₹{i.foodItem.price * i.quantity}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Dish Customization Modal */}
        {selectedCustomizingItem && (
          <div className="fixed inset-0 z-60 bg-slate-100/70 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl p-5 space-y-4 border border-slate-200 dark:border-slate-800 shadow-2xl">
              <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-2">
                <h3 className="font-extrabold text-slate-900 dark:text-white text-base">
                  Customize {selectedCustomizingItem.name}
                </h3>
                <button
                  onClick={() => setSelectedCustomizingItem(null)}
                  className="text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {selectedCustomizingItem.customizationOptions?.map((group, idx) => (
                <div key={idx} className="space-y-2">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                    {group.name} {group.required && <span className="text-rose-500">*</span>}
                  </label>
                  <div className="space-y-1.5">
                    {group.options.map((opt, oIdx) => (
                      <button
                        key={oIdx}
                        onClick={() => setCustomPortion(opt.label)}
                        className={`w-full p-2.5 rounded-xl text-xs font-bold text-left flex justify-between border transition ${
                          customPortion === opt.label
                            ? 'bg-orange-50 border-orange-500 text-orange-950 dark:bg-orange-950 dark:text-orange-200'
                            : 'bg-slate-50 border-slate-200 text-slate-700 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <span>{opt.label}</span>
                        {opt.price > 0 && <span>+₹{opt.price}</span>}
                      </button>
                    ))}
                  </div>
                </div>
              ))}

              <div className="pt-2 flex gap-3">
                <button
                  onClick={handleConfirmCustomization}
                  className="flex-1 bg-orange-600 hover:bg-orange-500 text-white font-bold py-2.5 rounded-xl text-xs shadow"
                >
                  Add Custom Dish
                </button>
                <button
                  onClick={() => setSelectedCustomizingItem(null)}
                  className="px-4 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl text-xs"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
