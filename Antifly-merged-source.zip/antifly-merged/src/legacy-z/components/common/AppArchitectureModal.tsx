import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Layers,
  Sparkles,
  Smartphone,
  Store,
  Truck,
  ShieldCheck,
  CheckCircle2,
  TrendingUp,
  CreditCard,
  QrCode,
  Users,
  MessageSquare,
  RefreshCw,
  X,
  FileText,
  DollarSign,
  ArrowRight,
  Server,
  Zap,
} from 'lucide-react';

export const AppArchitectureModal: React.FC = () => {
  const {
    isAppArchitectureModalOpen,
    setIsAppArchitectureModalOpen,
    resellerEarnings,
    resellerWalletBalance,
    currentDriver,
    driverTasks,
    currentSeller,
    orders,
    formatPrice,
    setDeviceMode,
    setIsUniversalChatOpen,
    setIsCommunityHubOpen,
    setIsResellerModalOpen,
    setIsCheckoutOpen,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'overview' | 'driver_earnings' | 'reseller_earnings' | 'qr_payment' | 'chat_community'>('overview');

  if (!isAppArchitectureModalOpen) return null;

  return (
    <div
      id="app-architecture-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-100/65 backdrop-blur-md p-2 sm:p-4 overflow-y-auto"
    >
      <div className="bg-white w-full max-w-5xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-slate-100 animate-in fade-in zoom-in-95">
        {/* HEADER */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-5 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center">
              <Layers className="w-6 h-6 text-indigo-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-bold tracking-tight">
                  Antifly Ecosystem Architecture & Interactive Proof
                </h2>
                <span className="bg-emerald-500/20 text-emerald-300 text-[11px] px-2 py-0.5 rounded-full font-semibold border border-emerald-400/30">
                  Full Synchronization Live
                </span>
              </div>
              <p className="text-xs text-indigo-200/80 mt-0.5">
                Explore how the Driver App, Seller App, Reseller Margin, BharatQR payments, and WhatsApp Chat synchronize in real-time.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAppArchitectureModalOpen(false)}
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* NAVIGATION TABS */}
        <div className="bg-slate-50 border-b border-slate-200 px-4 sm:px-6 py-2.5 flex items-center space-x-2 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === 'overview'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            🌟 Ecosystem Flowchart
          </button>

          <button
            onClick={() => setActiveTab('driver_earnings')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'driver_earnings'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            <Truck className="w-3.5 h-3.5" /> Driver Earnings & OTP Proof
          </button>

          <button
            onClick={() => setActiveTab('reseller_earnings')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'reseller_earnings'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" /> Reseller Margin Proof
          </button>

          <button
            onClick={() => setActiveTab('qr_payment')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'qr_payment'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" /> BharatQR Instant Pay
          </button>

          <button
            onClick={() => setActiveTab('chat_community')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'chat_community'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" /> WhatsApp Chat & 15s Reels
          </button>
        </div>

        {/* TAB BODY */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-50/50 space-y-6">
          {/* TAB 1: ECOSYSTEM FLOWCHART */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Architecture Core Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {/* 1. Customer App */}
                <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm relative">
                  <div className="w-10 h-10 rounded-xl bg-red-100 text-red-600 flex items-center justify-center mb-3">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <h4 className="font-bold text-sm text-slate-900">1. Customer Storefront</h4>
                  <p className="text-xs text-slate-500 mt-1">
                    Multi-country currency conversion, BharatQR & UPI instant checkout, and 5-Day SLA cancellation.
                  </p>
                  <button
                    onClick={() => {
                      setDeviceMode('website');
                      setIsAppArchitectureModalOpen(false);
                    }}
                    className="mt-3 text-xs text-red-600 font-bold hover:underline flex items-center gap-1"
                  >
                    Open Customer App <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                {/* 2. Seller Central */}
                <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm relative">
                  <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center mb-3">
                    <Store className="w-5 h-5" />
                  </div>
                  <h4 className="font-bold text-sm text-slate-900">2. Seller Central</h4>
                  <p className="text-xs text-slate-500 mt-1">
                    Direct handloom inventory management, live order dispatching, driver assignment, and instant bank payouts.
                  </p>
                  <button
                    onClick={() => {
                      setDeviceMode('seller');
                      setIsAppArchitectureModalOpen(false);
                    }}
                    className="mt-3 text-xs text-amber-700 font-bold hover:underline flex items-center gap-1"
                  >
                    Open Seller Central <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                {/* 3. Driver Logistics */}
                <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm relative">
                  <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center mb-3">
                    <Truck className="w-5 h-5" />
                  </div>
                  <h4 className="font-bold text-sm text-slate-900">3. Driver Logistics</h4>
                  <p className="text-xs text-slate-500 mt-1">
                    Real-time GPS routing, OTP delivery confirmation, cash collection, and automatic driver wallet earnings.
                  </p>
                  <button
                    onClick={() => {
                      setDeviceMode('driver');
                      setIsAppArchitectureModalOpen(false);
                    }}
                    className="mt-3 text-xs text-blue-600 font-bold hover:underline flex items-center gap-1"
                  >
                    Open Driver App <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                {/* 4. Universal Chat & Community */}
                <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm relative">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center mb-3">
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <h4 className="font-bold text-sm text-slate-900">4. Universal Chat & Hub</h4>
                  <p className="text-xs text-slate-500 mt-1">
                    WhatsApp style 1-to-1 chats for customers, sellers, drivers, plus 15s video reels with direct shopping.
                  </p>
                  <button
                    onClick={() => {
                      setIsUniversalChatOpen(true);
                      setIsAppArchitectureModalOpen(false);
                    }}
                    className="mt-3 text-xs text-emerald-700 font-bold hover:underline flex items-center gap-1"
                  >
                    Launch Chat <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Data Flow Pipeline Banner */}
              <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
                <h3 className="font-bold text-sm text-slate-900 mb-3 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-500" />
                  Complete Lifecycle of an Order in Antifly:
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 text-xs text-slate-700">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="font-bold text-slate-900 block mb-1">Step 1: Checkout</span>
                    Customer pays via QR code / UPI / Card / COD. An order and secure 4-digit OTP are minted.
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="font-bold text-slate-900 block mb-1">Step 2: Reseller Margin</span>
                    If ordered via Reseller link, margin (e.g. ₹500) is instantly credited to the Reseller Wallet.
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="font-bold text-slate-900 block mb-1">Step 3: Seller Dispatch</span>
                    Seller sees incoming order, packages stock, generates AWB, and requests driver pickup.
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="font-bold text-slate-900 block mb-1">Step 4: Driver Delivery</span>
                    Driver accepts trip on Driver App, navigates to doorstep, and inputs customer's 4-digit OTP.
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="font-bold text-slate-900 block mb-1">Step 5: Automatic Earnings</span>
                    Driver wallet is credited delivery fee + tip (₹105+), seller balance unlocks, and invoice is finalized!
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: DRIVER EARNINGS */}
          {activeTab === 'driver_earnings' && (
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-2xl p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-base text-blue-950">
                      Driver Earnings Engine ({currentDriver.name})
                    </h3>
                    <p className="text-xs text-blue-800 mt-1">
                      Every delivery completed with OTP verification automatically credits the driver's wallet and updates their daily earnings tally.
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-blue-600 font-semibold">Driver Wallet Balance</span>
                    <p className="text-2xl font-black text-blue-900">{formatPrice(currentDriver.walletBalance)}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-4 border border-slate-200">
                <h4 className="font-bold text-xs text-slate-900 mb-3">Live Active Deliveries & Payouts</h4>
                <div className="space-y-2.5">
                  {driverTasks.map((task) => (
                    <div
                      key={task.id}
                      className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900">{task.customerName}</span>
                          <span className="bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded font-mono text-[10px]">
                            {task.id}
                          </span>
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                              task.status === 'Delivered'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {task.status}
                          </span>
                        </div>
                        <p className="text-slate-500 text-[11px] mt-0.5">{task.customerAddress}</p>
                      </div>

                      <div className="text-right">
                        <span className="font-bold text-emerald-700 text-sm">
                          +₹{task.payoutFee + task.tipAmount}
                        </span>
                        <span className="block text-[10px] text-slate-400">
                          (₹{task.payoutFee} fee + ₹{task.tipAmount} tip)
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="text-center pt-2">
                <button
                  onClick={() => {
                    setDeviceMode('driver');
                    setIsAppArchitectureModalOpen(false);
                  }}
                  className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs shadow transition-colors"
                >
                  Switch to Driver App to Complete Trip & Verify OTP
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: RESELLER EARNINGS */}
          {activeTab === 'reseller_earnings' && (
            <div className="space-y-4">
              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-base text-amber-950">
                      Reseller Profit Margin Engine (Zero Investment)
                    </h3>
                    <p className="text-xs text-amber-800 mt-1">
                      Resellers set their custom selling price. The difference between wholesale and customer payment is directly credited to their Reseller Wallet with 1-click UPI payouts.
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-amber-700 font-semibold">Reseller Balance Available</span>
                    <p className="text-2xl font-black text-amber-900">{formatPrice(resellerWalletBalance)}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-4 border border-slate-200">
                <h4 className="font-bold text-xs text-slate-900 mb-3">Itemized Reseller Margin Ledger</h4>
                <div className="space-y-2">
                  {resellerEarnings.map((record) => (
                    <div
                      key={record.id}
                      className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs"
                    >
                      <div>
                        <p className="font-bold text-slate-900">{record.productName}</p>
                        <p className="text-[11px] text-slate-500">
                          Order: {record.orderNumber} • Buyer: {record.customerName} • {record.date}
                        </p>
                      </div>

                      <div className="text-right">
                        <span
                          className={`font-bold text-sm ${
                            record.marginEarned > 0 ? 'text-emerald-600' : 'text-slate-600'
                          }`}
                        >
                          {record.marginEarned > 0 ? `+${formatPrice(record.marginEarned)}` : formatPrice(record.marginEarned)}
                        </span>
                        <span className="block text-[10px] text-slate-400">{record.status}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="text-center pt-2">
                <button
                  onClick={() => {
                    setIsResellerModalOpen(true);
                    setIsAppArchitectureModalOpen(false);
                  }}
                  className="px-6 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs shadow transition-colors"
                >
                  Open Reseller Business Hub & Withdraw to UPI
                </button>
              </div>
            </div>
          )}

          {/* TAB 4: BHARATQR PAYMENT */}
          {activeTab === 'qr_payment' && (
            <div className="space-y-4">
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-base text-emerald-950">
                      BharatQR & Dynamic UPI Instant Payment Gateway
                    </h3>
                    <p className="text-xs text-emerald-800 mt-1">
                      Customers scan the dynamic QR code using Google Pay, PhonePe, Paytm, or any banking app. Payment is validated with zero latency.
                    </p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                    <QrCode className="w-7 h-7" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-white rounded-2xl p-4 border border-slate-200 flex flex-col items-center text-center">
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl mb-3">
                    <img
                      src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=upi://pay?pa=antifly.pay@icici&pn=Antifly%20Commerce&mc=5411"
                      alt="Sample BharatQR"
                      className="w-40 h-40"
                    />
                  </div>
                  <p className="text-xs font-bold text-slate-800">Dynamic Order BharatQR</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Compatible with NPCI UPI 2.0 specs</p>
                </div>

                <div className="bg-white rounded-2xl p-4 border border-slate-200 text-xs text-slate-700 space-y-3">
                  <h4 className="font-bold text-slate-900">QR Payment Security Matrix</h4>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span><strong>Instant Webhook:</strong> Payment status flips from Pending to Success in 800ms.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span><strong>Automatic Invoice IRN:</strong> Generates GST compliant invoice with verified digital signature.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span><strong>OTP Handover Binding:</strong> Auto-creates customer delivery OTP to prevent porch theft.</span>
                    </li>
                  </ul>

                  <button
                    onClick={() => {
                      setIsCheckoutOpen(true);
                      setIsAppArchitectureModalOpen(false);
                    }}
                    className="w-full mt-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow transition-colors"
                  >
                    Test Live Checkout & Scan QR Code
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: CHAT & COMMUNITY */}
          {activeTab === 'chat_community' && (
            <div className="space-y-4">
              <div className="bg-purple-50 border border-purple-200 rounded-2xl p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-base text-purple-950">
                      WhatsApp Style Universal 1-to-1 Chat & 15s Reels Community
                    </h3>
                    <p className="text-xs text-purple-800 mt-1">
                      Connect customers directly with sellers, drivers, and fellow creators. Share 15s video reels, lookbook photos, voice notes, and live catalog snippets with end-to-end encryption.
                    </p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center">
                    <MessageSquare className="w-7 h-7" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-white rounded-2xl p-4 border border-slate-200 text-xs">
                  <h4 className="font-bold text-slate-900 mb-2 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    Security & Privacy Controls
                  </h4>
                  <ul className="space-y-1.5 text-slate-600">
                    <li>• Enable / Disable chat switch per conversation</li>
                    <li>• Disappearing messages (24h / 7d / Off)</li>
                    <li>• 1-Click contact block & spam reporting</li>
                    <li>• Mute push notification toggles</li>
                  </ul>
                  <button
                    onClick={() => {
                      setIsUniversalChatOpen(true);
                      setIsAppArchitectureModalOpen(false);
                    }}
                    className="mt-4 w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs"
                  >
                    Open Universal WhatsApp Chat
                  </button>
                </div>

                <div className="bg-white rounded-2xl p-4 border border-slate-200 text-xs">
                  <h4 className="font-bold text-slate-900 mb-2 flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-rose-600" />
                    Join Community Hub Features
                  </h4>
                  <ul className="space-y-1.5 text-slate-600">
                    <li>• 15-Second short video reels showcasing fabric shine</li>
                    <li>• Photo outfit lookbooks with tagged "Buy Now" links</li>
                    <li>• Live comments, likes, and WhatsApp direct share</li>
                    <li>• Master Weaver artisan stories</li>
                  </ul>
                  <button
                    onClick={() => {
                      setIsCommunityHubOpen(true);
                      setIsAppArchitectureModalOpen(false);
                    }}
                    className="mt-4 w-full py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs"
                  >
                    Open Join Community Hub
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
