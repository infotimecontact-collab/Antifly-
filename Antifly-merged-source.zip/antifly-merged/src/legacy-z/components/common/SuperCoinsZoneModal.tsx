import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Coins,
  Gem,
  X,
  Sparkles,
  Gift,
  Crown,
  TrendingUp,
  Flame,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldCheck,
  ChevronRight,
  Award,
  Zap,
  Copy,
  Check,
  Share2,
  Users,
  Play,
  Search,
  Camera,
  ShoppingBag,
  ExternalLink,
  DollarSign,
  AlertTriangle,
  Lock,
  RefreshCw,
  Sliders,
  Wallet,
} from 'lucide-react';
import {
  INITIAL_SUPER_COIN_WALLET,
  INITIAL_DIAMOND_WALLET,
  INITIAL_LOYALTY_TIER,
  INITIAL_CHECKIN_DAYS,
  INITIAL_REWARD_MISSIONS,
  INITIAL_FLASH_EVENTS,
  INITIAL_REFERRAL_DATA,
  INITIAL_CREATOR_DIAMOND_STATS,
  INITIAL_SELLER_REWARD_CONFIG,
  INITIAL_REWARD_TRANSACTIONS,
  INITIAL_FRAUD_RULES,
  INITIAL_FRAUD_AUDIT_LOGS,
  DailyCheckInDay,
} from '../../data/rewardsData';
import { RewardMissionItem, UnifiedRewardTransaction } from '../../types';

export const SuperCoinsZoneModal: React.FC = () => {
  const {
    isSuperCoinsModalOpen,
    setIsSuperCoinsModalOpen,
    superCoinsBalance,
    setSuperCoinsBalance,
    superCoinRewards,
    redeemSuperCoinReward,
    isPlusMember,
    showToast,
    formatPrice,
  } = useApp();

  // State Management
  const [activeTab, setActiveTab] = useState<
    'hub' | 'missions' | 'flash' | 'tier' | 'rewards' | 'referrals' | 'creator' | 'seller' | 'history' | 'security'
  >('hub');
  const [selectedCurrencyView, setSelectedCurrencyView] = useState<'super_coins' | 'diamonds'>('super_coins');
  const [checkInDays, setCheckInDays] = useState<DailyCheckInDay[]>(INITIAL_CHECKIN_DAYS);
  const [missions, setMissions] = useState<RewardMissionItem[]>(INITIAL_REWARD_MISSIONS);
  const [transactions, setTransactions] = useState<UnifiedRewardTransaction[]>(INITIAL_REWARD_TRANSACTIONS);
  const [diamondBalance, setDiamondBalance] = useState<number>(INITIAL_DIAMOND_WALLET.balance);
  const [historyFilter, setHistoryFilter] = useState<'all' | 'super_coins' | 'diamonds'>('all');
  const [rewardCategory, setRewardCategory] = useState<string>('all');
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [payoutRequested, setPayoutRequested] = useState<boolean>(false);

  if (!isSuperCoinsModalOpen) return null;

  // Handlers
  const handleClaimDailyCheckIn = (dayNumber: number) => {
    setCheckInDays((prev) =>
      prev.map((d) => (d.dayNumber === dayNumber ? { ...d, isClaimed: true } : d))
    );
    const day = checkInDays.find((d) => d.dayNumber === dayNumber);
    if (day) {
      setSuperCoinsBalance((prev) => prev + day.coins);
      if (day.diamonds) {
        setDiamondBalance((prev) => prev + day.diamonds);
      }
      // Add ledger transaction
      const newTx: UnifiedRewardTransaction = {
        id: `tx-checkin-${Date.now()}`,
        date: 'Just now',
        activityTitle: `Day ${day.dayNumber} Daily Streak Check-in`,
        activityType: 'daily_checkin',
        currency: 'super_coins',
        direction: 'credit',
        amount: day.coins,
        status: 'Completed',
        notes: `Claimed +${day.coins} Coins ${day.diamonds ? `and +${day.diamonds} Diamonds` : ''}`,
      };
      setTransactions((prev) => [newTx, ...prev]);
      showToast(`🎉 Claimed +${day.coins} Super Coins${day.diamonds ? ` & +${day.diamonds} Diamonds` : ''}!`);
    }
  };

  const handleClaimMission = (missionId: string) => {
    const mission = missions.find((m) => m.id === missionId);
    if (!mission || mission.isClaimed) return;

    setMissions((prev) =>
      prev.map((m) => (m.id === missionId ? { ...m, isClaimed: true } : m))
    );

    if (mission.rewardCoins > 0) {
      setSuperCoinsBalance((prev) => prev + mission.rewardCoins);
    }
    if (mission.rewardDiamonds > 0) {
      setDiamondBalance((prev) => prev + mission.rewardDiamonds);
    }

    const newTx: UnifiedRewardTransaction = {
      id: `tx-mission-${Date.now()}`,
      date: 'Just now',
      activityTitle: `Mission Complete: ${mission.title}`,
      activityType: 'mission_reward',
      currency: mission.currency === 'diamonds' ? 'diamonds' : 'super_coins',
      direction: 'credit',
      amount: mission.rewardCoins || mission.rewardDiamonds,
      status: 'Completed',
      notes: `Reward credited for ${mission.title}`,
    };
    setTransactions((prev) => [newTx, ...prev]);
    showToast(`✨ Claimed reward for "${mission.title}"!`);
  };

  const handleCompleteSocialAction = (missionId: string) => {
    setMissions((prev) =>
      prev.map((m) =>
        m.id === missionId
          ? { ...m, progress: m.maxProgress, isCompleted: true }
          : m
      )
    );
    showToast('🚀 Task completed! Click "Claim Reward" to collect your coins.');
  };

  const handleCopy = (text: string, type: 'code' | 'link') => {
    navigator.clipboard?.writeText(text);
    if (type === 'code') {
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    } else {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
    showToast('📋 Copied to clipboard!');
  };

  const handleRequestCreatorPayout = () => {
    if (diamondBalance < 1000) {
      showToast('⚠️ Minimum payout threshold is 1,000 Diamonds (₹500)');
      return;
    }
    setPayoutRequested(true);
    setTimeout(() => {
      setPayoutRequested(false);
      setDiamondBalance((prev) => prev - 1000);
      const newTx: UnifiedRewardTransaction = {
        id: `tx-payout-${Date.now()}`,
        date: 'Just now',
        activityTitle: 'Creator Instant UPI Payout (1,000 Diamonds)',
        activityType: 'diamond_payout',
        currency: 'diamonds',
        direction: 'debit',
        amount: 1000,
        status: 'Completed',
        notes: '₹500 transferred to verified UPI ID (priya@okhdfcbank)',
      };
      setTransactions((prev) => [newTx, ...prev]);
      showToast('💰 ₹500 successfully sent to your registered UPI ID!');
    }, 1200);
  };

  const filteredRewards = superCoinRewards.filter((r) => {
    if (rewardCategory === 'all') return true;
    return r.category === rewardCategory;
  });

  const filteredTransactions = transactions.filter((t) => {
    if (historyFilter === 'all') return true;
    return t.currency === historyFilter;
  });

  return (
    <div
      id="supercoins-zone-modal"
      className="fixed inset-0 z-50 bg-white/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 lg:p-6 animate-fade-in"
    >
      <div className="bg-white dark:bg-slate-900 w-full max-w-5xl rounded-3xl shadow-2xl border border-stone-200 dark:border-slate-800 overflow-hidden flex flex-col my-auto max-h-[94vh]">
        
        {/* TOP DUAL-CURRENCY HEADER BANNER */}
        <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 p-5 sm:p-6 text-slate-800 relative overflow-hidden flex-shrink-0">
          <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 opacity-15 pointer-events-none">
            <Coins className="w-64 h-64 text-slate-800" />
          </div>

          <div className="flex items-start justify-between relative z-10">
            <div className="flex items-center gap-3.5">
              <div className="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center border border-slate-200/10 shadow-inner">
                <Coins className="w-8 h-8 text-slate-800 fill-amber-300" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] font-black uppercase tracking-wider bg-white text-amber-300 px-2 py-0.5 rounded-full">
                    ⚡ Antifly Dual Economy
                  </span>
                  <span className="text-[10px] font-black text-slate-800 bg-amber-300/90 px-2 py-0.5 rounded-full flex items-center gap-1 border border-amber-400">
                    <Crown className="w-3 h-3" /> Gold Loyalty Member (1.5x Boost)
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black tracking-tight text-slate-800 mt-0.5">
                  Super Coins & Diamond Economy
                </h2>
                <p className="text-xs text-slate-900 font-semibold opacity-90">
                  Shop to earn Super Coins • Create & engage to earn Diamonds • 100% genuine value
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsSuperCoinsModalOpen(false)}
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-slate-800 transition cursor-pointer"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* DUAL WALLET STAT CARDS */}
          <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 relative z-10">
            {/* Super Coins Wallet */}
            <div
              onClick={() => setSelectedCurrencyView('super_coins')}
              className={`p-3.5 rounded-2xl cursor-pointer transition-all border ${
                selectedCurrencyView === 'super_coins'
                  ? 'bg-white text-amber-300 border-amber-400 shadow-lg scale-101'
                  : 'bg-white/20 text-slate-800 border-slate-200/10 hover:bg-white/30'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase tracking-wider opacity-80 flex items-center gap-1">
                  <Coins className="w-3.5 h-3.5 fill-amber-400" /> Super Coins Wallet
                </span>
                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-400/30 text-amber-300">
                  Shopping
                </span>
              </div>
              <div className="flex items-baseline gap-1.5 mt-1">
                <span className="text-2xl font-black">{superCoinsBalance}</span>
                <span className="text-xs font-semibold opacity-80">Coins (≈ ₹{superCoinsBalance})</span>
              </div>
              <div className="text-[10px] mt-1 opacity-75 flex items-center justify-between">
                <span>Pending: +{INITIAL_SUPER_COIN_WALLET.pendingCoins}</span>
                <span>Exp: {INITIAL_SUPER_COIN_WALLET.expiringCoins} on 28 Aug</span>
              </div>
            </div>

            {/* Diamonds Wallet */}
            <div
              onClick={() => setSelectedCurrencyView('diamonds')}
              className={`p-3.5 rounded-2xl cursor-pointer transition-all border ${
                selectedCurrencyView === 'diamonds'
                  ? 'bg-white text-sky-300 border-sky-400 shadow-lg scale-101'
                  : 'bg-white/20 text-slate-800 border-slate-200/10 hover:bg-white/30'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase tracking-wider opacity-80 flex items-center gap-1">
                  <Gem className="w-3.5 h-3.5 fill-sky-400 text-sky-300" /> Diamond Vault
                </span>
                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-sky-400/30 text-sky-300">
                  Creator & Social
                </span>
              </div>
              <div className="flex items-baseline gap-1.5 mt-1">
                <span className="text-2xl font-black">{diamondBalance}</span>
                <span className="text-xs font-semibold opacity-80">💎 (≈ ₹{Math.round(diamondBalance * 0.5)})</span>
              </div>
              <div className="text-[10px] mt-1 opacity-75 flex items-center justify-between">
                <span>Earned Today: +{INITIAL_DIAMOND_WALLET.todayEarnings}</span>
                <span>Rank: Top 3%</span>
              </div>
            </div>

            {/* Daily Goal Gauge */}
            <div className="bg-white/20 backdrop-blur-md rounded-2xl p-3.5 border border-slate-200/10 text-slate-800 flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase tracking-wider">Daily Goal</span>
                <span className="text-[10px] font-black bg-white text-amber-300 px-1.5 py-0.5 rounded">
                  80/100 Coins
                </span>
              </div>
              <div className="w-full bg-white/30 rounded-full h-2 overflow-hidden my-1">
                <div className="bg-amber-300 h-full rounded-full" style={{ width: '80%' }} />
              </div>
              <p className="text-[10px] font-semibold opacity-90">
                Complete 1 more task to unlock +20 bonus coins!
              </p>
            </div>

            {/* Loyalty Journey Card */}
            <div
              onClick={() => setActiveTab('tier')}
              className="bg-white/20 hover:bg-white/30 backdrop-blur-md rounded-2xl p-3.5 border border-slate-200/10 text-slate-800 cursor-pointer flex flex-col justify-between"
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase tracking-wider">Loyalty Journey</span>
                <span className="text-[10px] font-extrabold text-slate-800 flex items-center gap-0.5">
                  Tier Map <ChevronRight className="w-3 h-3" />
                </span>
              </div>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-base font-black">450 coins to</span>
                <span className="text-base font-black text-slate-800 underline">Platinum</span>
              </div>
              <p className="text-[10px] font-semibold opacity-80">
                Unlocks 2.0x coin multiplier & VIP Concierge
              </p>
            </div>
          </div>
        </div>

        {/* PRIMARY NAVIGATION TABS */}
        <div className="flex items-center px-4 sm:px-6 border-b border-stone-200 dark:border-slate-800 bg-stone-50 dark:bg-white overflow-x-auto gap-1 sm:gap-2 flex-shrink-0 scrollbar-none">
          {[
            { id: 'hub', label: 'Rewards Hub', icon: Gift },
            { id: 'missions', label: 'Daily Missions', icon: Flame },
            { id: 'flash', label: 'Flash Events', icon: Zap },
            { id: 'tier', label: 'Loyalty Tiers', icon: Crown },
            { id: 'rewards', label: 'Voucher Store', icon: ShoppingBag },
            { id: 'referrals', label: 'Refer & Earn', icon: Users },
            { id: 'creator', label: 'Creator Diamonds', icon: Gem },
            { id: 'seller', label: 'Seller Rewards', icon: Sliders },
            { id: 'history', label: 'Ledger History', icon: Clock },
            { id: 'security', label: 'Fraud Shield', icon: ShieldCheck },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3.5 px-3 text-xs font-extrabold border-b-2 flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer ${
                  isActive
                    ? 'border-amber-500 text-amber-600 dark:text-amber-400 bg-amber-50/50 dark:bg-amber-950/20'
                    : 'border-transparent text-stone-600 dark:text-slate-400 hover:text-stone-900 dark:hover:text-white'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-amber-500' : 'text-stone-400'}`} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* SCROLLABLE MODAL CONTENT BODY */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6 bg-white dark:bg-slate-900">
          
          {/* TAB 1: REWARDS HUB & 7-DAY STREAK */}
          {activeTab === 'hub' && (
            <div className="space-y-6">
              {/* 7-Day Check-in Calendar */}
              <div className="p-5 rounded-3xl bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50 dark:from-slate-800/80 dark:via-slate-800/50 dark:to-slate-900 border border-amber-200 dark:border-amber-900/40">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-800 flex items-center justify-center font-black">
                      <Flame className="w-5 h-5 fill-amber-300" />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-sm text-stone-900 dark:text-white">
                        7-Day Check-In Streak & Bonus Chest
                      </h3>
                      <p className="text-xs text-stone-500 dark:text-slate-400">
                        Check in daily to earn escalating Super Coins & bonus Creator Diamonds
                      </p>
                    </div>
                  </div>
                  <span className="text-xs font-black px-3 py-1 bg-amber-500 text-slate-800 rounded-full shadow-sm">
                    Active: 5-Day Streak 🔥
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2.5">
                  {checkInDays.map((day) => (
                    <div
                      key={day.dayNumber}
                      className={`p-3 rounded-2xl text-center border flex flex-col justify-between transition relative ${
                        day.isClaimed
                          ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800'
                          : day.isToday
                          ? 'bg-amber-100 dark:bg-amber-950/60 border-amber-400 ring-2 ring-amber-400 shadow-md'
                          : 'bg-white dark:bg-slate-800 border-stone-200 dark:border-slate-700 opacity-80'
                      }`}
                    >
                      <div className="text-[10px] font-bold uppercase text-stone-500 dark:text-slate-400">
                        Day {day.dayNumber} ({day.dayLabel})
                      </div>
                      <div className="my-2">
                        {day.isSpecialChest ? (
                          <div className="text-2xl animate-bounce">🎁</div>
                        ) : (
                          <Coins className="w-6 h-6 mx-auto text-amber-500 fill-amber-400" />
                        )}
                        <div className="text-xs font-black text-stone-900 dark:text-white mt-1">
                          +{day.coins} Coins
                        </div>
                        {day.diamonds && (
                          <div className="text-[10px] font-extrabold text-sky-600 dark:text-sky-400">
                            +{day.diamonds} 💎
                          </div>
                        )}
                      </div>

                      {day.isClaimed ? (
                        <span className="text-[10px] font-extrabold text-emerald-600 dark:text-emerald-400 flex items-center justify-center gap-0.5">
                          <CheckCircle2 className="w-3 h-3" /> Claimed
                        </span>
                      ) : day.isToday ? (
                        <button
                          onClick={() => handleClaimDailyCheckIn(day.dayNumber)}
                          className="w-full py-1 bg-amber-500 hover:bg-amber-400 text-slate-800 text-[10px] font-black rounded-lg shadow transition active:scale-95 cursor-pointer"
                        >
                          Claim Today
                        </button>
                      ) : (
                        <span className="text-[10px] font-semibold text-stone-400">Upcoming</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Core Economy Loop Infographic */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded-2xl bg-stone-50 dark:bg-slate-800/60 border border-stone-200 dark:border-slate-700">
                  <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300 flex items-center justify-center font-black text-xs mb-2">
                    01
                  </div>
                  <h4 className="font-bold text-xs text-stone-900 dark:text-white">Discover & Shop</h4>
                  <p className="text-[11px] text-stone-500 dark:text-slate-400 mt-0.5">
                    Earn 4-8 Super Coins for every ₹100 spent across authentic artisan collections.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-stone-50 dark:bg-slate-800/60 border border-stone-200 dark:border-slate-700">
                  <div className="w-8 h-8 rounded-xl bg-sky-100 text-sky-700 dark:bg-sky-950 dark:text-sky-300 flex items-center justify-center font-black text-xs mb-2">
                    02
                  </div>
                  <h4 className="font-bold text-xs text-stone-900 dark:text-white">Engage & Create</h4>
                  <p className="text-[11px] text-stone-500 dark:text-slate-400 mt-0.5">
                    Earn Diamonds by publishing shoppable reels, referring friends, and driving sales.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-stone-50 dark:bg-slate-800/60 border border-stone-200 dark:border-slate-700">
                  <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 flex items-center justify-center font-black text-xs mb-2">
                    03
                  </div>
                  <h4 className="font-bold text-xs text-stone-900 dark:text-white">Burn & Redeem</h4>
                  <p className="text-[11px] text-stone-500 dark:text-slate-400 mt-0.5">
                    Pay 1:1 at checkout, claim OTT passes, or withdraw Diamonds to UPI instantly.
                  </p>
                </div>
              </div>

              {/* Quick Action Highlights */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div
                  onClick={() => setActiveTab('flash')}
                  className="p-4 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-800 cursor-pointer shadow-md hover:scale-101 transition"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-wider bg-white text-amber-300 px-2 py-0.5 rounded-full">
                      ⚡ 10X Rush Active
                    </span>
                    <span className="text-xs font-extrabold">Ends in 28 mins</span>
                  </div>
                  <h4 className="text-base font-black mt-2">10X Super Coins on Festive Silks</h4>
                  <p className="text-xs font-semibold opacity-90 mt-0.5">
                    Earn up to 1,000 bonus coins on every handloom purchase today.
                  </p>
                </div>

                <div
                  onClick={() => setActiveTab('referrals')}
                  className="p-4 rounded-2xl bg-gradient-to-r from-indigo-900 to-slate-900 text-white cursor-pointer shadow-md hover:scale-101 transition border border-indigo-700"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-wider bg-indigo-500 text-white px-2 py-0.5 rounded-full">
                      🎁 Invite Friends
                    </span>
                    <span className="text-xs font-bold text-indigo-300">Earn 1,000 Coins</span>
                  </div>
                  <h4 className="text-base font-black mt-2">Invite 3 Friends → Unlock VIP Pass</h4>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Get 500 Super Coins + 100 Diamonds for every friend who shops.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: DAILY MISSIONS & QUESTS */}
          {activeTab === 'missions' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-extrabold text-base text-stone-900 dark:text-white">
                    Today's Missions & Challenges
                  </h3>
                  <p className="text-xs text-stone-500 dark:text-slate-400">
                    Complete social-commerce activities to earn instant reward tokens
                  </p>
                </div>
                <span className="text-xs font-bold text-stone-500">Resets daily at 12:00 AM</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {missions.map((mission) => (
                  <div
                    key={mission.id}
                    className="p-4 rounded-2xl border border-stone-200 dark:border-slate-800 bg-stone-50/70 dark:bg-slate-800/40 flex flex-col justify-between hover:border-amber-400/50 transition"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300">
                          {mission.badge || 'Quest'}
                        </span>
                        <div className="flex items-center gap-1.5 text-xs font-black">
                          {mission.rewardCoins > 0 && (
                            <span className="text-amber-600 dark:text-amber-400 flex items-center gap-0.5">
                              <Coins className="w-3.5 h-3.5 fill-amber-400" /> +{mission.rewardCoins}
                            </span>
                          )}
                          {mission.rewardDiamonds > 0 && (
                            <span className="text-sky-600 dark:text-sky-400 flex items-center gap-0.5">
                              <Gem className="w-3.5 h-3.5 fill-sky-400" /> +{mission.rewardDiamonds}
                            </span>
                          )}
                        </div>
                      </div>

                      <h4 className="font-bold text-xs sm:text-sm text-stone-900 dark:text-white mt-2">
                        {mission.title}
                      </h4>
                      <p className="text-[11px] text-stone-500 dark:text-slate-400 mt-0.5">
                        {mission.description}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-stone-200 dark:border-slate-700/60 mt-3 flex items-center justify-between">
                      <div className="text-[11px] font-bold text-stone-600 dark:text-slate-300">
                        Progress: {mission.progress}/{mission.maxProgress}
                      </div>

                      {mission.isClaimed ? (
                        <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Claimed
                        </span>
                      ) : mission.isCompleted ? (
                        <button
                          onClick={() => handleClaimMission(mission.id)}
                          className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-800 text-xs font-black rounded-xl shadow transition active:scale-95 cursor-pointer"
                        >
                          Claim Reward
                        </button>
                      ) : (
                        <button
                          onClick={() => handleCompleteSocialAction(mission.id)}
                          className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-amber-300 text-xs font-bold rounded-xl transition cursor-pointer"
                        >
                          {mission.ctaLabel}
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: FLASH COIN EVENTS */}
          {activeTab === 'flash' && (
            <div className="space-y-4">
              <div>
                <h3 className="font-extrabold text-base text-stone-900 dark:text-white">
                  Limited-Time Flash Coin Drops
                </h3>
                <p className="text-xs text-stone-500 dark:text-slate-400">
                  Time-sensitive shopping multipliers and festival coin boosts
                </p>
              </div>

              <div className="space-y-3">
                {INITIAL_FLASH_EVENTS.map((event) => (
                  <div
                    key={event.id}
                    className={`p-5 rounded-3xl text-white bg-gradient-to-r ${event.bgGradient} shadow-lg relative overflow-hidden`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded-full bg-slate-100/40 backdrop-blur-md text-[10px] font-black text-amber-300 border border-amber-400/30">
                            ⚡ {event.multiplier}
                          </span>
                          <span className="text-xs text-white/90 font-bold">
                            {event.categoryTag}
                          </span>
                        </div>
                        <h4 className="text-lg font-black mt-1">{event.title}</h4>
                        <p className="text-xs text-white/90 font-medium">{event.subtitle}</p>
                      </div>

                      <div className="flex sm:flex-col items-end justify-between sm:justify-center flex-shrink-0">
                        <div className="flex items-center gap-1.5 bg-slate-100/50 px-3 py-1.5 rounded-xl text-xs font-bold text-amber-300">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{event.endsAt}</span>
                        </div>
                        <div className="text-[10px] text-white/80 font-semibold mt-1">
                          Pool: {event.claimedPercent}% Claimed
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: LOYALTY TIER PROGRESSION */}
          {activeTab === 'tier' && (
            <div className="space-y-6">
              {/* Main Progress Card */}
              <div className="p-6 rounded-3xl bg-gradient-to-br from-amber-500 via-amber-600 to-yellow-600 text-slate-800 shadow-xl">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider bg-white text-amber-300 px-2.5 py-0.5 rounded-full">
                      Tier Level System
                    </span>
                    <h3 className="text-2xl font-black mt-1">Current Tier: Gold Member</h3>
                    <p className="text-xs font-bold opacity-90">
                      Enjoying 1.5X coin multiplier & Free Express Courier Delivery
                    </p>
                  </div>
                  <div className="w-14 h-14 rounded-2xl bg-white text-amber-400 flex items-center justify-center font-black shadow-lg">
                    <Crown className="w-8 h-8" />
                  </div>
                </div>

                {/* Progress Journey Bar */}
                <div className="mt-6 bg-white/20 backdrop-blur-md p-4 rounded-2xl border border-slate-200/15">
                  <div className="flex justify-between items-center text-xs font-bold mb-2">
                    <span>Lifetime Coins: 3,550</span>
                    <span className="bg-white text-amber-300 px-2 py-0.5 rounded-full text-[11px] font-black">
                      450 coins to Platinum (4,000 Total)
                    </span>
                  </div>
                  <div className="w-full bg-white/30 h-3.5 rounded-full overflow-hidden p-0.5">
                    <div
                      className="bg-gradient-to-r from-yellow-300 to-white h-full rounded-full transition-all duration-500"
                      style={{ width: '88%' }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] font-black uppercase mt-2">
                    <span>Bronze (0)</span>
                    <span>Silver (1k)</span>
                    <span className="text-slate-800 underline font-black">Gold (2.5k)</span>
                    <span>Platinum (4k)</span>
                    <span>Diamond (10k)</span>
                  </div>
                </div>
              </div>

              {/* Tier Comparison Perks */}
              <div className="space-y-3">
                <h4 className="font-extrabold text-sm text-stone-900 dark:text-white">
                  Gold Member Unlocked Perks
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {INITIAL_LOYALTY_TIER.perks.map((perk, idx) => (
                    <div
                      key={idx}
                      className={`p-4 rounded-2xl border flex items-start gap-3 ${
                        perk.isUnlocked
                          ? 'bg-amber-50/50 dark:bg-slate-800 border-amber-300 dark:border-amber-900/40'
                          : 'bg-stone-50 dark:bg-slate-900 border-stone-200 dark:border-slate-800 opacity-60'
                      }`}
                    >
                      <div
                        className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 font-bold ${
                          perk.isUnlocked
                            ? 'bg-amber-500 text-slate-800'
                            : 'bg-stone-200 dark:bg-slate-700 text-stone-500'
                        }`}
                      >
                        {perk.isUnlocked ? <Check className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                      </div>
                      <div>
                        <h5 className="font-bold text-xs text-stone-900 dark:text-white">{perk.title}</h5>
                        <p className="text-[11px] text-stone-500 dark:text-slate-400 mt-0.5">
                          {perk.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: VOUCHER REWARDS STORE */}
          {activeTab === 'rewards' && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                {['all', 'Discount', 'OTT', 'Travel', 'Dining', 'GiftCard'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setRewardCategory(cat)}
                    className={`px-3 py-1.5 rounded-full text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                      rewardCategory === cat
                        ? 'bg-amber-500 text-slate-800 shadow'
                        : 'bg-stone-100 dark:bg-slate-800 text-stone-600 dark:text-slate-300 hover:bg-stone-200'
                    }`}
                  >
                    {cat === 'all' ? 'All Rewards' : `${cat} Vouchers`}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredRewards.map((reward) => {
                  const canAfford = superCoinsBalance >= reward.coinsCost;
                  return (
                    <div
                      key={reward.id}
                      className="border border-stone-200 dark:border-slate-800 rounded-2xl p-4 flex gap-3.5 bg-stone-50/50 dark:bg-slate-800/50 hover:border-amber-400/50 transition group"
                    >
                      <img
                        src={reward.imageUrl}
                        alt={reward.title}
                        className="w-24 h-24 rounded-xl object-cover flex-shrink-0 shadow-sm"
                      />
                      <div className="flex-1 flex flex-col justify-between">
                        <div>
                          <div className="flex items-center justify-between gap-1">
                            <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300">
                              {reward.badge}
                            </span>
                            <span className="text-[10px] text-stone-400 font-medium">
                              Expires {reward.expiresInDays}d
                            </span>
                          </div>
                          <h4 className="font-bold text-stone-900 dark:text-white text-xs mt-1.5 group-hover:text-amber-600 dark:group-hover:text-amber-400 transition">
                            {reward.title}
                          </h4>
                          <p className="text-[11px] text-stone-500 dark:text-slate-400 line-clamp-2 mt-0.5">
                            {reward.description}
                          </p>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-stone-200 dark:border-slate-700/60 mt-2">
                          <div className="flex items-center gap-1 font-bold text-stone-900 dark:text-white text-xs">
                            <Coins className="w-4 h-4 text-amber-500 fill-amber-400" />
                            <span>{reward.coinsCost} Coins</span>
                            <span className="text-[10px] text-stone-400 line-through">₹{reward.monetaryValue}</span>
                          </div>

                          <button
                            onClick={() => redeemSuperCoinReward(reward.id)}
                            disabled={!canAfford}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer ${
                              canAfford
                                ? 'bg-amber-500 hover:bg-amber-400 text-slate-800 shadow-sm active:scale-95'
                                : 'bg-stone-200 dark:bg-slate-700 text-stone-400 cursor-not-allowed'
                            }`}
                          >
                            {canAfford ? 'Redeem Now' : `Need ${reward.coinsCost - superCoinsBalance} More`}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 6: REFERRAL ECONOMY */}
          {activeTab === 'referrals' && (
            <div className="space-y-6">
              {/* Referral Invite Card */}
              <div className="p-6 rounded-3xl bg-gradient-to-br from-indigo-900 via-slate-900 to-purple-950 text-white shadow-xl border border-indigo-700/50">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider bg-indigo-500 text-white px-2.5 py-0.5 rounded-full">
                      Referral Network
                    </span>
                    <h3 className="text-xl sm:text-2xl font-black mt-1">
                      Invite Friends & Earn 1,000 Super Coins
                    </h3>
                    <p className="text-xs text-indigo-200 mt-0.5">
                      Earn 500 Coins + 100 Diamonds when your friend registers and places their first order.
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-black text-amber-300">
                      {INITIAL_REFERRAL_DATA.totalCoinsEarned} Coins
                    </div>
                    <div className="text-xs text-slate-300">Total Referral Earnings</div>
                  </div>
                </div>

                {/* Shareable Code Box */}
                <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 bg-white/60 rounded-2xl border border-indigo-500/30 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Your Referral Code</span>
                      <div className="text-sm font-black text-amber-300">{INITIAL_REFERRAL_DATA.referralCode}</div>
                    </div>
                    <button
                      onClick={() => handleCopy(INITIAL_REFERRAL_DATA.referralCode, 'code')}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl transition flex items-center gap-1 cursor-pointer"
                    >
                      {copiedCode ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      {copiedCode ? 'Copied' : 'Copy'}
                    </button>
                  </div>

                  <div className="p-3 bg-white/60 rounded-2xl border border-indigo-500/30 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Invite Link</span>
                      <div className="text-xs font-bold text-slate-300 truncate max-w-[180px]">
                        {INITIAL_REFERRAL_DATA.referralLink}
                      </div>
                    </div>
                    <button
                      onClick={() => handleCopy(INITIAL_REFERRAL_DATA.referralLink, 'link')}
                      className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-800 text-xs font-black rounded-xl transition flex items-center gap-1 cursor-pointer"
                    >
                      {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Share2 className="w-3.5 h-3.5" />}
                      {copiedLink ? 'Copied' : 'Share'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Invited Friends Progress List */}
              <div className="space-y-3">
                <h4 className="font-extrabold text-sm text-stone-900 dark:text-white">
                  Invited Friends ({INITIAL_REFERRAL_DATA.friendsList.length})
                </h4>
                <div className="divide-y divide-stone-200 dark:divide-slate-800 border border-stone-200 dark:border-slate-800 rounded-2xl overflow-hidden bg-stone-50/50 dark:bg-slate-800/40">
                  {INITIAL_REFERRAL_DATA.friendsList.map((friend) => (
                    <div key={friend.id} className="p-3.5 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-stone-900 dark:text-white">{friend.friendName}</div>
                        <div className="text-[11px] text-stone-400">{friend.friendPhone} • Joined {friend.joinedDate}</div>
                      </div>
                      <div className="text-right">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                            friend.status === 'Completed'
                              ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                              : 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300'
                          }`}
                        >
                          {friend.status}
                        </span>
                        {friend.superCoinsEarned > 0 && (
                          <div className="text-[11px] font-black text-emerald-600 dark:text-emerald-400 mt-0.5">
                            +{friend.superCoinsEarned} Coins
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: CREATOR DIAMOND DASHBOARD */}
          {activeTab === 'creator' && (
            <div className="space-y-6">
              {/* Creator Analytics Banner */}
              <div className="p-6 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-950 to-sky-950 text-white shadow-xl border border-sky-500/30">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-2xl bg-sky-500/20 text-sky-400 border border-sky-400/40 flex items-center justify-center font-black">
                      <Gem className="w-8 h-8 fill-sky-400" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-black uppercase bg-sky-400 text-slate-800 px-2 py-0.5 rounded-full">
                          Creator Studio
                        </span>
                        <span className="text-xs font-bold text-sky-300">@priyasharma_style</span>
                      </div>
                      <h3 className="text-xl font-black mt-0.5">₹42,500 Content GMV Generated</h3>
                      <p className="text-xs text-slate-300">10% affiliate diamond bounty on all shoppable reel conversions</p>
                    </div>
                  </div>

                  <div className="text-left sm:text-right">
                    <div className="text-2xl font-black text-sky-300">{diamondBalance} 💎</div>
                    <div className="text-xs text-slate-400">Available (≈ ₹{Math.round(diamondBalance * 0.5)})</div>
                    <button
                      onClick={handleRequestCreatorPayout}
                      disabled={payoutRequested}
                      className="mt-2 px-4 py-1.5 bg-sky-500 hover:bg-sky-400 text-slate-800 text-xs font-black rounded-xl shadow transition active:scale-95 cursor-pointer"
                    >
                      {payoutRequested ? 'Processing UPI Transfer...' : 'Withdraw to Bank (UPI)'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Top Performing Converted Products */}
              <div className="space-y-3">
                <h4 className="font-extrabold text-sm text-stone-900 dark:text-white">
                  Top Converting Outfits & Earnings
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                  {INITIAL_CREATOR_DIAMOND_STATS.topProducts.map((prod) => (
                    <div
                      key={prod.productId}
                      className="p-3.5 rounded-2xl border border-stone-200 dark:border-slate-800 bg-stone-50/50 dark:bg-slate-800/40 flex gap-3"
                    >
                      <img src={prod.productImage} alt={prod.productName} className="w-16 h-16 rounded-xl object-cover" />
                      <div className="flex-1 min-w-0">
                        <h5 className="font-bold text-xs text-stone-900 dark:text-white truncate">{prod.productName}</h5>
                        <div className="text-[11px] text-stone-500 mt-0.5">{prod.salesCount} Sales • ₹{prod.gmvDriven.toLocaleString()} GMV</div>
                        <div className="text-xs font-black text-sky-600 dark:text-sky-400 mt-1 flex items-center gap-1">
                          <Gem className="w-3.5 h-3.5 fill-sky-400" /> +{prod.diamondsEarned} Diamonds
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 8: SELLER REWARD CONFIG */}
          {activeTab === 'seller' && (
            <div className="space-y-6">
              <div className="p-6 rounded-3xl bg-stone-50 dark:bg-slate-800/60 border border-stone-200 dark:border-slate-700">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                      Seller Sponsored Economy
                    </span>
                    <h3 className="text-lg font-black text-stone-900 dark:text-white mt-1">
                      Store Loyalty & Cashback Controls
                    </h3>
                    <p className="text-xs text-stone-500 dark:text-slate-400">
                      Reward repeat customers with seller-funded Super Coins and exclusive bounties
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 mt-5">
                  <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-stone-200 dark:border-slate-800">
                    <span className="text-[10px] font-bold uppercase text-stone-400">Coin Cashback Rate</span>
                    <div className="text-xl font-black text-emerald-600 dark:text-emerald-400 mt-0.5">
                      {INITIAL_SELLER_REWARD_CONFIG.coinCashbackPercentage}% Cashback
                    </div>
                    <p className="text-[11px] text-stone-500 mt-1">Credited automatically on delivery confirmation.</p>
                  </div>

                  <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-stone-200 dark:border-slate-800">
                    <span className="text-[10px] font-bold uppercase text-stone-400">First Order Welcome Bonus</span>
                    <div className="text-xl font-black text-amber-600 dark:text-amber-400 mt-0.5">
                      +{INITIAL_SELLER_REWARD_CONFIG.firstOrderBonusCoins} Coins
                    </div>
                    <p className="text-[11px] text-stone-500 mt-1">Encourages first-time discovery checkout.</p>
                  </div>

                  <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-stone-200 dark:border-slate-800">
                    <span className="text-[10px] font-bold uppercase text-stone-400">Repeat Purchase Milestone</span>
                    <div className="text-xl font-black text-purple-600 dark:text-purple-400 mt-0.5">
                      +{INITIAL_SELLER_REWARD_CONFIG.repeatPurchaseBonusCoins} Coins
                    </div>
                    <p className="text-[11px] text-stone-500 mt-1">Unlocked on customer's 3rd store order.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 9: UNIFIED PASSBOOK LEDGER */}
          {activeTab === 'history' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-extrabold text-base text-stone-900 dark:text-white">
                    Unified Reward Passbook Ledger
                  </h3>
                  <p className="text-xs text-stone-500 dark:text-slate-400">
                    Complete transparent accounting of all Super Coin and Diamond transactions
                  </p>
                </div>

                <div className="flex items-center gap-1 bg-stone-100 dark:bg-slate-800 p-1 rounded-xl">
                  {['all', 'super_coins', 'diamonds'].map((f) => (
                    <button
                      key={f}
                      onClick={() => setHistoryFilter(f as any)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                        historyFilter === f
                          ? 'bg-amber-500 text-slate-800 shadow-xs'
                          : 'text-stone-500 hover:text-stone-900 dark:hover:text-white'
                      }`}
                    >
                      {f === 'all' ? 'All' : f === 'super_coins' ? 'Coins' : 'Diamonds'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="divide-y divide-stone-200 dark:divide-slate-800 border border-stone-200 dark:border-slate-800 rounded-2xl overflow-hidden bg-white dark:bg-slate-900">
                {filteredTransactions.map((tx) => (
                  <div key={tx.id} className="p-4 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold ${
                          tx.direction === 'credit'
                            ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600'
                            : 'bg-rose-100 dark:bg-rose-950 text-rose-600'
                        }`}
                      >
                        {tx.direction === 'credit' ? '+' : '-'}
                      </div>
                      <div>
                        <p className="font-bold text-stone-900 dark:text-white">{tx.activityTitle}</p>
                        <p className="text-[11px] text-stone-400">
                          {tx.date} • {tx.notes}
                        </p>
                      </div>
                    </div>

                    <div
                      className={`font-black text-sm flex items-center gap-1 ${
                        tx.direction === 'credit' ? 'text-emerald-600' : 'text-rose-600'
                      }`}
                    >
                      <span>
                        {tx.direction === 'credit' ? '+' : '-'}
                        {tx.amount}
                      </span>
                      {tx.currency === 'diamonds' ? (
                        <Gem className="w-4 h-4 text-sky-500 fill-sky-400" />
                      ) : (
                        <Coins className="w-4 h-4 text-amber-500 fill-amber-400" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 10: FRAUD SHIELD & RISK DEFENSE */}
          {activeTab === 'security' && (
            <div className="space-y-6">
              <div className="p-6 rounded-3xl bg-white text-white border border-emerald-500/30">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-slate-800 flex items-center justify-center font-black">
                    <ShieldCheck className="w-7 h-7" />
                  </div>
                  <div>
                    <h3 className="text-lg font-black">AI-Powered Anti-Abuse & Fraud Defense</h3>
                    <p className="text-xs text-slate-400">
                      Real-time velocity limits, device fingerprinting, and return clawbacks protect economy integrity
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 mt-5">
                  {INITIAL_FRAUD_RULES.map((rule) => (
                    <div key={rule.id} className="p-3.5 bg-slate-900 rounded-2xl border border-slate-800">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white">{rule.ruleName}</span>
                        <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                          Active
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">{rule.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Audit Records */}
              <div className="space-y-3">
                <h4 className="font-extrabold text-sm text-stone-900 dark:text-white">
                  Recent Security Audit Logs
                </h4>
                <div className="divide-y divide-stone-200 dark:divide-slate-800 border border-stone-200 dark:border-slate-800 rounded-2xl overflow-hidden bg-stone-50/50 dark:bg-slate-800/40">
                  {INITIAL_FRAUD_AUDIT_LOGS.map((log) => (
                    <div key={log.id} className="p-3.5 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-stone-900 dark:text-white">
                          {log.userName} — {log.activity}
                        </div>
                        <div className="text-[11px] text-stone-400">{log.timestamp} • {log.reason}</div>
                      </div>
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-black ${
                          log.actionTaken === 'Approved'
                            ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                            : 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300'
                        }`}
                      >
                        {log.actionTaken}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
