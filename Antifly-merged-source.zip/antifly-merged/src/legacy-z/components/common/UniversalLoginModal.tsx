import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Smartphone,
  Mail,
  ShieldCheck,
  CheckCircle2,
  Lock,
  ArrowRight,
  User,
  Store,
  Truck,
  Sparkles,
  RefreshCw,
  LogOut,
  X,
  PhoneCall,
  KeyRound,
  AlertCircle,
} from 'lucide-react';

export const UniversalLoginModal: React.FC = () => {
  const {
    isLoginModalOpen,
    setIsLoginModalOpen,
    currentUserSession,
    loginWithMobile,
    loginWithSocial,
    logoutUserSession,
    showToast,
    deviceMode,
    setDeviceMode,
    sellers,
    drivers,
    setActiveSellerId,
    setActiveDriverId,
  } = useApp();

  const [selectedRole, setSelectedRole] = useState<'customer' | 'seller' | 'driver' | 'admin'>('customer');
  const [authMethod, setAuthMethod] = useState<'mobile' | 'social'>('mobile');
  
  // Mobile form
  const [mobileNumber, setMobileNumber] = useState('9876543210');
  const [otpCode, setOtpCode] = useState('');
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Social form
  const [socialEmail, setSocialEmail] = useState('');
  const [socialProvider, setSocialProvider] = useState<'google' | 'apple' | 'github'>('google');
  const [socialDriverPhone, setSocialDriverPhone] = useState('');

  if (!isLoginModalOpen) return null;

  const handleSendOtp = () => {
    const cleanNumber = mobileNumber.replace(/\D/g, '');
    if (cleanNumber.length < 10) {
      showToast('Please enter a valid 10-digit mobile number');
      return;
    }
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(code);
    setIsOtpSent(true);
    setOtpCode(code); // Pre-fill for instantaneous ease of testing
    showToast(`📲 Direct OTP generated: ${code} (Sent to +91 ${cleanNumber})`);
  };

  const handleMobileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isOtpSent) {
      handleSendOtp();
      return;
    }
    if (!otpCode || otpCode.length < 4) {
      showToast('Please enter the 4-digit verification OTP');
      return;
    }

    setIsLoading(true);
    const res = await loginWithMobile(`+91 ${mobileNumber}`, otpCode, selectedRole);
    setIsLoading(false);

    if (res.success) {
      showToast(`✨ Welcome! Logged in as ${res.name || selectedRole.toUpperCase()}`);
      setIsLoginModalOpen(false);
      setIsOtpSent(false);

      // Auto-route to corresponding view if requested
      if (selectedRole === 'seller') {
        setDeviceMode('seller');
        if (sellers[0]) setActiveSellerId(sellers[0].id);
      } else if (selectedRole === 'driver') {
        setDeviceMode('driver');
        if (drivers[0]) setActiveDriverId(drivers[0].id);
      } else if (selectedRole === 'admin') {
        setDeviceMode('admin');
      } else {
        setDeviceMode('website');
      }
    } else {
      showToast(res.message);
    }
  };

  const handleSocialLogin = async (provider: 'google' | 'apple' | 'github') => {
    setSocialProvider(provider);
    setIsLoading(true);

    let defaultEmail = 'user.contact@gmail.com';
    let defaultName = 'Priya Sharma';

    if (selectedRole === 'seller') {
      defaultEmail = 'vendor.care@royalheritagesilks.com';
      defaultName = 'Royal Heritage Silks';
    } else if (selectedRole === 'driver') {
      defaultEmail = 'rahul.delivery@antifly.com';
      defaultName = 'Rahul Sharma (Rider)';
    }

    const emailToUse = socialEmail.trim() || defaultEmail;

    // For driver, mobile number is required
    const driverPhone = selectedRole === 'driver' ? (socialDriverPhone || '+91 98765 43210') : undefined;

    const res = await loginWithSocial(provider, emailToUse, selectedRole, driverPhone);
    setIsLoading(false);

    if (res.success) {
      showToast(`✨ Logged in successfully via ${provider.toUpperCase()} (${emailToUse})`);
      setIsLoginModalOpen(false);

      if (selectedRole === 'seller') {
        setDeviceMode('seller');
      } else if (selectedRole === 'driver') {
        setDeviceMode('driver');
      } else if (selectedRole === 'admin') {
        setDeviceMode('admin');
      } else {
        setDeviceMode('website');
      }
    }
  };

  // Quick One-Click Demo Logins
  const handleQuickDemoLogin = (role: 'customer' | 'seller' | 'driver' | 'admin') => {
    setSelectedRole(role);
    if (role === 'customer') {
      setMobileNumber('9849022334');
      loginWithMobile('+91 98490 22334', '4829', 'customer').then(() => {
        showToast('👤 Logged in as Priya Sharma (Customer)');
        setIsLoginModalOpen(false);
        setDeviceMode('website');
      });
    } else if (role === 'seller') {
      setMobileNumber('9845012890');
      loginWithMobile('+91 98450 12890', '4829', 'seller').then(() => {
        showToast('🏪 Logged in as Royal Heritage Silks (Seller Partner)');
        setIsLoginModalOpen(false);
        setDeviceMode('seller');
      });
    } else if (role === 'driver') {
      setMobileNumber('9876543210');
      loginWithMobile('+91 98765 43210', '4829', 'driver').then(() => {
        showToast('🛵 Logged in as Rahul Sharma (Delivery Partner)');
        setIsLoginModalOpen(false);
        setDeviceMode('driver');
      });
    } else if (role === 'admin') {
      setMobileNumber('9900011223');
      loginWithMobile('+91 99000 11223', '4829', 'admin').then(() => {
        showToast('🛡️ Logged in as Super Administrator');
        setIsLoginModalOpen(false);
        setDeviceMode('admin');
      });
    }
  };

  return (
    <div
      id="universal-login-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/70 backdrop-blur-md animate-in fade-in"
    >
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden text-slate-900 relative">
        {/* Header Ribbon */}
        <div className="bg-gradient-to-r from-orange-600 via-amber-600 to-amber-500 p-6 text-white relative">
          <button
            onClick={() => setIsLoginModalOpen(false)}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-slate-100/20 hover:bg-slate-100/40 text-white transition-all"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-xs font-bold uppercase tracking-wider backdrop-blur-xs">
              Universal Unified Auth
            </span>
            <span className="flex items-center gap-1 text-xs text-amber-100">
              <ShieldCheck className="w-3.5 h-3.5" />
              Direct Instant Login
            </span>
          </div>

          <h2 className="text-2xl font-black tracking-tight">
            Sign In to Antifly
          </h2>
          <p className="text-xs text-amber-100 mt-1">
            No signup required. Enter your mobile number or connect your social account to access Customer, Venture, or Buddy consoles.
          </p>
        </div>

        {/* Role Selector Tabs */}
        <div className="p-4 bg-slate-50 border-b border-slate-200">
          <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-2">
            Select Your Account Role:
          </label>
          <div className="grid grid-cols-4 gap-1.5">
            {[
              { id: 'customer', label: 'Customer', icon: User, color: 'hover:border-amber-400' },
              { id: 'seller', label: 'Venture', icon: Store, color: 'hover:border-orange-400' },
              { id: 'driver', label: 'Buddy', icon: Truck, color: 'hover:border-emerald-400' },
              { id: 'admin', label: 'Admin', icon: ShieldCheck, color: 'hover:border-indigo-400' },
            ].map((r) => {
              const Icon = r.icon;
              const isSelected = selectedRole === r.id;
              return (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => {
                    setSelectedRole(r.id as any);
                    setIsOtpSent(false);
                  }}
                  className={`flex flex-col items-center justify-center p-2.5 rounded-xl border text-xs font-bold transition-all ${
                    isSelected
                      ? 'bg-amber-500 text-slate-800 border-amber-500 shadow-sm'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="w-4 h-4 mb-1" />
                  <span>{r.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Method Toggle: Mobile vs Social */}
        <div className="px-6 pt-4 pb-2">
          <div className="flex items-center justify-center bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => setAuthMethod('mobile')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                authMethod === 'mobile'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Mobile OTP (Mandatory Option)</span>
            </button>
            <button
              type="button"
              onClick={() => setAuthMethod('social')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                authMethod === 'social'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Mail className="w-3.5 h-3.5" />
              <span>Social Media / Email</span>
            </button>
          </div>
        </div>

        {/* Auth Body */}
        <div className="p-6 pt-2">
          {authMethod === 'mobile' ? (
            <form onSubmit={handleMobileSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Mobile Number {selectedRole === 'driver' && <span className="text-rose-500">* (Mandatory for Driver)</span>}
                </label>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1 bg-slate-100 border border-slate-200 px-3 py-2.5 rounded-xl text-xs font-bold text-slate-700">
                    <span>🇮🇳</span>
                    <span>+91</span>
                  </div>
                  <input
                    type="tel"
                    maxLength={10}
                    placeholder="Enter 10-digit mobile number"
                    value={mobileNumber}
                    onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, ''))}
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white"
                  />
                </div>
              </div>

              {isOtpSent && (
                <div className="space-y-2 animate-in fade-in">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-700">Enter 4-Digit Verification OTP:</span>
                    <span className="text-amber-600 font-mono font-bold">Auto-sent: {generatedOtp}</span>
                  </div>
                  <input
                    type="text"
                    maxLength={4}
                    placeholder="e.g. 4829"
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-center text-xl font-mono font-bold tracking-widest text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                    <span>Didn't receive?</span>
                    <button
                      type="button"
                      onClick={handleSendOtp}
                      className="text-amber-600 hover:text-amber-700 font-semibold flex items-center gap-1"
                    >
                      <RefreshCw className="w-3 h-3" />
                      Resend OTP
                    </button>
                  </div>
                </div>
              )}

              <button
                id="login-submit-btn"
                type="submit"
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 font-bold py-3 rounded-xl text-sm transition-all shadow-md flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <span>Authenticating...</span>
                ) : isOtpSent ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Verify OTP & Login</span>
                  </>
                ) : (
                  <>
                    <span>Get Instant Login OTP</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          ) : (
            <div className="space-y-3">
              <p className="text-xs text-slate-500 text-center">
                Authenticate securely via OAuth 2.0 single sign-on:
              </p>

              {selectedRole === 'driver' && (
                <div className="bg-amber-50 border border-amber-200 p-2.5 rounded-xl text-[11px] text-amber-800 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>
                    Driver dispatch requires a linked mobile phone (+91 98765 43210 will be registered with your social account).
                  </span>
                </div>
              )}

              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => handleSocialLogin('google')}
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2.5 px-4 py-2.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-800 font-bold rounded-xl text-xs transition-all shadow-xs"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>Continue with Google (Gmail)</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSocialLogin('apple')}
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2.5 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs transition-all shadow-xs"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.62-.75 1.04-1.8 0.92-2.85-.9.04-1.99.6-2.63 1.35-.57.65-1.07 1.71-.93 2.73 1.01.08 2.02-.48 2.64-1.23z" />
                  </svg>
                  <span>Continue with Apple ID</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSocialLogin('github')}
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2.5 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-xs transition-all border border-slate-200"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
                  </svg>
                  <span>Continue with GitHub</span>
                </button>
              </div>
            </div>
          )}

          {/* Quick 1-Click Profile Switcher for Testing / Instant Access */}
          <div className="mt-5 pt-4 border-t border-slate-200">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-2">
              ⚡ Instant 1-Click Fast Login Profiles:
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('customer')}
                className="flex items-center gap-2 p-2 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-left transition-all text-xs"
              >
                <span className="w-7 h-7 rounded-lg bg-amber-500 text-slate-800 flex items-center justify-center font-bold text-xs shrink-0">
                  PS
                </span>
                <div className="truncate">
                  <p className="font-bold text-slate-900 truncate">Priya Sharma</p>
                  <p className="text-[10px] text-slate-500">Customer Shopper</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemoLogin('seller')}
                className="flex items-center gap-2 p-2 rounded-xl bg-orange-50 hover:bg-orange-100 border border-orange-200 text-left transition-all text-xs"
              >
                <span className="w-7 h-7 rounded-lg bg-orange-500 text-slate-800 flex items-center justify-center font-bold text-xs shrink-0">
                  RH
                </span>
                <div className="truncate">
                  <p className="font-bold text-slate-900 truncate">Royal Heritage</p>
                  <p className="text-[10px] text-slate-500">Verified Seller</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemoLogin('driver')}
                className="flex items-center gap-2 p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-left transition-all text-xs"
              >
                <span className="w-7 h-7 rounded-lg bg-emerald-500 text-slate-800 flex items-center justify-center font-bold text-xs shrink-0">
                  RS
                </span>
                <div className="truncate">
                  <p className="font-bold text-slate-900 truncate">Rahul Sharma</p>
                  <p className="text-[10px] text-slate-500">Delivery Partner</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemoLogin('admin')}
                className="flex items-center gap-2 p-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-left transition-all text-xs"
              >
                <span className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                  AD
                </span>
                <div className="truncate">
                  <p className="font-bold text-slate-900 truncate">Super Admin</p>
                  <p className="text-[10px] text-slate-500">Ecosystem Control</p>
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* Current Active Session Status */}
        {currentUserSession.isLoggedIn && (
          <div className="bg-slate-100 px-6 py-3 border-t border-slate-200 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-slate-600">
                Logged in as <strong className="text-slate-900">{currentUserSession.name}</strong> ({currentUserSession.role.toUpperCase()})
              </span>
            </div>
            <button
              onClick={() => {
                logoutUserSession();
                showToast('Logged out of active session');
              }}
              className="text-rose-600 hover:text-rose-700 font-bold flex items-center gap-1"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Log Out</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
