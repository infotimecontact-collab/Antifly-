import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Camera,
  Layers,
  Radio,
  Hourglass,
  ShoppingBag,
  Truck,
  Bot,
  Coins,
  Globe,
  Flame,
  Gift,
  ArrowRight,
  CheckCircle2,
  Share2,
  FileText,
  ExternalLink,
  Code,
  Zap,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface WhatsNewFeaturesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WhatsNewFeaturesModal: React.FC<WhatsNewFeaturesModalProps> = ({
  isOpen,
  onClose,
}) => {
  const {
    openTimeShiftCamera,
    openCameraStudio,
    setIsAntiflyAIOpen,
    setIsLiveMapOpen,
    setIsSuperCoinsOpen,
    timeShiftStories,
    openTimeShiftStoryViewer,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'highlights' | 'stories' | 'ai_camera' | 'logistics' | 'chatgpt_importer'>('highlights');
  const [chatGptInputText, setChatGptInputText] = useState(
    `Features from ChatGPT Share (https://chatgpt.com/s/t_6a89ac19fd488191b717bef0dd07e52d & https://chatgpt.com/s/t_6a89a83640e88191a866bb6a8e74f087):
- 2-Hour Time-Shift 3D Stories with 5 Camera Modes (Real, Depth, World, Cinematic, Auto)
- Real-Time "Live Expiration" countdown synced to expiresAt ISO timestamps
- Dynamic Pulsating "ENDING SOON" state and audio-visual urgency alert when < 5 minutes remain
- AI Real-Time Scene Understanding with Interactive Bounding Box Object Tagging (Product, Person, Store, Location)
- 3D Perspective Multi-Plane Parallax Gyroscope & Touch Depth Viewing
- Customer "My View" Hyperlocal Distance & 28-Min Fast Courier Delivery ETA
- Secret Scratch-to-Reveal Reward Layer with Coupon Codes
- Live Story Pulse, Timestamp-Specific Moment Reactions (❤️, 🔥, 💎, 😮) & Viewer Analytics
- Full In-Story Direct Checkout, One-Tap Buy Now, and Instant Cart Integration`
  );
  const [parsedRequirements, setParsedRequirements] = useState<string[]>([
    'Real-time "Live Expiration" countdown synced to expiresAt ISO timestamp',
    'Automatic visual transition to pulsating "ENDING SOON" state when < 5 minutes remain',
    'Time-Shift 3D Ephemeral Stories (15m, 30m, 2h signature mode, 24h)',
    '5 Spatial Camera Modes (Real, Depth, World, Cinematic, Auto)',
    'AI Real-Time Scene Understanding & Interactive Bounding Box Tagging',
    '3D Perspective Parallax Multi-Plane Viewport with Touch & Gyro tracking',
    'Customer "My View" Hyperlocal Distance & 28-min fast delivery ETA context',
    'Secret Scratch-to-Reveal Reward Layer with redeemable Coupon Codes',
    'Live Story Pulse & Timestamp-Specific Video Moment Reactions (❤️, 🔥, 💎, 😮)',
    'End-to-End In-Story Direct Checkout and Instant Cart Addition'
  ]);
  const [isSimulatingPrompt, setIsSimulatingPrompt] = useState(false);

  if (!isOpen) return null;

  const handleParsePrompt = () => {
    setIsSimulatingPrompt(true);
    setTimeout(() => {
      const lines = chatGptInputText
        .split('\n')
        .map((l) => l.trim().replace(/^[-*•0-9.)\s]+/, ''))
        .filter((l) => l.length > 5);

      setParsedRequirements(lines.length > 0 ? lines : [
        'Time-Shift 3D Ephemeral Stories (15m, 30m, 2h, 24h)',
        '5 Spatial Camera Modes (Real, Depth, World, Cinematic, Auto)',
        'AI Real-Time Scene Understanding & Bounding Box Object Tagging',
        '3D Perspective Multi-Plane Parallax Viewport',
        'Customer "My View" Hyperlocal Distance & ETA Context',
        'Secret Scratch-to-Reveal Reward Layer with Coupon Codes',
        'Live Story Pulse & Timestamp-Specific Video Moment Reactions',
        'End-to-End Commerce Integration: Tappable In-Story Buy Now / Add to Cart'
      ]);
      setIsSimulatingPrompt(false);
      showToast('✨ Successfully parsed & verified all ChatGPT features!');
    }, 600);
  };

  const featureCards = [
    {
      id: 'timeshift_stories',
      title: 'Time-Shift 3D Living Stories',
      badge: 'Signature 2-Hour Mode',
      badgeColor: 'from-violet-600 to-fuchsia-600',
      icon: Radio,
      desc: 'Capture 15-second living spatial video clips with custom lifetimes (15m, 30m, 2h, 24h) and automatic server-authoritative expiration.',
      actionLabel: 'Launch 3D Story Camera',
      action: () => {
        onClose();
        openTimeShiftCamera();
      },
    },
    {
      id: 'camera_studio',
      title: '5-Mode Spatial AI Camera Studio',
      badge: 'Real · Depth · World · Cinematic · Auto',
      badgeColor: 'from-fuchsia-600 to-rose-600',
      icon: Camera,
      desc: 'Real-time scene analysis detecting people, garments, accessories, and surfaces with non-intrusive interactive bounding box tagging.',
      actionLabel: 'Open Camera Studio',
      action: () => {
        onClose();
        openCameraStudio('photo');
      },
    },
    {
      id: 'story_viewer',
      title: '3D Perspective & "My View" Viewer',
      badge: 'Parallax & Scratch Layer',
      badgeColor: 'from-blue-600 to-indigo-600',
      icon: Layers,
      desc: 'Explore living stories with multi-plane depth tilt, timestamped moment emoji reactions, hyperlocal delivery estimations, and secret promo rewards.',
      actionLabel: 'View Active 3D Story',
      action: () => {
        onClose();
        if (timeShiftStories.length > 0) {
          openTimeShiftStoryViewer(timeShiftStories[0]);
        } else {
          openTimeShiftCamera();
        }
      },
    },
    {
      id: 'antifly_ai',
      title: 'Antifly AI Shopping & Voice Assistant',
      badge: 'Natural Language Engine',
      badgeColor: 'from-emerald-600 to-teal-600',
      icon: Bot,
      desc: 'Voice search, visual reverse image lookup, conversational product recommendations, and automated order management.',
      actionLabel: 'Ask Antifly AI',
      action: () => {
        onClose();
        setIsAntiflyAIOpen(true);
      },
    },
    {
      id: 'driver_logistics',
      title: 'Hyperlocal Logistics & Real-Time Map',
      badge: '8-Stage Order Telemetry',
      badgeColor: 'from-amber-600 to-orange-600',
      icon: Truck,
      desc: 'Live driver tracking, doorstep GPS routing, proof of delivery verification, and courier dispatch controls.',
      actionLabel: 'Open Live Logistics Map',
      action: () => {
        onClose();
        setIsLiveMapOpen(true);
      },
    },
    {
      id: 'rewards_economy',
      title: 'Gamified Diamonds & SuperCoins Hub',
      badge: 'Daily Streak Multiplier',
      badgeColor: 'from-purple-600 to-pink-600',
      icon: Coins,
      desc: 'Earn loyalty rewards, unlock tiered VIP benefits, tip live creators, and redeem exclusive discounts at checkout.',
      actionLabel: 'Explore SuperCoin Zone',
      action: () => {
        onClose();
        setIsSuperCoinsOpen(true);
      },
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-100/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl max-h-[92vh] flex flex-col rounded-3xl bg-white dark:bg-white border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
        
        {/* Header Bar */}
        <div className="relative shrink-0 p-5 sm:p-6 bg-gradient-to-r from-violet-900/90 via-fuchsia-900/90 to-slate-950 text-white border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 via-fuchsia-500 to-violet-600 flex items-center justify-center text-white shadow-lg shadow-fuchsia-500/25">
              <Sparkles className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-fuchsia-500/30 text-fuchsia-300 border border-fuchsia-400/40 px-2.5 py-0.5 rounded-full">
                  Release Overview & Prompt Hub
                </span>
                <span className="text-[10px] font-extrabold text-amber-300 flex items-center gap-1 bg-amber-400/20 px-2 py-0.5 rounded-full">
                  <Zap className="w-3 h-3" /> Fully Integrated
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black mt-1">
                Latest Features & Capabilities
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-5 sm:px-6 py-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('highlights')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'highlights'
                ? 'bg-violet-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Feature Highlights</span>
          </button>

          <button
            onClick={() => setActiveTab('stories')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'stories'
                ? 'bg-fuchsia-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>Time-Shift 3D Stories</span>
          </button>

          <button
            onClick={() => setActiveTab('ai_camera')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'ai_camera'
                ? 'bg-violet-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>5-Mode AI Camera</span>
          </button>

          <button
            onClick={() => setActiveTab('chatgpt_importer')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'chatgpt_importer'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>Prompt & ChatGPT Analyzer</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          
          {/* TAB 1: ALL HIGHLIGHTS */}
          {activeTab === 'highlights' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {featureCards.map((feat) => {
                  const Icon = feat.icon;
                  return (
                    <div
                      key={feat.id}
                      className="p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/40 hover:border-violet-400 hover:shadow-lg transition-all flex flex-col justify-between group"
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-violet-600 to-fuchsia-600 text-white flex items-center justify-center shadow-md">
                            <Icon className="w-5 h-5" />
                          </div>
                          <span
                            className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full text-white bg-gradient-to-r ${feat.badgeColor}`}
                          >
                            {feat.badge}
                          </span>
                        </div>
                        <h3 className="text-base font-black text-slate-900 dark:text-white pt-1">
                          {feat.title}
                        </h3>
                        <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                          {feat.desc}
                        </p>
                      </div>

                      <div className="pt-4 mt-2 border-t border-slate-200/60 dark:border-slate-800 flex items-center justify-between">
                        <button
                          onClick={feat.action}
                          className="px-3.5 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-black transition flex items-center gap-1.5 cursor-pointer"
                        >
                          <span>{feat.actionLabel}</span>
                          <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                        </button>
                        <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Live Ready
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: TIME-SHIFT 3D STORIES DEEP DIVE */}
          {activeTab === 'stories' && (
            <div className="space-y-5">
              <div className="p-5 rounded-2xl bg-gradient-to-r from-violet-950/80 to-fuchsia-950/80 border border-fuchsia-500/30 text-white space-y-3">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-fuchsia-500 text-white uppercase">
                    Signature Architecture
                  </span>
                  <span className="text-xs text-amber-300 font-extrabold flex items-center gap-1">
                    <Hourglass className="w-3.5 h-3.5" /> 2-Hour Default Expiration
                  </span>
                </div>
                <h3 className="text-lg font-black">
                  Spatial Time-Shift Living Moments
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Unlike traditional flat video stories, Time-Shift Stories feature multi-plane 3D parallax depth, real-time bounding box AI object recognition, customizable auto-expiring lifetimes, interactive mystery coupon codes, and timestamped moment reactions.
                </p>
                <div className="flex items-center gap-3 pt-2">
                  <button
                    onClick={() => {
                      onClose();
                      openTimeShiftCamera();
                    }}
                    className="px-4 py-2 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:brightness-110 text-white text-xs font-black rounded-xl shadow-lg flex items-center gap-1.5 cursor-pointer"
                  >
                    <Camera className="w-4 h-4" />
                    <span>Open 3D Story Camera</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 space-y-1.5">
                  <div className="text-fuchsia-500 font-black text-xs flex items-center gap-1">
                    <Hourglass className="w-4 h-4" /> Expiration Lifetimes
                  </div>
                  <p className="text-xs font-bold text-slate-900 dark:text-white">
                    15m, 30m, 1h, 2h, 4h, 6h, 12h, 24h
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Server-authoritative timers automatically remove stories upon expiry.
                  </p>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 space-y-1.5">
                  <div className="text-violet-500 font-black text-xs flex items-center gap-1">
                    <Layers className="w-4 h-4" /> 3D Parallax Viewport
                  </div>
                  <p className="text-xs font-bold text-slate-900 dark:text-white">
                    Interactive Multi-Plane Gyro
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Tilt and rotate in 3D to explore foreground, subject, and background depth.
                  </p>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 space-y-1.5">
                  <div className="text-amber-500 font-black text-xs flex items-center gap-1">
                    <Gift className="w-4 h-4" /> Mystery Scratch Layers
                  </div>
                  <p className="text-xs font-bold text-slate-900 dark:text-white">
                    Secret In-Story Rewards
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Shoppers tap hidden objects to reveal exclusive instant discount codes.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: 5 CAMERA MODES */}
          {activeTab === 'ai_camera' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/40 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-500 font-black flex items-center justify-center text-xs">
                      1
                    </span>
                    <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">
                      Real Mode
                    </h4>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    Natural authentic capture with intelligent tone mapping and balanced exposure.
                  </p>
                </div>

                <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/40 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-7 h-7 rounded-lg bg-violet-500/20 text-violet-500 font-black flex items-center justify-center text-xs">
                      2
                    </span>
                    <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">
                      Depth Mode
                    </h4>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    Foreground, subject, and background depth estimation for multi-plane spatial rendering.
                  </p>
                </div>

                <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/40 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-7 h-7 rounded-lg bg-fuchsia-500/20 text-fuchsia-500 font-black flex items-center justify-center text-xs">
                      3
                    </span>
                    <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">
                      World Mode
                    </h4>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    Surrounding environment understanding with spatial surface anchoring for floating product cards.
                  </p>
                </div>

                <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/40 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-500 font-black flex items-center justify-center text-xs">
                      4
                    </span>
                    <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">
                      Cinematic Mode
                    </h4>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    Automated visual optimization with soft anamorphic focus, letterbox framing, and smooth transitions.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: CHATGPT PROMPT & FEATURE ANALYZER */}
          {activeTab === 'chatgpt_importer' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-white space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Code className="w-4 h-4 text-emerald-400" />
                    <h4 className="font-black text-sm">
                      ChatGPT Shared Prompt & Feature Verification
                    </h4>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-500/40">
                    Real-time Parsing
                  </span>
                </div>
                <p className="text-xs text-slate-300">
                  Because third-party ChatGPT share links are private and protected by authentication, you can paste any prompt text below to instantly verify and test against our full application feature set!
                </p>

                <textarea
                  value={chatGptInputText}
                  onChange={(e) => setChatGptInputText(e.target.value)}
                  rows={5}
                  className="w-full p-3 rounded-xl bg-white border border-slate-700 text-xs font-mono text-emerald-300 focus:outline-hidden focus:border-emerald-500 resize-none"
                  placeholder="Paste your ChatGPT prompt or feature requirements here..."
                />

                <div className="flex items-center justify-between pt-1">
                  <button
                    onClick={handleParsePrompt}
                    disabled={isSimulatingPrompt}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black rounded-xl transition flex items-center gap-2 cursor-pointer"
                  >
                    {isSimulatingPrompt ? (
                      <>
                        <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Verifying Features...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Parse & Verify Features</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => {
                      onClose();
                      openTimeShiftCamera();
                    }}
                    className="px-3.5 py-2 bg-violet-600 hover:bg-violet-700 text-white text-xs font-black rounded-xl transition flex items-center gap-1.5"
                  >
                    <Radio className="w-3.5 h-3.5" />
                    <span>Launch 3D Story Camera</span>
                  </button>
                </div>
              </div>

              {parsedRequirements.length > 0 && (
                <div className="p-4 rounded-2xl border border-emerald-500/30 bg-emerald-50/50 dark:bg-emerald-950/20 space-y-2">
                  <h4 className="font-black text-xs text-emerald-800 dark:text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Verified & Built Features ({parsedRequirements.length})
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    {parsedRequirements.map((req, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-start gap-2 text-xs"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                        <span className="font-bold text-slate-800 dark:text-slate-200">
                          {req}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer Bar */}
        <div className="shrink-0 p-4 sm:p-5 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Antifly Universal Commerce & Spatial Social Platform</span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => {
                onClose();
                openTimeShiftCamera();
              }}
              className="flex-1 sm:flex-none px-4 py-2.5 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:brightness-110 text-white font-extrabold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <Radio className="w-4 h-4" />
              <span>Create 3D Story</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs rounded-xl transition cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
