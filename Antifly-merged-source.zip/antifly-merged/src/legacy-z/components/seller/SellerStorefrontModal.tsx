import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Store,
  CheckCircle,
  Star,
  MapPin,
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  Plus,
  ThumbsUp,
  ThumbsDown,
  ShoppingBag,
  Send,
  Sparkles,
  Camera,
  Tag,
  UserCheck,
  UserPlus,
  Eye,
  Award,
  Clock,
  ExternalLink,
  UserX,
  ShieldAlert,
} from 'lucide-react';
import { SellerPost, SellerPortfolioItem } from '../../types';

export const SellerStorefrontModal: React.FC = () => {
  const {
    activeSellerStorefrontId,
    setActiveSellerStorefrontId,
    sellers,
    products,
    followedSellerIds,
    toggleFollowSeller,
    isFollowingSeller,
    openDirectChatWithPeer,
    toggleLikeProduct,
    isProductLiked,
    getProductLikeCount,
    toggleSaveProductSocial,
    isProductSavedSocial,
    setActiveCommentsProductId,
    setIsProductCommentsOpen,
    setActiveShareProduct,
    setIsProductShareOpen,
    setActivePdpId,
    addToCart,
    likeSellerPost,
    dislikeSellerPost,
    toggleSaveSellerPost,
    addCommentToSellerPost,
    likeSellerPortfolioItem,
    dislikeSellerPortfolioItem,
    toggleSaveSellerPortfolioItem,
    createSellerPost,
    createSellerPortfolioItem,
    setIsSavePortfolioOpen,
    openSellerShareModal,
    openBlockConfirmationModal,
    isSellerBlocked,
    toggleBlockSeller,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'products' | 'posts' | 'portfolio' | 'create_post'>('products');
  const [postCommentInputs, setPostCommentInputs] = useState<Record<string, string>>({});

  // New post form state
  const [newPostCaption, setNewPostCaption] = useState('');
  const [newPostImageUrl, setNewPostImageUrl] = useState('');
  const [newPostTaggedProduct, setNewPostTaggedProduct] = useState('');

  if (!activeSellerStorefrontId) return null;

  const seller = sellers.find((s) => s.id === activeSellerStorefrontId) || sellers[0];
  const isFollowing = isFollowingSeller(seller.id);

  // Match products created by this seller
  const sellerProducts = products.filter(
    (p) =>
      p.brand.toLowerCase() === seller.storeName.toLowerCase() ||
      p.tags.includes(seller.storeName) ||
      p.specifications?.some((spec) => spec.value.toLowerCase().includes(seller.storeName.toLowerCase())) ||
      (seller.id === 'seller-001' && (p.category === 'ethnic-wear' || p.id === 'wi-prod-001' || p.id === 'wi-prod-011')) ||
      (seller.id === 'seller-002' && (p.category === 'electronics' || p.id === 'wi-prod-009' || p.id === 'wi-prod-010'))
  );

  const posts: SellerPost[] = seller.posts || [];
  const portfolio: SellerPortfolioItem[] = seller.portfolio || [];

  const handlePostComment = (postId: string, e: React.FormEvent) => {
    e.preventDefault();
    const text = postCommentInputs[postId];
    if (!text || !text.trim()) return;
    addCommentToSellerPost(seller.id, postId, text);
    setPostCommentInputs((prev) => ({ ...prev, [postId]: '' }));
  };

  const handleCreateNewPost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostCaption.trim()) return;

    const taggedProd = products.find((p) => p.id === newPostTaggedProduct);

    createSellerPost(seller.id, {
      imageUrl:
        newPostImageUrl.trim() ||
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=700&auto=format&fit=crop&q=80',
      caption: newPostCaption.trim(),
      taggedProductId: taggedProd ? taggedProd.id : undefined,
      taggedProductName: taggedProd ? taggedProd.name : undefined,
      taggedProductPrice: taggedProd ? taggedProd.price : undefined,
    });

    setNewPostCaption('');
    setNewPostImageUrl('');
    setNewPostTaggedProduct('');
    setActiveTab('posts');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-white/60 backdrop-blur-sm p-2 sm:p-4 animate-in fade-in duration-200">
      <div
        id="seller-storefront-modal-container"
        className="bg-white rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden text-slate-800"
      >
        {/* Top Header / Close */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-white sticky top-0 z-20">
          <div className="flex items-center gap-2">
            <Store className="w-5 h-5 text-orange-600" />
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Seller Profile & Social Hub
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Instagram Style Share Profile Button */}
            <button
              id="share-seller-profile-btn"
              onClick={() => openSellerShareModal(seller)}
              className="text-xs font-bold text-white bg-gradient-to-r from-pink-600 via-rose-600 to-amber-600 hover:opacity-90 px-3 py-1.5 rounded-lg flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Share Profile</span>
            </button>

            {/* Instagram Style Block Button */}
            <button
              id="block-seller-store-btn"
              onClick={() => {
                if (isSellerBlocked(seller.id)) {
                  toggleBlockSeller(seller.id);
                } else {
                  openBlockConfirmationModal(
                    'seller',
                    seller.id,
                    seller.storeName,
                    seller.storeAvatar,
                    `@${seller.storeName.toLowerCase().replace(/[^a-z0-9]/g, '_')}`
                  );
                }
              }}
              className={`text-xs font-semibold px-2.5 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer ${
                isSellerBlocked(seller.id)
                  ? 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100'
                  : 'bg-slate-50 hover:bg-rose-50 text-slate-600 hover:text-rose-600 border-slate-200 hover:border-rose-200'
              }`}
            >
              <UserX className="w-3.5 h-3.5" />
              <span>{isSellerBlocked(seller.id) ? 'Blocked' : 'Block'}</span>
            </button>

            <button
              id="open-save-portfolio-from-seller-btn"
              onClick={() => {
                setActiveSellerStorefrontId(null);
                setIsSavePortfolioOpen(true);
              }}
              className="text-xs font-semibold text-slate-600 hover:text-orange-600 bg-slate-100 hover:bg-orange-50 px-3 py-1.5 rounded-lg border border-slate-200 flex items-center gap-1.5 transition-all"
            >
              <Bookmark className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
              <span>Saved Portfolio</span>
            </button>

            <button
              id="close-seller-storefront-modal-btn"
              onClick={() => setActiveSellerStorefrontId(null)}
              className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Blocked Profile Notice Banner */}
        {isSellerBlocked(seller.id) && (
          <div className="bg-rose-50 border-b border-rose-200 p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-rose-900">You have blocked @{seller.storeName}</p>
                <p className="text-[11px] text-rose-700">
                  Their catalog, drops, and stories are hidden from your shopping stream.
                </p>
              </div>
            </div>
            <button
              onClick={() => toggleBlockSeller(seller.id)}
              className="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition shadow-xs cursor-pointer"
            >
              Unblock Venture
            </button>
          </div>
        )}

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto">
          {/* Hero Banner & Profile Info */}
          <div className="relative bg-slate-100 border-b border-slate-200">
            {/* Banner Image */}
            <div className="h-36 sm:h-48 w-full overflow-hidden bg-gradient-to-r from-orange-500 via-amber-500 to-rose-500 relative">
              {seller.bannerUrl ? (
                <img src={seller.bannerUrl} alt="Store Banner" className="w-full h-full object-cover opacity-90" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-white/40 font-bold text-xl">
                  {seller.storeName}
                </div>
              )}
            </div>

            {/* Profile Avatar & Actions Overlay */}
            <div className="px-4 sm:px-6 pb-4">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between -mt-12 sm:-mt-14 gap-3">
                <div className="flex items-end gap-3.5">
                  <div className="relative">
                    <img
                      src={seller.storeAvatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200'}
                      alt={seller.storeName}
                      className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-4 border-white shadow-md bg-white"
                    />
                    {seller.kycStatus === 'Verified' && (
                      <span className="absolute -bottom-1 -right-1 bg-emerald-500 text-white p-1 rounded-full border-2 border-white shadow">
                        <CheckCircle className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </div>

                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <h1 className="text-base sm:text-lg font-bold text-slate-900 leading-tight">
                        {seller.storeName}
                      </h1>
                      <span className="text-[11px] bg-amber-50 text-amber-800 border border-amber-200 px-2 py-0.5 rounded-full font-semibold">
                        ★ {seller.rating}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-slate-500 flex-wrap">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        {seller.warehouseAddress.city}, {seller.warehouseAddress.country}
                      </span>
                      <span>•</span>
                      <span>{seller.totalOrders.toLocaleString()} Orders</span>
                    </div>
                  </div>
                </div>

                {/* Follow & Chat Buttons */}
                <div className="flex items-center gap-2 self-start sm:self-auto">
                  <button
                    id="toggle-follow-seller-btn"
                    onClick={() => toggleFollowSeller(seller.id)}
                    className={`px-4 py-2 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all shadow-sm ${
                      isFollowing
                        ? 'bg-slate-100 text-slate-800 border border-slate-300 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-200'
                        : 'bg-orange-600 text-white hover:bg-orange-700'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <UserCheck className="w-4 h-4 text-emerald-600" />
                        <span>Following</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4" />
                        <span>Follow Seller</span>
                      </>
                    )}
                  </button>

                  <button
                    id="chat-with-seller-btn"
                    onClick={() => {
                      setActiveSellerStorefrontId(null);
                      openDirectChatWithPeer(seller.id, seller.storeName, 'seller');
                    }}
                    className="px-3.5 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 flex items-center gap-1.5 transition-all shadow-sm"
                  >
                    <MessageCircle className="w-4 h-4 text-slate-500" />
                    <span>Chat</span>
                  </button>
                </div>
              </div>

              {/* Bio & Description */}
              <div className="mt-3 text-xs text-slate-600 leading-relaxed max-w-2xl">
                {seller.bio ||
                  'Authentic verified creator listed on Antifly Marketplace. Handcrafted with traditional expertise, strict quality controls, and express door-to-door delivery.'}
              </div>
            </div>
          </div>

          {/* Social Navigation Tabs */}
          <div className="px-4 sm:px-6 border-b border-slate-200 flex items-center gap-1 bg-white sticky top-0 z-10">
            <button
              id="seller-tab-products"
              onClick={() => setActiveTab('products')}
              className={`py-3 px-3 sm:px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 ${
                activeTab === 'products'
                  ? 'border-orange-600 text-orange-600'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Products</span>
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-100 text-slate-600 font-semibold">
                {sellerProducts.length}
              </span>
            </button>

            <button
              id="seller-tab-posts"
              onClick={() => setActiveTab('posts')}
              className={`py-3 px-3 sm:px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 ${
                activeTab === 'posts'
                  ? 'border-orange-600 text-orange-600'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>Studio Feed & Photos</span>
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-100 text-slate-600 font-semibold">
                {posts.length}
              </span>
            </button>

            <button
              id="seller-tab-portfolio"
              onClick={() => setActiveTab('portfolio')}
              className={`py-3 px-3 sm:px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 ${
                activeTab === 'portfolio'
                  ? 'border-orange-600 text-orange-600'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              <Award className="w-4 h-4" />
              <span>Artisan Portfolio</span>
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-100 text-slate-600 font-semibold">
                {portfolio.length}
              </span>
            </button>

            <button
              id="seller-tab-create"
              onClick={() => setActiveTab('create_post')}
              className={`py-3 px-3 sm:px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 ml-auto ${
                activeTab === 'create_post'
                  ? 'border-orange-600 text-orange-600'
                  : 'border-transparent text-slate-400 hover:text-orange-600'
              }`}
            >
              <Camera className="w-4 h-4" />
              <span>Post New Image</span>
            </button>
          </div>

          {/* TAB CONTENT */}
          <div className="p-4 sm:p-6">
            {/* TAB 1: PRODUCTS BY THIS SELLER */}
            {activeTab === 'products' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Products by {seller.storeName}
                  </h3>
                  <span className="text-xs text-slate-400">Like, Comment, Share or Save directly below</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {sellerProducts.map((product) => {
                    const isLiked = isProductLiked(product.id);
                    const likeCount = getProductLikeCount(product.id);
                    const isSaved = isProductSavedSocial(product.id);

                    return (
                      <div
                        key={product.id}
                        className="group bg-white rounded-2xl border border-slate-200 overflow-hidden hover:shadow-md transition-all flex flex-col justify-between"
                      >
                        <div>
                          {/* Image */}
                          <div
                            className="relative aspect-square bg-slate-100 overflow-hidden cursor-pointer"
                            onClick={() => {
                              setActiveSellerStorefrontId(null);
                              setActivePdpId(product.id);
                            }}
                          >
                            <img
                              src={product.images[0]}
                              alt={product.name}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                            {product.discountPercentage > 0 && (
                              <span className="absolute top-2.5 left-2.5 bg-rose-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow">
                                {product.discountPercentage}% OFF
                              </span>
                            )}
                          </div>

                          {/* Instagram Action Icons directly below the product image */}
                          <div className="p-2.5 bg-slate-50/70 border-b border-slate-100 flex items-center justify-between">
                            <div className="flex items-center gap-1">
                              {/* Like button with counter */}
                              <button
                                id={`seller-product-like-btn-${product.id}`}
                                onClick={() => toggleLikeProduct(product.id)}
                                className={`flex items-center gap-1 p-1.5 px-2 rounded-lg text-xs font-medium transition-all ${
                                  isLiked
                                    ? 'text-rose-600 bg-rose-50'
                                    : 'text-slate-600 hover:text-rose-600 hover:bg-white'
                                }`}
                                title={isLiked ? 'Unlike' : 'Like'}
                              >
                                <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
                                <span>{likeCount}</span>
                              </button>

                              {/* Comment button */}
                              <button
                                id={`seller-product-comment-btn-${product.id}`}
                                onClick={() => {
                                  setActiveCommentsProductId(product.id);
                                  setIsProductCommentsOpen(true);
                                }}
                                className="p-1.5 text-slate-600 hover:text-orange-600 rounded-lg hover:bg-white transition-all flex items-center gap-1 text-xs"
                                title="Comments"
                              >
                                <MessageCircle className="w-4 h-4" />
                              </button>

                              {/* Share button */}
                              <button
                                id={`seller-product-share-btn-${product.id}`}
                                onClick={() => {
                                  setActiveShareProduct(product);
                                  setIsProductShareOpen(true);
                                }}
                                className="p-1.5 text-slate-600 hover:text-orange-600 rounded-lg hover:bg-white transition-all"
                                title="Share"
                              >
                                <Share2 className="w-4 h-4" />
                              </button>
                            </div>

                            {/* Save / Bookmark Button */}
                            <button
                              id={`seller-product-save-btn-${product.id}`}
                              onClick={() => toggleSaveProductSocial(product.id)}
                              className={`p-1.5 rounded-lg transition-all ${
                                isSaved
                                  ? 'text-amber-600 bg-amber-50'
                                  : 'text-slate-400 hover:text-amber-600 hover:bg-white'
                              }`}
                              title={isSaved ? 'Saved in Portfolio' : 'Save to Portfolio'}
                            >
                              <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-amber-500 text-amber-500' : ''}`} />
                            </button>
                          </div>

                          {/* Product Info */}
                          <div className="p-3">
                            <h4
                              onClick={() => {
                                setActiveSellerStorefrontId(null);
                                setActivePdpId(product.id);
                              }}
                              className="text-xs font-bold text-slate-900 line-clamp-1 hover:text-orange-600 cursor-pointer"
                            >
                              {product.name}
                            </h4>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-sm font-extrabold text-orange-600">
                                ₹{product.price.toLocaleString('en-IN')}
                              </span>
                              {product.mrp > product.price && (
                                <span className="text-xs text-slate-400 line-through">
                                  ₹{product.mrp.toLocaleString('en-IN')}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Quick Add to Cart */}
                        <div className="p-3 pt-0">
                          <button
                            onClick={() => {
                              addToCart({
                                productId: product.id,
                                variantId: 'default',
                                productName: product.name,
                                brand: product.brand,
                                color: product.colors[0]?.name || 'Standard',
                                size: product.sizes[0] || 'Standard',
                                price: product.price,
                                mrp: product.mrp,
                                image: product.images[0],
                                quantity: 1,
                                stock: product.totalStock,
                              });
                            }}
                            className="w-full py-1.5 bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 shadow-sm transition-all"
                          >
                            <ShoppingBag className="w-3.5 h-3.5" />
                            <span>Add to Cart</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB 2: SELLER POSTS & LIVE STUDIO FEED */}
            {activeTab === 'posts' && (
              <div className="space-y-6 max-w-2xl mx-auto">
                {posts.length === 0 ? (
                  <div className="text-center py-12 bg-slate-50 rounded-2xl border border-slate-200">
                    <Camera className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                    <p className="text-sm font-bold text-slate-700">No feed posts uploaded yet</p>
                    <p className="text-xs text-slate-400 mt-1">
                      Click "Post New Image" tab to upload workshop photos directly to this profile!
                    </p>
                  </div>
                ) : (
                  posts.map((post) => (
                    <div
                      key={post.id}
                      className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm"
                    >
                      {/* Post Header */}
                      <div className="p-3.5 border-b border-slate-100 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <img
                            src={post.sellerAvatar}
                            alt={post.sellerName}
                            className="w-9 h-9 rounded-full object-cover border border-slate-200"
                          />
                          <div>
                            <p className="text-xs font-bold text-slate-900 leading-tight">{post.sellerName}</p>
                            <p className="text-[11px] text-slate-400">{post.uploadedAt}</p>
                          </div>
                        </div>

                        <span className="text-[11px] bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full font-semibold">
                          {post.category || 'Studio Feed'}
                        </span>
                      </div>

                      {/* Post Photo */}
                      <div className="relative aspect-video sm:aspect-[4/3] bg-slate-100 overflow-hidden">
                        <img src={post.imageUrl} alt={post.caption} className="w-full h-full object-cover" />
                        {post.taggedProductName && (
                          <div
                            onClick={() => {
                              if (post.taggedProductId) {
                                setActiveSellerStorefrontId(null);
                                setActivePdpId(post.taggedProductId);
                              }
                            }}
                            className="absolute bottom-3 left-3 bg-white/85 backdrop-blur-md text-white text-xs font-semibold px-3 py-1.5 rounded-xl flex items-center gap-2 shadow-lg cursor-pointer hover:bg-slate-900 transition-all"
                          >
                            <Tag className="w-3.5 h-3.5 text-amber-400" />
                            <span>{post.taggedProductName}</span>
                            <span className="text-orange-400 font-bold">₹{post.taggedProductPrice}</span>
                          </div>
                        )}
                      </div>

                      {/* Instagram Action Icons below Image */}
                      <div className="p-3 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                        <div className="flex items-center gap-2">
                          {/* Like Button */}
                          <button
                            id={`like-post-btn-${post.id}`}
                            onClick={() => likeSellerPost(seller.id, post.id)}
                            className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border transition-all ${
                              post.isLikedByMe
                                ? 'bg-rose-50 border-rose-200 text-rose-600'
                                : 'bg-white border-slate-200 text-slate-600 hover:text-rose-600'
                            }`}
                          >
                            <ThumbsUp className="w-3.5 h-3.5" />
                            <span>Like ({post.likesCount})</span>
                          </button>

                          {/* Dislike Button */}
                          <button
                            id={`dislike-post-btn-${post.id}`}
                            onClick={() => dislikeSellerPost(seller.id, post.id)}
                            className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border transition-all ${
                              post.isDislikedByMe
                                ? 'bg-slate-200 border-slate-300 text-slate-800'
                                : 'bg-white border-slate-200 text-slate-500 hover:text-slate-800'
                            }`}
                          >
                            <ThumbsDown className="w-3.5 h-3.5" />
                            <span>Dislike ({post.dislikesCount})</span>
                          </button>
                        </div>

                        {/* Save to Portfolio */}
                        <button
                          id={`save-post-btn-${post.id}`}
                          onClick={() => toggleSaveSellerPost(seller.id, post.id)}
                          className={`p-2 rounded-full border transition-all ${
                            post.isSavedByMe
                              ? 'bg-amber-50 border-amber-200 text-amber-600'
                              : 'bg-white border-slate-200 text-slate-400 hover:text-amber-600'
                          }`}
                          title={post.isSavedByMe ? 'Saved in Portfolio' : 'Save post to Portfolio'}
                        >
                          <Bookmark className={`w-4 h-4 ${post.isSavedByMe ? 'fill-amber-500' : ''}`} />
                        </button>
                      </div>

                      {/* Caption & Comments */}
                      <div className="p-4 space-y-3">
                        <p className="text-xs text-slate-800 leading-relaxed">{post.caption}</p>

                        {/* Existing comments on this post */}
                        {post.comments && post.comments.length > 0 && (
                          <div className="pt-2 border-t border-slate-100 space-y-2">
                            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                              Comments ({post.comments.length})
                            </p>
                            {post.comments.map((comment) => (
                              <div key={comment.id} className="flex items-start gap-2.5 text-xs">
                                <img
                                  src={comment.userAvatar}
                                  alt={comment.userName}
                                  className="w-6 h-6 rounded-full object-cover shrink-0 mt-0.5"
                                />
                                <div>
                                  <span className="font-bold text-slate-900 mr-1.5">{comment.userName}</span>
                                  <span className="text-slate-700">{comment.text}</span>
                                  <div className="text-[10px] text-slate-400 mt-0.5">{comment.timestamp}</div>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Add Comment to Post */}
                        <form
                          onSubmit={(e) => handlePostComment(post.id, e)}
                          className="flex items-center gap-2 pt-2 border-t border-slate-100"
                        >
                          <input
                            type="text"
                            value={postCommentInputs[post.id] || ''}
                            onChange={(e) =>
                              setPostCommentInputs((prev) => ({ ...prev, [post.id]: e.target.value }))
                            }
                            placeholder="Add a comment to this seller photo..."
                            className="flex-1 text-xs bg-slate-100 px-3 py-2 rounded-full border border-transparent focus:border-orange-500 outline-none text-slate-800"
                          />
                          <button
                            type="submit"
                            disabled={!postCommentInputs[post.id]?.trim()}
                            className="p-2 bg-orange-600 hover:bg-orange-700 disabled:opacity-40 text-white rounded-full transition-all"
                          >
                            <Send className="w-3.5 h-3.5" />
                          </button>
                        </form>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* TAB 3: ARTISAN PORTFOLIO & WORKSHOP SHOWCASES */}
            {activeTab === 'portfolio' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Artisan & Workshop Highlights
                  </h3>
                  <span className="text-xs text-slate-400">Master craft stories, GI certs & awards</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  {portfolio.map((item) => (
                    <div
                      key={item.id}
                      className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm flex flex-col justify-between"
                    >
                      <div>
                        <div className="relative aspect-video bg-slate-100 overflow-hidden">
                          <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
                          <span className="absolute top-2.5 left-2.5 bg-white/80 backdrop-blur-md text-amber-300 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded shadow">
                            {item.category}
                          </span>
                        </div>

                        <div className="p-4">
                          <h4 className="text-sm font-bold text-slate-900 leading-snug">{item.title}</h4>
                          <p className="text-xs text-slate-600 mt-2 leading-relaxed">{item.description}</p>
                          {item.tags && (
                            <div className="flex items-center gap-1.5 flex-wrap mt-3">
                              {item.tags.map((t, i) => (
                                <span
                                  key={i}
                                  className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-medium"
                                >
                                  #{t}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Action Bar */}
                      <div className="p-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => likeSellerPortfolioItem(seller.id, item.id)}
                            className={`flex items-center gap-1 text-xs px-2.5 py-1 rounded-full border transition-all ${
                              item.isLikedByMe
                                ? 'bg-rose-50 border-rose-200 text-rose-600 font-bold'
                                : 'bg-white border-slate-200 text-slate-600 hover:text-rose-600'
                            }`}
                          >
                            <ThumbsUp className="w-3.5 h-3.5" />
                            <span>{item.likesCount}</span>
                          </button>

                          <button
                            onClick={() => dislikeSellerPortfolioItem(seller.id, item.id)}
                            className={`flex items-center gap-1 text-xs px-2.5 py-1 rounded-full border transition-all ${
                              item.isDislikedByMe
                                ? 'bg-slate-200 border-slate-300 text-slate-800 font-bold'
                                : 'bg-white border-slate-200 text-slate-500 hover:text-slate-700'
                            }`}
                          >
                            <ThumbsDown className="w-3.5 h-3.5" />
                            <span>{item.dislikesCount}</span>
                          </button>
                        </div>

                        <button
                          onClick={() => toggleSaveSellerPortfolioItem(seller.id, item.id)}
                          className={`p-2 rounded-full border transition-all ${
                            item.isSavedByMe
                              ? 'bg-amber-50 border-amber-200 text-amber-600'
                              : 'bg-white border-slate-200 text-slate-400 hover:text-amber-600'
                          }`}
                          title={item.isSavedByMe ? 'Saved in Portfolio' : 'Save to Portfolio'}
                        >
                          <Bookmark className={`w-4 h-4 ${item.isSavedByMe ? 'fill-amber-500' : ''}`} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 4: POST NEW IMAGE (SELLER ACCOUNT ACTION) */}
            {activeTab === 'create_post' && (
              <div className="max-w-xl mx-auto bg-slate-50 rounded-2xl border border-slate-200 p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Camera className="w-5 h-5 text-orange-600" />
                  <h3 className="text-sm font-bold text-slate-900">Upload Live Studio Photo or Story</h3>
                </div>

                <form onSubmit={handleCreateNewPost} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Photo Image URL</label>
                    <input
                      type="url"
                      value={newPostImageUrl}
                      onChange={(e) => setNewPostImageUrl(e.target.value)}
                      placeholder="https://images.unsplash.com/... (or leave blank for sample photo)"
                      className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-xl outline-none focus:border-orange-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Post Caption</label>
                    <textarea
                      rows={3}
                      value={newPostCaption}
                      onChange={(e) => setNewPostCaption(e.target.value)}
                      placeholder="Share what your studio or brand is working on today..."
                      required
                      className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-xl outline-none focus:border-orange-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Tag a Product (Optional)</label>
                    <select
                      value={newPostTaggedProduct}
                      onChange={(e) => setNewPostTaggedProduct(e.target.value)}
                      className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-xl outline-none focus:border-orange-500"
                    >
                      <option value="">-- Select a product to tag in photo --</option>
                      {sellerProducts.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} (₹{p.price})
                        </option>
                      ))}
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Publish Post to Seller Feed</span>
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
