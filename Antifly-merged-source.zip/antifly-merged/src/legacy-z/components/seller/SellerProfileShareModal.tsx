import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Share2,
  Copy,
  Check,
  QrCode,
  Send,
  Download,
  ExternalLink,
  Sparkles,
  Award,
  Star,
  Users,
  Store,
  ShieldCheck,
} from 'lucide-react';

export const SellerProfileShareModal: React.FC = () => {
  const {
    activeShareSeller,
    isSellerShareModalOpen,
    closeSellerShareModal,
    showToast,
    openDirectChatWithPeer,
  } = useApp();

  const [copied, setCopied] = useState<boolean>(false);
  const [showQRCodeView, setShowQRCodeView] = useState<boolean>(false);

  if (!isSellerShareModalOpen || !activeShareSeller) return null;

  const seller = activeShareSeller;
  const storeSlug = seller.storeName.toLowerCase().replace(/[^a-z0-9]/g, '_');
  const shareUrl = `https://antifly.app/@${storeSlug}`;
  const shareMessage = `🌟 Check out ${seller.storeName} on Antifly! Certified artisan venture with top-rated collections. Explore catalog: ${shareUrl}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    showToast('📋 Venture Profile link copied to clipboard!');
    setTimeout(() => setCopied(false), 2500);
  };

  const handleWhatsAppShare = () => {
    const encoded = encodeURIComponent(shareMessage);
    window.open(`https://api.whatsapp.com/send?text=${encoded}`, '_blank');
    showToast('💬 Opening WhatsApp to share Venture Profile...');
  };

  const handleInstagramShare = () => {
    navigator.clipboard.writeText(shareUrl);
    showToast('📸 Link copied! Paste into your Instagram Story sticker or DM.');
  };

  const handleSendToAppChat = () => {
    closeSellerShareModal();
    openDirectChatWithPeer('customer', undefined, `Shared Venture Profile: ${seller.storeName}`);
    showToast(`🚀 Profile of ${seller.storeName} attached to Universal Chat!`);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${seller.storeName} on Antifly`,
          text: `Explore handcrafted collections from ${seller.storeName}`,
          url: shareUrl,
        });
      } catch (err) {
        // User cancelled or share failed
      }
    } else {
      handleCopyLink();
    }
  };

  return (
    <div
      id="seller-profile-share-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-white/80 backdrop-blur-md p-3 sm:p-4 animate-in fade-in duration-200"
    >
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col animate-in zoom-in-95 duration-200">
        {/* Header with Close */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Share2 className="w-4 h-4 text-pink-500" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">Share Venture Profile</h3>
          </div>
          <button
            onClick={closeSellerShareModal}
            className="w-7 h-7 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center justify-center text-slate-500 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 flex flex-col items-center">
          {showQRCodeView ? (
            /* Scannable Venture QR Badge */
            <div className="w-full flex flex-col items-center animate-in zoom-in-95">
              <div className="p-4 bg-gradient-to-br from-purple-600 via-pink-600 to-amber-500 rounded-3xl shadow-xl p-1 w-full max-w-[240px]">
                <div className="bg-white dark:bg-slate-900 rounded-[22px] p-4 flex flex-col items-center text-center">
                  <div className="w-10 h-10 rounded-full border-2 border-pink-500 overflow-hidden mb-2">
                    <img src={seller.avatar} alt={seller.storeName} className="w-full h-full object-cover" />
                  </div>
                  <h4 className="font-black text-xs text-slate-900 dark:text-white truncate max-w-[180px]">
                    {seller.storeName}
                  </h4>
                  <p className="text-[10px] text-pink-600 font-bold mb-3">@{storeSlug}</p>

                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(shareUrl)}`}
                    alt="Store QR Code"
                    className="w-36 h-36 rounded-xl border border-slate-200 dark:border-slate-700"
                  />

                  <p className="text-[10px] text-slate-500 mt-2 font-medium">Scan to visit on Antifly</p>
                </div>
              </div>

              <div className="flex gap-2 w-full mt-4">
                <button
                  onClick={() => setShowQRCodeView(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                >
                  Back to Card
                </button>
                <button
                  onClick={() => showToast('📥 QR Badge saved to photos')}
                  className="flex-1 py-2.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
              </div>
            </div>
          ) : (
            /* Instagram-Style Profile Card Preview */
            <>
              <div className="w-full rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-md bg-slate-50 dark:bg-slate-800/50 mb-4">
                {/* Banner */}
                <div className="h-20 w-full relative overflow-hidden bg-slate-200 dark:bg-slate-700">
                  <img
                    src={seller.bannerUrl || 'https://images.unsplash.com/photo-1544441893-675973e31985?w=600'}
                    alt="Banner"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-100/60 to-transparent" />
                  <span className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-slate-100/60 backdrop-blur-md text-white text-[10px] font-bold">
                    {seller.category}
                  </span>
                </div>

                {/* Profile Avatar & Info */}
                <div className="px-4 pb-4 pt-0 relative">
                  <div className="flex items-end justify-between -mt-8 mb-2">
                    <div className="w-16 h-16 rounded-full p-0.5 bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 shadow-lg">
                      <div className="w-full h-full rounded-full border-2 border-white dark:border-slate-900 overflow-hidden bg-white">
                        <img src={seller.avatar} alt={seller.storeName} className="w-full h-full object-cover" />
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800/40 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded-full text-[10px] font-bold">
                      <ShieldCheck className="w-3 h-3" />
                      <span>Verified Venture</span>
                    </div>
                  </div>

                  <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1">
                    <span>{seller.storeName}</span>
                  </h4>
                  <p className="text-[11px] font-mono text-pink-600 dark:text-pink-400 font-semibold mb-2">
                    @{storeSlug}
                  </p>

                  <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed mb-3">
                    {seller.bio || 'Authentic artisan creations, handcrafted with heritage techniques.'}
                  </p>

                  {/* Social Metrics Strip */}
                  <div className="grid grid-cols-3 gap-2 py-2 border-t border-slate-200 dark:border-slate-700/60 text-center">
                    <div>
                      <p className="text-xs font-black text-slate-800 dark:text-slate-200">
                        {seller.followers ? (seller.followers >= 1000 ? `${(seller.followers / 1000).toFixed(1)}k` : seller.followers) : '12.4k'}
                      </p>
                      <p className="text-[10px] text-slate-500 font-medium">Followers</p>
                    </div>
                    <div>
                      <p className="text-xs font-black text-slate-800 dark:text-slate-200 flex items-center justify-center gap-0.5">
                        <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                        <span>{seller.rating || 4.8}</span>
                      </p>
                      <p className="text-[10px] text-slate-500 font-medium">Rating</p>
                    </div>
                    <div>
                      <p className="text-xs font-black text-slate-800 dark:text-slate-200">
                        {seller.totalProducts || 48}+
                      </p>
                      <p className="text-[10px] text-slate-500 font-medium">Drops</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Share Channels Grid */}
              <div className="w-full grid grid-cols-4 gap-2 mb-4">
                {/* WhatsApp */}
                <button
                  onClick={handleWhatsAppShare}
                  className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 hover:bg-emerald-100 text-emerald-600 transition cursor-pointer group"
                >
                  <div className="w-9 h-9 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-sm group-hover:scale-105 transition">
                    <Send className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] font-bold text-slate-700 dark:text-slate-300 mt-1">WhatsApp</span>
                </button>

                {/* Instagram Story */}
                <button
                  onClick={handleInstagramShare}
                  className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-gradient-to-tr from-amber-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20 hover:opacity-90 transition cursor-pointer group"
                >
                  <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 text-white flex items-center justify-center shadow-sm group-hover:scale-105 transition">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] font-bold text-slate-700 dark:text-slate-300 mt-1">IG Story</span>
                </button>

                {/* Store QR Code */}
                <button
                  onClick={() => setShowQRCodeView(true)}
                  className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition cursor-pointer group"
                >
                  <div className="w-9 h-9 rounded-full bg-slate-800 dark:bg-slate-700 text-white flex items-center justify-center shadow-sm group-hover:scale-105 transition">
                    <QrCode className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] font-bold text-slate-700 dark:text-slate-300 mt-1">QR Poster</span>
                </button>

                {/* Direct App Chat */}
                <button
                  onClick={handleSendToAppChat}
                  className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-sky-50 dark:bg-sky-950/30 hover:bg-sky-100 text-sky-600 transition cursor-pointer group"
                >
                  <div className="w-9 h-9 rounded-full bg-sky-500 text-white flex items-center justify-center shadow-sm group-hover:scale-105 transition">
                    <Store className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] font-bold text-slate-700 dark:text-slate-300 mt-1">App Chat</span>
                </button>
              </div>

              {/* Copy URL Bar */}
              <div className="w-full flex items-center gap-2 p-1.5 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <input
                  type="text"
                  readOnly
                  value={shareUrl}
                  className="flex-1 bg-transparent px-3 text-xs text-slate-600 dark:text-slate-300 font-mono focus:outline-hidden select-all truncate"
                />
                <button
                  onClick={handleCopyLink}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
                    copied
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:opacity-90'
                  }`}
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
