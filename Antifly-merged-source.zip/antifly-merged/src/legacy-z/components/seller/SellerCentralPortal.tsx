import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Store,
  Package,
  TrendingUp,
  Wallet,
  AlertTriangle,
  Plus,
  Truck,
  CheckCircle,
  Clock,
  ArrowUpRight,
  RefreshCw,
  Search,
  ExternalLink,
  ShieldCheck,
  Building2,
  FileText,
  DollarSign,
  Barcode,
  Layers,
  ChevronRight,
  Filter,
  LogIn,
  Tag,
  Percent,
  Trash2,
  Sparkles,
  Share2,
  Globe,
  Receipt,
  Check,
  Copy,
  Camera,
  Heart,
  ThumbsDown,
  Eye,
  Bookmark,
  MessageCircle,
  UserX,
  ShieldAlert,
  Smartphone,
  QrCode,
} from 'lucide-react';
import { Product, Coupon } from '../../types';

export const SellerCentralPortal: React.FC = () => {
  const {
    sellers,
    activeSellerId,
    setActiveSellerId,
    currentSeller,
    sellerPayouts,
    addSellerProduct,
    updateSellerInventory,
    requestSellerPayout,
    sellerCoupons,
    createSellerCoupon,
    deleteSellerCoupon,
    toggleSellerCouponStatus,
    sellerAdminFeeLedger,
    paySellerAdminPlatformFees,
    products,
    orders,
    formatPrice,
    t,
    language,
    showToast,
    viewOrderInvoice,
    updateDriverTaskStatus,
    updateOrderStatus,
    driverTasks,
    setIsLoginModalOpen,
    createSellerPost,
    openSellerStorefront,
    sellerUPI,
    openUPIPinModal,
    blockedCustomerIdsBySeller,
    customers,
    toggleBlockCustomerBySeller,
    isCustomerBlockedBySeller,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'dashboard' | 'inventory' | 'orders' | 'posts' | 'coupons' | 'admin-fees' | 'finance' | 'add-product' | 'blocked-users'>('dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  const [payoutAmountInput, setPayoutAmountInput] = useState<number>(50000);
  const [isRequestingPayout, setIsRequestingPayout] = useState(false);
  const [blockedSearchTerm, setBlockedSearchTerm] = useState('');

  // New Social Post State
  const [newPostCaption, setNewPostCaption] = useState('');
  const [newPostImageUrl, setNewPostImageUrl] = useState('');
  const [newPostCategory, setNewPostCategory] = useState('Workshop Updates');
  const [newPostTaggedProdId, setNewPostTaggedProdId] = useState('');
  const [isSubmittingPost, setIsSubmittingPost] = useState(false);

  // New Coupon Form State
  const [couponCodeInput, setCouponCodeInput] = useState('SK20');
  const [couponDiscountVal, setCouponDiscountVal] = useState<number>(20);
  const [couponMinCartVal, setCouponMinCartVal] = useState<number>(499);
  const [couponMaxDiscVal, setCouponMaxDiscVal] = useState<number>(1000);
  const [couponSelectedProds, setCouponSelectedProds] = useState<string[]>([]);
  const [couponSyndicateToggle, setCouponSyndicateToggle] = useState<boolean>(true);
  const [isSubmittingCoupon, setIsSubmittingCoupon] = useState<boolean>(false);
  const [isSettlingFees, setIsSettlingFees] = useState<boolean>(false);

  // New Product Form State
  const [newProdName, setNewProdName] = useState('');
  const [newProdCategory, setNewProdCategory] = useState('ethnic-wear');
  const [newProdPrice, setNewProdPrice] = useState<number>(2499);
  const [newProdMrp, setNewProdMrp] = useState<number>(4999);
  const [newProdStock, setNewProdStock] = useState<number>(50);
  const [newProdImage, setNewProdImage] = useState('');
  const [newProdDesc, setNewProdDesc] = useState('');
  const [isSubmittingProd, setIsSubmittingProd] = useState(false);

  // Filter products belonging to current seller or brand
  const sellerProducts = products.filter(
    (p) =>
      p.brand.toLowerCase().includes(currentSeller.storeName.toLowerCase()) ||
      p.specifications?.some((s) => s.value === currentSeller.storeName) ||
      p.tags.includes(currentSeller.storeName) ||
      p.tags.includes('Handloom') ||
      p.tags.includes('Silk')
  );

  const filteredProducts = sellerProducts.filter((p) =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const lowStockProducts = sellerProducts.filter((p) => (p.stock || 0) < 15);

  const currentSellerFeeLogs = sellerAdminFeeLedger.filter(
    (item) => item.sellerId === currentSeller.id || item.sellerName === currentSeller.storeName
  );
  const totalPlatformFeesIncurred = currentSellerFeeLogs.reduce((s, item) => s + item.adminFee, 0);
  const pendingPlatformFees = currentSellerFeeLogs.filter(
    (item) => item.status === 'Auto-Deducted' || item.status === 'Pending'
  ).length;

  const handleCreateCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCodeInput.trim()) {
      showToast('Please enter a valid coupon promo code (e.g., SK20)');
      return;
    }
    setIsSubmittingCoupon(true);
    await createSellerCoupon({
      code: couponCodeInput.toUpperCase().trim(),
      discountValue: couponDiscountVal,
      minCartValue: couponMinCartVal,
      maxDiscount: couponMaxDiscVal,
      applicableProductIds: couponSelectedProds.length > 0 ? couponSelectedProds : undefined,
      syndicateToExternalApps: couponSyndicateToggle,
      description: `Seller Offer: ${couponDiscountVal}% Off created by ${currentSeller.storeName}`,
    });
    setIsSubmittingCoupon(false);
    setCouponCodeInput(`SK${Math.floor(10 + Math.random() * 90)}`);
  };

  const handleQuickLaunchSK20 = async () => {
    setIsSubmittingCoupon(true);
    const applicableIds = sellerProducts.slice(0, 3).map((p) => p.id);
    await createSellerCoupon({
      code: 'SK20',
      discountValue: 20,
      minCartValue: 499,
      maxDiscount: 1000,
      applicableProductIds: applicableIds.length > 0 ? applicableIds : undefined,
      syndicateToExternalApps: true,
      description: `Seller Special Offer: 20% Off by ${currentSeller.storeName} with ₹1 admin fee settlement`,
    });
    setIsSubmittingCoupon(false);
  };

  const handleSettleAdminFees = async () => {
    setIsSettlingFees(true);
    await paySellerAdminPlatformFees(currentSeller.id);
    setIsSettlingFees(false);
  };

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName.trim()) {
      showToast('Please enter product title');
      return;
    }
    setIsSubmittingProd(true);
    await addSellerProduct({
      name: newProdName,
      title: newProdName,
      category: newProdCategory,
      price: newProdPrice,
      mrp: newProdMrp,
      stock: newProdStock,
      image: newProdImage || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&auto=format&fit=crop&q=80',
      description: newProdDesc || 'Artisan handcrafted exclusive listing on Antifly.',
    });
    setIsSubmittingProd(false);
    setNewProdName('');
    setNewProdImage('');
    setNewProdDesc('');
    setActiveTab('inventory');
  };

  const handlePayoutSubmit = async () => {
    if (payoutAmountInput <= 0 || payoutAmountInput > currentSeller.balanceAvailable) {
      showToast('Invalid payout amount or exceeds available balance.');
      return;
    }
    setIsRequestingPayout(true);
    await requestSellerPayout(currentSeller.id, payoutAmountInput);
    setIsRequestingPayout(false);
  };

  return (
    <div id="seller-central-portal" className="min-h-screen bg-slate-50 text-slate-900 pb-20">
      {/* Top Seller Bar - Light Theme */}
      <div className="bg-white border-b border-slate-200 px-4 sm:px-8 py-4 sticky top-12 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-slate-800 font-black shadow-sm">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-bold tracking-tight text-slate-900">
                  {currentSeller.storeName}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
                  {currentSeller.tier}
                </span>
                <span className="hidden sm:inline-block px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                  GST: {currentSeller.gstNumber}
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                {currentSeller.fulfillmentType} &bull; Rating: ⭐ {currentSeller.rating} (4.2k+ orders) &bull; Phone: <strong className="text-slate-800">{currentSeller.phone}</strong>
              </p>
            </div>
          </div>

          {/* Seller Switcher & Actions */}
          <div className="flex items-center gap-2.5">
            <label className="text-xs font-semibold text-slate-500 hidden sm:inline">Merchant:</label>
            <select
              id="select-seller-account"
              value={activeSellerId}
              onChange={(e) => setActiveSellerId(e.target.value)}
              className="bg-slate-50 text-slate-800 font-semibold text-xs border border-slate-200 rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-500 shadow-xs"
            >
              {sellers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.storeName} ({s.tier})
                </option>
              ))}
            </select>

            <button
              onClick={() => setIsLoginModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs border border-slate-200 transition-all shadow-xs"
            >
              <LogIn className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden sm:inline">Switch / Login</span>
            </button>

            <button
              id="seller-add-product-top-btn"
              onClick={() => setActiveTab('add-product')}
              className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 font-bold px-4 py-2 rounded-xl text-xs transition-all shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>List Product</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 mt-6">
        <div className="flex items-center gap-2 border-b border-slate-200 pb-3 overflow-x-auto">
          {[
            { id: 'dashboard', label: 'Overview Dashboard', icon: TrendingUp },
            { id: 'inventory', label: `Inventory & SKUs (${sellerProducts.length})`, icon: Package },
            { id: 'orders', label: 'Order Dispatches', icon: Truck },
            {
              id: 'posts',
              label: `Store Feeds & Studio Posts (${(currentSeller.posts || []).length})`,
              icon: Camera,
              badge: 'Social',
            },
            {
              id: 'coupons',
              label: `My Coupons & Offers (${sellerCoupons.length})`,
              icon: Tag,
              badge: 'SK20',
            },
            {
              id: 'admin-fees',
              label: `Admin Platform Fees (₹1/Order)`,
              icon: Receipt,
              badge: currentSellerFeeLogs.length > 0 ? `₹${totalPlatformFeesIncurred}` : undefined,
            },
            { id: 'finance', label: 'Wallet & Bank Payouts', icon: Wallet },
            {
              id: 'blocked-users',
              label: `Blocked Customers (${(blockedCustomerIdsBySeller[currentSeller.id] || []).length})`,
              icon: UserX,
              badge: (blockedCustomerIdsBySeller[currentSeller.id] || []).length > 0 ? `${(blockedCustomerIdsBySeller[currentSeller.id] || []).length}` : undefined,
            },
            { id: 'add-product', label: '+ New Listing', icon: Plus },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-orange-600 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span
                    className={`ml-1 px-1.5 py-0.5 rounded-md text-[10px] font-black uppercase ${
                      isActive ? 'bg-orange-800 text-white' : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* TAB 1: OVERVIEW DASHBOARD */}
        {activeTab === 'dashboard' && (
          <div className="mt-6 space-y-6">
            {/* KPI Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs">
                <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
                  <span>Gross Sales Volume</span>
                  <TrendingUp className="w-4 h-4 text-emerald-600" />
                </div>
                <div className="text-2xl font-black text-slate-900 mt-2">
                  {formatPrice(currentSeller.totalRevenue)}
                </div>
                <div className="text-xs text-emerald-600 mt-1 font-semibold flex items-center gap-1">
                  <ArrowUpRight className="w-3.5 h-3.5" />
                  +18.4% this week
                </div>
              </div>

              <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs">
                <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
                  <span>Available for Payout</span>
                  <Wallet className="w-4 h-4 text-amber-600" />
                </div>
                <div className="text-2xl font-black text-amber-600 mt-2">
                  {formatPrice(currentSeller.balanceAvailable)}
                </div>
                <div className="text-xs text-slate-500 mt-1">
                  Escrow: {formatPrice(currentSeller.balanceEscrow)}
                </div>
              </div>

              <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs">
                <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
                  <span>Total Fulfilled Orders</span>
                  <Package className="w-4 h-4 text-blue-600" />
                </div>
                <div className="text-2xl font-black text-slate-900 mt-2">
                  {currentSeller.totalOrders.toLocaleString()}
                </div>
                <div className="text-xs text-blue-600 mt-1 font-semibold">
                  99.4% On-time dispatch rate
                </div>
              </div>

              <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs">
                <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
                  <span>Commission Rate</span>
                  <DollarSign className="w-4 h-4 text-purple-600" />
                </div>
                <div className="text-2xl font-black text-purple-700 mt-2">
                  {(currentSeller.commissionRate * 100).toFixed(0)}%
                </div>
                <div className="text-xs text-slate-500 mt-1">
                  Diamond Seller Special Discounted Slab
                </div>
              </div>
            </div>

            {/* Low Inventory Alert Banner */}
            {lowStockProducts.length > 0 && (
              <div className="bg-amber-50 border border-amber-200 p-4 rounded-2xl flex items-start gap-3 shadow-xs">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <h4 className="text-sm font-bold text-amber-900">
                    Low Stock Alert on {lowStockProducts.length} Products
                  </h4>
                  <p className="text-xs text-amber-700 mt-0.5">
                    Replenish inventory to maintain AntiflyFulfilled Prime same-day delivery badges and buy-box priority.
                  </p>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {lowStockProducts.slice(0, 3).map((p) => (
                      <span key={p.id} className="text-xs bg-white px-2.5 py-1 rounded-lg border border-amber-200 text-amber-900 font-semibold shadow-xs">
                        {p.name} (Only {p.stock} left)
                      </span>
                    ))}
                  </div>
                </div>
                <button
                  onClick={() => setActiveTab('inventory')}
                  className="bg-amber-500 hover:bg-amber-600 text-slate-800 font-bold px-3.5 py-2 rounded-xl text-xs transition-all shrink-0 shadow-xs"
                >
                  Manage Stocks
                </button>
              </div>
            )}

            {/* Merchant Details & Warehouse Box */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-xs">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 mb-3">
                  <Building2 className="w-4 h-4 text-amber-600" />
                  Warehouse & Dispatch Origin
                </h3>
                <div className="space-y-2 text-xs text-slate-700">
                  <div className="flex justify-between py-1.5 border-b border-slate-100">
                    <span className="text-slate-500 font-medium">Street Address:</span>
                    <span className="font-semibold text-right text-slate-900">{currentSeller.warehouseAddress.street}</span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-100">
                    <span className="text-slate-500 font-medium">City / State / Pincode:</span>
                    <span className="font-semibold text-right text-slate-900">
                      {currentSeller.warehouseAddress.city}, {currentSeller.warehouseAddress.state} - {currentSeller.warehouseAddress.pincode}
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-100">
                    <span className="text-slate-500 font-medium">Country of Origin:</span>
                    <span className="font-semibold text-right text-slate-900">{currentSeller.warehouseAddress.country}</span>
                  </div>
                  <div className="flex justify-between py-1.5">
                    <span className="text-slate-500 font-medium">Merchant Contact:</span>
                    <span className="font-semibold text-right text-slate-900">{currentSeller.phone} ({currentSeller.email})</span>
                  </div>
                </div>
              </div>

              <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-xs">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 mb-3">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  Verified Bank Settlement Account
                </h3>
                <div className="space-y-2 text-xs text-slate-700">
                  <div className="flex justify-between py-1.5 border-b border-slate-100">
                    <span className="text-slate-500 font-medium">Beneficiary Name:</span>
                    <span className="font-semibold text-right text-slate-900">{currentSeller.bankAccount.beneficiaryName}</span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-100">
                    <span className="text-slate-500 font-medium">Bank Name:</span>
                    <span className="font-semibold text-right text-slate-900">{currentSeller.bankAccount.bankName}</span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-100">
                    <span className="text-slate-500 font-medium">Account Number:</span>
                    <span className="font-mono font-bold text-right text-emerald-700">•••• •••• {currentSeller.bankAccount.accountNumber.slice(-4)}</span>
                  </div>
                  <div className="flex justify-between py-1.5">
                    <span className="text-slate-500 font-medium">IFSC / Routing Code:</span>
                    <span className="font-mono font-bold text-right text-slate-900">{currentSeller.bankAccount.ifscCode}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: INVENTORY & SKUs */}
        {activeTab === 'inventory' && (
          <div className="mt-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-2 bg-slate-50 px-3 py-2 rounded-xl border border-slate-200 w-full sm:w-80">
                <Search className="w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search SKU or title..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="bg-transparent text-xs text-slate-900 focus:outline-none w-full"
                />
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('add-product')}
                  className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 font-bold px-3.5 py-2 rounded-xl text-xs transition-all shadow-xs"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New SKU</span>
                </button>
              </div>
            </div>

            {/* Inventory Table */}
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 uppercase tracking-wider font-bold border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-3.5">Product / SKU</th>
                      <th className="px-4 py-3.5">Category</th>
                      <th className="px-4 py-3.5">Price & MRP</th>
                      <th className="px-4 py-3.5">Live Stock</th>
                      <th className="px-4 py-3.5">Status</th>
                      <th className="px-4 py-3.5 text-right">Quick Stock Update</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredProducts.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="text-center py-8 text-slate-500">
                          No matching products found in this seller catalog. Click "List Product" to create one.
                        </td>
                      </tr>
                    ) : (
                      filteredProducts.map((p) => (
                        <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                          <td className="px-4 py-3.5">
                            <div className="flex items-center gap-3">
                              <img
                                src={p.image}
                                alt={p.name}
                                className="w-10 h-10 rounded-lg object-cover bg-slate-100 border border-slate-200 shadow-xs"
                              />
                              <div>
                                <p className="font-bold text-slate-900 max-w-xs truncate">{p.name}</p>
                                <span className="text-[10px] text-slate-500 font-mono">ID: {p.id}</span>
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3.5 text-slate-600 font-medium capitalize">{p.category}</td>
                          <td className="px-4 py-3.5">
                            <span className="font-bold text-slate-900">{formatPrice(p.price)}</span>
                            <span className="text-slate-400 line-through text-[10px] ml-1.5">{formatPrice(p.mrp)}</span>
                          </td>
                          <td className="px-4 py-3.5">
                            <span
                              className={`px-2.5 py-0.5 rounded-full font-bold text-xs ${
                                (p.stock || 0) < 10
                                  ? 'bg-rose-50 text-rose-700 border border-rose-200'
                                  : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              }`}
                            >
                              {p.stock || 0} in stock
                            </span>
                          </td>
                          <td className="px-4 py-3.5">
                            <span className="flex items-center gap-1 text-emerald-700 text-xs font-bold">
                              <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                              Active Live
                            </span>
                          </td>
                          <td className="px-4 py-3.5 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => updateSellerInventory(p.id, Math.max(0, (p.stock || 0) - 5))}
                                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700 text-xs font-bold border border-slate-200"
                                title="Deduct 5"
                              >
                                -5
                              </button>
                              <button
                                onClick={() => updateSellerInventory(p.id, (p.stock || 0) + 10)}
                                className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-lg text-xs font-bold"
                                title="Add 10 Units"
                              >
                                +10
                              </button>
                              <button
                                onClick={() => updateSellerInventory(p.id, (p.stock || 0) + 50)}
                                className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-bold"
                                title="Restock +50 Units"
                              >
                                +50
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: ORDER DISPATCHES */}
        {activeTab === 'orders' && (
          <div className="mt-6 space-y-4">
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 mb-3">
                <Truck className="w-4 h-4 text-orange-600" />
                Fulfillment & Ready for Pickup Queue
              </h3>
              <div className="divide-y divide-slate-100">
                {orders.slice(0, 8).map((ord) => {
                  const matchingTask = driverTasks.find(
                    (t) => t.orderId === ord.id || t.orderNumber === ord.orderNumber
                  );

                  return (
                    <div key={ord.id} className="py-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 text-sm font-mono">{ord.orderNumber || ord.id}</span>
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            ord.status === 'Delivered'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : ord.status === 'Out for delivery' || ord.status === 'Shipped'
                              ? 'bg-blue-50 text-blue-700 border border-blue-200'
                              : 'bg-amber-50 text-amber-800 border border-amber-200'
                          }`}>
                            {ord.status}
                          </span>
                          {ord.deliveryOtp && (
                            <span className="text-[10px] bg-amber-50 px-2 py-0.5 rounded-md text-amber-800 font-mono font-bold border border-amber-200">
                              OTP: {ord.deliveryOtp}
                            </span>
                          )}
                        </div>
                        <p className="text-slate-600 mt-1">
                          Customer: <span className="text-slate-900 font-bold">{ord.customerName}</span> &bull; Items: {ord.items?.length || 1} &bull; Total: <strong className="text-slate-900">{formatPrice(ord.totalAmount)}</strong>
                        </p>
                        {ord.shippingAddress && (
                          <p className="text-[11px] text-slate-500 mt-0.5">
                            📍 {ord.shippingAddress.city}, {ord.shippingAddress.state} - {ord.shippingAddress.pincode}
                          </p>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => viewOrderInvoice(ord)}
                          className="flex items-center gap-1 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition-all border border-slate-200 shadow-xs"
                        >
                          <FileText className="w-3.5 h-3.5 text-amber-600" />
                          <span>Tax Invoice</span>
                        </button>

                        <button
                          onClick={() => {
                            if (matchingTask) {
                              updateDriverTaskStatus(matchingTask.id, 'In Transit');
                            }
                            updateOrderStatus(ord.id, 'Out for delivery');
                            showToast(`🛵 Rider dispatched! Order ${ord.orderNumber} handed over to Driver Partner.`);
                          }}
                          className="flex items-center gap-1 px-3.5 py-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 font-bold rounded-xl transition-all shadow-xs"
                        >
                          <Truck className="w-3.5 h-3.5" />
                          <span>Handover to Driver</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: WALLET & FINANCES */}
        {activeTab === 'finance' && (
          <div className="mt-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Request Payout Form */}
              <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-xs">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 mb-2">
                  <Wallet className="w-5 h-5 text-amber-600" />
                  Instant Bank & UPI Payout Settlement
                </h3>
                <p className="text-xs text-slate-500 mb-4">
                  Transfers funds directly to your verified IFSC account ({currentSeller.bankAccount.bankName}) or Linked UPI VPA with 0 gateway charge.
                </p>

                {/* Seller Linked UPI Card */}
                <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs">
                      UPI
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 flex items-center gap-1.5">
                        <span>{sellerUPI?.bankName || currentSeller.bankAccount.bankName}</span>
                        <span className="text-[10px] text-slate-500 font-mono">({sellerUPI?.accountNumberMask || 'XX4590'})</span>
                      </p>
                      <p className="text-[11px] font-mono text-emerald-700 font-semibold">{sellerUPI?.vpa || 'royal.handloom@okhdfcbank'}</p>
                    </div>
                  </div>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full border border-emerald-300">
                    Auto-Settlement Ready
                  </span>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 mb-4">
                  <span className="text-xs text-slate-500 block font-semibold">Available Balance:</span>
                  <span className="text-2xl font-black text-amber-600">{formatPrice(currentSeller.balanceAvailable)}</span>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">Transfer Amount (INR ₹):</label>
                    <input
                      type="number"
                      value={payoutAmountInput}
                      onChange={(e) => setPayoutAmountInput(Number(e.target.value))}
                      max={currentSeller.balanceAvailable}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-bold"
                    />
                  </div>

                  <div className="flex gap-2">
                    {[25000, 50000, 100000, currentSeller.balanceAvailable].map((amt, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setPayoutAmountInput(amt)}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs rounded-lg font-bold border border-slate-200"
                      >
                        ₹{amt.toLocaleString('en-IN')}
                      </button>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
                    <button
                      id="seller-payout-submit-btn"
                      onClick={handlePayoutSubmit}
                      disabled={isRequestingPayout || currentSeller.balanceAvailable <= 0}
                      className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-2.5 rounded-xl text-xs transition-all shadow-md disabled:opacity-50"
                    >
                      {isRequestingPayout ? 'Processing...' : 'Direct Bank IMPS'}
                    </button>

                    <button
                      type="button"
                      disabled={currentSeller.balanceAvailable <= 0}
                      onClick={() => {
                        openUPIPinModal({
                          amount: payoutAmountInput > 0 ? payoutAmountInput : currentSeller.balanceAvailable,
                          payeeName: `${currentSeller.storeName} (Merchant Settlement)`,
                          payeeVpa: sellerUPI?.vpa || 'royal.handloom@okhdfcbank',
                          upiApp: sellerUPI?.linkedApp || 'gpay',
                          bankName: sellerUPI?.bankName || currentSeller.bankAccount.bankName,
                          accountMask: sellerUPI?.accountNumberMask || 'XX4590',
                          onSuccess: async (utr) => {
                            await requestSellerPayout(currentSeller.id, payoutAmountInput);
                            showToast(`💸 ₹${payoutAmountInput.toLocaleString('en-IN')} instant merchant settlement transferred to ${sellerUPI?.vpa}! UTR: ${utr}`);
                          },
                        });
                      }}
                      className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold py-2.5 rounded-xl text-xs transition-all shadow-md disabled:opacity-50 cursor-pointer"
                    >
                      Instant UPI PIN Payout
                    </button>
                  </div>
                </div>
              </div>

              {/* Settlement History Table */}
              <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-xs">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 mb-3">
                  <FileText className="w-5 h-5 text-emerald-600" />
                  Recent Bank Settlement History
                </h3>
                <div className="space-y-2.5">
                  {sellerPayouts.map((pay) => (
                    <div key={pay.id} className="bg-slate-50 border border-slate-200 p-3 rounded-xl flex items-center justify-between text-xs shadow-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900">{formatPrice(pay.amount)}</span>
                          <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-50 text-emerald-700 font-bold border border-emerald-200">
                            {pay.status}
                          </span>
                        </div>
                        <p className="text-slate-500 text-[11px] font-mono mt-0.5">{pay.utrNumber}</p>
                      </div>
                      <div className="text-right text-slate-500 text-[11px]">
                        <div className="font-medium text-slate-700">{pay.date}</div>
                        <div className="text-slate-400">{pay.orderCount} orders</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB: BLOCKED CUSTOMERS MANAGER (Instagram-Style Block) */}
        {activeTab === 'blocked-users' && (
          <div className="mt-6 space-y-6">
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <UserX className="w-5 h-5 text-rose-600" />
                    <h2 className="text-lg font-bold text-slate-900">
                      Blocked Customers Directory (Instagram-Style Block)
                    </h2>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Blocked customers cannot send you live messages, view your private seller stories, or place direct COD orders. You can unblock them at any time.
                  </p>
                </div>

                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    placeholder="Search users to block/unblock..."
                    value={blockedSearchTerm}
                    onChange={(e) => setBlockedSearchTerm(e.target.value)}
                    className="pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500 w-full sm:w-64"
                  />
                </div>
              </div>

              {/* Blocked List Section */}
              <div className="mt-6">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3 flex items-center justify-between">
                  <span>Currently Blocked Accounts ({(blockedCustomerIdsBySeller[currentSeller.id] || []).length})</span>
                </h3>

                {(blockedCustomerIdsBySeller[currentSeller.id] || []).length === 0 ? (
                  <div className="p-8 text-center bg-slate-50/60 rounded-2xl border border-dashed border-slate-200">
                    <ShieldCheck className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                    <p className="text-sm font-bold text-slate-800">No Blocked Customers</p>
                    <p className="text-xs text-slate-500 mt-1">
                      Your store has an open customer relationship. If any abusive user needs restriction, you can block them from their profile or below.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {(blockedCustomerIdsBySeller[currentSeller.id] || []).map((customerId) => {
                      const cust = customers.find((c) => c.id === customerId) || {
                        id: customerId,
                        name: 'Customer Account',
                        email: 'user@example.com',
                        phone: '+91 98000 00000',
                        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
                      };

                      return (
                        <div
                          key={customerId}
                          className="p-4 bg-rose-50/40 border border-rose-200/80 rounded-2xl flex items-center justify-between gap-3 shadow-2xs"
                        >
                          <div className="flex items-center gap-3">
                            <img
                              src={cust.avatar}
                              alt={cust.name}
                              className="w-10 h-10 rounded-full object-cover border border-rose-300"
                            />
                            <div>
                              <p className="font-bold text-sm text-slate-900">{cust.name}</p>
                              <p className="text-xs text-slate-500">{cust.email}</p>
                              <span className="text-[10px] text-rose-700 font-bold bg-rose-100 px-2 py-0.5 rounded-full mt-1 inline-block">
                                Restricted from Storefront
                              </span>
                            </div>
                          </div>

                          <button
                            onClick={() => {
                              toggleBlockCustomerBySeller(currentSeller.id, customerId);
                              showToast(`Unblocked ${cust.name}`);
                            }}
                            className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs border border-slate-300 rounded-xl transition cursor-pointer"
                          >
                            Unblock
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Quick Block from Customer Directory */}
              <div className="mt-8 pt-6 border-t border-slate-100">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3">
                  Quick Restrict / Block Customers
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {customers
                    .filter((c) =>
                      blockedSearchTerm
                        ? c.name.toLowerCase().includes(blockedSearchTerm.toLowerCase()) ||
                          c.email.toLowerCase().includes(blockedSearchTerm.toLowerCase())
                        : true
                    )
                    .slice(0, 6)
                    .map((cust) => {
                      const isBlocked = isCustomerBlockedBySeller(currentSeller.id, cust.id);
                      return (
                        <div
                          key={cust.id}
                          className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-2"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <img
                              src={cust.avatar}
                              alt={cust.name}
                              className="w-8 h-8 rounded-full object-cover shrink-0"
                            />
                            <div className="truncate">
                              <p className="font-bold text-xs text-slate-900 truncate">{cust.name}</p>
                              <p className="text-[10px] text-slate-500 truncate">{cust.email}</p>
                            </div>
                          </div>

                          <button
                            onClick={() => {
                              toggleBlockCustomerBySeller(currentSeller.id, cust.id);
                              showToast(isBlocked ? `Unblocked ${cust.name}` : `Blocked ${cust.name}`);
                            }}
                            className={`px-2.5 py-1 text-xs font-bold rounded-lg shrink-0 transition cursor-pointer ${
                              isBlocked
                                ? 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                                : 'bg-rose-50 border border-rose-200 text-rose-600 hover:bg-rose-100'
                            }`}
                          >
                            {isBlocked ? 'Unblock' : 'Block'}
                          </button>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: SELLER COUPONS & PROMOTIONS */}
        {activeTab === 'coupons' && (
          <div className="mt-6 space-y-6">
            {/* Header & Quick Action */}
            <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 rounded-3xl p-6 text-slate-800 shadow-md">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="max-w-2xl">
                  <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider mb-2">
                    <Sparkles className="w-3.5 h-3.5" />
                    Seller Growth Engine & Customer Discounts
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black tracking-tight text-slate-800">
                    Create Custom Coupon Codes & Product Offers
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-900/90 font-medium mt-1">
                    Set up direct discounts (e.g., <strong>SK20 for 20% OFF</strong>) for your catalog. When customers order using your coupon or from partner cross-applications, a fixed ₹1 admin platform fee is auto-settled per fulfilled order.
                  </p>
                </div>

                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={handleQuickLaunchSK20}
                    disabled={isSubmittingCoupon}
                    className="flex items-center gap-2 bg-white text-white hover:bg-slate-900 px-4 py-2.5 rounded-2xl text-xs font-bold shadow-md transition-all active:scale-95"
                  >
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>Quick Launch "SK20" (20% OFF)</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Coupon Creation Card & Active Coupons List */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Creation Form */}
              <div className="lg:col-span-1 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
                <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
                  <Tag className="w-5 h-5 text-orange-600" />
                  <h3 className="text-sm font-bold text-slate-900">Create New Coupon Code</h3>
                </div>

                <form onSubmit={handleCreateCoupon} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      Coupon Promo Code *
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        required
                        placeholder="e.g. SK20"
                        value={couponCodeInput}
                        onChange={(e) => setCouponCodeInput(e.target.value.toUpperCase())}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-mono font-bold text-sm tracking-wider uppercase focus:outline-none focus:ring-2 focus:ring-orange-500"
                      />
                      <span className="absolute right-3 top-2 text-[10px] font-bold text-slate-400 uppercase">
                        CODE
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-slate-700 font-semibold mb-1">
                        Discount (%) *
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          min="1"
                          max="90"
                          required
                          value={couponDiscountVal}
                          onChange={(e) => setCouponDiscountVal(Number(e.target.value))}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-orange-500"
                        />
                        <Percent className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-2.5" />
                      </div>
                    </div>

                    <div>
                      <label className="block text-slate-700 font-semibold mb-1">
                        Min Cart (₹)
                      </label>
                      <input
                        type="number"
                        min="0"
                        value={couponMinCartVal}
                        onChange={(e) => setCouponMinCartVal(Number(e.target.value))}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-orange-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      Max Discount Cap (₹)
                    </label>
                    <input
                      type="number"
                      min="50"
                      value={couponMaxDiscVal}
                      onChange={(e) => setCouponMaxDiscVal(Number(e.target.value))}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      Target Eligible Products (Optional)
                    </label>
                    <div className="max-h-36 overflow-y-auto space-y-1.5 p-2 bg-slate-50 border border-slate-200 rounded-xl">
                      <label className="flex items-center gap-2 cursor-pointer font-medium text-slate-700">
                        <input
                          type="checkbox"
                          checked={couponSelectedProds.length === 0}
                          onChange={() => setCouponSelectedProds([])}
                          className="rounded text-orange-600 focus:ring-orange-500"
                        />
                        <span>All Products in My Store</span>
                      </label>
                      {sellerProducts.slice(0, 6).map((p) => {
                        const isChecked = couponSelectedProds.includes(p.id);
                        return (
                          <label key={p.id} className="flex items-center gap-2 cursor-pointer text-[11px] text-slate-600">
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setCouponSelectedProds([...couponSelectedProds, p.id]);
                                } else {
                                  setCouponSelectedProds(couponSelectedProds.filter((id) => id !== p.id));
                                }
                              }}
                              className="rounded text-orange-600 focus:ring-orange-500"
                            />
                            <span className="truncate">{p.name}</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>

                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 space-y-2">
                    <label className="flex items-start gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={couponSyndicateToggle}
                        onChange={(e) => setCouponSyndicateToggle(e.target.checked)}
                        className="rounded text-orange-600 focus:ring-orange-500 mt-0.5"
                      />
                      <span className="text-[11px] font-semibold leading-tight">
                        Syndicate offer to Android App, iOS App, and partner reseller applications.
                      </span>
                    </label>
                    <p className="text-[10px] text-amber-700 font-medium">
                      * ₹1 Admin Platform Fee applies automatically upon fulfillment of cross-app orders.
                    </p>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmittingCoupon}
                    className="w-full bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 text-white font-bold py-2.5 rounded-xl shadow-xs transition-all flex items-center justify-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{isSubmittingCoupon ? 'Publishing Offer...' : 'Create & Syndicate Offer'}</span>
                  </button>
                </form>
              </div>

              {/* Coupons List */}
              <div className="lg:col-span-2 space-y-4">
                <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
                  <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                        <span>Active Offers & Coupons</span>
                        <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-orange-100 text-orange-800">
                          {sellerCoupons.length} Active
                        </span>
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Coupons enable customers to unlock extra discounts at cart & checkout
                      </p>
                    </div>
                  </div>

                  {sellerCoupons.length === 0 ? (
                    <div className="p-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-200">
                      <Tag className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                      <p className="text-sm font-bold text-slate-700">No seller coupons active yet</p>
                      <p className="text-xs text-slate-500 mt-1">
                        Use the form on the left or click "Quick Launch SK20" to roll out a 20% promotional offer!
                      </p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {sellerCoupons.map((coupon) => (
                        <div
                          key={coupon.id}
                          className={`p-4 rounded-2xl border transition-all ${
                            coupon.isActive
                              ? 'bg-gradient-to-br from-white to-amber-50/40 border-amber-200 shadow-xs'
                              : 'bg-slate-50 border-slate-200 opacity-60'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-mono font-black text-base text-orange-700 bg-orange-100 px-2 py-0.5 rounded-lg border border-orange-200">
                                  {coupon.code}
                                </span>
                                <span className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-emerald-100 text-emerald-800">
                                  {coupon.discountValue}% OFF
                                </span>
                              </div>
                              <p className="text-xs font-medium text-slate-700 mt-2 line-clamp-2">
                                {coupon.description}
                              </p>
                            </div>

                            <button
                              onClick={() => {
                                navigator.clipboard.writeText(coupon.code);
                                showToast(`Copied ${coupon.code} to clipboard!`);
                              }}
                              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-all"
                              title="Copy Code"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="mt-3 pt-3 border-t border-amber-100/80 flex flex-wrap items-center justify-between text-[11px] text-slate-600 gap-2">
                            <div className="flex items-center gap-1.5">
                              <Globe className="w-3.5 h-3.5 text-blue-600" />
                              <span className="font-semibold text-blue-700">
                                {coupon.syndicateToExternalApps !== false ? 'Live across Partner Apps' : 'Store Only'}
                              </span>
                            </div>
                            <div className="font-mono text-slate-500">
                              Min Cart: ₹{coupon.minCartValue || 499}
                            </div>
                          </div>

                          <div className="mt-2 flex items-center justify-between pt-2 border-t border-slate-100">
                            <button
                              onClick={() => toggleSellerCouponStatus(coupon.id)}
                              className={`text-[11px] font-bold px-2.5 py-1 rounded-lg transition-all ${
                                coupon.isActive
                                  ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                                  : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                              }`}
                            >
                              {coupon.isActive ? 'Active' : 'Paused'}
                            </button>

                            <button
                              onClick={() => deleteSellerCoupon(coupon.id)}
                              className="text-[11px] font-bold text-rose-600 hover:text-rose-700 hover:bg-rose-50 px-2 py-1 rounded-lg flex items-center gap-1 transition-all"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>Remove</span>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Vice-Versa Rule Information Card */}
                <div className="bg-blue-50 border border-blue-200 p-4 rounded-2xl flex items-start gap-3">
                  <Receipt className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                  <div className="text-xs text-blue-900 space-y-1">
                    <h4 className="font-bold">Ecosystem Rule: ₹1 Admin Fee Deduction Vice-Versa</h4>
                    <p className="text-blue-800">
                      When a customer redeems a seller promo code (e.g. <strong>SK20</strong>) or orders via external applications, a nominal fee of <strong>₹1.00 per fulfilled order</strong> is automatically transferred to the central Admin Panel. Check the <button onClick={() => setActiveTab('admin-fees')} className="font-bold underline text-blue-950">Admin Platform Fees tab</button> for real-time ledger records.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: ADMIN PLATFORM FEE LEDGER */}
        {activeTab === 'admin-fees' && (
          <div className="mt-6 space-y-6">
            {/* Header & Metrics */}
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
              <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <Receipt className="w-5 h-5 text-indigo-600" />
                    <h2 className="text-lg font-bold text-slate-900">
                      Admin Platform Fee Ledger (₹1/Order)
                    </h2>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Transparent transaction history tracking ₹1.00 fees paid to Admin Panel for orders using seller promo codes or cross-application routing.
                  </p>
                </div>

                <button
                  onClick={handleSettleAdminFees}
                  disabled={isSettlingFees || pendingPlatformFees === 0}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-xs ${
                    pendingPlatformFees > 0
                      ? 'bg-indigo-600 hover:bg-indigo-700 text-white'
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{isSettlingFees ? 'Reconciling with Admin...' : `Reconcile Fees (${pendingPlatformFees} Pending)`}</span>
                </button>
              </div>

              {/* KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-xs text-slate-500 font-semibold">Total Admin Fees Paid</span>
                  <div className="text-2xl font-black text-slate-900 mt-1 font-mono">
                    ₹{totalPlatformFeesIncurred.toFixed(2)}
                  </div>
                  <span className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1 mt-0.5">
                    <CheckCircle className="w-3 h-3" />
                    Auto-reconciled with Admin
                  </span>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-xs text-slate-500 font-semibold">Orders using Seller Promo/Cross-App</span>
                  <div className="text-2xl font-black text-slate-900 mt-1 font-mono">
                    {currentSellerFeeLogs.length}
                  </div>
                  <span className="text-[11px] text-indigo-600 font-semibold mt-0.5 block">
                    100% Verified Track Record
                  </span>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-xs text-slate-500 font-semibold">Admin SLA Fee Rate</span>
                  <div className="text-2xl font-black text-indigo-600 mt-1 font-mono">
                    ₹1.00
                  </div>
                  <span className="text-[11px] text-slate-500 mt-0.5 block">
                    Fixed Flat Rate Per Order
                  </span>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-xs text-slate-500 font-semibold">Seller Balance Available</span>
                  <div className="text-2xl font-black text-amber-600 mt-1 font-mono">
                    {formatPrice(currentSeller.balanceAvailable)}
                  </div>
                  <span className="text-[11px] text-slate-500 mt-0.5 block">
                    Net After Fee Settlement
                  </span>
                </div>
              </div>
            </div>

            {/* Transactional Ledger Table */}
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
              <div className="p-4 bg-slate-50/50 border-b border-slate-200 flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Admin Platform Fee Deduction Records
                </h3>
                <span className="text-xs text-slate-500 font-semibold">
                  Showing {currentSellerFeeLogs.length} Records
                </span>
              </div>

              {currentSellerFeeLogs.length === 0 ? (
                <div className="p-8 text-center">
                  <Receipt className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <p className="text-sm font-bold text-slate-700">No platform fee logs recorded yet</p>
                  <p className="text-xs text-slate-500 mt-1">
                    When customers place orders using your seller coupon (e.g. SK20) or from external applications, logs will be displayed here in real time.
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                      <tr>
                        <th className="py-3 px-4">Date & Time</th>
                        <th className="py-3 px-4">Order ID</th>
                        <th className="py-3 px-4">Product</th>
                        <th className="py-3 px-4">Origin Channel</th>
                        <th className="py-3 px-4">Coupon Applied</th>
                        <th className="py-3 px-4 text-right">Fee Deducted</th>
                        <th className="py-3 px-4 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {currentSellerFeeLogs.map((log) => (
                        <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                            {log.date}
                          </td>
                          <td className="py-3 px-4 font-bold text-slate-900 font-mono">
                            #{log.orderNumber}
                          </td>
                          <td className="py-3 px-4 text-slate-700 max-w-[200px] truncate font-medium">
                            {log.productName}
                          </td>
                          <td className="py-3 px-4">
                            <span className="inline-flex items-center gap-1 bg-slate-100 text-slate-800 px-2 py-0.5 rounded-md font-semibold text-[11px]">
                              <Globe className="w-3 h-3 text-slate-500" />
                              {log.originApp}
                            </span>
                          </td>
                          <td className="py-3 px-4">
                            {log.couponCode ? (
                              <span className="font-mono font-bold bg-amber-50 text-amber-800 border border-amber-200 px-1.5 py-0.5 rounded text-[11px]">
                                {log.couponCode}
                              </span>
                            ) : (
                              <span className="text-slate-400">-</span>
                            )}
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                            ₹{log.adminFee.toFixed(2)}
                          </td>
                          <td className="py-3 px-4 text-right">
                            <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded-full font-bold text-[10px]">
                              <Check className="w-3 h-3 text-emerald-600" />
                              {log.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 6: ADD NEW PRODUCT */}
        {activeTab === 'add-product' && (
          <div className="mt-6 max-w-3xl mx-auto bg-white border border-slate-200 p-6 rounded-2xl shadow-xs">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2 mb-1">
              <Plus className="w-5 h-5 text-amber-600" />
              Publish New Product to Marketplace
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              Listing on behalf of <strong className="text-amber-700">{currentSeller.storeName}</strong>. 0% listing fee applies.
            </p>

            <form onSubmit={handleCreateProduct} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Product Title / Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Handcrafted Mulberry Silk Saree with Temple Border"
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm font-semibold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Category</label>
                  <select
                    value={newProdCategory}
                    onChange={(e) => setNewProdCategory(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
                  >
                    <option value="ethnic-wear">Ethnic Wear & Sarees</option>
                    <option value="electronics">Electronics & Gadgets</option>
                    <option value="beauty">Beauty & Cosmetics</option>
                    <option value="footwear">Footwear & Accessories</option>
                    <option value="home">Home & Living</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Selling Price (₹) *</label>
                  <input
                    type="number"
                    required
                    value={newProdPrice}
                    onChange={(e) => setNewProdPrice(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">MRP Price (₹)</label>
                  <input
                    type="number"
                    value={newProdMrp}
                    onChange={(e) => setNewProdMrp(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Initial Stock Count</label>
                  <input
                    type="number"
                    value={newProdStock}
                    onChange={(e) => setNewProdStock(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Cover Image URL</label>
                  <input
                    type="url"
                    placeholder="https://images.unsplash.com/..."
                    value={newProdImage}
                    onChange={(e) => setNewProdImage(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Description & Craftsmanship Story</label>
                <textarea
                  rows={3}
                  placeholder="Describe material, weave authenticity, wash care instructions..."
                  value={newProdDesc}
                  onChange={(e) => setNewProdDesc(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('inventory')}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold border border-slate-200"
                >
                  Cancel
                </button>
                <button
                  id="submit-product-listing-btn"
                  type="submit"
                  disabled={isSubmittingProd}
                  className="px-6 py-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 font-bold rounded-xl shadow-md transition-all"
                >
                  {isSubmittingProd ? 'Publishing SKU...' : 'Publish Product to Global Catalog'}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* TAB 8: SOCIAL FEEDS & STUDIO POSTS */}
        {activeTab === 'posts' && (
          <div className="mt-6 space-y-6">
            {/* Header with Public Storefront Preview Action */}
            <div className="bg-white border border-slate-200 p-6 rounded-3xl shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <Camera className="w-5 h-5 text-orange-600" />
                  <h3 className="text-lg font-bold text-slate-900">
                    Storefront Photo Feeds & Customer Interaction
                  </h3>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Upload behind-the-scenes weaving photos, loom workshops, and product releases. Customers can like, dislike, comment, and save your posts directly into their Portfolio!
                </p>
              </div>

              <button
                onClick={() => openSellerStorefront(currentSeller.id)}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-600 to-amber-600 text-white font-bold text-xs rounded-xl shadow-sm hover:opacity-95 transition"
              >
                <Eye className="w-4 h-4" />
                <span>Preview Public Profile Feed</span>
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Column: Create New Post Form */}
              <div className="lg:col-span-1 bg-white border border-slate-200 p-6 rounded-3xl shadow-xs space-y-4">
                <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Plus className="w-4 h-4 text-orange-600" />
                  <span>Publish New Image / Story</span>
                </h4>

                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    if (!newPostImageUrl.trim() && !newPostCaption.trim()) {
                      showToast('Please provide an image and caption');
                      return;
                    }
                    setIsSubmittingPost(true);
                    const selectedProd = products.find((p) => p.id === newPostTaggedProdId);
                    await createSellerPost(currentSeller.id, {
                      imageUrl: newPostImageUrl || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800',
                      caption: newPostCaption || 'Crafted with passion in our boutique studio!',
                      category: newPostCategory,
                      taggedProductId: selectedProd?.id,
                      taggedProductName: selectedProd?.name,
                      taggedProductPrice: selectedProd?.price,
                    });
                    setIsSubmittingPost(false);
                    setNewPostCaption('');
                    setNewPostImageUrl('');
                    setNewPostTaggedProdId('');
                  }}
                  className="space-y-4 text-xs"
                >
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      Post Caption & Story *
                    </label>
                    <textarea
                      required
                      rows={3}
                      value={newPostCaption}
                      onChange={(e) => setNewPostCaption(e.target.value)}
                      placeholder="Share what makes this saree/shirt special, weaving time, or festive collection details..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      Image URL
                    </label>
                    <input
                      type="url"
                      value={newPostImageUrl}
                      onChange={(e) => setNewPostImageUrl(e.target.value)}
                      placeholder="https://images.unsplash.com/photo-..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>

                  {/* Quick Preset Image Pickers */}
                  <div>
                    <label className="block text-slate-500 font-bold text-[10px] uppercase mb-1.5">
                      Or Pick Studio Preset Photo:
                    </label>
                    <div className="grid grid-cols-4 gap-1.5">
                      {[
                        { label: 'Silk Loom', url: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600' },
                        { label: 'Hand Dye', url: 'https://images.unsplash.com/photo-1607344645866-009c320c5ab8?w=600' },
                        { label: 'Linen Weave', url: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=600' },
                        { label: 'Embroidery', url: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=600' },
                      ].map((preset, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => setNewPostImageUrl(preset.url)}
                          className="relative rounded-lg overflow-hidden border border-slate-200 hover:border-orange-500 aspect-square group"
                        >
                          <img src={preset.url} alt={preset.label} className="w-full h-full object-cover" />
                          <span className="absolute inset-x-0 bottom-0 bg-slate-100/60 text-[9px] text-white font-semibold py-0.5 text-center truncate px-0.5">
                            {preset.label}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      Post Category / Topic
                    </label>
                    <select
                      value={newPostCategory}
                      onChange={(e) => setNewPostCategory(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                    >
                      <option value="Workshop Updates">Workshop & Loom Updates</option>
                      <option value="Artisan Stories">Artisan Stories & Heritage</option>
                      <option value="New Launches">New Collection Launches</option>
                      <option value="Festival Specials">Festival Specials</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      Tag a Product (Optional)
                    </label>
                    <select
                      value={newPostTaggedProdId}
                      onChange={(e) => setNewPostTaggedProdId(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                    >
                      <option value="">No Product Tagged</option>
                      {sellerProducts.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} (₹{p.price})
                        </option>
                      ))}
                    </select>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmittingPost}
                    className="w-full py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl shadow-sm transition disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    <Camera className="w-4 h-4" />
                    <span>{isSubmittingPost ? 'Posting...' : 'Publish to Seller Profile'}</span>
                  </button>
                </form>
              </div>

              {/* Right 2 Columns: Feed of Current Posts */}
              <div className="lg:col-span-2 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-slate-900">
                    Live Feed ({currentSeller.posts?.length || 0} Published Posts)
                  </h4>
                  <span className="text-xs text-slate-500">
                    Total Followers: <strong>{currentSeller.followerCount}</strong>
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {(currentSeller.posts || []).map((post) => (
                    <div
                      key={post.id}
                      className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-2xs flex flex-col justify-between"
                    >
                      <div>
                        {/* Post Header */}
                        <div className="p-3 flex items-center gap-2 border-b border-slate-100">
                          <img
                            src={post.sellerAvatar || currentSeller.logo}
                            alt={post.sellerName}
                            className="w-6 h-6 rounded-full object-cover border border-slate-200"
                          />
                          <div className="flex-1 min-w-0">
                            <h5 className="font-bold text-xs text-slate-900 truncate">
                              {post.sellerName}
                            </h5>
                            <span className="text-[10px] text-slate-400">
                              {post.uploadedAt || 'Recently'}
                            </span>
                          </div>
                          <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-50 text-amber-800 rounded-full border border-amber-200">
                            {post.category || 'Feed'}
                          </span>
                        </div>

                        {/* Post Image */}
                        <div className="relative aspect-4/3 bg-slate-100 overflow-hidden">
                          <img
                            src={post.imageUrl}
                            alt={post.caption}
                            className="w-full h-full object-cover"
                          />
                        </div>

                        {/* Caption */}
                        <div className="p-3">
                          <p className="text-xs text-slate-700 line-clamp-2">{post.caption}</p>
                          {post.taggedProductName && (
                            <div className="mt-2 p-1.5 bg-slate-50 border border-slate-100 rounded-lg flex items-center justify-between text-[11px]">
                              <span className="font-bold text-slate-800 truncate">
                                🏷️ {post.taggedProductName}
                              </span>
                              {post.taggedProductPrice && (
                                <span className="font-bold text-orange-600 shrink-0 ml-2">
                                  ₹{post.taggedProductPrice}
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Social Engagement Counters */}
                      <div className="px-3 py-2.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                        <div className="flex items-center gap-3">
                          <span className="flex items-center gap-1 text-rose-600 font-bold">
                            <Heart className="w-3.5 h-3.5 fill-rose-500" />
                            <span>{post.likesCount}</span>
                          </span>

                          <span className="flex items-center gap-1 text-slate-500 font-semibold">
                            <ThumbsDown className="w-3.5 h-3.5" />
                            <span>{post.dislikesCount || 0}</span>
                          </span>

                          <span className="flex items-center gap-1 text-slate-500 font-semibold">
                            <MessageCircle className="w-3.5 h-3.5" />
                            <span>{post.commentsCount || (post.comments?.length || 0)}</span>
                          </span>
                        </div>

                        <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                          Active in Feed
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
