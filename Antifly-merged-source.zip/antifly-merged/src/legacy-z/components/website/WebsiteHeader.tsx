import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Search,
  Mic,
  Camera,
  ShoppingBag,
  Heart,
  User,
  Sparkles,
  ChevronDown,
  Menu,
  X,
  Bell,
  Scale,
  Truck,
  ShieldCheck,
  Smartphone,
  Layers,
  ArrowRight,
  Coins,
  Store,
  Users,
  UtensilsCrossed,
  Crown,
  CreditCard,
  Tv,
  MessageSquare,
  Bookmark,
  Radio,
} from 'lucide-react';

interface WebsiteHeaderProps {
  currentView: 'home' | 'catalog' | 'account';
  setCurrentView: (view: 'home' | 'catalog' | 'account') => void;
}

export const WebsiteHeader: React.FC<WebsiteHeaderProps> = ({ currentView, setCurrentView }) => {
  const {
    categories,
    cart,
    wishlist,
    comparisonList,
    setIsCartOpen,
    setIsAntiflyAIOpen,
    setIsVoiceSearchOpen,
    setIsImageSearchOpen,
    setIsNotificationDrawerOpen,
    setIsComparisonOpen,
    searchQuery,
    setSearchQuery,
    selectedCategorySlug,
    setSelectedCategorySlug,
    notifications,
    setDeviceMode,
    superCoinsBalance,
    setIsSuperCoinsModalOpen,
    setIsResellerModalOpen,
    setIsStyleCastModalOpen,
    setIsGroupBuyModalOpen,
    resellerConfig,
    setIsFoodDeliveryModalOpen,
    setIsAntiflyOneModalOpen,
    setIsBankOffersModalOpen,
    setIsOTTModalOpen,
    antiflyOneSubscription,
    currentUserSession,
    setIsLoginModalOpen,
    setIsUniversalChatOpen,
    setIsCommunityHubOpen,
    setIsAppArchitectureModalOpen,
    setIsSavePortfolioOpen,
    savedProductIds,
    savedSellerPostIds,
    setIsFavoritesHubOpen,
    openTimeShiftCamera,
    setIsWhatsNewModalOpen,
  } = useApp();

  const totalSavedCount = (savedProductIds?.length || 0) + (savedSellerPostIds?.length || 0);

  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  const [isCategoryDropdownOpen, setIsCategoryDropdownOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 30) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const unreadCount = notifications.filter((n) => !n.isRead).length;
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setCurrentView('catalog');
    }
  };

  const handleSelectCategory = (slug: string) => {
    setSelectedCategorySlug(slug);
    setCurrentView('catalog');
    setIsCategoryDropdownOpen(false);
    setIsMobileNavOpen(false);
  };

  return (
    <header
      className={`sticky top-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#f7f4ef]/80 backdrop-blur-xl border-b border-white/60 shadow-lg shadow-stone-900/5'
          : 'bg-white/95 backdrop-blur-md border-b border-slate-200'
      }`}
    >
      {/* Top Value Proposition & Ecosystem Actions Bar */}
      <div
        className={`bg-[#f7f5f0]/90 text-slate-800 text-[11px] px-4 hidden sm:block border-b border-slate-200/80 font-medium transition-all duration-300 overflow-hidden ${
          isScrolled ? 'max-h-0 py-0 opacity-0 pointer-events-none border-b-0' : 'max-h-12 py-1.5 opacity-100'
        }`}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            {/* Ecosystem Architecture & Explainer */}
            <button
              id="header-btn-architecture"
              onClick={() => setIsAppArchitectureModalOpen(true)}
              className="flex items-center gap-1 bg-slate-900 hover:bg-slate-800 text-white px-2.5 py-0.5 rounded-full font-bold shadow-xs transition cursor-pointer"
            >
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>How It Works & Purpose</span>
            </button>

            <span className="text-slate-300">•</span>

            {/* Join Community with 15s Reels */}
            <button
              id="header-btn-community"
              onClick={() => setIsCommunityHubOpen(true)}
              className="flex items-center gap-1 bg-rose-100 hover:bg-rose-200 text-rose-800 px-2 py-0.5 rounded-full font-bold border border-rose-200 transition cursor-pointer"
            >
              <Users className="w-3 h-3 text-rose-600" />
              <span>Join Community (15s Reels)</span>
            </button>

            <span className="text-slate-300">•</span>

            {/* Universal WhatsApp Chat */}
            <button
              id="header-btn-whatsapp-chat"
              onClick={() => setIsUniversalChatOpen(true)}
              className="flex items-center gap-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded-full font-bold border border-emerald-200 transition cursor-pointer"
            >
              <MessageSquare className="w-3 h-3 text-emerald-600" />
              <span>WhatsApp Chat Support</span>
            </button>
          </div>

          <div className="flex items-center gap-3">
            {/* ZoloCoins VIP Button */}
            <button
              onClick={() => setIsSuperCoinsModalOpen(true)}
              className="flex items-center gap-1 text-slate-800 hover:text-red-600 font-bold cursor-pointer"
            >
              <Coins className="w-3 h-3 text-amber-500 fill-amber-400" />
              <span>Coins: {superCoinsBalance}</span>
            </button>
            <span className="text-slate-300">•</span>
            {/* WiseReseller Hub Button */}
            <button
              onClick={() => setIsResellerModalOpen(true)}
              className="flex items-center gap-1 text-red-600 hover:text-red-700 font-bold cursor-pointer"
            >
              <Store className="w-3 h-3 text-red-600" />
              <span>Reseller Margin Hub</span>
            </button>
            <span className="text-slate-300">•</span>
            {/* Squad Group Buy */}
            <button
              onClick={() => setIsGroupBuyModalOpen(true)}
              className="flex items-center gap-1 text-slate-700 hover:text-slate-900 font-bold cursor-pointer"
            >
              <Users className="w-3 h-3 text-slate-600" />
              <span>Squad Deals</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div
        className={`max-w-7xl mx-auto px-4 sm:px-6 transition-all duration-300 ${
          isScrolled ? 'py-2' : 'py-3.5'
        }`}
      >
        <div className="flex items-center justify-between gap-3 sm:gap-6">
          {/* Logo & Hamburger Menu Button (Opens Taupe Slide Drawer) */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMobileNavOpen(true)}
              title="Open Navigation Menu"
              className={`p-2 text-slate-800 bg-[#ece7de] hover:bg-[#dfd9ce] rounded-xl transition shadow-xs cursor-pointer flex items-center justify-center ${
                isScrolled ? 'scale-95' : 'scale-100'
              }`}
            >
              <Menu className="w-5 h-5" />
            </button>

            <div
              onClick={() => {
                setCurrentView('home');
                setSelectedCategorySlug('all');
                setSearchQuery('');
              }}
              className="cursor-pointer flex items-center gap-2.5 group"
            >
              <div
                className={`rounded-xl bg-gradient-to-tr from-cyan-500 via-indigo-600 to-purple-600 shadow-md flex items-center justify-center font-black group-hover:scale-105 transition-all relative overflow-hidden text-white ${
                  isScrolled ? 'w-8 h-8 text-base' : 'w-9 h-9 text-lg'
                }`}
              >
                <span className="font-extrabold tracking-tighter">
                  K
                </span>
              </div>
              <div className="leading-tight">
                <span
                  className={`font-extrabold tracking-tight text-slate-900 flex items-center gap-1.5 transition-all ${
                    isScrolled ? 'text-sm sm:text-base' : 'text-base'
                  }`}
                >
                  KELOI
                  <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-cyan-100 text-cyan-800 font-bold border border-cyan-300">
                    Super App
                  </span>
                </span>
                {!isScrolled && (
                  <p className="text-[9px] tracking-wide text-slate-500 font-semibold transition-opacity duration-200">
                    Artisanal Commerce • Delivery Buddy • LIFEOS
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Search Bar with AI Voice & Visual Search */}
          <div className="flex-1 max-w-xl hidden md:block">
            <form onSubmit={handleSearchSubmit} className="relative flex items-center">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search linen shirts, leather juttis, organic cotton..."
                className={`w-full pl-10 pr-20 bg-[#f6f3ee]/90 border border-[#e2ddd4] rounded-2xl text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition-all font-medium placeholder-slate-400 ${
                  isScrolled ? 'py-1.5 text-xs shadow-inner' : 'py-2.5'
                }`}
              />
              <Search className="w-4 h-4 text-slate-500 absolute left-3.5" />

              <div className="absolute right-2 flex items-center gap-1">
                {/* Voice Search */}
                <button
                  type="button"
                  onClick={() => setIsVoiceSearchOpen(true)}
                  title="Voice Search (English, Hindi, Hinglish)"
                  className="p-1.5 text-slate-600 hover:text-amber-600 hover:bg-white rounded-lg transition-all"
                >
                  <Mic className="w-4 h-4" />
                </button>

                {/* Visual Image Search */}
                <button
                  type="button"
                  onClick={() => setIsImageSearchOpen(true)}
                  title="Search by Photo"
                  className="p-1.5 text-slate-600 hover:text-amber-600 hover:bg-white rounded-lg transition-all"
                >
                  <Camera className="w-4 h-4" />
                </button>
              </div>
            </form>
          </div>

          {/* Right Action Icons */}
          <div className="flex items-center gap-1 sm:gap-2">
            {/* What's New & Prompt Features Explorer */}
            <button
              onClick={() => setIsWhatsNewModalOpen(true)}
              className={`flex items-center gap-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-emerald-500/20 ${
                isScrolled ? 'px-2.5 py-1.5' : 'px-3 py-2'
              }`}
              title="Prompt Latest Features & Release Overview"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">What's New</span>
            </button>

            {/* Time-Shift 3D Story Button */}
            <button
              onClick={openTimeShiftCamera}
              className={`flex items-center gap-1.5 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-fuchsia-500/20 ${
                isScrolled ? 'px-2.5 py-1.5' : 'px-3 py-2'
              }`}
              title="Time-Shift 3D Stories (2-Hour Ephemeral Spatial Media)"
            >
              <Radio className="w-3.5 h-3.5 animate-pulse" />
              <span className="hidden sm:inline">3D Story</span>
            </button>

            {/* Antifly AI Shopping Assistant Trigger */}
            <button
              onClick={() => setIsAntiflyAIOpen(true)}
              className={`flex items-center gap-1.5 bg-gradient-to-r from-amber-500/10 to-orange-500/10 hover:from-amber-500/20 hover:to-orange-500/20 text-amber-800 border border-amber-500/30 rounded-xl text-xs font-bold transition-all shadow-xs ${
                isScrolled ? 'px-2.5 py-1.5' : 'px-3 py-2'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
              <span className="hidden sm:inline">Ask AntiflyAI</span>
            </button>

            {/* Product Comparison Trigger */}
            {comparisonList.length > 0 && (
              <button
                onClick={() => setIsComparisonOpen(true)}
                title="Compare Products"
                className="relative p-2 text-slate-700 hover:text-amber-600 hover:bg-[#f6f3ee] rounded-xl transition-all"
              >
                <Scale className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 bg-blue-600 text-white font-bold text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
                  {comparisonList.length}
                </span>
              </button>
            )}

            {/* Notifications Bell */}
            <button
              onClick={() => setIsNotificationDrawerOpen(true)}
              title="Notifications"
              className="relative p-2 text-slate-700 hover:text-amber-600 hover:bg-[#f6f3ee] rounded-xl transition-all"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-amber-500 text-slate-800 font-bold text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Save Portfolio & Collections Hub Trigger */}
            <button
              id="header-btn-save-portfolio"
              onClick={() => setIsFavoritesHubOpen(true)}
              title="Favorites & Saved Collections Hub"
              className="relative p-2 text-slate-700 hover:text-red-500 hover:bg-[#f6f3ee] rounded-xl transition-all"
            >
              <Heart className="w-5 h-5 fill-red-50 text-red-500" />
              {totalSavedCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white font-bold text-[10px] w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                  {totalSavedCount}
                </span>
              )}
            </button>

            {/* Account Orders & Auth Button */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => {
                  if (currentUserSession.isLoggedIn) {
                    setCurrentView('account');
                  } else {
                    setIsLoginModalOpen(true);
                  }
                }}
                title={currentUserSession.isLoggedIn ? `${currentUserSession.name} (${currentUserSession.role})` : 'Sign In'}
                className={`flex items-center gap-1.5 rounded-xl text-xs font-bold transition-all border ${
                  isScrolled ? 'px-2.5 py-1' : 'px-3 py-1.5'
                } ${
                  currentUserSession.isLoggedIn
                    ? 'bg-amber-50 text-amber-900 border-amber-200 hover:bg-amber-100'
                    : 'bg-slate-900 text-white border-slate-900 hover:bg-slate-800'
                }`}
              >
                <User className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">
                  {currentUserSession.isLoggedIn
                    ? currentUserSession.name.split(' ')[0]
                    : 'Sign In'}
                </span>
                {currentUserSession.isLoggedIn && (
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-200 text-amber-900 font-extrabold uppercase">
                    {currentUserSession.role.slice(0, 3)}
                  </span>
                )}
              </button>

              {currentUserSession.isLoggedIn && (
                <button
                  onClick={() => setIsLoginModalOpen(true)}
                  title="Switch User / Relogin"
                  className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-[#f6f3ee] rounded-lg text-xs"
                >
                  ⚙️
                </button>
              )}
            </div>

            {/* Shopping Bag */}
            <button
              id="header-cart-button"
              onClick={() => setIsCartOpen(true)}
              className={`relative flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer ${
                isScrolled ? 'px-3 py-1.5' : 'px-3.5 py-2'
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">Bag</span>
              <span className="bg-amber-400 text-slate-800 px-1.5 py-0.5 rounded-full text-[10px] font-extrabold">
                {cartItemCount}
              </span>
            </button>
          </div>
        </div>

        {/* Mobile Search Bar */}
        <div className={`md:hidden transition-all duration-300 ${isScrolled ? 'mt-1.5' : 'mt-3'}`}>
          <form onSubmit={handleSearchSubmit} className="relative flex items-center">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products, brands, tags..."
              className={`w-full pl-9 pr-18 bg-[#f6f3ee]/90 border border-[#e2ddd4] rounded-xl text-xs text-slate-900 transition-all ${
                isScrolled ? 'py-1.5' : 'py-2'
              }`}
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3" />
            <div className="absolute right-1.5 flex items-center gap-1">
              <button
                type="button"
                onClick={() => setIsVoiceSearchOpen(true)}
                className="p-1 text-slate-400 hover:text-amber-500"
              >
                <Mic className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setIsImageSearchOpen(true)}
                className="p-1 text-slate-400 hover:text-amber-500"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Navigation Submenu */}
      <nav
        className={`border-t border-slate-200/80 bg-[#fdfcf9]/95 hidden lg:block transition-all duration-300 ${
          isScrolled ? 'py-0 border-t-white/40' : ''
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between text-xs font-semibold">
          <div className="flex items-center gap-1">
            <button
              onClick={() => handleSelectCategory('all')}
              className={`transition-all border-b-2 ${
                isScrolled ? 'py-2 px-3 text-[11px]' : 'py-3 px-3.5'
              } ${
                currentView === 'home' && selectedCategorySlug === 'all'
                  ? 'border-amber-500 text-amber-600 font-bold'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              All Collections
            </button>
            {categories.slice(0, 7).map((cat) => (
              <button
                key={cat.id}
                onClick={() => handleSelectCategory(cat.slug)}
                className={`transition-all border-b-2 ${
                  isScrolled ? 'py-2 px-3 text-[11px]' : 'py-3 px-3.5'
                } ${
                  currentView === 'catalog' && selectedCategorySlug === cat.slug
                    ? 'border-amber-500 text-amber-600 font-bold'
                    : 'border-transparent text-slate-600 hover:text-slate-900'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>

          <div>
            <button
              onClick={() => {
                setSelectedCategorySlug('all');
                setCurrentView('catalog');
              }}
              className="text-amber-600 hover:underline font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>Explore All Products</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </nav>

      {/* SIGNATURE TAUPE / MOCHA CURVED SLIDE DRAWER (Figma Reference Image 2) */}
      {isMobileNavOpen && (
        <div className="fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-slate-100/40 backdrop-blur-xs transition-opacity animate-fade-in"
            onClick={() => setIsMobileNavOpen(false)}
          />

          {/* Curved Taupe Drawer Panel */}
          <div className="relative w-80 max-w-[85vw] drawer-taupe-panel h-full p-6 flex flex-col justify-between z-50 animate-slide-in-right overflow-y-auto">
            {/* Top Header */}
            <div>
              <div className="flex items-center justify-between pb-6 border-b border-white/15">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center font-black text-white text-lg border border-white/30">
                    Z
                  </div>
                  <div>
                    <h3 className="font-extrabold text-base tracking-tight text-white">
                      Antifly Studio
                    </h3>
                    <p className="text-xs text-white/70">
                      {currentUserSession.isLoggedIn ? `Hi, ${currentUserSession.name}` : 'Welcome, Guest'}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setIsMobileNavOpen(false)}
                  className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Navigation Menu (Icon + Label matching Image 2) */}
              <div className="mt-6 space-y-2">
                <button
                  onClick={() => {
                    setCurrentView('home');
                    setSelectedCategorySlug('all');
                    setIsMobileNavOpen(false);
                  }}
                  className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-2xl text-sm font-bold transition ${
                    currentView === 'home'
                      ? 'bg-white/20 text-white shadow-xs'
                      : 'text-white/80 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <div className="w-7 h-7 rounded-xl bg-white/15 flex items-center justify-center">
                    <Store className="w-4 h-4 text-white" />
                  </div>
                  <span>Home Showcase</span>
                </button>

                <button
                  onClick={() => {
                    setCurrentView('catalog');
                    setSelectedCategorySlug('all');
                    setIsMobileNavOpen(false);
                  }}
                  className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-2xl text-sm font-bold transition ${
                    currentView === 'catalog'
                      ? 'bg-white/20 text-white shadow-xs'
                      : 'text-white/80 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <div className="w-7 h-7 rounded-xl bg-white/15 flex items-center justify-center">
                    <Layers className="w-4 h-4 text-white" />
                  </div>
                  <span>All Catalogues</span>
                </button>

                <button
                  onClick={() => {
                    setIsSuperCoinsModalOpen(true);
                    setIsMobileNavOpen(false);
                  }}
                  className="w-full flex items-center gap-3.5 px-4 py-3 rounded-2xl text-sm font-bold text-white/80 hover:bg-white/10 hover:text-white transition"
                >
                  <div className="w-7 h-7 rounded-xl bg-amber-400/30 flex items-center justify-center">
                    <Coins className="w-4 h-4 text-amber-300 fill-amber-300" />
                  </div>
                  <div className="flex-1 flex items-center justify-between">
                    <span>Super Coins Hub</span>
                    <span className="text-xs bg-amber-400 text-slate-800 px-2 py-0.5 rounded-full font-black">
                      {superCoinsBalance}
                    </span>
                  </div>
                </button>

                <button
                  onClick={() => {
                    setIsResellerModalOpen(true);
                    setIsMobileNavOpen(false);
                  }}
                  className="w-full flex items-center gap-3.5 px-4 py-3 rounded-2xl text-sm font-bold text-white/80 hover:bg-white/10 hover:text-white transition"
                >
                  <div className="w-7 h-7 rounded-xl bg-rose-400/30 flex items-center justify-center">
                    <Store className="w-4 h-4 text-rose-300" />
                  </div>
                  <span>Reseller Margin Hub</span>
                </button>

                <button
                  onClick={() => {
                    setCurrentView('account');
                    setIsMobileNavOpen(false);
                  }}
                  className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-2xl text-sm font-bold transition ${
                    currentView === 'account'
                      ? 'bg-white/20 text-white shadow-xs'
                      : 'text-white/80 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <div className="w-7 h-7 rounded-xl bg-white/15 flex items-center justify-center">
                    <User className="w-4 h-4 text-white" />
                  </div>
                  <span>My Orders & Profile</span>
                </button>
              </div>

              {/* Category Links */}
              <div className="mt-6 pt-5 border-t border-white/15">
                <p className="text-[11px] font-bold text-white/60 uppercase tracking-wider mb-2.5">
                  Departments
                </p>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {categories.slice(0, 6).map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => handleSelectCategory(cat.slug)}
                      className="text-left px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold truncate transition"
                    >
                      {cat.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-6 border-t border-white/15 space-y-3">
              <button
                onClick={() => {
                  setDeviceMode('mobile-android');
                  setIsMobileNavOpen(false);
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-white text-slate-900 font-bold text-xs flex items-center justify-center gap-2 shadow-md hover:bg-amber-100 transition"
              >
                <Smartphone className="w-4 h-4 text-slate-900" />
                <span>Switch to Mobile View</span>
              </button>

              <div className="flex items-center justify-between text-[11px] text-white/70">
                <span>Version 3.2.0 • Live Sync</span>
                <span>Antifly Omnichannel</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
