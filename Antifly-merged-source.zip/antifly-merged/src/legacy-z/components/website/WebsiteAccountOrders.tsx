import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../common/ProductCard';
import {
  User,
  Package,
  Heart,
  MapPin,
  Clock,
  Truck,
  RotateCcw,
  FileText,
  CheckCircle,
  AlertCircle,
  ArrowRight,
  ShieldCheck,
  ShoppingBag,
  Store,
  Zap,
} from 'lucide-react';
import { Order } from '../../types';
import { VentureProfileManager } from '../profile/VentureProfileManager';
import { BuddyProfileManager } from '../profile/BuddyProfileManager';
import { CoinsAndDiamondsTracker } from '../profile/CoinsAndDiamondsTracker';
import { Coins, Gem, Sparkles } from 'lucide-react';

export const WebsiteAccountOrders: React.FC = () => {
  const {
    currentCustomer,
    orders,
    products,
    wishlist,
    setActiveTrackingOrder,
    addToCart,
    showToast,
    settings,
    currentUserSession,
    quickSwitchUser,
    setDeviceMode,
    superCoinsBalance,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'orders' | 'rewards' | 'wishlist' | 'addresses' | 'venture' | 'buddy'>('orders');

  // Customer's orders
  const customerOrders = orders.filter(
    (o) => o.customerId === currentCustomer.id || o.customerEmail === currentCustomer.email
  );

  // Customer's wishlist products
  const wishlistProducts = products.filter((p) => wishlist.includes(p.id));

  const handlePrintInvoice = (order: Order) => {
    showToast(`Generating GST Tax Invoice for Order #${order.orderNumber}...`);
    const invoiceWindow = window.open('', '_blank');
    if (invoiceWindow) {
      invoiceWindow.document.write(`
        <html>
          <head>
            <title>Tax Invoice - ${order.orderNumber}</title>
            <style>
              body { font-family: sans-serif; padding: 24px; color: #1e293b; }
              .header { display: flex; justify-content: space-between; border-bottom: 2px solid #e2e8f0; padding-bottom: 16px; margin-bottom: 20px; }
              .table { width: 100%; border-collapse: collapse; margin-top: 20px; }
              .table th, .table td { border: 1px solid #cbd5e1; padding: 8px 12px; text-align: left; font-size: 12px; }
              .table th { background: #f8fafc; }
              .totals { margin-top: 20px; text-align: right; font-size: 13px; }
            </style>
          </head>
          <body>
            <div class="header">
              <div>
                <h2>Antifly Retail Pvt Ltd</h2>
                <p>GSTIN: 27AABCT3421K1ZZ<br/>Mumbai, Maharashtra - 400001</p>
              </div>
              <div>
                <h3>TAX INVOICE</h3>
                <p><strong>Invoice No:</strong> INV-${order.orderNumber}<br/><strong>Date:</strong> ${new Date(order.createdAt).toLocaleDateString('en-IN')}<br/><strong>Order Source:</strong> ${order.source}</p>
              </div>
            </div>
            <div>
              <strong>Billed To:</strong><br/>
              ${order.shippingAddress.fullName}<br/>
              ${order.shippingAddress.street}, ${order.shippingAddress.city}, ${order.shippingAddress.state} - ${order.shippingAddress.pincode}<br/>
              Phone: ${order.shippingAddress.phone}
            </div>
            <table class="table">
              <thead>
                <tr>
                  <th>Item</th>
                  <th>Size/Color</th>
                  <th>Qty</th>
                  <th>Price</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>
                ${order.items
                  .map(
                    (it) => `
                  <tr>
                    <td>${it.productName}</td>
                    <td>${it.size} / ${it.color}</td>
                    <td>${it.quantity}</td>
                    <td>₹${it.price.toLocaleString('en-IN')}</td>
                    <td>₹${(it.price * it.quantity).toLocaleString('en-IN')}</td>
                  </tr>
                `
                  )
                  .join('')}
              </tbody>
            </table>
            <div class="totals">
              <p>Subtotal: ₹${order.subtotal.toLocaleString('en-IN')}</p>
              ${order.discount ? `<p>Discount: -₹${order.discount.toLocaleString('en-IN')}</p>` : ''}
              <p>Shipping: ₹${order.shippingFee.toLocaleString('en-IN')}</p>
              <p><strong>Grand Total: ₹${order.totalAmount.toLocaleString('en-IN')}</strong></p>
              <p>Payment: ${order.paymentMethod} (${order.paymentStatus})</p>
            </div>
          </body>
        </html>
      `);
      invoiceWindow.document.close();
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Profile Overview Card */}
      <div className="p-6 rounded-3xl bg-slate-900 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border border-slate-800 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-slate-800 font-black text-2xl shadow-lg">
            {currentCustomer.name.charAt(0)}
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl sm:text-2xl font-extrabold text-white">
                {currentCustomer.name}
              </h2>
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                Gold Patron
              </span>
              <button
                onClick={() => setActiveTab('venture')}
                className="px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-300 border border-orange-500/30 text-[10px] font-bold hover:bg-orange-500 hover:text-white transition-all flex items-center gap-1"
              >
                <Store className="w-3 h-3" />
                <span>Venture Active</span>
              </button>
              <button
                onClick={() => setActiveTab('buddy')}
                className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold hover:bg-emerald-500 hover:text-white transition-all flex items-center gap-1"
              >
                <Truck className="w-3 h-3" />
                <span>Buddy Active</span>
              </button>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {currentCustomer.email} &bull; {currentCustomer.phone}
            </p>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="flex items-center gap-4 sm:gap-6 text-xs border-t md:border-t-0 md:border-l border-slate-800 pt-4 md:pt-0 md:pl-6 flex-wrap">
          <div>
            <span className="text-slate-400 block">Total Orders</span>
            <span className="text-lg font-extrabold text-amber-400 font-mono">
              {customerOrders.length}
            </span>
          </div>
          <div
            onClick={() => setActiveTab('rewards')}
            className="cursor-pointer hover:opacity-80 transition-opacity"
          >
            <span className="text-slate-400 flex items-center gap-1">
              <Coins className="w-3 h-3 text-amber-400" />
              <span>Coins Balance</span>
            </span>
            <span className="text-lg font-extrabold text-amber-400 font-mono">
              {superCoinsBalance} 🪙
            </span>
          </div>
          <div
            onClick={() => setActiveTab('rewards')}
            className="cursor-pointer hover:opacity-80 transition-opacity"
          >
            <span className="text-slate-400 flex items-center gap-1">
              <Gem className="w-3 h-3 text-cyan-400" />
              <span>Seller Diamonds</span>
            </span>
            <span className="text-lg font-extrabold text-cyan-400 font-mono">
              2,450 💎
            </span>
          </div>
          <div>
            <span className="text-slate-400 block">Total Spent</span>
            <span className="text-lg font-extrabold text-white font-mono">
              ₹{customerOrders.reduce((sum, o) => sum + o.totalAmount, 0).toLocaleString('en-IN')}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 sm:gap-3 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveTab('orders')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm whitespace-nowrap transition-all ${
            activeTab === 'orders'
              ? 'bg-amber-500 text-slate-800 shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>My Orders ({customerOrders.length})</span>
        </button>

        <button
          id="btn-tab-rewards-manage"
          onClick={() => setActiveTab('rewards')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm whitespace-nowrap transition-all ${
            activeTab === 'rewards'
              ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-800 shadow-md font-extrabold'
              : 'text-amber-600 dark:text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Coins & Diamonds Hub 🪙💎</span>
        </button>

        <button
          onClick={() => setActiveTab('wishlist')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm whitespace-nowrap transition-all ${
            activeTab === 'wishlist'
              ? 'bg-amber-500 text-slate-800 shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>Wishlist ({wishlistProducts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('addresses')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm whitespace-nowrap transition-all ${
            activeTab === 'addresses'
              ? 'bg-amber-500 text-slate-800 shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <MapPin className="w-4 h-4" />
          <span>Saved Addresses ({currentCustomer.addresses.length})</span>
        </button>

        <button
          id="btn-tab-venture-manage"
          onClick={() => setActiveTab('venture')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm whitespace-nowrap transition-all ${
            activeTab === 'venture'
              ? 'bg-orange-500 text-white shadow-md'
              : 'text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/40 hover:bg-orange-100'
          }`}
        >
          <Store className="w-4 h-4" />
          <span>Venture Management</span>
        </button>

        <button
          id="btn-tab-buddy-manage"
          onClick={() => setActiveTab('buddy')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm whitespace-nowrap transition-all ${
            activeTab === 'buddy'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100'
          }`}
        >
          <Truck className="w-4 h-4" />
          <span>Delivery Buddy Management</span>
        </button>
      </div>

      {/* Tab Contents */}
      {activeTab === 'rewards' && (
        <CoinsAndDiamondsTracker />
      )}

      {/* Tab Contents */}
      {activeTab === 'venture' && (
        <VentureProfileManager />
      )}

      {activeTab === 'buddy' && (
        <BuddyProfileManager />
      )}

      {activeTab === 'orders' && (
        <div className="space-y-4">
          {customerOrders.length === 0 ? (
            <div className="p-12 text-center bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
              <Package className="w-12 h-12 text-slate-400 mx-auto" />
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                No orders placed yet
              </h3>
              <p className="text-xs text-slate-500">Explore our catalog to place your first order.</p>
            </div>
          ) : (
            customerOrders.map((order) => {
              const isDelivered = order.status === 'Delivered';
              const isPending = order.status === 'Pending' || order.status === 'Confirmed';
              const isShipped = order.status === 'Shipped' || order.status === 'Out for delivery';

              return (
                <div
                  key={order.id}
                  className="p-5 sm:p-6 bg-white dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700/80 shadow-sm space-y-4"
                >
                  {/* Order Top Banner */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-700/80 text-xs">
                    <div className="flex items-center gap-3">
                      <span className="font-mono font-bold text-sm text-slate-900 dark:text-white">
                        #{order.orderNumber}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                        {order.source}
                      </span>
                      <span className="text-slate-500">
                        Placed on {new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </span>
                    </div>

                    {/* Status Badge */}
                    <div className="flex items-center gap-2">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-extrabold ${
                          isDelivered
                            ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/30'
                            : isShipped
                            ? 'bg-blue-500/10 text-blue-600 border border-blue-500/30'
                            : order.status === 'Cancelled'
                            ? 'bg-rose-500/10 text-rose-600 border border-rose-500/30'
                            : 'bg-amber-500/10 text-amber-600 border border-amber-500/30'
                        }`}
                      >
                        ● {order.status}
                      </span>

                      {order.returnStatus && order.returnStatus !== 'None' && (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-600 border border-purple-500/30">
                          Return: {order.returnStatus}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Items list */}
                  <div className="space-y-3">
                    {order.items.map((item, i) => (
                      <div key={i} className="flex items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={item.image}
                            alt={item.productName}
                            className="w-14 h-16 object-cover rounded-xl border border-slate-200 dark:border-slate-700 flex-shrink-0"
                          />
                          <div>
                            <span className="text-[10px] uppercase font-bold text-slate-500">
                              {item.brand}
                            </span>
                            <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                              {item.productName}
                            </h4>
                            <p className="text-xs text-slate-500">
                              Size: <strong>{item.size}</strong> &bull; Color: <strong>{item.color}</strong> &bull; Qty: <strong>{item.quantity}</strong>
                            </p>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="font-bold text-sm text-slate-900 dark:text-white">
                            ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Bottom details & Actions */}
                  <div className="pt-3 border-t border-slate-100 dark:border-slate-700/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs">
                    <div className="text-slate-600 dark:text-slate-400">
                      <span>Delivery to: <strong>{order.shippingAddress.city}, {order.shippingAddress.pincode}</strong></span> &bull; <span>Total Paid: <strong className="text-slate-900 dark:text-white">₹{order.totalAmount.toLocaleString('en-IN')}</strong></span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        onClick={() => handlePrintInvoice(order)}
                        className="bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-800 dark:text-slate-200 font-semibold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Tax Invoice</span>
                      </button>

                      <button
                        onClick={() => setActiveTrackingOrder(order)}
                        className="bg-slate-900 dark:bg-amber-500 hover:bg-slate-800 text-white dark:text-slate-800 font-bold px-3.5 py-1.5 rounded-xl text-xs flex items-center gap-1.5 shadow-sm"
                      >
                        <Truck className="w-3.5 h-3.5" />
                        <span>Track Live Package</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* Wishlist Tab */}
      {activeTab === 'wishlist' && (
        <div>
          {wishlistProducts.length === 0 ? (
            <div className="p-12 text-center bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
              <Heart className="w-12 h-12 text-slate-400 mx-auto" />
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Your wishlist is empty
              </h3>
              <p className="text-xs text-slate-500">Tap the heart icon on any product to save items.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              {wishlistProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Addresses Tab */}
      {activeTab === 'addresses' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {currentCustomer.addresses.map((addr) => (
            <div
              key={addr.id}
              className="p-5 bg-white dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700/80 space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                    {addr.fullName}
                  </h4>
                  <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-[10px] font-bold uppercase">
                    {addr.type}
                  </span>
                </div>
                {addr.isDefault && (
                  <span className="text-[10px] font-bold text-amber-600 bg-amber-500/10 px-2 py-0.5 rounded">
                    Default Address
                  </span>
                )}
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                {addr.street}
                {addr.apartment && <>, {addr.apartment}</>}
                <br />
                {addr.city}, {addr.state} - {addr.pincode}
                <br />
                Phone: {addr.phone}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

