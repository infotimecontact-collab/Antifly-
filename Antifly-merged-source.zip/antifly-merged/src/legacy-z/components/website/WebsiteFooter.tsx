import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Mail,
  Phone,
  MapPin,
  ShieldCheck,
  Truck,
  RotateCcw,
  Sparkles,
  ArrowRight,
  Heart,
  Smartphone,
  ExternalLink,
} from 'lucide-react';

export const WebsiteFooter: React.FC = () => {
  const {
    cmsPages,
    setActiveCMSPage,
    setDeviceMode,
    settings,
    categories,
    setSelectedCategorySlug,
    showToast,
  } = useApp();

  const [newsletterEmail, setNewsletterEmail] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail.trim()) {
      showToast(`Subscribed ${newsletterEmail}! ₹200 voucher code sent.`);
      setNewsletterEmail('');
    }
  };

  const handleOpenPage = (slug: string) => {
    const page = cmsPages.find((p) => p.slug === slug);
    if (page) {
      setActiveCMSPage(page);
    }
  };

  return (
    <footer className="bg-white text-slate-400 border-t border-slate-800 transition-colors">
      {/* Newsletter Signup Strip */}
      <div className="border-b border-slate-800/80 bg-slate-900/60 py-8 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <h3 className="text-lg sm:text-xl font-extrabold text-white">
              Join the Keloi Circle
            </h3>
            <p className="text-xs text-slate-400">
              Get <strong>₹200 OFF</strong> your first order + early access to seasonal capsule drops & LIFEOS sync.
            </p>
          </div>

          <form onSubmit={handleSubscribe} className="flex gap-2 w-full md:w-auto max-w-md">
            <div className="relative flex-1">
              <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
              <input
                type="email"
                required
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                placeholder="Enter your email address..."
                className="w-full pl-10 pr-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-sans"
              />
            </div>
            <button
              type="submit"
              className="bg-gradient-to-r from-cyan-400 via-indigo-500 to-purple-600 hover:from-cyan-300 hover:to-purple-500 text-white font-extrabold px-5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md shadow-indigo-500/20"
            >
              <span>Subscribe</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>

      {/* Main 4-Column Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 via-indigo-600 to-purple-600 flex items-center justify-center text-white font-black text-sm shadow-md shadow-indigo-500/25">
                K
              </div>
              <span className="font-extrabold text-lg text-white tracking-tight">KELOI</span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Next-generation Indian Super App uniting hyperlocal artisanal commerce, dynamic Buddy delivery, and sovereign Life Operating System (LIFEOS).
            </p>

            <div className="space-y-2 text-xs">
              <div className="flex items-center gap-2 text-slate-300">
                <MapPin className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                <span>Infotime Tech Hub, Bangalore & Mumbai, India</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <Phone className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                <span>{settings.contactPhone} (10 AM - 7 PM IST)</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <Mail className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                <span>infotime.contact@gmail.com</span>
              </div>
            </div>
          </div>

          {/* Quick Categories */}
          <div className="space-y-3 text-xs">
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">
              Artisan Collections
            </h4>
            <ul className="space-y-2">
              {categories.map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => setSelectedCategorySlug(cat.slug)}
                    className="hover:text-amber-400 transition-colors text-left"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Customer Care & Policies */}
          <div className="space-y-3 text-xs">
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">
              Customer Service
            </h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => handleOpenPage('shipping-policy')}
                  className="hover:text-amber-400 transition-colors text-left"
                >
                  Shipping & Pan-India Delivery
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleOpenPage('returns-exchange')}
                  className="hover:text-amber-400 transition-colors text-left"
                >
                  7-Day Returns & Exchanges
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleOpenPage('privacy-policy')}
                  className="hover:text-amber-400 transition-colors text-left"
                >
                  Privacy Policy & Data Security
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleOpenPage('terms-conditions')}
                  className="hover:text-amber-400 transition-colors text-left"
                >
                  Terms & Conditions
                </button>
              </li>
            </ul>
          </div>

          {/* Omnichannel Experience */}
          <div className="space-y-3 text-xs">
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">
              Ecosystem & Developer Hub
            </h4>
            <p className="text-[11px] text-slate-400">
              One Unified Multi-Role Commerce Ecosystem:
            </p>
            <div className="space-y-2">
              <button
                onClick={() => setDeviceMode('seller')}
                className="w-full p-2 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 rounded-xl flex items-center gap-2 text-amber-300 text-left font-bold"
              >
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>Seller Central Portal</span>
              </button>
              <button
                onClick={() => setDeviceMode('driver')}
                className="w-full p-2 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 rounded-xl flex items-center gap-2 text-emerald-300 text-left font-bold"
              >
                <Truck className="w-4 h-4 text-emerald-400" />
                <span>Driver Delivery App</span>
              </button>
              <button
                onClick={() => setDeviceMode('api-docs')}
                className="w-full p-2 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30 rounded-xl flex items-center gap-2 text-indigo-300 text-left font-bold"
              >
                <Sparkles className="w-4 h-4 text-indigo-400" />
                <span>Worldwide Open REST APIs</span>
              </button>
            </div>
          </div>
        </div>

        {/* Bottom copyright & badges */}
        <div className="pt-8 mt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <p>© {new Date().getFullYear()} Antifly Retail Technologies Pvt. Ltd. All rights reserved.</p>
          <div className="flex items-center gap-4 text-slate-400">
            <span>🔒 256-Bit SSL Encrypted</span>
            <span>⚡ GST Invoicing Enabled</span>
            <span>🇮🇳 Made for India</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
