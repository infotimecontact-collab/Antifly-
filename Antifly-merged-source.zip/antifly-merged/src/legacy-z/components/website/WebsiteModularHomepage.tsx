import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../common/ProductCard';
import {
  ProductCardSkeleton,
  CategorySkeleton,
  LookbookCardSkeleton,
  NearbyProductCardSkeleton,
} from '../common/SkeletonUI';
import { RealtimeETABadge } from '../common/RealtimeETABadge';
import {
  Sparkles,
  Zap,
  TrendingUp,
  Award,
  Clock,
  ArrowRight,
  ShieldCheck,
  Truck,
  RotateCcw,
  Headphones,
  Smartphone,
  Star,
  Tag,
  CheckCircle,
  Coins,
  Store,
  Users,
  Heart,
  Eye,
  Gift,
  ShoppingBag,
  Flame,
  UtensilsCrossed,
  Crown,
  CreditCard,
  Tv,
  Film,
  Percent,
  Bookmark,
  UserCheck,
  UserPlus,
  MessageCircle,
  MapPin,
  SlidersHorizontal,
  RefreshCw,
  Navigation,
  Check,
  ThumbsUp,
  Camera,
  Layers,
  Plus,
  Hourglass,
  Radio,
  Share2,
  Bell,
  BellRing,
  Filter,
  ChevronDown,
  ChevronUp,
  X,
  ExternalLink,
} from 'lucide-react';

interface WebsiteModularHomepageProps {
  onSelectCategory: (slug: string) => void;
  onViewCatalog: () => void;
}

export const WebsiteModularHomepage: React.FC<WebsiteModularHomepageProps> = ({
  onSelectCategory,
  onViewCatalog,
}) => {
  const {
    homepageSections,
    products,
    categories,
    banners,
    setIsAntiflyAIOpen,
    setDeviceMode,
    superCoinsBalance,
    setIsSuperCoinsModalOpen,
    setIsResellerModalOpen,
    setIsStyleCastModalOpen,
    setActiveStyleLook,
    styleCastLooks,
    groupBuyDeals,
    setIsGroupBuyModalOpen,
    joinGroupBuy,
    formatPrice,
    setIsFoodDeliveryModalOpen,
    setIsAntiflyOneModalOpen,
    setIsBankOffersModalOpen,
    setIsOTTModalOpen,
    antiflyOneSubscription,
    sellers,
    openSellerStorefront,
    toggleFollowSeller,
    isFollowingSeller,
    setIsSavePortfolioOpen,
    // Interest & Nearby Engine
    userInterestProfile,
    setIsInterestManagerOpen,
    getPersonalizedRecommendedProducts,
    getNearbyInterestedProducts,
    isLoadingHomepage,
    simulateHomepageRefresh,
    setShoppingVibePreference,
    setActivePdpId,
    addToCart,
    showToast,
    // Stock alerts
    openStockAlertModal,
    isSubscribedToStockAlert,
    // Time-Shift 3D Stories
    timeShiftStories,
    openTimeShiftStoryViewer,
    openTimeShiftCamera,
  } = useApp();

  // Flash Sale Countdown Timer
  const [timeLeft, setTimeLeft] = useState({ hours: 7, minutes: 42, seconds: 19 });
  // Pop animation feedback state for Nearby Products Express Buy
  const [poppingNearbyIds, setPoppingNearbyIds] = useState<Record<string, boolean>>({});
  // Nearby Products Filter
  const [nearbyFilter, setNearbyFilter] = useState<'fastest' | 'price_low' | 'rating_high'>('fastest');
  // Expanded Nearby Card for in-card store rating & delivery map summary
  const [expandedNearbyCardId, setExpandedNearbyCardId] = useState<string | null>(null);

  const handleExpressBuyNearby = (match: any) => {
    addToCart({
      productId: match.product.id,
      variantId: 'default',
      productName: match.product.name,
      brand: match.product.brand,
      color: match.product.colors[0]?.name || 'Standard',
      size: match.product.sizes[0] || 'Standard',
      price: match.product.price,
      mrp: match.product.mrp,
      image: match.product.images[0],
      quantity: 1,
      stock: match.product.totalStock,
    });

    setPoppingNearbyIds((prev) => ({ ...prev, [match.product.id]: true }));
    setTimeout(() => {
      setPoppingNearbyIds((prev) => ({ ...prev, [match.product.id]: false }));
    }, 1200);
  };

  const handleShareNearbyProduct = async (e: React.MouseEvent, match: any) => {
    e.stopPropagation();
    const product = match.product;
    const shareTitle = `${product.name} — Available Nearby (${match.distanceKm} km)`;
    const shareText = `Check out "${product.name}" from ${match.seller.storeName} (${match.deliveryType} • ETA ${match.etaMinutes}m) on Antifly!`;
    const shareUrl = `${window.location.origin}/#product-${product.id}`;

    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareText,
          url: shareUrl,
        });
        showToast('✨ Product link shared successfully!');
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          if (navigator.clipboard) {
            navigator.clipboard.writeText(`${shareTitle}\n${shareText}\n${shareUrl}`);
            showToast('🔗 Product link copied! Share via WhatsApp or Instagram.');
          }
        }
      }
    } else {
      if (navigator.clipboard) {
        navigator.clipboard.writeText(`${shareTitle}\n${shareText}\n${shareUrl}`);
        showToast('🔗 Product link copied! Paste into WhatsApp or Instagram.');
      } else {
        showToast(`Shared: ${shareTitle}`);
      }
    }
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return { hours: 12, minutes: 0, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const visibleSections = [...homepageSections]
    .filter((s) => s.isVisible)
    .sort((a, b) => a.order - b.order);

  const personalizedProducts = getPersonalizedRecommendedProducts().slice(0, 4);
  const nearbyMatches = [...getNearbyInterestedProducts()]
    .sort((a, b) => {
      if (nearbyFilter === 'fastest') {
        return (a.etaMinutes ?? a.distanceKm * 4) - (b.etaMinutes ?? b.distanceKm * 4);
      }
      if (nearbyFilter === 'price_low') {
        const priceA = a.product.finalPrice ?? a.product.price;
        const priceB = b.product.finalPrice ?? b.product.price;
        return priceA - priceB;
      }
      if (nearbyFilter === 'rating_high') {
        return (b.product.rating ?? 0) - (a.product.rating ?? 0);
      }
      return 0;
    })
    .slice(0, 4);
  const trendingProducts = products.filter((p) => p.isTrending || p.isFeatured).slice(0, 4);
  const flashSaleProducts = products.filter((p) => p.discountPercentage >= 30).slice(0, 4);
  const newArrivals = products.filter((p) => p.isNewArrival || p.isBestSeller).slice(0, 4);

  return (
    <div className="space-y-12 sm:space-y-16 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* 0. AI Personalized Interest Feed Banner & Quick Vibes Selector */}
      <section className="p-5 sm:p-6 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 rounded-3xl text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border border-amber-300/40">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[10px] font-black uppercase tracking-wider bg-white/40 backdrop-blur-md px-2.5 py-0.5 rounded-full text-amber-200 border border-white/20">
              ✨ Amazon, Flipkart & Instagram Style Feed
            </span>
            <span className="text-xs text-amber-100 font-bold flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-amber-200" />
              Delivering to: <strong className="text-white underline decoration-amber-300">{userInterestProfile.userCity} ({userInterestProfile.userPincode})</strong>
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black leading-tight text-white">
            Tailored to Your Handloom & Artisan Style
          </h2>

          {/* Quick Vibe Chips */}
          <div className="flex flex-wrap gap-1.5 pt-1">
            {[
              { id: 'all', label: '🌟 All Styles' },
              { id: 'festive', label: '🪔 Festive & Wedding' },
              { id: 'daily', label: '🌿 Everyday Casual' },
              { id: 'luxury', label: '👑 Luxury Artisanal' },
              { id: 'budget', label: '⚡ Steal Deals' },
            ].map((vibe) => (
              <button
                key={vibe.id}
                onClick={() => {
                  setShoppingVibePreference(vibe.id as any);
                  showToast(`Shopping vibe set to ${vibe.label}`);
                }}
                className={`text-[11px] font-bold px-3 py-1 rounded-full transition cursor-pointer ${
                  userInterestProfile.shoppingVibe === vibe.id
                    ? 'bg-white text-slate-900 shadow-md font-black'
                    : 'bg-slate-100/20 text-white hover:bg-slate-100/30 border border-white/20'
                }`}
              >
                {vibe.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 self-stretch md:self-auto shrink-0">
          <button
            id="open-interest-manager-btn"
            onClick={() => setIsInterestManagerOpen(true)}
            className="flex-1 md:flex-initial px-4 py-2.5 bg-white hover:bg-slate-900 text-amber-300 font-bold text-xs rounded-2xl shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Tune Interests</span>
          </button>

          <button
            id="refresh-feed-skeleton-btn"
            onClick={simulateHomepageRefresh}
            disabled={isLoadingHomepage}
            className="p-2.5 bg-white/20 hover:bg-white/30 text-white rounded-2xl transition cursor-pointer"
            title="Refresh Feed (Loads Skeleton UI)"
          >
            <RefreshCw className={`w-4 h-4 ${isLoadingHomepage ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </section>

      {/* 0.5. HYPERLOCAL & NEARBY INTERESTED PRODUCTS (According to user location & style) */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shadow-md">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded-md">
                  Hyperlocal Fast Delivery
                </span>
                <span className="text-xs text-slate-500 font-semibold hidden sm:inline">
                  Artisan Studios within {userInterestProfile.maxDistanceRadiusKm}km of {userInterestProfile.userCity}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-3 mt-1">
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
                  Nearby Products Matching Your Interest
                </h2>

                {/* Filter by Dropdown Menu */}
                <div className="inline-flex items-center gap-1.5 bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 hover:border-emerald-500/50 rounded-xl px-2.5 py-1 text-xs shadow-xs transition-colors">
                  <Filter className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <label htmlFor="nearby-filter-select" className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                    Filter by:
                  </label>
                  <select
                    id="nearby-filter-select"
                    value={nearbyFilter}
                    onChange={(e) => setNearbyFilter(e.target.value as 'fastest' | 'price_low' | 'rating_high')}
                    className="bg-transparent text-xs font-bold text-slate-800 dark:text-slate-100 focus:outline-none cursor-pointer pr-1"
                  >
                    <option value="fastest" className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100">
                      Fastest Delivery
                    </option>
                    <option value="price_low" className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100">
                      Lowest Price
                    </option>
                    <option value="rating_high" className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100">
                      Highest Rated
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={() => setIsInterestManagerOpen(true)}
            className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>Change City</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Nearby Products Grid / Skeletons */}
        {isLoadingHomepage ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {[1, 2, 3, 4].map((i) => (
              <NearbyProductCardSkeleton key={i} />
            ))}
          </div>
        ) : (
          <motion.div
            key={nearbyFilter}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6"
            initial="hidden"
            animate="visible"
            variants={{
              hidden: { opacity: 0 },
              visible: {
                opacity: 1,
                transition: {
                  staggerChildren: 0.1,
                  delayChildren: 0.05,
                },
              },
            }}
          >
            {nearbyMatches.map((match) => {
              const isOutOfStock =
                (match.product.totalStock ?? match.product.stock ?? 0) <= 0 || match.stockCount <= 0;
              const isStockAlertSubscribed = isSubscribedToStockAlert(match.product.id);
              const isExpanded = expandedNearbyCardId === match.product.id;

              return (
                <motion.div
                  key={match.product.id}
                  layout
                  layoutId={`nearby-product-card-${match.product.id}`}
                  transition={{
                    layout: { duration: 0.35, ease: [0.22, 1, 0.36, 1] },
                    opacity: { duration: 0.2 },
                  }}
                  variants={{
                    hidden: { opacity: 0, y: 28 },
                    visible: {
                      opacity: 1,
                      y: 0,
                      transition: {
                        duration: 0.5,
                        ease: [0.22, 1, 0.36, 1],
                      },
                    },
                  }}
                  onClick={() => {
                    setExpandedNearbyCardId(isExpanded ? null : match.product.id);
                  }}
                  className={`bg-white dark:bg-slate-900 rounded-2xl border transition-all flex flex-col justify-between overflow-hidden group cursor-pointer ${
                    isExpanded
                      ? 'border-emerald-500 ring-2 ring-emerald-500/20 shadow-xl'
                      : 'border-slate-200 dark:border-slate-800 hover:border-emerald-500/60 shadow-xs hover:shadow-xl'
                  }`}
                >
                  <AnimatePresence mode="wait" initial={false}>
                    {isExpanded ? (
                      /* ========================================================================= */
                      /* EXPANDED COMPACT SUMMARY VIEW (IN-CARD: STORE RATINGS + DELIVERY MAP) */
                      /* ========================================================================= */
                      <motion.div
                        key="expanded-summary"
                        initial={{ opacity: 0, scale: 0.98 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.98 }}
                        transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
                        className="p-3.5 sm:p-4 flex flex-col justify-between h-full space-y-3 select-text"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {/* Header: Product Mini Preview & Collapse Button */}
                        <div className="flex items-start justify-between gap-2.5 pb-2.5 border-b border-slate-100 dark:border-slate-800">
                          <div className="flex items-center gap-2.5">
                            <img
                              src={match.product.images[0]}
                              alt={match.product.name}
                              className="w-12 h-12 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                            />
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="bg-emerald-600 text-white text-[9px] font-black uppercase px-1.5 py-0.5 rounded shadow-xs flex items-center gap-0.5">
                                  <Truck className="w-2.5 h-2.5" /> {match.deliveryType}
                                </span>
                                <span className="text-[10px] font-bold text-slate-500">
                                  {match.distanceKm} km away
                                </span>
                              </div>
                              <h4 className="text-xs font-extrabold text-slate-900 dark:text-white line-clamp-1 mt-0.5">
                                {match.product.name}
                              </h4>
                              <div className="text-xs font-black text-emerald-600 dark:text-emerald-400">
                                {formatPrice(match.product.price)}
                              </div>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setExpandedNearbyCardId(null);
                            }}
                            className="p-1 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors cursor-pointer shrink-0"
                            title="Collapse summary view"
                          >
                            <ChevronUp className="w-4 h-4" />
                          </button>
                        </div>

                        {/* 1. Store Ratings & Merchant Reputation Block */}
                        <div className="bg-slate-50 dark:bg-slate-800/80 rounded-xl p-2.5 border border-slate-200/80 dark:border-slate-700/80 space-y-1.5">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-1.5 min-w-0">
                              <div className="w-6 h-6 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center shrink-0">
                                <Store className="w-3.5 h-3.5" />
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                                    {match.seller.storeName}
                                  </span>
                                  <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[9px] font-black bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700/60 shrink-0">
                                    {match.distanceKm} km away
                                  </span>
                                </div>
                                <div className="text-[10px] text-slate-500 truncate">
                                  {match.seller.warehouseAddress?.city || match.seller.city || 'Local Hub'} &bull; {match.seller.tier || 'Diamond Vendor'}
                                </div>
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                openSellerStorefront(match.seller.id);
                              }}
                              className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-0.5 shrink-0 cursor-pointer ml-1"
                            >
                              <span>Store</span>
                              <ExternalLink className="w-2.5 h-2.5" />
                            </button>
                          </div>

                          {/* Star Rating Score & Trust Indicators */}
                          <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 dark:border-slate-700/60 text-[11px]">
                            <div className="flex items-center gap-1">
                              <div className="flex items-center text-amber-500">
                                {[...Array(5)].map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`w-3 h-3 ${
                                      i < Math.floor(match.seller.rating || 4.9)
                                        ? 'fill-amber-400 text-amber-400'
                                        : 'text-slate-300 dark:text-slate-600'
                                    }`}
                                  />
                                ))}
                              </div>
                              <span className="font-extrabold text-slate-900 dark:text-white">
                                {match.seller.rating || 4.9}
                              </span>
                              <span className="text-[10px] text-slate-500">
                                ({match.seller.totalOrders || 1240}+ orders)
                              </span>
                            </div>
                            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.5 rounded">
                              99.2% On-time
                            </span>
                          </div>
                        </div>

                        {/* 2. Interactive Delivery Route Map Snippet */}
                        <div className="group/map bg-slate-900 text-white rounded-xl p-2.5 border border-slate-800 hover:border-emerald-500/50 hover:shadow-lg hover:shadow-emerald-950/40 transition-all duration-300 space-y-2 relative overflow-hidden cursor-pointer">
                          {/* Map Background Grid Simulation */}
                          <div
                            className="absolute inset-0 opacity-15 group-hover/map:opacity-25 transition-opacity duration-300 pointer-events-none"
                            style={{
                              backgroundImage:
                                'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.4) 1px, transparent 0)',
                              backgroundSize: '12px 12px',
                            }}
                          />

                          <div className="flex items-center justify-between text-[10px] font-bold text-slate-300 relative z-10">
                            <div className="flex items-center gap-1.5">
                              <span className="flex items-center gap-1 text-emerald-400 group-hover/map:text-emerald-300 transition-colors">
                                <Navigation className="w-3 h-3 group-hover/map:rotate-12 transition-transform duration-300" />
                                <span>Live Hyperlocal Corridor</span>
                              </span>
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-emerald-500/20 group-hover/map:bg-emerald-500/30 border border-emerald-400/50 group-hover/map:border-emerald-400/80 text-emerald-300 text-[8px] font-black shadow-xs group-hover/map:shadow-[0_0_8px_rgba(52,211,153,0.5)] transition-all duration-300">
                                <Zap className="w-2.5 h-2.5 fill-amber-400 text-amber-400 animate-pulse" />
                                <span>Fastest Route</span>
                              </span>
                            </div>
                            <RealtimeETABadge
                              initialMinutes={match.etaMinutes}
                              id={`expanded-nearby-eta-${match.product.id}`}
                            />
                          </div>

                          {/* Visual Route SVG Corridor with Animated Courier Marker */}
                          <div className="relative py-2 px-1 z-10">
                            <div className="flex items-center justify-between text-[10px] font-bold mb-1">
                              <div className="flex items-center gap-1 text-slate-300">
                                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                                <span className="truncate max-w-[90px]">
                                  {match.seller.warehouseAddress?.city || match.seller.city || 'Hub'}
                                </span>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <div className="text-[9px] font-black text-amber-400 bg-amber-950/70 group-hover/map:bg-amber-900/80 px-1.5 py-0.5 rounded border border-amber-500/30 group-hover/map:border-amber-400/60 flex items-center gap-0.5 transition-all">
                                  <Zap className="w-2 h-2 fill-amber-400 text-amber-400" />
                                  <span>{match.distanceKm} km direct</span>
                                </div>
                                <span className="text-[8px] text-slate-500 hidden sm:inline line-through">
                                  {(match.distanceKm * 1.35).toFixed(1)} km detour
                                </span>
                              </div>
                              <div className="flex items-center gap-1 text-slate-300">
                                <MapPin className="w-3 h-3 text-rose-400 group-hover/map:scale-110 transition-transform" />
                                <span className="truncate max-w-[90px]">
                                  {userInterestProfile.userCity || 'Your Location'}
                                </span>
                              </div>
                            </div>

                            {/* SVG Route Line (Multiple paths: Detour vs Fastest Active with glowing hover state) */}
                            <div className="relative h-7 flex items-center justify-center">
                              <svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox="0 0 200 28">
                                <defs>
                                  <filter id={`route-glow-${match.product.id}`} x="-20%" y="-40%" width="140%" height="180%">
                                    <feDropShadow dx="0" dy="0" stdDeviation="3.5" floodColor="#34d399" floodOpacity="0.9" />
                                  </filter>
                                </defs>
                                {/* Alternate Secondary Path (Detour) */}
                                <path
                                  d="M 10,14 C 60,26 140,2 190,14"
                                  fill="none"
                                  stroke="#475569"
                                  strokeWidth="1.5"
                                  strokeDasharray="3 3"
                                  strokeOpacity="0.6"
                                  className="transition-opacity duration-300 group-hover/map:stroke-opacity-40"
                                />
                                {/* Primary Base Glow Outline (Intensifies on map hover) */}
                                <path
                                  d="M 10,14 C 60,4 140,24 190,14"
                                  fill="none"
                                  stroke="#10b981"
                                  strokeWidth="6"
                                  strokeOpacity="0.15"
                                  strokeLinecap="round"
                                  className="transition-all duration-300 group-hover/map:stroke-emerald-400 group-hover/map:stroke-opacity-50 group-hover/map:stroke-[8]"
                                />
                                {/* Active Fastest Transit Path with Dynamic Glow */}
                                <path
                                  d="M 10,14 C 60,4 140,24 190,14"
                                  fill="none"
                                  stroke="#10b981"
                                  strokeWidth="2.5"
                                  strokeLinecap="round"
                                  className="transition-all duration-300 group-hover/map:stroke-emerald-300 group-hover/map:stroke-[3.5] group-hover/map:[filter:drop-shadow(0_0_8px_rgba(52,211,153,0.95))_drop-shadow(0_0_16px_rgba(16,185,129,0.6))]"
                                  style={{
                                    filter: 'drop-shadow(0 0 2px rgba(16,185,129,0.5))',
                                  }}
                                />
                              </svg>

                              {/* Animated Courier Marker */}
                              <motion.div
                                animate={{
                                  x: ['-60%', '60%'],
                                }}
                                transition={{
                                  repeat: Infinity,
                                  repeatType: 'reverse',
                                  duration: 3.5,
                                  ease: 'easeInOut',
                                }}
                                className="absolute top-1/2 -translate-y-1/2 flex items-center gap-0.5 bg-emerald-500 text-slate-800 px-1.5 py-0.5 rounded-full text-[9px] font-black shadow-md border border-emerald-300 group-hover/map:scale-110 group-hover/map:shadow-[0_0_12px_rgba(16,185,129,0.9)] transition-all duration-300"
                              >
                                <Truck className="w-2.5 h-2.5" />
                                <span>Express</span>
                              </motion.div>
                            </div>

                            <div className="flex items-center justify-between text-[9px] text-slate-400 pt-0.5">
                              <div className="flex items-center gap-1.5">
                                <span className="inline-flex items-center gap-1 text-emerald-400 group-hover/map:text-emerald-300 font-bold transition-colors">
                                  <Zap className="w-2.5 h-2.5 fill-amber-400 text-amber-400" />
                                  <span>Fastest Highway Corridor</span>
                                </span>
                                <span className="text-[8px] text-slate-500">(2 routes analyzed)</span>
                              </div>
                              <span className="text-emerald-400 group-hover/map:text-emerald-300 font-semibold flex items-center gap-1 transition-colors">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 group-hover/map:bg-emerald-300 animate-pulse" />
                                Priority Lane
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Expanded Actions Footer */}
                        <div className="pt-1 flex items-center gap-2">
                          {isOutOfStock ? (
                            <button
                              id={`expanded-notify-btn-${match.product.id}`}
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                openStockAlertModal(match.product);
                              }}
                              className={`flex-1 py-2 px-3 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer select-none ${
                                isStockAlertSubscribed
                                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-700/60'
                                  : 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-800 font-extrabold shadow-xs hover:shadow-md'
                              }`}
                            >
                              <Bell className="w-3.5 h-3.5" />
                              <span>{isStockAlertSubscribed ? 'Alert Active' : 'Notify Restock'}</span>
                            </button>
                          ) : (
                            <button
                              id={`expanded-express-buy-btn-${match.product.id}`}
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleExpressBuyNearby(match);
                              }}
                              className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition-all shadow-xs hover:shadow-md flex items-center justify-center gap-1.5 cursor-pointer select-none"
                            >
                              <ShoppingBag className="w-3.5 h-3.5" />
                              <span>Express Buy &bull; {formatPrice(match.product.price)}</span>
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setActivePdpId(match.product.id);
                            }}
                            className="py-2 px-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold transition-colors cursor-pointer"
                            title="View Full Product Details"
                          >
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </motion.div>
                    ) : (
                      /* ========================================================================= */
                      /* STANDARD COLLAPSED CARD VIEW WITH STORE & MAP EXPANSION TRIGGER */
                      /* ========================================================================= */
                      <motion.div
                        key="collapsed-standard"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="flex flex-col justify-between h-full"
                      >
                        <div className="relative overflow-hidden group/img">
                          <img
                            src={match.product.images[0]}
                            alt={match.product.name}
                            onClick={(e) => {
                              e.stopPropagation();
                              setActivePdpId(match.product.id);
                            }}
                            className={`w-full aspect-[4/3] object-cover cursor-pointer group-hover:scale-105 transition-transform duration-500 ${
                              isOutOfStock ? 'grayscale-[35%] opacity-90' : ''
                            }`}
                          />
                          <div className="absolute top-2.5 left-2.5 flex flex-col gap-1">
                            <span className="bg-emerald-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded shadow-sm flex items-center gap-1">
                              <Truck className="w-3 h-3" /> {match.deliveryType}
                            </span>
                            {isOutOfStock && (
                              <span className="bg-rose-600/95 backdrop-blur-xs text-white text-[10px] font-black uppercase px-2 py-0.5 rounded shadow-sm flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                                Sold Out
                              </span>
                            )}
                          </div>
                          <div className="absolute top-2.5 right-2.5 flex items-center gap-1.5 z-10">
                            <div className="bg-white/80 backdrop-blur-md text-white text-[11px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                              <Navigation className="w-3 h-3 text-emerald-400" />
                              <span>{match.distanceKm} km</span>
                            </div>
                            <button
                              id={`nearby-product-share-btn-${match.product.id}`}
                              type="button"
                              onClick={(e) => handleShareNearbyProduct(e, match)}
                              className="w-7 h-7 rounded-full bg-white/85 hover:bg-emerald-600 backdrop-blur-md text-white flex items-center justify-center transition-all shadow-md cursor-pointer border border-white/20 hover:scale-110 active:scale-95"
                              title="Share product link (WhatsApp, Instagram, Web Share)"
                            >
                              <Share2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          {/* Floating Action: Quick Add OR Notify Me if Out of Stock */}
                          <div className="absolute bottom-2.5 right-2.5 z-10">
                            {isOutOfStock ? (
                              <motion.button
                                id={`floating-notify-btn-${match.product.id}`}
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openStockAlertModal(match.product);
                                }}
                                whileTap={{ scale: 0.9 }}
                                whileHover={{ scale: 1.05 }}
                                className={`px-2.5 py-1.5 rounded-xl text-xs font-bold shadow-lg backdrop-blur-md transition-all flex items-center gap-1.5 cursor-pointer border select-none ${
                                  isStockAlertSubscribed
                                    ? 'bg-emerald-600 text-white border-emerald-400 shadow-emerald-600/40 ring-2 ring-emerald-300'
                                    : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 border-amber-300/40 shadow-amber-500/25'
                                }`}
                                title={
                                  isStockAlertSubscribed
                                    ? 'Restock alert active — click to manage or test'
                                    : 'Item out of stock — click to get notified when restocked'
                                }
                              >
                                <Bell
                                  className={`w-3.5 h-3.5 ${
                                    isStockAlertSubscribed ? 'fill-white text-white' : 'fill-slate-950 text-slate-800'
                                  }`}
                                />
                                <span>{isStockAlertSubscribed ? 'Alert Active' : 'Notify Me'}</span>
                              </motion.button>
                            ) : (
                              <motion.button
                                id={`floating-quick-add-btn-${match.product.id}`}
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleExpressBuyNearby(match);
                                }}
                                whileTap={{ scale: 0.9 }}
                                whileHover={{ scale: 1.05 }}
                                animate={
                                  poppingNearbyIds[match.product.id]
                                    ? { scale: [1, 1.25, 0.95, 1.1, 1], transition: { duration: 0.4 } }
                                    : { scale: 1 }
                                }
                                className={`px-2.5 py-1.5 rounded-xl text-xs font-bold shadow-lg backdrop-blur-md transition-all flex items-center gap-1.5 cursor-pointer border select-none ${
                                  poppingNearbyIds[match.product.id]
                                    ? 'bg-emerald-600 text-white border-emerald-400 shadow-emerald-600/40 ring-2 ring-emerald-300'
                                    : 'bg-white/85 hover:bg-emerald-600 dark:bg-slate-900/90 dark:hover:bg-emerald-600 text-white border-white/20 hover:border-emerald-400 shadow-slate-950/30'
                                }`}
                                title="Quick Add to Cart"
                              >
                                {poppingNearbyIds[match.product.id] ? (
                                  <>
                                    <Check className="w-3.5 h-3.5 text-white stroke-[3]" />
                                    <span>Added</span>
                                  </>
                                ) : (
                                  <>
                                    <Plus className="w-3.5 h-3.5 text-emerald-400" />
                                    <span>Quick Add</span>
                                  </>
                                )}
                              </motion.button>
                            )}
                          </div>
                        </div>

                        <div className="p-3.5 flex-1 flex flex-col justify-between space-y-3">
                          <div>
                            <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openSellerStorefront(match.seller.id);
                                }}
                                className="font-bold text-slate-700 dark:text-slate-300 hover:text-emerald-600 truncate flex items-center gap-1 cursor-pointer"
                              >
                                <Store className="w-3 h-3 text-emerald-600 shrink-0" />
                                <span className="truncate">{match.seller.storeName}</span>
                              </button>
                              <RealtimeETABadge
                                initialMinutes={match.etaMinutes}
                                id={`nearby-eta-tag-${match.product.id}`}
                              />
                            </div>

                            <h4
                              onClick={(e) => {
                                e.stopPropagation();
                                setActivePdpId(match.product.id);
                              }}
                              className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1 hover:text-emerald-600 cursor-pointer"
                            >
                              {match.product.name}
                            </h4>

                            {isOutOfStock ? (
                              <p className="text-[11px] text-rose-500 dark:text-rose-400 font-semibold mt-0.5 flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                                Out of stock at {match.seller.city} hub &bull; Subscribe for alert
                              </p>
                            ) : (
                              <p className="text-[11px] text-slate-500 mt-0.5">
                                Dispatching from {match.seller.city} hub &bull; {match.stockCount} left
                              </p>
                            )}
                          </div>

                          {/* Interactive In-Card Expansion Hint Bar */}
                          <div
                            onClick={(e) => {
                              e.stopPropagation();
                              setExpandedNearbyCardId(match.product.id);
                            }}
                            className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold hover:text-emerald-700 transition-colors cursor-pointer group/bar select-none"
                          >
                            <span className="flex items-center gap-1">
                              <Store className="w-3.5 h-3.5 text-emerald-500" />
                              <span className="font-bold">Store Ratings &amp; Route Map</span>
                            </span>
                            <span className="flex items-center gap-0.5 text-[10px] font-extrabold bg-emerald-50 dark:bg-emerald-950/60 group-hover/bar:bg-emerald-100 dark:group-hover/bar:bg-emerald-900/60 px-1.5 py-0.5 rounded-md transition-colors">
                              <span>Summary</span>
                              <ChevronDown className="w-3 h-3 transition-transform group-hover/bar:translate-y-0.5" />
                            </span>
                          </div>

                          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                            <span className="text-sm font-black text-slate-900 dark:text-white">
                              {formatPrice(match.product.price)}
                            </span>

                            {isOutOfStock ? (
                              <button
                                id={`nearby-notify-me-btn-${match.product.id}`}
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openStockAlertModal(match.product);
                                }}
                                className={`px-3 py-1.5 text-xs font-bold rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer select-none ${
                                  isStockAlertSubscribed
                                    ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-700/60 hover:bg-emerald-100'
                                    : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-800 hover:shadow-md'
                                }`}
                                title={
                                  isStockAlertSubscribed
                                    ? 'Stock alert active — click to configure or test restock push'
                                    : 'Out of stock — click to get web push notification when restocked'
                                }
                              >
                                <Bell
                                  className={`w-3.5 h-3.5 ${
                                    isStockAlertSubscribed
                                      ? 'fill-emerald-500 text-emerald-500'
                                      : 'fill-slate-950 text-slate-800'
                                  }`}
                                />
                                <span>{isStockAlertSubscribed ? 'Alert Set' : 'Notify Me'}</span>
                              </button>
                            ) : (
                              (() => {
                                const isPopping = !!poppingNearbyIds[match.product.id];
                                return (
                                  <motion.button
                                    id={`express-buy-btn-${match.product.id}`}
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleExpressBuyNearby(match);
                                    }}
                                    whileTap={{ scale: 0.9 }}
                                    animate={
                                      isPopping
                                        ? {
                                            scale: [1, 1.22, 0.94, 1.08, 1],
                                            transition: { duration: 0.45, ease: [0.175, 0.885, 0.32, 1.275] },
                                          }
                                        : { scale: 1 }
                                    }
                                    className={`relative px-3 py-1.5 text-xs font-bold rounded-xl shadow-xs transition-colors duration-200 flex items-center gap-1.5 cursor-pointer overflow-hidden select-none ${
                                      isPopping
                                        ? 'bg-emerald-700 text-white ring-2 ring-emerald-400/60 shadow-emerald-600/30'
                                        : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs hover:shadow-md'
                                    }`}
                                  >
                                    <AnimatePresence mode="wait" initial={false}>
                                      {isPopping ? (
                                        <motion.span
                                          key="added"
                                          initial={{ opacity: 0, scale: 0.6, y: 2 }}
                                          animate={{ opacity: 1, scale: 1, y: 0 }}
                                          exit={{ opacity: 0, scale: 0.6, y: -2 }}
                                          transition={{ duration: 0.18 }}
                                          className="flex items-center gap-1 text-emerald-100"
                                        >
                                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                                          <span>Added!</span>
                                        </motion.span>
                                      ) : (
                                        <motion.span
                                          key="buy"
                                          initial={{ opacity: 0, scale: 0.8 }}
                                          animate={{ opacity: 1, scale: 1 }}
                                          exit={{ opacity: 0, scale: 0.8 }}
                                          transition={{ duration: 0.15 }}
                                          className="flex items-center gap-1"
                                        >
                                          <ShoppingBag className="w-3.5 h-3.5" />
                                          <span>Express Buy</span>
                                        </motion.span>
                                      )}
                                    </AnimatePresence>

                                    {/* Subtle ripple burst ping when popping */}
                                    {isPopping && (
                                      <motion.span
                                        initial={{ scale: 0.4, opacity: 0.8 }}
                                        animate={{ scale: 2.2, opacity: 0 }}
                                        transition={{ duration: 0.5, ease: 'easeOut' }}
                                        className="absolute inset-0 rounded-xl bg-emerald-400 pointer-events-none"
                                      />
                                    )}
                                  </motion.button>
                                );
                              })()
                            )}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </motion.div>
        )}
      </section>

      {/* 0.8. PERSONALIZED FOR YOU (Instagram, Meesho, Amazon & Flipkart Style) */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-rose-500 to-amber-500 text-white flex items-center justify-center shadow-md">
              <Heart className="w-5 h-5 fill-white text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 px-2 py-0.5 rounded-md">
                  Personalized Recommendation Engine
                </span>
                <span className="text-xs text-slate-500 font-semibold hidden sm:inline">
                  Double tap image to like & train your feed
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
                Recommended For You ❤️
              </h2>
            </div>
          </div>

          <button
            onClick={() => setIsInterestManagerOpen(true)}
            className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>Manage Likes & Hidden Items</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Products Grid / Skeletons */}
        {isLoadingHomepage ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {[1, 2, 3, 4].map((i) => (
              <ProductCardSkeleton key={i} />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {personalizedProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </section>

      {/* 1. Value Proposition Features Bar */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-4 p-5 sm:p-6 bg-slate-50 dark:bg-slate-800/60 rounded-3xl border border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-600 flex items-center justify-center flex-shrink-0">
            <Truck className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">Free Express Delivery</h4>
            <p className="text-[11px] text-slate-500">On all prepaid orders over ₹999</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center flex-shrink-0">
            <RotateCcw className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">7-Day Free Returns</h4>
            <p className="text-[11px] text-slate-500">Instant UPI & Bank refunds</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-blue-500/10 text-blue-600 flex items-center justify-center flex-shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">100% Authentic Quality</h4>
            <p className="text-[11px] text-slate-500">Handcrafted artisan standards</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-purple-500/10 text-purple-600 flex items-center justify-center flex-shrink-0">
            <Headphones className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">24/7 Antifly AI Concierge</h4>
            <p className="text-[11px] text-slate-500">Styling & size recommendations</p>
          </div>
        </div>
      </section>

      {/* 2. ZoloCoins Loyalty & Rewards Zone Bar with Visual Tier Progress */}
      <section className="p-5 sm:p-6 bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-500 rounded-3xl text-slate-800 shadow-lg border border-amber-300 flex flex-col lg:flex-row items-center justify-between gap-5 relative overflow-hidden">
        <div className="flex items-center gap-4 flex-1 w-full">
          <div className="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center border border-slate-200/10 shadow-inner flex-shrink-0">
            <Coins className="w-8 h-8 text-slate-800 fill-amber-300 animate-bounce" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-black uppercase tracking-wider bg-white text-amber-300 px-2 py-0.5 rounded-full">
                ⚡ Super Coins & Diamond Hub
              </span>
              <span className="text-xs font-black text-slate-900 bg-white/40 px-2.5 py-0.5 rounded-full">
                Balance: {superCoinsBalance} Coins (≈ ₹{superCoinsBalance})
              </span>
              <span className="text-[11px] font-black text-slate-800 bg-amber-300/80 px-2 py-0.5 rounded-full flex items-center gap-1 border border-amber-400">
                👑 Gold Member (1.5x Multiplier)
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-black text-slate-800 mt-1 leading-snug">
              Earn Super Coins on Every Purchase & Level Up to Diamond
            </h3>

            {/* Visual Level Progress Bar (Bronze -> Silver -> Gold -> Platinum -> Diamond) */}
            <div className="mt-3 bg-white/20 backdrop-blur-sm p-2.5 rounded-2xl border border-slate-200/15 max-w-xl">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-800 mb-1">
                <span className="flex items-center gap-1">
                  Current Level: <strong className="text-slate-800 underline font-black">Gold</strong>
                </span>
                {/* Tooltip trigger indicator */}
                <div className="relative group cursor-pointer inline-flex items-center gap-1 bg-white text-amber-300 text-[10px] font-black px-2 py-0.5 rounded-full shadow-sm">
                  <span>450 coins to reach Platinum</span>
                  <div className="absolute bottom-full mb-1.5 left-1/2 -translate-x-1/2 hidden group-hover:flex flex-col items-center z-30 pointer-events-none">
                    <div className="bg-white text-amber-300 text-[10px] font-extrabold px-2.5 py-1 rounded-lg shadow-xl whitespace-nowrap border border-amber-400/40">
                      ✨ 450 coins to reach Platinum Tier (2.0x Multiplier + VIP Priority)
                    </div>
                    <div className="w-2 h-2 bg-white rotate-45 -mt-1" />
                  </div>
                </div>
              </div>

              {/* Progress Track */}
              <div className="w-full h-2.5 bg-white/30 rounded-full overflow-hidden p-0.5">
                <div
                  className="h-full bg-gradient-to-r from-yellow-300 via-amber-200 to-white rounded-full transition-all duration-700 shadow-sm"
                  style={{ width: '78%' }}
                />
              </div>

              {/* Tier Marks */}
              <div className="flex items-center justify-between text-[9px] font-black uppercase text-slate-900 mt-1 px-1">
                <span className="opacity-70">Bronze</span>
                <span className="opacity-70">Silver</span>
                <span className="font-extrabold text-slate-800 bg-amber-400/60 px-1 rounded">● Gold</span>
                <span className="font-bold text-slate-800">Platinum</span>
                <span className="opacity-70">Diamond</span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex sm:flex-row flex-col items-center gap-2.5 w-full lg:w-auto flex-shrink-0">
          <button
            onClick={() => setIsSuperCoinsModalOpen(true)}
            className="w-full sm:w-auto px-5 py-3 bg-white hover:bg-slate-900 text-amber-300 font-black text-xs rounded-2xl shadow-lg transition flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer hover:scale-102 active:scale-98"
          >
            <Gift className="w-4 h-4" />
            Explore Coin & Diamond Hub
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </section>

      {/* 2.5. TIME-SHIFT 3D LIVING STORIES (2-Hour Ephemeral Spatial Feed) */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-violet-600 via-fuchsia-600 to-amber-500 text-white flex items-center justify-center shadow-lg shadow-fuchsia-500/20">
              <Layers className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white px-2.5 py-0.5 rounded-full shadow-xs flex items-center gap-1">
                  <Radio className="w-3 h-3 animate-ping" />
                  Time-Shift 3D Stories
                </span>
                <span className="text-xs text-fuchsia-600 dark:text-fuchsia-400 font-extrabold flex items-center gap-1">
                  <Hourglass className="w-3.5 h-3.5" />
                  2-Hour Auto Expiring Living Media
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-0.5">
                Living Stories & Spatial Product Drops
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={openTimeShiftCamera}
              className="px-4 py-2.5 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white font-extrabold text-xs rounded-2xl shadow-md transition flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <Camera className="w-4 h-4" />
              <span>Create 3D Story</span>
            </button>
          </div>
        </div>

        {/* Stories Horizontal Tray */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3.5">
          {/* Create Story Action Card */}
          <div
            onClick={openTimeShiftCamera}
            className="group relative rounded-3xl overflow-hidden border-2 border-dashed border-fuchsia-400/60 dark:border-fuchsia-500/40 bg-gradient-to-b from-fuchsia-50/50 to-violet-50/50 dark:from-slate-900 dark:to-slate-950 p-4 flex flex-col items-center justify-center text-center cursor-pointer hover:border-fuchsia-500 hover:shadow-xl transition-all duration-300 min-h-[260px]"
          >
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-violet-600 to-fuchsia-600 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform mb-3">
              <Plus className="w-7 h-7" />
            </div>
            <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">
              Your Living Story
            </h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 max-w-[130px] leading-tight">
              Record 15s clip, auto-tag items & set 2h expiration
            </p>
            <span className="mt-3 inline-flex items-center gap-1 text-[10px] font-black uppercase text-fuchsia-600 dark:text-fuchsia-400 bg-fuchsia-100 dark:bg-fuchsia-950/60 px-2 py-0.5 rounded-full">
              <Sparkles className="w-3 h-3" />
              AI 3D Tagging
            </span>
          </div>

          {/* Active Time-Shift Stories */}
          {timeShiftStories.map((story) => {
            const expiresAtMs = new Date(story.expiresAt).getTime();
            const minutesLeft = Math.max(
              1,
              Math.floor((expiresAtMs - Date.now()) / (1000 * 60))
            );
            const isUrgent = minutesLeft <= 30;

            return (
              <div
                key={story.id}
                onClick={() => openTimeShiftStoryViewer(story)}
                className="group relative rounded-3xl overflow-hidden bg-white border border-slate-200 dark:border-slate-800 shadow-md hover:shadow-2xl hover:border-fuchsia-400 transition-all duration-300 flex flex-col justify-between cursor-pointer min-h-[260px]"
              >
                {/* Media Image / Background */}
                <img
                  src={story.mediaUrl}
                  alt={story.authorName}
                  className="absolute inset-0 w-full h-full object-cover group-hover:scale-108 transition-transform duration-700 opacity-80"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent" />

                {/* Top Expiration & 3D Badges */}
                <div className="relative z-10 p-3 flex items-center justify-between">
                  <span
                    className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full flex items-center gap-1 shadow-md ${
                      isUrgent
                        ? 'bg-rose-600 text-white animate-pulse'
                        : 'bg-white/80 backdrop-blur-md text-amber-300 border border-amber-400/30'
                    }`}
                  >
                    <Hourglass className="w-3 h-3" />
                    {minutesLeft}m left
                  </span>

                  <span className="text-[10px] font-black uppercase bg-violet-600/90 text-white px-2 py-0.5 rounded-md shadow-xs">
                    3D
                  </span>
                </div>

                {/* Center Secret Reward or Multi-Contributor Tag if available */}
                <div className="relative z-10 px-3 flex flex-col gap-1 items-start">
                  {story.secretLayerUnlockedCount > 0 && (
                    <span className="bg-amber-400 text-slate-800 text-[10px] font-black px-2 py-0.5 rounded-full shadow-sm flex items-center gap-1">
                      <Gift className="w-3 h-3" /> Mystery Code
                    </span>
                  )}
                  {story.multiContributors && story.multiContributors.length > 1 && (
                    <span className="bg-fuchsia-600/90 backdrop-blur-md text-white text-[10px] font-extrabold px-2 py-0.5 rounded-full">
                      👥 {story.multiContributors.length} Creators
                    </span>
                  )}
                </div>

                {/* Bottom Creator Info & Live Pulse */}
                <div className="relative z-10 p-3.5 space-y-1.5 text-white">
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <img
                        src={story.authorAvatar}
                        alt={story.authorName}
                        className="w-7 h-7 rounded-full object-cover ring-2 ring-fuchsia-400"
                      />
                      <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-1 ring-slate-200" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-white truncate leading-tight">
                        {story.authorName}
                      </p>
                      <p className="text-[10px] text-fuchsia-300 truncate">
                        {story.authorRole}
                      </p>
                    </div>
                  </div>

                  <p className="text-[11px] font-extrabold text-slate-100 line-clamp-1">
                    {story.storyDna}
                  </p>

                  <div className="pt-1.5 border-t border-white/20 flex items-center justify-between text-[10px] text-slate-300">
                    <span className="flex items-center gap-1">
                      <ShoppingBag className="w-3 h-3 text-amber-300" />
                      {(story.interactiveObjects || []).length} Tap Items
                    </span>
                    <span className="font-bold text-fuchsia-300 group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
                      Open 3D <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. AntiflyStyle Creator Lookbook */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-pink-500 to-rose-500 text-white flex items-center justify-center shadow-md">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-pink-100 dark:bg-pink-950 text-pink-700 dark:text-pink-300 px-2 py-0.5 rounded-md">
                  AntiflyStyle Runway & Lookbook
                </span>
                <span className="text-xs text-stone-500 font-semibold">Influencer Outfit Styling</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-stone-900 dark:text-white">
                Shop Trending Looks & Outfits
              </h2>
            </div>
          </div>

          <button
            onClick={() => setIsStyleCastModalOpen(true)}
            className="text-xs font-bold text-pink-600 dark:text-pink-400 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>Open AntiflyStyle</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {isLoadingHomepage ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <LookbookCardSkeleton key={i} />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {styleCastLooks.map((look) => (
              <div
                key={look.id}
                onClick={() => {
                  setActiveStyleLook(look);
                  setIsStyleCastModalOpen(true);
                }}
                className="group cursor-pointer rounded-3xl overflow-hidden border border-stone-200 dark:border-slate-800 bg-stone-950 relative shadow-md hover:shadow-xl transition-all flex flex-col justify-between h-[360px]"
              >
                <img
                  src={look.coverImage}
                  alt={look.title}
                  className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-85"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent" />

                {/* Top pill */}
                <div className="relative z-10 p-3 flex justify-between items-center">
                  <span className="px-2.5 py-1 rounded-full bg-slate-100/60 backdrop-blur-md text-[10px] font-extrabold text-pink-300 border border-pink-500/30">
                    ✨ {look.occasion}
                  </span>
                  <span className="px-2 py-1 rounded-full bg-rose-600/90 text-white text-[10px] font-black shadow-sm">
                    {look.bundleDiscountPercentage}% Bundle OFF
                  </span>
                </div>

                {/* Bottom Creator Info */}
                <div className="relative z-10 p-4 space-y-2 text-white">
                  <div className="flex items-center gap-2">
                    <img
                      src={look.influencerAvatar}
                      alt={look.influencerName}
                      className="w-7 h-7 rounded-full border border-pink-400 object-cover"
                    />
                    <div>
                      <p className="text-xs font-bold text-white">{look.influencerName}</p>
                      <p className="text-[10px] text-pink-300">{look.influencerHandle}</p>
                    </div>
                  </div>

                  <h4 className="font-extrabold text-xs text-white line-clamp-2 leading-snug">
                    {look.title}
                  </h4>

                  <div className="pt-2 border-t border-white/20 flex items-center justify-between">
                    <span className="text-[11px] text-stone-300 font-semibold flex items-center gap-1">
                      <ShoppingBag className="w-3.5 h-3.5 text-pink-400" />
                      {look.taggedProductIds.length} Items Tagged
                    </span>
                    <span className="text-xs font-extrabold text-pink-400 group-hover:translate-x-1 transition-transform flex items-center gap-0.5">
                      Shop Look <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* 3.5. Wise Super-App 4-in-1 Lifestyle Services Ecosystem */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-orange-500 to-indigo-600 text-white px-2.5 py-0.5 rounded-full shadow-xs">
                Wise Super-App Ecosystem
              </span>
              <span className="text-xs text-slate-500 font-semibold hidden sm:inline">
                Food • Entertainment • VIP Pass • Card Rewards
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
              One App for Everything You Need
            </h2>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: AntiflyBites Food Delivery */}
          <div
            onClick={() => setIsFoodDeliveryModalOpen(true)}
            className="group relative overflow-hidden rounded-3xl p-5 bg-gradient-to-br from-orange-500 to-amber-600 text-white shadow-lg cursor-pointer hover:shadow-orange-500/30 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between h-56"
          >
            <div className="space-y-1.5 z-10">
              <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center">
                <UtensilsCrossed className="w-5 h-5 text-white" />
              </div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-full inline-block">
                ⚡ 25 Min Delivery
              </span>
              <h3 className="text-lg font-black leading-tight">
                AntiflyBites Food Delivery
              </h3>
              <p className="text-xs text-orange-100 line-clamp-2">
                Order hot biryani, burgers, pizzas & North Indian feasts from top cloud kitchens.
              </p>
            </div>
            <div className="flex items-center justify-between z-10 pt-2 border-t border-white/20">
              <span className="text-xs font-bold text-amber-200">50% Off First 3 Orders</span>
              <span className="text-xs font-black bg-white text-orange-600 px-2.5 py-1 rounded-xl group-hover:scale-105 transition-transform flex items-center gap-1">
                Order Now <ArrowRight className="w-3 h-3" />
              </span>
            </div>
            <div className="absolute -right-6 -bottom-6 w-28 h-28 bg-white/10 rounded-full blur-xl pointer-events-none" />
          </div>

          {/* Card 2: AntiflyOne VIP All-in-One Subscription */}
          <div
            onClick={() => setIsAntiflyOneModalOpen(true)}
            className="group relative overflow-hidden rounded-3xl p-5 bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950 text-white border border-amber-500/30 shadow-lg cursor-pointer hover:shadow-amber-500/20 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between h-56"
          >
            <div className="space-y-1.5 z-10">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center">
                <Crown className="w-5 h-5 fill-amber-400" />
              </div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded-full inline-block">
                👑 All-in-One VIP Pass
              </span>
              <h3 className="text-lg font-black leading-tight text-amber-300">
                AntiflyOne Membership
              </h3>
              <p className="text-xs text-slate-300 line-clamp-2">
                Free Express Delivery, unlimited OTT stream, 0₹ food delivery fee & 2X coins.
              </p>
            </div>
            <div className="flex items-center justify-between z-10 pt-2 border-t border-slate-800">
              <span className="text-xs font-bold text-amber-400">Plans from ₹149/mo</span>
              <span className="text-xs font-black bg-gradient-to-r from-amber-400 to-amber-500 text-slate-800 px-2.5 py-1 rounded-xl group-hover:scale-105 transition-transform flex items-center gap-1">
                {antiflyOneSubscription.isActive ? 'Active VIP' : 'Join VIP'} <ArrowRight className="w-3 h-3" />
              </span>
            </div>
            <div className="absolute -right-6 -bottom-6 w-28 h-28 bg-amber-500/10 rounded-full blur-xl pointer-events-none" />
          </div>

          {/* Card 3: All Bank Credit Cards & EMI Hub */}
          <div
            onClick={() => setIsBankOffersModalOpen(true)}
            className="group relative overflow-hidden rounded-3xl p-5 bg-gradient-to-br from-sky-600 via-blue-700 to-indigo-800 text-white shadow-lg cursor-pointer hover:shadow-sky-500/30 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between h-56"
          >
            <div className="space-y-1.5 z-10">
              <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-white" />
              </div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-full inline-block">
                💳 All Indian Banks
              </span>
              <h3 className="text-lg font-black leading-tight">
                Bank Offers & 0% EMI
              </h3>
              <p className="text-xs text-sky-100 line-clamp-2">
                Instant 10% Off with HDFC, ICICI, SBI, Axis, Kotak, BOB, & Federal bank cards.
              </p>
            </div>
            <div className="flex items-center justify-between z-10 pt-2 border-t border-white/20">
              <span className="text-xs font-bold text-sky-200">No-Cost EMI up to 12m</span>
              <span className="text-xs font-black bg-white text-sky-700 px-2.5 py-1 rounded-xl group-hover:scale-105 transition-transform flex items-center gap-1">
                View Cards <ArrowRight className="w-3 h-3" />
              </span>
            </div>
            <div className="absolute -right-6 -bottom-6 w-28 h-28 bg-sky-400/20 rounded-full blur-xl pointer-events-none" />
          </div>

          {/* Card 4: AntiflyStream OTT Platform */}
          <div
            onClick={() => setIsOTTModalOpen(true)}
            className="group relative overflow-hidden rounded-3xl p-5 bg-gradient-to-br from-purple-700 via-pink-600 to-rose-700 text-white shadow-lg cursor-pointer hover:shadow-pink-500/30 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between h-56"
          >
            <div className="space-y-1.5 z-10">
              <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center">
                <Tv className="w-5 h-5 text-white" />
              </div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-full inline-block">
                🎬 AntiflyStream OTT Hub
              </span>
              <h3 className="text-lg font-black leading-tight">
                Movies, Shows & Live Sports
              </h3>
              <p className="text-xs text-pink-100 line-clamp-2">
                Watch 4K blockbusters, web originals, live cricket T20 streaming & anime series.
              </p>
            </div>
            <div className="flex items-center justify-between z-10 pt-2 border-t border-white/20">
              <span className="text-xs font-bold text-pink-200">Free with AntiflyOne</span>
              <span className="text-xs font-black bg-white text-pink-700 px-2.5 py-1 rounded-xl group-hover:scale-105 transition-transform flex items-center gap-1">
                Watch Now <ArrowRight className="w-3 h-3" />
              </span>
            </div>
            <div className="absolute -right-6 -bottom-6 w-28 h-28 bg-pink-400/20 rounded-full blur-xl pointer-events-none" />
          </div>
        </div>
      </section>

      {/* 4. WiseSquad Community Group Buy Deals */}
      <section className="p-6 sm:p-8 bg-gradient-to-br from-rose-50 via-pink-50 to-amber-50 dark:from-rose-950/30 dark:to-slate-900 rounded-3xl border border-rose-200 dark:border-rose-900/40 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-rose-600 text-white flex items-center justify-center shadow-lg">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-rose-600 text-white px-2 py-0.5 rounded-full">
                  WiseSquad Group Buy
                </span>
                <span className="text-xs text-rose-700 dark:text-rose-300 font-bold">2-Person Buying Teams</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-stone-900 dark:text-white">
                Team Up with Shoppers & Unlock Wholesale Discounts
              </h3>
            </div>
          </div>

          <button
            onClick={() => setIsGroupBuyModalOpen(true)}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition self-start sm:self-auto cursor-pointer"
          >
            View All Open Teams
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {groupBuyDeals.map((deal) => (
            <div
              key={deal.id}
              className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-rose-200 dark:border-slate-700 shadow-sm flex flex-col justify-between space-y-3"
            >
              <div className="flex gap-3">
                <img
                  src={deal.productImage}
                  alt={deal.productName}
                  className="w-16 h-16 rounded-xl object-cover flex-shrink-0"
                />
                <div className="min-w-0">
                  <span className="text-[10px] font-extrabold text-rose-600 uppercase">{deal.groupCode}</span>
                  <h4 className="font-bold text-xs text-stone-900 dark:text-white truncate mt-0.5">
                    {deal.productName}
                  </h4>
                  <div className="flex items-baseline gap-1.5 mt-1">
                    <span className="font-black text-sm text-rose-600">{formatPrice(deal.groupPrice)}</span>
                    <span className="text-xs text-stone-400 line-through">{formatPrice(deal.originalPrice)}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-stone-100 dark:border-slate-700 text-xs">
                <span className="font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded">
                  Save {formatPrice(deal.savings)}
                </span>
                <button
                  onClick={() => joinGroupBuy(deal.id)}
                  className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs shadow-sm transition cursor-pointer"
                >
                  Join Team
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 2. Categories Circular Visual Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white">
              Shop by Department
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">Explore our artisan curated categories</p>
          </div>
          <button
            onClick={onViewCatalog}
            className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {isLoadingHomepage ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 sm:gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <CategorySkeleton key={i} />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 sm:gap-4">
            {categories.map((cat) => (
              <div
                key={cat.id}
                onClick={() => onSelectCategory(cat.slug)}
                className="group cursor-pointer p-3 sm:p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 hover:border-amber-500 hover:shadow-xl transition-all flex flex-col items-center text-center"
              >
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden mb-3 group-hover:scale-105 transition-transform">
                  <img
                    src={cat.image}
                    alt={cat.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white group-hover:text-amber-600 transition-colors">
                  {cat.name}
                </h3>
                <p className="text-[10px] text-slate-500 mt-0.5">{cat.itemCount}+ Products</p>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* 3. Flash Sale / Deals of the Day with Live Countdown */}
      <section className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-amber-500/10 via-orange-500/5 to-rose-500/10 border border-amber-500/30 space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 text-slate-800 flex items-center justify-center font-black">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
                  Limited Flash Deals
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-rose-600 text-white font-black text-[10px] uppercase animate-pulse">
                  Up to 45% Off
                </span>
              </div>
              <p className="text-xs text-slate-500">Handcrafted pieces at unbeatable festival prices</p>
            </div>
          </div>

          {/* Countdown Clock */}
          <div className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-2xl font-mono text-xs shadow-md">
            <Clock className="w-4 h-4 text-amber-400 animate-spin" />
            <span className="font-semibold text-slate-300">Ends in:</span>
            <span className="bg-slate-800 px-2 py-1 rounded font-bold text-amber-400">
              {String(timeLeft.hours).padStart(2, '0')}h
            </span>
            <span>:</span>
            <span className="bg-slate-800 px-2 py-1 rounded font-bold text-amber-400">
              {String(timeLeft.minutes).padStart(2, '0')}m
            </span>
            <span>:</span>
            <span className="bg-slate-800 px-2 py-1 rounded font-bold text-amber-400">
              {String(timeLeft.seconds).padStart(2, '0')}s
            </span>
          </div>
        </div>

        {/* Product Cards */}
        {isLoadingHomepage ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {[1, 2, 3, 4].map((i) => (
              <ProductCardSkeleton key={i} />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {flashSaleProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </section>

      {/* 4. Trending & Best-Selling Spotlight */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-amber-500" />
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Trending Modern Indian Wear
            </h2>
          </div>
          <button
            onClick={onViewCatalog}
            className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>Explore All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {isLoadingHomepage ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {[1, 2, 3, 4].map((i) => (
              <ProductCardSkeleton key={i} />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {trendingProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </section>

      {/* 5. Antifly AI Stylist Interactive Banner */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950 text-white p-6 sm:p-10 border border-slate-800 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-3 max-w-xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold border border-amber-500/30">
            <Sparkles className="w-3.5 h-3.5 animate-spin" />
            <span>Powered by Gemini 3.7 Flash</span>
          </div>
          <h3 className="text-2xl sm:text-3xl font-extrabold">
            Can't decide what to wear for Diwali, Weddings or Work?
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Chat with <strong>Antifly AI Stylist</strong>. Ask in English, Hindi, or Hinglish ("Kurta for sangeet under 2500"), and get tailored product pairings instantly.
          </p>
          <div className="pt-2">
            <button
              onClick={() => setIsAntiflyAIOpen(true)}
              className="bg-amber-500 hover:bg-amber-400 text-slate-800 font-bold px-6 py-3 rounded-xl text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-amber-500/20 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Launch AntiflyAI Assistant</span>
            </button>
          </div>
        </div>

        <div className="w-full md:w-72 bg-slate-800/80 backdrop-blur-md rounded-2xl p-4 border border-slate-700 space-y-2 text-xs">
          <div className="flex items-center gap-2 text-amber-400 font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Sample Prompts</span>
          </div>
          <div
            onClick={() => setIsAntiflyAIOpen(true)}
            className="p-2.5 bg-slate-900/80 rounded-xl cursor-pointer hover:bg-slate-900 text-slate-300 border border-slate-700"
          >
            💬 "Show me beige linen shirts for summer under ₹2,000"
          </div>
          <div
            onClick={() => setIsAntiflyAIOpen(true)}
            className="p-2.5 bg-slate-900/80 rounded-xl cursor-pointer hover:bg-slate-900 text-slate-300 border border-slate-700"
          >
            💬 "Wedding footwear that matches my silk Nehru jacket"
          </div>
        </div>
      </section>

      {/* 6. New Arrivals Collection */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-500" />
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Fresh New Arrivals
            </h2>
          </div>
          <button
            onClick={onViewCatalog}
            className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {isLoadingHomepage ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {[1, 2, 3, 4].map((i) => (
              <ProductCardSkeleton key={i} />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {newArrivals.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </section>

      {/* 7. Customer Reviews & Community Trust */}
      <section className="p-6 sm:p-8 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-6">
        <div className="text-center max-w-xl mx-auto space-y-1">
          <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
            Loved by 45,000+ Patrons Across India
          </h3>
          <p className="text-xs text-slate-500">
            Real verified reviews from Mumbai, Delhi, Bengaluru, Pune, and Jaipur.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
            <div className="flex items-center gap-1 text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400" />
              ))}
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 italic">
              "The linen quality is unmatched at this price point. Breathable, perfectly stitched, and got delivered to Bangalore within 48 hours."
            </p>
            <div className="pt-2 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-900 dark:text-white">Rohan Deshmukh</span>
              <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1">
                <CheckCircle className="w-3 h-3" /> Verified Buyer
              </span>
            </div>
          </div>

          <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
            <div className="flex items-center gap-1 text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400" />
              ))}
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 italic">
              "AntiflyAI helped me choose the exact matching mojari footwear for my sangeet kurta. Super accurate sizing chart too!"
            </p>
            <div className="pt-2 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-900 dark:text-white">Pooja Singhania</span>
              <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1">
                <CheckCircle className="w-3 h-3" /> Verified Buyer
              </span>
            </div>
          </div>

          <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
            <div className="flex items-center gap-1 text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400" />
              ))}
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 italic">
              "Seamless exchange when I needed one size larger. Courier picked it up right from my doorstep in Gurgaon without questions."
            </p>
            <div className="pt-2 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-900 dark:text-white">Vikramaditya S.</span>
              <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1">
                <CheckCircle className="w-3 h-3" /> Verified Buyer
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* 8. Verified Artisans & Seller Storefront Showcase */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Store className="w-5 h-5 text-amber-600" />
            <div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
                Verified Artisans & Seller Studios
              </h2>
              <p className="text-xs text-slate-500">
                Follow master weavers, view their latest product photos & portfolios
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsSavePortfolioOpen(true)}
            className="self-start sm:self-auto flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200 text-xs font-bold rounded-xl hover:bg-amber-100 transition shadow-2xs cursor-pointer"
          >
            <Bookmark className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
            <span>Open Saved Portfolio</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {sellers.slice(0, 4).map((seller) => {
            const isFollowing = isFollowingSeller(seller.id);
            const latestPost = seller.posts && seller.posts.length > 0 ? seller.posts[0] : null;

            return (
              <div
                key={seller.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-md hover:border-amber-400/60 transition-all flex flex-col justify-between"
              >
                {/* Banner & Logo */}
                <div className="relative h-24 bg-gradient-to-r from-amber-500/20 to-orange-500/20">
                  {seller.bannerImage ? (
                    <img
                      src={seller.bannerImage}
                      alt={seller.storeName}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-slate-100 dark:bg-slate-800" />
                  )}

                  <div className="absolute -bottom-4 left-4 w-12 h-12 rounded-2xl bg-white dark:bg-slate-900 p-1 border border-slate-200 dark:border-slate-700 shadow-md">
                    <img
                      src={seller.logo}
                      alt={seller.storeName}
                      className="w-full h-full object-cover rounded-xl"
                    />
                  </div>
                </div>

                <div className="p-4 pt-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-1">
                      <div>
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1">
                          <span>{seller.storeName}</span>
                          {seller.isVerified && (
                            <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                          )}
                        </h4>
                        <p className="text-[11px] text-slate-500">
                          {seller.city}, {seller.state} &bull; {seller.followerCount} followers
                        </p>
                      </div>

                      <button
                        onClick={() => toggleFollowSeller(seller.id)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition-all cursor-pointer ${
                          isFollowing
                            ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200'
                            : 'bg-orange-600 text-white hover:bg-orange-700 shadow-2xs'
                        }`}
                      >
                        {isFollowing ? (
                          <>
                            <UserCheck className="w-3 h-3" />
                            <span>Following</span>
                          </>
                        ) : (
                          <>
                            <UserPlus className="w-3 h-3" />
                            <span>Follow</span>
                          </>
                        )}
                      </button>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 line-clamp-2">
                      {seller.bio}
                    </p>

                    {/* Latest Post Image Preview */}
                    {latestPost && (
                      <div
                        onClick={() => openSellerStorefront(seller.id)}
                        className="mt-3 relative rounded-xl overflow-hidden cursor-pointer border border-slate-100 dark:border-slate-800 group"
                      >
                        <img
                          src={latestPost.image}
                          alt={latestPost.caption}
                          className="w-full h-24 object-cover group-hover:scale-105 transition duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-100/70 via-transparent to-transparent flex items-end p-2">
                          <p className="text-[10px] text-white font-medium line-clamp-1">
                            📸 {latestPost.caption}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <span className="text-[11px] font-bold text-amber-700 dark:text-amber-400">
                      {seller.productIds?.length || 8} Handcrafted Products
                    </span>

                    <button
                      onClick={() => openSellerStorefront(seller.id)}
                      className="text-xs font-bold text-slate-900 dark:text-white hover:text-orange-600 flex items-center gap-1 cursor-pointer"
                    >
                      <span>Visit Studio</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 9. App Download Banner Simulation */}
      <section className="p-6 sm:p-8 rounded-3xl bg-slate-900 text-white flex flex-col sm:flex-row items-center justify-between gap-6 border border-slate-800 shadow-xl">
        <div className="space-y-2 max-w-md">
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
            <Smartphone className="w-4 h-4" />
            <span>Omnichannel Mobile Experience</span>
          </div>
          <h3 className="text-2xl font-extrabold">Shop Smarter with Antifly App</h3>
          <p className="text-xs text-slate-300">
            Get exclusive app-only coupons (e.g. <strong>APPEXCLUSIVE15</strong>), real-time push notifications, and visual camera search on Android & iOS.
          </p>
        </div>

        <div className="flex flex-wrap gap-3">
          <button
            onClick={() => setDeviceMode('mobile-android')}
            className="bg-white/10 hover:bg-white/20 border border-white/20 px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer"
          >
            <span>📱 Preview Android App</span>
          </button>
          <button
            onClick={() => setDeviceMode('mobile-ios')}
            className="bg-amber-500 hover:bg-amber-400 text-slate-800 px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer"
          >
            <span>🍏 Preview iOS App</span>
          </button>
        </div>
      </section>
    </div>
  );
};
