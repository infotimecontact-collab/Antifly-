import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../common/ProductCard';
import {
  Filter,
  SlidersHorizontal,
  X,
  Search,
  Check,
  ChevronDown,
  Sparkles,
  Layers,
  ArrowUpDown,
} from 'lucide-react';

interface WebsiteCatalogProps {
  onBackToHome: () => void;
}

export const WebsiteCatalog: React.FC<WebsiteCatalogProps> = ({ onBackToHome }) => {
  const {
    products,
    categories,
    selectedCategorySlug,
    setSelectedCategorySlug,
    searchQuery,
    setSearchQuery,
    appliedFilters,
    setAppliedFilters,
    setIsAntiflyAIOpen,
  } = useApp();

  const [isFilterDrawerOpen, setIsFilterDrawerOpen] = useState(false);
  const [priceRange, setPriceRange] = useState<number>(appliedFilters.maxPrice || 10000);
  const [selectedRating, setSelectedRating] = useState<number>(0);
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [selectedTag, setSelectedTag] = useState<string>('');

  // Available unique colors & tags from products
  const allColors = Array.from(
    new Set(products.flatMap((p) => p.colors.map((c) => c.name)))
  );
  const allTags = Array.from(new Set(products.flatMap((p) => p.tags)));

  // Filter products based on all conditions
  const filteredProducts = products.filter((product) => {
    // Category match
    if (selectedCategorySlug && selectedCategorySlug !== 'all') {
      const matchCat =
        product.category.toLowerCase() === selectedCategorySlug.toLowerCase() ||
        product.subcategory.toLowerCase() === selectedCategorySlug.toLowerCase();
      if (!matchCat) return false;
    }

    // Search query match
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = product.name.toLowerCase().includes(q);
      const matchBrand = product.brand.toLowerCase().includes(q);
      const matchDesc = product.description.toLowerCase().includes(q);
      const matchTag = product.tags.some((t) => t.toLowerCase().includes(q));
      const matchKeyword = product.searchKeywords.some((k) => k.toLowerCase().includes(q));
      if (!matchName && !matchBrand && !matchDesc && !matchTag && !matchKeyword) return false;
    }

    // Price range match
    if (product.price > priceRange) return false;

    // Rating match
    if (selectedRating > 0 && product.rating < selectedRating) return false;

    // Color match
    if (selectedColor && !product.colors.some((c) => c.name === selectedColor)) return false;

    // Tag match
    if (selectedTag && !product.tags.includes(selectedTag)) return false;

    return true;
  });

  // Sort filtered list
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (appliedFilters.sortBy) {
      case 'price-low':
        return a.price - b.price;
      case 'price-high':
        return b.price - a.price;
      case 'rating':
        return b.rating - a.rating;
      case 'discount':
        return b.discountPercentage - a.discountPercentage;
      case 'newest':
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      default:
        return 0;
    }
  });

  const clearAllFilters = () => {
    setSelectedCategorySlug('all');
    setSearchQuery('');
    setPriceRange(10000);
    setSelectedRating(0);
    setSelectedColor('');
    setSelectedTag('');
    setAppliedFilters({ sortBy: 'featured' });
  };

  const activeFiltersCount =
    (selectedCategorySlug !== 'all' ? 1 : 0) +
    (searchQuery ? 1 : 0) +
    (priceRange < 10000 ? 1 : 0) +
    (selectedRating > 0 ? 1 : 0) +
    (selectedColor ? 1 : 0) +
    (selectedTag ? 1 : 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header breadcrumb & info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <button onClick={onBackToHome} className="hover:text-amber-600">
              Home
            </button>
            <span>/</span>
            <span className="font-semibold text-slate-900 dark:text-white capitalize">
              {selectedCategorySlug === 'all' ? 'All Collections' : selectedCategorySlug}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            {selectedCategorySlug === 'all'
              ? searchQuery
                ? `Search Results for "${searchQuery}"`
                : 'Explore All Collections'
              : categories.find((c) => c.slug === selectedCategorySlug)?.name || selectedCategorySlug}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Showing {sortedProducts.length} handcrafted artisan items
          </p>
        </div>

        {/* Sort & Mobile Filter Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsFilterDrawerOpen(!isFilterDrawerOpen)}
            className="md:hidden flex items-center gap-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-800 dark:text-white"
          >
            <Filter className="w-4 h-4" />
            <span>Filters</span>
            {activeFiltersCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-amber-500 text-slate-800 font-bold text-[10px] flex items-center justify-center">
                {activeFiltersCount}
              </span>
            )}
          </button>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 px-3 py-1.5 rounded-xl text-xs">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-slate-500 font-medium">Sort:</span>
            <select
              value={appliedFilters.sortBy || 'featured'}
              onChange={(e) =>
                setAppliedFilters((prev) => ({ ...prev, sortBy: e.target.value }))
              }
              className="bg-transparent font-bold text-slate-900 dark:text-white focus:outline-none cursor-pointer"
            >
              <option value="featured">Featured & Trending</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="rating">Customer Rating</option>
              <option value="discount">Biggest Discount</option>
              <option value="newest">Newest First</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Grid: Sidebar Filters + Products List */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Sidebar Filters (Desktop & Mobile) - Styled to match Figma Reference Images 1 & 4 */}
        <aside
          className={`space-y-5 md:block ${
            isFilterDrawerOpen ? 'block' : 'hidden'
          } p-5 bg-[#f6f3ee] rounded-3xl border border-[#e5dfd5] shadow-sm h-fit text-slate-800`}
        >
          {/* Avatar & Status Header (Image 1 & 4) */}
          <div className="flex items-center justify-between pb-3 border-b border-[#e2ddd4]">
            <div className="flex items-center gap-2.5">
              <div className="relative">
                <div className="w-8 h-8 rounded-full bg-slate-800 text-white font-bold text-xs flex items-center justify-center border-2 border-white shadow-xs">
                  Z
                </div>
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border border-white" />
              </div>
              <div>
                <h4 className="text-xs font-extrabold text-slate-900 tracking-tight">
                  Studio Catalog
                </h4>
                <p className="text-[10px] text-slate-500 font-medium flex items-center gap-1">
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  online filters
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              {activeFiltersCount > 0 && (
                <button
                  onClick={clearAllFilters}
                  className="text-[11px] font-bold text-rose-600 hover:underline mr-1"
                >
                  Reset
                </button>
              )}
              <div className="p-1 rounded-lg bg-[#eae4da] text-slate-700">
                <SlidersHorizontal className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          {/* Recessed Category Input / Pill (Image 1 & 4) */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
              Category
            </label>
            <div className="relative flex items-center">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search category or price..."
                className="w-full pl-3.5 pr-9 py-2 bg-[#ece7de] border border-[#ded8cd] rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-slate-400 shadow-inner"
              />
              <button
                type="button"
                className="absolute right-1.5 w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs hover:bg-slate-800 transition"
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Department / Category Pill List */}
          <div className="space-y-1.5 pt-2 border-t border-[#e2ddd4]">
            <h4 className="font-bold text-[11px] uppercase tracking-wider text-slate-500">
              Departments
            </h4>
            <div className="space-y-1 text-xs">
              <button
                onClick={() => setSelectedCategorySlug('all')}
                className={`w-full text-left px-3 py-1.5 rounded-xl font-semibold transition-all flex items-center justify-between ${
                  selectedCategorySlug === 'all'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-700 hover:bg-[#eae4da]'
                }`}
              >
                <span>All Departments</span>
                <span className="text-[10px] opacity-70">({products.length})</span>
              </button>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategorySlug(cat.slug)}
                  className={`w-full text-left px-3 py-1.5 rounded-xl font-semibold flex items-center justify-between transition-all ${
                    selectedCategorySlug === cat.slug
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-700 hover:bg-[#eae4da]'
                  }`}
                >
                  <span>{cat.name}</span>
                  <span className="text-[10px] opacity-70">({cat.itemCount})</span>
                </button>
              ))}
            </div>
          </div>

          {/* Brand Filter with 3D Circular Radio & "+98 more" (Image 1 & 4) */}
          <div className="space-y-2 pt-2 border-t border-[#e2ddd4]">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-[11px] uppercase tracking-wider text-slate-500">
                Brand & Label
              </h4>
              <span className="text-[11px] font-bold text-blue-600 hover:underline cursor-pointer">
                +98 more
              </span>
            </div>
            <div className="space-y-1.5">
              {['Antifly Atelier', 'Royal Heritage', 'Vedic Weaves', 'Urban Khadi'].map((brand) => {
                const isSelected = searchQuery.toLowerCase().includes(brand.toLowerCase());
                return (
                  <label
                    key={brand}
                    onClick={() => setSearchQuery(isSelected ? '' : brand)}
                    className="flex items-center gap-2.5 text-xs text-slate-700 font-medium cursor-pointer hover:text-slate-800 py-0.5"
                  >
                    <span
                      className={`tactile-radio-circle ${
                        isSelected ? 'active text-white' : ''
                      }`}
                    >
                      {isSelected && <Check className="w-2.5 h-2.5 text-white stroke-[3]" />}
                    </span>
                    <span>{brand}</span>
                  </label>
                );
              })}
            </div>
          </div>

          {/* Price Range Slider (Tactile Inset) */}
          <div className="space-y-2 pt-2 border-t border-[#e2ddd4]">
            <div className="flex justify-between items-center text-xs">
              <h4 className="font-bold uppercase tracking-wider text-slate-500 text-[11px]">
                Price Filter
              </h4>
              <span className="font-bold font-mono text-slate-900 bg-[#ece7de] px-2 py-0.5 rounded-lg border border-[#ded8cd]">
                ₹{priceRange.toLocaleString('en-IN')}
              </span>
            </div>
            <input
              type="range"
              min={500}
              max={10000}
              step={200}
              value={priceRange}
              onChange={(e) => setPriceRange(Number(e.target.value))}
              className="w-full accent-slate-900 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>₹500</span>
              <span>₹5,000</span>
              <span>₹10,000</span>
            </div>
          </div>

          {/* Extruded Collapsible Condition Pills (Image 1 & 4) */}
          <div className="space-y-2 pt-2 border-t border-[#e2ddd4]">
            <h4 className="font-bold text-[11px] uppercase tracking-wider text-slate-500">
              Condition & Authenticity
            </h4>
            <div className="grid grid-cols-2 gap-1.5 text-xs font-semibold">
              {['New Season', 'Handwoven', 'Organic Pure', 'Artisanal'].map((condition) => {
                const isActive = selectedTag === condition;
                return (
                  <button
                    key={condition}
                    onClick={() => setSelectedTag(isActive ? '' : condition)}
                    className={`px-2.5 py-1.5 rounded-xl border text-center transition-all ${
                      isActive
                        ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                        : 'bg-[#ece7de] border-[#ded8cd] text-slate-700 hover:bg-[#e4ded3]'
                    }`}
                  >
                    {condition}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Dark Pill "More Filters" Button (Image 1 & 4) */}
          <div className="pt-2 border-t border-[#e2ddd4]">
            <button
              onClick={() => setIsAntiflyAIOpen(true)}
              className="w-full py-2.5 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>More Filters & AI Assist</span>
            </button>
          </div>
        </aside>

        {/* Product Cards Grid */}
        <main className="md:col-span-3 space-y-6">
          {/* Active Filter Chips */}
          {activeFiltersCount > 0 && (
            <div className="flex flex-wrap items-center gap-2 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl text-xs">
              <span className="font-bold text-slate-500">Active Filters:</span>
              {selectedCategorySlug !== 'all' && (
                <span className="px-2.5 py-1 bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-200 rounded-lg flex items-center gap-1 font-semibold">
                  Category: {selectedCategorySlug}
                  <button onClick={() => setSelectedCategorySlug('all')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {searchQuery && (
                <span className="px-2.5 py-1 bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-200 rounded-lg flex items-center gap-1 font-semibold">
                  Search: "{searchQuery}"
                  <button onClick={() => setSearchQuery('')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {selectedColor && (
                <span className="px-2.5 py-1 bg-slate-200 dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg flex items-center gap-1 font-semibold">
                  Color: {selectedColor}
                  <button onClick={() => setSelectedColor('')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {selectedTag && (
                <span className="px-2.5 py-1 bg-slate-200 dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg flex items-center gap-1 font-semibold">
                  Tag: #{selectedTag}
                  <button onClick={() => setSelectedTag('')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              <button
                onClick={clearAllFilters}
                className="text-rose-600 dark:text-rose-400 font-bold ml-auto hover:underline"
              >
                Clear All
              </button>
            </div>
          )}

          {/* Grid or Empty state */}
          {sortedProducts.length === 0 ? (
            <div className="py-16 text-center space-y-4 bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-slate-200 dark:border-slate-800 p-8">
              <div className="w-16 h-16 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center mx-auto text-slate-500">
                <Search className="w-8 h-8" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-slate-900 dark:text-white">
                  No products matched your criteria
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Try clearing some filters or searching for terms like "linen", "kurta", "juttis", or "blazer".
                </p>
              </div>
              <button
                onClick={clearAllFilters}
                className="bg-amber-500 text-slate-800 font-bold px-6 py-2.5 rounded-xl text-xs shadow-md"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {sortedProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
