// ============================================================================
// THE FUTURE OF SOCIAL COMMERCE: GLOBAL COMMUNITY COMMERCE & DELIVERY NETWORK
// «ONE PERSON → BUY → SELL → DELIVER → EARN → CREATE → CONNECT»
// ============================================================================

export interface UserCapabilityPowers {
  buyingPower: {
    active: boolean;
    trustScore: number;
    instantCreditINR: number;
    activeOrdersCount: number;
    communityBadges: string[];
  };
  sellingPower: {
    active: boolean;
    itemsListedCount: number;
    salesVolumeINR: number;
    rating: number;
    verifiedKyc: boolean;
  };
  deliveryPower: {
    active: boolean;
    earnModeActive: boolean;
    vehicleType: 'walking' | 'bicycle' | 'motorcycle' | 'car' | 'ev';
    maxRadiusKm: number;
    deliveriesCompleted: number;
    reliabilityRating: number;
    currentDetourRoute?: {
      fromCity: string;
      toCity: string;
      departureTime: string;
      maxDetourKm: number;
    };
  };
  socialPower: {
    active: boolean;
    followersCount: number;
    followingCount: number;
    communityBadges: string[];
    localCityHub: string;
  };
  creatorPower: {
    active: boolean;
    shoppablePostsCount: number;
    creatorEarningsINR: number;
    commissionRatePct: number;
  };
  earningPower: {
    totalLifetimeEarnedINR: number;
    withdrawableWalletINR: number;
    timeToEarnActive: boolean;
    availableFreeMinutes: number;
  };
}

export interface CommunityDeliveryOpportunity {
  id: string;
  orderNumber: string;
  productName: string;
  productImage: string;
  productValueINR: number;
  pickup: {
    hubName: string;
    address: string;
    city: string;
    lat: number;
    lng: number;
    contactName: string;
    contactPhone: string;
    readyAt: string;
  };
  destination: {
    recipientName: string;
    address: string;
    city: string;
    lat: number;
    lng: number;
    contactPhone: string;
    deliveryDeadline: string;
  };
  pickupDistanceKm: number;
  deliveryDistanceKm: number;
  totalRouteKm: number;
  detourKm: number;
  alongRouteName: string;
  estimatedDurationMins: number;
  parcel: {
    size: 'Small (Pocket/Doc)' | 'Medium (Box)' | 'Large (Multi-Item)';
    weightKg: number;
    description: string;
    isFragile: boolean;
    securitySealOtpRequired: boolean;
  };
  rewardAmountINR: number;
  surgeBonusINR: number;
  customerDeliveryFeeINR: number; // Always 0 (FREE DELIVERY)
  fundingBreakdown: {
    sellerLogisticsContributionINR: number;
    platformSubsidyINR: number;
    communityIncentivePoolINR: number;
    netPlatformMarginINR: number;
  };
  matchingScorePct: number;
  matchingSignals: {
    routeCompatibilityPct: number;
    vehicleSuitabilityPct: number;
    trustScorePct: number;
    historicalAcceptancePct: number;
  };
  multiParcelEligible: boolean;
  multiParcelAddon?: {
    secondaryOrderId: string;
    secondaryProductName: string;
    extraRewardINR: number;
    extraDetourKm: number;
    extraDurationMins: number;
  };
  status: 'available' | 'reserved' | 'in_transit' | 'delivered' | 'skipped';
  assignedPartnerName?: string;
  assignedPartnerId?: string;
  createdAt: string;
}

export interface SecondHandProductAssessment {
  id: string;
  productName: string;
  category: string;
  originalMrp: number;
  suggestedSellingPrice: number;
  photos: string[];
  sellerDeclaredCondition: 'Pristine (Like New)' | 'Excellent' | 'Good (Minor Signs)' | 'Fair (Used)';
  aiVisualAssessment: {
    overallGrade: 'Grade A+ (Pristine)' | 'Grade A (Excellent)' | 'Grade B (Good)' | 'Grade C (Fair)';
    confidenceScorePct: number;
    cosmeticWearObservation: string;
    screenAndDisplayStatus: string;
    functionalIntegrityCheck: string;
    estimatedDepreciationPct: number;
    detectedAccessories: string[];
    missingAccessories: string[];
    fraudRiskIndicator: 'Ultra-Low Risk' | 'Verified Safe' | 'Requires Invoice Proof';
    transparencySummary: string;
  };
  isExchangeEligible: boolean;
  sellerCity: string;
  sellerTrustScore: number;
}

export interface ProductExchangeOffer {
  id: string;
  title: string;
  offeredItem: {
    title: string;
    category: string;
    condition: string;
    estimatedValueINR: number;
    image: string;
    location: string;
  };
  targetCategoryOrItems: string[];
  cashAdjustmentINR: number; // Positive = offered cash added, Negative = requesting cash difference
  tradeType: 'Direct Item Swap' | 'Item + Cash Difference' | 'Free Community Giveaway';
  ownerId: string;
  ownerName: string;
  ownerCity: string;
  ownerAvatar: string;
  communityTrustScore: number;
  aiTradeFairnessScorePct: number;
  status: 'open' | 'negotiating' | 'completed';
  datePosted: string;
}

export interface TimeToEarnOption {
  id: string;
  timeWindowMinutes: number;
  opportunityType: 'Rapid Neighborhood Delivery' | 'Venture Store Pickup & Drop' | 'Community Parcel Escort' | 'Urgent Medicines / Food Transit';
  title: string;
  routeSummary: string;
  distanceKm: number;
  estimatedEarningsINR: number;
  instantPayoutEligible: boolean;
  urgencyLevel: 'High Demand (+20% Surge)' | 'Standard Opportunity' | 'Relaxed Detour';
  parcelSize: string;
}

export interface CommerceGraphNode {
  id: string;
  label: string;
  category: 'Person' | 'Product' | 'Community' | 'Route' | 'Delivery' | 'Trust' | 'Demand';
  color: string;
  metrics: string;
}

export interface CommerceGraphEdge {
  from: string;
  to: string;
  relationship: string;
  weight: number;
}

export interface NoCodeBusinessRule {
  id: string;
  name: string;
  triggerEvent: string;
  conditions: string[];
  action: string;
  isActive: boolean;
  impactMetric: string;
}

export interface LedgerFinancialEntry {
  id: string;
  timestamp: string;
  eventId: string;
  eventType: string;
  customerChargedINR: number;
  sellerPayoutINR: number;
  communityPartnerRewardINR: number;
  platformCommissionINR: number;
  taxGstINR: number;
  deliverySubsidizedINR: number;
  auditHash: string;
  status: 'SETTLED' | 'HELD_IN_ESCROW' | 'RELEASED';
}

// ----------------------------------------------------------------------------
// INITIAL SEED DATA
// ----------------------------------------------------------------------------

export const INITIAL_CAPABILITY_POWERS: UserCapabilityPowers = {
  buyingPower: {
    active: true,
    trustScore: 920,
    instantCreditINR: 25000,
    activeOrdersCount: 2,
    communityBadges: ['Prime Buyer', 'Instant Payer', 'Verified Resident'],
  },
  sellingPower: {
    active: true,
    itemsListedCount: 6,
    salesVolumeINR: 48500,
    rating: 4.9,
    verifiedKyc: true,
  },
  deliveryPower: {
    active: true,
    earnModeActive: false,
    vehicleType: 'motorcycle',
    maxRadiusKm: 25,
    deliveriesCompleted: 48,
    reliabilityRating: 4.95,
    currentDetourRoute: {
      fromCity: 'Indore (Vijay Nagar)',
      toCity: 'Khandwa (Anand Nagar)',
      departureTime: 'Today 5:30 PM',
      maxDetourKm: 2.5,
    },
  },
  socialPower: {
    active: true,
    followersCount: 1420,
    followingCount: 380,
    communityBadges: ['Local Champion', 'Community Hero', 'Top Recommender'],
    localCityHub: 'Indore Central',
  },
  creatorPower: {
    active: true,
    shoppablePostsCount: 14,
    creatorEarningsINR: 8420,
    commissionRatePct: 7.5,
  },
  earningPower: {
    totalLifetimeEarnedINR: 32640,
    withdrawableWalletINR: 4250,
    timeToEarnActive: true,
    availableFreeMinutes: 60,
  },
};

export const INITIAL_COMMUNITY_DELIVERIES: CommunityDeliveryOpportunity[] = [
  {
    id: 'comm-del-101',
    orderNumber: 'WISE-COMM-8821',
    productName: 'Sony WH-1000XM5 Wireless Headphones (Sealed Box)',
    productImage: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500',
    productValueINR: 28990,
    pickup: {
      hubName: 'TechVibe Gadgets Store',
      address: 'Shop 14, Treasure Island Mall, MG Road',
      city: 'Indore',
      lat: 22.7196,
      lng: 75.8577,
      contactName: 'Rohit Sharma (Store Mgr)',
      contactPhone: '+91 98260 11223',
      readyAt: 'Ready for Immediate Pickup',
    },
    destination: {
      recipientName: 'Pooja Verma',
      address: 'Flat 402, Royal Palms, Bypass Road',
      city: 'Indore',
      lat: 22.7482,
      lng: 75.8988,
      contactPhone: '+91 97550 44332',
      deliveryDeadline: 'Within 45 Mins (Fast Track)',
    },
    pickupDistanceKm: 1.8,
    deliveryDistanceKm: 6.4,
    totalRouteKm: 8.2,
    detourKm: 0.9,
    alongRouteName: 'MG Road → AB Road Bypass Corridor',
    estimatedDurationMins: 24,
    parcel: {
      size: 'Medium (Box)',
      weightKg: 1.2,
      description: 'Original Electronics Retail Package with Tamper-Proof Seal',
      isFragile: true,
      securitySealOtpRequired: true,
    },
    rewardAmountINR: 145,
    surgeBonusINR: 35,
    customerDeliveryFeeINR: 0, // FREE FOR BUYER
    fundingBreakdown: {
      sellerLogisticsContributionINR: 110,
      platformSubsidyINR: 70,
      communityIncentivePoolINR: 0,
      netPlatformMarginINR: 18,
    },
    matchingScorePct: 96,
    matchingSignals: {
      routeCompatibilityPct: 98,
      vehicleSuitabilityPct: 95,
      trustScorePct: 99,
      historicalAcceptancePct: 92,
    },
    multiParcelEligible: true,
    multiParcelAddon: {
      secondaryOrderId: 'WISE-COMM-8824',
      secondaryProductName: 'Handmade Kashmiri Pashmina Stole',
      extraRewardINR: 65,
      extraDetourKm: 0.6,
      extraDurationMins: 7,
    },
    status: 'available',
    createdAt: '5 mins ago',
  },
  {
    id: 'comm-del-102',
    orderNumber: 'WISE-COMM-9940',
    productName: 'Traditional Maheshwari Pure Silk Saree',
    productImage: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=500',
    productValueINR: 8450,
    pickup: {
      hubName: 'Malwa Heritage Handlooms',
      address: '22 Chhatribagh Main Market',
      city: 'Indore',
      lat: 22.7154,
      lng: 75.8452,
      contactName: 'Deepak Patidar',
      contactPhone: '+91 94250 88776',
      readyAt: 'Packed & Verified',
    },
    destination: {
      recipientName: 'Dr. Anand Joshi',
      address: 'Civil Lines, Near Collectorate',
      city: 'Khandwa',
      lat: 21.8314,
      lng: 76.3498,
      contactPhone: '+91 98270 33221',
      deliveryDeadline: 'Today Evening by 7:30 PM',
    },
    pickupDistanceKm: 2.1,
    deliveryDistanceKm: 128.0,
    totalRouteKm: 130.1,
    detourKm: 1.4,
    alongRouteName: 'Indore → Simrol → Barwah → Sanawad → Khandwa Highway (SH-27)',
    estimatedDurationMins: 140,
    parcel: {
      size: 'Small (Pocket/Doc)',
      weightKg: 0.8,
      description: 'Luxury Gift Box with Protected Waterproof Sheath',
      isFragile: false,
      securitySealOtpRequired: true,
    },
    rewardAmountINR: 480,
    surgeBonusINR: 120,
    customerDeliveryFeeINR: 0, // FREE FOR BUYER
    fundingBreakdown: {
      sellerLogisticsContributionINR: 350,
      platformSubsidyINR: 250,
      communityIncentivePoolINR: 0,
      netPlatformMarginINR: 45,
    },
    matchingScorePct: 94,
    matchingSignals: {
      routeCompatibilityPct: 96,
      vehicleSuitabilityPct: 92,
      trustScorePct: 97,
      historicalAcceptancePct: 91,
    },
    multiParcelEligible: false,
    status: 'available',
    createdAt: '12 mins ago',
  },
  {
    id: 'comm-del-103',
    orderNumber: 'WISE-COMM-7731',
    productName: 'Organic Alphonso Mango Crate (5 Kg Fresh Farm Direct)',
    productImage: 'https://images.unsplash.com/photo-1553279768-865429fa0078?w=500',
    productValueINR: 1650,
    pickup: {
      hubName: 'Nimar Organic Farmers Hub',
      address: 'Pipliyahana Square Farm Outlet',
      city: 'Indore',
      lat: 22.7092,
      lng: 75.8921,
      contactName: 'Suresh Mukati',
      contactPhone: '+91 97520 99118',
      readyAt: 'Fresh Harvest Ready',
    },
    destination: {
      recipientName: 'Kavita Saxena',
      address: 'B-12 Shekhar Residency, Mahalaxmi Nagar',
      city: 'Indore',
      lat: 22.7541,
      lng: 75.9015,
      contactPhone: '+91 99810 55667',
      deliveryDeadline: 'Within 60 Mins',
    },
    pickupDistanceKm: 1.1,
    deliveryDistanceKm: 5.2,
    totalRouteKm: 6.3,
    detourKm: 0.4,
    alongRouteName: 'Ring Road → Bombay Hospital → Mahalaxmi Nagar',
    estimatedDurationMins: 18,
    parcel: {
      size: 'Large (Multi-Item)',
      weightKg: 5.2,
      description: 'Ventilated Fruit Crate Handle Pack',
      isFragile: true,
      securitySealOtpRequired: false,
    },
    rewardAmountINR: 120,
    surgeBonusINR: 25,
    customerDeliveryFeeINR: 0,
    fundingBreakdown: {
      sellerLogisticsContributionINR: 85,
      platformSubsidyINR: 60,
      communityIncentivePoolINR: 0,
      netPlatformMarginINR: 12,
    },
    matchingScorePct: 91,
    matchingSignals: {
      routeCompatibilityPct: 93,
      vehicleSuitabilityPct: 88,
      trustScorePct: 96,
      historicalAcceptancePct: 89,
    },
    multiParcelEligible: true,
    status: 'available',
    createdAt: '18 mins ago',
  },
  {
    id: 'comm-del-104',
    orderNumber: 'WISE-COMM-6625',
    productName: 'Fujifilm Instax Mini 12 Instant Camera Bundle',
    productImage: 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=500',
    productValueINR: 6999,
    pickup: {
      hubName: 'Camera Studio Hub',
      address: 'Palasia Point, Old Palasia',
      city: 'Indore',
      lat: 22.7244,
      lng: 75.8839,
      contactName: 'Vikram Rajput',
      contactPhone: '+91 98930 77441',
      readyAt: 'Ready for Pickup',
    },
    destination: {
      recipientName: 'Aryan Chawla',
      address: 'IIT Indore Campus, Simrol',
      city: 'Indore Outskirts',
      lat: 22.5204,
      lng: 75.9207,
      contactPhone: '+91 93020 66554',
      deliveryDeadline: 'Today 4:00 PM',
    },
    pickupDistanceKm: 3.2,
    deliveryDistanceKm: 24.5,
    totalRouteKm: 27.7,
    detourKm: 1.8,
    alongRouteName: 'Palasia → Tejaji Nagar → Simrol Route',
    estimatedDurationMins: 42,
    parcel: {
      size: 'Medium (Box)',
      weightKg: 1.4,
      description: 'Camera + 2x Film Packs Boxed',
      isFragile: true,
      securitySealOtpRequired: true,
    },
    rewardAmountINR: 260,
    surgeBonusINR: 50,
    customerDeliveryFeeINR: 0,
    fundingBreakdown: {
      sellerLogisticsContributionINR: 190,
      platformSubsidyINR: 120,
      communityIncentivePoolINR: 0,
      netPlatformMarginINR: 22,
    },
    matchingScorePct: 88,
    matchingSignals: {
      routeCompatibilityPct: 90,
      vehicleSuitabilityPct: 94,
      trustScorePct: 95,
      historicalAcceptancePct: 86,
    },
    multiParcelEligible: true,
    status: 'available',
    createdAt: '25 mins ago',
  },
];

export const INITIAL_SECOND_HAND_ASSESSMENTS: SecondHandProductAssessment[] = [
  {
    id: 'sh-prod-201',
    productName: 'Apple iPhone 14 Pro (128GB Space Black) — Dual eSIM',
    category: 'Electronics & Mobiles',
    originalMrp: 129900,
    suggestedSellingPrice: 62500,
    photos: [
      'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=600',
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600',
    ],
    sellerDeclaredCondition: 'Pristine (Like New)',
    aiVisualAssessment: {
      overallGrade: 'Grade A+ (Pristine)',
      confidenceScorePct: 97.4,
      cosmeticWearObservation: 'Zero micro-scratches detected on ceramic shield. Bezel chamfer shows factory satin shine without dents.',
      screenAndDisplayStatus: '120Hz ProMotion OLED flawless with 100% pixel response. No burn-in or tinting.',
      functionalIntegrityCheck: 'Face ID, TrueTone, 48MP Triple Lens Camera, and MagSafe charging verified operational.',
      estimatedDepreciationPct: 51.8,
      detectedAccessories: ['Original USB-C to Lightning Braided Cable', 'Spigen Mag Armor Case', 'Original Box + Bill'],
      missingAccessories: ['Charging Brick (Sold separately by Apple)'],
      fraudRiskIndicator: 'Verified Safe',
      transparencySummary: 'AI computer-vision multi-angle verification completed. Seller declared condition matches visual evidence with 97.4% precision index.',
    },
    isExchangeEligible: true,
    sellerCity: 'Indore (Saket Nagar)',
    sellerTrustScore: 960,
  },
  {
    id: 'sh-prod-202',
    productName: 'Sony Alpha A7 III Full-Frame Mirrorless Camera (Body Only)',
    category: 'Photography & Cameras',
    originalMrp: 164990,
    suggestedSellingPrice: 84000,
    photos: [
      'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=600',
    ],
    sellerDeclaredCondition: 'Excellent',
    aiVisualAssessment: {
      overallGrade: 'Grade A (Excellent)',
      confidenceScorePct: 94.8,
      cosmeticWearObservation: 'Minor rubber grip texture smoothing near shutter button. Sensor glass pristine with 0 dust particles.',
      screenAndDisplayStatus: 'Flip LCD clean, protected by tempered glass sheet.',
      functionalIntegrityCheck: 'Shutter count verified at 14,200 clicks (Rated for 200,000). Dual SD slots tested.',
      estimatedDepreciationPct: 49.0,
      detectedAccessories: ['2x OEM Sony NP-FZ100 Batteries', 'Dual Bay Rapid Charger', 'Camera Strap'],
      missingAccessories: ['Original Outer Paper Packaging Box'],
      fraudRiskIndicator: 'Verified Safe',
      transparencySummary: 'Superb mechanical status. Shutter life remaining is approximately 93%.',
    },
    isExchangeEligible: true,
    sellerCity: 'Indore (Vijay Nagar)',
    sellerTrustScore: 945,
  },
  {
    id: 'sh-prod-203',
    productName: 'Herman Miller Aeron Ergonomic Office Chair (Size B)',
    category: 'Furniture & Living',
    originalMrp: 145000,
    suggestedSellingPrice: 58000,
    photos: [
      'https://images.unsplash.com/photo-1580481077195-722f4509132d?w=600',
    ],
    sellerDeclaredCondition: 'Good (Minor Signs)',
    aiVisualAssessment: {
      overallGrade: 'Grade B (Good)',
      confidenceScorePct: 92.1,
      cosmeticWearObservation: 'Pellicle mesh taut and undamaged. Armrest polyurethane has minor scuff on left edge.',
      screenAndDisplayStatus: 'N/A (Mechanical Furniture)',
      functionalIntegrityCheck: 'Pneumatic cylinder height lock, forward tilt limiter, and PostureFit SL lumbar functioning smoothly.',
      estimatedDepreciationPct: 60.0,
      detectedAccessories: ['Forward Tilt & Lumbar Dial Kit'],
      missingAccessories: ['Manufacturer Warranty Card (Expired)'],
      fraudRiskIndicator: 'Verified Safe',
      transparencySummary: 'Iconic ergonomic build with 8+ years of active lifespan remaining. Recommended local pickup or community truck courier.',
    },
    isExchangeEligible: false,
    sellerCity: 'Indore (Old Palasia)',
    sellerTrustScore: 910,
  },
];

export const INITIAL_EXCHANGE_OFFERS: ProductExchangeOffer[] = [
  {
    id: 'exch-offer-301',
    title: 'Apple iPad Pro 11" (M2 Chip, 256GB) ↔ Looking for Sony Mirrorless Lens or DJI Drone',
    offeredItem: {
      title: 'iPad Pro 11-inch M2 (256GB WiFi) Space Grey',
      category: 'Electronics',
      condition: 'Pristine (Like New)',
      estimatedValueINR: 65000,
      image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=500',
      location: 'Indore (Geeta Bhawan)',
    },
    targetCategoryOrItems: ['Sony 24-70mm GM Lens', 'DJI Mini 3 Pro Drone', 'MacBook Air M2'],
    cashAdjustmentINR: 0,
    tradeType: 'Direct Item Swap',
    ownerId: 'usr-adv-101',
    ownerName: 'Harshwardhan Patel',
    ownerCity: 'Indore',
    ownerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    communityTrustScore: 980,
    aiTradeFairnessScorePct: 98,
    status: 'open',
    datePosted: '2 hours ago',
  },
  {
    id: 'exch-offer-302',
    title: 'PlayStation 5 Disc Edition + 4 Games ↔ Looking for Gaming Laptop (Will Add Cash)',
    offeredItem: {
      title: 'Sony PS5 Disc Edition + 2 DualSense Controllers',
      category: 'Gaming',
      condition: 'Excellent',
      estimatedValueINR: 42000,
      image: 'https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=500',
      location: 'Khandwa (Cinema Square)',
    },
    targetCategoryOrItems: ['ASUS ROG Zephyrus', 'Lenovo Legion 5', 'Acer Predator RTX 4060'],
    cashAdjustmentINR: 20000, // Willing to add ₹20,000 cash for RTX 4060 laptop
    tradeType: 'Item + Cash Difference',
    ownerId: 'usr-adv-102',
    ownerName: 'Vikas Kushwaha',
    ownerCity: 'Khandwa',
    ownerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    communityTrustScore: 935,
    aiTradeFairnessScorePct: 95,
    status: 'open',
    datePosted: '4 hours ago',
  },
  {
    id: 'exch-offer-303',
    title: 'Complete 30-Volume Classic World Literature & Philosophy Collection ↔ Free Giveaway for Student',
    offeredItem: {
      title: 'Hardbound Classic Literature & Philosophy Books',
      category: 'Books & Learning',
      condition: 'Good (Minor Signs)',
      estimatedValueINR: 7500,
      image: 'https://images.unsplash.com/photo-1495446815901-a7297e633e8d?w=500',
      location: 'Indore (Annapurna)',
    },
    targetCategoryOrItems: ['Deserving Student / College Reader'],
    cashAdjustmentINR: 0,
    tradeType: 'Free Community Giveaway',
    ownerId: 'usr-adv-103',
    ownerName: 'Prof. Ramakant Dave',
    ownerCity: 'Indore',
    ownerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
    communityTrustScore: 995,
    aiTradeFairnessScorePct: 100,
    status: 'open',
    datePosted: 'Yesterday',
  },
];

export const INITIAL_TIME_TO_EARN_OPTIONS: TimeToEarnOption[] = [
  {
    id: 'tte-15m',
    timeWindowMinutes: 15,
    opportunityType: 'Rapid Neighborhood Delivery',
    title: 'Deliver Artisan Coffee Beans & Pastry Box (1.4 km)',
    routeSummary: 'Curo High Street Cafe → Gulmohar Colony',
    distanceKm: 1.4,
    estimatedEarningsINR: 85,
    instantPayoutEligible: true,
    urgencyLevel: 'High Demand (+20% Surge)',
    parcelSize: 'Small Bag (0.4 kg)',
  },
  {
    id: 'tte-30m',
    timeWindowMinutes: 30,
    opportunityType: 'Venture Store Pickup & Drop',
    title: 'Deliver Wireless Mechanical Keyboard to IT Park (4.2 km)',
    routeSummary: 'Sapna Sangeeta Electronics Hub → Crystal IT Park',
    distanceKm: 4.2,
    estimatedEarningsINR: 165,
    instantPayoutEligible: true,
    urgencyLevel: 'High Demand (+20% Surge)',
    parcelSize: 'Medium Box (1.1 kg)',
  },
  {
    id: 'tte-60m',
    timeWindowMinutes: 60,
    opportunityType: 'Community Parcel Escort',
    title: 'Batch Deliver 2 Compatible Boutiques on your evening commute (9.8 km)',
    routeSummary: 'Chhappan Dukan → Rau Bypass via Rajendra Nagar',
    distanceKm: 9.8,
    estimatedEarningsINR: 320,
    instantPayoutEligible: true,
    urgencyLevel: 'Standard Opportunity',
    parcelSize: '2x Medium Boxes (2.6 kg)',
  },
  {
    id: 'tte-120m',
    timeWindowMinutes: 120,
    opportunityType: 'Urgent Medicines / Food Transit',
    title: 'Regional Highway Transit Deliveries (Indore → Khandwa Corridor)',
    routeSummary: 'Indore Central Hub → Barwah & Khandwa Drops',
    distanceKm: 110.0,
    estimatedEarningsINR: 750,
    instantPayoutEligible: true,
    urgencyLevel: 'High Demand (+20% Surge)',
    parcelSize: 'Express Package (3.0 kg)',
  },
];

export const INITIAL_COMMERCE_GRAPH_NODES: CommerceGraphNode[] = [
  { id: 'usr-you', label: 'You (Verified Citizen)', category: 'Person', color: '#10b981', metrics: 'Trust 920 • 6 Capabilities Active' },
  { id: 'usr-seller-1', label: 'TechVibe Store (Rohit S.)', category: 'Person', color: '#3b82f6', metrics: 'Venture • 4.9★ (3.4k Sales)' },
  { id: 'usr-buyer-1', label: 'Pooja Verma (Buyer)', category: 'Person', color: '#ec4899', metrics: 'Instant UPI Verified' },
  { id: 'prod-headphones', label: 'Sony WH-1000XM5', category: 'Product', color: '#f59e0b', metrics: '₹28,990 • Digital Passport Valid' },
  { id: 'prod-iphone14', label: 'iPhone 14 Pro (Second-Hand)', category: 'Product', color: '#8b5cf6', metrics: '₹62,500 • AI Grade A+' },
  { id: 'hub-indore', label: 'Indore Community Hub', category: 'Community', color: '#06b6d4', metrics: '42,800 Active Members' },
  { id: 'hub-khandwa', label: 'Khandwa Community Hub', category: 'Community', color: '#14b8a6', metrics: '11,400 Active Members' },
  { id: 'route-indore-khandwa', label: 'SH-27 Highway Corridor', category: 'Route', color: '#f43f5e', metrics: '130 km • 84 Daily Travelers' },
  { id: 'del-opp-101', label: 'Delivery Opportunity #8821', category: 'Delivery', color: '#e11d48', metrics: '₹180 Partner Reward • Free to Buyer' },
  { id: 'trust-cluster', label: 'Consensus Trust Network', category: 'Trust', color: '#22c55e', metrics: 'Zero Fraud Dispute SLA' },
];

export const INITIAL_COMMERCE_GRAPH_EDGES: CommerceGraphEdge[] = [
  { from: 'usr-you', to: 'hub-indore', relationship: 'Belongs to & Champion of', weight: 1 },
  { from: 'usr-you', to: 'route-indore-khandwa', relationship: 'Travels & Detour Capable', weight: 1 },
  { from: 'usr-you', to: 'del-opp-101', relationship: 'Matched via 96% Affinity', weight: 1 },
  { from: 'usr-seller-1', to: 'prod-headphones', relationship: 'Sells & Funds Delivery', weight: 1 },
  { from: 'usr-buyer-1', to: 'prod-headphones', relationship: 'Purchased with Free Shipping', weight: 1 },
  { from: 'prod-headphones', to: 'del-opp-101', relationship: 'Generates Live Delivery', weight: 1 },
  { from: 'del-opp-101', to: 'route-indore-khandwa', relationship: 'Intersects Travel Route', weight: 1 },
  { from: 'usr-you', to: 'prod-iphone14', relationship: 'Listed for Sale & Barter', weight: 1 },
  { from: 'usr-you', to: 'trust-cluster', relationship: 'Backed by 920 Trust Score', weight: 1 },
];

export const INITIAL_NO_CODE_BUSINESS_RULES: NoCodeBusinessRule[] = [
  {
    id: 'rule-01',
    name: 'Zero-Cost Customer Free Delivery Engine',
    triggerEvent: 'ORDER_CHECKOUT_INITIALIZED',
    conditions: ['orderValue >= ₹499 OR isWiseOneMember == true', 'deliveryDistanceKm <= 50'],
    action: 'SET customerDeliveryFee = 0; FUND partnerReward from sellerLogisticsFee (65%) + platformSubsidy (35%)',
    isActive: true,
    impactMetric: '100% Free Shipping Conversion Boost (+42%)',
  },
  {
    id: 'rule-02',
    name: 'Dynamic Route Detour Carry & Earn Surge',
    triggerEvent: 'COMMUNITY_PARTNER_DETOUR_DETECTED',
    conditions: ['detourKm <= 3.0', 'destinationDistance <= 150 km', 'partnerTrustScore >= 850'],
    action: 'PROPOSE instant opportunity with +20% Express Detour Bonus; ALLOCATE matching score >= 90%',
    isActive: true,
    impactMetric: 'Cuts inter-city transit time from 24 hrs to 3.5 hrs',
  },
  {
    id: 'rule-03',
    name: 'Multi-Parcel Smart Batching (+₹45 / +8 mins)',
    triggerEvent: 'PARTNER_ACCEPTED_PRIMARY_DELIVERY',
    conditions: ['nearbyCompatibleParcelAvailable == true', 'extraDetourKm <= 1.5', 'vehicleCapacity == OK'],
    action: 'TRIGGER "Add One More Delivery" modal with auto-calculated detour and combined payout',
    isActive: true,
    impactMetric: 'Increases partner hourly earning by +64%',
  },
  {
    id: 'rule-04',
    name: 'AI Second-Hand Fraud Guard & Price Guidance',
    triggerEvent: 'USER_CREATES_USED_ITEM_LISTING',
    conditions: ['photosUploaded >= 1', 'category == "Electronics" OR category == "Luxury"'],
    action: 'RUN AI condition inspection; GENERATE Grade A-C scorecard; SUGGEST fair price band; PREVENT banned goods',
    isActive: true,
    impactMetric: 'Reduces peer-to-peer disputes to <0.04%',
  },
];

export const INITIAL_LEDGER_ENTRIES: LedgerFinancialEntry[] = [
  {
    id: 'LEDGER-TX-901',
    timestamp: '2026-08-23 14:12:05',
    eventId: 'EVT-ORDER-DEL-8821',
    eventType: 'DELIVERY_COMPLETED_PAYMENT_RELEASED',
    customerChargedINR: 28990,
    sellerPayoutINR: 27440,
    communityPartnerRewardINR: 180,
    platformCommissionINR: 1250,
    taxGstINR: 120,
    deliverySubsidizedINR: 70,
    auditHash: '0x8f3c4a2b9e1d88a7c29012f499bb810e74ac5e91',
    status: 'SETTLED',
  },
  {
    id: 'LEDGER-TX-902',
    timestamp: '2026-08-23 13:45:22',
    eventId: 'EVT-DETOUR-DEL-9940',
    eventType: 'INTERCITY_DETOUR_ESCROW_LOCKED',
    customerChargedINR: 8450,
    sellerPayoutINR: 7980,
    communityPartnerRewardINR: 600,
    platformCommissionINR: 320,
    taxGstINR: 45,
    deliverySubsidizedINR: 250,
    auditHash: '0x12b7e9a8f4c3d2105e6b7c8a9f0e1d2c3b4a5967',
    status: 'HELD_IN_ESCROW',
  },
  {
    id: 'LEDGER-TX-903',
    timestamp: '2026-08-23 12:10:48',
    eventId: 'EVT-EXCH-SWAP-301',
    eventType: 'PEER_EXCHANGE_FEE_SETTLED',
    customerChargedINR: 0,
    sellerPayoutINR: 0,
    communityPartnerRewardINR: 0,
    platformCommissionINR: 99,
    taxGstINR: 18,
    deliverySubsidizedINR: 0,
    auditHash: '0x44c9b2a1f0d3e56789012345abcdef6789012345',
    status: 'SETTLED',
  },
];
