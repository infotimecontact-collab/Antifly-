import { ProductReview } from '../types';

export const DEFAULT_PRODUCT_REVIEWS: Record<string, ProductReview[]> = {
  default: [
    {
      id: 'rev-01',
      userId: 'user-001',
      userName: 'Aarav Singhania',
      userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
      rating: 5,
      title: 'Outstanding quality and luxurious natural drape!',
      comment:
        'The fabric texture exceeded my expectations. Pre-washed feel right out of the box with zero harsh chemical odor. Pairs wonderfully with linen chinos and loafers. Highly recommended!',
      date: '14 Aug 2026',
      verifiedPurchase: true,
      isVerified: true,
      location: 'Bengaluru, Karnataka',
      helpfulCount: 42,
      pros: ['100% Breathable', 'True to Size', 'Premium Finishing'],
      cons: ['Dry clean or delicate wash recommended'],
      images: [
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=600&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=600&auto=format&fit=crop&q=80',
      ],
      status: 'Approved',
      featured: true,
    },
    {
      id: 'rev-02',
      userId: 'user-002',
      userName: 'Pooja Verma',
      userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&auto=format&fit=crop&q=80',
      rating: 5,
      title: 'Real artisan craft - worth every rupee!',
      comment:
        'Got this for my brother’s anniversary party. The packaging was top tier with recycled cotton dust bags. Received in less than 48 hours via Antifly express courier.',
      date: '10 Aug 2026',
      verifiedPurchase: true,
      isVerified: true,
      location: 'Mumbai, Maharashtra',
      helpfulCount: 28,
      pros: ['Fast Delivery', 'Eco-friendly Packaging'],
      cons: [],
      images: [
        'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=600&auto=format&fit=crop&q=80',
      ],
      status: 'Approved',
      featured: true,
    },
    {
      id: 'rev-03',
      userId: 'user-003',
      userName: 'Rohan Deshmukh',
      userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
      rating: 4,
      title: 'Great fit and stitching, very comfortable',
      comment:
        'Fit is relaxed and airy. If you want a slim fit, consider sizing down by one notch. Color is identical to website photos.',
      date: '02 Aug 2026',
      verifiedPurchase: true,
      isVerified: true,
      location: 'Pune, Maharashtra',
      helpfulCount: 15,
      pros: ['Vibrant Color Match', 'Comfortable Collar'],
      cons: ['Slightly relaxed torso'],
      status: 'Approved',
    },
  ],
};

export function getProductReviews(productId: string): ProductReview[] {
  return DEFAULT_PRODUCT_REVIEWS[productId] || DEFAULT_PRODUCT_REVIEWS.default;
}
