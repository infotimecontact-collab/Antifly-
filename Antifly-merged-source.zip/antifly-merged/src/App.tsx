import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { DeviceSwitcher } from './components/common/DeviceSwitcher';
import { WebsiteHeader } from './components/website/WebsiteHeader';
import { WebsiteHero } from './components/website/WebsiteHero';
import { WebsiteModularHomepage } from './components/website/WebsiteModularHomepage';
import { WebsiteCatalog } from './components/website/WebsiteCatalog';
import { WebsiteAccountOrders } from './components/website/WebsiteAccountOrders';
import { WebsiteFooter } from './components/website/WebsiteFooter';
import { MobileAppContainer } from './components/mobile/MobileAppContainer';
import { AdminLayout } from './components/admin/AdminLayout';
import { SellerCentralPortal } from './components/seller/SellerCentralPortal';
import { SellerAndroidApp } from './components/seller/SellerAndroidApp';
import { SellerIOSApp } from './components/seller/SellerIOSApp';
import { DriverPartnerPortal } from './components/driver/DriverPartnerPortal';
import { EcommerceAPIPlayground } from './components/api/EcommerceAPIPlayground';

import { WebsiteNearbyStores } from './components/website/WebsiteNearbyStores';
import { WebsiteSellersDirectory } from './components/website/WebsiteSellersDirectory';
import { WebsiteInstagramSearch } from './components/website/WebsiteInstagramSearch';
import { WebsiteSocialCommunity } from './components/website/WebsiteSocialCommunity';
import { WebsiteCustomerProfile } from './components/website/WebsiteCustomerProfile';

// Common Global Modals & Drawers
import { CartDrawer } from './components/common/CartDrawer';
import { CheckoutModal } from './components/common/CheckoutModal';
import { ProductDetailModal } from './components/common/ProductDetailModal';
import { WiseAIChatModal } from './components/common/WiseAIChatModal';
import { VoiceSearchModal } from './components/common/VoiceSearchModal';
import { ImageSearchModal } from './components/common/ImageSearchModal';
import { NotificationDrawer } from './components/common/NotificationDrawer';
import { OrderTrackingModal } from './components/common/OrderTrackingModal';
import { ProductComparisonModal } from './components/common/ProductComparisonModal';
import { CMSModal } from './components/common/CMSModal';
import { ToastNotification } from './components/common/ToastNotification';
import { GoogleAnalytics4Modal } from './components/common/GoogleAnalytics4Modal';
import { SEOManagerModal } from './components/common/SEOManagerModal';
import { ProductFinderModal } from './components/common/ProductFinderModal';

import { AuthModal } from './components/common/AuthModal';
import { RoleExclusivityBanner } from './components/common/RoleExclusivityBanner';

// WiseCoins, WiseReseller, WiseStyle & Squad Buy Feature Modals
import { SuperCoinsZoneModal } from './components/common/SuperCoinsZoneModal';
import { MeeshoResellerModal } from './components/common/MeeshoResellerModal';
import { MyntraStudioModal } from './components/common/MyntraStudioModal';
import { SizeAssistantModal } from './components/common/SizeAssistantModal';
import { GroupBuyModal } from './components/common/GroupBuyModal';
import { LiveMapTrackingModal } from './components/common/LiveMapTrackingModal';
import { InvoiceModal } from './components/common/InvoiceModal';
import { FoodDeliveryModal } from './components/common/FoodDeliveryModal';
import { WiseOneSubscriptionModal } from './components/common/WiseOneSubscriptionModal';
import { BankOffersModal } from './components/common/BankOffersModal';
import { OTTEntertainmentModal } from './components/common/OTTEntertainmentModal';
import { StoreCommunityModal } from './components/common/StoreCommunityModal';
import { StoreChatDrawer } from './components/common/StoreChatDrawer';
import { GlobalAppDock } from './components/common/GlobalAppDock';

// Unified Personas, Vendor Connect, Verified Badges & Admin AI
import { UnifiedRoleSwitcherModal } from './components/common/UnifiedRoleSwitcherModal';
import { VendorConnectMembershipModal } from './components/common/VendorConnectMembershipModal';
import { VerifiedBadgeModal } from './components/common/VerifiedBadgeModal';
import { AdminAIChatbotModal } from './components/common/AdminAIChatbotModal';
import { ShortReelPlayerModal } from './components/common/ShortReelPlayerModal';
import { SellerRatingModal } from './components/common/SellerRatingModal';
import { PlayStoreMarketingModal } from './components/common/PlayStoreMarketingModal';
import { AdminDriverIncentiveLedgerModal } from './components/admin/AdminDriverIncentiveLedgerModal';
import { BookBuddyModal } from './components/seller/BookBuddyModal';
import { IncomingBuddyCallModal } from './components/driver/IncomingBuddyCallModal';

// WhatsApp-Style 24H Status & Story System
import { WhatsAppStatusHub } from './components/social/WhatsAppStatusHub';
import { StoryViewerModal } from './components/social/StoryViewerModal';
import { AddStoryModal } from './components/social/AddStoryModal';
import { CreateSellerPostModal } from './components/social/CreateSellerPostModal';

// Universal Save, Favorites & Collections System
import { FavoritesHubModal } from './components/favorites/FavoritesHubModal';
import { SaveToCollectionModal } from './components/favorites/SaveToCollectionModal';

// Universal Disappearing Content & Auto-Delete System + Flagship Super Coin & Diamond Economy
import { UniversalAutoDeleteModal } from './components/lifecycle/UniversalAutoDeleteModal';
import { SuperCoinDiamondRewardsModal } from './components/rewards/SuperCoinDiamondRewardsModal';

// Live Stream Commerce, Multilingual Vernacular Voice Studio & 3D AR Studio
import { LiveStreamShoppingModal } from './components/common/LiveStreamShoppingModal';
import { MultilingualVoiceStudioModal } from './components/common/MultilingualVoiceStudioModal';
import { VirtualTryOnModal } from './components/common/VirtualTryOnModal';

// NAVA — Next-Gen Social Network & Mission Ecosystem (17 Redefining Features)
import { NavaSocialHubModal } from './components/nava/NavaSocialHubModal';

// Next-Generation Autonomous Commerce & Delivery Brain (60 Pillars) & Zero-Admin Engine
import { AutonomousDeliveryBrainModal } from './components/autonomous/AutonomousDeliveryBrainModal';
import { AutonomousZeroAdminModal } from './components/autonomous/AutonomousZeroAdminModal';

// JustAway — "Just go. Just away." Spontaneous Travel & Nomad Gear Engine
import { JustAwayHubModal } from './components/justaway/JustAwayHubModal';

// Community Commerce Network & Earning Engine Modals
import { CommunityNetworkHubModal } from './components/network/CommunityNetworkHubModal';
import { DestinationDeliveryMatcherModal } from './components/network/DestinationDeliveryMatcherModal';
import { TimeToEarnModal } from './components/network/TimeToEarnModal';
import { ProductExchangeBarterModal } from './components/network/ProductExchangeBarterModal';
import { AIConditionInspectorModal } from './components/network/AIConditionInspectorModal';

// Human-First Social Commerce Redesign Modals & Main View
import { UnifiedHumanCommerceApp } from './components/human/UnifiedHumanCommerceApp';
import { OneTapSellingModal } from './components/human/OneTapSellingModal';
import { UniversalProfileIdentityModal } from './components/human/UniversalProfileIdentityModal';
import { SmartDeliveryCardModal } from './components/human/SmartDeliveryCardModal';
import { AdminCommandCenterModal } from './components/human/AdminCommandCenterModal';
import { AntiflyUnifiedOSLauncher } from './components/common/AntiflyUnifiedOSLauncher';

const AppContent: React.FC = () => {
  const {
    deviceMode,
    themeMode,
    setSelectedCategorySlug,
    isStoreCommunityOpen,
    setIsStoreCommunityOpen,
    activeStoreCommunitySellerId,
    websiteMainTab,
    isBookBuddyModalOpen,
    setIsBookBuddyModalOpen,
    isAddStoryModalOpen,
    setIsAddStoryModalOpen,
    isCreateSellerPostModalOpen,
    setIsCreateSellerPostModalOpen,
    isAutonomousBrainModalOpen,
    setIsAutonomousBrainModalOpen,
    isCommunityNetworkOpen,
    setIsCommunityNetworkOpen,
    isDestinationDetourOpen,
    setIsDestinationDetourOpen,
    isTimeToEarnOpen,
    setIsTimeToEarnOpen,
    isProductExchangeOpen,
    setIsProductExchangeOpen,
    isAIConditionInspectorOpen,
    setIsAIConditionInspectorOpen,
    isOneTapSellOpen,
    setIsOneTapSellOpen,
    isUniversalIdentityOpen,
    setIsUniversalIdentityOpen,
    isSmartDeliveryDecisionOpen,
    setIsSmartDeliveryDecisionOpen,
    isAdminCommandCenterOpen,
    setIsAdminCommandCenterOpen,
    isAutonomousZeroAdminOpen,
    setIsAutonomousZeroAdminOpen,
    isJustAwayHubOpen,
    setIsJustAwayHubOpen,
  } = useApp();

  const [websiteView, setWebsiteView] = useState<'home' | 'catalog' | 'account'>('home');
  const [isPlayStoreModalOpen, setIsPlayStoreModalOpen] = useState(false);
  const [isDriverLedgerModalOpen, setIsDriverLedgerModalOpen] = useState(false);

  const handleSelectCategory = (slug: string) => {
    setSelectedCategorySlug(slug);
    setWebsiteView('catalog');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleViewCatalog = () => {
    setWebsiteView('catalog');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div
      className="min-h-screen font-sans antialiased selection:bg-amber-500 selection:text-slate-800 bg-slate-50 text-slate-900"
    >
      {/* Top Global Ecosystem Switcher */}
      <DeviceSwitcher />
      <RoleExclusivityBanner />

      {/* Main View Switcher */}
      {deviceMode === 'website' && (
        <div id="antifly-website-container" className="flex flex-col min-h-[calc(100vh-50px)]">
          <WebsiteHeader currentView={websiteView} setCurrentView={setWebsiteView} />

          <main className="flex-1">
            {websiteView === 'home' && (
              <>
                {websiteMainTab === 'nearby' && (
                  <UnifiedHumanCommerceApp
                    onSelectCategory={handleSelectCategory}
                    onViewCatalog={handleViewCatalog}
                  />
                )}

                {websiteMainTab === 'status' && (
                  <WhatsAppStatusHub />
                )}

                {websiteMainTab === 'sellers' && (
                  <WebsiteSellersDirectory />
                )}

                {websiteMainTab === 'search' && (
                  <WebsiteInstagramSearch />
                )}

                {websiteMainTab === 'social' && (
                  <WebsiteSocialCommunity />
                )}

                {websiteMainTab === 'profile' && (
                  <WebsiteCustomerProfile />
                )}
              </>
            )}

            {websiteView === 'catalog' && (
              <WebsiteCatalog onGoHome={() => setWebsiteView('home')} />
            )}

            {websiteView === 'account' && (
              <WebsiteAccountOrders onGoHome={() => setWebsiteView('home')} />
            )}
          </main>

          <WebsiteFooter onNavigate={setWebsiteView} />
        </div>
      )}

      {(deviceMode === 'mobile-ios' || deviceMode === 'mobile-android') && (
        <div id="antifly-mobile-container" className="py-4">
          <MobileAppContainer />
        </div>
      )}

      {deviceMode === 'seller' && (
        <div id="antifly-seller-website-container">
          <SellerCentralPortal />
        </div>
      )}

      {deviceMode === 'seller-android' && (
        <div id="antifly-seller-android-container">
          <SellerAndroidApp />
        </div>
      )}

      {deviceMode === 'seller-ios' && (
        <div id="antifly-seller-ios-container">
          <SellerIOSApp />
        </div>
      )}

      {deviceMode === 'driver' && (
        <div id="antifly-driver-container">
          <DriverPartnerPortal />
        </div>
      )}

      {deviceMode === 'api-docs' && (
        <div id="antifly-api-container">
          <EcommerceAPIPlayground />
        </div>
      )}

      {deviceMode === 'admin' && (
        <div id="antifly-admin-container">
          <AdminLayout />
        </div>
      )}

      {/* Global Drawers & Modals (Shared across the ecosystem) */}
      <AuthModal />
      <CartDrawer />
      <CheckoutModal />
      <ProductDetailModal />
      <WiseAIChatModal />
      <VoiceSearchModal />
      <ImageSearchModal />
      <NotificationDrawer />
      <OrderTrackingModal />
      <ProductComparisonModal />
      <CMSModal />
      <ToastNotification />
      <GoogleAnalytics4Modal />
      <SEOManagerModal />
      <ProductFinderModal />

      {/* Antifly Ecosystem Feature Modals */}
      <SuperCoinsZoneModal />
      <MeeshoResellerModal />
      <MyntraStudioModal />
      <SizeAssistantModal />
      <GroupBuyModal />
      <LiveMapTrackingModal />
      <InvoiceModal />
      <FoodDeliveryModal />
      <WiseOneSubscriptionModal />
      <BankOffersModal />
      <OTTEntertainmentModal />

      {/* Store Communities & 1-on-1 Bargaining Chat */}
      <StoreCommunityModal
        isOpen={isStoreCommunityOpen}
        onClose={() => setIsStoreCommunityOpen(false)}
        initialSellerId={activeStoreCommunitySellerId}
      />
      <StoreChatDrawer />

      {/* Unified Multi-Role Vice-Versa Persona, Vendor Connect, Verified Badge & AI Admin */}
      <UnifiedRoleSwitcherModal />
      <VendorConnectMembershipModal />
      <VerifiedBadgeModal />
      <AdminAIChatbotModal />
      <ShortReelPlayerModal />
      <SellerRatingModal />

      {/* Play Store Growth Marketing & PDF Kit Modal */}
      <PlayStoreMarketingModal
        isOpen={isPlayStoreModalOpen}
        onClose={() => setIsPlayStoreModalOpen(false)}
      />

      {/* Driver Incentive & Credit Conversion Ledger Modal */}
      <AdminDriverIncentiveLedgerModal
        isOpen={isDriverLedgerModalOpen}
        onClose={() => setIsDriverLedgerModalOpen(false)}
      />

      {/* WhatsApp-Style 24H Status & Story System Modals */}
      <StoryViewerModal />
      <AddStoryModal
        isOpen={isAddStoryModalOpen}
        onClose={() => setIsAddStoryModalOpen(false)}
      />
      <CreateSellerPostModal
        isOpen={isCreateSellerPostModalOpen}
        onClose={() => setIsCreateSellerPostModalOpen(false)}
      />

      {/* Venture Book a Buddy 5km Broadcast Modal & Incoming Buddy Call Alert */}
      <BookBuddyModal
        isOpen={isBookBuddyModalOpen}
        onClose={() => setIsBookBuddyModalOpen(false)}
      />
      <IncomingBuddyCallModal />

      {/* Universal Save, Favorites Vault & Collection Moodboards */}
      <FavoritesHubModal />
      <SaveToCollectionModal />

      {/* Universal Disappearing Content & Auto-Delete Lifecycle Engine */}
      <UniversalAutoDeleteModal />

      {/* Super Coin & Diamond Economy Rewards Hub */}
      <SuperCoinDiamondRewardsModal />

      {/* Live Stream Commerce, Multilingual Vernacular Voice Studio & 3D AR Studio Modals */}
      <LiveStreamShoppingModal />
      <MultilingualVoiceStudioModal />
      <VirtualTryOnModal />

      {/* NAVA — Next-Gen Social Network & Mission Ecosystem (17 Redefining Features) */}
      <NavaSocialHubModal />

      {/* Next-Generation Autonomous Commerce & Delivery Brain (60 Pillars) */}
      <AutonomousDeliveryBrainModal
        isOpen={isAutonomousBrainModalOpen}
        onClose={() => setIsAutonomousBrainModalOpen(false)}
      />

      {/* Zero-Admin Autonomous Operations & Self-Governance Engine */}
      <AutonomousZeroAdminModal
        isOpen={isAutonomousZeroAdminOpen}
        onClose={() => setIsAutonomousZeroAdminOpen(false)}
      />

      {/* Community-Powered Commerce & Elastic Delivery Network Modals */}
      <CommunityNetworkHubModal
        isOpen={isCommunityNetworkOpen}
        onClose={() => setIsCommunityNetworkOpen(false)}
      />
      <DestinationDeliveryMatcherModal
        isOpen={isDestinationDetourOpen}
        onClose={() => setIsDestinationDetourOpen(false)}
      />
      <TimeToEarnModal
        isOpen={isTimeToEarnOpen}
        onClose={() => setIsTimeToEarnOpen(false)}
      />
      <ProductExchangeBarterModal
        isOpen={isProductExchangeOpen}
        onClose={() => setIsProductExchangeOpen(false)}
      />
      <AIConditionInspectorModal
        isOpen={isAIConditionInspectorOpen}
        onClose={() => setIsAIConditionInspectorOpen(false)}
      />

      {/* Human-First Social Commerce Redesign Modals */}
      <OneTapSellingModal
        isOpen={isOneTapSellOpen}
        onClose={() => setIsOneTapSellOpen(false)}
      />
      <UniversalProfileIdentityModal
        isOpen={isUniversalIdentityOpen}
        onClose={() => setIsUniversalIdentityOpen(false)}
      />
      <SmartDeliveryCardModal
        isOpen={isSmartDeliveryDecisionOpen}
        onClose={() => setIsSmartDeliveryDecisionOpen(false)}
      />
      <AdminCommandCenterModal
        isOpen={isAdminCommandCenterOpen}
        onClose={() => setIsAdminCommandCenterOpen(false)}
      />

      {/* JustAway Spontaneous Escapes & WanderKits Hub */}
      <JustAwayHubModal
        isOpen={isJustAwayHubOpen}
        onClose={() => setIsJustAwayHubOpen(false)}
      />

      {/* Floating Marketing & Driver Ledger Launcher Button (Visible in Driver/Seller modes) */}
      {(deviceMode === 'driver' || deviceMode === 'seller') && (
        <div className="fixed bottom-20 right-4 z-40 flex flex-col gap-2">
          <button
            onClick={() => setIsPlayStoreModalOpen(true)}
            className="bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-700 hover:to-amber-700 text-white font-black px-3.5 py-2 rounded-2xl text-xs shadow-lg flex items-center gap-1.5 transition-all hover:scale-105 cursor-pointer border border-white/20"
            title="Play Store Marketing Kit & PDF Generator"
          >
            <span>🚀 Play Store Kit</span>
          </button>
          {deviceMode === 'driver' && (
            <button
              onClick={() => setIsDriverLedgerModalOpen(true)}
              className="bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white font-black px-3.5 py-2 rounded-2xl text-xs shadow-lg flex items-center gap-1.5 transition-all hover:scale-105 cursor-pointer border border-white/20"
              title="Driver Incentive & Credit Ledger"
            >
              <span>💰 Driver Ledger</span>
            </button>
          )}
        </div>
      )}

      <AntiflyUnifiedOSLauncher />

      {/* Floating 3-in-1 App Ecosystem Dock */}
      <GlobalAppDock />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
